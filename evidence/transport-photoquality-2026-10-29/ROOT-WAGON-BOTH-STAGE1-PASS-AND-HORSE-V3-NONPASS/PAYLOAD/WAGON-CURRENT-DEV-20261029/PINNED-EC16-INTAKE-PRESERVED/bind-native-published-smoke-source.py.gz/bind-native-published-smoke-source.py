import argparse,datetime,hashlib,json,os,shutil,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('phase',choices=['before','after']);p.add_argument('output');a=p.parse_args()
R=Path('/tmp/chicago-wagon-20261029');O=Path(__file__).resolve().parent;D=Path(a.output);D.mkdir(parents=True,exist_ok=True)
G={**os.environ,'GIT_NO_LAZY_FETCH':'1'}
def git(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*args],cwd=R,env=G)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
receipt=json.loads((O/'ACTUAL-NORMAL-CHECKED-BRANCH-PUSH.json').read_bytes())
assert git('rev-parse','HEAD').decode().strip()==receipt['HEAD'];assert not git('status','--porcelain').strip()
assert git('rev-parse','HEAD^{tree}').decode().strip()==receipt['TREE']
index=git('ls-files','--stage','-z');binding=json.loads((O/'COMPLETE-NATIVE-PREFLIGHT-02/SOURCE-BINDING.json').read_bytes())
rows=[]
for old in binding['source_paths']:
 q=R/old['path'];row={'path':old['path']}
 if old.get('deleted'):assert not q.exists();row['deleted']=True
 else:assert q.is_file()and sha(q)==old['sha256'];row.update(bytes=q.stat().st_size,sha256=old['sha256'])
 rows.append(row)
mirror=R/'site/4d';assert mirror.is_dir();mir=[{'path':str(q.relative_to(mirror)),'bytes':q.stat().st_size,'sha256':sha(q)}for q in sorted(mirror.rglob('*'))if q.is_file()]
state=dict(HEAD=receipt['HEAD'],TREE=receipt['TREE'],APP=receipt['APP'],source_paths=rows,index_sha256=hashlib.sha256(index).hexdigest(),mirror_paths=mir,mirror_files=len(mir),mirror_bytes=sum(x['bytes']for x in mir))
if a.phase=='after':
 prior=json.loads((D/'SOURCE-AND-MIRROR-BEFORE.json').read_bytes());assert state==prior,'Source, index or published mirror changed during native smoke'
(D/('SOURCE-AND-MIRROR-'+a.phase.upper()+'.json')).write_text(json.dumps(state,indent=2)+'\n')
if a.phase=='before':(D/'COMPLETE-INDEX.z').write_bytes(index)
resource=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase=a.phase,TMPDIR=os.environ.get('TMPDIR','/tmp'),workspace_free_bytes=shutil.disk_usage('/workspace').free,tmp_free_bytes=shutil.disk_usage('/tmp').free)
for f in ['memory.max','memory.current','memory.events']:
 q=Path('/sys/fs/cgroup')/f
 if q.exists():resource[f]=q.read_text().strip()
(D/('RESOURCES-'+a.phase.upper()+'.json')).write_text(json.dumps(resource,indent=2)+'\n')
print(json.dumps(dict(phase=a.phase,HEAD=state['HEAD'],TREE=state['TREE'],APP=state['APP'],source_paths=len(rows),mirror_files=len(mir),mirror_bytes=state['mirror_bytes'],result='PASS exact source/index/published mirror binding',resources=resource)),flush=True)
