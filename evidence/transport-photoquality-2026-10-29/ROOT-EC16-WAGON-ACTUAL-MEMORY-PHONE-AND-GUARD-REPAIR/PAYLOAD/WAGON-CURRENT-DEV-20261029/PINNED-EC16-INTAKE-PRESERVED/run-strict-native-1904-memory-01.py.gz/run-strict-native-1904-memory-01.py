import hashlib, json, os, subprocess, time
from pathlib import Path

R=Path('/tmp/chicago-wagon-20261029'); A=R/'chicago/4d'; O=Path(__file__).resolve().parent
OUT=O/'STRICT-NATIVE-1904-MEMORY-01'
OWNER=O/'NATIVE-OWNER-PHASE-01/RESULT.json'
PREFIX=O.parent/'rail-native-ec16-owner-01'
assert 'GIT_NO_LAZY_FETCH' not in os.environ
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,env={**os.environ,'GIT_NO_LAZY_FETCH':'1'})
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as stream:
  for data in iter(lambda:stream.read(1048576),b''):h.update(data)
 return h.hexdigest()
result=json.loads(Path(str(PREFIX)+'.result.json').read_bytes()); cleanup=json.loads(Path(str(PREFIX)+'.cleanup.json').read_bytes())
assert result['returncode']==0 and not result['timed_out']
assert cleanup['cleanup_complete'] and not cleanup['remaining_owned_children']
binding=json.loads(OWNER.read_bytes()); assert binding['result'].startswith('PASS')
fixed=json.loads((O/'PRE-OWNER-FIXED-AUTHORED-AND-NATIVE-CONTROL-HASHES.json').read_bytes())
semantic_index=git('ls-files','--stage','-z')
def guard():
 assert git('rev-parse','HEAD').decode().strip()==binding['HEAD']
 assert git('rev-parse','MERGE_HEAD').decode().strip()==binding['MERGE_HEAD']
 assert git('write-tree').decode().strip()==binding['TREE']
 assert git('ls-files','--stage','-z')==semantic_index
 assert not git('diff','--name-only').strip()
 assert all(sha(R/p)==h for p,h in fixed.items())
 return [dict(path=p.relative_to(R/'site/4d').as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted((R/'site/4d').rglob('*')) if p.is_file()]
before=guard(); assert before
OUT.mkdir(exist_ok=False)
(OUT/'SOURCE-BINDING.json').write_text(json.dumps(binding,indent=2)+'\n')
(OUT/'COMPLETE-INDEX.z').write_bytes(semantic_index)
(OUT/'FULL-MIRROR-BEFORE.json').write_text(json.dumps(before,indent=2)+'\n')
target=OUT/'NATIVE-RAW.json'
cmd=['node','tools/measure_memory.mjs','--gate','--year','1904','--only','both','--no-snapshot','--json',str(target)]
print('START unchanged native1904 both profiles; independent original1125/400 comparison follows actual native JSON',flush=True)
start=time.monotonic();rc=1
try:
 with (OUT/'NATIVE-COMMAND.log').open('wb',buffering=0) as stream:rc=subprocess.run(cmd,cwd=A,stdout=stream,stderr=subprocess.STDOUT).returncode
finally:
 after=guard(); exact=after==before
 (OUT/'FULL-MIRROR-AFTER.json').write_text(json.dumps(after,indent=2)+'\n')
 d=dict(native_returncode=rc,seconds=time.monotonic()-start,command=cmd,HEAD=binding['HEAD'],MERGE_HEAD=binding['MERGE_HEAD'],TREE=binding['TREE'],APP=binding['APP'],source_complete_index_exact=True,full_mirror_before_after_exact=exact,mirror_files=len(before),native_meter_and_ceiling_bytes_unchanged=True)
 (OUT/'ACTUAL-NATIVE-CLOSURE.json').write_text(json.dumps(d,indent=2)+'\n')
 assert exact,'Full mirror changed during native memory reading'
assert rc==0,'Actual native memory gate failed; do not promote to strict PASS'
raw=json.loads(target.read_bytes()); rows=raw['rows']; assert len(rows)==2
assert {(r['year'],r['viewport']) for r in rows}=={('1904','desktop'),('1904','mobile')}
caps={'desktop':1125*1048576,'mobile':400*1048576}; comparison=[]
for row in rows:
 vp=row['viewport']; assert row['tier']==('full' if vp=='desktop' else 'light')
 assert row['pixelRatio']==1 and row['keepGeometry'] is False
 assert not row.get('errors',[]) and not row.get('error')
 for key in ['jsHeap','arrayBuffers','gpuBuffers','gpuTextures','total']:
  assert isinstance(row['totals'][key],(int,float)) and row['totals'][key]>0
 total=row['totals']['total']; assert total==sum(row['totals'][k] for k in ['jsHeap','arrayBuffers','gpuBuffers','gpuTextures'])
 comparison.append(dict(viewport=vp,tier=row['tier'],actual_bytes=total,actual_MiB=total/1048576,original_strict_cap_bytes=caps[vp],original_strict_cap_MiB=caps[vp]/1048576,pass_check=total<=caps[vp]))
strict=dict(result='PASS' if all(r['pass_check'] for r in comparison) else 'FAIL',scope='Actual native memory under ORIGINAL1125MiB desktop/400MiB phone; native current1300 desktop ceiling alone is insufficient',rows=comparison,native_raw_sha256=sha(target),HEAD=binding['HEAD'],MERGE_HEAD=binding['MERGE_HEAD'],TREE=binding['TREE'],APP=binding['APP'],source_and_complete_semantic_index_exact=True,full_published_mirror_exact=True,supervisor_cleanup='MUST verify actual outer cleanup separately',full_preflight_commit_push='UNRUN')
(OUT/'ORIGINAL-STRICT-COMPARISON.json').write_text(json.dumps(strict,indent=2)+'\n');print(json.dumps(strict),flush=True)
assert strict['result']=='PASS','Original strict memory ceiling failed; no cap edit/waiver'
