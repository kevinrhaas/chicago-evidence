import hashlib, json, os, shutil, subprocess, time
from pathlib import Path
R=Path('/tmp/chicago-wagon-20261029'); A=R/'chicago/4d'; O=Path(__file__).resolve().parent
OUT=O/'COMPLETE-NATIVE-PREFLIGHT-01'; BASE='ec16b8dd726fa7852ede885ef2d754d55b9b4c59'
assert 'GIT_NO_LAZY_FETCH' not in os.environ
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,env={**os.environ,'GIT_NO_LAZY_FETCH':'1'})
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as stream:
  for block in iter(lambda:stream.read(1048576),b''):h.update(block)
 return h.hexdigest()
def closed(prefix):
 d=json.loads(Path(str(prefix)+'.result.json').read_bytes());c=json.loads(Path(str(prefix)+'.cleanup.json').read_bytes())
 assert d['returncode']==0 and not d['timed_out'] and c['cleanup_complete'] and not c['remaining_owned_children']
closed(O.parent/'rail-native-ec16-owner-01');closed(O.parent/'rail-strict-native1904-ec16-01')
owner=json.loads((O/'NATIVE-OWNER-PHASE-01/RESULT.json').read_bytes())
strict=json.loads((O/'STRICT-NATIVE-1904-MEMORY-01/ORIGINAL-STRICT-COMPARISON.json').read_bytes())
assert owner['result'].startswith('PASS') and strict['result']=='PASS'
assert (strict['TREE'],strict['APP'])==(owner['TREE'],owner['APP'])
assert git('rev-parse','HEAD').decode().strip()==owner['HEAD']
assert git('rev-parse','MERGE_HEAD').decode().strip()==BASE
assert git('write-tree').decode().strip()==owner['TREE']
index=git('ls-files','--stage','-z');assert index==(O/'STRICT-NATIVE-1904-MEMORY-01/COMPLETE-INDEX.z').read_bytes()
assert not git('diff','--name-only').strip()
scratch=Path(os.environ.get('TMPDIR','/tmp'));demand=sum(((p.stat().st_size+4095)//4096)*4096 for root in [A/'data',A/'docs/RESEARCH'] for p in root.rglob('*') if p.is_file());free=shutil.disk_usage(scratch).free
disk=dict(TMPDIR=str(scratch),native_synthesis_copy_bytes=demand,reserve_bytes=512*1048576,free_bytes=free,pass_check=free>=demand+512*1048576)
(O/'ACTUAL-COMPLETE-PREFLIGHT-LAUNCH-DISK.json').write_text(json.dumps(disk,indent=2)+'\n');assert disk['pass_check'],'Scratch demand plus512MiB reserve does not fit'
OUT.mkdir(exist_ok=False)
paths=set(git('diff','--name-only','HEAD').decode().splitlines())|set(git('diff','--name-only',BASE).decode().splitlines())
paths.update(json.loads((O/'PRE-OWNER-FIXED-AUTHORED-AND-NATIVE-CONTROL-HASHES.json').read_bytes()))
rows=[dict(path=p,bytes=(R/p).stat().st_size,sha256=sha(R/p)) if (R/p).is_file() else dict(path=p,deleted=True) for p in sorted(paths)]
binding=dict(HEAD=owner['HEAD'],MERGE_HEAD=BASE,TREE=owner['TREE'],APP=owner['APP'],source_paths=rows,required_readers=1,check_jobs=4,BASE=BASE,TMPDIR=str(scratch),scope='Full check.sh on exact working/index candidate; preflight HEAD-only changelog/ID questions still see old9e until actual postcommit checks')
(OUT/'SOURCE-BINDING.json').write_text(json.dumps(binding,indent=2)+'\n');(OUT/'COMPLETE-INDEX.z').write_bytes(index)
# Prevent automatic packing of this partial clone; retain every borrowed/complete object.
subprocess.run(['git','config','--local','gc.auto','0'],cwd=R,check=True)
subprocess.run(['git','config','--local','maintenance.auto','false'],cwd=R,check=True)
print(json.dumps(dict(stage='ACTUAL COMPLETE PREFLIGHT START',TREE=owner['TREE'],APP=owner['APP'],BASE=BASE,paths=len(rows),disk=disk)),flush=True)
start=time.monotonic();rc=1
try:
 rc=subprocess.run(['bash','tools/preflight.sh'],cwd=A,env={**os.environ,'BASE':BASE,'C4D_GATE_REQUIRE_READERS':'1','C4D_GATE_REQUIRE_BASE':'1','CHECK_JOBS':'4'}).returncode
finally:
 for kind in ['check','cl','ids']:
  p=Path('/tmp/preflight-'+kind+'.log')
  if p.exists():shutil.copy2(p,OUT/('ACTUAL-INNER-'+kind+'.log'))
 d=dict(returncode=rc,seconds=time.monotonic()-start,HEAD=owner['HEAD'],MERGE_HEAD=BASE,TREE=owner['TREE'],APP=owner['APP'],scope=binding['scope'],actual_newHEAD_questions='PENDING after exact checked commit')
 (OUT/'ACTUAL-CLOSURE.json').write_text(json.dumps(d,indent=2)+'\n')
assert rc==0,'Complete native preflight failed; no commit/push'
assert git('ls-files','--stage','-z')==index and git('write-tree').decode().strip()==owner['TREE']
assert not git('diff','--name-only').strip()
assert not git('ls-files','--others','--exclude-standard').strip()
for row in rows:
 p=R/row['path'];assert (not p.exists()) if row.get('deleted') else (p.is_file() and sha(p)==row['sha256']),row['path']
d.update(result='PASS actual complete native preflight on exact working/index candidate; outer cleanup and real newHEAD checks still required',source_binding_and_complete_index_unchanged=True,target600_met=d['seconds']<=600,commit_push='UNRUN')
(OUT/'ACTUAL-CLOSURE.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
