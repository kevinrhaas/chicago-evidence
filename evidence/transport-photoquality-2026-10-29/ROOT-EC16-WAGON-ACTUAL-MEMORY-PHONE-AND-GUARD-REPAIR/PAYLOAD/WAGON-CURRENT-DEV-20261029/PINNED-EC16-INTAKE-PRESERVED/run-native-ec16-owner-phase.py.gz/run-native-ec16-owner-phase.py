import ast, hashlib, json, os, shutil, subprocess, time
from pathlib import Path

R=Path('/tmp/chicago-wagon-20261029'); A=R/'chicago/4d'
O=Path(__file__).resolve().parent; OUT=O/'NATIVE-OWNER-PHASE-01'
PIN='ec16b8dd726fa7852ede885ef2d754d55b9b4c59'
HEAD='9e14c138848ef854a535271fbd3feaae52dd4aa2'
assert 'GIT_NO_LAZY_FETCH' not in os.environ, 'Keep read-only Git guard environment out of native execution'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,env={**os.environ,'GIT_NO_LAZY_FETCH':'1'})
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for data in iter(lambda:f.read(1048576),b''):h.update(data)
 return h.hexdigest()
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert git('rev-parse','MERGE_HEAD').decode().strip()==PIN
assert git('ls-files','--stage','-z')==(O/'PRE-OWNER-EC16-COMPLETE-INDEX.z').read_bytes()
fixed=json.loads((O/'PRE-OWNER-FIXED-AUTHORED-AND-NATIVE-CONTROL-HASHES.json').read_bytes())
assert all(sha(R/p)==h for p,h in fixed.items()), 'Frozen authored/native-control input changed'
expected=['chicago/4d/data/liberties.json','chicago/4d/data/sidecars/1812/sources/uses.json','chicago/4d/data/sidecars/1835/sources/index.json','chicago/4d/data/sidecars/1904/sources/uses.json','chicago/4d/docs/measurements/source_use_coverage.md']
assert git('diff','--name-only','--diff-filter=U').decode().splitlines()==expected
scratch=Path(os.environ.get('TMPDIR','/tmp'))
demand=sum(((p.stat().st_size+4095)//4096)*4096 for root in [A/'data',A/'docs/RESEARCH'] for p in root.rglob('*') if p.is_file())
disk=dict(TMPDIR=str(scratch),copy_allocation_bytes=demand,reserve_bytes=512*1048576,free_bytes=shutil.disk_usage(scratch).free)
disk['pass_check']=disk['free_bytes']>=disk['copy_allocation_bytes']+disk['reserve_bytes']
(O/'ACTUAL-NATIVE-OWNER-LAUNCH-DISK.json').write_text(json.dumps(disk,indent=2)+'\n');print(json.dumps(disk),flush=True)
assert disk['pass_check'],'Native synthesis scratch plus512MiB reserve does not fit; no producer launched'
OUT.mkdir(exist_ok=False)
manifest=json.loads((A/'tools/derived_manifest.json').read_bytes())
owned={p for s in manifest['steps'] for p in s.get('resolves',[])}
b=json.loads((O/'PRE-INTAKE-SOURCE53-BINDING.json').read_bytes())
incoming=json.loads((O.parent/'PINNED-EC16-LIGHT-INTEGRATION-PLAN-UNAPPLIED.json').read_bytes())
paths={r['path'] for r in b['paths']+b['protected_checked_paths']}
paths.update(row.split('\t')[-1] for row in incoming['incoming_name_status'])
protected={p:sha(R/p) for p in sorted(paths-owned-{'chicago/4d/tools/derived_manifest.json'}) if (R/p).is_file()}
protected.update(fixed)
(OUT/'AUTHORED-INPUTS-BEFORE.json').write_text(json.dumps(protected,indent=2)+'\n')
commands=[]
def run(label,cmd):
 print('START '+label,flush=True);start=time.monotonic();log=OUT/(label+'.log')
 with log.open('wb') as stream: rc=subprocess.run(cmd,cwd=A,stdout=stream,stderr=subprocess.STDOUT).returncode
 row=dict(label=label,command=cmd,returncode=rc,seconds=time.monotonic()-start,log=str(log));commands.append(row)
 (OUT/'COMMANDS.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(row),flush=True)
 if rc:print(log.read_text(errors='replace')[-6000:],flush=True);raise SystemExit(rc)
 return log
run('canonical-liberty-owner',['python3','tools/compile_liberties.py'])
run('canonical-liberty-check',['python3','tools/compile_liberties.py','--check'])
actual=json.loads((A/'data/liberties.json').read_bytes())
incoming_lib=json.loads(git('show',PIN+':chicago/4d/data/liberties.json'))
want={r['id']:r for r in incoming_lib['liberties']};got={r['id']:r for r in actual['liberties']}
assert all(got.get(k)==v for k,v in want.items()), 'An accepted incoming liberty changed or disappeared'
old=json.loads(git('show',HEAD+':chicago/4d/data/liberties.json'))
own=[r for r in old['liberties'] if r['id'] not in want]
assert own and all(got.get(r['id'])==r for r in own), 'Own checked master liberty changed or disappeared'
subprocess.run(['git','add','--','chicago/4d/data/liberties.json'],cwd=R,check=True)
assert git('diff','--name-only','--diff-filter=U').decode().splitlines()==expected[1:]
log=run('supported-native-resolve',['node','tools/rederive.mjs','--resolve'])
assert 'and the last one moved nothing' in log.read_text(), 'No actual native fixed-point proof'
assert not git('diff','--name-only','--diff-filter=U').strip()
run('final-native-publisher',['bash','tools/publish.sh'])
run('native-mirror-guard',['node','tools/check_published.mjs'])
run('native-yearpack-guard',['node','tools/write_year_packs.mjs','--check','../../site/4d'])
budget=next(ast.literal_eval(n.value) for n in ast.parse((A/'tools/validate.py').read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SITE_BUDGET_MB' for t in n.targets))
total=sum(p.stat().st_size for p in (R/'site/4d').rglob('*') if p.is_file());assert total<=budget*1048576,(total,budget)
changed=[p for p,h in protected.items() if not (R/p).is_file() or sha(R/p)!=h];assert not changed,changed
unstaged=git('diff','--name-only').decode().splitlines();assert all(p in owned or p=='chicago/4d/tools/derived_manifest.json' for p in unstaged),unstaged
if unstaged:subprocess.run(['git','add','--',*unstaged],cwd=R,check=True)
assert not git('diff','--name-only').strip()
tree=git('write-tree').decode().strip();app=git('rev-parse',tree+':chicago/4d').decode().strip()
d=dict(result='PASS actual canonical owners/native fixedpoint/publisher/mirror/yearpacks; memory/fullgate remain pending',HEAD=HEAD,MERGE_HEAD=PIN,TREE=tree,APP=app,protected_authored_paths=len(protected),authored_changes=[],incoming_liberties_exact=len(want),own_master_liberties_exact=len(own),published_bytes=total,published_MiB=total/1048576,inherited_native_budget_MiB=budget,commands=commands,commit_push='UNRUN',strict_original1125_400_memory='UNRUN on new composed APP',complete_preflight='UNRUN on new composed APP')
(OUT/'RESULT.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
