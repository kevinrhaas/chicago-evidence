import hashlib,json,os,subprocess,time
from pathlib import Path
R=Path('/tmp/chicago-wagon-20261029');O=Path(__file__).resolve().parent
PAYLOAD=Path('/workspace/.cloud-setup/logs/transport-recovery/WAGON-FILELOADER-DIAGNOSIS-PREP-20261029/diagnose-native-farm-network.cjs')
OUT=O.parent/'NATIVE-FARM-NETWORK-DIAGNOSTIC-EC16-PHONE-01'
seal=O/'PHONE-DIAG-CURRENT-WHOLE-APP-SEAL.json';index=O/'PHONE-DIAG-CURRENT-COMPLETE-INDEX.z'
b=json.loads(seal.read_bytes());assert hashlib.sha256(PAYLOAD.read_bytes()).hexdigest()=='8eb6b6f159add1768fbc35f6bf0f418a73f086c6dbafc84e3097ebf283847f26'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,env={**os.environ,'GIT_NO_LAZY_FETCH':'1'})
def guard():
 assert git('rev-parse','HEAD').decode().strip()==b['HEAD']
 assert git('rev-parse','MERGE_HEAD').decode().strip()==b['MERGE_HEAD']
 assert git('write-tree').decode().strip()==b['TREE']
 assert git('ls-files','--stage','-z')==index.read_bytes()
 assert not git('diff','--name-only').strip()
guard();assert not OUT.exists();start=time.monotonic();rc=1
cmd=['node',str(PAYLOAD),str(R),str(OUT),str(seal),str(index),b['HEAD'],'phone']
try:rc=subprocess.run(cmd,cwd=R/'chicago/4d').returncode
finally:
 guard();(O/'PHONE-FILELOADER-DIAG-01-SOURCE-INDEX-CLOSED.json').write_text(json.dumps(dict(returncode=rc,seconds=time.monotonic()-start,HEAD=b['HEAD'],MERGE_HEAD=b['MERGE_HEAD'],TREE=b['TREE'],APP=b['APP'],whole_APP_seal_paths=len(b['paths']),complete_semantic_index_exact=True,working_source_no_unstaged=True,diagnostic_payload_sha256=hashlib.sha256(PAYLOAD.read_bytes()).hexdigest(),scope='Fresh phone-only chronology; native observer owns allsource/fullmirror beforeafter/error/HTTP/LOD/control assertions; originalBOTH remainsNONPASS',command=cmd),indent=2)+'\n')
raise SystemExit(rc)
