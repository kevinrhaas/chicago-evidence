"""Prepare an explicit source-current reconciliation; never rewrite original verdicts."""

import argparse
import datetime
import hashlib
import importlib.util
import json
import re
import subprocess
import sys
from pathlib import Path

O = Path(__file__).resolve().parent
R = Path('/tmp/chicago-wagon-20261029')
A = R / 'chicago/4d'
D = Path('/tmp/WAGON-OWNBOUND-PUBLISHED-DESKTOP-STAGE3-01')
PREFIX = O.parent.parent / 'rail-owned-wagon-bound-published-desktop-3-01'
POLICY_PATH = O / 'resource_admission_v10.py'
POLICY_SHA256 = 'eebdd83e057f31bc44f76e0b85acf037f28e4d06807c1070346e4e2802b6d65d'
MANIFEST_PATH = O / 'DESKTOP3-RESOURCE10-ORIGINAL-PINNED-ARTIFACTS-20261030.json'
MANIFEST_SHA256 = '722d3b14eeba315f3302e014f53212717a3c35d3986430cf374056d730adb3da'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def original_artifacts():
    assert sha(MANIFEST_PATH) == MANIFEST_SHA256
    data = json.loads(MANIFEST_PATH.read_bytes())
    for row in data['records']:
        path = Path(row['path'])
        assert path.is_file() and not path.is_symlink()
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], str(path)
    return data


parser = argparse.ArgumentParser()
parser.add_argument('--out', required=True)
args = parser.parse_args()
out = Path(args.out)
out.mkdir(exist_ok=False)
assert sha(POLICY_PATH) == POLICY_SHA256
spec = importlib.util.spec_from_file_location('reviewed_resource10', POLICY_PATH)
policy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy)
manifest = original_artifacts()
result_path = Path(str(PREFIX) + '.result.json')
cleanup_path = Path(str(PREFIX) + '.cleanup.json')
result = json.loads(result_path.read_bytes())
cleanup = json.loads(cleanup_path.read_bytes())
verdict = json.loads((D / 'ACTUAL-PARTIAL-VERDICT.json').read_bytes())
old_before = json.loads((D / 'ACTUAL-LAUNCH-RESOURCES.json').read_bytes())
old_after = json.loads((D / 'ACTUAL-CLOSED-MEMORY-EVENTS.json').read_bytes())
source_before = json.loads((D / 'SOURCE-AND-MIRROR-BEFORE.json').read_bytes())
source_after = json.loads((D / 'SOURCE-AND-MIRROR-AFTER.json').read_bytes())
log = Path(str(PREFIX) + '.log').read_text(errors='replace')
summaries = re.findall(r'(\d+) passed, (\d+) failed', log)
assert summaries == [('107', '0')] and log.rstrip().endswith('SMOKE PASS')
assert result['returncode'] == 0 and not result['timed_out']
assert result['requested_timeout_seconds'] == result['effective_timeout_seconds'] == 600
assert result['timeout_override_reason'] is None
assert result['command'] == ['node', 'tools/smoke_renderer.mjs', '--published']
assert result['cwd'] == str(A)
assert cleanup['cleanup_complete'] and cleanup['remaining_owned_children'] == []
assert verdict['native_assertions_complete_PASS'] is True
assert verdict['resource_event_admission_before_after_PASS'] is False
assert verdict['result'].startswith('NONPASS') and verdict['passed_checks'] == 107 and verdict['failed_checks'] == 0
assert old_after['accepted'] is False and old_after['native_assertions_complete_PASS'] is True
assert old_before['memory_events']['max'] == 1269 and old_after['actual_memory_events']['max'] == 5144
assert verdict['memory_events_baseline_sha256'] == old_after['baseline_sha256'] == policy.BASELINE_SHA256
assert source_before == source_after
assert (source_before['HEAD'], source_before['TREE'], source_before['APP']) == (manifest['HEAD'], manifest['TREE'], manifest['APP'])
old_before_check = policy.check_snapshot(old_before)
old_event_check = policy.check_events(old_before['memory_events'], old_after['actual_memory_events'])
assert old_before_check['accepted'] and old_event_check['accepted']

current_before = policy.snapshot()
(out / 'ACTUAL-CURRENT-RESOURCES-BEFORE.json').write_text(json.dumps(current_before, indent=2) + '\n')
assert policy.check_snapshot(current_before)['accepted']
assert current_before['memory_events']['max'] >= old_after['actual_memory_events']['max']
with (out / 'FRESH-SOURCE-BINDING.log').open('wb') as log_out:
    subprocess.run([sys.executable, str(O / 'bind-checked-followup-published-source.py'), 'before', str(out)],
                   cwd=A, stdout=log_out, stderr=subprocess.STDOUT, check=True)
fresh_source_path = out / 'SOURCE-AND-MIRROR-BEFORE.json'
assert json.loads(fresh_source_path.read_bytes()) == source_before
assert (out / 'COMPLETE-INDEX.z').read_bytes() == (D / 'COMPLETE-INDEX.z').read_bytes()
current_after = policy.snapshot()
(out / 'ACTUAL-CURRENT-RESOURCES-AFTER.json').write_text(json.dumps(current_after, indent=2) + '\n')
current_check = policy.check_pair(current_before, current_after)
assert current_check['accepted']
assert sha(POLICY_PATH) == POLICY_SHA256
original_artifacts()

receipt = {
    'schema': 'explicit-native-pass-resource10-source-current-reconciliation-v1',
    'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'result': 'PASS explicit resource10 reconciliation for existing desktop3 native PASS only',
    'HEAD': manifest['HEAD'], 'TREE': manifest['TREE'], 'APP': manifest['APP'],
    'viewport': 'desktop', 'stage': '3', 'native_checks': 107, 'native_failed_checks': 0,
    'original_native_seconds': result['seconds'], 'original_native_timeout_seconds': 600,
    'original_native_result': {'path': str(result_path), 'sha256': sha(result_path)},
    'original_cleanup': {'path': str(cleanup_path), 'sha256': sha(cleanup_path)},
    'original_verdict': {'path': str(D / 'ACTUAL-PARTIAL-VERDICT.json'), 'sha256': sha(D / 'ACTUAL-PARTIAL-VERDICT.json')},
    'original_fixed_counter_resource_verdict_preserved_NONPASS': True,
    'original_artifact_manifest': {'path': str(MANIFEST_PATH), 'sha256': MANIFEST_SHA256},
    'policy_code': {'path': str(POLICY_PATH), 'sha256': POLICY_SHA256},
    'trusted_initial_baseline_sha256': policy.BASELINE_SHA256,
    'original_before_healthy_under_resource10': old_before_check,
    'original_event_transition_under_resource10': old_event_check,
    'fresh_source_binding': {'path': str(fresh_source_path), 'sha256': sha(fresh_source_path)},
    'current_resources_before': {'path': str(out / 'ACTUAL-CURRENT-RESOURCES-BEFORE.json'), 'sha256': sha(out / 'ACTUAL-CURRENT-RESOURCES-BEFORE.json')},
    'current_resources_after': {'path': str(out / 'ACTUAL-CURRENT-RESOURCES-AFTER.json'), 'sha256': sha(out / 'ACTUAL-CURRENT-RESOURCES-AFTER.json')},
    'current_postclosure_resource_check': current_check,
    'original_after_full_resource_components_available': False,
    'qualification_scope': 'Original native107/0/source/cleanup proof plus original healthy launch and event transition; later fresh source/index/fullmirror and healthy postclosure resources. Current snapshots are later measurements, never retargeted as original run-end components.',
    'new_browser_or_native_test_run_performed': False,
    'original_artifacts_rewritten': False,
    'whole_published_gate_PASS': False,
}
path = out / 'ACTUAL-EXPLICIT-RECONCILIATION.json'
path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'result': receipt['result'], 'receipt': str(path), 'sha256': sha(path), 'scope': receipt['qualification_scope']}), flush=True)
