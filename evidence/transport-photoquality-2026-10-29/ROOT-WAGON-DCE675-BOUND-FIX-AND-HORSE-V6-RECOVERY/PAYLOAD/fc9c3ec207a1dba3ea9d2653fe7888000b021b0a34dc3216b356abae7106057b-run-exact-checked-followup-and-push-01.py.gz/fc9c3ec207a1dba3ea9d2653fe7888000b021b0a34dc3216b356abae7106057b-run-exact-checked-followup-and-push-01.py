import datetime,hashlib,json,os,subprocess
from pathlib import Path
R=Path('/tmp/chicago-wagon-20261029');A=R/'chicago/4d';O=Path(__file__).resolve().parent;L=O.parent.parent;BASE='ec16b8dd726fa7852ede885ef2d754d55b9b4c59';BRANCH='steward/t2793-wagon-photoquality-20261026';E={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_TERMINAL_PROMPT':'0','C4D_GATE_REQUIRE_BASE':'1'}
def git(*x):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false',*x],cwd=R,env=E).decode().strip()
def closed(name):
 d=json.loads((L/(name+'.result.json')).read_bytes());c=json.loads((L/(name+'.cleanup.json')).read_bytes());assert d['returncode']==0 and not d['timed_out']and c['cleanup_complete']and not c['remaining_owned_children']
for name in ['rail-exact-owner-targeted-mobile-2-3-01','rail-exact-owner-full-preflight-01']:closed(name)
b=json.loads((O/'SEALED-CANDIDATE.json').read_bytes());f=O/'COMPLETE-NATIVE-PREFLIGHT-01';full=json.loads((f/'ACTUAL-CLOSURE.json').read_bytes());assert full['result'].startswith('PASS')and(full['TREE'],full['APP'])==(b['TREE'],b['APP']);assert git('rev-parse','HEAD')==b['HEAD']and git('write-tree')==b['TREE'];assert subprocess.check_output(['git','ls-files','--stage','-z'],cwd=R)==(f/'COMPLETE-INDEX.z').read_bytes();assert not git('diff','--name-only')and not git('ls-files','--others','--exclude-standard');assert git('branch','--show-current')==BRANCH
for row in json.loads((f/'SOURCE-BINDING.json').read_bytes())['source_paths']:
 p=R/row['path'];assert(not p.exists())if row.get('deleted')else(p.is_file()and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']),row['path']
subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
message=O/'CHECKED-FOLLOWUP-MESSAGE.txt';message.write_text('T-2793: measure yard objects by their emitted pick ranges\n\nUse exact existing ownership for the Green Tree bench, shed and covered\nwagon after the accepted T-2376 bay move made their search radii overlap.\nKeep every original wall, roof and bench limit. Restore the exact111470\nfrontage census after the accepted T-2385 walk-length restoration.\n\nThe only runtime addition annotates three existing pick spans; all emitted\ngeometry, materials and original pick ranges remain unchanged. The actual\npublished mobile2-3 gate and full native preflight passed on this exact tree.\n')
subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','commit','--file',str(message)],cwd=R,env=E,check=True)
head=git('rev-parse','HEAD');assert git('rev-parse','HEAD^1')==b['HEAD'];assert git('rev-parse','HEAD^{tree}')==b['TREE']and git('rev-parse','HEAD:chicago/4d')==b['APP'];assert not git('status','--porcelain');assert git('merge-base',BASE,'HEAD')==BASE
checks=[]
for label,cmd in [
 ('real-newHEAD-changelog-entry',['node','tools/check-changelog-entry.mjs',BASE,'HEAD']),
 ('real-newHEAD-ID-collision',['node','tools/resolve_id_collisions.mjs','--base',BASE,'--check']),
 ('real-newHEAD-changelog-contract',['node','tools/check-changelog.mjs']),
 ('real-newHEAD-pending-entries',['node','tools/changelog-entries.mjs','--check']),
 ('real-newHEAD-pinned-history',['node','tools/changelog-history.mjs','--base',BASE])]:
 p=subprocess.run(cmd,cwd=A,env=E,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(O/(label+'.log')).write_bytes(p.stdout);print(p.stdout.decode(errors='replace'),flush=True);checks.append(dict(label=label,command=cmd,returncode=p.returncode,log_sha256=hashlib.sha256(p.stdout).hexdigest()));assert p.returncode==0,label
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
remote=git('ls-remote','--heads','origin','refs/heads/'+BRANCH).split();assert len(remote)==2 and remote[0]==b['HEAD'],remote
out=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),HEAD=head,parent=b['HEAD'],TREE=b['TREE'],APP=b['APP'],BASE=BASE,checks=checks,remote_before=remote[0],push='PENDING',DEV_merge='UNRUN; no API/CI/ready/merge claim')
(O/'ACTUAL-NEWHEAD-ALL-CHECKS.json').write_text(json.dumps(out,indent=2)+'\n')
p=subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','push','origin',head+':refs/heads/'+BRANCH],cwd=R,env=E,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(O/'ACTUAL-NORMAL-FOLLOWUP-PUSH.log').write_bytes(p.stdout);print(p.stdout.decode(errors='replace'),flush=True);assert p.returncode==0,'Normal existing feature push failed'
remote=git('ls-remote','--heads','origin','refs/heads/'+BRANCH).split();assert len(remote)==2 and remote[0]==head;assert git('rev-parse','HEAD')==head and git('rev-parse','HEAD^{tree}')==b['TREE']and not git('status','--porcelain')
out.update(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),push='PASS actual normal checked feature push',remote_after=head,clean=True,PR=1340);(O/'ACTUAL-NORMAL-CHECKED-FOLLOWUP-PUSH.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
