import argparse,datetime,json,os,shutil,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('viewport',choices=['mobile','desktop']);a=p.parse_args();v=a.viewport
O=Path(__file__).resolve().parent;R=Path('/tmp/chicago-wagon-20261029');A=R/'chicago/4d';L=O.parent.parent
head=json.loads((O/'ACTUAL-NORMAL-CHECKED-FOLLOWUP-PUSH.json').read_bytes())['HEAD']
out=Path('/tmp')/f'WAGON-OWNBOUND-PUBLISHED-{v.upper()}-STAGE1-01';prefix=L/f'rail-owned-wagon-bound-newHEAD-published-{v}-1-01';assert not out.exists()and not Path(str(prefix)+'.log').exists()
assert json.loads((R/'site/4d/build.json').read_bytes())['version']==head[:9],'canonical mirror must stamp actual new HEAD'
out.mkdir();(out/'PNGS').mkdir()
with(out/'STANDING-RECORD.log').open('wb')as f:subprocess.run(['node','tools/dev-smoke-state.mjs','ask','--viewport',v,'--stage','1'],cwd=A,stdout=f,stderr=subprocess.STDOUT,check=True)
bind=O/'bind-checked-followup-published-source.py'
with(out/'BINDING-BEFORE.log').open('wb')as f:subprocess.run([sys.executable,str(bind),'before',str(out)],cwd=A,stdout=f,stderr=subprocess.STDOUT,check=True)
resource=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),memory_free_bytes=int(Path('/sys/fs/cgroup/memory.max').read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text()),workspace_free_bytes=shutil.disk_usage('/workspace').free,tmp_free_bytes=shutil.disk_usage('/tmp').free)
(out/'ACTUAL-LAUNCH-RESOURCES.json').write_text(json.dumps(resource,indent=2)+'\n')
assert resource['memory_free_bytes']>=4*1024**3 and resource['workspace_free_bytes']>=512*1024**2 and resource['tmp_free_bytes']>=1024**3,'Resource launch reserve failed; no browser launched'
assert not Path('/workspace/.cloud-setup/transport-browser-resource-pause.json').exists(),'Root browser pause active; no browser launched'
tmp=Path('/tmp')/f'wg-bound-n{v[0]}1';tmp.mkdir(mode=0o700,exist_ok=False)
env={**os.environ,'TMPDIR':str(tmp),'SMOKE_VIEWPORT':v,'SMOKE_STAGE':'1','SMOKE_TIMING':'1','SMOKE_SHOTS':str(out/'PNGS')}
rc=subprocess.run([sys.executable,'/workspace/.cloud-setup/transport-supervise.py','--prefix',str(prefix),'--cwd',str(A),'--timeout','600','--','node','tools/smoke_renderer.mjs','--published'],cwd=A,env=env).returncode
result=json.loads(Path(str(prefix)+'.result.json').read_bytes());cleanup=json.loads(Path(str(prefix)+'.cleanup.json').read_bytes())
with(out/'BINDING-AFTER.log').open('wb')as f:subprocess.run([sys.executable,str(bind),'after',str(out)],cwd=A,stdout=f,stderr=subprocess.STDOUT,check=True)
passed=rc==0 and result['returncode']==0 and not result['timed_out']and cleanup['cleanup_complete']and not cleanup['remaining_owned_children']
verdict=dict(HEAD=head,TREE=json.loads((O/'SEALED-CANDIDATE.json').read_bytes())['TREE'],APP=json.loads((O/'SEALED-CANDIDATE.json').read_bytes())['APP'],result='PASS native partial group only'if passed else'NONPASS actual native partial group',viewport=v,stage='1',seconds=result['seconds'],timed_out=result['timed_out'],cleanup_complete=cleanup['cleanup_complete'],remaining_owned_children=len(cleanup['remaining_owned_children']),source_index_fullmirror_unchanged=True,whole_published_gate='PENDING until all required groups pass')
(out/'ACTUAL-PARTIAL-VERDICT.json').write_text(json.dumps(verdict,indent=2)+'\n');print(json.dumps(verdict),flush=True)
raise SystemExit(0 if passed else 1)
