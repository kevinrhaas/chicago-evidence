# V6 quiet head/neck idle — proposal only

No producer, GLB, canonical installation, native run or application edit has been made for V6. All V2/V3/V4/V5 assets, frozen source maps and failed results remain immutable. This is an explicitly narrower quiet-idle feature, not a passing version of the failed17-track head-and-tail gesture. Tail gesture, walk/trot, riders/drivers and broader photographic acceptance remain open.

## Exact source feasibility

The immutable V2 candidate0ced8a09e27da047ad404c902e9d032e43654393027199db8dfd9c315be17929 contains the original13-track posture clip and the added17-track natural clip. The13 original channels and samplers are an exact prefix of17: BODY1.translation and the twelve existing planted-leg rotations. Channels13/14 add NECK2.rotation and HEAD3.rotation, using existing output accessors232/233. Channels15/16 add TAIL_BASE4.rotation and TAIL_TIP5.rotation, output accessors234/235. Every channel has65keys, shared input212, native LINEAR interpolation. Full input/output stream SHA values are in EXACT-TRACK-DIFF-AND-OLD13-TAIL-FEASIBILITY.json.

A new named15-track quiet clip can retain channels/samplers0–14 exactly and omit only15/16. No key, time, quaternion, amplitude, duration, body/leg curve or original animation is rewritten. Append this as animation2, keeping original animation0 (13tracks) and the failed broader animation1 (17tracks) exact and present. No extra BIN animation data is needed: the new clip references existing samplers/accessors. Its new scope/UNRUN provenance is explicit.

In the actual recorded old13 native129 report, TAIL_BASE4 relative to BODY1 and TAIL_TIP5 relative toTAIL_BASE4 have exactly zero matrix/rotation change. BODY1 retains its existing4mm vertical posture motion. NECK2→HEAD3 and TAIL4→TAIL5 are separate branches below BODY1, so the new retained head/neck channels do not target the tail branch. This establishes source feasibility; it is not native qualification of the new clip.

## Proposed source and asset scope

Start from V2's immutable candidate/pair. Apply only the already produced V4 HEAD skin field, byte-exact across all2306 head/neck rows. Keep all969 original V2 TAIL rows byte-exact, all BODY/EYE/JAW binding, all1184 rigid skull-core rows, geometry, UVs, images, node rests, rig/IBMs and all existing clip bytes. V4's tail field and V5's transfer are not adopted. The only new selected motion is the independently named quiet15 clip, preserving full2degree/.75degree neck and4degree/1.5degree head curves exactly from the existing17 source.

Proposed outside folder: HORSE-QUIET-HEAD-NECK-IDLE-V6-PROPOSAL-20261029. New candidate name horse-sevket-quiet-head-neck-idle-v6.glb; paired name horse-sevket-original925-head-neck-binding-v6.glb; selected clip sevket_reconstructed_quiet_head_neck_idle_v1. A later first-class implementation would use tools/transport/horse_quiet_head_neck_idle_v6 with its own declared input/admission pins and the immutable original36 metrics/physical loop. No V3/V4/V5 receipt or hash is retargeted.

The candidate's actual selected clip must be found by its exact new name and asserted to have15 tracks, not by the old natural-idle index1 helper. Animation1 remains the unqualified17-track gesture and must never be selected by a quiet-idle fallback.

## Source controls and actual-native proof plan

Source export admission must prove exact original13/17 animation JSON, exact original BIN except the allowed V4 HEAD skin bytes, exact969TAIL and BODY/EYE/core/geometry/images/rig/IBMs, full candidate/pair skin correspondence and exact15-track references to source channels0–14. Negative controls must refuse adding either tail channel, silently selecting17, removing neck/head, changing any retained curve/key/interpolation/amplitude, BODY/EYE/unlisted skin or weld/core/palette/mass changes, geometry/image edits and wrong paired ancestry. Omission of the broader gesture is recorded as feature scope, not hidden as a15-track version of the old17 verdict.

Native old13 parity/physical and quiet15 physical are fresh separate stages. A real GLTFLoader imports the new clip, a real AnimationMixer selects the exact quiet name, restores native bind PRS normally before each sample, advances all65 keys plus64 midpoints and updates every actual world/skeleton matrix. Never take the old17 sampled matrices and zero tail entries. Generate independent65-key expected reference matrices from the literal quiet15 source tracks and source hierarchy/rests, not by editing the old17 output dump. Preserve every original edge/area/normal/hoof/loop/interface/socket limit.

Measure all969 tail vertices under the actual quiet15 mixer against the actual old13 mixer at the same129 times, plus tail relative-bone matrices, while separately proving actual nonzero neck/head motion. This catches a wrong17 selection and proves tail remains the quiet inherited posture rather than a fabricated reference. Old13 complete12838-vertex/shader-normal parity still requires its own actual original-parent comparison.

After actual native physical PASS, capture all129 paired925 BODY/EYE Float64 frames. The actual imported quiet15 AnimationClip may drive an independent native AnimationMixer on the unchanged paired925 hierarchy; require exact node/skeleton correspondence. This uses real clip bindings on both models rather than manually fixing candidate tail matrices. Then run the original14mm/7mm/interface/crossing posed qualification under new source/code bindings. Real unheld published desktop/phone head/neck motion and photographic review, full required source gate, checked feature push and ordinary current CI remain necessary before runtime adoption/merge. Every V6 stage is currently UNRUN.
