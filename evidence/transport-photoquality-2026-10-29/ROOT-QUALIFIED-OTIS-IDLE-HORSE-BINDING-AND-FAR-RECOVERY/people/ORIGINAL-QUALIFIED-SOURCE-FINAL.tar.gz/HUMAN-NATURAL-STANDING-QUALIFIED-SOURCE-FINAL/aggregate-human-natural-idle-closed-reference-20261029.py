#!/usr/bin/env python3
"""Collate two completed scoped native runs; never convert a partial group to eight."""
from pathlib import Path
import hashlib
import json

BASE = Path('/workspace/.cloud-setup/logs/transport-recovery')
APP = Path('/tmp/chicago-transport-resume-20261029/chicago/4d')
GROUPS = (
    ('HUMAN-NATURAL-STANDING-CLOSED-REFERENCE-LOD1-01', 'human-natural-standing-closed-reference-lod1-01'),
    ('HUMAN-NATURAL-STANDING-CLOSED-REFERENCE-REMAINING7-01', 'human-natural-standing-closed-reference-remaining7-01'),
)


def need(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    recipe = read(APP/'data/humans/animations/natural-standing-v1.json')
    expected = {row['file'] for row in recipe['parents']}
    need(len(expected) == 8, 'eight unique recipe paths required')
    models = {}
    common_pins = common_children = common_reference = None
    groups = []
    for directory, prefix in GROUPS:
        report_path = BASE/directory/'RESULT.json'
        result_path, cleanup_path = BASE/(prefix+'.result.json'), BASE/(prefix+'.cleanup.json')
        report, supervisor, cleanup = read(report_path), read(result_path), read(cleanup_path)
        need(supervisor['returncode'] == 0 and not supervisor['timed_out'], 'scoped supervisor did not pass: '+prefix)
        need(cleanup['cleanup_complete'] and cleanup['remaining_owned_children'] == [], 'owned cleanup incomplete')
        need(report['selected_scope_passed'] and not report['all_eight_passed'], 'expected a truthful passing subset, not a claimed eight-file run')
        need(not report.get('error') and report['errors'] == [], 'actual browser errors')
        lifecycle = report['lifecycle']
        need(lifecycle['passed'] and lifecycle['slow_frame_elapsed_s'] == 1 and lifecycle['acquired'] == lifecycle['released']
             and lifecycle['remaining_actors'] == 0 and lifecycle['webgl_requests'] == 0, 'native actor lifecycle mismatch')
        need(set(report['selected_files']) == {r['file'] for r in report['files']}, 'selected/actual model census mismatch')
        for model in report['files']:
            name = model['file']
            need(name in expected and name not in models, 'duplicate or extra model: '+name)
            need(model['passed'] and not model.get('error') and model['webgl_requests'] == 0, 'model did not pass: '+name)
            samples = model['samples']
            need(len(samples) == 129 and [s['time_s'] for s in samples] == [8*i/128 for i in range(129)], 'actual key/midpoint grid incomplete')
            need(all(s['footwear_displacement_m'] < 1e-9 and s['new_or_deeper_penetration_vertices'] == 0 for s in samples), 'foot/anatomical guard failed')
            need(model['footwear_maximum_displacement_m'] < 1e-9 and model['upper_body_maximum_displacement_m'] > .01
                 and model['new_clearance_failures'] == [], 'model motion/contact summary mismatch')
            need(model['anatomical_reference_same_native_clip_and_time']
                 and model['maximum_reference_subject_bone_world_matrix_difference'] <= 1e-5
                 and len(model['reference_body_morph_weights']) == 3
                 and all(v == 0 for v in model['reference_body_morph_weights']), 'reference pose/morph alignment mismatch')
            penetration = model['penetration_negative_control']
            need(penetration['passed'] and all(not r['inside'] for r in penetration['source_outside_rays'])
                 and all(r['inside'] for r in penetration['injected_inside_rays'])
                 and penetration['rejection']['reason'] == 'newly inside BODY', 'injected garment penetration was not refused')
            need(model['foot_drift_negative_control']['passed'] and model['foot_drift_negative_control']['injected_vertex_displacement_m'] > 1e-9,
                 'injected shoe drift was not refused')
            pins = model['implementation_and_parent_pins_before']
            children = model['candidate_sha256_before_all']
            reference = model['anatomical_reference']
            need(pins == model['implementation_and_parent_pins_after'] and children == model['candidate_sha256_after_all'], 'native source/child guards changed')
            need(set(children) == expected and model['sha256'] == children[name], 'candidate identity mismatch')
            if common_pins is None:
                common_pins, common_children, common_reference = pins, children, reference
            need(pins == common_pins and children == common_children and reference == common_reference, 'groups/models do not share final implementation/parents/children/reference')
            model_path = BASE/directory/(name.replace('/', '__')+'.json')
            need(read(model_path) == model, 'durable per-model record differs from group result')
            models[name] = {'file': name, 'sha256': model['sha256'], 'samples': len(samples),
                            'footwear_maximum_displacement_m': model['footwear_maximum_displacement_m'],
                            'upper_body_maximum_displacement_m': model['upper_body_maximum_displacement_m'],
                            'robust_classifications': model['robust_classifications'],
                            'maximum_reference_subject_bone_world_matrix_difference': model['maximum_reference_subject_bone_world_matrix_difference'],
                            'actual_open_render_body_unsigned_distance_increase_m': model['actual_render_body_unsigned_distance_maximum_increase_m'],
                            'actual_open_render_body_unsigned_distance_decrease_m': model['actual_render_body_unsigned_distance_maximum_decrease_m'],
                            'inherited_inside_vertices_observed': len(model['inherited_inside_vertices_observed']),
                            'record': str(model_path), 'record_sha256': digest(model_path)}
        groups.append({'directory': directory, 'supervisor_prefix': prefix, 'seconds': supervisor['seconds'],
                       'result_sha256': digest(result_path), 'cleanup_sha256': digest(cleanup_path),
                       'report_sha256': digest(report_path), 'selected_files': report['selected_files']})
    need(set(models) == expected, 'exact eight-model union incomplete')
    for name, wanted in common_pins.items():
        need(digest(APP/name) == wanted, 'current implementation/parent differs: '+name)
    candidate = Path('/tmp/human-natural-standing-20261029-source-04-final')
    for name, wanted in common_children.items():
        need(digest(candidate/name) == wanted, 'current child differs: '+name)
    summary = {'status': 'EXACT_EIGHT_SAME_FINAL_SOURCE_NATIVE_129_ONLY_PASS', 'all_eight_passed': True,
               'implementation_and_parent_pins': common_pins, 'candidate_pins': common_children,
               'anatomical_reference': common_reference, 'groups': groups,
               'models': [models[name] for name in sorted(models)],
               'scope': 'Actual native loader/Meshopt/mixer/skin readback, planted footwear and finite garment vertices against the closed master-LOD0 anatomical reference. Actual coarse render BODYs remain open; their unsigned deltas are disclosed. No continuous full fit, actual scene, photographic or canonical CI transfer.',
               'active_app_asset_adoption': False, 'published_scene_accepted': False,
               'photographic_accepted': False, 'whole_ticket_accepted': False}
    out = BASE/'HUMAN-NATURAL-STANDING-EXACT-EIGHT-NATIVE-SUMMARY.json'
    need(not out.exists(), 'fresh aggregate path required')
    out.write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps({'all_eight_passed': True, 'model_count': len(models), 'summary': str(out), 'sha256': digest(out)}))


if __name__ == '__main__':
    main()
