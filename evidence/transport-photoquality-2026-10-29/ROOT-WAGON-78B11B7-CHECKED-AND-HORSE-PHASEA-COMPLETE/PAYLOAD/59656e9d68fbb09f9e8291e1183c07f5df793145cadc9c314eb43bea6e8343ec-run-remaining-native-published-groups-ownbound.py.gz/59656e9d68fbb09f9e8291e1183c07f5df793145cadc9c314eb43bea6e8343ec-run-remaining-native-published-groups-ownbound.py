import datetime,json,os,re,shutil,subprocess,sys
from pathlib import Path
O=Path(__file__).resolve().parent; R=Path('/tmp/chicago-wagon-20261029'); A=R/'chicago/4d'; L=O.parent.parent
SUP='/workspace/.cloud-setup/transport-supervise.py'; BIND=O/'bind-checked-followup-published-source.py'
plan=json.loads((O/'ACTUAL-NEWHEAD-NATIVE-SMOKE-PLAN-SUMMARY.json').read_bytes());receipt=json.loads((O/'ACTUAL-NORMAL-CHECKED-FOLLOWUP-PUSH.json').read_bytes());assert(plan['HEAD'],plan['TREE'],plan['APP'])==(receipt['HEAD'],receipt['TREE'],receipt['APP'])
bridge=json.loads((O/'TARGETED-TO-COMMITTED-PUBLISH-COVERAGE-BRIDGE.json').read_bytes());assert bridge['result'].startswith('PASS')and bridge['committed_HEAD']==plan['HEAD']and(bridge['TREE'],bridge['APP'])==(plan['TREE'],plan['APP'])
# Both first-profile groups have actually closed and been rebound, before this
# controller is started. Never assume an existing unclosed transcript is a PASS.
for v in ['MOBILE','DESKTOP']:
 d=json.loads((Path('/tmp')/f'WAGON-OWNBOUND-PUBLISHED-{v}-STAGE1-01/ACTUAL-PARTIAL-VERDICT.json').read_bytes())
 assert d['result'].startswith('PASS') and d['cleanup_complete'] and d['remaining_owned_children']==0
 assert d['HEAD']==plan['HEAD']
rows=[r for r in plan['groups'] if r['stage']!='1'and not(r['viewport']=='mobile'and r['stage']=='2-3')];assert len(rows)==25;completed=[]
S=O/'REMAINING-NATIVE-PUBLISHED-GROUPS-ACTUAL-STATE.json'
def save(status,**kw):
 data=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),HEAD=plan['HEAD'],status=status,completed=completed,remaining_groups=len(rows)-len(completed),whole_gate='PENDING unless every required group actually passes and binds',**kw)
 S.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data),flush=True)
try:
 for row in rows:
  v=row['viewport'];stage=row['stage'];out=Path('/tmp')/f'WAGON-OWNBOUND-PUBLISHED-{v.upper()}-STAGE{stage}-01';prefix=L/f'rail-owned-wagon-bound-published-{v}-{stage}-01'
  assert not out.exists() and not Path(str(prefix)+'.log').exists(),f'Existing actual group must be reviewed, never overwritten: {out}'
  save('PREPARING next native group',active=row,prefix=str(prefix),output=str(out))
  out.mkdir();(out/'PNGS').mkdir()
  with (out/'STANDING-RECORD.log').open('wb')as f:subprocess.run(['node','tools/dev-smoke-state.mjs','ask','--viewport',v,'--stage',stage],cwd=A,stdout=f,stderr=subprocess.STDOUT,check=True)
  with(out/'BINDING-BEFORE.log').open('wb')as f:subprocess.run([sys.executable,str(BIND),'before',str(out)],cwd=A,stdout=f,stderr=subprocess.STDOUT,check=True)
  maxmem=int(Path('/sys/fs/cgroup/memory.max').read_text());mem=int(Path('/sys/fs/cgroup/memory.current').read_text())
  resource=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),memory_free_bytes=maxmem-mem,workspace_free_bytes=shutil.disk_usage('/workspace').free,tmp_free_bytes=shutil.disk_usage('/tmp').free)
  (out/'ACTUAL-LAUNCH-RESOURCES.json').write_text(json.dumps(resource,indent=2)+'\n')
  assert resource['memory_free_bytes']>=4*1024**3 and resource['workspace_free_bytes']>=512*1024**2 and resource['tmp_free_bytes']>=1024**3,'Resource launch reserve failed; no browser launched'
  assert not Path('/workspace/.cloud-setup/transport-browser-resource-pause.json').exists(),'Root browser pause active; no browser launched'
  tmp=Path('/tmp')/f'wg-bound-{v[0]}{stage.replace("-", "_")}';tmp.mkdir(mode=0o700,exist_ok=False)
  env={**os.environ,'TMPDIR':str(tmp),'SMOKE_VIEWPORT':v,'SMOKE_STAGE':stage,'SMOKE_TIMING':'1','SMOKE_SHOTS':str(out/'PNGS')}
  save('RUNNING actual native group',active=row,prefix=str(prefix),output=str(out))
  rc=subprocess.run([sys.executable,SUP,'--prefix',str(prefix),'--cwd',str(A),'--timeout','600','--','node','tools/smoke_renderer.mjs','--published'],cwd=A,env=env).returncode
  result=json.loads(Path(str(prefix)+'.result.json').read_bytes());cleanup=json.loads(Path(str(prefix)+'.cleanup.json').read_bytes())
  with(out/'BINDING-AFTER.log').open('wb')as f:subprocess.run([sys.executable,str(BIND),'after',str(out)],cwd=A,stdout=f,stderr=subprocess.STDOUT,check=True)
  transcript=Path(str(prefix)+'.log').read_text(errors='replace');summary=re.search(r'(\d+) passed, (\d+) failed',transcript)
  passed=rc==0 and result['returncode']==0 and not result['timed_out'] and cleanup['cleanup_complete'] and not cleanup['remaining_owned_children']and 'SMOKE PASS'in transcript and summary is not None and int(summary[2])==0
  verdict=dict(HEAD=plan['HEAD'],TREE=plan['TREE'],APP=plan['APP'],passed_checks=int(summary[1])if summary else None,failed_checks=int(summary[2])if summary else None,result='PASS native partial group only'if passed else'NONPASS actual native partial group',viewport=v,stage=stage,seconds=result['seconds'],timed_out=result['timed_out'],cleanup_complete=cleanup['cleanup_complete'],remaining_owned_children=len(cleanup['remaining_owned_children']),source_index_fullmirror_unchanged=True,whole_published_gate='PENDING until all required groups pass')
  (out/'ACTUAL-PARTIAL-VERDICT.json').write_text(json.dumps(verdict,indent=2)+'\n');completed.append(verdict)
  if not passed:save('STOPPED at first actual NONPASS',active=row,prefix=str(prefix));raise SystemExit(1)
  save('CLOSED PASS partial group; preparing next',last=row)
 save('ALL planned native groups closed PASS; root review and fresh CI/merge still required',whole_gate_candidates='25remaining native groups plus freshly closed first mobile/desktop and exact209targeted phone2-3 bridged source/mirror; root must audit complete coverage, no CI/merge claim')
except BaseException as err:
 if not isinstance(err,SystemExit):save('STOPPED exception/resource/source issue; inspect actuals before resuming',error=repr(err))
 raise
