import hashlib,json,re
from pathlib import Path
O=Path(__file__).resolve().parent;L=O.parent.parent
r=json.loads((O/'ACTUAL-NORMAL-CHECKED-FOLLOWUP-PUSH.json').read_bytes());plan=json.loads((O/'ACTUAL-NEWHEAD-NATIVE-SMOKE-PLAN-SUMMARY.json').read_bytes());assert r['HEAD']==plan['HEAD'];state=json.loads((O/'REMAINING-NATIVE-PUBLISHED-GROUPS-ACTUAL-STATE.json').read_bytes());assert state['HEAD']==r['HEAD']and len(state['completed'])==25 and state['remaining_groups']==0 and state['status'].startswith('ALL planned native groups closed PASS')
bridge=json.loads((O/'TARGETED-TO-COMMITTED-PUBLISH-COVERAGE-BRIDGE.json').read_bytes());assert bridge['committed_HEAD']==r['HEAD']and bridge['result'].startswith('PASS')
rows=[];mir=None;parts={'mobile':[],'desktop':[]}
for g in plan['groups']:
 v=g['viewport'];stage=g['stage'];target=v=='mobile'and stage=='2-3'
 if target:out=Path('/tmp/WAGON-OWNBOUND-TARGETED-PUBLISHED-MOBILE2-3-01');prefix=L/'rail-owned-wagon-bound-targeted-mobile-2-3-01'
 elif stage=='1':out=Path('/tmp')/f'WAGON-OWNBOUND-PUBLISHED-{v.upper()}-STAGE1-01';prefix=L/f'rail-owned-wagon-bound-newHEAD-published-{v}-1-01'
 else:out=Path('/tmp')/f'WAGON-OWNBOUND-PUBLISHED-{v.upper()}-STAGE{stage}-01';prefix=L/f'rail-owned-wagon-bound-published-{v}-{stage}-01'
 actual=json.loads(Path(str(prefix)+'.result.json').read_bytes());cleanup=json.loads(Path(str(prefix)+'.cleanup.json').read_bytes());verdict=json.loads((out/'ACTUAL-PARTIAL-VERDICT.json').read_bytes());before=json.loads((out/'SOURCE-AND-MIRROR-BEFORE.json').read_bytes());after=json.loads((out/'SOURCE-AND-MIRROR-AFTER.json').read_bytes());assert before==after
 assert actual['returncode']==0 and not actual['timed_out']and actual['requested_timeout_seconds']==600 and cleanup['cleanup_complete']and not cleanup['remaining_owned_children']and verdict['result'].startswith('PASS')
 assert(verdict['TREE'],verdict['APP'])==(r['TREE'],r['APP']);assert verdict['HEAD']==(r['parent']if target else r['HEAD'])
 if not target:
  if mir is None:mir=before
  else:assert before==mir,'Cross-group committed source/index/fullmirror drift'
 else:assert before['index_sha256']==mir['index_sha256']and before['source_paths']==mir['source_paths']
 text=Path(str(prefix)+'.log').read_text(errors='replace');summary=re.search(r'(\d+) passed, (\d+) failed',text);assert summary and int(summary[2])==0 and 'SMOKE PASS'in text
 bound=list(map(int,stage.split('-')));covered=list(range(bound[0],bound[-1]+1));parts[v]+=covered
 rows.append(dict(viewport=v,stage=stage,parts=covered,original_run_HEAD=verdict['HEAD'],TREE=verdict['TREE'],APP=verdict['APP'],seconds=actual['seconds'],passed_checks=int(summary[1]),failed_checks=0,cleanup_complete=True,remaining_owned_children=0,source_index_fullmirror_unchanged=True,explicit_committed_publish_bridge=target,log=str(prefix)+'.log',log_sha256=hashlib.sha256(Path(str(prefix)+'.log').read_bytes()).hexdigest(),verdict=str(out/'ACTUAL-PARTIAL-VERDICT.json')))
assert len(rows)==28
for v in parts:assert parts[v]==list(range(1,16)),(v,parts[v])
x=dict(result='PASS actual native published coverage all15parts bothprofiles; independent root audit and ordinary CI/merge still required',HEAD=r['HEAD'],TREE=r['TREE'],APP=r['APP'],BASE=plan['pinned_base'],groups=rows,parts=parts,actual_summed_command_seconds=sum(g['seconds']for g in rows),scope='All28 native groups with exact source/index/fullmirror closure; one209phone2-3 originalrunHEAD retained through explicit exhaustively verified generatedpublication bridge. No Manager/CI/ready/DEVmerge claim.')
(O/'ACTUAL-COMPLETE-NATIVE-PUBLISHED-COVERAGE.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(dict(result=x['result'],groups=len(rows),parts=parts,actual_seconds=x['actual_summed_command_seconds'])),flush=True)
