# Reviewed-source next phase commands — prepared, not launched

Frozen110source TREEbc697721852b6a3fb2e2dc5850dcebf693ad0089 / APP4367c7e1d1a19226d28ea34e3da218e823336db5 / fullindex8544dc56091fecdf4dea2b3497f418f10c43a75fb5eb81d6e2e64f4617cfd747. Independent installed-source/protocol review CLEAR. Actual canonical23source controls CLOSEDPASS7.788036s, no timeout/cleanuptrue/0remaining. All static/native/posed phases below remain UNRUN until root grants a fresh slot after W desktop cleanup.

Root reads each actual result+cleanup and full final verdict before starting the next phase. Each block is a separate fresh shell/tool call; the static CPU ulimit must not carry into native/posed. Do not rerun an unchanged failed phase or extend its original bound. If any output/prefix already exists, preserve it and choose a new reviewed name rather than overwrite.

## Static: proposed bounded60s wall/30CPU, one thread, no browser

The new canonical static phase repeats all23source controls and calls unchanged original static socket functions. Fresh actual RAM>=2GiB, /tmp>=768MiB/workspace>=512MiB, all110source/index/mirror exact and no actual Chrome are checked. Root must explicitly grant this slot; preparation does not launch it.

```bash
set -e
source /workspace/.cloud-setup/transport-activate.sh
python /workspace/.cloud-setup/logs/transport-recovery/HORSE-QUIET-HEAD-NECK-IDLE-V6-PROPOSAL-20261029/check-next-slot-resources.py --phase static --closed-prefix /workspace/.cloud-setup/logs/transport-recovery/horse-quiet-head-neck-v6-canonical-source-controls-01 --out /tmp/horse-v6-canonical-static-launch-resources-20261030-01.json
ulimit -t 30
python /workspace/.cloud-setup/transport-supervise.py --prefix /workspace/.cloud-setup/logs/transport-recovery/horse-quiet-head-neck-v6-canonical-static-01 --cwd /tmp/chicago-horse-20261029/chicago/4d --timeout 60 -- python /tmp/chicago-horse-20261029/chicago/4d/tools/transport/horse_quiet_head_neck_idle_v6/qualify_quiet_head_neck.py --phase static --out /tmp/horse-quiet-head-neck-v6-canonical-static-20261030-01.json
```

## Native: original600s wall, actual master/runtime/pair Mixer129

This is a separate heavy/browser slot, not automatically authorized by a static PASS. The exact native command admits the actual closed static supervisor result+cleanup/command/cwd/output/timeout and exact current static source/code receipt before browser launch. Its CLI includes the actual static supervisor prefix. Fresh short owned TMPDIR is mandatory; realRAM/disk/no-other-Chrome/current110source guards repeat inside the actual driver.

```bash
set -e
source /workspace/.cloud-setup/transport-activate.sh
python /workspace/.cloud-setup/logs/transport-recovery/HORSE-QUIET-HEAD-NECK-IDLE-V6-PROPOSAL-20261029/check-next-slot-resources.py --phase native --closed-prefix /workspace/.cloud-setup/logs/transport-recovery/horse-quiet-head-neck-v6-canonical-static-01 --out /tmp/horse-v6-canonical-native-launch-resources-20261030-01.json
horse_v6_native_tmp=$(mktemp -d /tmp/hq6n-XXXXXX)
export TMPDIR="$horse_v6_native_tmp"
python /workspace/.cloud-setup/transport-supervise.py --prefix /workspace/.cloud-setup/logs/transport-recovery/horse-quiet-head-neck-v6-canonical-native129-01 --cwd /tmp/chicago-horse-20261029/chicago/4d --timeout 600 -- node /tmp/chicago-horse-20261029/chicago/4d/tools/transport/horse_quiet_head_neck_idle_v6/run_quiet_head_neck129.cjs /tmp/horse-quiet-head-neck-v6-canonical-static-20261030-01.json /workspace/.cloud-setup/logs/transport-recovery/horse-quiet-head-neck-v6-canonical-static-01 /tmp/horse-quiet-head-neck-v6-canonical-native129-20261030-01
```

Expected actual stages: original13fullvertex/native-shader-normal parity+physical129; masterquiet15physical129; separately imported onequiet runtimephysical129; runtime/master allvertex/shadernormal/bone parity129; independent literal reference and tailold13/headsource17 checks129 with actual nonzero motion; then independent paired925 nativeMixer on the actual runtime clip and all516Float64 arrays/59,214,096B. Passive WebGLrequests/contexts must0. No body/pose/time/capture overrides. Any failure means no subsequent posed/adoption claim.

The actual driver writes exact CAPTURE-FRAMES.json bytes and binds their SHA/length into RESULT, then manifest. The qualifier later checks typed frame equality and unique canonical per-frame/role RAW paths/hash/shape/length/containment/nosymlinks. No outside prototype8575 or earlier failedV3 result is retargeted.

## Posed: original600s wall, original14mm/7mm/crossing rules

This requires another root-coordinated CPU slot after actual native PASS/cleanup0. It reads the actual closed native manifest/result/static supervisor chain and all129 real arrays, runs five actual postcapture replay/state/path mutation controls without changing captured files, calls the unchanged original socket traversal and rechecks the complete immutable capture inventory afterward.

```bash
set -e
source /workspace/.cloud-setup/transport-activate.sh
python /workspace/.cloud-setup/logs/transport-recovery/HORSE-QUIET-HEAD-NECK-IDLE-V6-PROPOSAL-20261029/check-next-slot-resources.py --phase posed --closed-prefix /workspace/.cloud-setup/logs/transport-recovery/horse-quiet-head-neck-v6-canonical-native129-01 --out /tmp/horse-v6-canonical-posed-launch-resources-20261030-01.json
python /workspace/.cloud-setup/transport-supervise.py --prefix /workspace/.cloud-setup/logs/transport-recovery/horse-quiet-head-neck-v6-canonical-posed129-01 --cwd /tmp/chicago-horse-20261029/chicago/4d --timeout 600 -- python /tmp/chicago-horse-20261029/chicago/4d/tools/transport/horse_quiet_head_neck_idle_v6/qualify_quiet_head_neck.py --phase posed --out /tmp/horse-quiet-head-neck-v6-canonical-posed129-20261030-01.json --poses /tmp/horse-quiet-head-neck-v6-canonical-native129-20261030-01/POSE-MANIFEST.json --supervisor-prefix /workspace/.cloud-setup/logs/transport-recovery/horse-quiet-head-neck-v6-canonical-native129-01
```

Only after actual source/static/native/posed closure may the generic recorded reader build a new finite certificate outside app. It requires exact four phase commands/current code/actual receipts and keeps world/photo/app/gait/adoption unaccepted. Later reviewed certificate copy/runtime selection/helper/registry changes get an explicit NEW source bridge/freeze; original PhaseA receipts retain their exact tested tree. A real world window later derives maximumdelay +12/minimumrate +margin and must be at least16s;16s is not automatically sufficient.
