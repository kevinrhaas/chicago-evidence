import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
R=Path('/tmp/chicago-wagon-20261029');A=R/'chicago/4d';O=Path(__file__).resolve().parent;L=O.parent.parent;F=O/'COMPLETE-NATIVE-PREFLIGHT-01';BASE='ec16b8dd726fa7852ede885ef2d754d55b9b4c59'
git=lambda *x:subprocess.check_output(['git',*x],cwd=R,env={**os.environ,'GIT_NO_LAZY_FETCH':'1'})
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def closed(name):
 d=json.loads((L/(name+'.result.json')).read_bytes());c=json.loads((L/(name+'.cleanup.json')).read_bytes());assert d['returncode']==0 and not d['timed_out'] and c['cleanup_complete']and not c['remaining_owned_children'];return d
closed('rail-owned-wagon-bound-targeted-mobile-2-3-01');closed('rail-exact-owner-paired-CPU-all81-03')
b=json.loads((O/'SEALED-CANDIDATE.json').read_bytes());T=Path('/tmp/WAGON-OWNBOUND-TARGETED-PUBLISHED-MOBILE2-3-01');v=json.loads((T/'ACTUAL-PARTIAL-VERDICT.json').read_bytes());assert v['result'].startswith('PASS')and(v['TREE'],v['APP'])==(b['TREE'],b['APP']);assert json.loads((T/'SOURCE-AND-MIRROR-BEFORE.json').read_bytes())==json.loads((T/'SOURCE-AND-MIRROR-AFTER.json').read_bytes())
binding=json.loads((T/'SOURCE-AND-MIRROR-AFTER.json').read_bytes());assert git('rev-parse','HEAD').decode().strip()==b['HEAD'];assert git('write-tree').decode().strip()==b['TREE'];index=git('ls-files','--stage','-z');assert index==(O/'SEALED-COMPLETE-INDEX.z').read_bytes();assert not git('diff','--name-only').strip()
for row in binding['source_paths']:
 p=R/row['path'];assert(not p.exists())if row.get('deleted')else(p.is_file()and sha(p)==row['sha256']),row['path']
scratch=Path(os.environ.get('TMPDIR','/tmp'));demand=sum(((p.stat().st_size+4095)//4096)*4096 for root in[A/'data',A/'docs/RESEARCH']for p in root.rglob('*')if p.is_file());disk=dict(TMPDIR=str(scratch),native_synthesis_copy_bytes=demand,reserve_bytes=512*1048576,free_bytes=shutil.disk_usage(scratch).free);assert disk['free_bytes']>=demand+disk['reserve_bytes']
F.mkdir(exist_ok=False);(F/'SOURCE-BINDING.json').write_text(json.dumps(dict(HEAD=b['HEAD'],TREE=b['TREE'],APP=b['APP'],BASE=BASE,source_paths=binding['source_paths'],source_transition=str(O/'SEALED-CANDIDATE.json'),targeted_actual=str(T/'ACTUAL-PARTIAL-VERDICT.json'),paired_actual=str(O.parent/'EXACT-OWNERSHIP-REPAIR-20261029/ACTUAL-PAIRED-ALL81-GEOMETRY-AND-PICKSPANS.json'),scope='Exact staged smoke-only original wagon bound restoration; runtime source unchanged from dce675 and prior paired proof, preflight HEAD-only questions see dce675 until actual postcommit checks',disk=disk),indent=2)+'\n');(F/'COMPLETE-INDEX.z').write_bytes(index)
prev=F/'PREVIOUS-CLOSED-SHARED-LOGS';prev.mkdir()
for kind in['check','cl','ids']:
 p=Path('/tmp/preflight-'+kind+'.log')
 if p.exists():shutil.copy2(p,prev/p.name)
print(json.dumps(dict(stage='ACTUAL COMPLETE PREFLIGHT START',HEAD=b['HEAD'],TREE=b['TREE'],APP=b['APP'],disk=disk)),flush=True);start=time.monotonic();rc=1
try:rc=subprocess.run(['bash','tools/preflight.sh'],cwd=A,env={**os.environ,'BASE':BASE,'C4D_GATE_REQUIRE_READERS':'1','C4D_GATE_REQUIRE_BASE':'1','CHECK_JOBS':'4'}).returncode
finally:
 for kind in['check','cl','ids']:
  p=Path('/tmp/preflight-'+kind+'.log')
  if p.exists():shutil.copy2(p,F/('ACTUAL-INNER-'+kind+'.log'))
 result=dict(returncode=rc,seconds=time.monotonic()-start,HEAD=b['HEAD'],TREE=b['TREE'],APP=b['APP'],BASE=BASE,scope='Full native check.sh/preflight on exact staged candidate; actual newHEAD questions pending commit')
 (F/'ACTUAL-CLOSURE.json').write_text(json.dumps(result,indent=2)+'\n')
assert rc==0,'Full required native preflight NONPASS; no commit/push'
assert git('rev-parse','HEAD').decode().strip()==b['HEAD']and git('write-tree').decode().strip()==b['TREE']and git('ls-files','--stage','-z')==index
assert not git('diff','--name-only').strip()and not git('ls-files','--others','--exclude-standard').strip()
for row in binding['source_paths']:
 p=R/row['path'];assert(not p.exists())if row.get('deleted')else(p.is_file()and sha(p)==row['sha256']),row['path']
result.update(result='PASS exact staged candidate full native preflight; outer cleanup and actual newHEAD checks still required',source_index_unchanged=True,target600_met=result['seconds']<=600,commit_push='UNRUN');(F/'ACTUAL-CLOSURE.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
