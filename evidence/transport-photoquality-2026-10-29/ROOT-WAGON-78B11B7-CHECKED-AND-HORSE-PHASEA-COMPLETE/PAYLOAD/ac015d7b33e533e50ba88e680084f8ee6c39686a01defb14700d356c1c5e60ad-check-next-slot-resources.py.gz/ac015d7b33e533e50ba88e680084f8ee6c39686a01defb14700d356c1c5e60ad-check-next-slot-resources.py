"""Read-only fresh launch guard. Does not launch a qualification phase."""
from pathlib import Path
import argparse,datetime,json,os,shutil,subprocess
P=Path(__file__).resolve().parent;A=Path('/tmp/chicago-horse-20261029/chicago/4d');G=A/'tools/transport/horse_quiet_head_neck_idle_v6/canonical_guard.py'
p=argparse.ArgumentParser();p.add_argument('--phase',choices=['static','native','posed'],required=True);p.add_argument('--closed-prefix',required=True,type=Path);p.add_argument('--out',required=True,type=Path);a=p.parse_args();assert not a.out.exists()
frozen=json.loads((P/'PHASEA-INSTALLED-SOURCE-FREEZE-01.json').read_bytes())['source_binding'];current=json.loads(subprocess.check_output(['python',str(G)],cwd=A));assert current==frozen,'All110 canonical sources/index/code/mirror must remain exactly frozen'
run=json.loads(Path(str(a.closed_prefix)+'.result.json').read_bytes());cleanup=json.loads(Path(str(a.closed_prefix)+'.cleanup.json').read_bytes());assert run['returncode']==0 and not run['timed_out'] and cleanup['cleanup_complete'] and cleanup['remaining_owned_children']==[],'Prior actual required phase must close PASS/cleanup0'
limit_raw=Path('/sys/fs/cgroup/memory.max').read_text().strip();used=int(Path('/sys/fs/cgroup/memory.current').read_text());free=None if limit_raw=='max' else int(limit_raw)-used;assert free is None or free>2*1024**3,'At least2GiB actual cgroup RAM reserve'
workspace=shutil.disk_usage('/workspace').free;scratch=shutil.disk_usage('/tmp').free;assert workspace>512*1024**2 and scratch>768*1024**2,'512MiB workspace/768MiB scratch reserves'
browsers=[]
for d in Path('/proc').iterdir():
 if d.name.isdigit():
  try:
   if Path(os.readlink(d/'exe')).name in {'chrome','chromium','headless_shell','chrome-headless-shell'}:browsers.append(int(d.name))
  except (FileNotFoundError,PermissionError,ProcessLookupError):pass
assert not browsers,'No competing actual browser; root owns heavy-slot coordination'
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:assert os.environ.get(k)=='1','Single numerical thread '+k
record=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase=a.phase,source_files=110,TREE=current['TREE'],APP=current['APP'],semantic_index_sha256=current['semantic_index_sha256'],prior_closed_prefix=str(a.closed_prefix),prior_actual_PASS_cleanup_zero=True,RAM_free_bytes=free,workspace_free_bytes=workspace,tmp_free_bytes=scratch,existing_browser_pids=browsers,qualification_started=False,root_GO_still_required=True)
a.out.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
