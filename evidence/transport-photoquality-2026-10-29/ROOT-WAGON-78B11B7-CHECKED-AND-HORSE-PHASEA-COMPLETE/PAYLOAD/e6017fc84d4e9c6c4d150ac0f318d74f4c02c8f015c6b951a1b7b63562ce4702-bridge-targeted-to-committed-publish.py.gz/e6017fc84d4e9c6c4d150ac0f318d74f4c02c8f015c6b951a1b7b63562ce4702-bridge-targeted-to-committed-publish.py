import datetime,hashlib,json,subprocess
from pathlib import Path
O=Path(__file__).resolve().parent;R=Path('/tmp/chicago-wagon-20261029');M=R/'site/4d';T=Path('/tmp/WAGON-OWNBOUND-TARGETED-PUBLISHED-MOBILE2-3-01');RAW=Path('/tmp/WAGON-OWNBOUND-BEFORE-COMMITTED-MIRROR-RAW')
sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((O/'ACTUAL-NORMAL-CHECKED-FOLLOWUP-PUSH.json').read_bytes());s=json.loads((O/'SEALED-CANDIDATE.json').read_bytes());v=json.loads((T/'ACTUAL-PARTIAL-VERDICT.json').read_bytes());b=json.loads((T/'SOURCE-AND-MIRROR-BEFORE.json').read_bytes());assert b==json.loads((T/'SOURCE-AND-MIRROR-AFTER.json').read_bytes());assert v['result'].startswith('PASS')and v['cleanup_complete']and v['remaining_owned_children']==0
assert (v['HEAD'],v['TREE'],v['APP'])==(s['HEAD'],r['TREE'],r['APP'])and r['parent']==s['HEAD']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==r['HEAD']and not subprocess.check_output(['git','status','--porcelain'],cwd=R).strip()
index=subprocess.check_output(['git','ls-files','--stage','-z'],cwd=R);assert sha(index)==b['index_sha256']
for row in b['source_paths']:
 p=R/row['path'];assert(not p.exists())if row.get('deleted')else(p.is_file()and sha(p.read_bytes())==row['sha256']),row['path']
old={row['path']:row for row in b['mirror_paths']};new={str(p.relative_to(M)):dict(path=str(p.relative_to(M)),bytes=p.stat().st_size,sha256=sha(p.read_bytes()))for p in M.rglob('*')if p.is_file()};assert old.keys()==new.keys()
changed=[k for k in sorted(old)if old[k]!=new[k]]
allowed=set(row['path']for row in json.loads((RAW/'VERIFIED-RAW-CAPTURE.json').read_bytes())['files']);assert set(changed)<=allowed,changed
for k in allowed:assert sha((RAW/k).read_bytes())==old[k]['sha256'],k
oldstamp=json.loads((RAW/'build.json').read_bytes());stamp=json.loads((M/'build.json').read_bytes());assert stamp['version']==r['HEAD'][:9]and oldstamp['version']==s['HEAD'][:9];assert stamp.keys()==oldstamp.keys()=={'version','built_utc','built_ct'}
reasons={}
for k in changed:
 if k.endswith('/index.html'):
  x=(M/k).read_bytes().replace(stamp['version'].encode(),oldstamp['version'].encode()).replace(stamp['built_ct'].encode(),oldstamp['built_ct'].encode());assert x==(RAW/k).read_bytes(),k;reasons[k]='Only actual canonical build version and Central-Time stamp changed; reverse substitution reproduces exact original bytes/SHA.'
 elif k.startswith('data/prebuilt/'):
  x=(M/k).read_bytes().replace(stamp['version'].encode(),oldstamp['version'].encode());assert x==(RAW/k).read_bytes(),k;reasons[k]='Only canonical build tag changed; reverse substitution reproduces exact original bytes/SHA, bins and every other field unchanged.'
 elif k=='build.json':reasons[k]='Exactly version, built_utc and built_ct canonical build stamp fields; keys unchanged.'
summary={}
for y in ['1812','1835','1904']:
 k=f'packs/{y}.json';a=json.loads((RAW/k).read_bytes());z=json.loads((M/k).read_bytes());assert [x[0]for x in a['files']]==[x[0]for x in z['files']]
 for row in z['files']:assert row==[row[0],new[row[0]]['sha256'][:16],new[row[0]]['bytes']],row[0]
 expected=dict(a);expected['files']=[[row[0],new[row[0]]['sha256'][:16],new[row[0]]['bytes']]for row in a['files']];expected['id']=sha('\n'.join(' '.join(map(str,row))for row in expected['files']).encode())[:16];expected['bytes']=sum(row[2]for row in expected['files']);assert z==expected;assert (json.dumps(expected,separators=(',',':'),ensure_ascii=False)+'\n').encode()==(M/k).read_bytes()
 summary[y]={key:z[key]for key in ['id','count','bytes']}
 if k in changed:reasons[k]='Same complete file membership; every hash/size equals actual full new mirror, all fields/ID/bytes independently regenerated from exact original pack.'
assert json.loads((M/'packs/index.json').read_bytes())==summary
if 'packs/index.json'in changed:reasons['packs/index.json']='Exactly the three independently verified deterministic year-pack summaries.'
def differences(a,z,path=''):
 if type(a)!=type(z):return[dict(path=path,before=a,after=z)]
 if isinstance(a,dict):
  result=[]
  for key in sorted(a.keys()|z.keys()):
   if key not in a or key not in z:result.append(dict(path=path+'/'+key,before=a.get(key),after=z.get(key)))
   else:result+=differences(a[key],z[key],path+'/'+key)
  return result
 if isinstance(a,list):
  if len(a)!=len(z):return[dict(path=path,before=a,after=z)]
  return[item for i,(x,y)in enumerate(zip(a,z))for item in differences(x,y,path+'/'+str(i))]
 return[]if a==z else[dict(path=path,before=a,after=z)]
board=[]
if 'tickets.json'in changed:
 a=json.loads((RAW/'tickets.json').read_bytes());z=json.loads((M/'tickets.json').read_bytes());assert a['project']==z['project']=='chicago-4d';board=differences(a,z);reasons['tickets.json']='Separately regenerated central ticket board; every changed JSON field recorded. This bridge claims world/structure phone2-3 coverage, never Manager/board acceptance; tickets.json is excluded from every year pack.'
 for y in summary:assert not any(row[0]=='tickets.json'for row in json.loads((M/f'packs/{y}.json').read_bytes())['files'])
assert set(reasons)==set(changed),(set(changed)-set(reasons))
out=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),result='PASS exact committed source and exhaustively explained generated-publish bridge; independent review required before coverage reuse',original_run_HEAD=v['HEAD'],committed_HEAD=r['HEAD'],TREE=r['TREE'],APP=r['APP'],original_actual=str(T/'ACTUAL-PARTIAL-VERDICT.json'),original_run_seconds=v['seconds'],original_receipt_unchanged=True,source_index_identical=True,old_mirror_files=len(old),new_mirror_files=len(new),byteidentical_files=len(old)-len(changed),changes=[dict(path=k,before=old[k],after=new[k],explanation=reasons[k])for k in changed],ticket_board_field_differences=board,scope='Only exact-source actual published phone parts2-3; original dce675 run identity retained. Fresh committed stage1 phone/desktop and all remaining groups still required; no whole gate/CI/merge claim.')
(O/'TARGETED-TO-COMMITTED-PUBLISH-COVERAGE-BRIDGE.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(result=out['result'],changed_files=len(changed),byteidentical_files=out['byteidentical_files'],board_field_differences=len(board))),flush=True)
