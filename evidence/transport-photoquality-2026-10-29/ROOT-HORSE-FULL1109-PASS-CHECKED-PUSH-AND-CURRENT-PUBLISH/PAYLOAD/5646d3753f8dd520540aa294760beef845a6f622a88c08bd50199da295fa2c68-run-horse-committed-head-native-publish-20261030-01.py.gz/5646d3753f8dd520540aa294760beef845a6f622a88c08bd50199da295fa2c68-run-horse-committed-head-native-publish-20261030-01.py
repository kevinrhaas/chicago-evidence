from pathlib import Path
import sys,os,json,hashlib,importlib.util,subprocess,datetime,time,re
sys.dont_write_bytecode=True
R=Path('/tmp/chicago-horse-20261029');A=R/'chicago/4d';D=Path('/tmp/HORSE-ACTUAL-COMMITTED-HEAD-NATIVE-PUBLISH-20261030-01')
HEAD='2177b51b1f6d0c4aedfbc5374f4f1e2ce1fa7d1b';G=Path('/tmp/HORSE-ACTUAL-FULL-GATE-SHM-20261030-03');EXE=Path('/tmp/HORSE-CHECKED-FEATURE-PUSH-SOURCEUSE-PREP-20261030/run-checked-feature-commit-push.py');sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(EXE.read_bytes())=='52db34ff406d7caa3a736d383a29c0aaf78fc22d330817e4acfac1ae93d930c3'
spec=importlib.util.spec_from_file_location('horse_committed_source_guard',EXE);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
ps=importlib.util.spec_from_file_location('horse_current_publish_resources',m.POLICY);policy=importlib.util.module_from_spec(ps);ps.loader.exec_module(policy);assert m.pin(m.POLICY)['sha256']==m.POLICY_SHA
full=Path('/tmp/HORSE-FULL-GATE-RETRY03-PREP-20261030/run-guarded-whole-gate.py');assert m.pin(full)['sha256']=='b33933ac9b84d4e11192b6b36dc96550d496711e99a9c415f3bc417d50fbc6ba';ws=importlib.util.spec_from_file_location('horse_publish_owner_guard',full);w=importlib.util.module_from_spec(ws);ws.loader.exec_module(w)
assert not D.exists();D.mkdir(mode=0o700);started=time.monotonic();before=None;index=None;rb=None;errors=[];native_pass=False;after=None;mirror=None;pair=None
state=dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='ACTUAL_CURRENT_COMMITTED_HEAD_NATIVE_PUBLICATION_PENDING',HEAD=HEAD,TREE=m.TREE,APP=m.APP,source_count=117,original_full_gate_head=m.OLD,original_full_gate_retargeted=False,source_tree_unchanged_bridge=True,commands=[],published_current_HEAD=False,ordinary_CI='UNKNOWN_NOT_QUERIED',DEV_merge=False,H6_full12_world='NONPASS_5.636_NATIVE_SECONDS_PARTIAL_NEAR_ONLY',broad_photo_gait_rider_driver_traffic='OPEN',codepins=dict(executor=m.pin(EXE),full_helper=m.pin(full),publisher=m.pin(A/'tools/publish.sh'),native_check=m.pin(A/'tools/check_published.mjs'),resource10=m.pin(m.POLICY)))
def save(name,j):(D/name).write_text(json.dumps(j,indent=2)+'\n')
def close():save('ACTUAL-COMMITTED-HEAD-PUBLISH-CLOSED.json',state)
close()
try:
 index=(G/'COMPLETE-INDEX-BEFORE.z').read_bytes();before=m.current_source(HEAD,index);save('SOURCE-BEFORE.json',before);(D/'COMPLETE-INDEX-BEFORE.z').write_bytes(index);oldmirror=json.loads((G/'MIRROR-AFTER.json').read_bytes());state['mirror_before']=m.current_mirror(oldmirror);save('MIRROR-BEFORE.json',oldmirror)
 owners=w.active_owners();assert owners==[],owners;rb=policy.snapshot();assessment=policy.check_snapshot(rb);save('RESOURCES-BEFORE.json',dict(snapshot=rb,assessment=assessment,active_owners=owners));assert assessment['accepted'];state['source_before']=before;close()
 env={**m.E,'PYTHONDONTWRITEBYTECODE':'1'}
 for label,timeout,args in [('native-publish',300,['bash','tools/publish.sh']),('native-check-published',30,['node','tools/check_published.mjs'])]:
  prefix=D/label;argv=[sys.executable,'/workspace/.cloud-setup/transport-supervise.py','--prefix',str(prefix),'--cwd',str(A),'--timeout',str(timeout),'--',*args];launcher=subprocess.run(argv,cwd=A,env=env);result=json.loads(Path(str(prefix)+'.result.json').read_bytes());cleanup=json.loads(Path(str(prefix)+'.cleanup.json').read_bytes());state['commands'].append(dict(label=label,argv=argv,launcher_returncode=launcher.returncode,native_result=result,native_cleanup=cleanup));close();assert launcher.returncode==result['returncode']==0 and not result['timed_out'] and result['requested_timeout_seconds']==result['effective_timeout_seconds']==timeout and result['timeout_override_reason']is None and result['command']==args and result['cwd']==str(A) and cleanup['cleanup_complete']and cleanup['remaining_owned_children']==[]
 native_pass=True
except BaseException as error:errors.append('NATIVE_OR_ADMISSION: '+repr(error))
finally:
 if before is not None:
  try:
   after=m.current_source(HEAD,index);assert before==after;save('SOURCE-AFTER.json',after);state['source_after']=after
   mirror=w.mirror_snapshot({'repo':str(R)});save('MIRROR-AFTER.json',mirror);assert mirror['files_count']==5640;state['mirror_after']=m.current_mirror(mirror)
  except BaseException as error:errors.append('SOURCE_OR_MIRROR: '+repr(error))
 if native_pass:
  try:
   build=json.loads((R/'site/4d/build.json').read_bytes());short=m.git('rev-parse','--short','HEAD');assert build['version']==short and HEAD.startswith(short) and len(short)>=7;save('ACTUAL-CURRENT-HEAD-build.json',build);stamps=[]
   for relative in ['walk/index.html','1835/index.html']:
    text=(R/'site/4d'/relative).read_text();stamp=re.search(r'build '+re.escape(short)+r'[^<]*',text);assert stamp,relative;stamps.append(dict(path=relative,actual_visible_gate_stamp=stamp.group(0)))
   state.update(actual_build_json=build,actual_native_short_HEAD=short,actual_visible_native_gate_stamps=stamps)
  except BaseException as error:errors.append('ACTUAL_NATIVE_GATE_STAMP: '+repr(error))
 if rb is not None:
  try:
   ra=policy.snapshot();pair=policy.check_pair(rb,ra);owners=w.active_owners();save('RESOURCES-AFTER.json',dict(snapshot=ra,pair_assessment=pair,active_owners=owners));assert pair['accepted']and owners==[];state['shared_resource10_pair']=pair
  except BaseException as error:errors.append('RESOURCE10: '+repr(error))
 for key,path in [('executor',EXE),('full_helper',full),('publisher',A/'tools/publish.sh'),('native_check',A/'tools/check_published.mjs'),('resource10',m.POLICY)]:
  try:assert m.pin(path)==state['codepins'][key]
  except BaseException as error:errors.append('CODE_DRIFT: '+repr(error))
passed=native_pass and not errors and after==before and mirror is not None and pair is not None and pair['accepted']
state.update(closed=datetime.datetime.now(datetime.timezone.utc).isoformat(),seconds=time.monotonic()-started,status='PASS_ACTUAL_CURRENT_COMMITTED_HEAD_NATIVE_PUBLISH_AND_CHECK_PUBLISHED_SOURCE117_INDEX_MIRROR_RESOURCE10_EXACT'if passed else'NONPASS_CURRENT_HEAD_NATIVE_PUBLICATION_OR_SOURCE_RESOURCE_CLOSURE',errors=errors,published_current_HEAD=passed,source117_and_complete_index_unchanged=(after==before and before is not None),actual_published_file_count=mirror['files_count']if mirror else None,actual_published_bytes=mirror['bytes']if mirror else None,product_source_or_index_mutated=False);close();print(json.dumps({k:v for k,v in state.items()if k not in ['shared_resource10_pair','commands','codepins']}));raise SystemExit(0 if passed else 1)
