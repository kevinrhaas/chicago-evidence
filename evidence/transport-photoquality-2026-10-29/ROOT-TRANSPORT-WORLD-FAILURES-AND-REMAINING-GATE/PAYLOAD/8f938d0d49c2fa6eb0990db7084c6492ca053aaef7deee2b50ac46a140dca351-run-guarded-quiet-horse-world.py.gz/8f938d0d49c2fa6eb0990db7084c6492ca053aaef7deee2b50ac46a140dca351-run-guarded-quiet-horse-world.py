"""Outside PhaseB proposal: final-source/published guard and owned real world observer.

Freeze/run only after actual finite certificate installation and reviewed active
quiet15 integration. Wrap run with transport-supervise at original600seconds.
No phaseA qualification receipt/source binding is rewritten by this bridge.
"""
from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial
import argparse,datetime,hashlib,json,os,shutil,subprocess,sys,tempfile,threading,time
P=Path(__file__).resolve().parent
A=Path('/tmp/chicago-horse-20261029/chicago/4d');R=A.parents[1];M=R/'site/4d';T=A/'tools/transport/horse_quiet_head_neck_idle_v6'
TOOLS=Path('/workspace/.cloud-setup/logs/transport-recovery/HUMAN-WORLD-MOTION-PREP-V3-20261029/native-tools')
E={**os.environ,'GIT_NO_LAZY_FETCH':'1'}
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R,env=E)
def pin(p):
    p=Path(p);assert p.is_file() and not p.is_symlink(),p;b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def check_pin(d):
    assert pin(d['path'])==d,d['path']
def mirror_rows():
    assert M.is_dir() and not M.is_symlink(),'Actual full published mirror required';rows=[]
    for p in sorted(M.rglob('*')):
        assert not p.is_symlink(),'Ordinary published paths only'
        if p.is_file():
            b=p.read_bytes();rows.append(dict(path=str(p.relative_to(M)),bytes=len(b),sha256=sha(b)))
    assert len(rows)>=5630,'Complete native published mirror';return rows

def semantic_index():
    rows=[]
    for item in git('ls-files','--stage','-z').split(b'\0'):
        if not item:continue
        meta,name=item.split(b'\t',1);mode,blob,stage=meta.decode().split(' ');assert stage=='0'
        rows.append(dict(path=name.decode(),mode=mode,blob=blob,stage=0))
    return rows

def tools():
    video=TOOLS/'ffmpeg-1011/ffmpeg-linux';assert video.is_symlink() and video.resolve()==Path('/usr/bin/ffmpeg'),'Reuse verified pinned supported system FFmpeg shim, no downloads'
    return [pin('/usr/bin/ffmpeg'),pin('/usr/bin/ffprobe'),pin('/usr/bin/chromium')]

def adoption_bridge(phaseA,tree,plan_path,plan_sha):
    raw=Path(plan_path).read_bytes();assert sha(raw)==plan_sha,'Explicit reviewed concrete adoption-plan SHA'
    plan=json.loads(raw);assert plan['schema']=='quiet_head_neck_phaseB_exact_adoption_v1' and plan['state']=='READY_FOR_FINAL_FREEZE' and plan['phaseA_TREE']==phaseA['TREE'] and plan['phaseA_APP']==phaseA['APP'],'Concrete reviewed PhaseA bridge only'
    changes=plan['changes'];assert len(changes)>0 and len({r['path'] for r in changes})==len(changes),'Unique explicit changed paths'
    before_index={}
    for item in git('ls-tree','-r','-z',phaseA['TREE']).split(b'\0'):
        if not item:continue
        meta,name=item.split(b'\t',1);mode,kind,blob=meta.decode().split(' ');assert kind=='blob';before_index[name.decode()]=dict(mode=mode,blob=blob)
    current={r['path']:r for r in semantic_index()};actual=set(x for x in git('diff','--name-only','--no-renames','-z',phaseA['TREE'],tree).decode().split('\0') if x)
    assert actual=={r['path'] for r in changes},'Every PhaseA-to-final changed path explicitly reviewed; no extras or missing changes'
    protected=json.loads((T/'CODE-PIN-PATHS.json').read_bytes())['paths'].values();protected={'chicago/4d/'+p for p in protected};assert not actual.intersection(protected),'All original current63 qualifying code/input pins immutable'
    for r in changes:
        relative=r['path'];assert relative.startswith('chicago/4d/') and '..' not in Path(relative).parts
        assert r['before']==before_index.get(relative),'Exact PhaseA path/mode/blob predecessor'
        p=R/relative;b=p.read_bytes();assert p.is_file() and not p.is_symlink() and relative in current
        now=dict(mode=current[relative]['mode'],blob=current[relative]['blob'],bytes=len(b),sha256=sha(b));assert now==r['after'],'Every adopted after-byte hash/mode/blob explicitly reviewed: '+relative
    for r in phaseA['source_files']:
        if r['path'] in actual:continue
        p=R/r['path'];b=p.read_bytes();assert p.is_file() and not p.is_symlink() and len(b)==r['bytes'] and sha(b)==r['sha256'] and current[r['path']]['mode']==r['mode'] and current[r['path']]['blob']==r['blob'],'Every unexcepted original110 PhaseA source exact: '+r['path']
    return dict(plan=pin(plan_path),phaseA_TREE=phaseA['TREE'],phaseA_APP=phaseA['APP'],actual_changes=changes,all_unexcepted_PhaseA_sources_and63_qualifying_pins_exact=True,original_PhaseA_receipts_rewritten=False)

def snapshot(certificate_path,certificate_sha,adoption_plan,adoption_sha):
    assert not git('diff','--name-only').strip(),'All final app changes staged before world proof';assert len(certificate_sha)==64
    sys.path.insert(0,str(T));import recorded_qualification as record
    cert=record.read_certificate(Path(certificate_path),certificate_sha)
    spec=json.loads((A/'data/transport/parked/horse-sevket-sidecar.json').read_bytes());runtime=spec['runtime_asset'];manifest=json.loads((A/'data/transport/parked/standing-horses.json').read_bytes());authored=json.loads((A/'assets/authored/transport/horse_standing/SOURCE.json').read_bytes())
    assert runtime['sha256']==record.child.CANDIDATE_SHA and runtime['bytes']==4165556 and runtime['file']==record.RUNTIME_FILE and runtime['source_qualification_mode']==record.child.MODE and runtime['qualification_sha256']==certificate_sha and runtime['animation_count']==1 and runtime['declared_idle_clip']=='sevket_reconstructed_quiet_head_neck_idle_v1'
    assert spec['idle']['enabled'] and spec['idle']['clip']==runtime['declared_idle_clip'] and authored['runtime_derivative']==runtime,'Actual active authored/sidecar identity must agree'
    assert manifest['models']['sevket_horse_standing_development_01']['file']==runtime['file'];placement=manifest['scenes']['1835'];assert len(placement)==1 and placement[0]['id']=='western_hotel_yard_standing_horse_01' and placement[0]['animation']['clip']==runtime['declared_idle_clip']
    index=semantic_index();entries={x['path']:x for x in index};tree=git('write-tree').decode().strip();assert git('rev-parse',tree+':chicago/4d').decode().strip();phaseA=cert['phaseA_source_binding'];paths={r['path'] for r in phaseA['source_files']}
    paths.update(x['path'] for x in index if x['path'].startswith('chicago/4d/renderers/web/js/') or x['path'].startswith('chicago/4d/renderers/web/css/'))
    paths.update(x for x in git('diff','--cached','--name-only','-z','HEAD').decode().split('\0') if x)
    paths.update(str(p.relative_to(R)) for p in [A/'renderers/web/index.html',A/'renderers/web/js/standing-horse-quiet-head-neck-idle.js',A/'assets/authored/transport/horse_standing/SOURCE.json',Path(certificate_path).resolve()])
    source=[]
    for relative in sorted(paths):
        p=R/relative;assert p.is_file() and not p.is_symlink() and relative in entries,relative;b=p.read_bytes();blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert blob==entries[relative]['blob'],'Actual source equals indexed blob '+relative
        source.append(dict(path=relative,mode=entries[relative]['mode'],blob=blob,bytes=len(b),sha256=sha(b)))
    bridge=adoption_bridge(phaseA,tree,adoption_plan,adoption_sha)
    published=mirror_rows();runtime_pub=next(x for x in published if x['path']=='walk/'+runtime['file']);assert runtime_pub['sha256']==runtime['sha256'] and runtime_pub['bytes']==runtime['bytes'],'Actual published selected runtime bytes'
    outside=[pin(P/name) for name in ['standing-horse-quiet-head-neck-idle.js','observer-protocol.json','observe-quiet-horse-world.cjs','run-guarded-quiet-horse-world.py','verify-world-closure.py','record-native-frames.cjs']]
    return dict(schema='quiet_head_neck_final_world_guard_v1',repo=str(R),APP=str(A),head=git('rev-parse','HEAD').decode().strip(),tree=tree,app_tree=git('rev-parse',tree+':chicago/4d').decode().strip(),semantic_index=index,source_files=source,published_root_prefix='/',published_files=published,runtime_qualification_sha256=certificate_sha,qualification_certificate=pin(certificate_path),phaseA_qualification_source_binding=phaseA,actual_current_qualifying_code_pins=cert['actual_code_pins'],explicit_phaseA_to_final_source_bridge=bridge,outside_proof_files=outside,external_tools=tools(),video_tools_directory=str(TOOLS),source_index_or_PhaseA_receipt_rewritten=False)

def resource_guard():
    raw=Path('/sys/fs/cgroup/memory.max').read_text().strip();used=int(Path('/sys/fs/cgroup/memory.current').read_text());free=None if raw=='max' else int(raw)-used;disk={p:shutil.disk_usage(p).free for p in ['/workspace','/tmp']};active=[]
    for d in Path('/proc').iterdir():
        if not d.name.isdigit():continue
        try:
            name=Path(os.readlink(d/'exe')).name
            cmd=(d/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace').split()
            if name in {'chrome','chromium','headless_shell','chrome-headless-shell'} or any(Path(t).name in {'check.sh','preflight.sh','rederive.mjs','smoke_renderer.mjs','publish.sh'} for t in cmd[:5]):active.append(dict(pid=int(d.name),executable=name,command=cmd[:5]))
        except (FileNotFoundError,PermissionError,ProcessLookupError):pass
    stat={k:int(v) for k,v in (line.split() for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines())};events={k:int(v) for k,v in (line.split() for line in Path('/sys/fs/cgroup/memory.events').read_text().splitlines())}
    clean_inactive=max(0,stat.get('inactive_file',0)-stat.get('file_dirty',0)-stat.get('file_writeback',0));available=None if free is None else max(0,free)+clean_inactive
    out=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),RAM_raw_free_bytes=free,RAM_clean_inactive_file_bytes=clean_inactive,RAM_available_bytes=available,RAM_components={k:stat.get(k,0) for k in ['inactive_file','file_dirty','file_writeback','shmem','active_file']},memory_events=events,workspace_free_bytes=disk['/workspace'],tmp_free_bytes=disk['/tmp'],active_browser_or_heavy_owners=active)
    assert all(v==0 for v in events.values()),'Nonzero cgroup pressure/OOM events require explicit review'
    assert (available is None or available>=4*1024**3) and disk['/workspace']>=512*1024**2 and disk['/tmp']>=1024**3 and not active,'Fresh single-owner world resource guard:4GiB RAM/1GiB tmp/512MiB workspace'
    return out

def check_guard(expected):
    assert expected['schema']=='quiet_head_neck_final_world_guard_v1';bridge=expected['explicit_phaseA_to_final_source_bridge'];actual=snapshot(expected['qualification_certificate']['path'],expected['runtime_qualification_sha256'],bridge['plan']['path'],bridge['plan']['sha256']);assert actual==expected,'Final source/index/complete published mirror/protocol/cert/tool drift';return dict(head=actual['head'],tree=actual['tree'],app_tree=actual['app_tree'],source_files=len(actual['source_files']),semantic_index_entries=len(actual['semantic_index']),published_files=len(actual['published_files']),outside_files=len(actual['outside_proof_files']),full_source_index_mirror_protocol_cert_tools_exact=True)

def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='operation',required=True);f=sub.add_parser('freeze');f.add_argument('--certificate',required=True,type=Path);f.add_argument('--certificate-sha',required=True);f.add_argument('--out',required=True,type=Path);f.add_argument('--adoption-plan',required=True,type=Path);f.add_argument('--adoption-plan-sha',required=True);r=sub.add_parser('run');r.add_argument('--profile',choices=['desktop','mobile'],required=True);r.add_argument('--out',required=True,type=Path);r.add_argument('--guard',required=True,type=Path);a=p.parse_args()
    if a.operation=='freeze':
        assert not a.out.exists();d=snapshot(a.certificate.resolve(),a.certificate_sha,a.adoption_plan.resolve(),a.adoption_plan_sha);a.out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(state='FROZEN_FINAL_SOURCE_PUBLISHED_GUARD_ONLY_WORLD_UNRUN',path=str(a.out),sha256=sha(a.out.read_bytes()),source_files=len(d['source_files']),published_files=len(d['published_files']))));return 0
    output=a.out.resolve();assert not output.exists() and not output.is_relative_to(R) and output.parent.exists();raw=a.guard.read_bytes();expected=json.loads(raw);resources=resource_guard();before=check_guard(expected);output.with_name(output.name+'-LAUNCH-RESOURCES.json').write_text(json.dumps(resources,indent=2)+'\n')
    scratch=Path(tempfile.mkdtemp(prefix='hqw-',dir='/tmp'));assert len(str(scratch))<=35 and not list(scratch.iterdir());env={**os.environ,'PLAYWRIGHT_BROWSERS_PATH':str(TOOLS),'PW_EXECUTABLE':'/usr/bin/chromium','TMPDIR':str(scratch)}
    handler=partial(SimpleHTTPRequestHandler,directory=str(M));server=ThreadingHTTPServer(('127.0.0.1',0),handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();rc=1;errors=[];start=time.monotonic();command=None
    try:
        url=f'http://127.0.0.1:{server.server_address[1]}/1835/';command=['node',str(P/'observe-quiet-horse-world.cjs'),url,a.profile,str(output),str(a.guard.resolve())];print(json.dumps(dict(native_server=url,profile=a.profile,before=before)),flush=True);rc=subprocess.run(command,cwd=A,env=env).returncode
    finally:
        server.shutdown();server.server_close();thread.join(timeout=10)
        if thread.is_alive():errors.append('Owned HTTP-server thread did not close');rc=1
        try:after=check_guard(expected);assert before==after
        except BaseException as e:errors.append(str(e));after=None;rc=1
        if (output/'RESULT.json').exists():
            result=json.loads((output/'RESULT.json').read_bytes())
            if result['status']!='ACTUAL_UNHELD_QUIET_HORSE_MOTION_BOTH_VIEWS_AND_REAL_CARD_REQUIRES_ROOT_VIDEO_REVIEW':rc=1
        else:errors.append('Actual observer RESULT absent');rc=1
        closed=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),returncode=rc,seconds=time.monotonic()-start,profile=a.profile,observer_command=command,observer_cwd=str(A),guard_manifest=dict(path=str(a.guard.resolve()),bytes=len(raw),sha256=sha(raw)),before=before,after=after,closure_errors=errors,HTTP_server_closed=not thread.is_alive(),outer_supervisor_required_seconds=600,outer_supervisor_validation='REQUIRED_AFTER_THIS_WRAPPER_EXITS',native_actor_time_pose_material_renderer_modified=False,root_video_image_review='PENDING');output.with_name(output.name+'-GUARD-CLOSED.json').write_text(json.dumps(closed,indent=2)+'\n')
    return rc
if __name__=='__main__':sys.exit(main())
