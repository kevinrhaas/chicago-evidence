#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""SOURCE ONLY: current26 eight-part saddle/girth core, no rider/stirrup fit.

Never imports the old15-joint producer or loads its horse. Every part remains
unqualified until actual native/self/interpart/horse-contact/visual checks.
"""
import os
for k in('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import argparse,copy,hashlib,itertools,json,math,struct
from current_surface import Surface,need,sha
from closed_mesh import closed_grid,closed_loft,f32
from current26_glb import write_current26

HERE=Path(__file__).resolve().parent.parent
NAMES=['saddle_pad_l','saddle_pad_r','tree_sidebar_l','tree_sidebar_r','saddle_seat','riding_girth','billet_l','billet_r']

def add(a,b):return [x+y for x,y in zip(a,b)]
def mul(a,t):return [x*t for x in a]
def point(ref,offset):return add(ref['surface_world_m'],mul(ref['source_winding_unit_normal'],offset))
def norm(v):return math.sqrt(sum(x*x for x in v))
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]

def assign(mesh,name,refs,surface,material,rigid=False):
    need(len(refs)==len(mesh['positions']),'Every new vertex has current-source binding provenance')
    bindings=[surface.bind(ref,rigid)for ref in refs]
    mesh.update(binding_overrides=[],name=name,JOINTS_0=[j for j,w in bindings],WEIGHTS_0=[w for j,w in bindings],material_index=material,source_references=refs,binding_mode='rigid_horse_body'if rigid else'authored_barycentric_native_influence_field_no_pruning')
    return mesh

def grid_part(surface,name,xs,zs,low,high,material,rigid=False,side_levels=()):
    refs=[surface.dorsal(x,z)for z in zs for x in xs]
    mesh=closed_grid([point(r,low)for r in refs],[point(r,high)for r in refs],len(xs),len(zs),boundary_layers=[[point(r,o)for r in refs]for o in side_levels])
    bound=[None]*len(mesh['positions'])
    for key,i in mesh['grid_vertex_ids'].items():
        layer,row,col=map(int,key.split(':'));bound[i]=refs[row*len(xs)+col]
    return assign(mesh,name,bound,surface,material,rigid)

def port(mesh,zs,outer_col,zlo,zhi):
    lo,hi=zs.index(zlo),zs.index(zhi);need(hi==lo+1,'Exact consecutive port rows')
    ids=[mesh['grid_vertex_ids'][f'{layer}:{row}:{outer_col}']for layer,row in[(1,lo),(2,lo),(2,hi),(1,hi)]]
    faces=[f for f in mesh['faces']if set(f)<=set(ids)];need(len(faces)==2,'Actual two-triangle tree port')
    diagonal=set(faces[0])&set(faces[1]);need(len(diagonal)==2,'Actual port diagonal')
    labels=list(range(4));diag={ids.index(i)for i in diagonal}
    need(diag in({0,2},{1,3}),'Conforming port quad')
    if diag=={1,3}:labels=[1,2,3,0]
    return ids,labels

def diagonal_flag(labels):
    d={labels[0],labels[2]};need(d in({0,2},{1,3}),'Exact cap diagonal');return 0 if d=={0,2}else 1

def ring_for(surface,theta,zlo,zhi,inner,outer):
    refs=[surface.radial(theta,zlo),surface.radial(theta,zhi)]
    # Source-winding normals determine offsets; these are NEW authored surfaces.
    return [point(refs[0],inner),point(refs[0],outer),point(refs[1],outer),point(refs[1],inner)],[refs[0],refs[0],refs[1],refs[1]]

def common_interfaces(parts):
    by={p['name']:p for p in parts}
    pairs=[('saddle_pad_'+s,'tree_sidebar_'+s)for s in('l','r')]+[('tree_sidebar_'+s,'saddle_seat')for s in('l','r')]+[('tree_sidebar_'+s,'billet_'+s)for s in('l','r')]+[('billet_'+s,'riding_girth')for s in('l','r')]
    result=[]
    def vertex_bytes(p,i):return struct.pack('<3f',*p['positions'][i])
    def skin_bytes(p,i):return struct.pack('<4H4f',*p['JOINTS_0'][i],*p['WEIGHTS_0'][i])
    def key(p,f):return tuple(sorted(vertex_bytes(p,i)for i in f))
    for a,b in pairs:
        A,B=by[a],by[b];lookup={key(B,f):i for i,f in enumerate(B['faces'])};need(len(lookup)==len(B['faces']),'No duplicate source triangle aliases');matches=[{'a_face':i,'b_face':lookup[key(A,f)]}for i,f in enumerate(A['faces'])if key(A,f)in lookup]
        need(matches,'No exact emitted contact patch '+a+'/'+b)
        for match in matches:
            af,bf=A['faces'][match['a_face']],B['faces'][match['b_face']];bj={vertex_bytes(B,i):i for i in bf}
            for ai in af:need(skin_bytes(A,ai)==skin_bytes(B,bj[vertex_bytes(A,ai)]),'Shared contact vertices require identical serialized current26 weights')
        result.append({'a':a,'b':b,'exact_F32_face_pairs':matches,'status':'PROPOSED_ALIASES_ONLY_NATIVE_TOPOLOGY_AND_CONTACT_CERTIFICATION_REQUIRED','whole_pair_excluded':False})
    return result

def build(surface,params):
    zlo=params['girth_z_m']-params['girth_width_m']/2;zhi=params['girth_z_m']+params['girth_width_m']/2
    zs=sorted(set(params['saddle_z_stations_m']+[zlo,zhi]));need(zs[-1]>zhi and zs[0]<zlo,'Tree spans real billet port')
    parts=[];bars={};ports={}
    pad_lo,pad_hi=params['pad_offsets_m'];wood_lo,wood_hi=params['wood_offsets_m'];seat_lo,seat_hi=params['seat_offsets_m'];port_lo,port_hi=params['tree_port_offsets_m'];girth_lo,girth_hi=params['girth_offsets_m']
    need(pad_hi==wood_lo and wood_hi==seat_lo and wood_lo<port_lo<port_hi<wood_hi,'Explicit exact material interfaces')
    need(port_hi-port_lo>0 and girth_hi-girth_lo>0,'Real strap thickness')
    for side,sign in(('l',1),('r',-1)):
        xs=sorted([sign*params['bar_inner_x_m'],sign*params['bar_outer_x_m']])
        pad=grid_part(surface,'saddle_pad_'+side,xs,zs,pad_lo,pad_hi,0);parts.append(pad)
        bar=grid_part(surface,'tree_sidebar_'+side,xs,zs,wood_lo,wood_hi,1,rigid=True,side_levels=(port_lo,port_hi));parts.append(bar);bars[side]=bar
        # Exact shared pad/tree port positions also share exact authored weights.
        # The pad's lower surface retains the measured surface influence field.
        for key,dst in pad['grid_vertex_ids'].items():
            layer,row,col=map(int,key.split(':'))
            if layer==1:
                src=bar['grid_vertex_ids'][f'0:{row}:{col}'];pad['JOINTS_0'][dst]=list(bar['JOINTS_0'][src]);pad['WEIGHTS_0'][dst]=list(bar['WEIGHTS_0'][src]);pad['binding_overrides'].append({'vertex':dst,'source_part':bar['name'],'source_vertex':src,'reason':'Shared real material interface; same source point and weights'})
        ids,labels=port(bar,zs,1 if sign>0 else 0,zlo,zhi);ports[side]=(ids,labels)
    xs=[-params['bar_outer_x_m'],-params['bar_inner_x_m'],0.,params['bar_inner_x_m'],params['bar_outer_x_m']]
    parts.append(grid_part(surface,'saddle_seat',xs,zs,seat_lo,seat_hi,0,rigid=True))
    angles=[math.pi/2+i*math.pi/16 for i in range(17)];rings=[];ringrefs=[]
    for theta in angles:
        r,refs=ring_for(surface,theta,zlo,zhi,girth_lo,girth_hi);rings.append(r);ringrefs.extend(refs)
    girth=closed_loft(rings,cap_diagonals=(diagonal_flag(ports['l'][1]),diagonal_flag(ports['r'][1])))
    assign(girth,'riding_girth',ringrefs,surface,0);parts.append(girth)
    for side,sign,end_index in(('l',1,0),('r',-1,-1)):
        bar=bars[side];ids,labels=ports[side];start=[bar['positions'][i]for i in ids];center=[sum(p[k]for p in start)/4 for k in range(3)]
        theta0=math.atan2(center[0],center[1]-1.05);theta1=sign*math.pi/2
        rings=[[start[i]for i in labels]];refs=[[bar['source_references'][ids[i]]for i in labels]]
        for i in range(1,12):
            t=i/12;theta=theta0+(theta1-theta0)*t
            r,rr=ring_for(surface,theta,zlo,zhi,port_lo*(1-t)+girth_lo*t,port_hi*(1-t)+girth_hi*t)
            rings.append([r[j]for j in labels]);refs.append([rr[j]for j in labels])
        end_ids=girth['ring_vertex_ids'][end_index];rings.append([girth['positions'][end_ids[i]]for i in labels]);refs.append([girth['source_references'][end_ids[i]]for i in labels])
        billet=closed_loft(rings);assign(billet,'billet_'+side,[r for ring in refs for r in ring],surface,0)
        # Shared port vertices inherit the exact corresponding already-authored
        # tree/girth weights, so these registered cap vertices coincide in pose.
        for dst,src in zip(billet['ring_vertex_ids'][0],[ids[i]for i in labels]):
            billet['JOINTS_0'][dst]=list(bar['JOINTS_0'][src]);billet['WEIGHTS_0'][dst]=list(bar['WEIGHTS_0'][src]);billet['binding_overrides'].append({'vertex':dst,'source_part':bar['name'],'source_vertex':src,'reason':'Exact tree port source point and weights'})
        for dst,src in zip(billet['ring_vertex_ids'][-1],[end_ids[i]for i in labels]):
            billet['JOINTS_0'][dst]=list(girth['JOINTS_0'][src]);billet['WEIGHTS_0'][dst]=list(girth['WEIGHTS_0'][src]);billet['binding_overrides'].append({'vertex':dst,'source_part':girth['name'],'source_vertex':src,'reason':'Exact girth cap source point and weights'})
        parts.append(billet)
    parts.sort(key=lambda p:NAMES.index(p['name']));need([p['name']for p in parts]==NAMES,'Explicit complete current core cohort')
    return parts

def main():
    p=argparse.ArgumentParser();p.add_argument('--go',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    manifest=json.loads((HERE/'SOURCE-MANIFEST.json').read_text());go=json.loads(a.go.read_text())
    need(go['approved']is True and go['canonical_lane_released']is True,'Root execution handoff required')
    need(go['source_manifest_sha256']==sha((HERE/'SOURCE-MANIFEST.json').read_bytes()),'Reviewed exact source manifest')
    for row in manifest['files']:
        data=(HERE/row['file']).read_bytes();need(len(data)==row['bytes']and sha(data)==row['sha256'],'Prepared source '+row['file'])
    need(a.out.is_absolute()and a.out.resolve().parent==HERE.resolve()and not a.out.exists(),'Fresh absolute direct child of owned projection');a.out.mkdir()
    config=json.loads((HERE/'INPUTS.json').read_text());surface=Surface(config);params=json.loads((HERE/'PARAMETERS.json').read_text())
    need(params['stage']=='rest_core8'and params['Joseph_contact_targets']is None and params['stirrup_targets']is None and params['install_or_rider_qualification_allowed']is False,'Only current eight-part unqualified rest core is implemented')
    parts=build(surface,params)
    aliases=common_interfaces(parts)
    materials=[{'name':'reconstructed_dark_leather','pbrMetallicRoughness':{'baseColorFactor':[.105,.052,.025,1],'metallicFactor':0,'roughnessFactor':.82}},{'name':'reconstructed_saddle_tree_wood','pbrMetallicRoughness':{'baseColorFactor':[.22,.115,.05,1],'metallicFactor':0,'roughnessFactor':.78}}]
    provenance={'status':'CURRENT26_REST_CORE_SOURCE_CANDIDATE_NOT_QUALIFIED','generated_geometry_license':'GPL-3.0-or-later','horse_source_license':'CC-BY-4.0; retain complete unchanged Sevket source attribution','standing_sha256':config['standing_horse_sha256'],'moving_sha256':config['moving_horse_sha256'],'native_inputs_closed':config['native_closed'],'all_horse_triangles':17390,'source_body_rig_textures_or_clips_mutated':False,'pose_contact_rider_or_photo_accepted':False}
    generated=write_current26(a.out/'current26-saddle-girth-core-SOURCE.glb',surface.doc,surface.ibm,parts,materials,provenance)
    coverage={'parts':NAMES,'self_parts':NAMES,'horse_contact_parts':NAMES,'horse_triangles':17390,'interpart_pairs':list(itertools.combinations(NAMES,2)),'interpart_pair_count':28,'whole_pair_exemptions':[],'old20_9_split_inherited':False,'if_future_cohort29':'ALL406 pairs and all29 current parts vsALL17390; no inherited old9 fit'}
    receipt={'status':'GENERATED_UNQUALIFIED_SOURCE_ONLY','generated':generated,'coverage_required':coverage,'interfaces_proposed_not_certified':aliases,'queries':surface.queries,'part_topology':{p['name']:p['topology']for p in parts},'part_bindings':{p['name']:{'mode':p['binding_mode'],'source_references':p['source_references'],'binding_overrides':p['binding_overrides']}for p in parts},'actual_seat_face_ids':[i for i,f in enumerate(next(p for p in parts if p['name']=='saddle_seat')['faces'])if all(v in set(int(x)for k,x in next(p for p in parts if p['name']=='saddle_seat')['grid_vertex_ids'].items()if k.startswith('1:'))for v in f)],'Joseph_pelvis_or_sole_or_palm_targets':None,'stirrup_geometry':None,'historical406_run':False,'geometry_self_intersection_or_native_contact_or_visual_test_executed':False}
    # Re-read all current inputs after source generation. No input is a writer.
    for r in config['files']:
        data=Path(r['path']).read_bytes();need(sha(data)==r['sha256']and len(data)==r['bytes'],'Input drift after generation')
    for row in manifest['files']:
        data=(HERE/row['file']).read_bytes();need(len(data)==row['bytes']and sha(data)==row['sha256'],'Source drift after generation '+row['file'])
    receipt['source_and_input_after_exact']=True
    (a.out/'SOURCE-CANDIDATE.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('Current26 eight-part SOURCE candidate generated; native physical/rider/photo qualification UNRUN')

if __name__=='__main__':main()
