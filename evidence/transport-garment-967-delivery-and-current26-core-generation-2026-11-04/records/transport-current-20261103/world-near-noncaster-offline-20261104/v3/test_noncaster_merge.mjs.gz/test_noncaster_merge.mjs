/** Generic near-noncaster merge counterexamples. No browser; real Three geometry. */
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
const app = process.env.C4D_TEST_APP ?? path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const web = path.join(app, 'renderers/web');
const threeURL = pathToFileURL(path.join(web, 'vendor/three-0.185.1/three.module.js')).href;
const THREE = await import(threeURL);
const source = await fs.readFile(process.env.C4D_MERGE_SOURCE ?? path.join(web, 'js/far-merge.js'), 'utf8');
const code = source.replace("from 'three'", `from '${threeURL}'`)
  .replace("from './compact-streams.js'", `from '${pathToFileURL(path.join(web, 'js/compact-streams.js')).href}'`);
const {createFarMerge} = await import('data:text/javascript;base64,' + Buffer.from(code).toString('base64'));
function fixture({z = -100, cast = false, change = () => {}} = {}) {
  const scene = new THREE.Scene(), group = new THREE.Group(); group.name = 'enclosures';scene.add(group);
  const camera = new THREE.PerspectiveCamera(90, 1, .1, 2000);
  camera.position.set(100, 2, 50);camera.lookAt(100, 2, -100);camera.updateMatrixWorld();
  const material = new THREE.MeshStandardMaterial();
  const members = Array.from({length:4}, (_,i) => {
    const geo = new THREE.BoxGeometry(2,2,2);geo.clearGroups();geo.userData.confidence=.5;
    const m = new THREE.Mesh(geo,material);m.position.set(90+i*5,2,z);m.castShadow=cast;m.receiveShadow=true;
    m.userData.pickId=`owner-${i}`;group.add(m);return m;
  });
  change({members,material,group});scene.updateMatrixWorld(true);
  const banked = members.map(mesh => {
    mesh.geometry.computeBoundingSphere();const s=mesh.geometry.boundingSphere.clone().applyMatrix4(mesh.matrixWorld);
    return {mesh,c:s.center,r:s.radius};
  });
  let marked=0;
  const merger=createFarMerge({scene,camera,layers:['enclosures'],onGeometry:g=>{assert.equal(g,group);marked++;}});
  const restoreReach=()=>{for(const m of members)m.visible=!m.userData.reachCulled;};
  const update=()=>{restoreReach();merger.update();};
  const copies=()=>group.children.filter(m=>m.userData.farMerged);
  merger.rebuild(banked);
  return {scene,group,camera,material,members,banked,merger,restoreReach,update,copies,get marked(){return marked;}};
}
function check(name, run){run();console.log('PASS '+name);}
check('near already-noncasting opaque members merge, exact triangles/material/confidence and original picks',()=>{
  const f=fixture();
  const ray=new THREE.Raycaster(new THREE.Vector3(90,2,50),new THREE.Vector3(0,0,-1));
  const hits=()=>ray.intersectObjects(f.members,false).map(h=>[h.object.userData.pickId,h.faceIndex,h.distance]);
  const before=hits(), triangles=f.members.reduce((n,m)=>n+m.geometry.index.count,0);
  f.update();assert.equal(f.merger.state.merged,1);assert.equal(f.merger.state.callsSaved,3);
  assert.ok(f.members.every(m=>!m.visible));assert.equal(f.copies().length,1);
  const merged=f.copies()[0];assert.equal(merged.castShadow,false);assert.equal(merged.material,f.material);
  assert.equal(merged.geometry.index.count,triangles);assert.equal(merged.geometry.userData.confidence,.5);
  assert.deepEqual(hits(),before);assert.deepEqual(ray.intersectObject(merged,false),[]);
  assert.equal(f.marked,1);f.update();assert.equal(f.marked,1,'cached copy creates no second marking/allocation');
  f.merger.dispose();
});
check('near caster fixture explicitly preserves original shadow-risk refusal',()=>{
  const f=fixture({cast:true});f.update();assert.equal(f.merger.state.merged,0);assert.equal(f.copies().length,0);
  assert.ok(f.members.every(m=>m.visible));f.merger.dispose();
});
check('caster transition unmerges before caller renders; reversing flags reuses noncasting copy',()=>{
  const f=fixture();f.update();const copy=f.copies()[0];f.members[0].castShadow=true;
  // Actual main.js contract: reach restores source visibility, then update, then render.
  f.update();assert.equal(copy.visible,false);assert.ok(f.members.every(m=>m.visible));
  assert.equal(f.merger.state.merged,0);assert.equal(copy.castShadow,false);
  f.members[0].castShadow=false;f.update();assert.equal(f.copies()[0],copy);assert.equal(copy.visible,true);
  f.merger.setEnabled(false);f.update();assert.equal(copy.visible,false);assert.ok(f.members.every(m=>m.visible));
  f.merger.setEnabled(true);f.update();assert.equal(copy.visible,true);f.merger.dispose();
});
check('original far caster path remains allowed',()=>{
  const f=fixture({z:-500,cast:true});f.update();assert.equal(f.merger.state.merged,1);
  assert.equal(f.copies()[0].castShadow,false);f.merger.dispose();
});
for(const [name,change] of [
 ['blended material',({material})=>{material.transparent=true;}],
 ['partial draw range',({members})=>{members[0].geometry.setDrawRange(3,3);}],
 ['different render order',({members})=>{members[0].renderOrder=3;}],
 ['different receiving state',({members})=>{members[0].receiveShadow=false;}],
 ['different layer mask',({members})=>{members[0].layers.set(1);}]
]) check('near '+name+' refuses without allocation',()=>{
  const f=fixture({change});f.update();assert.equal(f.merger.state.merged,0);assert.equal(f.copies().length,0);f.merger.dispose();
});
check('hidden member stays hidden and never adds triangles',()=>{
  const f=fixture();f.members[0].visible=false;f.merger.update();assert.equal(f.merger.state.merged,0);
  assert.equal(f.members[0].visible,false);assert.equal(f.copies().length,0);f.merger.dispose();
});
check('reach-cull after merge hides copy and retains the exact reach answer',()=>{
  const f=fixture();f.update();f.members[0].userData.reachCulled=true;f.update();
  assert.equal(f.copies()[0].visible,false);assert.equal(f.members[0].visible,false);
  assert.ok(f.members.slice(1).every(m=>m.visible));assert.equal(f.merger.state.merged,0);f.merger.dispose();
});
check('a cluster outside the camera frustum stays chunked',()=>{
  const f=fixture();f.camera.lookAt(-1000,2,50);f.camera.updateMatrixWorld();f.update();
  assert.equal(f.merger.state.merged,0);assert.equal(f.copies().length,0);f.merger.dispose();
});
check('released arrays before census refuse the cluster',()=>{
  const f=fixture();f.merger.dispose();f.members[0].geometry.attributes.position.array=null;
  f.merger.rebuild(f.banked);f.update();assert.equal(f.merger.state.merged,0);assert.equal(f.copies().length,0);f.merger.dispose();
});
check('arrays released after census also refuse without retaining or rereading them',()=>{
  const f=fixture();f.members[0].geometry.attributes.normal.array=null;f.update();
  assert.equal(f.merger.state.merged,0);assert.equal(f.copies().length,0);assert.equal(f.members[0].geometry.attributes.normal.array,null);
  f.merger.dispose();
});

check('uniform nondefault layer is copied to the merged mesh',()=>{
  const f=fixture({change:({members})=>{for(const m of members)m.layers.set(2);}});
  f.camera.layers.enable(2);f.update();assert.equal(f.merger.state.merged,1);
  assert.equal(f.copies()[0].layers.mask,1<<2);f.merger.dispose();
});
for(const [name,change] of [
 ['uniform layer mask',f=>{for(const m of f.members)m.layers.set(2);}],
 ['uniform receiving state',f=>{for(const m of f.members)m.receiveShadow=false;}],
 ['uniform render order',f=>{for(const m of f.members)m.renderOrder=2;}],
 ['member transform',f=>{f.members[0].position.x+=5;}],
 ['geometry binding',f=>{f.members[0].geometry=f.members[0].geometry.clone();}],
 ['attribute binding',f=>{const g=f.members[0].geometry;g.setAttribute('normal',g.attributes.normal.clone());}],
 ['attribute version',f=>{f.members[0].geometry.attributes.position.needsUpdate=true;}],
 ['index version',f=>{f.members[0].geometry.index.needsUpdate=true;}],
 ['attribute backing array',f=>{const a=f.members[0].geometry.attributes.position;a.array=a.array.slice();}],
 ['draw range',f=>{f.members[0].geometry.setDrawRange(3,3);}],
 ['object before-render hook',f=>{f.members[0].onBeforeRender=()=>{};}],
 ['object after-render hook',f=>{f.members[0].onAfterRender=()=>{};}]
]) check('changed '+name+' invalidates cached copy before either distance branch',()=>{
  const f=fixture();f.update();const copy=f.copies()[0];assert.equal(copy.visible,true);
  change(f);f.camera.position.z=500;f.camera.updateMatrixWorld(); // original far path would now qualify
  f.update();assert.equal(copy.visible,false);assert.equal(f.copies().length,0);
  assert.equal(f.merger.state.merged,0);assert.ok(f.members.every(m=>m.visible));f.merger.dispose();
});
for(const hook of ['onBeforeRender','onAfterRender']) check('nondefault '+hook+' refuses at original census',()=>{
  const f=fixture({change:({members})=>{members[0][hook]=()=>{};}});f.update();
  assert.equal(f.copies().length,0);assert.equal(f.merger.state.merged,0);f.merger.dispose();
});
check('source change after census refuses even before its first copy is built',()=>{
  const f=fixture();f.members[0].geometry.attributes.position.needsUpdate=true;f.update();
  assert.equal(f.copies().length,0);assert.equal(f.merger.state.merged,0);f.merger.dispose();
});

console.log('PASS generic near-noncaster merge controls; actual browser savings/pixels/memory remain separately required');
