from pathlib import Path
import subprocess,os,json,sys
D=Path(__file__).resolve().parent
P=Path('/workspace/.cloud-setup/transport-current-20261103/world-near-noncaster-offline-20261104/v3')
env=dict(os.environ,C4D_TEST_APP='/workspace/chicago-driver-interaction-integration-20261104/chicago/4d',C4D_MERGE_SOURCE=str(P/'far-merge.prototype.mjs'))
for c in [['node','--check',str(P/'far-merge.prototype.mjs')],['node','--check',str(P/'test_noncaster_merge.mjs')],['node',str(P/'test_noncaster_merge.mjs')],['node',str(D/'check_plank_gap_filter.mjs')],['node',str(D/'check_far_plank_tops.mjs')]]:
 print('COMMAND',c,flush=True);subprocess.run(c,env=env,check=True)
negative=dict(env,C4D_MERGE_SOURCE='/workspace/chicago-driver-interaction-integration-20261104/chicago/4d/renderers/web/js/far-merge.js')
r=subprocess.run(['node',str(P/'test_noncaster_merge.mjs')],env=negative,capture_output=True,text=True)
(D/'ORIGINAL-NEGATIVE.log').write_text(r.stdout+r.stderr)
assert r.returncode!=0 and 'AssertionError' in r.stderr and '0 !== 1' in r.stderr,r.stderr
print('PASS original C rejects new near-noncaster positive as expected',flush=True)
