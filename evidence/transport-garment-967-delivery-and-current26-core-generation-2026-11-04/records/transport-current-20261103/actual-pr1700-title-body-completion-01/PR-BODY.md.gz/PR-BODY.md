Otis’s and Hans’s reduced-detail shirts and trousers now retain fuller reviewed garments, fixing visible gaps. This combined update also carries the driver movement and interaction fixes from #1697, reduces repeated building scalar storage, and makes the shadow check use its declared calibration viewpoint.

The upstream interaction source `8057b7d6b125a80aad907b4e52f7aa8838b1ff8a` is included through an ordinary merge; it was not independently merged into DEV at this delivery. Existing geometry, shader values and original performance limits are preserved by the memory change.

Validation:

- All 1,165 distinct native checks and 402 self-tests passed on the exact committed tree `ff904c3f508b807700d0f5ec214e4ed840f3e637` in four parts (330.671/383.668/517.624/506.206 seconds), each under the original 600-second cap with source/resource/owned-child guards. Actual HEAD `967b427e5f8681b27eceefb065cf6f37199e3bbc` passes five QA checks, whitespace and original publication/check.
- The four clothing payload hashes remain exact. Earlier all-24 desktop/phone human fixture evidence stays bound to its admitted garment source; it is not relabelled as a new combined-world render.
- The separate measured memory candidate `05a2899` passed the unchanged 400 MiB mobile gate at 399.358 MiB, with 0.642 MiB headroom. Actual GPU storage fell by 4,767,776 bytes; native and fresh-context fallback WebGL pixel/pick controls passed. This finite reading is not a memory verdict on the later combined tree; current CI must measure it.
- The shadow counterfactual retakes the documented lake_market view and restores boot. The source8057 mobile diagnostic measured worst8/restoration0; the boot-pose worst3 failure remains recorded. Combined desktop/mobile Stage9 remains pending.

Fresh exact-head CI and whole-world qualification remain pending. The separate global Light cost failure (4,100 calls versus 4,498 Full, above its unchanged0.9 ratio) remains open. Broad transport/animation tickets stay claimed with no PR settlement; full photographic quality, continuous contact, natural gait and boarding/riding acceptance are not claimed.
