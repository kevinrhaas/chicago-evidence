import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {execSync} from 'node:child_process';
const APP='/workspace/chicago-driver-interaction-integration-20261104/chicago/4d';
const ROOT=path.resolve(APP,'../../site/4d'), OUT=process.argv[2], MODE=process.argv[3];
assert(OUT && ['light','shadow1904'].includes(MODE));
const smoke=fs.readFileSync(path.join(APP,'tools/smoke_renderer.mjs'),'utf8');
const report={mode:MODE,sourceSmokeSha256:crypto.createHash('sha256').update(smoke).digest('hex'),checks:[],errors:[],httpErrors:[]};
report.variant='CURRENT_C_BASE_WITH_ACTUAL_V3_MODULE_OVERLAY';report.history=[];report.served={};
const overlay=new Map(['/walk/js/far-merge.js','/walk/js/main.js'].map(u=>[u,fs.readFileSync(path.join(OUT,'overlay',path.basename(u)))]));
const save=()=>fs.writeFileSync(path.join(OUT,'PROBE.json'),JSON.stringify(report,null,2)+'\n');
const check=(name,pass,details)=>{report.checks.push({name,pass:!!pass,details});save();assert(pass,name+': '+details)};
const signatureDistance=new Function(smoke.slice(smoke.indexOf('function signatureDistance(a, b) {'),smoke.indexOf('\n/** Diagnostic bracket',smoke.indexOf('function signatureDistance(a, b) {')))+'; return signatureDistance;')();
const server=http.createServer((req,res)=>{const rel=decodeURIComponent(req.url.split('?')[0]);if(overlay.has(rel)){const b=overlay.get(rel);report.served[rel]={sha256:crypto.createHash('sha256').update(b).digest('hex'),bytes:b.length,requests:(report.served[rel]?.requests||0)+1};save();res.setHeader('content-type','text/javascript');res.end(b);return;}let file=path.join(ROOT,rel);if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');if(!file.startsWith(ROOT+'/')||!fs.existsSync(file)){res.writeHead(404);res.end(rel);return}res.setHeader('content-type',({'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.glb':'model/gltf-binary','.wasm':'application/wasm','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg'})[path.extname(file)]||'application/octet-stream');fs.createReadStream(file).pipe(res)});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
let ns;try{ns=await import('playwright')}catch{ns=await import(path.join((process.env.NODE_PATH||execSync('npm root -g',{encoding:'utf8'})).trim().split(path.delimiter)[0],'playwright/index.js'))}const{chromium}=ns.chromium?ns:ns.default;
let browser;
try{
 browser=await chromium.launch({executablePath:process.env.PW_EXECUTABLE,args:['--enable-unsafe-swiftshader']});
 const ctx=await browser.newContext({viewport:{width:390,height:780},hasTouch:true,isMobile:false,deviceScaleFactor:2});
 const page=await ctx.newPage();page.setDefaultTimeout(90000);
 page.on('pageerror',e=>{report.errors.push(String(e));save()});page.on('console',m=>{if(m.type()==='error'){report.errors.push(m.text());save()}});page.on('response',r=>{if(r.status()>=400){report.httpErrors.push({status:r.status(),url:r.url()});save()}});
 const url=`http://127.0.0.1:${server.address().port}/walk/?keep-geometry=1`;
 await page.goto(url,{waitUntil:'domcontentloaded'});
 await page.waitForFunction(()=>window.__chicago4d?.ready===true||!!window.__chicago4d?.error,null,{timeout:240000,polling:1000});
 check('1835 reaches ready',await page.evaluate(()=>window.__chicago4d?.ready===true));
 report.executedModule=await page.evaluate(async()=>{const m=await import('/walk/js/far-merge.js');return {candidateConstructor:m.createFarMerge.toString().includes('sameMemberInput'),nearBranch:m.createFarMerge.toString().includes('nearNoncasting')};});check('actual browser executed candidate far-merge constructor',report.executedModule.candidateConstructor&&report.executedModule.nearBranch,JSON.stringify(report.executedModule));
 const contracts=await import('file://'+path.join(APP,'tools/world_smoke_contracts.mjs'));
 const bstart=smoke.indexOf('    const batchCensus = await page.evaluate(() => {');
 const bend=smoke.indexOf('    await page.evaluate(() => window.__chicago4d.setAnimationHold(true));',bstart);
 const batchCode=smoke.slice(bstart,bend);
 report.batchSourceSha256=crypto.createHash('sha256').update(batchCode).digest('hex');
 const constants={STRUCTURE_BATCHES:contracts.STRUCTURE_BATCH_KEYS.length,TEXTURED_STRUCTURE_BATCHES:Number(smoke.match(/const TEXTURED_STRUCTURE_BATCHES = ([0-9]+)/)[1]),ROUGHNESS_VALUES_MIN:Number(smoke.match(/const ROUGHNESS_VALUES_MIN = ([0-9]+)/)[1]),structureBatchContract:contracts.structureBatchContract};
 report.batchCensus=await new Function('page','check','label',...Object.keys(constants), 'return(async()=>{'+batchCode+';return batchCensus;})()')(page,check,'mobile 390x780',...Object.values(constants));save();
 const bootStart=smoke.indexOf('    const bootPose = await page.evaluate(() => {');
 const bootEnd=smoke.indexOf('    // Stand where the thresholds were measured.',bootStart);
 const bootCode=smoke.slice(bootStart,bootEnd);
 report.bootPoseSourceSha256=crypto.createHash('sha256').update(bootCode).digest('hex');
 report.bootPose=await new Function('page','return(async()=>{'+bootCode+';return bootPose;})()')(page);save();
 const estart=smoke.indexOf('  const enterTown = () => page.evaluate(async () => {');
 const eend=smoke.indexOf('  // A click on the HUD chrome',estart);
 const enterCode=smoke.slice(estart,eend);
 report.enterTownSourceSha256=crypto.createHash('sha256').update(enterCode).digest('hex');save();
 await new Function('page','return(async()=>{'+enterCode+';return enterTown();})()')(page);
 report.enteredTown=true;save();
 await page.exposeFunction('__worldProbeProgress',x=>{report.progress=x;report.history.push(x);save()});
 if(MODE==='light'){
  const dstart=smoke.indexOf('    const detail = await page.evaluate(async (stands) => {');
  const dend=smoke.indexOf('    for (const s of detail.seen) {',dstart);
  const originalDetail=smoke.slice(dstart,dend);
  report.detailOriginalSourceSha256=crypto.createHash('sha256').update(originalDetail).digest('hex');
  const standText=smoke.match(/  \{\n    id: 'prairie_west'[^]*?\n  \},/)[0].trim().replace(/,$/,'');
  const stands=new Function('return ['+standText+'];')();
  report.selectedStands=stands;report.selectedLevels=['full','light'];save();
  let detailCode=originalDetail.replace('      const started = a.detail;', '      const started = a.detail; const startedMerge = a.farMerge.enabled; a.setFarMerge(false);').replace('for (const level of a.detailOrder) {',"for (const level of a.detailOrder.filter((level) => level === 'full' || level === 'light')) {");
  detailCode=detailCode.replace('        await a.setDetail(level);',"        await window.__worldProbeProgress({level,phase:'beforeSetDetail'});\n        await a.setDetail(level);\n        await window.__worldProbeProgress({level,phase:'afterSetDetail'});");
  detailCode=detailCode.replace('        await settle();',"        await settle();\n        await window.__worldProbeProgress({level,phase:'afterTierSettle'});");
  detailCode=detailCode.replace('          atStands.push(row);',`          row.off = {calls: r.drawCalls, tris: r.triangles};
          a.setFarMerge(true); a.step();
          const candidate = a.stats(); row.on = {calls:candidate.drawCalls,tris:candidate.triangles};
          row.merge = a.farMerge;
          a.setFarMerge(false); a.step();
          const restored = a.stats(); row.offAgain = {calls:restored.drawCalls,tris:restored.triangles};
          row.calls = row.on.calls; row.tris = row.on.tris;
          atStands.push(row);
          await window.__worldProbeProgress({level,phase:'baseline',row});`);
  detailCode=detailCode.replace('      await a.setDetail(started);', '      await a.setDetail(started); a.setFarMerge(startedMerge);');
  report.detailObservedSourceSha256=crypto.createHash('sha256').update(detailCode).digest('hex');save();
  report.detail=await new Function('page','STANDS','return(async()=>{'+detailCode+';return detail;})()')(page,stands);save();
  const full=report.detail.seen.find(x=>x.level==='full'),light=report.detail.seen.find(x=>x.level==='light');
  report.ratio={full:full.worstCalls.calls,light:light.worstCalls.calls,ratio:light.worstCalls.calls/full.worstCalls.calls};save();
  const cstart=smoke.indexOf('    const LIGHT_CALL_FLOOR = 5900;');
  const cend=smoke.indexOf('    // THE RIDGE DRAPE follows',cstart);
  const costChecks=smoke.slice(cstart,cend);
  report.costPredicatesSourceSha256=crypto.createHash('sha256').update(costChecks).digest('hex');save();
  const observe=(name,pass,details)=>{report.checks.push({name,pass:!!pass,details});if(!pass&&!report.firstFailure)report.firstFailure={name,details};save();};
  new Function('check','label','full','light',costChecks)(observe,'mobile 390x780',full,light);
  for(const row of report.detail.seen){const p=row.atStands[0];observe(row.level+' optimisation OFF reproduces immutable C original baseline',p.off.calls===(row.level==='full'?4498:4100),JSON.stringify(p));observe(row.level+' merge preserves exact drawn triangles and restores OFF counters',p.on.tris===p.off.tris&&p.offAgain.tris===p.off.tris&&p.offAgain.calls===p.off.calls,JSON.stringify(p));}
  report.activeMerge=await page.evaluate(()=>window.__chicago4d.farMerge);save();
  observe('actual candidate is exercised at original prairie view',report.activeMerge.merged>0,JSON.stringify(report.activeMerge));
  if(report.activeMerge.merged>0){
   await page.evaluate(()=>window.__chicago4d.setAnimationHold(true));
   const physical=async(on)=>{await page.evaluate(v=>window.__chicago4d.setFarMerge(v),on);const signature=await page.evaluate(()=>window.__chicago4d.capture(48));return {signature,state:await page.evaluate(()=>({merge:window.__chicago4d.farMerge,shadows:window.__chicago4d.furnitureShadows,copies:window.__chicago4d.scene3d.children.flatMap(g=>g.children.filter(m=>m.userData.farMerged).map(m=>({visible:m.visible,castShadow:m.castShadow,material:m.material.uuid,layers:m.layers.mask,receiveShadow:m.receiveShadow,renderOrder:m.renderOrder})))}))};};
   const off=await physical(false);report.physical={off};save();await page.screenshot({path:path.join(OUT,'prairie-off.png')});
   const on=await physical(true);report.physical.on=on;save();await page.screenshot({path:path.join(OUT,'prairie-on.png')});
   // A real source triangle provides a predeclared tap point; the originals remain the pick arrays.
   report.picks=await page.evaluate(async()=>{const a=window.__chicago4d,T=await import('three');const {compactStreams}=await import('/walk/js/compact-streams.js');const{boxedPositionAt}=compactStreams(T);const sources=a.enclosures.group.children.filter(m=>m.isMesh&&!m.userData.farMerged&&!m.visible&&!m.userData.reachCulled&&m.geometry.attributes.position.array);const read=p=>{const h=a.enclosures.pickAt(p,a.camera);return h?{id:h.id,distance:h.distance}:null;};let point=null;for(const m of sources){const g=m.geometry,v=new T.Vector3();for(let k=0;k<3;k++){const i=g.index?g.index.getX(k):k;v.add(boxedPositionAt(g,i,new T.Vector3()).applyMatrix4(m.matrixWorld));}v.multiplyScalar(1/3).project(a.camera);const p={x:v.x,y:v.y};if(Math.abs(p.x)<1&&Math.abs(p.y)<1&&read(p)){point=p;break;}}if(!point)return {positive:false,reason:'no actual merged source triangle produced a positive enclosure pick'};const on=read(point);a.setFarMerge(false);const off=read(point);a.setFarMerge(true);const again=read(point);return {positive:true,point,on,off,again};});save();
   observe('actual source GPU pick survives merging and restoration',report.picks.positive&&report.picks.on.id===report.picks.off.id&&report.picks.on.id===report.picks.again.id&&Math.abs(report.picks.on.distance-report.picks.off.distance)<=1e-6,JSON.stringify(report.picks));
   const back=await physical(false);report.physical.back=back;report.physical.delta=signatureDistance(off.signature,on.signature);report.physical.restore=signatureDistance(off.signature,back.signature);save();
   observe('merge leaves all original 48-squared picture and shadow pixels unchanged',report.physical.delta.worst===0&&report.physical.delta.mean===0,JSON.stringify(report.physical.delta));
   observe('restoring merge OFF restores the original picture exactly',report.physical.restore.worst===0&&report.physical.restore.mean===0,JSON.stringify(report.physical.restore));
   observe('all merged copies stay noncasting',on.state.copies.every(m=>m.castShadow===false)&&on.state.shadows.casting===off.state.shadows.casting,JSON.stringify(on.state));
   await page.evaluate(()=>{window.__chicago4d.setAnimationHold(false);window.__chicago4d.setFarMerge(true);});
  }
  if(report.checks.some(x=>!x.pass)){report.status='DIAGNOSTIC_NONPASS';save();process.exitCode=1;}

 }else{
  report.shadow=[];
  const number=(name)=>Number(smoke.match(new RegExp('const '+name+' = ([0-9_]+);'))[1].replaceAll('_',''));
  const rigConstants=['SHADOW_REACH_LIGHT_M','SHADOW_REACH_M','SHADOW_MAP_LOW','SHADOW_MAP_FULL'];
  const rigCode=smoke.slice(smoke.indexOf('const shadowRigFor ='),smoke.indexOf('\n/**',smoke.indexOf('const shadowRigFor =')));
  const shadowRigFor=new Function(...rigConstants,rigCode+';return shadowRigFor;')(...rigConstants.map(number));
  const kstart=smoke.indexOf('    const rigLevel = await page.evaluate(() => window.__chicago4d.detail);');
  const kend=smoke.indexOf('    // --- R-BUG6, the shadow box',kstart);
  const originalKernel=smoke.slice(kstart,kend);
  report.shadowOriginalSourceSha256=crypto.createHash('sha256').update(originalKernel).digest('hex');
  const poseStart=smoke.indexOf('    const standAtBootPose = async () => {');
  const poseEnd=smoke.indexOf('\n\n',poseStart);
  const poseCode=smoke.slice(poseStart,poseEnd);
  report.shadowPoseSourceSha256=crypto.createHash('sha256').update(poseCode).digest('hex');save();
  for(const station of ['boot','lake_market']){
   const pose=station==='boot'?report.bootPose:await page.evaluate(()=>window.__chicago4d.scene.anchors.find(a=>a.id==='lake_market'));
   const standAtBootPose=()=>new Function('page','bootPose','return(async()=>{'+poseCode+';return standAtBootPose();})()')(page,pose);
   let kernel=originalKernel;
   for(const [variable,suffix]of [['reachFull','120'],['reachOld','60'],['reachBack','restored120']]){
    const line=kernel.split('\n').find(x=>x.includes('const '+variable+' ='));
    kernel=kernel.replace(line,line+"\n    await page.screenshot({path:shotPrefix+'-"+suffix+".png'});");
   }
   const startCheck=report.checks.length;
   const observeCheck=(name,pass,details)=>{report.checks.push({name,pass:!!pass,details});save()};
   const raw=await new Function('page','check','label','shadowRigFor','touch','standAtBootPose','ROAD_AID_GRID','SHADOW_REACH_MIN_WORST','signatureDistance','shotPrefix','return(async()=>{'+kernel+';return {rigLevel,rig,want,woundBack,restored,dReach,dReachBack,reachFull,reachOld,reachBack};})()')(page,observeCheck,'mobile 390x780 '+station,shadowRigFor,true,standAtBootPose,number('ROAD_AID_GRID'),number('SHADOW_REACH_MIN_WORST'),signatureDistance,path.join(OUT,station));
   report.shadow.push({station,pose,...raw,checks:report.checks.slice(startCheck)});save();
  }
  const pstart=smoke.indexOf('      const peopleMountSelector =');const pend=smoke.indexOf('      const door = wantPublished',pstart);
  const positive=smoke.slice(pstart,pend);report.positiveSourceSha256=crypto.createHash('sha256').update(positive).digest('hex');
  const peopleSelector=await new Function('page','check','label',`return(async()=>{${positive}; return peopleMountSelector;})()`)(page,check,'mobile 390x780');
  await page.goto(`http://127.0.0.1:${server.address().port}/1904/?keep-geometry=1`,{waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>window.__chicago4d?.ready===true||!!window.__chicago4d?.error,null,{timeout:240000,polling:1000});check('1904 reaches ready',await page.evaluate(()=>window.__chicago4d?.ready===true));
  const dstart=smoke.indexOf('        const drawer = await page.evaluate((peopleSelector)');const dend=smoke.indexOf('        // >>> T-2667:',dstart);const drawerCode=smoke.slice(dstart,dend);report.drawerSourceSha256=crypto.createHash('sha256').update(drawerCode).digest('hex');
  report.drawer=await new Function('page','check','label','peopleMountSelector',`return(async()=>{${drawerCode}; return drawer;})()`)(page,check,'mobile 390x780',peopleSelector);save();
  report.publicPeopleOpen=await page.evaluate(()=>typeof window.__chicago4d.people?.open==='function');check('1904 public people.open bridge retained',report.publicPeopleOpen);
 }
 report.status=report.checks.some(x=>!x.pass)?'DIAGNOSTIC_NONPASS':'DIAGNOSTIC_COMPLETED';report.noMissingRequests=report.httpErrors.length===0;save();
}catch(e){report.status='NONPASS';report.failure=String(e.stack||e);save();console.error(report.failure);process.exitCode=1}
finally{await browser?.close();await new Promise(r=>server.close(r));save()}
