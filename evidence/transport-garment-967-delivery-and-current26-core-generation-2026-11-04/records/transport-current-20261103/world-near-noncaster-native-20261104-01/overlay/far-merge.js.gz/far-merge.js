/**
 * far-merge.js — give a draw call back when chunking has stopped buying
 * anything with it.
 *
 * T-0146, the second of T-0149's three pieces. The first (T-0150) stopped
 * drawing furniture beyond a reach at `light`. This one is about the two tiers
 * that have no reach: `full` and `balanced`, where the axial stands draw the
 * whole town and every chunk is its own call.
 *
 * ## The trade this undoes, exactly where it stops paying
 *
 * The 2026-08-21 chunking (T-0067, T-0068, T-0069, T-0119) deliberately
 * converted triangles into draw calls: one town-wide fence mesh has a bounding
 * sphere no frustum can cull, so 33,166 triangles of fence were drawn in every
 * frame including the fences behind you. Splitting the layer into patches of
 * ground gives the frustum something to skip, and at an ordinary stand it skips
 * a lot. `main.js` § BUDGET says so in the same words: *"the call count is the
 * price of the culling that keeps those ceilings reachable"*.
 *
 * A price is only worth paying while something is bought with it. Down Lake
 * Street from Canal nothing is behind the camera, the whole town is inside the
 * frustum, and the frustum skips **nothing** — so the chunk boundaries in that
 * frame are pure loss: 53 calls for the wagon yard's 64,640 triangles, 48 for
 * the fences, 38 for the plank walks, measured on the published mirror at
 * `full` (`tools/measure_stand_budget.mjs --stand lake_at_canal`). This module
 * watches for exactly that condition and, while it holds, submits the chunks as
 * ONE mesh instead of many.
 *
 * ## The two conditions, and why each one makes the merge free
 *
 * A cluster is a fixed patch of ground — `CLUSTER_M` across — holding the chunk
 * meshes whose own spheres centre inside it. It is merged for a frame only when
 * BOTH of these are true of the cluster's bounding sphere:
 *
 *  1. **It is wholly inside the view frustum.** Then no member of it could have
 *    been culled this frame, so drawing the cluster as one mesh submits the
 *    identical set of triangles — the saving is in calls and the triangle count
 *    is unchanged, not approximately but exactly. This is the condition that
 *    matters: the headroom under these ceilings had four figures at the axial
 *    stands when this was written (1,423,855 against 1,425,000 at `full`), and
 *    has six only because T-0223 culled the sun's pass over the far timber and
 *    T-0229 then handed the raise back — 1,207,211 against 1,400,000 down Lake
 *    Street today. A merge that could ADD a triangle would be a worse bargain
 *    than the calls it saves, at either figure. It cannot.
 *  2. **Every part of it is more than `FAR_M` from the eye.** The sun's pass
 *    draws a caster a second time, and its rig is an orthographic box `±r` in
 *    LIGHT space around the visitor (`world.setShadowRig`), r = 240 m at `full`
 *    and `balanced`. A point whose light-space |x| and |y| are both within 240
 *    lies within 240·√2 = 339.4 m of the centre, so anything beyond 340 m is
 *    outside that box whatever the sun's bearing. A merged cluster is therefore
 *    made of meshes that were contributing nothing to the shadow map, the
 *    merged mesh does not cast, and the shadow pass reads the same before and
 *    after. No bound, no tuning: a stated distance and the geometry of a box.
 *
 * A cluster of opaque meshes that ALREADY do not cast also satisfies condition
 * 2, at any distance: replacing no shadow contributors with a noncasting copy
 * cannot change the shadow pass. This reads the actual per-mesh flags, never a
 * tier name. Blended meshes retain the original far-only rule and their order.
 *
 * Composition with T-0150 is the third condition: every member must actually
 * be visible after the reach pass, and none may have been reach-culled. A near
 * noncasting merge cannot put back a triangle the tier or frustum withheld.
 *
 * ## What it is not
 *
 * It is not an LOD and not a simplification: no vertex is moved, dropped or
 * re-typed, no material changes, and the confidence attribute rides along in
 * the merged buffer so the confidence view colours a merged cluster exactly as
 * it colours the chunks. It is a change of BATCHING and nothing else — which is
 * why it can be applied at every tier without the tier meaning something
 * different.
 *
 * Picking is untouched for the same reason it has to be: the chunk meshes stay
 * in the scene and in the arrays each layer raycasts (`enclosures.pickAt`,
 * `yard.pickAt`, …). `THREE.Raycaster` does not test `visible` — it walks the
 * array it is handed — so a merged-away chunk still answers a click with its
 * own `pickId` and its own chunk-local `faceIndex`. The merged mesh itself is
 * given an empty `raycast` so it can never answer instead.
 *
 * Buffers are built LAZILY, the first frame a cluster actually qualifies, and
 * then kept. A cluster a visitor never stands far enough back from never costs
 * a byte, and a town walked end to end settles at roughly one extra copy of the
 * merged layers' vertex data.
 */
import * as THREE from 'three';
import { compactStreams } from './compact-streams.js';

const { boxedPositionAt } = compactStreams(THREE);

/**
 * How far a cluster may reach, in metres. Bigger clusters save more calls and
 * qualify less often — condition 1 asks the WHOLE cluster to be in frustum, and
 * a cluster subtending more than the field of view can never satisfy it. At the
 * 340 m floor a 200 m patch subtends at most about 33°, inside the 62° field,
 * so the two constants are chosen together rather than independently.
 */
const CLUSTER_M = 200;
/** The shadow floor derived above: 240 · √2 = 339.4, rounded up. */
const FAR_M = 340;
/**
 * Below this many members a cluster is left chunked. Merging two meshes saves
 * one call and costs a copy of their vertices; the copy is only worth making
 * where the call count is the thing being complained about.
 */
const MIN_MEMBERS = 4;

// Weak identity tokens never retain released source arrays or replaced attributes.
const INPUT_IDS = new WeakMap();
let nextInputId = 1;
function inputId(value) {
  if (value === null || typeof value !== 'object' && typeof value !== 'function') return 0;
  let id = INPUT_IDS.get(value);
  if (!id) { id = nextInputId++; INPUT_IDS.set(value, id); }
  return id;
}
const DEFAULT_BEFORE_RENDER = THREE.Object3D.prototype.onBeforeRender;
const DEFAULT_AFTER_RENDER = THREE.Object3D.prototype.onAfterRender;
const defaultRenderHooks = (m) => m.onBeforeRender === DEFAULT_BEFORE_RENDER
  && m.onAfterRender === DEFAULT_AFTER_RENDER;
function attributeInput(a) {
  return a ? { id: inputId(a), array: inputId(a.array), version: a.version,
    count: a.count, size: a.itemSize, normalized: a.normalized, gpuType: a.gpuType } : null;
}
function sameAttribute(a, saved) {
  return saved === null ? a === null : !!a && inputId(a) === saved.id
    && inputId(a.array) === saved.array && a.version === saved.version && a.count === saved.count
    && a.itemSize === saved.size && a.normalized === saved.normalized && a.gpuType === saved.gpuType;
}
function memberInput(m) {
  m.updateWorldMatrix(true, false);
  const g = m.geometry, boxes = g.userData?.positionBoxes;
  return { geometry: inputId(g), parent: inputId(m.parent), matrix: m.matrixWorld.elements.slice(),
    attrs: Object.keys(g.attributes).map(name => [name, attributeInput(g.attributes[name])]),
    index: attributeInput(g.index), range: [g.drawRange.start, g.drawRange.count],
    groups: g.groups.map(x => [x.start, x.count, x.materialIndex]),
    materials: (Array.isArray(m.material) ? m.material : [m.material]).map(x => [inputId(x), x.version]),
    layers: m.layers.mask, receiveShadow: m.receiveShadow, order: m.renderOrder,
    grade: g.userData?.confidence, lane: g.userData?.confidenceLane,
    boxes: boxes ? [boxes.first, ...boxes.boxes] : null };
}
function sameMemberInput(m, saved) {
  m.updateWorldMatrix(true, false);
  const g = m.geometry;
  if (!defaultRenderHooks(m) || inputId(g) !== saved.geometry || inputId(m.parent) !== saved.parent
      || m.layers.mask !== saved.layers || m.receiveShadow !== saved.receiveShadow || m.renderOrder !== saved.order
      || m.matrixWorld.elements.some((x, i) => x !== saved.matrix[i])
      || g.drawRange.start !== saved.range[0] || g.drawRange.count !== saved.range[1]
      || g.userData?.confidence !== saved.grade || g.userData?.confidenceLane !== saved.lane
      || !sameAttribute(g.index, saved.index) || g.groups.length !== saved.groups.length) return false;
  let attrs = 0;
  for (const name in g.attributes) if (Object.hasOwn(g.attributes, name)) attrs++;
  if (attrs !== saved.attrs.length) return false;
  for (const [name, state] of saved.attrs) if (!sameAttribute(g.attributes[name], state)) return false;
  for (let i = 0; i < g.groups.length; i++) {
    const a = g.groups[i], b = saved.groups[i];
    if (a.start !== b[0] || a.count !== b[1] || a.materialIndex !== b[2]) return false;
  }
  const mats = m.material;
  if ((Array.isArray(mats) ? mats.length : 1) !== saved.materials.length) return false;
  for (let i = 0; i < saved.materials.length; i++) {
    const mat = Array.isArray(mats) ? mats[i] : mats;
    if (inputId(mat) !== saved.materials[i][0] || mat.version !== saved.materials[i][1]) return false;
  }
  const boxes = g.userData?.positionBoxes;
  if (saved.boxes === null) return !boxes;
  return !!boxes && boxes.first === saved.boxes[0] && boxes.boxes.length + 1 === saved.boxes.length
    && boxes.boxes.every((x, i) => x === saved.boxes[i + 1]);
}

/** The signature two meshes must share to be mergeable at all. */
function signatureOf(mesh) {
  const geo = mesh.geometry;
  if (!defaultRenderHooks(mesh) || !geo || !geo.attributes?.position) return null;
  const names = Object.keys(geo.attributes).sort();
  const attrs = names.map((n) => {
    const a = geo.attributes[n];
    // An interleaved or instanced attribute has no plain array to concatenate,
    // and a morph target would need its own pass. Neither exists in these
    // layers today; refusing them here is what keeps that true.
    if (!a.array || a.isInterleavedBufferAttribute || a.isInstancedBufferAttribute) return null;
    return `${n}:${a.itemSize}:${a.array.constructor.name}:${a.normalized ? 1 : 0}`;
  });
  if (attrs.some((a) => a === null)) return null;
  if (geo.morphAttributes && Object.keys(geo.morphAttributes).length) return null;
  if (geo.groups && geo.groups.length > 1) return null;
  const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
  if (mats.length !== 1 || !mats[0]) return null;
  // A boxed mesh (T-2700) is a mesh too wide for one box, so its sphere spans
  // more of the town than a cluster does, and in a bucket beside chunks of the
  // same streams it would hold their cluster out of every merge it could take.
  // It buckets with boxed meshes only, as it did beside the float chunks it was.
  const boxed = geo.userData?.positionBoxes ? '|boxed' : '';
  return `${mats[0].uuid}|${geo.index ? 'i' : 'n'}|${attrs.join(',')}${boxed}`;
}

/** Extra near-path proof; the original far-distance path stays unchanged. */
function nearNoncasting(members) {
  const source = members[0], material = source.material;
  // Regrouping a blended list can change its order, even with no shadows.
  if (Array.isArray(material) || material?.opacity !== 1 || material.transparent !== false
      || material.transmission || material.depthWrite !== true || material.depthTest !== true) return false;
  for (const m of members) {
    const geo = m.geometry, count = geo.index ? geo.index.count : geo.attributes.position.count;
    if (m.constructor !== THREE.Mesh || m.castShadow !== false || m.material !== material
        || m.receiveShadow !== source.receiveShadow || m.renderOrder !== source.renderOrder
        || m.layers.mask !== source.layers.mask || geo.drawRange.start !== 0 || geo.drawRange.count < count
        || geo.groups.length && (geo.groups.length !== 1 || geo.groups[0].start !== 0
          || geo.groups[0].count < count)) return false;
  }
  return true;
}

/** The relative transform from a mesh's own space into its parent group's. */
const _inv = new THREE.Matrix4();
const _rel = new THREE.Matrix4();
const _identity = new THREE.Matrix4();
function relativeMatrix(mesh, group) {
  group.updateWorldMatrix(true, false);
  mesh.updateWorldMatrix(true, false);
  _inv.copy(group.matrixWorld).invert();
  return _rel.multiplyMatrices(_inv, mesh.matrixWorld);
}

/**
 * Concatenate a cluster's members into one geometry, in the parent group's
 * space. Returns null if anything about the set refuses — a refusal costs the
 * cluster its merge and nothing else.
 */
function mergeGeometries(members, group) {
  const first = members[0].geometry;
  const names = Object.keys(first.attributes);
  const indexed = !!first.index;
  // A phone lets go of a chunk's arrays once they are on the GPU
  // (upload-release.js); a cluster holding any such chunk refuses and stays
  // chunked.
  for (const m of members) {
    const g = m.geometry;
    if (names.some((n) => !g.attributes[n]?.array) || (indexed && !g.index?.array)) return null;
  }
  let verts = 0;
  let indices = 0;
  for (const m of members) {
    verts += m.geometry.attributes.position.count;
    if (indexed) indices += m.geometry.index.count;
  }
  const out = new THREE.BufferGeometry();
  const dst = {};
  for (const name of names) {
    const src = first.attributes[name];
    // A quantized position (Int16 x 4 over each member's own box, T-2687, or over each piece's, T-2700) is
    // written out as float32 metres in the group's frame: the members are on
    // different grids and the merged mesh has no matrix of its own.
    const asFloat = name === 'position' && src.normalized;
    const size = asFloat ? 3 : src.itemSize;
    const array = asFloat ? new Float32Array(verts * 3) : new src.array.constructor(verts * size);
    // Written through an attribute so a compact normal (Int8 x 4 normalized,
    // T-2569) is re-encoded at its own stride, not overwritten as float xyz.
    dst[name] = { array, at: 0, src, size,
      attr: new THREE.BufferAttribute(array, size, asFloat ? false : src.normalized) };
  }
  const idx = indexed
    ? (verts > 65535 ? new Uint32Array(indices) : new Uint16Array(indices))
    : null;
  let idxAt = 0;
  let base = 0;
  const p = new THREE.Vector3();
  const nrm = new THREE.Matrix3();
  for (const mesh of members) {
    const geo = mesh.geometry;
    const rel = relativeMatrix(mesh, group);
    const moved = !rel.equals(_identity);
    // A quantized chunk's matrix (T-2687) is a move and a uniform scale and
    // turns nothing, so its normals are copied as they are rather than turned
    // through the identity and re-rounded.
    const e = rel.elements;
    const turned = moved && !(e[1] === 0 && e[2] === 0 && e[4] === 0 && e[6] === 0
      && e[8] === 0 && e[9] === 0 && e[0] > 0 && e[0] === e[5] && e[0] === e[10]);
    if (turned) nrm.getNormalMatrix(rel);
    const count = geo.attributes.position.count;
    for (const name of names) {
      const src = geo.attributes[name];
      const slot = dst[name];
      if (!src || src.itemSize !== slot.src.itemSize) return null;
      // A quantized position is decoded even where its matrix happens to be identity.
      if ((name === 'position' && (moved || slot.size !== src.itemSize))
        || (name === 'normal' && turned)) {
        for (let i = 0; i < count; i++) {
          // A boxed member (T-2700) reads each vertex through its own box first.
          if (name === 'position') boxedPositionAt(geo, i, p).applyMatrix4(rel);
          else p.fromBufferAttribute(src, i).applyMatrix3(nrm).normalize();
          slot.attr.setXYZ(slot.at / slot.size + i, p.x, p.y, p.z);
        }
      } else {
        slot.array.set(src.array.subarray(0, count * src.itemSize), slot.at);
      }
      slot.at += count * slot.size;
    }
    if (indexed) {
      const src = geo.index;
      for (let i = 0; i < src.count; i++) idx[idxAt + i] = src.getX(i) + base;
      idxAt += src.count;
    }
    base += count;
  }
  for (const name of names) {
    const slot = dst[name];
    out.setAttribute(name, slot.attr);
  }
  if (indexed) out.setIndex(new THREE.BufferAttribute(idx, 1));
  // Where the members keep their confidence when it is not a float stream
  // (T-2689, compact-streams.js): the colour's fourth lane, or one grade for the
  // whole geometry. Carried when every member agrees, so `confidenceOf` reads
  // the merged mesh as it read its members.
  for (const key of ['confidenceLane', 'confidence']) {
    const v = first.userData?.[key];
    if (v !== undefined && members.every((m) => m.geometry.userData?.[key] === v)) out.userData[key] = v;
  }
  out.computeBoundingSphere();
  out.computeBoundingBox();
  return out;
}

/**
 * @param {object} opts
 * @param {THREE.Object3D} opts.scene the scene the layer groups hang from
 * @param {THREE.Camera} opts.camera the visitor's camera
 * @param {string[]} opts.layers the group names eligible for merging
 */
export function createFarMerge({ scene, camera, layers, onGeometry = null }) {
  /** @type {Array<{group:THREE.Object3D, members:THREE.Mesh[], c:THREE.Vector3,
   *                r:number, mesh:THREE.Mesh|null, tris:number, refused:boolean}>} */
  let clusters = [];
  const frustum = new THREE.Frustum();
  const viewProj = new THREE.Matrix4();
  const census = { clusters: 0, merged: 0, callsSaved: 0, built: 0, builtTris: 0 };
  /**
   * HARNESS ONLY, and never a visitor setting. The saving has to be measured by
   * turning the merge off and reading the same frame twice — the pattern T-0150
   * established for the reach — because a figure taken from two different trees
   * can be satisfied by any unrelated layer getting cheaper, and because the
   * claim that the triangle count is UNCHANGED is only checkable that way.
   */
  let enabled = true;

  /** A conservative sphere over a set of member world spheres. */
  function enclose(members) {
    let minX = Infinity; let minY = Infinity; let minZ = Infinity;
    let maxX = -Infinity; let maxY = -Infinity; let maxZ = -Infinity;
    for (const m of members) {
      minX = Math.min(minX, m.c.x - m.r); maxX = Math.max(maxX, m.c.x + m.r);
      minY = Math.min(minY, m.c.y - m.r); maxY = Math.max(maxY, m.c.y + m.r);
      minZ = Math.min(minZ, m.c.z - m.r); maxZ = Math.max(maxZ, m.c.z + m.r);
    }
    const c = new THREE.Vector3((minX + maxX) / 2, (minY + maxY) / 2, (minZ + maxZ) / 2);
    let r = 0;
    for (const m of members) r = Math.max(r, c.distanceTo(m.c) + m.r);
    return { c, r };
  }

  /**
   * Re-read the layers and re-cluster. Called wherever the furniture's banked
   * spheres are re-read (`collectFurniture` in main.js), for the same reason:
   * a rebuilt layer has new meshes and disposed old ones, and a cluster holding
   * a disposed mesh would draw a buffer that is gone.
   *
   * @param {Array<{mesh:THREE.Mesh, c:THREE.Vector3, r:number}>} banked
   *   the world spheres main.js has already computed, so this walks nothing twice
   */
  function rebuild(banked) {
    dispose();
    const buckets = new Map();
    for (const entry of banked) {
      const mesh = entry.mesh;
      if (mesh.userData.farMerged) continue;
      const group = mesh.parent;
      if (!group || !layers.includes(group.name)) continue;
      const sig = signatureOf(mesh);
      if (!sig) continue;
      const cell = `${Math.floor(entry.c.x / CLUSTER_M)},${Math.floor(entry.c.z / CLUSTER_M)}`;
      const key = `${group.name}|${cell}|${sig}`;
      let b = buckets.get(key);
      if (!b) { b = { group, members: [] }; buckets.set(key, b); }
      b.members.push(entry);
    }
    for (const b of buckets.values()) {
      if (b.members.length < MIN_MEMBERS) continue;
      const { c, r } = enclose(b.members);
      clusters.push({
        group: b.group, members: b.members.map((m) => m.mesh),
        inputs: b.members.map(({ mesh }) => memberInput(mesh)),
        c, r, mesh: null, tris: 0, refused: false,
      });
    }
    census.clusters = clusters.length;
    census.merged = 0;
    census.callsSaved = 0;
  }

  /** Build a cluster's merged mesh the first frame it is actually wanted. */
  function ensure(cl) {
    if (cl.mesh || cl.refused) return cl.mesh;
    const geo = mergeGeometries(cl.members, cl.group);
    if (!geo) { cl.refused = true; return null; }
    const src = cl.members[0];
    const mesh = new THREE.Mesh(geo, src.material);
    mesh.name = `${cl.group.name}-far-merge`;
    mesh.visible = false;
    // Never a caster: members are either outside the original sun-distance
    // bound or already noncasting. The shadow pass keeps its original answer.
    mesh.castShadow = false;
    mesh.receiveShadow = src.receiveShadow;
    mesh.renderOrder = src.renderOrder;
    mesh.layers.mask = src.layers.mask;
    mesh.userData.farMerged = true;
    // The chunks answer clicks, and they still do — this must never intercept
    // one, whatever raycasts the scene.
    mesh.raycast = () => {};
    cl.group.add(mesh);
    cl.mesh = mesh;
    // A late-built copy joins the normal phone upload/release lifecycle too.
    // This marks callbacks only; it never retains source arrays or renders.
    onGeometry?.(cl.group);
    const pos = geo.attributes.position.count;
    cl.tris = Math.floor((geo.index ? geo.index.count : pos) / 3);
    census.built += 1;
    census.builtTris += cl.tris;
    return mesh;
  }

  /**
   * Per frame, after the caller restores each source chunk's reach visibility.
   * This ordering also applies when casting flags change: main.js does both
   * synchronously before its next render. This controller only hides chunks.
   * Each cluster checks its source descriptors, one sphere against six planes,
   * and its distance. Descriptor snapshots contain metadata, never source arrays.
   */
  function update() {
    if (!clusters.length) return;
    if (!enabled) {
      for (const cl of clusters) if (cl.mesh) cl.mesh.visible = false;
      census.merged = 0;
      census.callsSaved = 0;
      return;
    }
    camera.updateMatrixWorld();
    viewProj.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse);
    frustum.setFromProjectionMatrix(viewProj);
    const eye = camera.position;
    let merged = 0;
    let saved = 0;
    for (const cl of clusters) {
      // The banked bounds and cached copy describe exactly the captured inputs.
      // Any change fails open before either the near OR original far path runs.
      if (!cl.refused) for (let i = 0; i < cl.members.length; i++) {
        if (sameMemberInput(cl.members[i], cl.inputs[i])) continue;
        cl.refused = true;
        if (cl.mesh) {
          cl.mesh.visible = false;
          cl.group.remove(cl.mesh);
          cl.mesh.geometry.dispose();
          cl.mesh = null;
        }
        break;
      }
      const far = eye.distanceTo(cl.c) - cl.r > FAR_M;
      let want = !cl.refused && (far || nearNoncasting(cl.members));
      if (want) {
        for (const pl of frustum.planes) {
          if (pl.distanceToPoint(cl.c) < cl.r) { want = false; break; }
        }
      }
      // T-0150 composes ahead of this one: a cluster the reach is holding back,
      // even partly, keeps the reach's answer.
      if (want) {
        for (const m of cl.members) {
          if (m.visible !== true || m.userData.reachCulled) { want = false; break; }
        }
      }
      if (want && !ensure(cl)) want = false;
      if (cl.mesh) cl.mesh.visible = want;
      if (want) {
        for (const m of cl.members) m.visible = false;
        merged += 1;
        saved += cl.members.length - 1;
      }
    }
    census.merged = merged;
    census.callsSaved = saved;
  }

  function dispose() {
    for (const cl of clusters) {
      if (!cl.mesh) continue;
      cl.group.remove(cl.mesh);
      cl.mesh.geometry.dispose();
    }
    clusters = [];
    census.clusters = 0;
    census.merged = 0;
    census.callsSaved = 0;
  }

  return {
    rebuild,
    update,
    dispose,
    /** @param {boolean} on — harness only; see `enabled` above. */
    setEnabled(on) { enabled = !!on; update(); return enabled; },
    /** What the merge is doing at this instant — read off the clusters, never
     *  off the constants that asked for it. */
    get state() {
      return {
        clusterM: CLUSTER_M, farM: FAR_M, minMembers: MIN_MEMBERS,
        enabled,
        clusters: census.clusters, merged: census.merged,
        callsSaved: census.callsSaved,
        built: census.built, builtTris: census.builtTris,
        layers: layers.slice(),
      };
    },
    scene,
  };
}
