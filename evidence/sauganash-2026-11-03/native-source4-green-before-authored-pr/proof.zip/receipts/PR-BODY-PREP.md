Andreas's 1884 Sauganash engraving now opens as a credited held image on the hotel's Images tab. The existing three rows become one held engraving and two source links. The visitor record explains the retrospective source and its limited relevance to July 1835.

A current hotel-specific, two-building comparison records `DIFFERS`: the roof/rear wing and left-gable presentation remain open. Camera uncertainty is within tolerance. Geometry, phases, placement, confidence and paint values are unchanged. **T-2383 remains partial and open.**

The link-only Photos test uses the hotel's remaining Trowbridge/Gale 1902 source and retains its title, caption, creator, publication holder, year and archive URL assertions. Its Green Tree and unresolved Beaubien cases are unchanged.

Validation is PENDING completion of all four native source parts, committed-head publication and contract, actual hotel Images/Record/Reader/body review on desktop and phone, official Stage 3 checks on both viewports, and the required hosted gate. Source parts 1 and 2 currently pass; focused scene, source-use, pictures, grade, image bindings and full data validation also passed. The structure record changes only `research_note`; the conservative all-15 smoke estimate is retained, and final runtime results will state the relevant scope explicitly.

[Native comparison and direct review](https://github.com/kevinrhaas/chicago-evidence/blob/9b32b26903431ce4fcfb083f47e18147b759d956/evidence/sauganash-2026-11-03/current-andreas-native-private-root-reviewed/RECOVERY.md) · [Checkpoint and preserved initial source-check failure/repair](https://github.com/kevinrhaas/chicago-evidence/blob/1e743fbca394f4574d18f2f72b493df489c074af/evidence/sauganash-2026-11-03/native-fixture-repair-and-coherent11/RECOVERY.md).
