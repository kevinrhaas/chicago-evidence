from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
O=Path(__file__).parent;R=Path('/workspace/chicago-bridge-increment-20261102');A=R/'chicago/4d';P=O/'private';B=P/'chicago/4d'
assert not P.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
def fingerprint(p):return {'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
native=[A/'tools'/n for n in ['photo_match.mjs','photo_match_group.mjs','photo_match_enclosures.mjs','photo_match_flora.mjs']]+[A/'renderers/web/js/keith-stone.js']+[p for p in (A/'renderers/web/vendor/three-0.185.1').rglob('*')if p.is_file()]
assert len(native)==20
camera=A/'data/reference_views/sauganash_hotel/andreas-1884.json';cam=json.loads(camera.read_bytes());assert sha(camera.read_bytes())=='276f2051fa8db6379236b5d642a6ca75c740f4e82ebf44819c72808917d55991'
photo=(camera.parent/cam['photo']).resolve()
files=set(native+[camera,photo,A/'data/scenes/1835.json',A/'data/sources/andreas_1884_sauganash_hotel_plate.json',A/'assets/LICENSES.md'])
for sid in ['sauganash_hotel','philo_carpenter_log_shop']:
 p=A/f'data/sidecars/1835/{sid}.json';d=json.loads(p.read_bytes());files.update([p,A/'assets'/d['asset']])
source={str(p):fingerprint(p)for p in sorted(files)}
for p in files:
 q=P/p.relative_to(R);q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
(B/'node_modules').symlink_to('/workspace/shared/node/node_modules',target_is_directory=True)
runtime=[Path('/workspace/shared/node/node_modules/playwright/package.json'),Path('/workspace/shared/node/node_modules/playwright-core/package.json'),Path('/workspace/shared/node/node_modules/playwright-core/browsers.json'),Path('/workspace/shared/playwright-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell')]
runtime_hashes={str(p):fingerprint(p)for p in runtime}
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PLAYWRIGHT_DISABLE_FORCED_CHROMIUM_PROXIED_LOOPBACK='1')
def metadata():
 result={}
 for args in [('rev-parse','HEAD'),('rev-parse','HEAD^{tree}'),('ls-files','--stage','-z'),('for-each-ref','--format=%(refname) %(objectname)'),('config','--local','--list','--null')]:result[' '.join(args)]=sha(subprocess.check_output(['git','-C',str(R),*args],env=env))
 for n in ['index','HEAD','objects/info/alternates']:
  p=R/'.git'/n;result[n]=fingerprint(p)
 return result
before_meta=metadata()
def guard():
 assert {str(p):fingerprint(p)for p in files}==source
 assert all(fingerprint(P/p.relative_to(R))==source[str(p)]for p in files)
 assert {str(p):fingerprint(p)for p in runtime}==runtime_hashes
 assert metadata()==before_meta
 assert shutil.disk_usage('/workspace').free>=536870912 and shutil.disk_usage('/tmp').free>=1800000000
guard()
plan={'status':'PRIVATE_NATIVE_RENDER_READY','source_head':'dacc6364b6e6dce484d197627abbea5244218a0c','native20_count':len(native),'source_inputs':source,'runtime_inputs':runtime_hashes,'source_metadata':before_meta,'new_camera_sha256':source[str(camera)]['sha256'],'original_shop_match_not_inherited':True,'no_model_or_source_picture_changes':True,'no_historical_camera_fit_claim':True,'photo':str(photo),'private_root':str(B),'expected_group_sha256':'67b94e08aed0d1c4abc5ae57789a467c66c6958b1b81bffd7e7e6e0c5f15ee85','analytic_projection_qualification':'/tmp/remaining-originals-next-20261103/SAUGANASH-REANCHOR-QUALIFICATION.json'}
(O/'PRIVATE-NATIVE-PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
command=['python','/workspace/shared/run-with-reaping.py',str(O/'PRIVATE-NATIVE-REAPER.json'),'--','timeout','--signal=TERM','--kill-after=15s','90s','nice','-n','19','taskset','-c','2','node','tools/photo_match.mjs','data/reference_views/sauganash_hotel/andreas-1884.json','--out','docs/RESEARCH/photo-match/sauganash_hotel']
started=time.monotonic()
with (O/'PRIVATE-NATIVE.log').open('xb')as log:r=subprocess.run(command,cwd=B,env=env,stdout=log,stderr=subprocess.STDOUT)
reaper=json.loads((O/'PRIVATE-NATIVE-REAPER.json').read_bytes());guard()
assert r.returncode==reaper['command_exit']==0 and reaper['all_children_reaped'] and not reaper['leftover_cleanup'] and reaper['interrupted_signal']is None,(r.returncode,reaper)
p=B/'docs/RESEARCH/photo-match/sauganash_hotel/andreas-1884.match.json';match=json.loads(p.read_bytes());assert match['verdict']=='unreviewed' and match['camera_sha256']==plan['new_camera_sha256'] and match['group_sha256']==plan['expected_group_sha256']
assert match['glb_sha256']=='a369598aafec6a868b0ec3e04ba591a821e4518174a1e75ac2bdba790ffbe5ec'
image=B/match['side_by_side'];assert image.exists()
result={'status':'ACTUAL_PRIVATE_NATIVE_CLOSED_UNREVIEWED','seconds':time.monotonic()-started,'native20_and_all_frame_model_source_camera_runtime_metadata_guards_exact':True,'native_exit':r.returncode,'reaper':reaper,'raw_match':str(p),'image':str(image),'image_sha256':sha(image.read_bytes()),'camera_sha256':match['camera_sha256'],'photo_sha256':match['photo_sha256'],'master_sha256':match['glb_sha256'],'group_sha256':match['group_sha256'],'root_direct_review_pending':True,'GPU_returned':True}
(O/'PRIVATE-NATIVE-CLOSURE.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
