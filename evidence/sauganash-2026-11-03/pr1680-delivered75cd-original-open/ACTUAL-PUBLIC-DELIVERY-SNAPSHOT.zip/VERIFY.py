"""Verify actual dev delivery after PR1680 merges; no browser/smoke claim."""
import argparse, hashlib, json, subprocess, time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
P=Path(__file__).resolve().parent
ROOT=Path('/workspace/chicago-bridge-increment-20261102')
Q=Path('/tmp/sauganash-final-qa-split-20261103')
HEAD='27ab2f3b6dc38547e2668ced16191c30c0e8ca48'
BASE='https://chicago.polecat.live/4d/dev/'
SID='sauganash_hotel'
PICTURES='data/pictures/1835.json'
SIDECAR='data/sidecars/1835/sauganash_hotel.json'
READER='data/reader/structures_1835.json'
MODULE='walk/js/reader-text.js'
MODEL='data/gltf/sauganash_hotel__frame_1831.glb'
MODEL_SHA='5f7d8a54f1c805d53bdb558506dc18ce237c9c0fb180a7cd274dec7d64ad480e'
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+path],timeout=45))
def get(path):
 request=Request(BASE+path+'?pr1680verify='+str(time.time_ns()),headers={'Cache-Control':'no-cache','User-Agent':'Chicago-Sauganash-dev-delivery-verification'})
 with urlopen(request,timeout=45)as response:
  assert response.status==200;data=response.read(10000001)
 assert len(data)<=10000000;return data
def copy_reader(sidecar,overlay):
 code="import fs from'node:fs';import{pathToFileURL}from'node:url';const{readerCopy}=await import(pathToFileURL(process.argv[1]));const p=JSON.parse(fs.readFileSync(0,'utf8'));console.log(JSON.stringify(readerCopy(p.sidecar,p.overlay).research_note));"
 return json.loads(subprocess.check_output(['node','--input-type=module','-e',code,str(ROOT/'site/4d'/MODULE)],input=json.dumps({'sidecar':sidecar,'overlay':overlay}).encode(),timeout=45))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true');args=ap.parse_args();assert args.run,'Prepared only; execute after actual merge and native/root QA acceptance'
 accepted=json.loads((Q/'PLAN.json').read_bytes());assert accepted['expected_head']==HEAD
 closure=json.loads((Q/'FINAL-CLOSURE.json').read_bytes());assert closure['status']=='FINAL_SAUGANASH_SPLIT_CUSTOM_NATIVE3_BOTH_CLOSED_PASS'and closure['head']==HEAD
 pr=api('pulls/1680');assert pr['head']['sha']==HEAD
 if not pr['merged']:print('NOT_MERGED_YET');return 20
 merge=pr['merge_commit_sha'];stamp=get('build.json');paths=[PICTURES,SIDECAR,READER,MODULE,MODEL]
 with ThreadPoolExecutor(max_workers=4)as pool:payloads=dict(zip(paths,pool.map(get,paths)))
 assert stamp==get('build.json'),'Public build changed during snapshot; repeat a fresh bounded snapshot'
 build=json.loads(stamp);assert build['tier']=='dev'and build['ref']=='refs/heads/dev'
 comparison=api('compare/'+merge+'...'+build['sha'])
 if comparison['behind_by']or comparison['status']not in['ahead','identical']:print('MERGED_NOT_DEPLOYED_YET',merge,build['sha']);return 21
 rows=json.loads(payloads[PICTURES])['by_structure'][SID];assert rows==accepted['saug_picture_rows']and len(rows)==3
 assert sum(bool(x.get('held'))for x in rows)==1 and all(not x.get('spot')for x in rows)
 held=next(x for x in rows if x.get('held'));assert held['id']=='early-andreas-1884-sauganash'and held['rights']=='public domain'
 assert'1884'in held['date']and'Andreas'in held['creator']and'Andreas'in held['holder']
 sidecar=json.loads(payloads[SIDECAR]);assert sidecar['id']==SID and sidecar['phase']=='frame_1831'and sidecar['target_date']=='1835-07-01'and sidecar['grade']['value']=='attested'
 assert hashlib.sha256(payloads[MODEL]).hexdigest()==MODEL_SHA
 assert hashlib.sha256(payloads[MODULE]).hexdigest()==accepted['input_bindings'][str(ROOT/'site/4d'/MODULE)]['sha256']
 note=copy_reader(sidecar,json.loads(payloads[READER]));assert note==accepted['expected_research_note']
 payloads={'build.json':stamp,**payloads};out=P/('after-'+build['sha']);assert not out.exists();out.mkdir()
 for path,data in payloads.items():
  target=out/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 result={'status':'MERGED_AND_PUBLIC_DEV_STATIC_DELIVERY_VERIFIED','at':datetime.now(timezone.utc).isoformat(),'pr':1680,'reviewed_head':HEAD,'merge_commit':merge,'deployed_build':build,'deployed_descends_from_merge':True,'images':3,'held':1,'links':2,'all_gallery_rows_exact_accepted_native':True,'grade':sidecar['grade'],'native_reader_exact_accepted27':True,'web_sha256':MODEL_SHA,'native_reader_note_sha256':hashlib.sha256(note.encode()).hexdigest(),'files':{path:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}for path,data in payloads.items()},'scope':'HTTP ancestry and exact static gallery/Reader/model delivery only. No new browser/fullsizeviewer/full15/original image-match completion claim.'}
 data=json.dumps(result,indent=2)+'\n';(out/'RESULT.json').write_text(data);(P/'RESULT.json').write_text(data);print(json.dumps({'status':result['status'],'merge':merge,'build':build['sha']}));return 0
if __name__=='__main__':raise SystemExit(main())
