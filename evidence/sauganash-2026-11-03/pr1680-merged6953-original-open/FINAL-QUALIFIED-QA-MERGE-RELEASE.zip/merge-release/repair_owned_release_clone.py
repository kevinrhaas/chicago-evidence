"""Finite authenticated repair of only our unpushed ticket-release clone."""
from pathlib import Path
import base64,datetime,hashlib,json,os,subprocess
O=Path('/tmp/sauganash-merge-27-20261103/TICKET-RELEASE-REPAIR');O.mkdir(exist_ok=True)
T=Path('/tmp/lake-house-source-20261103/chicago/4d/tickets');E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(*args,input=None):
 r=subprocess.run(['/usr/local/bin/git','-c','protocol.allow=never','-C',str(T),*args],input=input,env=E,capture_output=True);assert r.returncode==0,(args,r.stderr.decode(errors='replace')[:1500]);return r.stdout
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago-tickets/'+path],timeout=45))
old='30635782553ce162e307a792549b53c9b99d048d';assert git('rev-parse','HEAD').decode().strip()==old;assert not git('status','--porcelain','--untracked-files=normal')
assert git('log','-1','--format=%s').decode().startswith('T-2383: release')
parent=git('rev-parse','HEAD^').decode().strip();paths=git('diff','--name-only',parent,old).decode().splitlines();assert 1<=len(paths)<=2 and any('/T-2383-'in x for x in paths) and all(x=='QUEUE.md'or'/T-2383-'in x for x in paths)
(O/'UNPUSHED-RELEASE-COMMIT.raw').write_bytes(git('cat-file','commit',old));(O/'UNPUSHED-RELEASE-DIFF.patch').write_bytes(git('diff','--binary',parent,old));(O/'BEFORE-REFS.txt').write_bytes(git('for-each-ref','--format=%(refname) %(objectname)'));git('update-ref','refs/recovery/sauganash-unsaved-release-20261104',old)
tip=api('git/ref/heads/main')['object']['sha'];commit=api('git/commits/'+tip);tree=api('git/trees/'+commit['tree']['sha']+'?recursive=1');assert not tree['truncated'];(O/'VERIFIED-REMOTE-TIP.json').write_text(json.dumps({'tip':tip,'commit':commit},indent=2)+'\n')
blobs={r['sha']:r for r in tree['tree']if r['type']=='blob'};lines=git('cat-file','--batch-check',input=('\n'.join(blobs)+'\n').encode()).decode().splitlines();missing=[r.split()[0]for r in lines if r.endswith(' missing')];assert len(missing)<100 and sum(blobs[k]['size']for k in missing)<16*1024**2
imports=[]
for oid in missing:
 d=api('git/blobs/'+oid);b=base64.b64decode(d['content']);assert len(b)==blobs[oid]['size'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;assert git('hash-object','-w','--stdin',input=b).decode().strip()==oid;imports.append({'path':blobs[oid]['path'],'oid':oid,'bytes':len(b)})
trees={'':commit['tree']['sha']};trees.update({r['path']:r['sha']for r in tree['tree']if r['type']=='tree'})
for directory,oid in sorted(trees.items(),key=lambda pair:pair[0].count('/'),reverse=True):
 if subprocess.run(['/usr/local/bin/git','-C',str(T),'cat-file','-e',oid],env=E,capture_output=True).returncode==0:continue
 prefix=directory+'/'if directory else'';entries=[]
 for row in tree['tree']:
  if row['path'].startswith(prefix)and'/'not in row['path'][len(prefix):]:entries.append(f"{row['mode']} {row['type']} {row['sha']}\t{row['path'][len(prefix):]}")
 assert git('mktree','--missing',input=('\n'.join(entries)+'\n').encode()).decode().strip()==oid
if subprocess.run(['/usr/local/bin/git','-C',str(T),'cat-file','-e',tip],env=E,capture_output=True).returncode:
 v=commit['verification'];payload=v.get('payload')
 if payload:
  raw=payload.encode()
  if v.get('signature'):
   headers,message=raw.split(b'\n\n',1);raw=headers+b'\ngpgsig '+v['signature'].encode().rstrip(b'\n').replace(b'\n',b'\n ')+b'\n\n'+message
 else:
  def identity(d):
   timestamp=int(datetime.datetime.fromisoformat(d['date'].replace('Z','+00:00')).timestamp());return f"{d['name']} <{d['email']}> {timestamp} +0000"
  raw=('tree '+commit['tree']['sha']+'\n'+''.join('parent '+p['sha']+'\n'for p in commit['parents'])+'author '+identity(commit['author'])+'\ncommitter '+identity(commit['committer'])+'\n\n'+commit['message'].rstrip('\n')+'\n').encode()
 assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==tip,'Refuse unverified reconstructed commit'
 assert git('hash-object','-w','-t','commit','--stdin',input=raw).decode().strip()==tip
git('reset','--hard',tip);assert git('rev-parse','HEAD').decode().strip()==tip;assert not git('status','--porcelain','--untracked-files=normal')
git('update-ref','refs/remotes/origin/main',tip)
d={'status':'OWN_UNPUSHED_RELEASE_PRESERVED_AND_CLONE_RESTORED_TO_AUTHENTICATED_REMOTE','unpublished_release':old,'recovery_ref':'refs/recovery/sauganash-unsaved-release-20261104','restored_snapshot':tip,'missing_tip_blobs_imported':imports,'no_remote_push_reset_force_or_source_change':True};(O/'REPAIR-CLOSED.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
