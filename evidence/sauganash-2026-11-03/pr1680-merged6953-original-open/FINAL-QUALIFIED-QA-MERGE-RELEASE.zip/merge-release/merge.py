"""Ordinary exact-head merge only after actual split QA, root reviews and hosted gate."""
from pathlib import Path
import argparse, hashlib, json, subprocess, time
P=Path(__file__).resolve().parent
Q=Path('/tmp/sauganash-final-qa-split-20261103')
V=Path('/workspace/sauganash-final-27-root-review-20261103')
HEAD='27ab2f3b6dc38547e2668ced16191c30c0e8ca48'
RUN=41738483593
def api(path,body=None,method=None):
 cmd=['gh','api','repos/kevinrhaas/chicago/'+path]
 if body is not None:cmd+=['--method',method or'POST','--input','-']
 result=subprocess.run(cmd,input=None if body is None else json.dumps(body).encode(),capture_output=True,timeout=60)
 if result.returncode:raise RuntimeError((path,result.stderr.decode()[:2000]))
 return json.loads(result.stdout)
def dump(name,obj):(P/name).write_text(json.dumps(obj,indent=2)+'\n')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true');ap.add_argument('--qualified-dev',default='42b9c601d51d8a93cde2706e1773f0bd00fadfbe');ap.add_argument('--expected-tree',default='d719d0d702da0d5cbadf5ba1d49c0619143d10f0');args=ap.parse_args();assert args.run,'Prepared only; execute after all actual release obligations and normal readiness'
 c=json.loads((Q/'FINAL-CLOSURE.json').read_text());assert c['status']=='FINAL_SAUGANASH_SPLIT_CUSTOM_NATIVE3_BOTH_CLOSED_PASS'and c['head']==HEAD and c['source_Git_publication_helpers_plan_exact']and c['all_owned_process_groups_reaped']
 assert {(x['viewport'],x['leg'])for x in c['custom_viewports']}=={(v,l)for v in ['desktop','mobile']for l in ['cards','body']}and len(c['custom_viewports'])==4
 assert {x['viewport']for x in c['native_viewports']}=={'desktop','mobile'}and len(c['native_viewports'])==2
 for x in c['native_viewports']:assert x['passed']==107 and x['failed']==0
 for x in c['custom_viewports']+c['native_viewports']:assert x['reaper']['command_exit']==0 and x['reaper']['all_children_reaped']and not x['reaper']['leftover_cleanup']and x['reaper']['interrupted_signal']is None
 outer=json.loads((Q/'OUTER-REAPER.json').read_text());assert outer['command_exit']==0 and outer['all_children_reaped']and not outer['leftover_cleanup']
 reviews={}
 for viewport in ['DESKTOP','MOBILE']:
  for leg in ['CARDS','BODY']:
   name='ROOT-'+viewport+'-'+leg+'-REVIEW.json';r=json.loads((V/name).read_text());assert r['status']==viewport+'_'+leg+'_DIRECT_REVIEW_ACCEPTED'and r['head']==HEAD
   for s in r['screenshots'].values():assert hashlib.sha256(Path(s['path']).read_bytes()).hexdigest()==s['sha256']
   reviews[name]=r
 dump('ROOT-REVIEWS-VERIFIED.json',reviews)
 gate=api('actions/runs/'+str(RUN));assert gate['head_sha']==HEAD and gate['status']=='completed'and gate['conclusion']=='success';dump('HOSTED-GATE-BEFORE-MERGE.json',gate)
 pr=api('pulls/1680');assert pr['head']['sha']==HEAD and pr['base']['ref']=='dev';dump('PR-BEFORE-MERGE.json',pr)
 if pr['merged']:
  dump('ALREADY-MERGED.json',pr);print('ALREADY_MERGED',pr['merge_commit_sha']);return 0
 assert pr['state']=='open'and not pr['draft'];assert not any(x['name']=='hold'for x in pr['labels'])
 dev=api('git/ref/heads/dev?fresh='+str(time.time_ns()))['object']['sha'];dump('DEV-BEFORE-MERGE.json',{'head':dev,'qualified':args.qualified_dev,'expected_merge_tree':args.expected_tree});assert dev==args.qualified_dev,('New dev needs actual qualification before merge',dev,args.qualified_dev)
 request={'sha':HEAD,'merge_method':'squash','commit_title':pr['title']+' (#1680)','commit_message':"Hold Andreas's credited retrospective Sauganash engraving and record the actual hotel comparison with remaining roof and gable differences explicit. Source4, current integration owners, whole1139 hosted gate and actual bounded desktop/phone plus native107both checks passed. Preserve existing geometry and keep originalT2383 partial."}
 dump('NORMAL-MERGE-REQUEST.json',request);response=api('pulls/1680/merge',request,'PUT');dump('NORMAL-MERGE-RESPONSE.json',response);assert response.get('merged')is True,response
 pr=api('pulls/1680');dump('MERGED-READBACK.json',pr);assert pr['merged']and pr['head']['sha']==HEAD
 commit=api('git/commits/'+pr['merge_commit_sha']);dump('ACTUAL-MERGE-COMMIT.json',commit);assert commit['parents'][0]['sha']==args.qualified_dev and commit['tree']['sha']==args.expected_tree,('Actual merge differs from qualified native tree/base',commit)
 summary={'status':'ORDINARY_EXACT_HEAD_DEV_MERGE_VERIFIED','pr':1680,'head':HEAD,'merge':pr['merge_commit_sha'],'merged_at':pr['merged_at'],'actual_parent':commit['parents'][0]['sha'],'actual_tree':commit['tree']['sha'],'normal_sha_checked_squash':True,'no_admin_or_forced_ref_update':True,'required_hosted_gate':RUN,'original_T2383':'PARTIAL_RELEASE_PENDING_NOT_DONE','public_delivery':'PENDING'};dump('MERGE-CLOSED.json',summary);print(json.dumps(summary));return 0
if __name__=='__main__':raise SystemExit(main())
