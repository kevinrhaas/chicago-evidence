"""Recover only the owned ticket clone after a test inherited its directory override."""
from pathlib import Path
import base64,datetime,hashlib,json,os,subprocess
O=Path(__file__).parent/'TICKET-FIXTURE-AUDIT';O.mkdir(exist_ok=True)
T=Path('/tmp/lake-house-source-20261103/chicago/4d/tickets');E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
base='2c0b8c4a6908d90e6a0d0480524fdf43dd7aa1b1';bad='1db76697f0f277193c0b44d7df0cba62551d9c4a';pregate_remote='4aaa41101d4982cbeee83ab66ea9c34da4d32c6c'
def git(*args,input=None):
 r=subprocess.run(['/usr/local/bin/git','-c','protocol.allow=never','-C',str(T),*args],input=input,env=E,capture_output=True);assert r.returncode==0,(args,r.stderr.decode(errors='replace')[:1000]);return r.stdout
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago-tickets/'+path]))
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not(O/'RECOVERY-CLOSED.json').exists();assert git('rev-parse','HEAD').decode().strip()==bad;assert not git('status','--porcelain','--untracked-files=normal');assert git('rev-parse','HEAD^').decode().strip()==base
paths=git('diff','--name-only',base,bad).decode().splitlines();assert len(paths)==2 and 'QUEUE.md'in paths;ticket=next(p for p in paths if p!='QUEUE.md');assert ticket.startswith('T-0000-0249/T-0002-')
assert git('log','-1','--format=%s').decode().strip()=='T-0002: block'
for n in ['HEAD','index','config','packed-refs']:
 p=T/'.git'/n
 if p.exists():(O/('BEFORE-'+n)).write_bytes(p.read_bytes())
(O/'LOCAL-TEST-COMMIT.raw').write_bytes(git('cat-file','commit',bad));(O/'LOCAL-TEST-DIFF.patch').write_bytes(git('diff','--binary',base,bad));(O/'BEFORE-REFS.txt').write_bytes(git('for-each-ref','--format=%(refname) %(objectname)'))
git('update-ref','refs/recovery/sauganash-p1-local-test-20261103',bad)
tip=api('git/ref/heads/main')['object']['sha'];comparison=api('compare/'+pregate_remote+'...'+tip);assert not any(p['filename'].startswith('T-0000-0249/')for p in comparison.get('files',[])),comparison.get('files')
remote_ticket=api('contents/'+ticket+'?ref='+tip);assert remote_ticket['sha']==git('rev-parse',base+':'+ticket).decode().strip()
commit=api('git/commits/'+tip);tree=api('git/trees/'+commit['tree']['sha']+'?recursive=1');assert not tree['truncated'];(O/'REMOTE-AUDIT.json').write_text(json.dumps({'tip':tip,'pre_gate_remote':pregate_remote,'comparison':comparison,'T0002_remote_blob':remote_ticket['sha'],'T0002_remote_exact_pre_gate':True,'tip_commit':commit},indent=2)+'\n')
blobs={r['sha']:r for r in tree['tree']if r['type']=='blob'};lines=git('cat-file','--batch-check',input=('\n'.join(blobs)+'\n').encode()).decode().splitlines();missing=[r.split()[0]for r in lines if r.endswith(' missing')];assert len(missing)<100 and sum(blobs[k]['size']for k in missing)<16*1024**2
imports=[]
for oid in missing:
 d=api('git/blobs/'+oid);b=base64.b64decode(d['content']);assert len(b)==blobs[oid]['size'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;assert git('hash-object','-w','--stdin',input=b).decode().strip()==oid;imports.append({'path':blobs[oid]['path'],'oid':oid,'bytes':len(b)})
trees={'':commit['tree']['sha']};trees.update({r['path']:r['sha']for r in tree['tree']if r['type']=='tree'})
for directory,oid in sorted(trees.items(),key=lambda pair:pair[0].count('/'),reverse=True):
 if subprocess.run(['/usr/local/bin/git','-C',str(T),'cat-file','-e',oid],env=E,capture_output=True).returncode==0:continue
 prefix=directory+'/'if directory else'';entries=[]
 for row in tree['tree']:
  if row['path'].startswith(prefix)and'/'not in row['path'][len(prefix):]:entries.append(f"{row['mode']} {row['type']} {row['sha']}\t{row['path'][len(prefix):]}")
 assert git('mktree','--missing',input=('\n'.join(entries)+'\n').encode()).decode().strip()==oid
if subprocess.run(['/usr/local/bin/git','-C',str(T),'cat-file','-e',tip],env=E,capture_output=True).returncode:
 v=commit['verification'];payload=v.get('payload')
 if payload:
  raw=payload.encode()
  if v.get('signature'):
   headers,message=raw.split(b'\n\n',1);raw=headers+b'\ngpgsig '+v['signature'].encode().rstrip(b'\n').replace(b'\n',b'\n ')+b'\n\n'+message
 else:
  def identity(d):
   timestamp=int(datetime.datetime.fromisoformat(d['date'].replace('Z','+00:00')).timestamp());return f"{d['name']} <{d['email']}> {timestamp} +0000"
  raw=('tree '+commit['tree']['sha']+'\n'+''.join('parent '+p['sha']+'\n'for p in commit['parents'])+'author '+identity(commit['author'])+'\ncommitter '+identity(commit['committer'])+'\n\n'+commit['message'].rstrip('\n')+'\n').encode()
 assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==tip,'Refuse unverified reconstructed commit'
 assert git('hash-object','-w','-t','commit','--stdin',input=raw).decode().strip()==tip
git('reset','--hard',tip);assert git('rev-parse','HEAD').decode().strip()==tip;assert not git('status','--porcelain','--untracked-files=normal');assert git('rev-parse','HEAD:'+ticket).decode().strip()==remote_ticket['sha']
d={'status':'OWN_LOCAL_TEST_COMMIT_PRESERVED_AND_CLONE_RESTORED_TO_VERIFIED_REMOTE_SNAPSHOT','bad_local_commit':bad,'pre_gate_local':base,'restored_snapshot':tip,'only_local_test_paths':paths,'no_remote_test_changes':True,'remote_T0002_exact_pre_gate':True,'missing_tip_blobs_imported':imports,'no_remote_push_reset_force_or_source_change':True,'recovery_ref':'refs/recovery/sauganash-p1-local-test-20261103','reason':'Whole-gate CHICAGO_TICKETS_DIR leaked into private ticket fixtures; unset for every future whole source part'};(O/'RECOVERY-CLOSED.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'status':d['status'],'snapshot':tip,'imported_blobs':len(imports),'remote_writes':False}),flush=True)
