"""One bounded foreground source-gate part; source and staged bodies stay frozen."""
from pathlib import Path
import argparse,hashlib,json,os,re,shutil,subprocess,time
ap=argparse.ArgumentParser();ap.add_argument('part',type=int,choices=range(1,5));ap.add_argument('--label');args=ap.parse_args()
R=Path('/workspace/chicago-bridge-increment-20261102');A=R/'chicago/4d';O=Path(__file__).parent;part=args.part
frozen=json.loads((O/'FROZEN11.json').read_bytes());label=args.label or f'PART{part}';receipt=O/(label+'-REAPER.json');log=O/(label+'.log');result=O/(label+'-RESULT.json')
E=os.environ.copy()
for key in ['GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','CHICAGO_TICKETS_DIR']:
 E.pop(key,None)
E.update(CHECK_JOBS='4',C4D_GATE_REQUIRE_READERS='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PATH=str(O/'fixture-local-git-bin')+':'+E['PATH'])
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['/usr/local/bin/git','-C',str(R),*args],env=E)
def guard():
 assert git('rev-parse','HEAD').decode().strip()==frozen['head']
 assert not git('diff','--name-only'),'Unexpected unstaged source change'
 assert set(git('diff','HEAD','--name-only').decode().splitlines())==set(frozen['members'])
 for path,row in frozen['members'].items():
  assert sha((R/path).read_bytes())==row['sha256'],path
  assert git('ls-files','--stage','--',path).decode().startswith(row['mode']+' '+row['oid']+' 0\t'),path
 assert sha((O/'fixture-local-git-bin/git').read_bytes())==frozen['fixture_adapter_sha256']
 free={p:shutil.disk_usage(p).free for p in ['/workspace','/tmp']};assert free['/workspace']>=536870912 and free['/tmp']>=1800000000,free
 return free
assert not receipt.exists()and not log.exists()and not result.exists()
before=guard();start=time.monotonic()
cmd=['setsid','--fork','--wait','python','/workspace/shared/run-with-reaping.py',str(receipt),'--','timeout','--signal=TERM','--kill-after=15s','600s','taskset','-c','0,1,3,4','./tools/check.sh','--part',f'{part}/4']
with log.open('xb')as f:run=subprocess.run(cmd,cwd=A,env=E,stdout=f,stderr=subprocess.STDOUT)
closed=json.loads(receipt.read_bytes());text=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',log.read_text(errors='replace'))
passed=run.returncode==closed['command_exit']==0 and closed['all_children_reaped']and not closed['leftover_cleanup']and closed['interrupted_signal']is None and bool(re.search(r'CHECK PASS\s*[—-]\s*part\s+'+str(part)+r'/4\b',text))
try:after=guard();exact=True;error=None
except BaseException as e:after={p:shutil.disk_usage(p).free for p in ['/workspace','/tmp']};exact=False;error=repr(e)
d={'status':'NATIVE_SOURCE_PART_PASS'if passed and exact else'NOT_QUALIFIED','part':part,'head':frozen['head'],'seconds':time.monotonic()-start,'native_exit':run.returncode,'source11_and_staged_postimages_exact':exact,'whole_gate_ticket_directory_override_unset':True,'fixture_exception':'ONLY verified private local file:// repo-file fixture; every real repository remains NoLazy1','reaper':closed,'before_free':before,'after_free':after,'last_lines':text.splitlines()[-10:],'log_sha256':sha(log.read_bytes()),'error':error};result.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'part':part,'status':d['status'],'seconds':d['seconds']}),flush=True)
raise SystemExit(0 if d['status']=='NATIVE_SOURCE_PART_PASS' else 1)
