"""Commit only the exact eleven Sauganash paths after all four source parts pass."""
from pathlib import Path
import hashlib,json,os,subprocess,time
P=Path(__file__).parent;R=Path('/workspace/chicago-bridge-increment-20261102');A=R/'chicago/4d'
E=os.environ.copy()
for k in ['GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','CHICAGO_TICKETS_DIR']:E.pop(k,None)
E.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
frozen=json.loads((P/'FROZEN11.json').read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['/usr/local/bin/git','-C',str(R),*args],env=E)
assert not(P/'AUTHORED-COMMIT.json').exists()
parts=[]
for part in range(1,5):
 label='PART1-LINK-FIXTURE-ENV-RETRY' if part==1 else f'PART{part}';row=json.loads((P/(label+'-RESULT.json')).read_bytes());assert row['status']=='NATIVE_SOURCE_PART_PASS'and row['source11_and_staged_postimages_exact'];rr=row['reaper'];assert rr['command_exit']==0 and rr['all_children_reaped']and not rr['leftover_cleanup']and rr['interrupted_signal']is None;parts.append(row)
assert git('rev-parse','HEAD').decode().strip()==frozen['head'];assert not git('diff','--name-only');paths=sorted(frozen['members']);assert sorted(git('diff','--cached','--name-only').decode().splitlines())==paths
for path,row in frozen['members'].items():
 assert sha((R/path).read_bytes())==row['sha256'];assert git('ls-files','--stage','--',path).decode().startswith(row['mode']+' '+row['oid']+' 0\t')
message="T-2383: Hold Andreas's Sauganash engraving and record its current differences"
with(P/'authored-native-commit.log').open('xb')as out:
 c=subprocess.run(['setsid','--fork','--wait','python','/workspace/shared/run-with-reaping.py',str(P/'AUTHORED-COMMIT-REAPER.json'),'--','timeout','--signal=TERM','--kill-after=15s','600s','git','commit','-m',message],cwd=R,env=E,stdout=out,stderr=subprocess.STDOUT)
rr=json.loads((P/'AUTHORED-COMMIT-REAPER.json').read_bytes());assert c.returncode==rr['command_exit']==0 and rr['all_children_reaped']and not rr['leftover_cleanup']
h=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip();assert git('rev-parse','HEAD^').decode().strip()==frozen['head'];assert sorted(git('diff-tree','--no-commit-id','--name-only','-r',h).decode().splitlines())==paths;assert not git('status','--porcelain','--untracked-files=normal')
d={'head':h,'tree':tree,'parent':frozen['head'],'branch':git('branch','--show-current').decode().strip(),'paths':paths,'all_eleven_staged_source_bodies_exact':True,'all_four_native_source_parts_passed_before_commit':True,'source_part_seconds':[x['seconds']for x in parts],'original_T2383':'PARTIAL_CLAIMED_NO_DONE','models_phases_placement_unchanged':True,'commit_reaper':rr};(P/'AUTHORED-COMMIT.json').write_text(json.dumps(d,indent=2)+'\n')
for label,command in [('actual-head-PR-changelog',['node','tools/check-changelog-entry.mjs',frozen['head'],h]),('actual-head-PR-ids',['node','tools/resolve_id_collisions.mjs','--check','--base',frozen['head']])]:
 t=time.monotonic()
 with(P/(label+'.log')).open('xb')as out:c=subprocess.run(['setsid','--fork','--wait','python','/workspace/shared/run-with-reaping.py',str(P/(label+'-REAPER.json')),'--','timeout','--signal=TERM','--kill-after=15s','600s','taskset','-c','0,1,3,4',*command],cwd=A,env=E,stdout=out,stderr=subprocess.STDOUT)
 rr=json.loads((P/(label+'-REAPER.json')).read_bytes());assert c.returncode==rr['command_exit']==0 and rr['all_children_reaped']and not rr['leftover_cleanup'];print(label,'PASS',round(time.monotonic()-t,3),flush=True)
(P/'AUTHORED-PR-QUESTIONS-PASS.json').write_text(json.dumps({'head':h,'tree':tree,'base':frozen['head'],'actual_commit_changelog_and_id_questions_passed':True},indent=2)+'\n');print(json.dumps({'head':h,'tree':tree,'source4':'PASS','PR_questions':'PASS'}),flush=True)
