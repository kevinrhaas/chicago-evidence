from pathlib import Path
import os,subprocess,json,time,hashlib
P=Path(__file__).parent;R=Path('/workspace/chicago-bridge-increment-20261102');A=R/'chicago/4d';E=os.environ.copy()
for k in ['CHICAGO_TICKETS_DIR','GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES']: E.pop(k,None)
E.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',PATH=str(P/'fixture-local-git-bin')+':'+E['PATH'])
clones=[A/'tickets',Path('/tmp/lake-house-source-20261103/chicago/4d/tickets')]
def snap():
 d={}
 for p in clones:
  def git(*args):return subprocess.check_output(['/usr/local/bin/git','-C',str(p),*args],env=E)
  d[str(p)]={'head':git('rev-parse','HEAD').decode().strip(),'index':hashlib.sha256((p/'.git/index').read_bytes()).hexdigest(),'config':hashlib.sha256((p/'.git/config').read_bytes()).hexdigest(),'status':git('status','--porcelain=v1','--untracked-files=no').decode()}
 return d
before=snap();out=[]
for name in ['test_nav_photos','test_ticket_claim_lock','test_ticket_landed','test_ticket_parked','test_ticket_blocked_band']:
 label='FOCUSED-'+name;rec=P/(label+'-REAPER.json');log=P/(label+'.log');assert not rec.exists()and not log.exists();t=time.monotonic()
 with log.open('xb')as f: x=subprocess.run(['setsid','--fork','--wait','python','/workspace/shared/run-with-reaping.py',str(rec),'--','timeout','--signal=TERM','--kill-after=15s','600s','taskset','-c','0,1,3,4','node','tools/'+name+'.mjs'],cwd=A,env=E,stdout=f,stderr=subprocess.STDOUT)
 rr=json.loads(rec.read_bytes());row={'test':name,'exit':x.returncode,'seconds':time.monotonic()-t,'reaper':rr};out.append(row);print(json.dumps(row),flush=True)
 assert x.returncode==rr['command_exit']==0 and rr['all_children_reaped']and not rr['leftover_cleanup']and rr['interrupted_signal']is None
post=snap();assert before==post,(before,post)
(P/'FOCUSED-RETRY-CLOSED.json').write_text(json.dumps({'status':'ALL_FIVE_PASS_BOTH_REAL_TICKET_CLONES_UNCHANGED','before':before,'after':post,'tests':out},indent=2)+'\n')
print('ALL FIVE PASS; both real ticket clones unchanged',flush=True)
