"""Publish the exact checked native commit without walking missing old local history."""
from pathlib import Path
import base64, datetime, hashlib, json, re, subprocess

P = Path(__file__).resolve().parent
R = Path('/workspace/chicago-bridge-increment-20261102')
receipt = json.loads((P / 'INTEGRATED-COMMIT.json').read_bytes())
HEAD = receipt['head']
TREE = receipt['tree']
BRANCH = 'steward/t2383-sauganash-andreas-current-20261103'

def git(*args):
    return subprocess.check_output(['git', '-C', str(R), *args])

def api(path, data=None, method=None):
    args = ['gh', 'api', 'repos/kevinrhaas/chicago/' + path]
    if data is not None:
        args += ['--method', method or 'POST', '--input', '-']
    result = subprocess.run(args, input=None if data is None else json.dumps(data).encode(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode:
        raise RuntimeError((path, result.stderr.decode()[:1200]))
    return json.loads(result.stdout)

raw = git('cat-file', 'commit', HEAD)
assert hashlib.sha1(b'commit ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == HEAD
headers, message = raw.split(b'\n\n', 1)
lines = headers.decode().splitlines()
assert len(lines) == 5
parents = [line.split(' ', 1)[1] for line in lines if line.startswith('parent ')]
fields = dict(line.split(' ', 1) for line in lines if not line.startswith('parent '))
assert fields['tree'] == TREE and parents == receipt['parents']

def identity(value):
    m = re.fullmatch(r'(.*) <([^<>]+)> (\d+) ([+-])(\d{2})(\d{2})', value)
    assert m
    minutes = (int(m[5]) * 60 + int(m[6])) * (1 if m[4] == '+' else -1)
    date = datetime.datetime.fromtimestamp(int(m[3]), datetime.timezone(datetime.timedelta(minutes=minutes))).isoformat()
    return {'name': m[1], 'email': m[2], 'date': date}

entries = []
blobs = []
for path in receipt['paths']:
    body = git('show', f'{HEAD}:{path}')
    oid = hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()
    assert git('rev-parse', f'{HEAD}:{path}').decode().strip() == oid
    result = api('git/blobs', {'encoding': 'base64', 'content': base64.b64encode(body).decode()})
    assert result['sha'] == oid
    # Read actual server bytes before any ref is created.
    back = api('git/blobs/' + oid)
    assert base64.b64decode(back['content']) == body
    entries.append({'path': path, 'mode': '100644', 'type': 'blob', 'sha': oid})
    blobs.append({'path': path, 'git_blob': oid, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
    print('Exact server blob', path, flush=True)
base_tree = git('rev-parse', receipt['qualified_incoming'] + '^{tree}').decode().strip()
tree = api('git/trees', {'base_tree': base_tree, 'tree': entries})
assert tree['sha'] == TREE, ('native tree changed', tree['sha'], TREE)
commit = api('git/commits', {'tree': TREE, 'parents': parents, 'message': message.decode(), 'author': identity(fields['author']), 'committer': identity(fields['committer'])})
assert commit['sha'] == HEAD, ('native commit changed', commit['sha'], HEAD)
ref_path = 'git/ref/heads/' + BRANCH
read = subprocess.run(['gh', 'api', 'repos/kevinrhaas/chicago/' + ref_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
assert read.returncode == 0, 'Existing authored source branch must exist'
remote_before = json.loads(read.stdout)['object']['sha']
assert remote_before in [parents[0], HEAD], 'Concurrent source branch change; never overwrite it'
if remote_before != HEAD:
    result_ref = api('git/refs/heads/' + BRANCH, {'sha': HEAD, 'force': False}, 'PATCH')
    assert result_ref['object']['sha'] == HEAD
created = False
assert api(ref_path)['object']['sha'] == HEAD
result = {'head': HEAD, 'tree': TREE, 'parents': parents, 'qualified_incoming': receipt['qualified_incoming'], 'remote_before': remote_before, 'branch': BRANCH, 'normal_feature_branch_fast_forward': True, 'exact_native_commit_and_tree': True, 'every_blob_server_readback_exact': True, 'blobs': blobs, 'no_force_or_dev_main_ref_write': True, 'reason': 'Publish the exact native scoped integration head after source4 and current owner qualification, without walking unrelated incomplete historical objects. No assertion or required PR check is bypassed.'}
(P / 'PUSH-INTEGRATED.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'head': HEAD, 'branch': BRANCH, 'all_server_readback': 'PASS'}), flush=True)
