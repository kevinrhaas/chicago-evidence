from pathlib import Path
import subprocess,os,json,hashlib,time,shutil
R=Path('/workspace/chicago-bridge-increment-20261102');P=Path(__file__).parent;H='ce36ee0ee05a1b23003b9e89ca5c246015cd2720';D='42b9c601d51d8a93cde2706e1773f0bd00fadfbe';E=os.environ.copy()
for k in ['CHICAGO_TICKETS_DIR','GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES']:E.pop(k,None)
E.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',GIT_MERGE_AUTOEDIT='no',PYTHONDONTWRITEBYTECODE='1')
def git(*a):return subprocess.check_output(['/usr/local/bin/git','-C',str(R),*a],env=E)
assert not(P/'MERGE-BEGIN.json').exists();assert git('rev-parse','HEAD').decode().strip()==H and not git('status','--porcelain','--untracked-files=normal');assert json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/git/ref/heads/dev']))['object']['sha']==D
for n in ['HEAD','index','config']:(P/('BEFORE-'+n)).write_bytes((R/'.git'/n).read_bytes())
(P/'BEFORE-REFS.txt').write_bytes(git('for-each-ref','--format=%(refname) %(objectname)'));alt=R/'.git/objects/info/alternates';old=alt.read_bytes();(P/'BEFORE-ALTERNATES').write_bytes(old);paths=old.decode().splitlines();added=[]
for name in ['gt-current500-composite-cache-20261103','gt-801-fold-composite-cache-20261103','gt-381-k12-composite-cache-20261103','gt-b6-sign-composite-cache-20261103','gt-final42b-composite-cache-20261103']:
 c=Path('/tmp')/name;ready=json.loads((c/'READY.json').read_bytes());ob=c/'objects.git/objects';assert ob.is_dir() and not(ob/'info/alternates').exists();assert ready['tip'];v=str(ob)
 if v not in paths:paths.append(v);added.append(v)
alt.write_text('\n'.join(paths)+'\n');assert git('rev-parse',D+'^{tree}').decode().strip()=='f899a5ea9f2b075e9578a54d84bebb77e9153eda';assert subprocess.run(['/usr/local/bin/git','-C',str(R),'merge-base','--is-ancestor','8025bc1ef69db40a1ebf6c5ced6b81de58c9d759',D],env=E).returncode==0
incoming=git('diff','--name-only','8025bc1ef69db40a1ebf6c5ced6b81de58c9d759',D).decode().splitlines();(P/'INCOMING-PATHS.json').write_text(json.dumps(incoming,indent=2)+'\n')
assert shutil.disk_usage('/workspace').free>=536870912 and shutil.disk_usage('/tmp').free>=1800000000
rec=P/'MERGE-REAPER.json';log=P/'MERGE.log';assert not rec.exists()and not log.exists();t=time.monotonic()
with log.open('xb')as f:x=subprocess.run(['setsid','--fork','--wait','python','/workspace/shared/run-with-reaping.py',str(rec),'--','timeout','--signal=TERM','--kill-after=15s','600s','taskset','-c','0,1,3,4','/usr/local/bin/git','merge','--no-ff','--no-commit','--no-edit',D],cwd=R,env=E,stdout=f,stderr=subprocess.STDOUT)
rr=json.loads(rec.read_bytes());assert x.returncode==rr['command_exit']and x.returncode in [0,1]and rr['all_children_reaped']and not rr['leftover_cleanup']and rr['interrupted_signal']is None
conflicts=git('diff','--name-only','--diff-filter=U').decode().splitlines();row={'source_authored':H,'incoming':D,'incoming_tree':'f899a5ea9f2b075e9578a54d84bebb77e9153eda','seconds':time.monotonic()-t,'exit':x.returncode,'conflicts':conflicts,'added_independent_read_only_object_caches':added,'incoming_paths':incoming,'reaper':rr,'no_foreign_object_store_mutation_or_cycles':True};(P/'MERGE-BEGIN.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps({'exit':x.returncode,'conflicts':conflicts,'incoming_paths':len(incoming),'seconds':row['seconds']}))
