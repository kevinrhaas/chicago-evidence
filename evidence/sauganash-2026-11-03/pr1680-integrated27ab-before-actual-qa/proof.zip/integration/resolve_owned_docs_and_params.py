from pathlib import Path
import os,json,subprocess,hashlib,sys,dataclasses
R=Path('/workspace/chicago-bridge-increment-20261102');A=R/'chicago/4d';P=Path(__file__).parent;D='42b9c601d51d8a93cde2706e1773f0bd00fadfbe';H='ce36ee0ee05a1b23003b9e89ca5c246015cd2720';E=os.environ.copy()
for k in ['CHICAGO_TICKETS_DIR','GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES']:E.pop(k,None)
E.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1');sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['/usr/local/bin/git','-C',str(R),*args],env=E)
assert git('rev-parse','HEAD').decode().strip()==H and git('rev-parse','MERGE_HEAD').decode().strip()==D
conflicts=git('diff','--name-only','--diff-filter=U').decode().splitlines();expected=['chicago/4d/docs/ROADMAP.md','chicago/4d/docs/STATUS.md'];assert conflicts==expected,conflicts
rows=[]
for path in conflicts:
 before=(R/path).read_bytes();(P/(Path(path).name+'.native-conflict.bin')).write_bytes(before);incoming=git('show',D+':'+path);tail=(P/(Path(path).name+'.own-append.bin')).read_bytes();old=git('show',H+':'+path);base=git('show','8025bc1ef69db40a1ebf6c5ced6b81de58c9d759:'+path);assert old==base+tail;assert incoming.startswith(base);assert tail not in incoming
 post=incoming+tail;(R/path).write_bytes(post);oid=git('hash-object','--',path).decode().strip();existing=subprocess.run(['/usr/local/bin/git','-C',str(R),'cat-file','-e',oid],env=E,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
 if not existing:assert git('hash-object','-w','--',path).decode().strip()==oid
 git('update-index','--add','--cacheinfo','100644,'+oid+','+path);rows.append({'path':path,'incoming_prefix_sha256':sha(incoming),'owned_append_sha256':sha(tail),'final_sha256':sha(post),'incoming_complete_prefix_preserved':True,'invalid_UTF8_preserved_raw':True})
assert not git('diff','--name-only','--diff-filter=U');assert not git('diff','--name-only')
owned=json.loads((P/'CHECKED-AUTHORED-COMMIT.json').read_bytes())['paths'];invariants={}
for path in owned:
 if path in expected:continue
 b=git('show',H+':'+path);assert (R/path).read_bytes()==b,path;invariants[path]=sha(b)
sys.path.insert(0,str(A/'generators'));import mesh_inputs
record=json.loads((A/'data/structures/sauganash_hotel.json').read_bytes());actual=[]
for phase in record['phases']:actual.append({'phase':phase['id'],'archetype':record['archetype'],'scheme':mesh_inputs.SCHEME,'recipe':mesh_inputs.structure_inputs_sha(record,phase),'resolved_params':dataclasses.asdict(mesh_inputs.resolve_params(record['archetype'],phase,record))})
expected_params=json.loads(Path('/tmp/sauganash-source4-20261103/SAUGANASH-PRE-INTEGRATION-NATIVE-PARAMS.json').read_bytes())['phases'];assert actual==expected_params,(actual,expected_params)
(P/'DOCS-AND-NATIVE-PARAMS-CLOSED.json').write_text(json.dumps({'status':'OWN_DOCS_RAW_APPENDS_AND_ALL_NATIVE_HOTEL_PHASE_PARAMS_EXACT','incoming':D,'source':H,'docs':rows,'all_nine_non_doc_owned_paths_exact':invariants,'native_all_phases':actual,'all_nine_non_doc_owned_paths_exact_count':len(invariants)},indent=2)+'\n');print('Native merge conflicts only two owned appends; resolved raw incoming prefix+owned tail. All nine other paths and both native Hotel phase recipes/params EXACT.')
