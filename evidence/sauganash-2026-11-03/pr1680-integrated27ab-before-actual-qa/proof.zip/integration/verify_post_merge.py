from pathlib import Path
import os,json,subprocess,hashlib,sys,dataclasses
R=Path('/workspace/chicago-bridge-increment-20261102');A=R/'chicago/4d';P=Path(__file__).parent;D='42b9c601d51d8a93cde2706e1773f0bd00fadfbe';H='ce36ee0ee05a1b23003b9e89ca5c246015cd2720';E=os.environ.copy();E.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1');E.pop('CHICAGO_TICKETS_DIR',None);sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['/usr/local/bin/git','-C',str(R),*args],env=E)
assert git('rev-parse','HEAD').decode().strip()==H and git('rev-parse','MERGE_HEAD').decode().strip()==D and not git('diff','--name-only','--diff-filter=U')and not git('diff','--name-only')
rows=[];owned=json.loads((P/'CHECKED-AUTHORED-COMMIT.json').read_bytes())['paths'];invariants={}
for path in owned:
 b=(R/path).read_bytes()
 if path in ['chicago/4d/docs/STATUS.md','chicago/4d/docs/ROADMAP.md']:
  incoming=git('show',D+':'+path);tail=(P/(Path(path).name+'.own-append.bin')).read_bytes();assert b==incoming+tail;rows.append({'path':path,'incoming_complete_prefix_preserved':True,'append_sha256':sha(tail),'final_sha256':sha(b),'raw_bytes_invalid_UTF8_preserved':True})
 else:assert b==git('show',H+':'+path),path;invariants[path]=sha(b)
sys.path.insert(0,str(A/'generators'));import mesh_inputs
record=json.loads((A/'data/structures/sauganash_hotel.json').read_bytes());actual=[]
for phase in record['phases']:actual.append({'phase':phase['id'],'archetype':record['archetype'],'scheme':mesh_inputs.SCHEME,'recipe':mesh_inputs.structure_inputs_sha(record,phase),'resolved_params':dataclasses.asdict(mesh_inputs.resolve_params(record['archetype'],phase,record))})
actual=json.loads(json.dumps(actual));expected=json.loads(Path('/tmp/sauganash-source4-20261103/SAUGANASH-PRE-INTEGRATION-NATIVE-PARAMS.json').read_bytes())['phases'];assert actual==expected
(P/'PARAMS-JSON-CONTAINER-COLLECTOR-REFUSAL.json').write_text(json.dumps({'first_comparator':'raw dataclass.asdict tuples versus JSON-loaded baseline lists caused a false refusal; both native recipes remained identical','correction':'Compare the same exact JSON serialization domain on both sides; all nested numeric, enum and confidence values retained','no_model_parameter_or_source_change':True,'original_first_script_preserved':'resolve_owned_docs_and_params.py'},indent=2)+'\n')
(P/'DOCS-AND-NATIVE-PARAMS-CLOSED.json').write_text(json.dumps({'status':'OWN_DOCS_RAW_APPENDS_AND_ALL_NATIVE_HOTEL_PHASE_PARAMS_EXACT','incoming':D,'source':H,'docs':rows,'all_nine_non_doc_owned_paths_exact':invariants,'native_all_phases':actual},indent=2)+'\n');print('Both native Hotel phase recipes and complete JSON-domain resolved params EXACT; nine own non-doc paths exact; both raw full incoming doc prefixes+own appends exact.')
