from pathlib import Path
import json,zipfile,hashlib,subprocess
P=Path(__file__).parent;Q=Path('/tmp/sauganash-final-qa-prep-20261103');O=Path('/tmp/sauganash-integrated27ab-checkpoint-20261103');assert not O.exists();O.mkdir();files={}
for p in P.glob('*.json'):
 if p.name.startswith('BEFORE-'):continue
 files['integration/'+p.name]=p.read_bytes()
for p in P.glob('*.py'):files['integration/'+p.name]=p.read_bytes()
for n in ['STATUS.md.own-append.bin','ROADMAP.md.own-append.bin']:files['integration/'+n]=(P/n).read_bytes()
for n in ['run.py','probe.mjs','DIRECTION-ONLY-REFERENCE.json','WRITER-FREEZE.json','PLAN.json','BEFORE-PUBMAP.json','NATIVE-READER-EXPECTATION.json']:files['actual-qa-freeze/'+n]=(Q/n).read_bytes()
for n in ['AUTHORED-COMMIT.json','AUTHORED-PR-QUESTIONS-PASS.json','PUBLIC-PUSH.json','PR-BODY.md']:files['source4/'+n]=(Path('/tmp/sauganash-source4-20261103')/n).read_bytes()
with zipfile.ZipFile(O/'proof.zip','x',compression=zipfile.ZIP_DEFLATED)as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(O/'proof.zip')as z:
 for n,b in files.items():assert z.read(n)==b
(O/'ARCHIVE.json').write_text(json.dumps({n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}for n,b in files.items()},indent=2)+'\n')
(O/'RECOVERY.md').write_text('''# Sauganash PR1680 integrated27ab: source/owners/publication closed, actual QA active

Visible source PR https://github.com/kevinrhaas/chicago/pull/1680 . Eleven authored paths were natively committed ce36ee0ee05a1b23003b9e89ca5c246015cd2720 only after all four complete native source parts passed398.589/337.654/220.104/315.061s. Actual PR-only questions passed. All native blobs/tree/unsigned commit were recreated and read back exactly on the normal new feature branch; no dev/main/forced ref write. Full source4 and independent root semantic review: public16ec2f7608bba25175688b3e08efedfa9db519f5, evidence/sauganash-2026-11-03/native-source4-green-before-authored-pr/RECOVERY.md.

Root explicitly approved scoped ordinary integration of independently qualified incoming dev without blindly replaying all source4. Fresh dev42b9c601d51d8a93cde2706e1773f0bd00fadfbe includes GT1677 and its bot fold. R normal native merge encountered only two owned document append conflicts. Complete incoming STATUS/ROADMAP raw prefixes +exact own tails retained, including invalidUTF8. Nine other owned paths remain exact. All current native Hotel phase recipes AND complete resolved params match the pre-incoming native baseline. The initial container comparator correctly refused Python tuples vs JSON lists; its script/refusal is preserved, then same JSON serialization domain compared exactly with no parameter/model/source change. All twelve current native owners and full validate passed with proper reapers and ZERO generated drift. Actual integrated-head PR-only questions passed.

Integrated native head27ab2f3b6dc38547e2668ced16191c30c0e8ca48/tree d719d0d702da0d5cbadf5ba1d49c0619143d10f0/parentsce36+42b was normally FF-pushed to the feature branch with exact server blob/tree/two-parent-commit readbacks. Only eleven paths differ from current42b. Current source model geometry, phases, placement, confidence, paint and source photo/camera/group remain unchanged. Native fresh publication50.626s and every-shipped-file contract2.091s closed PASS, source/index exact and clean. PR1680 stays draft; actual required hosted gate41738483593 is queued on27ab. Draft avoids automatic PR-lap while exact-source QA runs.

ACTUAL DESKTOP/PHONE QA IS ACTIVE, NOT YET PASSED. Root granted exclusive GPU; protected controller is /tmp/sauganash-final-qa-prep-20261103/run.py with exact27ab/tree d719, outer2500s and each leg600s/proper reapers. Frozen actual5849-member pubmap, selected source/Git metadata/helper hashes and plan included. Source/Git/publication/ticket writers must remain frozen. Current controller session91896, OUTER-REAPER.json. Root must directly review actual pixels as viewports close. No all15/full-smoke claim: conservative ALL15 budget retained, root-approved relevant scope is custom HotelImages/Record/nativeReader/bodyNormalByGrade/outside-entryboth plus official native Stage3both107. No archival-viewpoint/door-traversal/FPS/whole-ticket completion claim.

Original T2383 remains partial/OPEN/claimed, expires00:13Nov4. Current hotel comparisonDIFFERS; roof/rear-wing and left-gable discrepancies stayOPEN, camera uncertaintyWITHINTOLERANCE. Do not mark originaldone for this increment. After finalbothQA/rootpixels and required hostedgate green, normal protecteddevmerge then explicit native partialrelease. Use CHICAGO_TICKETS_DIR only command-locally for real ticket tools, NEVER whole checks. All first failure/local-only fixture recovery remains public1e743fbca394f4574d18f2f72b493df489c074af. Source every shell /workspace/shared/resume-chicago-env.sh. Preserve borrowed R Git object packs; no GC/repack/broadstage/alternatecycle. Independent incoming caches added directly/read-only; N was never an alternate.
''')
spec={'prefix':'evidence/sauganash-2026-11-03/pr1680-integrated27ab-before-actual-qa/','message':'Checkpoint pushed Sauganash PR1680 exact integrated head, current owners and actual QA writer freeze','receipt':str(O/'PUBLISHED.json'),'files':{n:str(O/n)for n in ['RECOVERY.md','ARCHIVE.json','proof.zip']}};(O/'publication.json').write_text(json.dumps(spec));subprocess.run(['python','/workspace/shared/publish-evidence-files.py','--manifest',str(O/'publication.json')],check=True)
