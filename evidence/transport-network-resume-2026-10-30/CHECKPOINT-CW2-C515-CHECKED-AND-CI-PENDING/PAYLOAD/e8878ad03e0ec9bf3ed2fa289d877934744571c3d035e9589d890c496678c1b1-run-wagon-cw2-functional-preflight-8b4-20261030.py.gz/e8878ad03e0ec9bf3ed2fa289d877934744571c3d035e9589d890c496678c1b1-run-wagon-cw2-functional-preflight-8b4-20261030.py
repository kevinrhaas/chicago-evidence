import datetime,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
APP=Path('/workspace/chicago-wagon-delivery-20261030/chicago/4d')
OUT=Path('/workspace/.cloud-setup/logs/transport-recovery/WAGON-PR1340-DELIVERY-20261030/CW2-FUNCTIONAL-CLOUD-1200-NOT-600-BUDGET-QUALIFICATION-01')
GUARD=Path('/workspace/.cloud-setup/transport-network-resume-20261030/resource_guard.py')
BASELINE=GUARD.with_name('RESTORED-RUNTIME-BASELINE.json')
SUPERVISOR=Path('/workspace/.cloud-setup/transport-supervise.py')
TOOLROOT=Path('/tmp/wagon-cw2-gltf-tools-20261030/node_modules')
RECIPE=APP/'data/transport/studies/farm-box-master.json'
RECORDS=[]
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,obj):Path(p).write_text(json.dumps(obj,indent=2)+'\n')
def pins():
 assert digest(GUARD)=='ac68e89608a6828d71d0933a4e3403ca09585a8f362551e28582e33ea4a73a3c'
 assert digest(BASELINE)=='8ca3ae1358d85ad1dbf3a992c19423bef84f49675947e756d9455d6952680942'
 assert digest(APP/'tools/transport/farm_box/licensed_source.py')=='1a3e87647cbb95c1beb878239bc2a8d93a1f818313356f2b5ae9a6d266aa970b'
 assert digest(APP/'tools/transport/farm_box/adapt_old_cart.py')=='a45b932c912bc1ce8fbf73fa5047ee5997aa8ebd722c9c77eeea37c52661c0f4'
def run(label,budget,cmd,core=None):
 pins();prefix=OUT/label
 before=Path(str(prefix)+'.resources-before.json');after=Path(str(prefix)+'.resources-after.json');pair=Path(str(prefix)+'.resource-pair.json')
 subprocess.run([sys.executable,str(GUARD),'capture',str(before)],check=True)
 env=os.environ.copy()
 if core:env['OPENBLAS_CORETYPE']=core
 else:env.pop('OPENBLAS_CORETYPE',None)
 write(OUT/'LIVE-FUNCTIONAL-PREFLIGHT-STATE.json',{'at':stamp(),'controller_pid':os.getpid(),'state':'RUNNING','label':label,'prefix':str(prefix),'budget':budget,'native_command':cmd,'requested_BLAS_core':core})
 with open(str(prefix)+'.supervisor.stdout.log','wb')as stream:
  cp=subprocess.run([sys.executable,str(SUPERVISOR),'--prefix',str(prefix),'--cwd',str(APP),'--timeout',str(budget),'--',*cmd],env=env,stdout=stream,stderr=subprocess.STDOUT)
 after_rc=subprocess.run([sys.executable,str(GUARD),'capture',str(after)]).returncode
 pair_rc=subprocess.run([sys.executable,str(GUARD),'pair',str(before),str(after),str(pair)]).returncode
 pins();result=json.loads(Path(str(prefix)+'.result.json').read_bytes());cleanup=json.loads(Path(str(prefix)+'.cleanup.json').read_bytes())
 row={'label':label,'requested_core':core,'result':result,'cleanup':cleanup,'resource_pair':json.loads(pair.read_bytes()),'result_sha256':digest(str(prefix)+'.result.json'),'cleanup_sha256':digest(str(prefix)+'.cleanup.json')};RECORDS.append(row)
 write(OUT/'ACTUAL-FUNCTIONAL-PREFLIGHT-STEP-LEDGER.json',RECORDS)
 assert cp.returncode==0 and result['returncode']==0 and not result['timed_out'],row
 assert result['requested_timeout_seconds']==budget and result['effective_timeout_seconds']==budget and result['timeout_override_reason']is None
 assert cleanup['cleanup_complete']and not cleanup['remaining_owned_children'],row
 assert after_rc==0 and pair_rc==0 and row['resource_pair']['accepted'],row
 print(json.dumps({'at':stamp(),'closed_step':label,'native_rc':result['returncode'],'seconds':result['seconds'],'cleanup_complete':cleanup['cleanup_complete'],'resource_accepted':True}),flush=True)
 return row

import re,time
OUT.mkdir(exist_ok=False)
canonical_path=OUT.parent/'CW2-CANONICAL-RESOLVE-8B4-01/ACTUAL-CANONICAL-8B4-SOURCE-RESOURCE-CLOSED.json'
canonical=json.loads(canonical_path.read_bytes());assert canonical['status']=='PASS'
shutil.copyfile(canonical_path,OUT/'ACTUAL-PRIOR-CANONICAL-CLOSED.json')
git=lambda *args:subprocess.check_output(['git',*args],cwd=APP)
expected_tree=canonical['candidate_TREE'];expected_index=canonical['complete_semantic_index_sha256']
assert git('rev-parse','HEAD').decode().strip()=='1ed797136be6841ca6095c1d7a2b8be7c8599953'
assert git('rev-parse','MERGE_HEAD').decode().strip()=='8b4e98207c1afcff4878239cd700379447218cfb'
assert git('write-tree').decode().strip()==expected_tree
assert hashlib.sha256(git('ls-files','--stage','-z')).hexdigest()==expected_index
assert not git('diff','--name-only').strip()
assert not git('ls-files','--others','--exclude-standard').strip()
os.environ['C4D_GATE_REQUIRE_READERS']='1';os.environ['C4D_GATE_REQUIRE_BASE']='1';os.environ['CHECK_JOBS']='4'
os.environ['BASE']='refs/remotes/wagon-delivery/dev-cw2-refresh-20261030'
os.environ['CHECK_TIMINGS']=str(OUT/'ACTUAL-CHECK-TIMINGS.tsv')
started=time.time();row=None;error=None
try:
 row=run('native-functional-preflight',1200,['bash','tools/preflight.sh'])
except BaseException as exc:
 error=repr(exc)
finally:
 copied=[]
 for source,name in [('/tmp/preflight-check.log','ACTUAL-FULL-CHECK-SH.log'),('/tmp/preflight-cl.log','ACTUAL-PREFLIGHT-CHANGELOG.log'),('/tmp/preflight-ids.log','ACTUAL-PREFLIGHT-IDS.log')]:
  p=Path(source)
  if p.is_file()and p.stat().st_mtime>=started-0.1:
   shutil.copyfile(p,OUT/name);copied.append({'source':source,'snapshot':name,'sha256':digest(OUT/name)})
 write(OUT/'ACTUAL-FRESH-GLOBAL-NATIVE-LOG-SNAPSHOT-MAP.json',{'started_epoch':started,'copied_only_actual_this_attempt_logs':copied})
if error:
 write(OUT/'ACTUAL-FUNCTIONAL-GATE-NONPASS-STOPPED.json',{'at':stamp(),'status':'NONPASS_STOPPED','error':error,'native_records':RECORDS,'original600_performance_nonpass_preserved':True})
 write(OUT/'LIVE-FUNCTIONAL-PREFLIGHT-STATE.json',{'at':stamp(),'controller_pid':os.getpid(),'state':'STOPPED_NONPASS','error':error})
 raise SystemExit(1)
assert row is not None
assert git('write-tree').decode().strip()==expected_tree
index=git('ls-files','--stage','-z');assert hashlib.sha256(index).hexdigest()==expected_index
assert not git('diff','--name-only').strip()
assert not git('ls-files','--others','--exclude-standard').strip()
log=(OUT/'ACTUAL-FULL-CHECK-SH.log').read_text(errors='replace');summary=re.findall(r'CHECK PASS[^\n]*?(\d+) steps, none red',log);assert len(summary)==1,summary
native_log=Path(str(OUT/'native-functional-preflight')+'.log').read_text(errors='replace');assert 'PREFLIGHT PASS'in native_log
(OUT/'ACTUAL-POST-FULL-GATE-COMPLETE-SEMANTIC-INDEX.stage-z').write_bytes(index)
result={'at':stamp(),'status':'PASS','label':'FUNCTIONAL-CLOUD-1200-NOT-600-BUDGET-QUALIFICATION','native':row,'all_check_sh_steps_passed':int(summary[0]),'all_three_preflight_questions_passed':True,'HEAD':'1ed797136be6841ca6095c1d7a2b8be7c8599953','MERGE_HEAD':'8b4e98207c1afcff4878239cd700379447218cfb','candidate_TREE':expected_tree,'candidate_APP':canonical['candidate_APP'],'complete_semantic_index_sha256':expected_index,'source_worktree_and_candidate_index_unchanged_by_full_gate':True,'CHECK_JOBS':4,'C4D_GATE_REQUIRE_READERS':1,'C4D_GATE_REQUIRE_BASE':1,'BASE':os.environ['BASE'],'inner_origin_dev_before_or_after_is_metadata_not_false_qualification':git('rev-parse','origin/dev').decode().strip(),'original600_performance_nonpass_preserved_not_budget_qualification':True,'commit_newHEAD_questions_push_CI_DEVmerge_UNRUN':True}
write(OUT/'ACTUAL-FULL-FUNCTIONAL-PREFLIGHT-SOURCE-RESOURCE-CLOSED.json',result)
write(OUT/'LIVE-FUNCTIONAL-PREFLIGHT-STATE.json',{'at':stamp(),'controller_pid':os.getpid(),'state':'CLOSED_PASS','candidate_TREE':expected_tree,'steps':int(summary[0]),'owned_children_remaining':[]})
print(json.dumps({'at':stamp(),'functional_gate_closed':'PASS','seconds':row['result']['seconds'],'steps':int(summary[0]),'candidate_TREE':expected_tree,'cleanup_complete':True,'resource_accepted':True}),flush=True)
