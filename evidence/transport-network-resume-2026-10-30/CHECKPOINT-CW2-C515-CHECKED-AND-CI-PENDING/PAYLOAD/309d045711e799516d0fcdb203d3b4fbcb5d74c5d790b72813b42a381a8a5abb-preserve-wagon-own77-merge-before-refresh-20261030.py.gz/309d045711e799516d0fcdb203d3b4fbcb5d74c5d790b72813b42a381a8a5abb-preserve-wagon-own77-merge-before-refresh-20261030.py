import datetime,hashlib,json,shutil,subprocess
from pathlib import Path
repo=Path('/workspace/chicago-wagon-delivery-20261030');app=repo/'chicago/4d';out=Path('/workspace/.cloud-setup/logs/transport-recovery/WAGON-PR1340-DELIVERY-20261030/CW2-OWN77-MERGE-BEFORE-REFRESH');out.mkdir(exist_ok=False)
def git(*a):return subprocess.check_output(['git',*a],cwd=repo)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()=='1ed797136be6841ca6095c1d7a2b8be7c8599953'
assert git('rev-parse','MERGE_HEAD').decode().strip()=='77b5b30fbde083883d07cd6ea75d78f1a6c2d2af'
(out/'COMPLETE-OWN-PENDING77-HEAD-TO-WORKTREE.binary.patch').write_bytes(git('diff','--binary','HEAD','--'))
(out/'COMPLETE-OWN-PENDING77-HEAD-TO-INDEX.binary.patch').write_bytes(git('diff','--cached','--binary','HEAD','--'))
(out/'COMPLETE-OWN-PENDING77-SEMANTIC-INDEX.stage-z').write_bytes(git('ls-files','--stage','-z'))
index=Path(git('rev-parse','--git-path','index').decode().strip());shutil.copyfile(index,out/'EXACT-PRIVATE-INDEX-BYTES')
paths=['tools/transport/farm_box/licensed_source.py','tools/transport/farm_box/adapt_old_cart.py','assets/authored/transport/farm_box_master_v1/derived/farm-box-source.glb','assets/authored/transport/farm_box_master_v1/derived/farm-box-source.json','assets/authored/transport/farm_box_master_v1/SOURCE.json','renderers/web/transport/farm-box-master/farm-box.json','renderers/web/transport/farm-box-master/EXPORT-RECEIPT.json']+['renderers/web/transport/farm-box-master/farm-box-'+level+'.glb'for level in ['near','mid','far']]
records=[]
for rel in paths:
 src=app/rel;dst=out/'VERIFIED-OWN-FIX-AND-GENUINE-PRODUCTS'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert sha(src)==sha(dst);records.append({'relative_to_APP':rel,'snapshot':str(dst),'sha256':sha(dst),'bytes':dst.stat().st_size})
conflicts=git('diff','--name-only','--diff-filter=U').decode().splitlines();stages=[]
for p in conflicts:
 for stage in [0,1,2,3]:
  raw=(repo/p).read_bytes()if stage==0 else git('show',':'+str(stage)+':'+p)
  dst=out/('STAGE-'+str(stage))/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);stages.append({'path':p,'stage':stage,'snapshot':str(dst),'sha256':sha(dst),'bytes':len(raw)})
shutil.copyfile(app/'docs/LIBERTIES.md',out/'COMPLETE-AUTHORED-MERGED77-LIBERTIES.md')
report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'HEAD':'1ed797136be6841ca6095c1d7a2b8be7c8599953','MERGE_HEAD':'77b5b30fbde083883d07cd6ea75d78f1a6c2d2af','complete_own_fix_and_genuine_native_products':records,'all_conflict_current_and_stage_bytes':stages,'own_merge_abort_UNRUN':True,'native_production_closure':str(out.parent/'CW2-FARM-NUMERIC-FIX-20261030/ACTUAL-NATIVE-PRODUCTION-CLOSED.json')}
p=out/'PRESERVED-OWN77-PENDING-MERGE-AND-VERIFIED-PRODUCTS.json';p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'receipt':str(p),'sha256':sha(p),'ownproducts':len(records),'conflict_snapshot_rows':len(stages)}))
