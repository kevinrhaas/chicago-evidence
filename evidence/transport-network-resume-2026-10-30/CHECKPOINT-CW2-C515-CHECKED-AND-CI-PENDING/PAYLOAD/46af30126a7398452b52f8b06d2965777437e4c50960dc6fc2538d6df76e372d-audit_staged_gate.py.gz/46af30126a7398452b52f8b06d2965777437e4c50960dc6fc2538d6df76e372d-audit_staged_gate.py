"""Read-only audit of the complete native 20-invocation published smoke gate.

Exit 0 means COMPLETE_GATE_PASS; 1 means NONPASS; 2 means PENDING/UNKNOWN.
Every invocation remains tied to its actual checkout, inputs, attempt and log.
This never dispatches, retries, merges or changes repository source.
"""
import argparse
import concurrent.futures
import datetime
import hashlib
import json
import os
import re
import subprocess
import urllib.request
from pathlib import Path

from dispatch_full_smoke import BASE, WORKFLOW, api

ROOT = Path(__file__).parent
MOBILE = ['1-2', '3-6', '7-9', '10-14', '15']
DESKTOP = [str(n) for n in range(1, 16)]
SLOTS = {('mobile', s) for s in MOBILE} | {('desktop', s) for s in DESKTOP}
SOURCE_PATHS = ('.github/workflows/chicago-4d-smoke.yml',
                'chicago/4d/tools/smoke_renderer.mjs')
REVIEWED_SHA = '1ed797136be6841ca6095c1d7a2b8be7c8599953'
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
STAMP = re.compile(r'^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z ?')


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def clean_log(raw):
    return '\n'.join(STAMP.sub('', ANSI.sub('', line.lstrip('\ufeff')))
                     for line in raw.decode('utf-8', errors='replace').splitlines())


def native_summary(raw, sha, viewport, stage):
    """Reject incomplete native logs even when they contain many passing checks."""
    text = clean_log(raw)
    lines = text.splitlines()
    checkouts = []
    for index, line in enumerate(lines[:-1]):
        if '[command]' in line and line.endswith('git log -1 --format=%H'):
            following = next((s.strip() for s in lines[index + 1:] if s.strip()), '')
            checkouts.append(following)
    require(checkouts == [sha], 'Actual checkout full SHA does not uniquely match plan')
    for key, expected in [('SMOKE_VIEWPORT', viewport), ('SMOKE_STAGE', stage)]:
        values = re.findall(r'^[ \t]*' + key + r':[ \t]*([^\r\n]*)$', text, re.M)
        require([value.strip() for value in values] == [expected], key + ' input mismatch')
    require(text.count(f'NOT THE FULL GATE — viewports filtered to "{viewport}"') == 1,
            'Native viewport banner missing or ambiguous')
    require(text.count(f'NOT THE FULL GATE — stages filtered to "{stage}" of 15') == 1,
            'Native stage banner missing or ambiguous')
    require(bool(re.search(r'^node tools/smoke_renderer\.mjs --published$', text, re.M)),
            'Actual published smoke command missing')
    require(bool(re.search(r'^published .*site/4d[ \t]+\(', text, re.M)),
            'Actual freshly published mirror output missing')
    return parse_native_footer(text, viewport, stage) | {
        'actual_checkout_sha': checkouts[0], 'published': True}


def parse_native_footer(text, viewport, stage):
    """Read the real native completion tail; this alone is not a CI certificate."""
    lines = text.splitlines()
    totals = re.findall(r'^(\d+) passed, (\d+) failed$', text, re.M)
    sections = re.findall(r'^(\d+) staged-section check\(s\) \(stage ([\d-]+) of 15\), '
                          r'(\d+) always-on check\(s\)$', text, re.M)
    require(len(totals) == len(sections) == 1, 'Native final summaries absent or ambiguous')
    passed, failed = map(int, totals[0])
    staged, reported_stage, always = sections[0]
    staged, always = int(staged), int(always)
    require(reported_stage == stage and staged > 0 and always > 0,
            'Native stage/count does not match nonempty selected work')
    require(failed == 0 and passed == staged + always, 'Native counts disagree or failed')
    require(len(re.findall(r'^SMOKE PASS$', text, re.M)) == 1, 'Native SMOKE PASS absent/ambiguous')
    require('FAILURES:' not in text, 'Native failure tail exists')
    wall = re.findall(r'^(\d+) m (\d\d) s for stage ([\d-]+) at (mobile|desktop) — '
                      r'the ceiling on a steward run\x27s single foreground command is 10 m 00 s$',
                      text, re.M)
    require(len(wall) == 1, 'Native completed wall-clock line absent or ambiguous')
    minutes, seconds, wall_stage, wall_viewport = wall[0]
    elapsed = int(minutes) * 60 + int(seconds)
    require(int(seconds) < 60 and wall_stage == stage and wall_viewport == viewport,
            'Native wall-clock input mismatch')
    require(0 < elapsed <= 150 * 60, 'Native measured runtime outside existing CI job limit')
    for label in ['the suite body ran to completion', 'zero page errors',
                  'vendor: meshopt decoder loads and reports supported',
                  'vendor: meshopt import raises no page error']:
        require(any('pass ' in line and label in line for line in lines),
                'Always-on completion check absent: ' + label)
    return {'passed': passed, 'failed': failed, 'staged_section_checks': staged,
            'always_on_checks': always, 'native_seconds': elapsed,
            'native_summary_stage': reported_stage, 'native_viewport': viewport,
            'single_process_unfiltered_pass': False}


def source_contract(plan):
    sha = plan['head_sha']
    require(bool(re.fullmatch(r'[0-9a-f]{40}', sha)), 'Invalid expected SHA')
    require(isinstance(plan.get('branch'), str) and plan['branch'].startswith('steward/'),
            'Invalid expected feature branch')
    require(plan.get('mobile') == MOBILE and plan.get('desktop') == DESKTOP,
            'Plan does not contain the exact complete native recipe')
    require(plan.get('unchanged_original_job_timeout_minutes') == 150,
            'Existing 150-minute job cap is not preserved in plan')
    require(plan.get('prior_head_cancelled_results_reused') is False,
            'Plan must not reuse prior-head partial results')
    result = {}
    for path in SOURCE_PATHS:
        def read(commit):
            return subprocess.check_output(['git', '-C', '/workspace/chicago',
                'show', f'{commit}:{path}'], timeout=30,
                env=dict(os.environ, GIT_NO_LAZY_FETCH='1'))
        data = read(sha)
        require(data == read(REVIEWED_SHA), 'Execution contract changed: re-review ' + path)
        expected = plan['native_source'][path]
        require(expected['sha256'] == digest(data) and expected['bytes'] == len(data),
                'Native source receipt mismatch: ' + path)
        result[path] = {'sha256': digest(data), 'bytes': len(data),
                        'byte_identical_to_reviewed_sha': REVIEWED_SHA}
    workflow = subprocess.check_output(['git', '-C', '/workspace/chicago',
        'show', f'{sha}:{SOURCE_PATHS[0]}'], timeout=30,
        env=dict(os.environ, GIT_NO_LAZY_FETCH='1')).decode()
    require('timeout-minutes: 150' in workflow and not re.search(r'^\s*concurrency:', workflow, re.M),
            'Workflow timeout/concurrency execution contract changed')
    return result


def download_log(job_id, destination):
    if destination.exists():
        return destination.read_bytes()
    request = urllib.request.Request(BASE + f'actions/jobs/{job_id}/logs',
        headers={'Accept': 'application/vnd.github+json',
                 'User-Agent': 'Codex-transport-readonly-staged-audit'})
    with urllib.request.urlopen(request, timeout=45) as response:
        raw = response.read(32 * 1024 * 1024 + 1)
    require(len(raw) <= 32 * 1024 * 1024, 'Job log exceeds bounded 32MiB capture')
    temporary = destination.with_name(destination.name + '.tmp')
    temporary.write_bytes(raw)
    temporary.replace(destination)
    return raw


def inspect_slot(slot, plan, folder):
    viewport, stage, run_id = slot['viewport'], slot['stage'], slot['run_id']
    row = {'viewport': viewport, 'stage': stage, 'run_id': run_id,
           'state': 'UNKNOWN', 'observed_utc': utc()}
    receipt_path = folder / f'{viewport}-stage-{stage}-run-{run_id}.json'
    try:
        _, run = api('GET', f'actions/runs/{run_id}')
        row['run_before'] = run
        require(run['id'] == run_id and run['head_sha'] == plan['head_sha']
                and run['head_branch'] == plan['branch']
                and run['event'] == 'workflow_dispatch' and run['workflow_id'] == WORKFLOW,
                'Actual run identity/source/event/workflow mismatch')
        if run['status'] != 'completed':
            row['state'] = 'PENDING'
            row['reason'] = 'Actual run not completed'
            return row
        attempt = run['run_attempt']
        require(isinstance(attempt, int) and attempt > 0, 'Actual run attempt unavailable')
        _, jobs = api('GET', f'actions/runs/{run_id}/attempts/{attempt}/jobs?per_page=100')
        row['jobs'] = jobs
        require(jobs['total_count'] == len(jobs['jobs']) == 1,
                'Expected the one unchanged native smoke job')
        job = jobs['jobs'][0]
        require(job['run_id'] == run_id and job['name'] == 'smoke', 'Job identity mismatch')
        require(job.get('run_attempt', attempt) == attempt, 'Job attempt mismatch')
        if job['status'] != 'completed':
            row['state'] = 'PENDING'
            row['reason'] = 'Actual job not completed'
            return row
        log_path = folder / f'job-{job["id"]}-attempt-{attempt}.log'
        raw = download_log(job['id'], log_path)
        row['raw_log'] = {'path': str(log_path), 'bytes': len(raw), 'sha256': digest(raw)}
        require(run['conclusion'] == job['conclusion'] == 'success',
                'Terminal run/job conclusion is not success')
        steps = job['steps']
        for name in ['Run actions/checkout@v4',
                     'Publish the mirror the smoke serves (site/4d/ is generated)',
                     'Run the smoke against the published mirror']:
            found = [step for step in steps if step['name'] == name]
            require(len(found) == 1 and found[0]['status'] == 'completed'
                    and found[0]['conclusion'] == 'success', 'Required step not successful: ' + name)
        publish = next(s for s in steps if s['name'].startswith('Publish the mirror'))
        smoke = next(s for s in steps if s['name'] == 'Run the smoke against the published mirror')
        require(publish['completed_at'] <= smoke['started_at'],
                'Smoke did not start after successful fresh publication')
        row['native'] = native_summary(raw, plan['head_sha'], viewport, stage)
        _, after = api('GET', f'actions/runs/{run_id}')
        row['run_after'] = after
        require(all(after.get(key) == run.get(key) for key in
                    ['id', 'head_sha', 'head_branch', 'event', 'workflow_id',
                     'run_attempt', 'status', 'conclusion']),
                'Run/attempt changed while auditing; snapshot cannot qualify it')
        row['state'] = 'PASS'
    except ValueError as error:
        row['state'] = 'NONPASS'
        row['reason'] = str(error)
    except Exception as error:
        row['state'] = 'UNKNOWN'
        row['reason'] = type(error).__name__ + ': ' + str(error)
    finally:
        row['closed_utc'] = utc()
        save(receipt_path, row)
    return row


def audit(plan_path):
    plan = json.loads(plan_path.read_text())
    report = {'opened_utc': utc(), 'plan': str(plan_path),
              'plan_sha256': digest(plan_path.read_bytes()), 'state': 'UNKNOWN',
              'read_only_api_methods': ['GET'], 'single_process_unfiltered_pass': False}
    try:
        report['head_sha'] = plan['head_sha']
        report['native_source'] = source_contract(plan)
        rows = plan.get('closed_dispatches', [])
        slots = [(row.get('viewport'), row.get('stage')) for row in rows]
        require(len(slots) == len(set(slots)), 'Duplicate native slot in plan')
        require(set(slots).issubset(SLOTS), 'Unexpected native slot in plan')
        require(all(isinstance(row.get('run_id'), int) and row['run_id'] > 0 for row in rows),
                'Unbound dispatch: reconcile before auditing')
        require(len({row['run_id'] for row in rows}) == len(rows), 'Same run bound to multiple slots')
        folder = ROOT / 'ci' / plan['head_sha'] / 'staged-logs'
        folder.mkdir(parents=True, exist_ok=True)
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            report['slots'] = list(pool.map(lambda row: inspect_slot(row, plan, folder), rows))
        report['missing_slots'] = [list(slot) for slot in sorted(SLOTS - set(slots))]
        passed = [row for row in report['slots'] if row['state'] == 'PASS']
        report['counts'] = {state: sum(row['state'] == state for row in report['slots'])
                            for state in ['PASS', 'PENDING', 'NONPASS', 'UNKNOWN']}
        report['coverage'] = {}
        for viewport in ['mobile', 'desktop']:
            good = [row for row in passed if row['viewport'] == viewport]
            always = sorted({row['native']['always_on_checks'] for row in good})
            require(len(always) <= 1, viewport + ' always-on counts disagree across completed slots')
            parts = []
            for row in good:
                ends = list(map(int, row['stage'].split('-')))
                parts.extend(range(ends[0], ends[-1] + 1))
            require(len(parts) == len(set(parts)), viewport + ' completed sections overlap')
            report['coverage'][viewport] = {
                'passed_invocations': len(good), 'parts': sorted(parts),
                'staged_section_checks': sum(row['native']['staged_section_checks'] for row in good),
                'consistent_always_on_checks': always[0] if always else None,
                'complete_parts_1_to_15_once': sorted(parts) == list(range(1, 16))}
        if report['counts']['NONPASS']:
            report['state'] = 'NONPASS'
        elif (len(passed) == 20 and set(slots) == SLOTS
              and plan.get('state') == 'ALL_20_DISPATCHES_BOUND_RESULTS_PENDING'
              and all(value['complete_parts_1_to_15_once'] for value in report['coverage'].values())):
            report['state'] = 'COMPLETE_GATE_PASS'
        else:
            report['state'] = 'PENDING_OR_UNKNOWN'
    except ValueError as error:
        report['state'] = 'NONPASS'
        report['reason'] = str(error)
    except Exception as error:
        report['state'] = 'UNKNOWN'
        report['reason'] = type(error).__name__ + ': ' + str(error)
    report['closed_utc'] = utc()
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    result = audit(args.plan)
    suffix = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    output = args.out or ROOT / 'ci' / ('COMPLETE-STAGED-GATE-AUDIT-' + suffix + '.json')
    output.parent.mkdir(parents=True, exist_ok=True)
    save(output, result)
    print(json.dumps({key: result.get(key) for key in
        ['state', 'head_sha', 'counts', 'missing_slots', 'coverage', 'reason']}
        | {'receipt': str(output)}))
    raise SystemExit(0 if result['state'] == 'COMPLETE_GATE_PASS'
                     else 1 if result['state'] == 'NONPASS' else 2)
