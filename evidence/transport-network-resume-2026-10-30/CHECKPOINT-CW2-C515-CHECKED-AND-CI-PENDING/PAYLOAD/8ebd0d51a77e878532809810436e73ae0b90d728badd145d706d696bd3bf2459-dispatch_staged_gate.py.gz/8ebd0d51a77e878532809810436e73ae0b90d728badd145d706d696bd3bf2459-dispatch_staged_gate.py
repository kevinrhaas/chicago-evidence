"""Dispatch every native published-gate slot once, serially binding run IDs."""
import argparse
import datetime
import hashlib
import json
import subprocess
import sys
from pathlib import Path

from dispatch_full_smoke import api

MOBILE = ['1-2', '3-6', '7-9', '10-14', '15']
DESKTOP = [str(i) for i in range(1, 16)]
# Launch historically expensive desktop sections first; section entry is independent.
ORDER = [('desktop', '13'), ('desktop', '14'), ('desktop', '15'),
         ('desktop', '12'), ('mobile', '10-14'), ('mobile', '7-9'),
         ('mobile', '3-6'), ('mobile', '1-2'), ('mobile', '15'),
         *[('desktop', str(i)) for i in (2, 4, 7, 8, 1, 3, 5, 6, 9, 10, 11)]]


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--branch', required=True)
    parser.add_argument('--sha', required=True)
    args = parser.parse_args()
    assert len(ORDER) == len(set(ORDER)) == 20
    assert set(ORDER) == ({('mobile', s) for s in MOBILE}
                          | {('desktop', s) for s in DESKTOP})
    root = Path(__file__).parent
    out = root / 'ci' / (args.sha + '-COMPLETE-STAGED-DISPATCH-PLAN.json')
    assert not out.exists(), 'Existing plan: reconcile exact receipts rather than redispatch'
    _, pr = api('GET', 'pulls/1340')
    assert pr['state'] == 'open' and not pr['merged']
    assert pr['head']['sha'] == args.sha and pr['head']['ref'] == args.branch
    assert pr['base']['ref'] == 'dev'
    source = {}
    for path in ('.github/workflows/chicago-4d-smoke.yml',
                 'chicago/4d/tools/smoke_renderer.mjs'):
        data = subprocess.check_output(['git', '-C', '/workspace/chicago',
                                        'show', f'{args.sha}:{path}'])
        original = subprocess.check_output(['git', '-C', '/workspace/chicago',
            'show', f'1ed797136be6841ca6095c1d7a2b8be7c8599953:{path}'])
        assert data == original, 'Re-review native execution contract if source changes'
        source[path] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
    plan = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'head_sha': args.sha, 'branch': args.branch, 'native_source': source,
            'mobile': MOBILE, 'desktop': DESKTOP, 'dispatch_order': ORDER,
            'unchanged_original_job_timeout_minutes': 150,
            'acceptance': 'ALL 20 actual complete PASS on this fixed SHA, actual checkout/input binding, nonzero staged counts, per-viewport section totals and consistent always-on counts. No individual stage alone is the gate. No single-process unfiltered PASS claim.',
            'prior_head_cancelled_results_reused': False,
            'reason': 'Use the exact complete native recipe documented in smoke_renderer.mjs lines46-66. Cancelled prior-head serial jobs consumed about an hour mid-suite; the unchanged workflow records desktop13 alone at85 minutes. Parallel existing stages preserve every assertion within the existing150-minute per-job limit.',
            'state': 'DISPATCHING', 'closed_dispatches': []}
    out.write_text(json.dumps(plan, indent=2) + '\n')
    for viewport, stage in ORDER:
        command = [sys.executable, str(root / 'dispatch_full_smoke.py'),
                   '--branch', args.branch, '--sha', args.sha,
                   '--viewport', viewport, '--stage', stage]
        result = subprocess.run(command, text=True, capture_output=True)
        print(result.stdout, end='', flush=True)
        if result.stderr:
            print(result.stderr, end='', file=sys.stderr, flush=True)
        row = {'viewport': viewport, 'stage': stage, 'returncode': result.returncode,
               'stdout': result.stdout, 'stderr': result.stderr}
        plan['closed_dispatches'].append(row)
        if result.returncode:
            plan['state'] = 'STOPPED_RECONCILE_OUTCOME_NO_BLIND_REDISPATCH'
            out.write_text(json.dumps(plan, indent=2) + '\n')
            raise SystemExit(result.returncode)
        # A successful helper process must have uniquely bound its actual run.
        receipt = root / 'ci' / (args.branch.replace('/', '_') + '-'
            + args.sha[:12] + '-' + viewport + '-stage-' + stage + '-DISPATCH.json')
        bound = json.loads(receipt.read_text())
        if bound['state'] != 'BOUND_TO_ACTUAL_RUN':
            plan['state'] = 'STOPPED_UNBOUND_ACCEPTED_DISPATCH_RECONCILE_NO_REPOST'
            out.write_text(json.dumps(plan, indent=2) + '\n')
            raise SystemExit(2)
        row['run_id'] = bound['run_id']
        out.write_text(json.dumps(plan, indent=2) + '\n')
    plan['state'] = 'ALL_20_DISPATCHES_BOUND_RESULTS_PENDING'
    out.write_text(json.dumps(plan, indent=2) + '\n')
    print(json.dumps({'plan': str(out), 'state': plan['state'],
                      'run_ids': [r['run_id'] for r in plan['closed_dispatches']]}), flush=True)
