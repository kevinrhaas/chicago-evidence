"""Read-only GitHub snapshot; never infers required checks or merges a PR."""
import argparse
import concurrent.futures
import datetime
import json
import urllib.parse
from pathlib import Path

from dispatch_full_smoke import api


def snapshot(pr_number, expected_sha=None):
    _, pr = api('GET', f'pulls/{pr_number}')
    sha = pr['head']['sha']
    if expected_sha:
        assert sha == expected_sha, 'PR HEAD changed; old qualification does not cover it'
    paths = {
        'current_dev': 'git/ref/heads/dev',
        'head_checks': f'commits/{sha}/check-runs?per_page=100&filter=latest',
        'head_status': f'commits/{sha}/status?per_page=100',
        'head_runs': 'actions/runs?' + urllib.parse.urlencode(
            {'head_sha': sha, 'per_page': 100}),
    }
    merge_sha = pr.get('merge_commit_sha')
    if merge_sha and not pr['merged'] and pr.get('mergeable'):
        paths['synthetic_merge_checks'] = f'commits/{merge_sha}/check-runs?per_page=100&filter=latest'
    result = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'pr': pr, 'expected_head_sha': expected_sha,
              'required_contexts_unknown': True, 'read_only': True}
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        futures = {name: pool.submit(api, 'GET', path) for name, path in paths.items()}
        for name, future in futures.items():
            try:
                result[name] = future.result()[1]
            except Exception as error:
                result[name] = {'snapshot_error': repr(error)}
    _, after = api('GET', f'pulls/{pr_number}')
    result['head_stayed_fixed'] = after['head']['sha'] == sha
    result['pr_after'] = after
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--pr', type=int, default=1340)
    parser.add_argument('--sha')
    args = parser.parse_args()
    result = snapshot(args.pr, args.sha)
    sha = result['pr']['head']['sha']
    folder = Path(__file__).with_name('ci') / sha
    folder.mkdir(exist_ok=True, parents=True)
    out = folder / (datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ') + '.json')
    out.write_text(json.dumps(result, indent=2) + '\n')
    summary = {'receipt': str(out), 'head': sha,
               'head_stayed_fixed': result['head_stayed_fixed'],
               'mergeable': result['pr_after'].get('mergeable'),
               'mergeable_state': result['pr_after'].get('mergeable_state'),
               'merged': result['pr_after']['merged'],
               'current_dev': result['current_dev'].get('object', {}).get('sha'),
               'runs': [{k: run.get(k) for k in ('id', 'name', 'event', 'status', 'conclusion', 'head_sha', 'html_url')}
                        for run in result['head_runs'].get('workflow_runs', [])
                        if run['head_sha'] == sha]}
    print(json.dumps(summary))
