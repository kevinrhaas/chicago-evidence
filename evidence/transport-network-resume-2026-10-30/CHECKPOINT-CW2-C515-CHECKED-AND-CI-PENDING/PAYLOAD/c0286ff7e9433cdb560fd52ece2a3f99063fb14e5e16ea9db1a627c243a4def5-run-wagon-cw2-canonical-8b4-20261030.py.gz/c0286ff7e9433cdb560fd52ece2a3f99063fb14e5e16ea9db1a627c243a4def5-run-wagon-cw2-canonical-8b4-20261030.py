import datetime,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
APP=Path('/workspace/chicago-wagon-delivery-20261030/chicago/4d')
OUT=Path('/workspace/.cloud-setup/logs/transport-recovery/WAGON-PR1340-DELIVERY-20261030/CW2-CANONICAL-RESOLVE-8B4-01')
GUARD=Path('/workspace/.cloud-setup/transport-network-resume-20261030/resource_guard.py')
BASELINE=GUARD.with_name('RESTORED-RUNTIME-BASELINE.json')
SUPERVISOR=Path('/workspace/.cloud-setup/transport-supervise.py')
TOOLROOT=Path('/tmp/wagon-cw2-gltf-tools-20261030/node_modules')
RECIPE=APP/'data/transport/studies/farm-box-master.json'
RECORDS=[]
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,obj):Path(p).write_text(json.dumps(obj,indent=2)+'\n')
def pins():
 assert digest(GUARD)=='ac68e89608a6828d71d0933a4e3403ca09585a8f362551e28582e33ea4a73a3c'
 assert digest(BASELINE)=='8ca3ae1358d85ad1dbf3a992c19423bef84f49675947e756d9455d6952680942'
 assert digest(APP/'tools/transport/farm_box/licensed_source.py')=='1a3e87647cbb95c1beb878239bc2a8d93a1f818313356f2b5ae9a6d266aa970b'
 assert digest(APP/'tools/transport/farm_box/adapt_old_cart.py')=='a45b932c912bc1ce8fbf73fa5047ee5997aa8ebd722c9c77eeea37c52661c0f4'
def run(label,budget,cmd,core=None):
 pins();prefix=OUT/label
 before=Path(str(prefix)+'.resources-before.json');after=Path(str(prefix)+'.resources-after.json');pair=Path(str(prefix)+'.resource-pair.json')
 subprocess.run([sys.executable,str(GUARD),'capture',str(before)],check=True)
 env=os.environ.copy()
 if core:env['OPENBLAS_CORETYPE']=core
 else:env.pop('OPENBLAS_CORETYPE',None)
 write(OUT/'LIVE-CANONICAL-RESOLVE-STATE.json',{'at':stamp(),'controller_pid':os.getpid(),'state':'RUNNING','label':label,'prefix':str(prefix),'budget':budget,'native_command':cmd,'requested_BLAS_core':core})
 with open(str(prefix)+'.supervisor.stdout.log','wb')as stream:
  cp=subprocess.run([sys.executable,str(SUPERVISOR),'--prefix',str(prefix),'--cwd',str(APP),'--timeout',str(budget),'--',*cmd],env=env,stdout=stream,stderr=subprocess.STDOUT)
 after_rc=subprocess.run([sys.executable,str(GUARD),'capture',str(after)]).returncode
 pair_rc=subprocess.run([sys.executable,str(GUARD),'pair',str(before),str(after),str(pair)]).returncode
 pins();result=json.loads(Path(str(prefix)+'.result.json').read_bytes());cleanup=json.loads(Path(str(prefix)+'.cleanup.json').read_bytes())
 row={'label':label,'requested_core':core,'result':result,'cleanup':cleanup,'resource_pair':json.loads(pair.read_bytes()),'result_sha256':digest(str(prefix)+'.result.json'),'cleanup_sha256':digest(str(prefix)+'.cleanup.json')};RECORDS.append(row)
 write(OUT/'ACTUAL-CANONICAL-RESOLVE-STEP-LEDGER.json',RECORDS)
 assert cp.returncode==0 and result['returncode']==0 and not result['timed_out'],row
 assert result['requested_timeout_seconds']==budget and result['effective_timeout_seconds']==budget and result['timeout_override_reason']is None
 assert cleanup['cleanup_complete']and not cleanup['remaining_owned_children'],row
 assert after_rc==0 and pair_rc==0 and row['resource_pair']['accepted'],row
 print(json.dumps({'at':stamp(),'closed_step':label,'native_rc':result['returncode'],'seconds':result['seconds'],'cleanup_complete':cleanup['cleanup_complete'],'resource_accepted':True}),flush=True)
 return row

OUT.mkdir(exist_ok=False)
proof_path=OUT.parent/'CW2-FRESH8B4-MERGE-SOURCE-FREEZE/ACTUAL-FRESH8B4-SOURCE-PRODUCT-PRESERVATION-AND-OWNER-PLAN.json'
proof=json.loads(proof_path.read_bytes())
shutil.copyfile(proof_path,OUT/'FROZEN-ACTUAL8B4-SOURCE-AND-OWNER-PLAN.json')
try:
 assert subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=APP).decode().strip()=='8b4e98207c1afcff4878239cd700379447218cfb'
 row=run('native-resolve',1800,['node','tools/rederive.mjs','--resolve'])
 for x in proof['original_unmodified_nonoverlap_files_exact']:
  assert digest(APP.parents[1]/x['path'])==x['sha256'],x['path']
 for x in proof['reviewed_source_and_genuine_products_reapplied_with_all_native_inputs_unchanged']:
  assert digest(APP.parents[1]/x['path'])==x['sha256'],x['path']
 assert digest(APP.parents[1]/proof['legitimate_upstream_main_update']['path'])==proof['legitimate_upstream_main_update']['working_sha256']
 smoke=(APP/'tools/smoke_renderer.mjs').read_text()
 original=json.loads((OUT.parent/'PRE-MERGE-PUBLIC78-SOURCE-AND-OWN-ANCHOR-PINS.json').read_bytes())
 for x in original['critical_owned_wagon_blocks']:
  i=smoke.index(x['start']);j=smoke.index(x['end'],i);assert hashlib.sha256(smoke[i:j].encode()).hexdigest()==x['sha256']
 git=lambda *args:subprocess.check_output(['git',*args],cwd=APP)
 assert not git('diff','--name-only','--diff-filter=U').strip()
 assert not git('diff','--name-only').strip()
 assert not git('ls-files','--others','--exclude-standard').strip()
 index=git('ls-files','--stage','-z');(OUT/'POST-CANONICAL-COMPLETE-SEMANTIC-INDEX.stage-z').write_bytes(index)
 tree=git('write-tree').decode().strip();app_tree=git('rev-parse',tree+':chicago/4d').decode().strip()
 (OUT/'POST-CANONICAL-CANDIDATE-NET-DIFF.binary.patch').write_bytes(git('diff','--cached','--binary','HEAD'))
 log=Path(str(OUT/'native-resolve')+'.log').read_text(errors='replace')
 assert 'last one moved nothing' in log,'Native settled tail must close no-change'
 result={'at':stamp(),'status':'PASS','native':row,'HEAD':'1ed797136be6841ca6095c1d7a2b8be7c8599953','MERGE_HEAD':'8b4e98207c1afcff4878239cd700379447218cfb','candidate_TREE':tree,'candidate_APP':app_tree,'complete_semantic_index_sha256':hashlib.sha256(index).hexdigest(),'all32_other_original_featurefiles_exact':True,'all10_reviewed_source_and_genuine_native_products_exact':True,'main_exact_W_plus_upstreamT3263_retained':True,'all3_original_owned4_6m_blocks_exact':True,'no_unmerged_or_unstaged_or_untracked_paths':True,'native_settled_tail_last_moved_nothing':True,'wholefunctional_gate_commit_push_UNRUN':True}
 write(OUT/'ACTUAL-CANONICAL-8B4-SOURCE-RESOURCE-CLOSED.json',result)
 write(OUT/'LIVE-CANONICAL-RESOLVE-STATE.json',{'at':stamp(),'controller_pid':os.getpid(),'state':'CLOSED_PASS','candidate_TREE':tree,'owned_children_remaining':[]})
 print(json.dumps({'at':stamp(),'canonical_native_closed':'PASS','seconds':row['result']['seconds'],'candidate_TREE':tree,'candidate_APP':app_tree,'cleanup_complete':True,'resource_accepted':True}),flush=True)
except BaseException as exc:
 write(OUT/'ACTUAL-CANONICAL-CONTROLLER-STOPPED.json',{'at':stamp(),'status':'NONPASS_STOPPED','error':repr(exc),'closed_step_records':RECORDS})
 write(OUT/'LIVE-CANONICAL-RESOLVE-STATE.json',{'at':stamp(),'controller_pid':os.getpid(),'state':'STOPPED_NONPASS','error':repr(exc)})
 raise
