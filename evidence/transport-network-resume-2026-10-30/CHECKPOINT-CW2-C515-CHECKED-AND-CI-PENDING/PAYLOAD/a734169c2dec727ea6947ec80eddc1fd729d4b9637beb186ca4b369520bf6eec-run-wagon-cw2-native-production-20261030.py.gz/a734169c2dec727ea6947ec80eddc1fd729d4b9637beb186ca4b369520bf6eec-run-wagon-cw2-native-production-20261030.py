import datetime,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
APP=Path('/workspace/chicago-wagon-delivery-20261030/chicago/4d')
OUT=Path('/workspace/.cloud-setup/logs/transport-recovery/WAGON-PR1340-DELIVERY-20261030/CW2-FARM-NUMERIC-FIX-20261030')
GUARD=Path('/workspace/.cloud-setup/transport-network-resume-20261030/resource_guard.py')
BASELINE=GUARD.with_name('RESTORED-RUNTIME-BASELINE.json')
SUPERVISOR=Path('/workspace/.cloud-setup/transport-supervise.py')
TOOLROOT=Path('/tmp/wagon-cw2-gltf-tools-20261030/node_modules')
RECIPE=APP/'data/transport/studies/farm-box-master.json'
RECORDS=[]
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,obj):Path(p).write_text(json.dumps(obj,indent=2)+'\n')
def pins():
 assert digest(GUARD)=='ac68e89608a6828d71d0933a4e3403ca09585a8f362551e28582e33ea4a73a3c'
 assert digest(BASELINE)=='8ca3ae1358d85ad1dbf3a992c19423bef84f49675947e756d9455d6952680942'
 assert digest(APP/'tools/transport/farm_box/licensed_source.py')=='1a3e87647cbb95c1beb878239bc2a8d93a1f818313356f2b5ae9a6d266aa970b'
 assert digest(APP/'tools/transport/farm_box/adapt_old_cart.py')=='a45b932c912bc1ce8fbf73fa5047ee5997aa8ebd722c9c77eeea37c52661c0f4'
def run(label,budget,cmd,core=None):
 pins();prefix=OUT/label
 before=Path(str(prefix)+'.resources-before.json');after=Path(str(prefix)+'.resources-after.json');pair=Path(str(prefix)+'.resource-pair.json')
 subprocess.run([sys.executable,str(GUARD),'capture',str(before)],check=True)
 env=os.environ.copy()
 if core:env['OPENBLAS_CORETYPE']=core
 else:env.pop('OPENBLAS_CORETYPE',None)
 write(OUT/'LIVE-NATIVE-PRODUCTION-STATE.json',{'at':stamp(),'controller_pid':os.getpid(),'state':'RUNNING','label':label,'prefix':str(prefix),'budget':budget,'native_command':cmd,'requested_BLAS_core':core})
 with open(str(prefix)+'.supervisor.stdout.log','wb')as stream:
  cp=subprocess.run([sys.executable,str(SUPERVISOR),'--prefix',str(prefix),'--cwd',str(APP),'--timeout',str(budget),'--',*cmd],env=env,stdout=stream,stderr=subprocess.STDOUT)
 after_rc=subprocess.run([sys.executable,str(GUARD),'capture',str(after)]).returncode
 pair_rc=subprocess.run([sys.executable,str(GUARD),'pair',str(before),str(after),str(pair)]).returncode
 pins();result=json.loads(Path(str(prefix)+'.result.json').read_bytes());cleanup=json.loads(Path(str(prefix)+'.cleanup.json').read_bytes())
 row={'label':label,'requested_core':core,'result':result,'cleanup':cleanup,'resource_pair':json.loads(pair.read_bytes()),'result_sha256':digest(str(prefix)+'.result.json'),'cleanup_sha256':digest(str(prefix)+'.cleanup.json')};RECORDS.append(row)
 write(OUT/'ACTUAL-NATIVE-PRODUCTION-STEP-LEDGER.json',RECORDS)
 assert cp.returncode==0 and result['returncode']==0 and not result['timed_out'],row
 assert result['requested_timeout_seconds']==budget and result['effective_timeout_seconds']==budget and result['timeout_override_reason']is None
 assert cleanup['cleanup_complete']and not cleanup['remaining_owned_children'],row
 assert after_rc==0 and pair_rc==0 and row['resource_pair']['accepted'],row
 print(json.dumps({'at':stamp(),'closed_step':label,'native_rc':result['returncode'],'seconds':result['seconds'],'cleanup_complete':cleanup['cleanup_complete'],'resource_accepted':True}),flush=True)
 return row
try:
 masters={}
 for name,core in [('DEFAULT',None),('HASWELL','Haswell'),('SANDYBRIDGE','Sandybridge'),('NEHALEM','Nehalem')]:
  target=Path('/tmp/WAGON-CW2-NATIVE-MASTER-'+name+'-20261030-01');assert not target.exists()
  run('native-master-'+name.lower(),120,['python3','tools/transport/farm_box/adapt_old_cart.py','--parameters',str(RECIPE),'--output-dir',str(target)],core)
  assert digest(target/'farm-box-source.glb')=='fb0c507048ad8a95e19cc0d8a1e57ade5c2937060eeef3adc9e45af96a0e4ee4'
  assert digest(target/'farm-box-source.json')=='d820eec7844146b76099d0633b64c0603f1bc6675e72098b1c3a9e9e37806963'
  masters[name]=target
 export=Path('/tmp/WAGON-CW2-NATIVE-WEB-20261030-01');assert not export.exists()
 run('native-pinned-LOD-export',300,['node','tools/transport/farm_box/export_lods.mjs','--input',str(masters['DEFAULT']/'farm-box-source.glb'),'--output-dir',str(export),'--parameters',str(RECIPE),'--tools-root',str(TOOLROOT)])
 authored=APP/'assets/authored/transport/farm_box_master_v1';web=APP/'renderers/web/transport/farm-box-master';preserved=OUT/'ORIGINAL-1ED-PRODUCTION-OUTPUTS';preserved.mkdir(exist_ok=False)
 targets=[authored/'derived/farm-box-source.glb',authored/'derived/farm-box-source.json',authored/'SOURCE.json',web/'farm-box.json',web/'EXPORT-RECEIPT.json']+[web/('farm-box-'+level+'.glb')for level in ['near','mid','far']]
 original=[]
 for p in targets:
  rel=p.relative_to(APP);dst=preserved/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst);assert digest(p)==digest(dst);original.append({'path':str(rel),'old_sha256':digest(p),'snapshot':str(dst),'bytes':p.stat().st_size})
 installation=[]
 for src,dst in [(masters['DEFAULT']/'farm-box-source.glb',authored/'derived/farm-box-source.glb'),(masters['DEFAULT']/'farm-box-source.json',authored/'derived/farm-box-source.json'),(masters['DEFAULT']/'farm-box-source.json',web/'farm-box.json')]+[(export/p.name,p)for p in [web/'EXPORT-RECEIPT.json']+[web/('farm-box-'+level+'.glb')for level in ['near','mid','far']]]:
  tmp=dst.with_name(dst.name+'.cw2-atomic');shutil.copyfile(src,tmp);os.replace(tmp,dst);assert digest(src)==digest(dst);installation.append({'native_product':str(src),'installed':str(dst.relative_to(APP)),'sha256':digest(dst),'bytes':dst.stat().st_size})
 source=json.loads((authored/'SOURCE.json').read_bytes());before_source=json.loads((authored/'SOURCE.json').read_bytes())
 for row in source['authored_files']:
  p=authored/row['path'];row['bytes']=p.stat().st_size;row['sha256']=digest(p)
 receipt=json.loads((web/'EXPORT-RECEIPT.json').read_bytes());source['web_export']['sha256']=digest(web/'EXPORT-RECEIPT.json');source['web_export']['producer_sha256']=receipt['exporter_sha256'];source['web_export']['total_bytes']=sum(row['bytes']for row in receipt['lods'])
 assert len(source['web_export']['levels'])==len(receipt['lods'])
 for oldrow,newrow in zip(source['web_export']['levels'],receipt['lods']):
  assert oldrow['level']==newrow['level']
  for k in oldrow:oldrow[k]=newrow[k]
 write(authored/'SOURCE.json',source)
 write(OUT/'ACTUAL-NATIVE-PRODUCTION-INSTALLATION.json',{'at':stamp(),'original_products':original,'installed_actual_native_products':installation,'source_inventory_update':'Only actual produced-file bytes/SHA and native exporter measured level rows refreshed; all source rights/credit/limitations unchanged','old_SOURCE':before_source,'new_SOURCE':source,'binary_hand_edit':False})
 for name,core in [('DEFAULT',None),('HASWELL','Haswell'),('SANDYBRIDGE','Sandybridge'),('NEHALEM','Nehalem')]:run('native-strict-mechanics-'+name.lower(),120,['python3','tools/check_farm_box_master.py'],core)
 write(OUT/'ACTUAL-NATIVE-PRODUCTION-CLOSED.json',{'at':stamp(),'status':'PASS','controller_pid':os.getpid(),'actual_owned_steps':RECORDS,'master_four_cores_byte_identical':True,'all_four_original_strict_mechanical_checks_passed':True,'original_inputs_credits_and_thresholds_unchanged':True,'native_products_installed_from_measured_outputs_only':True,'app_commit_push_or_whole_gate_UNRUN':True})
 write(OUT/'LIVE-NATIVE-PRODUCTION-STATE.json',{'at':stamp(),'controller_pid':os.getpid(),'state':'CLOSED_PASS','owned_children_remaining':[]})
except BaseException as exc:
 write(OUT/'ACTUAL-NATIVE-PRODUCTION-CONTROLLER-STOPPED.json',{'at':stamp(),'status':'NONPASS_STOPPED','error':repr(exc),'closed_step_records':RECORDS})
 write(OUT/'LIVE-NATIVE-PRODUCTION-STATE.json',{'at':stamp(),'controller_pid':os.getpid(),'state':'STOPPED_NONPASS','error':repr(exc)})
 raise
