from pathlib import Path
import datetime,hashlib,json,subprocess,time
R=Path('/workspace/chicago-wagon-delivery-20261030');A=R/'chicago/4d';ROOT=Path('/workspace/.cloud-setup/logs/transport-recovery/WAGON-PR1340-DELIVERY-20261030');D=ROOT/'CW2-ACTUAL-FIVE-NEWHEAD-QUESTIONS-01';D.mkdir(exist_ok=False)
def git(*args):return subprocess.check_output(['git','-C',str(R),*args]).decode().strip()
qualification=json.loads((ROOT/'CW2-FUNCTIONAL-CLOUD-1200-NOT-600-BUDGET-QUALIFICATION-01/ACTUAL-FULL-FUNCTIONAL-PREFLIGHT-SOURCE-RESOURCE-CLOSED.json').read_bytes());assert qualification['status']=='PASS'
head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}');base='8b4e98207c1afcff4878239cd700379447218cfb'
assert tree==qualification['candidate_TREE']and git('show','-s','--format=%P','HEAD').split()==['1ed797136be6841ca6095c1d7a2b8be7c8599953',base]and not git('status','--porcelain')
commands=[('newHEAD-changelog-entry',['node','tools/check-changelog-entry.mjs',base,'HEAD']),('newHEAD-ID-collision',['node','tools/resolve_id_collisions.mjs','--base',base,'--check']),('newHEAD-changelog-contract',['node','tools/check-changelog.mjs']),('newHEAD-pending-entries',['node','tools/changelog-entries.mjs','--check']),('newHEAD-pinned-history',['node','tools/changelog-history.mjs','--base',base])];records=[]
for label,cmd in commands:
 p=D/(label+'.log');start=time.monotonic()
 with p.open('wb')as out:r=subprocess.run(cmd,cwd=A,stdout=out,stderr=subprocess.STDOUT,timeout=30)
 records.append({'label':label,'command':cmd,'returncode':r.returncode,'seconds':time.monotonic()-start,'log':str(p),'log_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 if r.returncode:break
white=subprocess.run(['git','diff','--check',base,'HEAD'],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
status='PASS'if len(records)==5 and all(r['returncode']==0 for r in records)and white.returncode==0 and not git('status','--porcelain')else'NONPASS'
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':status,'HEAD':head,'TREE':tree,'APP':git('rev-parse','HEAD:chicago/4d'),'actual_DEV_parent':base,'checks':records,'whitespace':{'command':['git','diff','--check',base,'HEAD'],'returncode':white.returncode,'stdout':white.stdout,'stderr':white.stderr},'clean':not bool(git('status','--porcelain')),'functional_gate_before_commit_exact_TREE_bridge':True,'functional_gate_original_HEAD_during_run':'1ed797136be6841ca6095c1d7a2b8be7c8599953','old600_performance_NONPASS_preserved':True,'no_push_performed_by_this_program':True};(D/'ACTUAL-FIVE-COMMITTED-HEAD-QUESTIONS.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);raise SystemExit(0 if status=='PASS'else 1)
