#!/usr/bin/env python3
"""Read actual receipts without editing the native command, source or old results."""
from pathlib import Path
import hashlib, json, re, subprocess, sys

P = Path('/workspace/horse-delivery-resume-20261030')
W = Path('/workspace/chicago-horse-delivery-20261030')
phase, folder = sys.argv[1:]
D = P/folder
closed = json.loads((D/'ACTUAL-CLOSED.json').read_text())
command = json.loads((D/'COMMAND.json').read_text())
assert phase == closed['phase'] and closed['state'] == 'PASS'
actual_base = subprocess.check_output(['git', '--no-optional-locks', '-C', str(W),
    'rev-parse', command['BASE']], text=True).strip()
assert actual_base == command['BASE_SHA'], 'Private BASE ref changed during owned phase'
raw = (D/'native.log').read_text(errors='replace')
proof = {'phase': phase, 'state': 'PASS', 'actual_native_seconds': closed['actual_native']['command_seconds'],
         'native_log_sha256': hashlib.sha256((D/'native.log').read_bytes()).hexdigest(),
         'closed_receipt_sha256': hashlib.sha256((D/'ACTUAL-CLOSED.json').read_bytes()).hexdigest(),
         'BASE_before_recorded': command['BASE_SHA'], 'BASE_after_actual': actual_base,
         'BASE_unchanged': True, 'actual_cleanup_complete_zero': True,
         'resource_pair_accepted': closed['resource_pair_accepted'],
         'TREE': closed.get('TREE'), 'APP': closed.get('APP')}
if phase == 'resolve':
    manifest = json.loads((W/'chicago/4d/tools/derived_manifest.json').read_text())
    n, second = len(manifest['steps']), len(manifest['second_pass'])
    assert n == 204 and second == 7
    main_rows = [int(x) for x in re.findall(r'^  \[(\d+)/204\]', raw, re.M)]
    second_rows = [int(x) for x in re.findall(r'^  \[second pass (\d+)/7\]', raw, re.M)]
    assert main_rows[:n] == list(range(1, n+1)), 'Full native main sequence is incomplete'
    assert second_rows == list(range(1, second+1)), 'Full native second pass is incomplete'
    assert 'derived layer rebuilt — 204 step(s) in dependency order, then a second pass of 7' in raw
    settled = re.findall(r'derived layer rebuilt from step (\d+) — (\d+) step\(s\) in manifest order, '
                         r'(\d+) lap\(s\), and the last one moved nothing', raw)
    assert settled and 'WARNING: the tail' not in raw
    assert '--resolve:' in raw and 'file(s) staged' in raw
    proof.update(full_main_sequence_count=n, actual_second_pass_count=second,
                 actual_unchanged_settlement=settled, manifest_sha256=hashlib.sha256(
                     (W/'chicago/4d/tools/derived_manifest.json').read_bytes()).hexdigest())
else:
    assert phase == 'preflight'
    assert 'PREFLIGHT PASS' in raw and 'PREFLIGHT FAIL' not in raw
    gate = (D/'preflight-check.log').read_text(errors='replace')
    final = gate[-2500:]
    assert re.search(r'CHECK PASS', final) and not re.search(r'CHECK FAIL', final)
    proof.update(native_preflight_all_three_questions_pass=True,
                 label='FUNCTIONAL-CLOUD-1200-NOT-600-BUDGET-QUALIFICATION',
                 native_gate_final_lines=gate.splitlines()[-4:],
                 precommit_PR_questions_HEAD='2177b51b1f6d0c4aedfbc5374f4f1e2ce1fa7d1b',
                 committed_HEAD_questions_still_required=True)
target = D/'INDEPENDENT-ACTUAL-CLOSURE-READBACK.json'
assert not target.exists()
target.write_text(json.dumps(proof, indent=2)+'\n')
print(json.dumps(proof))
