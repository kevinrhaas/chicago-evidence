import ctypes,hashlib,json,os,struct,sys,time
from pathlib import Path
import numpy as np
app=Path('/workspace/chicago-wagon-delivery-20261030/chicago/4d')
proof=Path(__file__).parent
sys.path.insert(0,str(app/'tools/transport/farm_box'))
import licensed_source
exec(compile((proof/"UNAPPLIED-CANDIDATE-LICENSED-SOURCE-v3.py").read_text(),str(app/"tools/transport/farm_box/licensed_source.py"),"exec"),licensed_source.__dict__)
import adapt_old_cart
candidate=proof/'UNAPPLIED-CANDIDATE-ADAPT-v3.py'
exec(compile(candidate.read_text(),str(app/'tools/transport/farm_box/adapt_old_cart.py'),'exec'),adapt_old_cart.__dict__)
start=time.monotonic()
raw,sidecar=adapt_old_cart.make(json.loads((app/'data/transport/studies/farm-box-master.json').read_bytes()))
sidecar['glb_sha256']=hashlib.sha256(raw).hexdigest()
sidecarbytes=(json.dumps(sidecar,indent=2)+'\n').encode()
old=(app/'assets/authored/transport/farm_box_master_v1/derived/farm-box-source.glb').read_bytes()
def parts(b):
 n=struct.unpack_from('<I',b,12)[0]
 return json.loads(b[20:20+n]),b[28+n:]
a,ab=parts(old);b,bb=parts(raw)
changes=[]
def numeric_changes(x,y,p=''):
 if isinstance(x,dict) and isinstance(y,dict):
  for k in x.keys()&y.keys(): numeric_changes(x[k],y[k],p+'/'+k)
 elif isinstance(x,list) and isinstance(y,list) and len(x)==len(y):
  for i,(v,w)in enumerate(zip(x,y)): numeric_changes(v,w,p+'/'+str(i))
 elif x!=y: changes.append({'path':p,'old':x,'new':y,'absolute_delta':abs(x-y) if isinstance(x,(int,float)) and isinstance(y,(int,float)) else None})
numeric_changes(a,b)
lib=ctypes.CDLL(str(next((Path(np.__file__).parent.parent/'numpy.libs').glob('*openblas*.so'))))
core=lib.scipy_openblas_get_corename64_;core.restype=ctypes.c_char_p
config=lib.scipy_openblas_get_config64_;config.restype=ctypes.c_char_p
name=sys.argv[1];out=proof/('CROSS-KERNEL-'+name);out.mkdir(exist_ok=False)
(out/'farm-box-source.glb').write_bytes(raw);(out/'farm-box-source.json').write_bytes(sidecarbytes)
result={'requested_core':os.environ.get('OPENBLAS_CORETYPE'),'actual_core':core().decode(),'blas_config':config().decode(),'numpy':np.__version__,'python':sys.version,'elapsed':time.monotonic()-start,'candidate_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'generated_glb_sha256':hashlib.sha256(raw).hexdigest(),'generated_sidecar_sha256':hashlib.sha256(sidecarbytes).hexdigest(),'old_glb_sha256':hashlib.sha256(old).hexdigest(),'old_vs_new_complete_binary_chunk_exact':ab==bb,'old_binary_chunk_sha256':hashlib.sha256(ab).hexdigest(),'new_binary_chunk_sha256':hashlib.sha256(bb).hexdigest(),'emitted_geometry_attributes_indices_material_embedded_texture_bytes_unchanged':ab==bb and a['meshes']==b['meshes'] and a['materials']==b['materials'],'accessor_JSON_unchanged':a['accessors']==b['accessors'],'changed_GLTF_JSON_fields':changes,'maximum_JSON_bound_numeric_change_m':max((x['absolute_delta']or 0)for x in changes),'native_checker_and_thresholds_unmodified':True}
(out/'QUALIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k!='changed_GLTF_JSON_fields'}))
