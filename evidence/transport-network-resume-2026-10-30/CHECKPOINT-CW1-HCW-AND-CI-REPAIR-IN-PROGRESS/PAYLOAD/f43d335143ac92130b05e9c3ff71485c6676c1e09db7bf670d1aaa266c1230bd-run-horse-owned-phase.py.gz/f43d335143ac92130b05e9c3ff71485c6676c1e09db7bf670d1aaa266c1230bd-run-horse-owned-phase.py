#!/usr/bin/env python3
"""Owned native commands; preserve original results and source/resource boundaries."""
from pathlib import Path
import datetime, hashlib, json, os, re, shutil, subprocess, sys, time

W = Path('/workspace/chicago-horse-delivery-20261030')
A = W / 'chicago/4d'
P = Path('/workspace/horse-delivery-resume-20261030')
GUARD = Path('/workspace/.cloud-setup/transport-network-resume-20261030/resource_guard.py')
BASELINE = GUARD.with_name('RESTORED-RUNTIME-BASELINE.json')
SUP = Path('/workspace/.cloud-setup/transport-supervise.py')
EXPECTED_GUARD = 'ac68e89608a6828d71d0933a4e3403ca09585a8f362551e28582e33ea4a73a3c'
EXPECTED_BASELINE = '8ca3ae1358d85ad1dbf3a992c19423bef84f49675947e756d9455d6952680942'
CW = '1ed797136be6841ca6095c1d7a2b8be7c8599953'
ORIGINAL_H = '2177b51b1f6d0c4aedfbc5374f4f1e2ce1fa7d1b'
BASE_REF = 'refs/remotes/horse-cw-20261030/dev'

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(W), *args])

def write(p, obj):
    p.write_text(json.dumps(obj, indent=2) + '\n')

def pins():
    assert sha(GUARD) == EXPECTED_GUARD
    assert sha(BASELINE) == EXPECTED_BASELINE
    for r in json.loads((P/'PRE-MERGE-IMMUTABLE-FREEZE.json').read_text())['records']:
        assert sha(W/r['path']) == r['sha256'], 'Immutable qualification input changed: '+r['path']

def source():
    index = git('ls-files', '--stage', '-z')
    files = {}
    for raw in git('ls-files', '-z').split(b'\0'):
        if not raw:
            continue
        rel = raw.decode()
        f = W/rel
        if f.is_symlink():
            b = str(f.readlink()).encode(); mode = '120000'
        elif f.exists():
            b = f.read_bytes(); mode = '100755' if f.stat().st_mode & 0o111 else '100644'
        else:
            files[rel] = {'missing': True}; continue
        files[rel] = {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(), 'mode': mode}
    return {'HEAD': git('rev-parse', 'HEAD').decode().strip(),
            'semantic_index_sha256': hashlib.sha256(index).hexdigest(),
            'files': files}

def main():
    phase, folder = sys.argv[1:]
    assert phase in ['resolve', 'preflight']
    out = P/folder
    out.mkdir(exist_ok=False)
    pins()
    before = source(); write(out/'SOURCE-BEFORE.json', before)
    assert before['HEAD'] == ORIGINAL_H
    assert git('rev-parse', 'MERGE_HEAD').decode().strip() == CW
    if phase == 'resolve':
        cap = 1800; command = ['node', 'tools/rederive.mjs', '--resolve']
        manifest = json.loads((A/'tools/derived_manifest.json').read_text())
        allowed = {x for s in manifest['steps'] for x in s.get('resolves', [])}
    else:
        cap = 1200; command = ['bash', 'tools/preflight.sh']
        assert not git('diff', '--name-only', '--diff-filter=U').strip()
        allowed = set()
    native = out/'native'
    env = os.environ.copy()
    env.update(CHECK_JOBS='4', C4D_GATE_REQUIRE_READERS='1', C4D_GATE_REQUIRE_BASE='1',
               CHECK_TIMINGS=str(out/'ACTUAL-CHECK-TIMINGS.tsv'), BASE=BASE_REF)
    env.pop('CHICAGO_TICKETS_DIR', None)
    write(out/'COMMAND.json', {'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'phase': phase, 'native_command': command, 'native_cap_seconds': cap,
        'label': 'CANONICAL-NATIVE-RESOLVE' if phase == 'resolve' else
                 'FUNCTIONAL-CLOUD-1200-NOT-600-BUDGET-QUALIFICATION',
        'BASE': BASE_REF, 'BASE_SHA': git('rev-parse', BASE_REF).decode().strip(),
        'CHECK_JOBS': 4, 'required_readers': 1, 'required_base': 1,
        'guard_sha256': sha(GUARD), 'baseline_sha256': sha(BASELINE),
        'supervisor_sha256': sha(SUP), 'controller_sha256': sha(__file__)})
    subprocess.run([sys.executable, str(GUARD), 'capture', str(out/'RESOURCE-BEFORE.json')], check=True)
    started = time.monotonic()
    with (out/'SUPERVISOR-STDOUT.log').open('wb') as log:
        rc = subprocess.run([sys.executable, str(SUP), '--prefix', str(native), '--cwd', str(A),
                             '--timeout', str(cap), '--', *command], env=env,
                            stdout=log, stderr=subprocess.STDOUT).returncode
    # Read the actual owned command and cleanup, even when native fails.
    actual = json.loads(Path(str(native)+'.result.json').read_text())
    cleanup = json.loads(Path(str(native)+'.cleanup.json').read_text())
    after_capture = subprocess.run([sys.executable, str(GUARD), 'capture', str(out/'RESOURCE-AFTER.json')]).returncode
    pair_rc = subprocess.run([sys.executable, str(GUARD), 'pair', str(out/'RESOURCE-BEFORE.json'),
                              str(out/'RESOURCE-AFTER.json'), str(out/'RESOURCE-PAIR.json')]).returncode
    after = source(); write(out/'SOURCE-AFTER.json', after)
    changed = [x for x in sorted(set(before['files']) | set(after['files']))
               if before['files'].get(x) != after['files'].get(x)]
    unallowed = [x for x in changed if x not in allowed]
    if phase == 'preflight':
        for name in ['preflight-check.log', 'preflight-cl.log', 'preflight-ids.log']:
            f = Path('/tmp')/name
            if f.exists(): shutil.copy2(f, out/name)
    raw = Path(str(native)+'.log').read_text(errors='replace')
    settled = bool(re.search(r'and the last one moved nothing', raw)) and 'WARNING: the tail' not in raw
    errors = []
    try: pins()
    except Exception as exc: errors.append(str(exc))
    if rc != 0 or actual['returncode'] != 0 or actual['timed_out']: errors.append('Native command did not pass')
    if actual['requested_timeout_seconds'] != cap or actual['effective_timeout_seconds'] != cap or actual['timeout_override_reason']:
        errors.append('Native cap changed')
    if not cleanup['cleanup_complete'] or cleanup['remaining_owned_children']: errors.append('Owned cleanup incomplete')
    if after_capture or pair_rc: errors.append('Resource closure rejected')
    if before['HEAD'] != after['HEAD']: errors.append('HEAD changed')
    if unallowed: errors.append('Unexpected tracked source changes: '+repr(unallowed))
    if phase == 'resolve':
        if not settled: errors.append('No genuine final unchanged settlement lap')
        if git('diff', '--name-only', '--diff-filter=U').strip(): errors.append('Unresolved conflicts remain')
    elif before != after:
        errors.append('Preflight source/index changed')
    result = {'state': 'PASS' if not errors else 'NONPASS', 'phase': phase,
              'seconds': time.monotonic()-started, 'actual_native': actual, 'actual_cleanup': cleanup,
              'resource_pair_accepted': pair_rc == 0 and after_capture == 0,
              'tracked_changed_paths': changed, 'unallowed_changed_paths': unallowed,
              'actual_final_settled_tail': settled if phase == 'resolve' else None,
              'HEAD_unchanged': before['HEAD'] == after['HEAD'],
              'index_unchanged': before['semantic_index_sha256'] == after['semantic_index_sha256'],
              'errors': errors}
    if not git('diff', '--name-only', '--diff-filter=U').strip():
        result['TREE'] = git('write-tree').decode().strip()
        result['APP'] = git('rev-parse', result['TREE']+':chicago/4d').decode().strip()
    write(out/'ACTUAL-CLOSED.json', result)
    print(json.dumps(result))
    return 0 if not errors else 1

if __name__ == '__main__':
    raise SystemExit(main())
