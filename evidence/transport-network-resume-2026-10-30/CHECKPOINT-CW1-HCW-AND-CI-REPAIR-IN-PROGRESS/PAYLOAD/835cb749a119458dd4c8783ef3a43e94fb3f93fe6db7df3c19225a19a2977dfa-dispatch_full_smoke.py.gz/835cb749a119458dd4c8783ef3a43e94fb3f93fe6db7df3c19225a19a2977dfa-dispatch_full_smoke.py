"""Dispatch one existing full-viewport workflow, once, bound to a checked branch head."""
import argparse, datetime, json, time, urllib.error, urllib.parse, urllib.request
from pathlib import Path

REPO = 'kevinrhaas/chicago'
WORKFLOW = 365585058
BASE = 'https://api.github.com/repos/'+REPO+'/'
ROOT = Path(__file__).with_name('ci')

def api(method, path, data=None):
    body = None if data is None else json.dumps(data).encode()
    request = urllib.request.Request(BASE+path, data=body, method=method,
        headers={'Accept':'application/vnd.github+json',
                 'X-GitHub-Api-Version':'2022-11-28',
                 'User-Agent':'Codex-transport-delivery',
                 'Content-Type':'application/json'})
    with urllib.request.urlopen(request, timeout=30) as response:
        raw = response.read()
        return response.status, json.loads(raw) if raw else None

def runs(branch, sha):
    query=urllib.parse.urlencode(dict(branch=branch,head_sha=sha,event='workflow_dispatch',per_page=100))
    _, data=api('GET',f'actions/workflows/{WORKFLOW}/runs?'+query)
    return [r for r in data['workflow_runs']
            if r['head_sha']==sha and r['head_branch']==branch and r['event']=='workflow_dispatch']

def save(path, receipt):
    path.write_text(json.dumps(receipt,indent=2)+'\n')

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--branch',required=True)
    parser.add_argument('--sha',required=True)
    parser.add_argument('--viewport',choices=['mobile','desktop'],required=True)
    args=parser.parse_args()
    assert args.branch.startswith('steward/') and len(args.sha)==40 and all(c in '0123456789abcdef'for c in args.sha)
    ROOT.mkdir(exist_ok=True)
    out=ROOT/(args.branch.replace('/','_')+'-'+args.sha[:12]+'-'+args.viewport+'-DISPATCH.json')
    assert not out.exists(),'Existing dispatch receipt: inspect/discover it; never blindly dispatch twice'
    _, ref=api('GET','git/ref/heads/'+urllib.parse.quote(args.branch,safe='/'))
    assert ref['object']['sha']==args.sha,'Public source moved; do not test an unbound revision'
    previous={r['id']for r in runs(args.branch,args.sha)}
    receipt=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        repo=REPO,workflow_id=WORKFLOW,branch=args.branch,expected_head_sha=args.sha,
        viewport=args.viewport,stage='',original_workflow_timeout_minutes=150,
        body={'ref':args.branch,'inputs':{'viewport':args.viewport,'stage':''}},
        previous_matching_run_ids=sorted(previous),state='DISPATCH_ATTEMPT_BEGIN',
        no_assertion_quality_or_workflow_changes=True)
    save(out,receipt)
    try:
        status,_=api('POST',f'actions/workflows/{WORKFLOW}/dispatches',receipt['body'])
        assert status in (200,201,204)
        receipt.update(state='ACCEPTED_WAITING_RUN_DISCOVERY',http_status=status)
        save(out,receipt)
    except urllib.error.HTTPError as error:
        receipt.update(state='HTTP_REJECTED',http_status=error.code,error=error.read().decode()[:1500])
        save(out,receipt)
        print(json.dumps({'receipt':str(out),**receipt}))
        raise SystemExit(1)
    except Exception as error:
        receipt.update(state='POST_OUTCOME_UNKNOWN_DO_NOT_RETRY',error=repr(error))
        save(out,receipt)
        print(json.dumps({'receipt':str(out),**receipt}))
        raise SystemExit(2)
    for attempt in range(6):
        found=[r for r in runs(args.branch,args.sha)if r['id']not in previous]
        if len(found)==1:
            run=found[0]
            receipt.update(state='BOUND_TO_ACTUAL_RUN',run_id=run['id'],run_url=run['html_url'],
                actual_head_sha=run['head_sha'],run_status=run['status'],run_conclusion=run['conclusion'])
            save(out,receipt)
            print(json.dumps({'receipt':str(out),'run_id':run['id'],'url':run['html_url'],
                              'head_sha':run['head_sha'],'viewport':args.viewport,'stage':''}))
            break
        if len(found)>1:
            receipt.update(state='MULTIPLE_NEW_RUNS_REQUIRE_INPUT_LOG_VERIFICATION',candidate_run_ids=[r['id']for r in found])
            save(out,receipt)
            print(json.dumps({'receipt':str(out),**receipt}))
            break
        if attempt<5:
            time.sleep(8)
    else:
        print(json.dumps({'receipt':str(out),'state':receipt['state'],'instruction':'Discover matching run without another POST'}))
