#!/usr/bin/env python3
from pathlib import Path
import hashlib, importlib.util, json, os, subprocess, sys

P = Path('/workspace/horse-delivery-resume-20261030')
spec = importlib.util.spec_from_file_location('horse_native', P/'run-horse-owned-phase.py')
n = importlib.util.module_from_spec(spec)
spec.loader.exec_module(n)
assert len(sys.argv) == 3
full, folder = sys.argv[1:]
OUT = P/folder
OUT.mkdir(exist_ok=False)
n.pins()
assert json.loads((P/full/'ACTUAL-CLOSED.json').read_text())['state'] == 'PASS'
assert json.loads((P/full/'INDEPENDENT-ACTUAL-CLOSURE-READBACK.json').read_text())['state'] == 'PASS'
env = os.environ.copy()
env.update(CHECK_JOBS='4', C4D_GATE_REQUIRE_READERS='1', C4D_GATE_REQUIRE_BASE='1')
env.pop('CHICAGO_TICKETS_DIR', None)
before = OUT/'RESOURCE-BEFORE.json'
after = OUT/'RESOURCE-AFTER.json'
pair = OUT/'RESOURCE-PAIR.json'
subprocess.run([sys.executable, str(n.GUARD), 'capture', str(before)], check=True)
command = [sys.executable, str(P/'commit-check-push-horse.py'), full, folder+'/inner']
(OUT/'COMMAND.json').write_text(json.dumps({'command': command, 'original_cap_seconds': 300,
    'guard_sha256': n.sha(n.GUARD), 'baseline_sha256': n.sha(n.BASELINE),
    'supervisor_sha256': n.sha(n.SUP), 'controller_sha256': n.sha(__file__),
    'inner_executor_sha256': n.sha(P/'commit-check-push-horse.py'),
    'actual_fullgate_folder': str(P/full), 'normal_feature_push_only': True,
    'no_PR_API_or_DEV_write': True}, indent=2)+'\n')
prefix = OUT/'native-checked-delivery'
with (OUT/'SUPERVISOR-STDOUT.log').open('wb') as log:
    rc = subprocess.run([sys.executable, str(n.SUP), '--prefix', str(prefix), '--cwd', str(n.W),
        '--timeout', '300', '--', *command], env=env, stdout=log, stderr=subprocess.STDOUT).returncode
after_rc = subprocess.run([sys.executable, str(n.GUARD), 'capture', str(after)]).returncode
pair_rc = subprocess.run([sys.executable, str(n.GUARD), 'pair', str(before), str(after), str(pair)]).returncode
actual = json.loads(Path(str(prefix)+'.result.json').read_text())
cleanup = json.loads(Path(str(prefix)+'.cleanup.json').read_text())
innerfile = OUT/'inner/ACTUAL-CHECKED-HORSE-COMMIT-PUSH.json'
inner = json.loads(innerfile.read_text()) if innerfile.exists() else None
errors = []
if rc or actual['returncode'] or actual['timed_out']: errors.append('Actual owned delivery did not pass')
if actual['requested_timeout_seconds'] != 300 or actual['effective_timeout_seconds'] != 300 or actual['timeout_override_reason']:
    errors.append('Delivery cap changed')
if not cleanup['cleanup_complete'] or cleanup['remaining_owned_children']: errors.append('Incomplete owned cleanup')
if after_rc or pair_rc: errors.append('Resource closure rejected')
if not inner or inner['state'] != 'PASS': errors.append('Actual inner checked delivery did not pass')
try: n.pins()
except Exception as exc: errors.append(str(exc))
result = {'state': 'PASS' if not errors else 'NONPASS', 'actual_native': actual,
    'actual_cleanup': cleanup, 'resource_pair_accepted': not after_rc and not pair_rc,
    'actual_inner': inner, 'errors': errors}
(OUT/'ACTUAL-CLOSED.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result), flush=True)
raise SystemExit(0 if not errors else 1)
