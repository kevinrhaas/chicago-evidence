#!/usr/bin/env python3
"""Run only after the actual final merged-source functional preflight passes."""
from pathlib import Path
import datetime, hashlib, importlib.util, json, os, subprocess, sys, time

P = Path('/workspace/horse-delivery-resume-20261030')
W = Path('/workspace/chicago-horse-delivery-20261030')
A = W/'chicago/4d'
H = '2177b51b1f6d0c4aedfbc5374f4f1e2ce1fa7d1b'
CW = '1ed797136be6841ca6095c1d7a2b8be7c8599953'
REMOTE_BRANCH = 'refs/heads/steward/t3088-horse-photoquality-20261026'
BASE = 'refs/remotes/horse-headcheck-20261030/dev'

spec = importlib.util.spec_from_file_location('horse_guarded_native', P/'run-horse-owned-phase.py')
native = importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)

def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(W), *args], text=True).strip()

def run(label, cmd, cwd, timeout):
    start = time.monotonic()
    logfile = OUT/(label+'.log')
    with logfile.open('wb') as log:
        r = subprocess.run(cmd, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
    row = {'label': label, 'command': cmd, 'returncode': r.returncode,
           'seconds': time.monotonic()-start, 'log': str(logfile),
           'log_sha256': hashlib.sha256(logfile.read_bytes()).hexdigest()}
    records.append(row)
    assert r.returncode == 0, label+' failed; preserve actual state and stop'
    return row

assert len(sys.argv) == 3, 'usage: commit-check-push-horse.py CLOSED-PREFLIGHT-FOLDER FRESH-OUTPUT-FOLDER'
FULL = P/sys.argv[1]
OUT = P/sys.argv[2]
OUT.mkdir(exist_ok=False)
records = []
result = {'state': 'NONPASS', 'original_H': H, 'checked_W_CW': CW,
          'broad_photo_gait_rider_driver_world_acceptance': 'OPEN',
          'H6_full12_world_verdict': 'NONPASS5.636/12_UNCHANGED', 'records': records}
try:
    closed = json.loads((FULL/'ACTUAL-CLOSED.json').read_text())
    readback = json.loads((FULL/'INDEPENDENT-ACTUAL-CLOSURE-READBACK.json').read_text())
    qualified = json.loads((FULL/'SOURCE-AFTER.json').read_text())
    assert closed['phase'] == 'preflight' and closed['state'] == readback['state'] == 'PASS'
    assert readback['closed_receipt_sha256'] == hashlib.sha256((FULL/'ACTUAL-CLOSED.json').read_bytes()).hexdigest()
    assert readback['native_log_sha256'] == hashlib.sha256((FULL/'native.log').read_bytes()).hexdigest()
    assert closed['actual_native']['returncode'] == 0 and not closed['actual_native']['timed_out']
    assert closed['actual_native']['requested_timeout_seconds'] == closed['actual_native']['effective_timeout_seconds'] == 1200
    assert closed['actual_cleanup']['cleanup_complete'] and not closed['actual_cleanup']['remaining_owned_children']
    assert closed['resource_pair_accepted'] and readback['native_preflight_all_three_questions_pass']
    native.pins()
    actual = native.source()
    assert actual == qualified and actual['HEAD'] == H, 'Actual full-gated source/index no longer exact'
    assert git('rev-parse', 'MERGE_HEAD') == CW
    assert not git('diff', '--name-only', '--diff-filter=U')
    assert git('write-tree') == closed['TREE']
    assert git('ls-remote', 'origin', REMOTE_BRANCH).split()[0] == H, 'Public H branch changed externally'
    run('fetch-actual-current-DEV', ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false',
        'fetch', '--filter=blob:none', '--no-tags', '--no-write-fetch-head', "--refmap=", 'origin',
        'refs/heads/dev:'+BASE], W, 30)
    base = git('rev-parse', BASE)
    result.update(actual_current_DEV=base, full_preflight_BASE=readback['BASE_before_recorded'],
                  full_preflight_TREE=closed['TREE'], full_preflight_APP=closed['APP'],
                  full_preflight_seconds=closed['actual_native']['command_seconds'],
                  source_index_before_commit=actual['semantic_index_sha256'])
    message = ('Merge checked wagon and DEV into quiet standing horse motion\n\n'
        'Retain the finite-qualified quiet head/neck selection and bounded eye work while '
        'integrating checked wagon CW1ed7971 through normal history.\n\n'
        'The actual merged-source functional preflight passed under1200; this does not '
        'qualify the600-second performance goal. Broad photo quality, gait, riding, '
        'driving and town interaction remain open. Historical H6 full-cycle observation '
        'remains NONPASS5.636/12; its certificate and source identity are not retargeted.')
    run('normal-merge-commit', ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false',
        'commit', '-m', message], W, 30)
    head = git('rev-parse', 'HEAD')
    assert git('show', '-s', '--format=%P', 'HEAD').split() == [H, CW]
    assert git('rev-parse', 'HEAD^{tree}') == closed['TREE']
    assert not git('status', '--porcelain')
    result['new_HEAD'] = head
    commands = [
        ('newHEAD-changelog-entry', ['node', 'tools/check-changelog-entry.mjs', base, 'HEAD']),
        ('newHEAD-ID-collision', ['node', 'tools/resolve_id_collisions.mjs', '--base', base, '--check']),
        ('newHEAD-changelog-contract', ['node', 'tools/check-changelog.mjs']),
        ('newHEAD-pending-entries', ['node', 'tools/changelog-entries.mjs', '--check']),
        ('newHEAD-pinned-history', ['node', 'tools/changelog-history.mjs', '--base', base]),
    ]
    for label, command in commands:
        run(label, command, A, 30)
    run('newHEAD-whitespace', ['git', 'diff', '--check', base, 'HEAD'], W, 30)
    native.pins()
    after_commit = native.source()
    assert after_commit['files'] == actual['files']
    assert after_commit['semantic_index_sha256'] == actual['semantic_index_sha256']
    assert not git('status', '--porcelain')
    assert git('ls-remote', 'origin', REMOTE_BRANCH).split()[0] == H, 'Public branch changed before normal push'
    assert git('rev-parse', 'HEAD') == head, 'Local checked HEAD changed before normal push'
    run('normal-original-H-feature-push', ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false',
        'push', 'origin', head+':'+REMOTE_BRANCH], W, 60)
    public = git('ls-remote', 'origin', REMOTE_BRANCH).split()[0]
    assert public == head and not git('status', '--porcelain')
    final = native.source()
    assert final == after_commit
    result.update(state='PASS', public_HEAD=public, TREE=closed['TREE'], APP=closed['APP'],
                  semantic_index_sha256=final['semantic_index_sha256'], clean=True,
                  original_qualified_TREE_preserved=True, normal_push_no_force=True,
                  all_five_committed_HEAD_questions_pass=True)
except Exception as exc:
    result['error'] = repr(exc)
    raise
finally:
    result['closed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUT/'ACTUAL-CHECKED-HORSE-COMMIT-PUSH.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result), flush=True)
