from pathlib import Path
import os,subprocess,json,datetime
repo=Path('/tmp/chicago-transport-tickets-20261030');cwd=Path('/workspace/chicago/chicago/4d');env=dict(os.environ,CHICAGO_TICKETS_DIR=str(repo))
def git(*a):return subprocess.check_output(['git','-C',str(repo),*a],text=True).strip()
assert not git('status','--porcelain')
by='Codex root coordinating resumed existing wagon PR1340 and saved horse/Otis branches after verified API restoration'
claims=[]
# Single-ticket native CAS commands stop on collision; --force only acknowledges
# the known existing branches/PR that this SAME user-authorized work resumes.
# Never let grouped-force retry over a rival's newly published live claim.
for tid in ['T-2793','T-3173','T-3088','T-2803','T-1790','T-1789']:
 subprocess.run(['git','-C',str(repo),'fetch','origin','main'],check=True)
 subprocess.run(['git','-C',str(repo),'merge','--ff-only','--no-stat','origin/main'],check=True)
 p=next(p for p in repo.glob('T-*/*.md')if p.name.startswith(tid+'-'));before=p.read_text().split('---',2)[1]
 assert 'state: open' in before and 'claimed_by: null' in before,(tid,before)
 subprocess.run(['node','tools/ticket.mjs','claim',tid,'--force','--by',by],cwd=cwd,env=env,check=True)
 after=p.read_text().split('---',2)[1];assert 'state: claimed' in after and by in after
 claims.append({'ticket':tid,'before':before,'after':after,'commit':git('rev-parse','HEAD')})
 assert not git('status','--porcelain')
 print(tid+' ACTUALLY claimed with normal single-ticket CAS',flush=True)
status=subprocess.run(['node','tools/ticket.mjs','lap','1340','--status'],cwd=cwd,env=env,text=True,capture_output=True)
assert status.returncode==0 and status.stdout.startswith('free lap/pr-1340'),status.stdout
subprocess.run(['node','tools/ticket.mjs','lap','1340','--by',by],cwd=cwd,env=env,check=True)
status=subprocess.run(['node','tools/ticket.mjs','lap','1340','--status'],cwd=cwd,env=env,text=True,capture_output=True);assert status.returncode==3 and by in status.stdout
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'claims':claims,'PR1340_lap_status':status.stdout,'existing_branch_acknowledgment_only_no_other_live_claim_overridden':True,'remote_exact_clean':git('ls-remote','origin','refs/heads/main').split()[0]==git('rev-parse','HEAD')and not git('status','--porcelain')}
p=Path('/workspace/.cloud-setup/transport-network-resume-20261030/ACTUAL-CLAIMS-AND-PR1340-LAP.json');p.write_text(json.dumps(r,indent=2)+'\n');print('All six exact-open claims and initially-free PR1340 lap acquired; receipt '+str(p),flush=True)
