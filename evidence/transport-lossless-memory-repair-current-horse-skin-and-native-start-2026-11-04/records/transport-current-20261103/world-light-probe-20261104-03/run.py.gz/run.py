from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,subprocess,sys,datetime
D=Path(__file__).resolve().parent
R=Path('/workspace/chicago-world-smoke-repair-20261104'); A=R/'chicago/4d'
ORIGINALS=[Path('/workspace/chicago-driver-pace-rendezvous-20261104'),Path('/workspace/chicago-transport-current-20261103')]
def save(n,x): (D/n).write_text(json.dumps(x,indent=2)+'\n')
def git(r,*args): return subprocess.check_output(['git','-C',str(r),*args],env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'),timeout=30)
def source(r):
 return dict(HEAD=git(r,'rev-parse','HEAD').decode().strip(),TREE=git(r,'rev-parse','HEAD^{tree}').decode().strip(),index_sha256=hashlib.sha256(git(r,'ls-files','--stage','-z')).hexdigest(),status=git(r,'status','--porcelain=v1','--untracked-files=all').decode(),diff_sha256=hashlib.sha256(git(r,'diff','HEAD','--binary')).hexdigest())
lock=open('/workspace/.cloud-setup/transport-8cec-generated-lap-20261030/ROOT-SOLE-CANONICAL-OWNER.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
spec=importlib.util.spec_from_file_location('guard','/workspace/.cloud-setup/transport-current-20261103/resource_guard.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
original={str(r):source(r) for r in ORIGINALS};own=source(R)
files={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [A/'tools/smoke_renderer.mjs',A/'tools/world_smoke_contracts.mjs',A/'tools/test_world_smoke_contracts.mjs',A/'tools/test_green_tree_yard_modes.py']}
probe=Path('/workspace/.cloud-setup/transport-current-20261103/world-phase2-probes-20261104/probe-v3.mjs');probe_hash=hashlib.sha256(probe.read_bytes()).hexdigest()
def pins():return hashlib.sha256(probe.read_bytes()).hexdigest()==probe_hash and {str(r):source(r) for r in ORIGINALS}==original and source(R)==own and all(hashlib.sha256((R/p).read_bytes()).hexdigest()==h for p,h in files.items())
browser='/workspace/.cloud-setup/transport-browser141-20261103/chromium_headless_shell-1194/chrome-linux/headless_shell'
version=subprocess.check_output([browser,'--version'],timeout=5).decode().strip();assert version=='Chromium 141.0.7390.37'
env=dict(os.environ,PW_EXECUTABLE=browser,PLAYWRIGHT_BROWSERS_PATH='/workspace/.cloud-setup/transport-browser141-20261103',PYTHONDONTWRITEBYTECODE='1',SMOKE_VIEWPORT='mobile',SMOKE_STAGE='2',SMOKE_PORT='4193');env.pop('CHICAGO_TICKETS_DIR',None)
save('OWNER.json',dict(owner='world_smoke_repair',pid=os.getpid(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),originals=original,source=own,files=files,browser=version))
ledger=[];status='RUNNING'
try:
 for label,command,cap in [('light-probe',['node','/workspace/.cloud-setup/transport-current-20261103/world-phase2-probes-20261104/probe-v3.mjs',str(D),'light'],600)]:
  assert pins(),'source pin changed'
  before=g.snapshot();save(label+'-RESOURCE-BEFORE.json',before);assert g.check(before)['accepted']
  save('STATE.json',dict(status='RUNNING',active=label,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
  with (D/(label+'.stdout')).open('xb') as stdout:
   q=subprocess.run([sys.executable,'/workspace/.cloud-setup/transport-supervise.py','--prefix',str(D/label),'--cwd',str(A),'--timeout',str(cap),'--',*command],env=env,stdout=stdout,stderr=subprocess.STDOUT)
  result=json.loads((D/(label+'.result.json')).read_text());cleanup=json.loads((D/(label+'.cleanup.json')).read_text());after=g.snapshot();save(label+'-RESOURCE-AFTER.json',after);resources=g.pair(before,after)
  row=dict(label=label,result=result,cleanup=cleanup,resources=resources,source_unchanged=pins());ledger.append(row);save('LEDGER.json',ledger)
  assert not result['timed_out'] and result['requested_timeout_seconds']==cap and result['effective_timeout_seconds']==cap and result['timeout_override_reason'] is None and cleanup['cleanup_complete'] and not cleanup['remaining_owned_children'] and resources['accepted'] and pins()
  if q.returncode or result['returncode']:status=label.upper()+'_NONPASS';break
 else:status='LIGHT_PROBE_COMPLETE'
except BaseException as e:
 status='RUNNER_NONPASS';save('ERROR.json',dict(error=repr(e)))
finally:
 save('CLOSED.json',dict(status=status,ledger=ledger,originals_unchanged={str(r):source(r) for r in ORIGINALS}==original,own_pins_unchanged=pins(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
 print(json.dumps(dict(status=status,receipt=str(D/'CLOSED.json'))),flush=True)
 fcntl.flock(lock,fcntl.LOCK_UN)
sys.exit(0 if status=='LIGHT_PROBE_COMPLETE' else 1)
