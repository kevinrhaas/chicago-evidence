#!/usr/bin/env bash
set -euo pipefail
source /workspace/.cloud-setup/transport-activate.sh
exec /workspace/.cloud-setup/venv311/bin/python /workspace/.cloud-setup/transport-interaction-combined-fourpart-prepared-20261104/run_combined_fourpart.py --binding "${1:?Exact Root GO binding required}" --out "${2:?Fresh outside-repository output required}"
