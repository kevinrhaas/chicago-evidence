from pathlib import Path
import subprocess,os,json,hashlib,importlib.util,time
R=Path('/workspace/chicago-driver-interaction-integration-20261104');O=Path(__file__).parent;env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1');env.pop('GIT_NO_LAZY_FETCH',None)
def git(*args):return subprocess.run(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(R),*args],capture_output=True,env=env,timeout=90)
def ok(*args):
 p=git(*args)
 if p.returncode:raise RuntimeError(args[0]+': '+p.stderr.decode(errors='replace')[-500:])
 return p.stdout
old=json.loads((O/'BEFORE.json').read_text());assert ok('rev-parse','HEAD').decode().strip()==old['HEAD'];assert hashlib.sha256(ok('diff','HEAD','--binary')).hexdigest()==old['full_patch_sha256']
url=subprocess.check_output(['git','-C','/workspace/chicago-transport-current-20261103','config','--get','remote.origin.url']).decode().strip();ok('config','remote.public.url',url);ok('config','remote.public.promisor','true');ok('config','remote.public.partialclonefilter','blob:none')
ok('reset','--hard','HEAD')
for row in old['untracked']:
 p=R/row['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];p.unlink()
ok('checkout','-B','steward/t1790-interaction-integration-20261104','6eeeeaa26942efc79e7b822b387bdc3979adb939');ok('merge','--no-commit','--no-ff','b83f60edd8486afb3813b6d1ba5a8276425ac22b')
for patch in ['/workspace/.cloud-setup/transport-interaction-integration-prepared-20261104/REPAIR-AND-METADATA.patch','/workspace/.cloud-setup/transport-current-20261103/world-smoke-stage2-repair-20261104-01/full-review.patch',str(O/'REGISTRATION-MEASUREMENT.patch')]:ok('apply','--3way',patch)
ok('diff','--check');assert not ok('ls-files','-u');(O/'RECONCILED.json').write_text(json.dumps({'status':'TRUE_REVIEWED_6EEEE_NORMAL_MERGE_PLUS_EXACT_REPAIR_WORLD_METADATA_AND_MEASURED_TEST_REGISTRATION','HEAD':ok('rev-parse','HEAD').decode().strip(),'MERGE_HEAD':ok('rev-parse','MERGE_HEAD').decode().strip(),'TREE':ok('write-tree').decode().strip(),'status':ok('status','--porcelain').decode(),'no_commit':True,'freshness_qualification':'reviewed6eeee; laterDEVfee068 observed separately, not retargeted'},indent=2)+'\n');print(str(O/'RECONCILED.json'))
