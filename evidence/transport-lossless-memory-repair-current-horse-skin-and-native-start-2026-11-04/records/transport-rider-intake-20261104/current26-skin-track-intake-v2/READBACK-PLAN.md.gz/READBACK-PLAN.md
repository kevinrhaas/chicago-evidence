# Current26 skin/track readback — prepared, unrun

This is a read-only extension of Root's actual1.017s rest-intake PASS. Source assets
are fixed standing7ce84d and movingad9dc0; no old6e9 body, rig or fit is loaded.
Body, textures, source weights,26-joint rig and animations remain unchanged.

The helper parses original GLB bytes through the same pinned native Three185 /
GLTFLoader CPU-only material adapter. It does not load images, create a mixer,
evaluate an animation/interpolant, construct tack or solve a human pose. It records:

* All12,838 vertices /17,390 rest triangles and26 joint/rest/inverse-bind matrices.
* Per mesh, exact packed source JOINTS_0/WEIGHTS_0 component bytes, declaration
  types/normalization flags, and native getter values as U32LE/F64LE tables.
  GLTFLoader's normal load path calls normalizeSkinWeights(). It is preserved and
  disclosed; the helper applies no additional normalization or repairs. Raw source
  bytes and actual native runtime values are deliberately distinguished.
* For all62 proposed fit references, original face/vertex IDs, barycentrics and
  each vertex's four actual native influences and named joint bindings. Its native
  rest vertices must match the already-measured BODY F64 values bit-for-bit.
  No barycentric weight averaging or new gear skinning/attachment is derived.
* Original declared animation channels/samplers and actual native track targets,
  joint membership, key counts/time endpoints, interpolation metadata and exact
  native time/value array hashes. Track targets must resolve on the real parsed
  scene. Non-joint targets, if any, remain visible in the report. No track is filtered
  away, sampled or interpreted as a fitted rider motion.

Standing/moving entire rest, raw/native skin and selected-vertex outputs must match.
The animation-track metadata stays specific to each original asset: quiet and walk
are deliberately different. Each asset's expected clip names come from Root's actual
native rest report. This is source/input measurement, not tack or riding acceptance.

After DIAG/WORLD/memory release and Root's explicit canonical-lane handoff, copy
ROOT-GO-UNBOUND-TEMPLATE.json to a NEW ROOT-ACTUAL-GO.json. Set approved and
canonical_lane_released true and preparation_manifest_sha256 to the reviewed frozen
PREPARATION-MANIFEST.json SHA256. The placeholder is fatal. Execute once:

    bash /workspace/.cloud-setup/transport-rider-intake-20261104/current26-skin-track-intake-v2/run_owned_once.sh \
      /workspace/.cloud-setup/transport-rider-intake-20261104/current26-skin-track-intake-v2/ROOT-ACTUAL-GO.json \
      /workspace/.cloud-setup/transport-rider-intake-20261104/current26-skin-track-intake-v2/actual-skin-track-01

Original60s native readback child caps,180s enclosing orchestration, inherited
single-CPU affinity/math threads1, canonical flock, unchanged3f49 resource epoch /
floors, fresh output and supervised cleanup remain. Input/vendor/preparation hashes
are checked before/after; actual emitted files are reread and rehashed. No retry.
A timeout, source drift or nonzero native/cleanup/resource result is NONPASS.

Expected proof: actual-skin-track-01-driver.CLOSED.json must say
CURRENT26_NATIVE_SKIN_TRACK_INTAKE_MEASURED_NOT_FIT with actual outer0/cleanup0 /
resources accepted, two child0/cleanup0 (60s each), source pins exact and actual
RESULT.json NATIVE_SKIN_TRACK_PAIR_MEASURED_NOT_RIDER_FIT. Inspect each asset's
SKIN-TRACK-WITNESSES.json and binary hashes; do not manufacture that receipt now.

Next source decision after measured influences/track targets: create a separate
current26 gear builder and bind every current part to measured current surfaces /
rig, then test actual rest/pose contact. Every current gear part must face all17,390
horse triangles; all406 interpart pairs apply if29 parts are emitted. Historical
cf148/88 negatives and original topology/contact kernels remain controls only.

V2 narrowly aligns palette validation with the actual existing quiet native reader:
all NONZERO-weight indices must be valid current26 joints; unused zero-weight
out-of-palette padding is retained verbatim, individually recorded (including signed
zero), and receives a null joint-name label rather than an invented bone. Complete
raw/native tables keep every slot. No weights/indices, getters, loader behavior,
geometry, tracking, physical predicates, caps or quality settings are changed.
The stronger all-slot V1 helper remains historical UNRUN, not a failed asset proof.
