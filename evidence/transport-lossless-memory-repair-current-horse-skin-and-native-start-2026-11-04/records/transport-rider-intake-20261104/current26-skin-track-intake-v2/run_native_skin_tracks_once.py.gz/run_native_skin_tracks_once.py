#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
# Prepared only; command-level orchestration. No model work before actual ROOT GO.
from pathlib import Path
import argparse, hashlib, json, os, subprocess, sys
P=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def write(p,d):Path(p).write_text(json.dumps(d,indent=2)+'\n')
def verify():
 for f in load(P/'PREPARATION-MANIFEST.json')['files']:
  b=(P/f['file']).read_bytes();assert len(b)==f['bytes'] and H(b)==f['sha256'],f['file']
 pins=load(P/'PINNED-INPUTS.json')
 for f in pins['files']:
  b=Path(f['path']).read_bytes();assert len(b)==f['bytes'] and H(b)==f['sha256'],f['path']
 return pins
p=argparse.ArgumentParser();p.add_argument('--go',required=True);p.add_argument('--out',required=True);a=p.parse_args()
pins=verify();go=load(a.go)
assert go['approved'] is True and go['canonical_lane_released'] is True
assert go['preparation_manifest_sha256']==H((P/'PREPARATION-MANIFEST.json').read_bytes()),'Actual GO must bind reviewed complete preparation'
assert go['pins_sha256']==H((P/'PINNED-INPUTS.json').read_bytes())
assert go['native_script_sha256']==H((P/'native_current26_skin_tracks.mjs').read_bytes())
out=Path(a.out).resolve();assert out.parent==P and not out.exists();out.mkdir()
initial_affinity=sorted(os.sched_getaffinity(0));assert initial_affinity
selected_cpu=initial_affinity[0];os.sched_setaffinity(0,{selected_cpu})
assert os.sched_getaffinity(0)=={selected_cpu}
python='/workspace/.cloud-setup/venv311/bin/python';node='/workspace/.cloud-setup/node-v22.22.0-linux-x64/bin/node'
sup='/workspace/.cloud-setup/transport-supervise.py';rows=[]
env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
for key in ('standing7ce','movingad9'):
 prefix=str(out/key)
 cmd=[python,sup,'--prefix',prefix,'--cwd',str(P),'--timeout','60','--',node,str(P/'native_current26_skin_tracks.mjs'),'--asset',key,'--out',str(out/(key+'-rest'))]
 with (out/(key+'.supervisor.stdout')).open('wb')as f:
  rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=75,check=False).returncode
 result=load(prefix+'.result.json');cleanup=load(prefix+'.cleanup.json')
 rows.append({'asset':key,'command':cmd,'outer_returncode':rc,'result':result,'cleanup':cleanup})
 write(out/'ATTEMPTS.json',rows)
 assert rc==0 and result['returncode']==0 and not result['timed_out'],key
 assert result['requested_timeout_seconds']==result['effective_timeout_seconds']==60 and result['timeout_override_reason'] is None
 assert cleanup['cleanup_complete']and not cleanup['remaining_owned_children'],key
 verify()
# Compare all actual world/body/joint/index outputs rather than transfer a previous fit.
reports=[]
for key in ('standing7ce','movingad9'):
 report_path=out/(key+'-rest')/'SKIN-TRACK-WITNESSES.json'
 report=load(report_path)
 for stream in report['outputs']:
  filename=stream['file'];assert Path(filename).name==filename
  raw=(report_path.parent/filename).read_bytes()
  assert len(raw)==stream['bytes'] and H(raw)==stream['sha256'],filename
 reports.append(report)
a,b=reports
for key in ('total_vertices','total_triangles','actual_skin_joint_count','meshes','draft_guides','selected_fit_faces'):
 assert a[key]==b[key],f'Actual rest witness equality: {key}'
# Mesh report equality includes each complete native emitted stream hash.
verify()
write(out/'RESULT.json',{'schema':'current26-native-skin-track-pair-v2','status':'NATIVE_SKIN_TRACK_PAIR_MEASURED_NOT_RIDER_FIT',
 'assets':pins['assets'],'native_reports':[{ 'path':str(out/(key+'-rest')/'SKIN-TRACK-WITNESSES.json'),
 'sha256':H((out/(key+'-rest')/'SKIN-TRACK-WITNESSES.json').read_bytes())}for key in('standing7ce','movingad9')],
 'complete_rest_surface_joint_and_native_skin_outputs_equal':True,'joint_tracks_reported_per_original_asset_without_pose_evaluation':True,'all_17390_triangles_retained':True,'source_inputs_after_exact':True,
 'rest_only':True,'new_saddle_seat_or_stirrup_anchors':False,'fit_or_load_or_photographic_acceptance':False,
 'historical_406_run_executed':False,'actual_one_cpu_affinity':{'initial_allowed_cpus':initial_affinity,'selected_cpu':selected_cpu,'inherited_child_affinity':[selected_cpu]},'emitted_stream_files_reread_and_hashed':True,'attempts':rows})
print('Current26 skin/track pair measured; no new weights, fit, pose or riding qualification')
