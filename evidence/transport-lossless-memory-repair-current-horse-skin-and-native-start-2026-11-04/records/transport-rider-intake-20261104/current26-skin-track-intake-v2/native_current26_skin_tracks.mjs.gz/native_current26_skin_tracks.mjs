// SPDX-License-Identifier: GPL-3.0-or-later
// PREPARED ONLY. Native rest/skin attribute and animation-track metadata; no pose/fit evaluation.
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { register } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';
const here = path.dirname(fileURLToPath(import.meta.url));
const sha = b => createHash('sha256').update(b).digest('hex');
const pinsPath = path.join(here, 'PINNED-INPUTS.json');
const pinsBytes = readFileSync(pinsPath), pins = JSON.parse(pinsBytes);
function verifyInputs() {
  assert.equal(sha(readFileSync(pinsPath)), sha(pinsBytes));
  for (const p of pins.files) {
    const b = readFileSync(p.path);
    assert.equal(b.length, p.bytes, p.path);
    assert.equal(sha(b), p.sha256, p.path);
  }
}
verifyInputs();
const args = process.argv.slice(2);
assert.equal(args.length, 4); assert.equal(args[0], '--asset'); assert.equal(args[2], '--out');
const asset = pins.assets[args[1]]; assert(asset, 'Explicit standing7ce/movingad9 selector');
const out = path.resolve(args[3]); assert(!existsSync(out), 'Fresh output only'); mkdirSync(out);
register(pathToFileURL(pins.native_vendor_loader), import.meta.url);
const T = await import('three'); assert.equal(T.REVISION, '185');
const { GLTFLoader } = await import('three/addons/loaders/GLTFLoader.js');
const { MeshoptDecoder } = await import('three/addons/libs/meshopt_decoder.module.js');
await MeshoptDecoder.ready;
const raw = readFileSync(asset.path); assert.equal(sha(raw), asset.sha256);
assert.equal(raw.readUInt32LE(0), 0x46546c67); assert.equal(raw.readUInt32LE(4), 2);
const doc = JSON.parse(raw.subarray(20, 20 + raw.readUInt32LE(12)).toString('utf8'));
assert.equal(doc.meshes.length, 3); assert.equal(doc.skins.length, 1);
// Same geometry-only material adapter as tools/measure_horse_support_domain.mjs.
// Original GLB bytes are passed unchanged; images/shader rendering are NOT exercised.
const loader = new GLTFLoader().setMeshoptDecoder(MeshoptDecoder);
loader.register(() => ({name: 'CPU_POSE_ONLY_MATERIAL_ADAPTER', loadMaterial: async i =>
  new T.MeshBasicMaterial({side: doc.materials[i].doubleSided ? T.DoubleSide : T.FrontSide})}));
const parsed = await loader.parseAsync(raw.buffer.slice(raw.byteOffset, raw.byteOffset + raw.byteLength), '');
const scene = parsed.scene; scene.updateMatrixWorld(true);
assert.deepEqual(scene.position.toArray(), [0,0,0]); assert.deepEqual(scene.scale.toArray(), [1,1,1]);
assert.deepEqual(scene.quaternion.toArray(), [0,0,0,1]);
const meshes = []; scene.traverse(o => { if (o.isSkinnedMesh) meshes.push(o); });
assert.equal(meshes.length, 3);
const binding = JSON.parse(readFileSync(pins.hitch_binding));
const outputs = [], rows = [], meshesByID = new Map(); let totalVertices = 0, totalTriangles = 0;
const native = new T.Vector3();
function emit(name, bytes) {
  writeFileSync(path.join(out, name), bytes);
  const row = {file:name, bytes:bytes.length, sha256:sha(bytes)}; outputs.push(row); return row;
}
function binary(name, values, kind) {
  const bytes = Buffer.alloc(values.length * (kind === 'f64' ? 8 : 4));
  for(let i=0;i<values.length;i++) kind === 'f64' ? bytes.writeDoubleLE(values[i],i*8) : bytes.writeUInt32LE(values[i],i*4);
  return emit(name, bytes);
}
function rawSkinAccessor(ai) {
  const a=doc.accessors[ai],view=doc.bufferViews[a.bufferView];
  assert(a&&a.type==='VEC4'&&!a.sparse&&view&&view.buffer===0&&!view.extensions?.EXT_meshopt_compression,
    'Raw skin stream packing only supports this pinned uncompressed source layout');
  const sizes={5120:1,5121:1,5122:2,5123:2,5125:4,5126:4};const bytes=sizes[a.componentType];assert(bytes);
  const elementSize=bytes*4,stride=view.byteStride??elementSize,offset=(view.byteOffset??0)+(a.byteOffset??0);
  const binHeader=20+raw.readUInt32LE(12);assert.equal(raw.readUInt32LE(binHeader+4),0x004e4942);
  const binStart=binHeader+8,binLength=raw.readUInt32LE(binHeader);assert(stride>=elementSize);
  assert(offset>=0&&offset+(a.count-1)*stride+elementSize<=binLength);
  const packed=Buffer.alloc(a.count*elementSize);
  for(let i=0;i<a.count;i++)raw.copy(packed,i*elementSize,binStart+offset+i*stride,binStart+offset+i*stride+elementSize);
  return packed;
}
for (const mesh of meshes) {
  const association = parsed.parser.associations.get(mesh);
  assert(association && Number.isInteger(association.meshes));
  const mi = association.meshes, pi = association.primitives ?? 0;
  assert.equal(pi, 0); assert(!meshesByID.has(mi));
  const declared = doc.meshes[mi].primitives[pi], g = mesh.geometry;
  assert.equal(declared.mode ?? 4, 4); assert(g.index, 'Original indexed triangle stream required');
  const count = g.attributes.position.count, ic = g.index.count; assert.equal(ic % 3, 0);
  assert.equal(count, doc.accessors[declared.attributes.POSITION].count);
  assert.equal(ic, doc.accessors[declared.indices].count);
  assert.equal(mesh.skeleton.bones.length, 26);
  assert.deepEqual(mesh.skeleton.bones.map(b => b.name), binding.joint_names);
  mesh.skeleton.update();
  const vertices = [], indices = [], triangles = [], min=[Infinity,Infinity,Infinity], max=[-Infinity,-Infinity,-Infinity];
  for(let i=0;i<count;i++) {
    mesh.getVertexPosition(i,native).applyMatrix4(mesh.matrixWorld);
    const v=native.toArray(); assert(v.every(Number.isFinite)); vertices.push(...v);
    for(let k=0;k<3;k++){min[k]=Math.min(min[k],v[k]);max[k]=Math.max(max[k],v[k]);}
  }
  for(let i=0;i<ic;i++) {const id=g.index.getX(i); assert(Number.isInteger(id)&&id>=0&&id<count);indices.push(id);triangles.push(...vertices.slice(id*3,id*3+3));}
  const J=g.getAttribute('skinIndex'), W=g.getAttribute('skinWeight');
  assert(J&&W&&J.itemSize===4&&W.itemSize===4&&J.count===count&&W.count===count);
  const jointRows=[],weightRows=[],zeroWeightPadding=[];let minWeightSum=Infinity,maxWeightSum=-Infinity;
  const getters=['getX','getY','getZ','getW'];
  for(let v=0;v<count;v++) {
    let sum=0;
    for(const getter of getters) {
      const j=J[getter](v),w=W[getter](v);
      assert(Number.isInteger(j)&&j>=0&&j<=65535,'Actual unsigned source joint component');
      assert(Number.isFinite(w)&&w>=0&&w<=1,'Actual source weight, never normalized/mutated here');
      assert(w===0||j<26,'Existing native predicate: every nonzero-weight joint in actual palette');
      if(w===0&&j>=26)zeroWeightPadding.push({vertex:v,slot:getters.indexOf(getter),native_joint_index:j,native_weight:w,negative_zero_weight:Object.is(w,-0)});
      jointRows.push(j);weightRows.push(w);sum+=w;
    }
    minWeightSum=Math.min(minWeightSum,sum);maxWeightSum=Math.max(maxWeightSum,sum);
  }
  const declaredSkin={};
  for(const name of ['JOINTS_0','WEIGHTS_0']) {
    const a=doc.accessors[declared.attributes[name]];assert(a);
    declaredSkin[name]={componentType:a.componentType,type:a.type,count:a.count,normalized:a.normalized??false};
  }
  const skinStatistics={native_skinIndex_constructor:J.array?.constructor?.name??J.data?.array?.constructor?.name,
    native_skinWeight_constructor:W.array?.constructor?.name??W.data?.array?.constructor?.name,
    native_skinIndex_normalized:J.normalized,native_skinWeight_normalized:W.normalized,
    source_accessor_declarations:declaredSkin,zero_weight_out_of_palette_components:zeroWeightPadding.length,
    zero_weight_padding_slots:zeroWeightPadding,zero_weight_padding_filtered_or_rewritten:false,min_native_weight_sum:minWeightSum,max_native_weight_sum:maxWeightSum,
    rows:count,slots_per_row:4,helper_weight_normalization_or_repair_performed:false,
    standard_GLTFLoader_normalizeSkinWeights_preserved:true,
    native_vs_source_semantics:'Raw packed source component bytes are preserved separately; native getters follow unmodified GLTFLoader normalizeSkinWeights() behavior'};
  const files={raw_source_JOINTS_0:emit(`mesh-${mi}-source-JOINTS_0.raw`,rawSkinAccessor(declared.attributes.JOINTS_0)),
    raw_source_WEIGHTS_0:emit(`mesh-${mi}-source-WEIGHTS_0.raw`,rawSkinAccessor(declared.attributes.WEIGHTS_0)),
    skin_indices:binary(`mesh-${mi}-native-JOINTS_0.u32le`,jointRows,'u32'),
    skin_weights:binary(`mesh-${mi}-native-WEIGHTS_0.f64le`,weightRows,'f64'),
    vertices:binary(`mesh-${mi}-rest-world-vertices.f64le`,vertices,'f64'),
    original_indices:binary(`mesh-${mi}-source-indices.u32le`,indices,'u32'),
    triangles:binary(`mesh-${mi}-rest-world-triangles.f64le`,triangles,'f64')};
  const materialName=doc.materials[declared.material]?.name;
  const isBody=count===binding.source_body_vertex_count&&materialName===binding.source_body_material_name;
  const joints=mesh.skeleton.bones.map((b,j)=>({index:j,name:b.name,
    local_matrix:b.matrix.toArray(),world_matrix:b.matrixWorld.toArray(),
    world_position:new T.Vector3().setFromMatrixPosition(b.matrixWorld).toArray(),
    inverse_bind_matrix:mesh.skeleton.boneInverses[j].toArray(),
    parent_name:b.parent?.name??null}));
  for(const j of joints) for(const k of ['local_matrix','world_matrix','world_position','inverse_bind_matrix']) assert(j[k].every(Number.isFinite));
  const row={mesh:mi,primitive:pi,material_name:materialName,is_BODY:isBody,vertices:count,triangles:ic/3,
    min_xyz_m:min,max_xyz_m:max,matrix_world:mesh.matrixWorld.toArray(),
    bind_matrix:mesh.bindMatrix.toArray(),bind_matrix_inverse:mesh.bindMatrixInverse.toArray(),joints,skin_statistics:skinStatistics,files};
  rows.push(row);meshesByID.set(mi,{row,vertices,indices,jointRows,weightRows,mesh});totalVertices+=count;totalTriangles+=ic/3;
}
rows.sort((a,b)=>a.mesh-b.mesh);
assert.equal(totalVertices,12838); assert.equal(totalTriangles,17390);
const bodies=[...meshesByID.values()].filter(x=>x.row.is_BODY); assert.equal(bodies.length,1);
const body=bodies[0]; assert.equal(body.row.vertices,5595); assert.equal(body.row.triangles,9794);
const fit=JSON.parse(readFileSync(pins.proposed_fit_witnesses));
assert.equal(fit.source_assets[args[1]],asset.sha256);
const measuredVertices=readFileSync(pins.previous_BODY_world_vertices);
assert.equal(measuredVertices.length,5595*3*8);
const refs=[...fit.dorsal_surface_witnesses,...fit.girth_surface_witnesses];
assert.equal(refs.length,62);
const selectedFitFaces=refs.map(ref=>{
  const w=ref.witness;
  assert.deepEqual(body.indices.slice(3*w.face,3*w.face+3),w.indices);
  const sourceVertices=w.indices.map(id=>{
    const point=body.vertices.slice(id*3,id*3+3);
    for(let k=0;k<3;k++) assert(Object.is(point[k],measuredVertices.readDoubleLE((id*3+k)*8)), 'Exact previous native rest vertex');
    const js=body.jointRows.slice(id*4,id*4+4),ws=body.weightRows.slice(id*4,id*4+4);
    return {source_vertex:id,rest_world_m:point,JOINTS_0:js,WEIGHTS_0:ws,
      joint_names:js.map(j=>j<26?binding.joint_names[j]:null),
      zero_weight_padding_slots:js.flatMap((j,k)=>j>=26?[{slot:k,native_joint_index:j,native_weight:ws[k],negative_zero_weight:Object.is(ws[k],-0)}]:[]),attribute_semantics:'Native getters after standard GLTFLoader normalization; original components separately preserved',native_weight_sum:ws.reduce((a,b)=>a+b,0)};
  });
  return {id:ref.id,face:w.face,indices:w.indices,barycentric:w.barycentric,source_vertices:sourceVertices,
    scope:'NATIVE_SOURCE_ATTRIBUTES_ONLY_NOT_NEW_GEAR_WEIGHTS_OR_ATTACHMENT'};
});
const jointTrackMetadata=parsed.animations.map((clip,ci)=>{
  const declaredClip=doc.animations[ci];assert(declaredClip&&clip.name===declaredClip.name);
  return {name:clip.name,duration_s:clip.duration,native_tracks:clip.tracks.map(track=>{
    const parsedName=T.PropertyBinding.parseTrackName(track.name);
    const target=T.PropertyBinding.findNode(scene,parsedName.nodeName);assert(target,'Actual native track target resolves');
    const joint=body.mesh.skeleton.bones.indexOf(target);
    const times=Array.from(track.times);assert(times.every(Number.isFinite));
    assert(times.every((t,i)=>i===0||t>times[i-1]),'Declared native key times strictly increase');
    assert(Array.from(track.values).every(Number.isFinite));
    const hashArray=a=>sha(Buffer.from(a.buffer,a.byteOffset,a.byteLength));
    return {name:track.name,parsed_binding:parsedName,target_name:target.name,
      target_source_node:parsed.parser.associations.get(target)?.nodes??null,
      current_skin_joint_index:joint>=0?joint:null,is_current_skin_joint:joint>=0,
      times_constructor:track.times.constructor.name,values_constructor:track.values.constructor.name,
      times_count:track.times.length,first_time_s:times[0]??null,last_time_s:times.at(-1)??null,
      values_count:track.values.length,native_value_size:track.getValueSize(),
      native_interpolation_code:track.getInterpolation()??null,
      gltf_cubic_factory:track.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline===true,
      times_bytes_sha256:hashArray(track.times),values_bytes_sha256:hashArray(track.values)};
    }),source_channels:declaredClip.channels.map(channel=>{
      const sampler=declaredClip.samplers[channel.sampler];
      return {target:channel.target,target_name:doc.nodes[channel.target.node]?.name??null,
        sampler:{input_accessor:sampler.input,output_accessor:sampler.output,interpolation:sampler.interpolation??'LINEAR'},
        input_declaration:doc.accessors[sampler.input],output_declaration:doc.accessors[sampler.output]};
    }),animation_or_interpolant_evaluated:false};
});
assert.deepEqual(jointTrackMetadata.map(c=>c.name),asset.expected_clip_names);
const draftGuides=[];
for(const [group, refs] of Object.entries(binding.surface_guides)) for(const [index,ref] of refs.entries()) {
  assert.deepEqual(body.indices.slice(ref.face*3,ref.face*3+3),ref.indices,'Actual existing BODY face correspondence');
  assert.equal(ref.barycentric.length,3); assert(ref.barycentric.every(x=>Number.isFinite(x)&&x>=0&&x<=1));
  assert(Math.abs(ref.barycentric.reduce((a,b)=>a+b,0)-1)<1e-12,'Existing weights form barycentric point');
  const point=new T.Vector3();
  ref.indices.forEach((id,k)=>point.addScaledVector(new T.Vector3(...body.vertices.slice(id*3,id*3+3)),ref.barycentric[k]));
  draftGuides.push({group,index,source_reference:ref,measured_unoffset_surface_world_m:point.toArray(),
    scope:'EXISTING_DRAFT_GUIDE_ONLY_NOT_A_RIDING_SOCKET'});
}
assert.equal(draftGuides.length,26);
const report={schema:'current26-native-skin-track-intake-v2',status:'NATIVE_SKIN_TRACK_READBACK_ONLY_NOT_FIT_QUALIFICATION',
  asset_key:args[1],asset_sha256:asset.sha256,pins_sha256:sha(pinsBytes),native_three_revision:T.REVISION,
  actual_node_version:process.version,actual_node_versions:process.versions,
  clips_declared:parsed.animations.map(c=>({name:c.name,duration_s:c.duration})),
  pose:'GLTF loader initial serialized rest; no mixer, animation, skeleton.pose(), root repositioning or scale changes',
  geometry_only_material_adapter:true,images_or_pixels_reviewed:false,actual_skin_joint_count:26,
  total_vertices:totalVertices,total_triangles:totalTriangles,meshes:rows,draft_guides:draftGuides,
  selected_fit_faces:selectedFitFaces,joint_track_metadata:jointTrackMetadata,
  native_attribute_read_only:true,new_gear_weights_interpolated:false,animations_or_interpolants_evaluated:false,
  surface_stream_layout:'All triangles, including hair/eyes; face f uses source indices[3f:3f+3] and nine F64LE world coordinates; source vertex IDs retained',
  saddle_anchor:null,seat_anchor:null,stirrup_anchor:null,rider_fit_or_loaded_contact:false,
  old_6e9_inputs_used:false,asset_body_rig_texture_changed:false,attribution:pins.current_source_attribution,outputs};
verifyInputs();emit('SKIN-TRACK-WITNESSES.json',Buffer.from(JSON.stringify(report,null,2)+'\n'));
console.log(`Current26 skin/track readback measured ${totalTriangles} original triangles, 26 joints and ${draftGuides.length} draft-guide witnesses; fit remains UNRUN`);
