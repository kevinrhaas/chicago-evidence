#!/usr/bin/env bash
# Prepared only: ROOT's explicit canonical-lane handoff remains required.
set -euo pipefail
[ "$#" -eq 2 ] || { echo 'usage: run_owned_once.sh ROOT-ACTUAL-GO.json /absolute/fresh-output';exit 2; }
source /workspace/.cloud-setup/transport-activate.sh
proposal=/workspace/.cloud-setup/transport-rider-intake-20261104/current26-skin-track-intake-v2
intake_go=$1
intake_out=$2
intake_prefix="${intake_out}-driver"
python - "$proposal" "$intake_out" <<'PY'
from pathlib import Path
import sys
assert Path(sys.argv[2]).is_absolute() and Path(sys.argv[2]).resolve().parent==Path(sys.argv[1]).resolve()
PY
exec 9>>/workspace/.cloud-setup/transport-8cec-generated-lap-20261030/ROOT-SOLE-CANONICAL-OWNER.lock
flock -n 9
for suffix in .resource-before.json .resource-after.json .resource-pair.json .supervisor.stdout .CLOSED.json;do
 [ ! -e "${intake_prefix}${suffix}" ] || { echo 'Use a fresh output/prefix';exit 2; }
done
python /workspace/.cloud-setup/transport-current-20261103/resource_guard.py capture "${intake_prefix}.resource-before.json"
set +e
python /workspace/.cloud-setup/transport-supervise.py --prefix "$intake_prefix" --cwd "$proposal" --timeout 180 -- \
 /workspace/.cloud-setup/venv311/bin/python "$proposal/run_native_skin_tracks_once.py" --go "$intake_go" --out "$intake_out" > "${intake_prefix}.supervisor.stdout" 2>&1
intake_rc=$?
python /workspace/.cloud-setup/transport-current-20261103/resource_guard.py capture "${intake_prefix}.resource-after.json"
intake_after=$?
python /workspace/.cloud-setup/transport-current-20261103/resource_guard.py pair "${intake_prefix}.resource-before.json" "${intake_prefix}.resource-after.json" "${intake_prefix}.resource-pair.json"
intake_pair=$?
set -e
python - "$intake_prefix" "$intake_out" "$intake_rc" "$intake_after" "$intake_pair" <<'PY'
from pathlib import Path
import sys,json,hashlib
prefix,out,rc,after,pair=sys.argv[1:]
load=lambda p:json.loads(Path(p).read_text())if Path(p).exists()else None
r=load(prefix+'.result.json');c=load(prefix+'.cleanup.json');g=load(prefix+'.resource-pair.json');i=load(str(Path(out)/'RESULT.json'))
ok=bool(rc==after==pair=='0'and r and r['returncode']==0 and not r['timed_out']and r['requested_timeout_seconds']==r['effective_timeout_seconds']==180 and r['timeout_override_reason']is None and c and c['cleanup_complete']and not c['remaining_owned_children']and g and g['accepted']and i and i['status']=='NATIVE_SKIN_TRACK_PAIR_MEASURED_NOT_RIDER_FIT'and i['source_inputs_after_exact'])
report={'status':'CURRENT26_NATIVE_SKIN_TRACK_INTAKE_MEASURED_NOT_FIT'if ok else'NONPASS_NO_AUTOMATIC_RETRY','result':r,'cleanup':c,'resources':g,'intake_result':i,'new_anchors_fit_rider_or_photo_accepted':False}
Path(prefix+'.CLOSED.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status']);raise SystemExit(0 if ok else 1)
PY
