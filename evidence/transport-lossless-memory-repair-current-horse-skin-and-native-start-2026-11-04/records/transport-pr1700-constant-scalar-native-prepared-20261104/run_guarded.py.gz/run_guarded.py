from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,subprocess,sys,shutil
P=Path('/workspace/chicago-pr1700-memory-constant-scalars-20261104');PREP=Path(__file__).parent;OUT=Path(sys.argv[1]);assert not OUT.exists()
lock=open('/workspace/.cloud-setup/transport-8cec-generated-lap-20261030/ROOT-SOLE-CANONICAL-OWNER.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
spec=importlib.util.spec_from_file_location('guard','/workspace/.cloud-setup/transport-current-20261103/resource_guard.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
before=g.snapshot();assert g.check(before)['accepted'];OUT.mkdir();scratch=OUT/'native-tmp';scratch.mkdir()
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(scratch),PW_EXECUTABLE='/workspace/.cloud-setup/transport-browser141-20261103/chromium_headless_shell-1194/chrome-linux/headless_shell')
for k in ['GIT_NO_LAZY_FETCH','CHICAGO_TICKETS_DIR','CHECK_PART','BASE','CHECK_TIMINGS']:env.pop(k,None)
def profile():
 e=dict(env,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0');git=lambda *a:subprocess.check_output(['git','-C',str(P),*a],env=e,timeout=30)
 return dict(HEAD=git('rev-parse','HEAD').decode().strip(),TREE=git('write-tree').decode().strip(),index=hashlib.sha256(git('ls-files','--stage','-z')).hexdigest(),status=git('status','--porcelain').decode(),sources={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in [P/'chicago/4d/renderers/web/js/compact-attributes.js',P/'chicago/4d/renderers/web/js/buildings.js',P/'chicago/4d/tools/check_compact_attributes.mjs',PREP/'fixture.html',PREP/'actual-building-scalar-patch.mjs',PREP/'run_native.mjs',P/'chicago/4d/renderers/web/vendor/three-0.185.1/three.module.js',P/'chicago/4d/renderers/web/vendor/three-0.185.1/three.core.js',*[Path('/workspace/chicago-driver-garment-projected-20261104/chicago/4d/renderers/web/js')/name for name in ['confidence.js','gpu-pick.js','compact-streams.js']]]})
source=profile();(OUT/'OWNER.json').write_text(json.dumps(dict(owner_pid=os.getpid(),source=source),indent=2)+'\n');prefix=OUT/'native-fallback-proof'
subprocess.run([sys.executable,'/workspace/.cloud-setup/transport-supervise.py','--prefix',str(prefix),'--cwd',str(P/'chicago/4d'),'--timeout','120','--','node',str(PREP/'run_native.mjs'),str(OUT/'RESULT.json')],env=env,check=False)
r=json.loads(Path(str(prefix)+'.result.json').read_text());c=json.loads(Path(str(prefix)+'.cleanup.json').read_text());res=g.pair(before,g.snapshot());stable=profile()==source
safe=c['cleanup_complete']and not c['remaining_owned_children'];qualified=r['returncode']==0 and not r['timed_out']and r['requested_timeout_seconds']==r['effective_timeout_seconds']==120 and r['timeout_override_reason']is None and safe and stable and res['accepted']
if safe:shutil.rmtree(scratch)
closed=dict(passed=qualified,source=source,source_unchanged=stable,result=r,cleanup=c,resources=res,owned_tmp_removed=not scratch.exists())
(OUT/'CLOSED.json').write_text(json.dumps(closed,indent=2)+'\n');print(json.dumps(dict(passed=qualified,returncode=r['returncode'],seconds=r['seconds'],source_unchanged=stable,resources=res['accepted'],cleanup=safe)));sys.exit(0 if qualified else 1)
