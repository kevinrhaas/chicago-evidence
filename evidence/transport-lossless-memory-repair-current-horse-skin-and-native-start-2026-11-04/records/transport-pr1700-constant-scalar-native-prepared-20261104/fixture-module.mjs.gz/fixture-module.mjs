
import * as THREE from 'three';
import {compactConstantBatchScalars,SCALARS,SCALARS_GLSL} from '/candidate/compact-attributes.js';
import {createConfidenceView} from '/base/confidence.js';
import {setPickRenderer,gpuPick,raycastPick} from '/base/gpu-pick.js';
import {perVertexScalars} from '/actual-building-scalar-patch.mjs';
const assert=(ok,why)=>{if(!ok)throw Error(why);};
const equal=(a,b)=>a.length===b.length&&a.every((v,i)=>v===b[i]);
const captures=[];
async function one(fallback,compact){
 const renderer=new THREE.WebGLRenderer({antialias:false});renderer.setSize(96,96);renderer.setPixelRatio(1);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.BasicShadowMap;
 const gl=renderer.getContext(),ext=renderer.extensions.get('WEBGL_multi_draw');assert(ext,'native WEBGL_multi_draw unavailable');
 let nativeDraws=0,plainDraws=0,divisorOne=0;
 const native=ext.multiDrawElementsWEBGL.bind(ext);ext.multiDrawElementsWEBGL=(...a)=>{nativeDraws++;return native(...a);};
 const plain=gl.drawElements.bind(gl);gl.drawElements=(...a)=>{plainDraws++;return plain(...a);};
 const divisor=gl.vertexAttribDivisor.bind(gl);gl.vertexAttribDivisor=(i,d)=>{if(d===1)divisorOne++;return divisor(i,d);};
 if(fallback){const get=renderer.extensions.get.bind(renderer.extensions),has=renderer.extensions.has.bind(renderer.extensions);renderer.extensions.get=n=>n==='WEBGL_multi_draw'?null:get(n);renderer.extensions.has=n=>n==='WEBGL_multi_draw'?false:has(n);}
 const scene=new THREE.Scene();scene.background=new THREE.Color(0x202020);
 const camera=new THREE.OrthographicCamera(-2,2,1.5,-1.5,.1,30);camera.position.set(0,1,6);camera.lookAt(0,0,0);camera.updateMatrixWorld(true);
 scene.add(new THREE.HemisphereLight(0xffffff,0x333333,1));const light=new THREE.DirectionalLight(0xffffff,4);light.position.set(1.5,3,4);light.castShadow=true;light.shadow.mapSize.set(128,128);scene.add(light);
 const confidence=createConfidenceView();const packed={read:SCALARS_GLSL.confidence,declare:SCALARS_GLSL.declare};
 const material=new THREE.MeshStandardMaterial({color:0x927f65,metalness:.15});confidence.patch(material,{packed});perVertexScalars(material);
 const geo=new THREE.SphereGeometry(.58,16,12);const n=geo.attributes.position.count,a=new Uint8Array(n*4);for(let i=0;i<n;i++)a.set([160,127,128,255],i*4);geo.setAttribute(SCALARS,new THREE.BufferAttribute(a,4,false));
 const batch=new THREE.BatchedMesh(2,n*2,geo.index.count*2,material);for(let i=0;i<2;i++){const g=batch.addGeometry(geo);const id=batch.addInstance(g);batch.setMatrixAt(id,new THREE.Matrix4().makeTranslation(i? .8:-.8,.05,0));batch.setColorAt(id,new THREE.Color(1,1,1));}
 batch.castShadow=true;batch.receiveShadow=true;batch.customDepthMaterial=confidence.patch(new THREE.MeshDepthMaterial({depthPacking:THREE.RGBADepthPacking}),{packed});
 const before=Array.from(batch.geometry.getAttribute(SCALARS).array),saved=compact?compactConstantBatchScalars(batch):0;
 if(compact){assert(saved===(n*2-1)*4,'exact allocated bytes');assert(batch.geometry.getAttribute(SCALARS).count===1,'honest one-tuple count');}
 scene.add(batch);const floor=new THREE.Mesh(new THREE.PlaneGeometry(6,5),new THREE.MeshStandardMaterial({color:0x777777}));floor.rotation.x=-Math.PI/2;floor.position.y=-.57;floor.receiveShadow=true;scene.add(floor);
 const target=new THREE.WebGLRenderTarget(96,96);const frame=()=>{scene.updateMatrixWorld(true);renderer.setRenderTarget(target);renderer.render(scene,camera);const out=new Uint8Array(96*96*4);renderer.readRenderTargetPixels(target,0,0,96,96,out);return Array.from(out);};
 const base=frame();setPickRenderer(renderer);renderer.setRenderTarget(null);
 const picks=[-.4,.4].map(x=>{const ndc=new THREE.Vector2(x,.03),gpu=gpuPick([batch],ndc,camera),ray=raycastPick([batch],ndc,camera);assert(gpu&&ray&&gpu.batchId===ray.batchId,'actual GPU pick agrees with ray oracle');return {batchId:gpu.batchId,distance:gpu.distance,point:gpu.point.toArray()};});
 const channel=batch.geometry.getAttribute(SCALARS),original=channel.array.slice(),version=channel.version;
 for(let i=0;i<channel.array.length;i+=4)channel.array[i]=4;channel.needsUpdate=true;assert(channel.version===version+1,'ordinary roughness write invalidates version');const rough=frame();assert(!equal(base,rough),'roughness actually reaches visible pixels');channel.array.set(original);channel.needsUpdate=true;assert(equal(base,frame()),'roughness restoration exact');
 confidence.set(true);const tinted=frame();assert(!equal(base,tinted),'confidence mode actually reaches pixels');confidence.set(false);confidence.setHidden('inferred',true);const hidden=frame();assert(!equal(base,hidden),'confidence hide actually reaches pixels');confidence.setHidden('inferred',false);assert(equal(base,frame()),'confidence restoration exact');
 scene.overrideMaterial=confidence.patch(new THREE.MeshDepthMaterial({depthPacking:THREE.RGBADepthPacking}),{packed});const depth=frame();scene.overrideMaterial=null;
 assert(fallback?nativeDraws===0&&plainDraws>0:nativeDraws>0,'requested actual native/fallback path observed');if(compact)assert(divisorOne>0,'native GL divisor-one actually bound');
 const result={fallback,compact,base,rough,tinted,hidden,depth,picks,nativeDraws,plainDraws,divisorOne,saved,storedTuple:Array.from(channel.array),originalRepeatedBytes:before.length};
 target.dispose();const gs=new Set(),ms=new Set();scene.traverse(o=>{if(o.geometry)gs.add(o.geometry);for(const m of[].concat(o.material??[],o.customDepthMaterial??[]))ms.add(m);});for(const g of gs)g.dispose();for(const m of ms)m.dispose();renderer.dispose();return result;
}
try{
 for(const fallback of[false,true]){const original=await one(fallback,false),compact=await one(fallback,true);for(const key of['base','rough','tinted','hidden','depth'])assert(equal(original[key],compact[key]),`${fallback?'fallback':'native'} ${key} pixels must be byte exact`);assert(JSON.stringify(original.picks)===JSON.stringify(compact.picks),'pick IDs/depth/points exact');captures.push({fallback,pixel_cases:5,pick_cases:2,originalNative:original.nativeDraws,compactNative:compact.nativeDraws,originalPlain:original.plainDraws,compactPlain:compact.plainDraws,actualDivisorOneBinds:compact.divisorOne,exactStoredTuple:compact.storedTuple,actualBufferBytesSaved:compact.saved});}
 globalThis.__fixtureResult={passed:true,cases:captures,scope:'Actual Three BatchedMesh, original building scalar shader patch/confidence/depth/GPU pick, native multi-draw and real fallback; no world-memory PASS claim'};
}catch(error){globalThis.__fixtureFailure=String(error.stack??error);console.error(error);}
