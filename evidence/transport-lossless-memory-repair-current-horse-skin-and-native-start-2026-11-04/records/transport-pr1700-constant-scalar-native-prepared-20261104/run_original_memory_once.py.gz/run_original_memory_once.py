from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,subprocess,sys,shutil,stat
P=Path('/workspace/chicago-pr1700-memory-constant-scalars-20261104');APP=P/'chicago/4d';OUT=Path(sys.argv[1]);assert not OUT.exists()
lock=open('/workspace/.cloud-setup/transport-8cec-generated-lap-20261030/ROOT-SOLE-CANONICAL-OWNER.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
spec=importlib.util.spec_from_file_location('guard','/workspace/.cloud-setup/transport-current-20261103/resource_guard.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
before=g.snapshot();assert g.check(before)['accepted'];OUT.mkdir();scratch=OUT/'native-tmp';scratch.mkdir();save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(scratch),PW_EXECUTABLE='/workspace/.cloud-setup/transport-browser141-20261103/chromium_headless_shell-1194/chrome-linux/headless_shell')
for k in ['GIT_NO_LAZY_FETCH','CHICAGO_TICKETS_DIR','CHECK_PART','BASE','CHECK_TIMINGS']:env.pop(k,None)
meta=dict(env,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(*a):return subprocess.check_output(['git','-C',str(P),*a],env=meta,timeout=45)
def profile():
 tree=git('write-tree').decode().strip();return dict(HEAD=git('rev-parse','HEAD').decode().strip(),TREE=tree,APP=git('rev-parse',tree+':chicago/4d').decode().strip(),index=hashlib.sha256(git('ls-files','--stage','-z')).hexdigest(),status=git('status','--porcelain').decode())
source=profile();ledger=[];error=None;meter=None
save(OUT/'OWNER.json',dict(owner_pid=os.getpid(),source=source))
def run(name,cmd,cap,nonzero=False):
 rb=g.snapshot();assert g.check(rb)['accepted'];prefix=OUT/name;save(OUT/'STATE.json',dict(owner_pid=os.getpid(),phase=name,ledger=ledger));subprocess.run([sys.executable,'/workspace/.cloud-setup/transport-supervise.py','--prefix',str(prefix),'--cwd',str(APP),'--timeout',str(cap),'--',*cmd],env=env,check=False)
 r=json.loads(Path(str(prefix)+'.result.json').read_text());c=json.loads(Path(str(prefix)+'.cleanup.json').read_text());res=g.pair(rb,g.snapshot());ledger.append(dict(name=name,result=r,cleanup=c,resources=res));save(OUT/'LEDGER.json',ledger)
 assert not r['timed_out']and r['requested_timeout_seconds']==r['effective_timeout_seconds']==cap and r['timeout_override_reason']is None and c['cleanup_complete']and not c['remaining_owned_children']and res['accepted']
 assert profile()==source,'candidate source drift'
 if not nonzero:assert r['returncode']==0,name
 return r
try:
 dirs=git('ls-tree','-z','-d','--name-only','HEAD:chicago/4d').decode().split('\0');paths=['/.github/','/chicago/pre_fire_v1/','/chicago/prairie_1904_v1/','/site/','/chicago/4d/docs/RESEARCH/glessner-v4-recovery/']+['/chicago/4d/'+d+'/'for d in dirs if d and d!='docs']
 run('materialize-original-publication-inputs',['git','-C',str(P),'-c','gc.auto=0','-c','maintenance.auto=false','sparse-checkout','add',*paths],120)
 for rel in git('ls-files','-z').decode().split('\0'):
  if not rel:continue
  f=P/rel
  if not f.exists()or not stat.S_ISREG(f.lstat().st_mode)or f.stat().st_size<1048576:continue
  fd=os.open(f,os.O_RDONLY|os.O_NOFOLLOW)
  try:os.posix_fadvise(fd,0,0,os.POSIX_FADV_DONTNEED)
  finally:os.close(fd)
 run('native-publish',['bash','tools/publish.sh'],180);run('published-check',['node','tools/check_published.mjs'],120)
 run('original1904-mobile-memory-ONCE',['node','tools/measure_memory.mjs','--gate','--year','1904','--only','mobile','--json',str(OUT/'memory-1904-mobile.json')],600,True)
 meter=json.loads((OUT/'memory-1904-mobile.json').read_text());row=meter['rows'][0];assert len(meter['rows'])==1 and row['year']=='1904'and row['viewport']=='mobile'and row['tier']=='light'and row['keepGeometry']is False and row['errors']==[]and row['residency']['pending']==0 and meter['measured']['build']==source['HEAD'][:10]
except BaseException as e:error=repr(e)
res=g.pair(before,g.snapshot());stable=profile()==source;safe=all(x['cleanup']['cleanup_complete']and not x['cleanup']['remaining_owned_children']for x in ledger)
if safe:shutil.rmtree(scratch)
passed=error is None and stable and safe and res['accepted']and meter is not None and meter['rows'][0]['totals']['total']<=419430400 and ledger[-1]['result']['returncode']==0
closed=dict(passed=passed,error=error,source=source,source_unchanged=stable,ledger=ledger,resources=res,reading=meter,original400MiB_limit_bytes=419430400,owned_tmp_removed=not scratch.exists(),scope='Uncommitted isolated lossless scalar source projection; build label is original HEAD; exact staged TREE recorded, no public G79 rerun')
save(OUT/'CLOSED.json',closed);print(json.dumps(dict(passed=passed,error=error,total=meter['rows'][0]['totals']['total']if meter else None,source_unchanged=stable,resources=res['accepted'],cleanup=safe)));sys.exit(0 if passed else 1)
