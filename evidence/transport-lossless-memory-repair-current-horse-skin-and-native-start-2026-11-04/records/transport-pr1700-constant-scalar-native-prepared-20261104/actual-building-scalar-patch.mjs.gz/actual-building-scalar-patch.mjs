import {SCALARS_GLSL} from '/candidate/compact-attributes.js';
import {programKeyOf} from '/base/confidence.js';
export function perVertexScalars(material) {
  const prior = material.onBeforeCompile;
  const priorKey = programKeyOf(material);
  material.onBeforeCompile = (shader, renderer) => {
    if (typeof prior === 'function') prior(shader, renderer);
    shader.uniforms.chiToneScale = { value: material.userData.chiToneScale ?? 255 };
    shader.vertexShader = SCALARS_GLSL.declare('uniform float chiToneScale;\n'
      + 'varying float vChiRough;\nvarying float vChiTone;\n'
      + shader.vertexShader.replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>\n  vChiRough = ${SCALARS_GLSL.roughness};\n`
        + `  vChiTone = ${SCALARS_GLSL.tone};`,
      ));
    shader.fragmentShader = 'varying float vChiRough;\nvarying float vChiTone;\n'
      + shader.fragmentShader
        .replace('#include <roughnessmap_fragment>', `#ifdef USE_ROUGHNESSMAP
#include <roughnessmap_fragment>
#else
  float roughnessFactor = vChiRough;
#endif`)
        .replace('#include <color_fragment>', 'diffuseColor.rgb *= vChiTone;\n#include <color_fragment>');
  };
  material.customProgramCacheKey = () => `chicago4d-scalars${priorKey ? `|over:${priorKey}` : ''}`;
  material.needsUpdate = true;
  return material;
}

