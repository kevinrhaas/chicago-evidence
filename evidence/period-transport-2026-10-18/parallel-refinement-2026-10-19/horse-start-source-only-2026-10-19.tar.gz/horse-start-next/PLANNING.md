Source-only during root's full gate; do not run mesh/LBS/browser sweeps yet.

Naively reversing a stop's quaternions while continuing forward would slide planted feet: local foot velocity reverses but actor velocity does not. New design reverses stop targets AND mirrors ankle longitudinal offsets about their own hip, then resolves original3D IK/flatfetlocks. Set Rnew(t)=D−Rold(T−t). For previously planted foot with old worldZ=W, newworldZ=D+hipnewZ+hipoldZ−W, constant. Y unchanged; no rootYlift/scale/marker change.

Walk needs foreleft/right timing remap under reversal to recover original quarter-cycle named offsets. Trot diagonal0/.5 offsets are self-inverse. Exitphase=(stance−oldentryphase)%1. Subsequent distancephase requires explicit exitphase offset; resetting globalphase0 would break pose/contact. Head/tail pose-targets interpolate separately to actual originalgait quaternion at exitphase; secondaryangularvelocity/biomechanics remain open.

Source plan holds initialrootstationary while preparatorysteps reverse the stop's post-brakingreplants, then accelerates over final.6s. It may look deliberate/awkward; no unseen visual acceptance. Same originalcontacttopology counts analytically reverse; must measure real GLB100soleverts and source/end wholemesh, reach, externaldistance monotonicity and gear after gate.

A bounded walk→trot or trot→walk can concatenate stop and start through a REAL finite neutralreplant moment, preserving exact distance/time profiles and pose. This is a slow stop-through-idle change, not a direct continuous-speed gait blend. Needs finiteasynccancellation/route/brakingroom and source/endphase metadata. No app integration claim. Code is originalCC0 and inputs originalCC0 from stable stop archive.
