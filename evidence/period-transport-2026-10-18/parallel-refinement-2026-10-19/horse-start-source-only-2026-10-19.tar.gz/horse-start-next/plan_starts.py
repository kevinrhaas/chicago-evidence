# SPDX-License-Identifier: CC0-1.0
"""Original source proposal. Execute mesh/GLB verification only after root gate release."""
from pathlib import Path
import json,math,struct,bisect
from limb_ik import solve_limb_3d
P=Path(__file__).parent;S=P.parent/'horse-stop-next'

def smooth(u):return u*u*u*(10+u*(-15+6*u))
def source():
 raw=(S/'input/equine_light_harness_skinned_prototype_01.glb').read_bytes();n=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+n]);blob=raw[28+n:]
 def read(i):
  a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];count={'SCALAR':1,'VEC4':4}[a['type']];flat=struct.unpack_from('<'+'f'*(a['count']*count),blob,v.get('byteOffset',0)+a.get('byteOffset',0));return [list(flat[k:k+count])for k in range(0,len(flat),count)]
 def rotation(clip_name,node_name,phase):
  clip=next(a for a in doc['animations']if a['name']==clip_name);channel=next(c for c in clip['channels']if doc['nodes'][c['target']['node']]['name']==node_name);sampler=clip['samplers'][channel['sampler']];times=[x[0]for x in read(sampler['input'])];qs=read(sampler['output']);t=phase*times[-1];i=max(0,min(len(times)-2,bisect.bisect_right(times,t)-1));u=(t-times[i])/(times[i+1]-times[i]);a=qs[i];b=qs[i+1];dot=sum(x*y for x,y in zip(a,b))
  if dot<0:b=[-x for x in b];dot=-dot
  if dot>.9995:q=[a[k]+u*(b[k]-a[k])for k in range(4)]
  else:
   angle=math.acos(max(-1,min(1,dot)));q=[(a[k]*math.sin((1-u)*angle)+b[k]*math.sin(u*angle))/math.sin(angle)for k in range(4)]
  length=math.sqrt(sum(x*x for x in q));return [x/length for x in q]
 return rotation

def main():
 old_plans=json.loads((S/'stop-plans.json').read_text());states=json.loads((S/'sampled-initial-states.json').read_text());manifest=json.loads((S/'input/manifest.json').read_text());rotation=source();results=[]
 for old in old_plans:
  gait=old['initial_clip'];duration=old['duration_s'];D=old['root_distance_m'];entry=next(s for s in states if s['clip']==gait and s['phase']==old['initial_phase']);exit_phase=(manifest['locomotion'][gait]['stance_fraction']-old['initial_phase'])%1;frames=[]
  for prior in reversed(old['samples']):
   t=duration-prior['time_s'];R=D-prior['distance_m'];frame={'time_s':t,'distance_m':R,'support_count':prior['support_count'],'limbs':{},'secondary_quaternions':{}}
   for label in ['fore_l','fore_r','hind_l','hind_r']:
    old_label=label
    # Walk's quarter-cycle fore offsets change handedness on time reversal;
    # remap foreleft/right timing so resulting gait keeps original named offsets.
    if gait=='walk'and label.startswith('fore'):old_label='fore_r'if label=='fore_l'else'fore_l'
    previous=prior['limbs'][old_label];old_hip=entry['limbs'][old_label]['hip'];hip=entry['limbs'][label]['hip'];point=previous['world_ankle_m'];target=[point[0]-old_hip[0],point[1]-old_hip[1],-(point[2]-prior['distance_m']-old_hip[2])];q=solve_limb_3d(target,label.startswith('fore'));world=[target[k]+hip[k]+(R if k==2 else 0)for k in range(3)]
    frame['limbs'][label]={'quaternions':q,'world_ankle_m':world,'planted':previous['planted'],'contact_segment':previous['contact_segment']}
   for node in ['head','tail_base']:
    goal=rotation(gait,node,exit_phase);u=smooth(t/duration);q=[u*goal[k]+(1-u)*(1 if k==3 else 0)for k in range(4)];length=math.sqrt(sum(x*x for x in q));frame['secondary_quaternions'][node]=[x/length for x in q]
   frames.append(frame)
  results.append({'name':'start_'+gait+'_exit_'+str(round(exit_phase*1000)).zfill(3),'initial_clip':'idle','initial_phase':0,'exit_clip':gait,'exit_phase':exit_phase,'source_stop':old['name'],'duration_s':duration,'root_distance_m':D,'sample_step_s':old['sample_step_s'],'initial_speed_m_s':0,'exit_speed_m_s':manifest['locomotion'][gait]['speed_m_s'],'post_exit_phase_contract':'phase=exit_phase+(external_distance-root_distance_m)/exported_exit_gait_stride; preservephaseoffset, do notresetto0','contract':'finiteinplacejoints+externalnonuniform+Zprofile; noYlift/scaling; mirroredankletargetsNOTreversedjointquaternions','secondary_velocity_gate':'posematched; angularvelocity/accelerationnotaccepted','samples':frames})
 (P/'start-plans.json').write_text(json.dumps(results,separators=(',',':'))+'\n');print(json.dumps({'source_only_startplans':len(results),'not_yet_mesh_validated':True}))
if __name__=='__main__':main()
