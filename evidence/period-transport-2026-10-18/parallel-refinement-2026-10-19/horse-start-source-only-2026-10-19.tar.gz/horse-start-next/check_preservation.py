# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,struct,hashlib
P=Path(__file__).parent

def load(file):
 b=file.read_bytes();n=struct.unpack_from('<I',b,12)[0];return json.loads(b[20:20+n]),b[28+n:]
old,ob=load(P.parent/'horse-stop-next/input/equine_light_harness_skinned_prototype_01.glb');new,nb=load(P/'start_change_study.glb');checks={k:old[k]==new[k]for k in ['nodes','meshes','materials','skins','scenes']};checks['all_original_accessors']=old['accessors']==new['accessors'][:len(old['accessors'])];checks['all_original_buffer_views']=old['bufferViews']==new['bufferViews'][:len(old['bufferViews'])];checks['all_original_buffer_bytes']=ob==nb[:len(ob)];checks['all_original_animations_exact']=old['animations']==new['animations'][:len(old['animations'])];checks['one_shot_external_distance_contract']=all(a['extras']['one_shot']and a['extras']['in_place']and a['extras']['external_root_distance_required']for a in new['animations'][len(old['animations']):]);result={'passed':all(checks.values()),'checks':checks,'baseline_sha256':hashlib.sha256((P.parent/'horse-stop-next/input/equine_light_harness_skinned_prototype_01.glb').read_bytes()).hexdigest(),'stop_glb_sha256':hashlib.sha256((P/'start_change_study.glb').read_bytes()).hexdigest()};(P/'preservation-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(result);assert result['passed']
