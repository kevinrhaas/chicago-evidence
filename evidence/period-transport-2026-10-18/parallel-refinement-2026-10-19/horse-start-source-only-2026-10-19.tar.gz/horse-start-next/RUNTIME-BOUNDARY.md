# Runtime boundary — no integration yet

These source clips are entry-conditioned studies, not a drop-in stopVehicle API. Do not choose a nearest entryphase and snap to it. Current stop proofs cover only exact five phases per gait at exported speed and straightheading; arbitrary current phase/velocity/turns still require targetplanner input/verification. A real controller must capture current actualfoot/bone/rootstate and plan from it, or wait for an actually reachable validated entry while preserving its livegait.

Stop coast requires.2787mwalk/.5449mtrot of clearroute. Do not run after routeend, shorten/clipdistance, liftroot or silently teleport neutral. Brake before routeend; unsupported space/velocity/turn cases need explicit rejection/replan. Longer2sprofile already has saved unreachablefailures.

One-shot playback: stop old action and activate exact newclip at time0 atomically before render, no crossfade; setLoop(LoopOnce,1),clampWhenFinished=true. Externaldistance follows profile time; no legacy phase-wrap/modulo or constantstride integration during finiteclip. At finalstop, await actualneutralcompletion then idle0; at start/change exit, activate targetcyclegait at explicit exitphase and retain distancephaseoffset. Current horsefixture's cyclic tick/defaultdropdown is not a finiteclipplayer.

Abort/dispose/cancel generationguards and cameraexit must have explicit tested ownership. Freezing currentpose may avoid a positionalpop but is not an accepted plantedrecovery or exitsequence; immediateidle0 previouslyfailedjointblend and neutralposepop are not repaired by newdata alone. No async-safe routeadapter, arbitraryphase transitions, steering, rider/reins/harnessloads or browseracceptance implemented here.

Pairedassembly gear tests currently validate cyclictrot/walk, not these newreplant poses. Keep those checks separate; meshes with more extreme steps may collide even when solecontactpasses. Head/tail match exitpose only; angularvelocity/acceleration and biologicalbalance open.

Start/change source depends on stable ../horse-stop-next archive. No newsourceidentity/anatomy/periodauthority arises from a contacttargetplanner. No namedperson orownership introduced. Root remains soleapp/queuewriter.
