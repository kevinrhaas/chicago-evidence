# T-2803 start/change SOURCE-ONLY checkpoint — NOT EXECUTED/ACCEPTED

2026-10-19 outside app. Stable sibling stop study is separate; do not conflate its actual mesh receipts with these proposed starts/changes.

Prepared originalCC0 limb_ik.py,plan_starts.py,export_transitions.py and GPLproject-style validate_start_change.mjs/check_preservation.py/khronos.cjs/Threeimporthook. Only Python syntaxcompile and Node --check ran. **No startplans generated, no newGLB generated, no actual start/change mesh/LBS/browser/Khronos checks executed.** Root holds heavy checks during tail/fullpreflight. Pendingcommands below must run after release and preserve anyfailure.

Read PLANNING.md and RUNTIME-BOUNDARY.md. Target reversal plus longitudinalmirror is essential; reversingjointquaternions withforwardrootmotion wouldslidefeet. Finite stop-through-neutral→start is explicitly slow and not a directcontinuousspeed walk↔trotblend. Existing 5entrycases/gait only; arbitraryphase/currentvelocity/turn/cancel/gear/biomechanical/photo acceptance remainopen.

Dependencies: sibling ../horse-stop-next stable archiveSHAaf9bb658cec4bbc81d35a003209eac7592fffe281e660c8286acadcb5578ca5c. Specifically originalinputhorse+manifest,sampled-initial-states.json andstop-plans.json; exactdependencyfilehashes in DEPENDENCIES.json. That archive alone has bounded actualstopcontactproof. New source does not mutate it.

After root releases:

python plan_starts.py
python export_transitions.py
python check_preservation.py
node khronos.cjs
node --experimental-loader ./three-loader.mjs ./validate_start_change.mjs

Expected prospective gates: actual GLTFLoader/AnimationMixer1001poses per20finiteclips,unchanged100authoredsoleverts,original20mmslide/5mmheight/−1mmpenetration gates,24joinpairs0; entry/fullmesh match and targetgaitexitposematch≤.1mm. That small endpointmatchbound is explicit engineeringtolerance for resampledquaternionpaths, not proofalreadyrun. No rootYlift,scale,markerreplacement or nearestphase snapping. Allolderfailures retained; do not inferfoot/gear/visualacceptance from syntax alone.

Original source CC0; projectvalidationglue GPL. No externalmodel/sourceimage/newlicense dependency. No app/ticket writes, Blender or browser. Root reviews/applies later only after actualtests/visualreview.
