# SPDX-License-Identifier: CC0-1.0
"""Original additive start + explicit stop-through-idle gait-change study exporter.
Source prepared during gate; actual GLB/LBS gates must run after root release.
"""
from pathlib import Path
import json,struct,hashlib
P=Path(__file__).parent;S=P.parent/'horse-stop-next'

def combined_plans(starts,stops):
 results=[]
 for stop in stops:
  exit_gait='trot'if stop['initial_clip']=='walk'else'walk'
  chosen=next(s for s in starts if s['exit_clip']==exit_gait and s['source_stop']==('stop_trot_phase_000'if exit_gait=='trot'else'stop_walk_phase_062'))
  frames=[]
  for frame in stop['samples']:
   frames.append(dict(frame,secondary_quaternions={name:secondary_at(stop,name,frame['time_s'])for name in ['head','tail_base']}))
  for frame in chosen['samples'][1:]:
   limbs={name:dict(v,contact_segment=v['contact_segment']+100,world_ankle_m=[v['world_ankle_m'][j]+(stop['root_distance_m']if j==2 else 0)for j in range(3)])for name,v in frame['limbs'].items()}
   frames.append(dict(frame,time_s=stop['duration_s']+frame['time_s'],distance_m=stop['root_distance_m']+frame['distance_m'],limbs=limbs))
  results.append({'name':'change_'+stop['initial_clip']+'_phase_'+str(round(stop['initial_phase']*100)).zfill(3)+'_through_neutral_to_'+exit_gait,'initial_clip':stop['initial_clip'],'initial_phase':stop['initial_phase'],'exit_clip':exit_gait,'exit_phase':chosen['exit_phase'],'duration_s':stop['duration_s']+chosen['duration_s'],'root_distance_m':stop['root_distance_m']+chosen['root_distance_m'],'sample_step_s':stop['sample_step_s'],'neutral_join_time_s':stop['duration_s'],'strategy':'finiteSTOP/replant then finiteSTART; NOTdirectcontinuousspeed gaitblend','post_exit_phase_contract':chosen['post_exit_phase_contract'],'samples':frames})
 return results

def secondary_at(stop,name,time):
 u=min(1,time/.6);u=u*u*u*(10+u*(-15+6*u));a=stop['secondary_initial_quaternions'][name];q=[a[k]*(1-u)+(1 if k==3 else 0)*u for k in range(4)];n=sum(x*x for x in q)**.5;return[x/n for x in q]

def main():
 raw=(S/'input/equine_light_harness_skinned_prototype_01.glb').read_bytes();n=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+n]);blob=bytearray(raw[28+n:]);starts=json.loads((P/'start-plans.json').read_text());stops=json.loads((S/'stop-plans.json').read_text());plans=starts+combined_plans(starts,stops);names={n['name']:i for i,n in enumerate(d['nodes'])}
 def acc(rows,kind):
  while len(blob)%4:blob.append(0)
  flat=[x for r in rows for x in(r if isinstance(r,list)else[r])];data=struct.pack('<'+'f'*len(flat),*flat);vi=len(d['bufferViews']);d['bufferViews'].append({'buffer':0,'byteOffset':len(blob),'byteLength':len(data)});blob.extend(data);a={'bufferView':vi,'componentType':5126,'count':len(rows),'type':kind}
  if kind=='SCALAR':a.update(min=[min(rows)],max=[max(rows)])
  d['accessors'].append(a);return len(d['accessors'])-1
 for plan in plans:
  frames=plan['samples'];ti=acc([s['time_s']for s in frames],'SCALAR');samplers=[];channels=[]
  def track(name,qs):
   samplers.append({'input':ti,'output':acc(qs,'VEC4'),'interpolation':'LINEAR'});channels.append({'sampler':len(samplers)-1,'target':{'node':names[name],'path':'rotation'}})
  for label in ['fore_l','fore_r','hind_l','hind_r']:
   for j,node in enumerate([label+'_upper',label+('_carpus'if label.startswith('fore')else'_hock'),label+'_fetlock']):track(node,[s['limbs'][label]['quaternions'][j]for s in frames])
  for node in ['head','tail_base']:track(node,[s['secondary_quaternions'][node]for s in frames])
  d['animations'].append({'name':plan['name'],'samplers':samplers,'channels':channels,'extras':{'status':'synthetic_source_transition_proposal_NOTaccepted','one_shot':True,'loop':False,'in_place':True,'external_root_distance_required':True,'entry_clip':plan['initial_clip'],'entry_phase':plan['initial_phase'],'exit_clip':plan['exit_clip'],'exit_phase':plan['exit_phase'],'duration_s':plan['duration_s'],'distance_profile':plan['name'],'root_distance_m':plan['root_distance_m'],'strategy':plan.get('strategy','mirrored_reversed_ankle_targets_then3DIK_NOTreversedquaternions'),'secondary_motion':'posematchedonlyangularvelocitynotaccepted'}})
 while len(blob)%4:blob.append(0)
 d['buffers'][0]['byteLength']=len(blob);jb=json.dumps(d,separators=(',',':')).encode();jb+=b' '*((-len(jb))%4);data=struct.pack('<III',0x46546c67,2,28+len(jb)+len(blob))+struct.pack('<II',len(jb),0x4e4f534a)+jb+struct.pack('<II',len(blob),0x004e4942)+blob;(P/'start_change_study.glb').write_bytes(data)
 profiles=[{k:v for k,v in plan.items()if k!='samples'}|{'samples':[{'time_s':s['time_s'],'distance_m':s['distance_m'],'support_count':s['support_count'],'contacts':{name:{'planted':v['planted'],'contact_segment':v['contact_segment']}for name,v in s['limbs'].items()}}for s in plan['samples']]}for plan in plans];(P/'transition-profiles.json').write_text(json.dumps({'input_sha256':hashlib.sha256(raw).hexdigest(),'glb_sha256':hashlib.sha256(data).hexdigest(),'contract':'ONE_SHOT+exact external+Zdistance/time; noYlift/scale/doublemotion; apply exitphaseoffset on resumingtargetgait; no directcontinuousspeedtransition claim','profiles':profiles},separators=(',',':'))+'\n');print({'source_exported_clips':len(plans),'bytes':len(data),'mesh_validation_pending':True})
if __name__=='__main__':main()
