from pathlib import Path
import difflib
O=Path(__file__).parent;old=Path('/workspace/shared/vehicle-boarding-next/boarding-controller.mjs').read_text();new=old.replace("mode='camera-study',person=null,gates={}","mode='camera-study',person=null,gates={},role='passenger'")
new=new.replace("if(seats.some(s=>!s.id||s.role!=='passenger'", "if(!['passenger','rider'].includes(role))throw Error('Unsupported attachment role');\n  if(seats.some(s=>!s.id||s.role!==role")
new=new.replace("!['sceneRoute','hitch','seatedHumanFit','cameraCollision'].every(k=>gates[k]===true)","!(role==='rider'?['sceneRoute','ridingTack','riderFit','gaitContact','cameraCollision']:['sceneRoute','hitch','seatedHumanFit','cameraCollision']).every(k=>gates[k]===true)")
new=new.replace("mode,person,reducedMotion});", "mode,person,reducedMotion,role});")
new=new.replace('export function validatePortablePassenger(actor,{scene,fit})','export function validatePortableAttachment(actor,{scene,fit,role=\'passenger\'})').replace("fit?.role!=='passenger'","fit?.role!==role")
new+="\nexport function validatePortablePassenger(actor,options){return validatePortableAttachment(actor,{...options,role:'passenger'}); }\n"
(O/'interaction-core-proposed.mjs').write_text(new)
(O/'shared-core-role-extension.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/renderers/web/js/vehicle-boarding.js',tofile='b/renderers/web/js/vehicle-boarding.js')))
