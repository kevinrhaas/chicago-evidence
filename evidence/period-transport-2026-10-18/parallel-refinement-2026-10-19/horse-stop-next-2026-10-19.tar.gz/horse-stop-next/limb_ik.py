# SPDX-License-Identifier: CC0-1.0
# Project-original3D two-bone sphere-intersection solver; no biological acceptance.
import math
def qmul(a, b):
    x, y, z, w = a
    X, Y, Z, W = b
    return [w * X + x * W + y * Z - z * Y, w * Y - x * Z + y * W + z * X, w * Z + x * Y - y * X + z * W, w * W - x * X - y * Y - z * Z]

def qinv(q):
    return [-q[0], -q[1], -q[2], q[3]]

def qrotate(q, v):
    return qmul(qmul(q, [*v, 0]), qinv(q))[:3]

def from_down(v):
    n = math.sqrt(sum((x * x for x in v)))
    v = [x / n for x in v]
    q = [-v[2], 0, v[0], 1 - v[1]]
    n = math.sqrt(sum((x * x for x in q)))
    if n < 1e-10:
        raise ValueError('Antiparallel target requires explicit bend frame')
    return [x / n for x in q]

def solve_limb_3d(target, fore):
    L1 = 0.65
    L2 = 0.55
    r = math.sqrt(sum((x * x for x in target)))
    if not abs(L1 - L2) < r < L1 + L2:
        raise ValueError('Unreachable ankle target')
    d = [x / r for x in target]
    axis = [1.0, 0.0, 0.0]
    projection = sum((axis[i] * d[i] for i in range(3)))
    axis = [axis[i] - projection * d[i] for i in range(3)]
    n = math.sqrt(sum((x * x for x in axis)))
    axis = [x / n for x in axis]
    perp = [axis[1] * d[2] - axis[2] * d[1], axis[2] * d[0] - axis[0] * d[2], axis[0] * d[1] - axis[1] * d[0]]
    sign = -1 if fore else 1
    distance = (L1 * L1 - L2 * L2 + r * r) / (2 * r)
    height = math.sqrt(max(0, L1 * L1 - distance * distance))
    knee = [distance * d[i] + sign * height * perp[i] for i in range(3)]
    upper = from_down(knee)
    lower_vector = [target[i] - knee[i] for i in range(3)]
    lower = from_down(qrotate(qinv(upper), lower_vector))
    fetlock = qinv(qmul(upper, lower))
    return (upper, lower, fetlock)
