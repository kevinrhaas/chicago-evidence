# SPDX-License-Identifier: CC0-1.0
"""Original world-foot-target finite stop/replant planner. No joint-pose blending."""
from pathlib import Path
import json,math,ast,copy,os
P=Path(__file__).parent;manifest=json.loads((P/'input/manifest.json').read_text());states=json.loads((P/'sampled-initial-states.json').read_text())
# Reuse only original CC0 geometric solver functions, not executing generator CLI.
import limb_ik
scope={'solve_limb_3d':limb_ik.solve_limb_3d}
DT=1/240;DECEL=float(os.environ.get('STOP_DECEL_S','.6'));STEP=.45;LIFT=.14;PREFIX=os.environ.get('STOP_PREFIX','')

def smooth(u):return u*u*u*(10+u*(-15+6*u))
def path(gait,phase):
 S=gait['stance_fraction'];sweep=gait['stride_m']*S
 if phase<S:return sweep*(.5-phase/S),0
 q=(phase-S)/(1-S);m=-sweep*(1-S)/S;z=(2*q**3-3*q*q+1)*(-sweep/2)+(q**3-2*q*q+q)*m+(-2*q**3+3*q*q)*(sweep/2)+(q**3-q*q)*m
 return z,(.12 if gait is manifest['locomotion'].get('trot') else .14)*16*q*q*(1-q)**2

def plan(state):
 gait=manifest['locomotion'][state['clip']];v=gait['speed_m_s'];D=v*DECEL/2;cycle=gait['cycle_duration_s'];S=gait['stance_fraction'];sweep=gait['stride_m']*S
 def root(t):
  if t>=DECEL:return D
  return v/2*(t+DECEL/math.pi*math.sin(math.pi*t/DECEL))
 feet={};events=[]
 for label,limb in state['limbs'].items():
  phase=(state['phase']+gait['phase_offsets'][label])%1;ankle=list(limb['ankle']);f={'hip':limb['hip'],'point':ankle,'goal':[limb['hip'][0],.1,limb['hip'][2]+D],'segment':0,'swing':None}
  if phase>=S:
   q=(phase-S)/(1-S);duration=(1-q)*(1-S)*cycle
   eps=1e-6;z0,y0=path(gait,phase);za,_=path(gait,max(S,phase-eps));zb,_=path(gait,min(1-1e-10,phase+eps));vz=(zb-za)/(2*eps*cycle)+v
   f['swing']={'kind':'existing','start':0,'end':duration,'from':ankle,'to':[limb['hip'][0],.1,limb['hip'][2]+root(duration)+sweep/2],'q0':q,'initial_lift':ankle[1]-.1,'z_velocity':vz,'initial_y_error':ankle[1]-.1-y0}
  feet[label]=f
 samples=[];maxReach=0;minimumSupport=4
 for k in range(1201):
  t=k*DT;R=root(t)
  for f in feet.values():
   swing=f['swing']
   if not swing:continue
   if t>=swing['end']-1e-12:f['point']=swing['to'][:];f['swing']=None;continue
   u=(t-swing['start'])/(swing['end']-swing['start']);h=smooth(u);start=swing['from'];end=swing['to'];point=[start[j]+(end[j]-start[j])*h for j in range(3)]
   if swing['kind']=='existing':
    # Match initial world foot-Z velocity and zero final velocity with quintic endpoint basis.
    duration=swing['end'];point[2]+=swing['z_velocity']*duration*(u-6*u**3+8*u**4-3*u**5)
    q=swing['q0']+(1-swing['q0'])*u;lift=(.12 if state['clip']=='trot' else .14)*16*q*q*(1-q)**2;point[1]=.1+lift+swing['initial_y_error']*(1-u)**3
   else:point[1]=start[1]+(.1-start[1])*h+LIFT*16*u*u*(1-u)**2
   f['point']=point
  # Keep at leasttwofeet planted when initiating replant steps. Initial inherited
  # gait swing contacts are not reclassified to hide a failure.
  support=sum(f['swing']is None for f in feet.values());minimumSupport=min(minimumSupport,support)
  candidates=[(f['point'][2]-R-f['hip'][2],label,f)for label,f in feet.items() if f['swing']is None and math.dist(f['point'],f['goal'])>1e-5 and (f['point'][2]-R-f['hip'][2]<-.20 or t>=DECEL)]
  candidates.sort(key=lambda item:item[0])
  while support>2 and candidates:
   _,label,f=candidates.pop(0);f['segment']+=1;f['swing']={'kind':'replant','start':t,'end':t+STEP,'from':f['point'][:],'to':f['goal'][:]};events.append({'time_s':t,'limb':label,'kind':'replant','touchdown_s':t+STEP});support-=1
  frame={'time_s':t,'distance_m':R,'limbs':{},'support_count':support}
  for label,f in feet.items():
   target=[f['point'][j]-f['hip'][j]-(R if j==2 else 0)for j in range(3)];reach=math.sqrt(sum(x*x for x in target));maxReach=max(maxReach,reach)
   try:q=scope['solve_limb_3d'](target,label.startswith('fore'))
   except ValueError as error:raise ValueError(f'{state["clip"]}phase{state["phase"]}t{t} {label} unreachable{reach}: {target}')from error
   frame['limbs'][label]={'quaternions':q,'planted':f['swing']is None,'contact_segment':f['segment'],'world_ankle_m':f['point'][:]}
  samples.append(frame)
  if t>=DECEL and all(f['swing']is None and math.dist(f['point'],f['goal'])<1e-5 for f in feet.values()):break
 else:raise ValueError('Planner did not settle')
 return {'name':'stop_'+state['clip']+'_phase_'+str(round(state['phase']*100)).zfill(3),'initial_clip':state['clip'],'initial_phase':state['phase'],'duration_s':samples[-1]['time_s'],'root_distance_m':D,'initial_speed_m_s':v,'deceleration_s':DECEL,'sample_step_s':DT,'max_ankle_reach_m':maxReach,'minimum_support':minimumSupport,'events':events,'samples':samples,'secondary_initial_quaternions':state['secondary'],'contract':'in_placejointclip; apply external+Zactortranslation from exact nonuniformdistance/time sidecar; do not add constantclipstride or rootYlift'}
results=[];failures=[]
for state in states:
 try:results.append(plan(state))
 except ValueError as e:failures.append({'clip':state['clip'],'phase':state['phase'],'failure':str(e)})
(P/(PREFIX+'stop-plans.json')).write_text(json.dumps(results,separators=(',',':'))+'\n');(P/(PREFIX+'planner-failures.json')).write_text(json.dumps(failures,indent=2)+'\n');print(json.dumps({'planned':len(results),'failures':failures,'durations':[r['duration_s']for r in results],'maxreach':max((r['max_ankle_reach_m']for r in results),default=None)}));
