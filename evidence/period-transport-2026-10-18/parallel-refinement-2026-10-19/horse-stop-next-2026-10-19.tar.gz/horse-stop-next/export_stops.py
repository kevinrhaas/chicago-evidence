# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,struct,hashlib,math
P=Path(__file__).parent;file=P/'input/equine_light_harness_skinned_prototype_01.glb';raw=file.read_bytes();n=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+n]);blob=bytearray(raw[28+n:]);plans=json.loads((P/'stop-plans.json').read_text());names={n['name']:i for i,n in enumerate(d['nodes'])}
def acc(rows,typ):
 while len(blob)%4:blob.append(0)
 values=[x for row in rows for x in(row if isinstance(row,list)else[row])];data=struct.pack('<'+'f'*len(values),*values);view=len(d['bufferViews']);d['bufferViews'].append({'buffer':0,'byteOffset':len(blob),'byteLength':len(data)});blob.extend(data);a={'bufferView':view,'componentType':5126,'count':len(rows),'type':typ}
 if typ=='SCALAR':a.update(min=[min(rows)],max=[max(rows)])
 d['accessors'].append(a);return len(d['accessors'])-1
for plan in plans:
 samples=plan['samples'];ti=acc([s['time_s']for s in samples],'SCALAR');samplers=[];channels=[]
 def track(name,qs):
  samplers.append({'input':ti,'output':acc(qs,'VEC4'),'interpolation':'LINEAR'});channels.append({'sampler':len(samplers)-1,'target':{'node':names[name],'path':'rotation'}})
 for label in ['fore_l','fore_r','hind_l','hind_r']:
  for j,node in enumerate([label+'_upper',label+('_carpus'if label.startswith('fore')else'_hock'),label+'_fetlock']):track(node,[s['limbs'][label]['quaternions'][j]for s in samples])
 for node,initial in plan['secondary_initial_quaternions'].items():
  qs=[]
  for s in samples:
   u=min(1,s['time_s']/.6);u=u*u*u*(10+u*(-15+6*u));q=[initial[j]*(1-u)+(1 if j==3 else 0)*u for j in range(4)];length=math.sqrt(sum(x*x for x in q));qs.append([x/length for x in q])
  track(node,qs)
 d['animations'].append({'name':plan['name'],'samplers':samplers,'channels':channels,'extras':{'status':'synthetic_original_stop_replant_trial_not_production','one_shot':True,'loop':False,'entry_clip':plan['initial_clip'],'entry_phase':plan['initial_phase'],'duration_s':plan['duration_s'],'in_place':True,'external_root_distance_required':True,'distance_profile':plan['name'],'root_translation_axis':'+Z','root_y_motion_m':0,'root_distance_m':plan['root_distance_m'],'contact_basis':'same_actual_authored_hoofsolevertices_no_marker_changes','gates_open':['arbitraryphasecoverage','collisionandgear','biomechanics','browser','startandgaittransitions','photographicquality']}})
while len(blob)%4:blob.append(0)
d['buffers'][0]['byteLength']=len(blob);jb=json.dumps(d,separators=(',',':')).encode();jb+=b' '*((-len(jb))%4);encoded=struct.pack('<III',0x46546c67,2,28+len(jb)+len(blob))+struct.pack('<II',len(jb),0x4e4f534a)+jb+struct.pack('<II',len(blob),0x004e4942)+blob;(P/'stop_study.glb').write_bytes(encoded)
profiles=[{k:v for k,v in plan.items()if k not in ['samples','secondary_initial_quaternions']}|{'samples':[{'time_s':s['time_s'],'distance_m':s['distance_m'],'support_count':s['support_count'],'contacts':{name:{'planted':v['planted'],'contact_segment':v['contact_segment']}for name,v in s['limbs'].items()}}for s in plan['samples']]}for plan in plans];(P/'stop-profiles.json').write_text(json.dumps({'input_sha256':hashlib.sha256(raw).hexdigest(),'glb_sha256':hashlib.sha256(encoded).hexdigest(),'contract':'ONE_SHOT clip+exactexternalactor+Zdistance-timeprofile; no constantstride/noextra rootmotion/noYlift. Do not loop or crossfade joints to idle. At finalactualneutralpose, switchidle0afterawaitedcompletion.','profiles':profiles},separators=(',',':'))+'\n');print(json.dumps({'bytes':len(encoded),'clips':len(plans),'sha256':hashlib.sha256(encoded).hexdigest()}))
