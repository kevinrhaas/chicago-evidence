# SPDX-License-Identifier: GPL-3.0-or-later
import pathlib,json,struct,hashlib,sys,numpy as np
P=pathlib.Path(__file__).parent;variant=sys.argv[1] if len(sys.argv)>1 else 'trial-v3'
def load(name):
 b=(P/name/'equine_light_harness_skinned_prototype_01.glb').read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);blob=b[28+n:];m=json.loads((P/name/'manifest.json').read_text())
 def read(i):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];c={'SCALAR':1,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];return np.frombuffer(blob,dtype={5126:'<f4',5123:'<u2',5125:'<u4'}[a['componentType']],count=a['count']*c,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,c).copy()
 return b,d,m,read
bb,b,bm,br=load('baseline');tb,t,tm,tr=load(variant);protected=[];changed=[]
for old in bm['vertex_ranges']:
 name=old['original_node'];new=next(x for x in tm['vertex_ranges']if x['original_node']==name)
 if name.startswith('fore_')and name.endswith('_upper_mesh'):changed.append(name);continue
 assert old['vertex_count']==new['vertex_count'];mat=old['material'];bp=b['meshes'][mat]['primitives'][0];tp=t['meshes'][mat]['primitives'][0]
 for attr in ['POSITION','NORMAL','JOINTS_0','WEIGHTS_0']:
  aa=br(bp['attributes'][attr])[old['vertex_start']:old['vertex_start']+old['vertex_count']];cc=tr(tp['attributes'][attr])[new['vertex_start']:new['vertex_start']+new['vertex_count']];assert np.array_equal(aa,cc),(name,attr)
 protected.append(name)
assert b['nodes']==t['nodes'];assert bm['sockets']==tm['sockets'];assert bm['locomotion']==tm['locomotion'];assert bm['joint_table']==tm['joint_table'];assert np.array_equal(br(b['skins'][0]['inverseBindMatrices']),tr(t['skins'][0]['inverseBindMatrices']))
for ba,ta in zip(b['animations'],t['animations']):
 assert ba['channels']==ta['channels']
 for bs,ts in zip(ba['samplers'],ta['samplers']):
  for key in ['input','output']:assert np.array_equal(br(bs[key]),tr(ts[key]))
areas=[]
for mesh in t['meshes']:
 a=mesh['primitives'][0];v=tr(a['attributes']['POSITION']);f=tr(a['indices']).reshape(-1,3);areas.extend(np.linalg.norm(np.cross(v[f[:,1]]-v[f[:,0]],v[f[:,2]]-v[f[:,0]]),axis=1)/2)
r={'variant':variant,'baseline_sha256':hashlib.sha256(bb).hexdigest(),'trial_sha256':hashlib.sha256(tb).hexdigest(),'baseline_triangles':bm['triangles'],'trial_triangles':tm['triangles'],'draws':tm['mesh_draws'],'protected_exact_ranges':protected,'changed_only':changed,'nodes_skeleton_inversebind_sockets_locomotion_animation_arrays_exact':True,'minimum_triangle_area_m2':float(min(areas)),'zero_area_triangles':int(sum(x==0 for x in areas))}
(P/(variant+'-source-invariants.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
