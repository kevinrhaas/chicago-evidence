# SPDX-License-Identifier: CC0-1.0
import pathlib,json,struct,math,hashlib
p=pathlib.Path(__file__).parent;b=(p/'output/civilian_english_form_1835_reconstructed_01.glb').read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);blob=b[28+n:]
def read(i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];c={'VEC3':3}[a['type']];x=struct.unpack_from('<'+'f'*(a['count']*c),blob,v.get('byteOffset',0));return [x[i:i+c]for i in range(0,len(x),c)]
minarea=math.inf;nonfinite=0;triangles=0
for mesh in d['meshes']:
 for pr in mesh['primitives']:
  v=read(pr['attributes']['POSITION']);norm=read(pr['attributes']['NORMAL']);nonfinite+=sum(not all(map(math.isfinite,row))for row in v+norm)
  for i in range(0,len(v),3):
   a,b_,c=v[i:i+3];u=[b_[k]-a[k]for k in range(3)];w=[c[k]-a[k]for k in range(3)];cross=[u[1]*w[2]-u[2]*w[1],u[2]*w[0]-u[0]*w[2],u[0]*w[1]-u[1]*w[0]];minarea=min(minarea,math.sqrt(sum(x*x for x in cross))/2);triangles+=1
names=[n['name']for n in d['nodes']];required=['socket_riding_rider_seat','socket_riding_seat']+['socket_riding_'+role+'_'+side for role in ['stirrup_foot','rein_hand','bit']for side in ['l','r']]
checks={'all_anchor_nodes':all(x in names for x in required),'finite_geometry':nonfinite==0,'nondegenerate_triangles':minarea>1e-14,'distinct_riding_assembly':not any(any(x in name for x in ['trace','shaft_tug','check_rein','breeching'])for name in names),'texture_free':not d.get('images')}
r={'passed':all(checks.values()),'checks':checks,'triangles':triangles,'min_triangle_area_m2':minarea,'nonfinite':nonfinite,'glb_sha256':hashlib.sha256(b).hexdigest(),'anchor_count':len(required),'scope':'Original geometric/anchor contract only; no rider fitted, no structural/period/photographic acceptance'};(p/'geometry-validation.json').write_text(json.dumps(r,indent=2)+'\n');print(r);assert r['passed']
