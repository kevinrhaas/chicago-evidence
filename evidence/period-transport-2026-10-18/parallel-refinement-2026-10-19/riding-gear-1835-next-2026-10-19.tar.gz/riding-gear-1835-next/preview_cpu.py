# SPDX-License-Identifier: CC0-1.0
# Original diagnostic painter projection, not glTF/PBR renderer acceptance.
import pathlib,json,struct,math
import numpy as np
from PIL import Image,ImageDraw
P=pathlib.Path(__file__).parent

def load(file):
 b=file.read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);blob=b[28+n:]
 def read(i):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];return np.frombuffer(blob,dtype={5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']],offset=v.get('byteOffset',0)+a.get('byteOffset',0),count=a['count']*{'VEC3':3,'SCALAR':1}[a['type']]).reshape(a['count'],-1)
 parent={c:i for i,n in enumerate(d['nodes'])for c in n.get('children',[])}
 def translation(i):return np.asarray(d['nodes'][i].get('translation',[0,0,0]))+(translation(parent[i])if i in parent else 0)
 faces=[]
 for ni,node in enumerate(d['nodes']):
  if 'mesh'not in node:continue
  for pr in d['meshes'][node['mesh']]['primitives']:
   v=read(pr['attributes']['POSITION'])+translation(ni);ix=read(pr['indices']).ravel().astype(int).reshape(-1,3)if'indices'in pr else np.arange(len(v)).reshape(-1,3)
   color=d['materials'][pr['material']]['pbrMetallicRoughness']['baseColorFactor'][:3]
   for ids in ix:faces.append((v[ids],color))
 return faces
faces=load(P/'horse-input/equine_light_harness_skinned_prototype_01.glb')+load(P/'output/civilian_english_form_1835_reconstructed_01.glb')
for view,theta in [('profile',math.pi/2),('front',0),('three-quarter',math.pi/4)]:
 image=Image.new('RGB',(1000,1000),(214,218,214));draw=ImageDraw.Draw(image);forward=np.array([math.sin(theta),0,math.cos(theta)]);right=np.array([math.cos(theta),0,-math.sin(theta)]);center=np.array([0,1.35,-.15]);light=np.array([.6,.8,.7]);light/=np.linalg.norm(light)
 rows=[]
 for points,color in faces:
  n=np.cross(points[1]-points[0],points[2]-points[0]);length=np.linalg.norm(n)
  if length==0:continue
  n/=length;shade=.45+.55*abs(float(n@light));rgb=tuple(int(255*min(1,max(0,c))**(1/2.2)*shade)for c in color);xy=[(500+float((v-center)@right)*650,500-(v[1]-center[1])*650)for v in points];rows.append((float(points.mean(axis=0)@forward),xy,rgb))
 for _,xy,rgb in sorted(rows,key=lambda x:x[0]):draw.polygon(xy,fill=rgb)
 draw.rectangle((0,0,1000,44),fill=(245,245,240));draw.text((12,12),'1835 original riding gear source-fit CPU diagnostic / '+view+' / NOT browser or historical acceptance',fill=(20,20,20));image.save(P/('cpu-'+view+'.png'))
