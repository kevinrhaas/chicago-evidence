# SPDX-License-Identifier: CC0-1.0
#!/usr/bin/env python3
"""Original parametric harness fixture: no photograph inputs or external geometry. Stdlib only."""
import json,math,pathlib,struct,argparse
parser=argparse.ArgumentParser();parser.add_argument('--parameters',type=pathlib.Path,required=True);parser.add_argument('--output-dir',type=pathlib.Path,required=True);parser.add_argument('--horse-input',type=pathlib.Path,required=True);args=parser.parse_args();P=args.output_dir;P.mkdir(parents=True,exist_ok=True)
p=json.loads(args.parameters.read_text())
d={'asset':{'version':'2.0','generator':'original civilian riding saddle/bridle reconstruction'},'scene':0,'scenes':[{'nodes':[0]}],'nodes':[],'meshes':[],'materials':[],'accessors':[],'bufferViews':[],'buffers':[]}
bin=bytearray();stats={}
def vector(a,b):return [a[i]-b[i] for i in range(3)]
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def unit(a):
 n=math.sqrt(sum(v*v for v in a));return [v/n for v in a] if n>1e-9 else [1,0,0]
def accessor(rows,kind,component=5126):
 while len(bin)%4:bin.append(0)
 flat=[v for r in rows for v in (r if isinstance(r,(list,tuple)) else [r])];off=len(bin);bin.extend(struct.pack('<'+('f' if component==5126 else 'I')*len(flat),*flat));vi=len(d['bufferViews']);d['bufferViews'].append({'buffer':0,'byteOffset':off,'byteLength':len(bin)-off});a={'bufferView':vi,'componentType':component,'count':len(rows),'type':kind}
 if kind=='VEC3':a.update(min=[min(r[i] for r in rows) for i in range(3)],max=[max(r[i] for r in rows) for i in range(3)])
 if kind=='SCALAR':a.update(min=[min(rows)],max=[max(rows)])
 d['accessors'].append(a);return len(d['accessors'])-1
def material(name,c,metal=0,rough=.55):
 d['materials'].append({'name':name,'pbrMetallicRoughness':{'baseColorFactor':c+[1],'metallicFactor':metal,'roughnessFactor':rough}});return len(d['materials'])-1
leather=material('tack_leather',p['leather_linear_rgb']);nickel=material('riding_iron_reconstructed',p['metal_linear_rgb'],1,.27);stitch=material('tack_stitch_reconstructed',[.13,.10,.065],0,.85)
def node(name,parent=0,translation=None,extras=None,mesh=None):
 n={'name':name}
 if translation is not None:n['translation']=translation
 if extras:n['extras']=extras
 if mesh is not None:n['mesh']=mesh
 d['nodes'].append(n);i=len(d['nodes'])-1
 if i: d['nodes'][parent].setdefault('children',[]).append(i)
 return i
node('root',extras={'chicago4d_riding_gear':{'version':'fixture_0.1','license':'CC0-1.0','grade':'reconstructed','not_production':True,'source':'Lebeaud1833 component/material text + Adams1805 snaffle comparator; no visual source geometry'}})
head=node('riding_head',translation=p['head_origin_m'],extras={'bind_to_horse_node':'head','binding_status':'rest_aligned_only'})
def mesh(name,vs,faces,ma,parent=0,extra=None):
 # Flat normals retain the visible thickness of rectangular straps.
 vv=[];nn=[]
 for f in faces:
  n=unit(cross(vector(vs[f[1]],vs[f[0]]),vector(vs[f[2]],vs[f[0]])))
  for k in f:vv.append(vs[k]);nn.append(n)
 mi=len(d['meshes']);d['meshes'].append({'name':name,'primitives':[{'attributes':{'POSITION':accessor(vv,'VEC3'),'NORMAL':accessor(nn,'VEC3')},'material':ma}]});stats[name]={'triangles':len(faces),'material':d['materials'][ma]['name']};return node(name,parent,mesh=mi,extras=extra or {'dimension_grade':'reconstructed'})
def strap(name,points,width=None,thick=None,parent=0,ma=leather,width_axis=(1,0,0),extra=None,surface_normals=None):
 w=width or p['strap_width_m'];t=thick or p['strap_thickness_m'];vs=[]
 for j,c in enumerate(points):
  tangent=unit(vector(points[min(len(points)-1,j+1)],points[max(0,j-1)]));side=unit(vector(width_axis,[tangent[k]*sum(width_axis[i]*tangent[i] for i in range(3)) for k in range(3)]));normal=unit(cross(tangent,side))
  if surface_normals:
   side=unit(cross(surface_normals[j],tangent))
   if side[1]<0:side=[-v for v in side]
   normal=unit(cross(tangent,side))
  for sw,st in [(-1,-1),(1,-1),(1,1),(-1,1)]:vs.append([c[k]+side[k]*sw*w/2+normal[k]*st*t/2 for k in range(3)])
 fs=[]
 for j in range(len(points)-1):
  for k in range(4):a=j*4+k;b=j*4+(k+1)%4;c=b+4;e=a+4;fs.extend([(a,b,c),(a,c,e)])
 fs.extend([(0,2,1),(0,3,2)]);k=len(vs)-4;fs.extend([(k,k+1,k+2),(k,k+2,k+3)]);return mesh(name,vs,fs,ma,parent,extra)
def tube(name,points,r=.004,parent=0,ma=leather,N=8):
 vs=[]
 for j,c in enumerate(points):
  tan=unit(vector(points[min(j+1,len(points)-1)],points[max(0,j-1)]));a=unit(cross(tan,[0,1,0] if abs(tan[1])<.95 else [1,0,0]));b=cross(tan,a)
  for k in range(N):v=k*2*math.pi/N;vs.append([c[i]+r*(a[i]*math.cos(v)+b[i]*math.sin(v)) for i in range(3)])
 fs=[]
 for j in range(len(points)-1):
  for k in range(N):a=j*N+k;b=j*N+(k+1)%N;c=b+N;e=a+N;fs.extend([(a,b,c),(a,c,e)])
 return mesh(name,vs,fs,ma,parent)
def arc_xy(cx,cy,z,rx,ry,start=0,end=2*math.pi,N=36):return [[cx+rx*math.cos(start+(end-start)*i/N),cy+ry*math.sin(start+(end-start)*i/N),z] for i in range(N+1)]
def ring(name,c,rx=.028,ry=.028,parent=0):tube(name,arc_xy(c[0],c[1],c[2],rx,ry),.003,parent,nickel)
# Exact current original horse surface, read only. No historical measurements inferred.
import hashlib
horse_raw=args.horse_input.read_bytes();hn=struct.unpack_from('<I',horse_raw,12)[0];hd=json.loads(horse_raw[20:20+hn]);hb=horse_raw[28+hn:]
def read_horse(i):
 a=hd['accessors'][i];v=hd['bufferViews'][a['bufferView']];c={'SCALAR':1,'VEC3':3,'VEC4':4}[a['type']];fmt={5126:'f',5125:'I',5123:'H'}[a['componentType']];rows=struct.unpack_from('<'+fmt*(a['count']*c),hb,v.get('byteOffset',0)+a.get('byteOffset',0));return [rows[k:k+c] for k in range(0,len(rows),c)]
horse_manifest=json.loads(args.horse_input.with_name('manifest.json').read_text());body_range=next(r for r in horse_manifest['vertex_ranges'] if r['original_node']=='continuous_body_neck');body_start=body_range['vertex_start'];body_stop=body_start+body_range['vertex_count']
body=next(m for m in hd['meshes'] if m['name']=='skinned_equine_coat')['primitives'][0];hv=read_horse(body['attributes']['POSITION']);hi=[x[0] for x in read_horse(body['indices'])];body_triangles=[tuple(hv[hi[j+k]] for k in range(3)) for j in range(0,len(hi),3) if all(body_start<=hi[j+k]<body_stop for k in range(3))]
def ray_hit(origin,direction):
 # Moller-Trumbore against actual retained torso triangles; positive outermost hit.
 hits=[]
 for a,b,c in body_triangles:
  e1=vector(b,a);e2=vector(c,a);h=cross(direction,e2);det=sum(e1[k]*h[k] for k in range(3))
  if abs(det)<1e-12:continue
  inv=1/det;s=vector(origin,a);u=inv*sum(s[k]*h[k] for k in range(3))
  if not -1e-9<=u<=1+1e-9:continue
  q=cross(s,e1);v=inv*sum(direction[k]*q[k] for k in range(3))
  if v< -1e-9 or u+v>1+1e-9:continue
  t=inv*sum(e2[k]*q[k] for k in range(3))
  if t>=0:hits.append(t)
 if not hits:raise ValueError('No torso ray hit at '+str(origin))
 return max(hits)
def top(x,z):return ray_hit([x,0,z],[0,1,0])
linen=material('reconstructed_linen_panels',[.36,.32,.24],rough=.94);wood=material('reconstructed_beech_tree',[.25,.14,.065],rough=.8)
# Paired closed conforming panels leave an explicit .11m unsupported spine channel.
for side,s in [('l',1),('r',-1)]:
 vs=[];N=17;M=7
 for upper in [False,True]:
  for j in range(N):
   z=p['panel_z_range_m'][0]+(p['panel_z_range_m'][1]-p['panel_z_range_m'][0])*j/(N-1)
   for k in range(M):
    x=s*(p['panel_x_range_m'][0]+(p['panel_x_range_m'][1]-p['panel_x_range_m'][0])*k/(M-1));vs.append([x,top(x,z)+p['panel_surface_offset_m']+(p['panel_thickness_m'] if upper else 0),z])
 fs=[];o=N*M
 for j in range(N-1):
  for k in range(M-1):
   a=j*M+k;b=a+1;c=b+M;e=a+M;fs.extend([(a,c,b),(a,e,c),(a+o,b+o,c+o),(a+o,c+o,e+o)])
 boundary=list(range(M))+[j*M+M-1 for j in range(1,N)]+list(range((N-1)*M+M-2,(N-1)*M-1,-1))+[j*M for j in range(N-2,0,-1)]
 for k,a in enumerate(boundary):b=boundary[(k+1)%len(boundary)];fs.extend([(a,b,b+o),(a,b+o,a+o)])
 # Mirroring changes winding; signed volume orients each closed component outward.
 vol=sum(sum(vs[a][i]*cross(vs[b],vs[c])[i] for i in range(3)) for a,b,c in fs)
 if vol<0:fs=[(a,c,b) for a,b,c in fs]
 mesh('panel_'+side,vs,fs,linen)
 # Beech sidebar and independent reconstructed rounded quarters outside panel edge.
 strap('tree_sidebar_'+side,[[s*.13,top(s*.13,z)+.049,z] for z in [-.47,-.35,-.2,-.05]],.055,.020,ma=wood)
# Original closed, lightly curved leather shell grids. No photographic cut pattern.
def shell(name,top_grid,bottom_grid,N,M,ma):
 vs=top_grid+bottom_grid;o=N*M;fs=[]
 for j in range(N-1):
  for k in range(M-1):
   a=j*M+k;b=a+1;c=b+M;e=a+M;fs.extend([(a,b,c),(a,c,e),(a+o,c+o,b+o),(a+o,e+o,c+o)])
 boundary=list(range(M))+[j*M+M-1 for j in range(1,N)]+list(range((N-1)*M+M-2,(N-1)*M-1,-1))+[j*M for j in range(N-2,0,-1)]
 for k,a in enumerate(boundary):b=boundary[(k+1)%len(boundary)];fs.extend([(a,b,b+o),(a,b+o,a+o)])
 vol=sum(sum(vs[a][i]*cross(vs[b],vs[c])[i]for i in range(3))for a,b,c in fs)
 if vol<0:fs=[(a,c,b)for a,b,c in fs]
 mesh(name,vs,fs,ma)
def seat_y(z):return p['seat_height_m']+.030*(2*(z+.48)/.535-1)**2
for side,sign in [('l',1),('r',-1)]:
 # Rounded lower quarter silhouette, conforming to actual back cross-section.
 topv=[];bottomv=[];N=17;M=13
 for i in range(N):
  t=i/(N-1);angle=math.pi/3*(1-t)+.12*t;half=.17-.035*t**4
  for k in range(M):
   z=-.15+half*(2*k/(M-1)-1);direction=[sign*math.cos(angle),math.sin(angle),0];radius=ray_hit([0,1.16,z],direction)
   topv.append([(radius+.015)*direction[0],1.16+(radius+.015)*direction[1],z]);bottomv.append([(radius+.009)*direction[0],1.16+(radius+.009)*direction[1],z])
 shell('quarter_'+side,topv,bottomv,N,M,leather)
 # Jockey covers the side of the tree instead of leaving a bare scaffold.
 topv=[];bottomv=[];N=19;M=7
 for i in range(N):
  z=-.48+.535*i/(N-1)
  for k in range(M):
   t=k/(M-1);x=sign*(.16+.075*t);y=(1-t)*(seat_y(z)+.012)+t*(top(x,z)+.049)
   topv.append([x,y,z]);bottomv.append([x,y-.006,z])
 shell('jockey_'+side,topv,bottomv,N,M,leather)
# Beech bows sit below the leather-covered seat; no horn or military fork.
for name,z,rise in [('front_bow',.015,.015),('rear_bow',-.48,.025)]:
 points=[[x,top(x,z)+.052+rise*(1-(x/.19)**2),z]for x in [-.19,-.14,-.08,0,.08,.14,.19]]
 strap(name,points,.040,.025,width_axis=(0,0,1),ma=wood)
topv=[];bottomv=[];N=19;M=17
for i in range(N):
 z=-.48+.535*i/(N-1)
 for k in range(M):
  x=.16*(2*k/(M-1)-1);y=seat_y(z)+.012*(x/.16)**2;topv.append([x,y,z]);bottomv.append([x,y-.018,z])
shell('seat_jockey',topv,bottomv,N,M,leather)
# Conforming girth route based on maximum actual torso radius across its full width.
girth=[];N=96;center=[0,1.16,p['girth_z_m']]
for i in range(N+1):
 t=2*math.pi*i/N;direction=[math.cos(t),math.sin(t),0];r=max(ray_hit([0,1.16,center[2]+dz],direction) for dz in [-p['girth_width_m']/2,0,p['girth_width_m']/2]);r+=p['girth_surface_offset_m'];girth.append([center[k]+r*direction[k] for k in range(3)])
strap('riding_girth',girth,p['girth_width_m'],.004,width_axis=(0,0,1))
anchors={}
def anchor(name,v,parent=0,role=None):
 node('socket_riding_'+name,parent=parent,translation=v,extras={'role':role or name,'grade':'reconstructed_target_not_rider_fitted'});anchors[name]={'parent':'riding_head' if parent==head else 'root','translation_m':v,'rotation_xyzw':[0,0,0,1],'status':'reconstructed_not_rider_fitted'}
anchor('rider_seat',[0,1.61,-.20]);anchor('seat',[0,1.60,-.20])
for side,s in [('l',1),('r',-1)]:
 # Broad girth billet and paired stirrup leathers distinct from a driving pad.
 strap('billet_'+side,[[s*.22,1.49,-.15],[s*.29,1.35,-.15],[s*.30,1.16,-.15]],.024,.004,width_axis=(0,0,1))
 stirrupx=s*p['stirrup_lateral_m'];z=p['stirrup_z_m'];bottom=p['stirrup_bottom_y_m']
 strap('stirrup_leather_'+side,[[s*.17,1.60,z],[s*.30,1.38,z],[stirrupx,1.10,z],[stirrupx,bottom+.15,z]],.025,.004,width_axis=(0,0,1))
 # Original steel stirrup outline; shape/dimensions not asserted from unseen plate.
 tube('stirrup_'+side,[[stirrupx,bottom+.15,z],[stirrupx-.050,bottom+.14,z],[stirrupx-.066,bottom+.025,z],[stirrupx-.050,bottom,z],[stirrupx+.050,bottom,z],[stirrupx+.066,bottom+.025,z],[stirrupx+.050,bottom+.14,z],[stirrupx,bottom+.15,z]],.006,ma=nickel,N=10)
 strap('stirrup_tread_'+side,[[stirrupx-.05,bottom,z],[stirrupx+.05,bottom,z]],.035,.009,width_axis=(0,0,1),ma=nickel)
 anchor('stirrup_foot_'+side,[stirrupx,bottom+.015,z]);anchor('rein_hand_'+side,p['reconstructed_hand_targets_m'][0 if s==1 else 1])
 # Reconstructed single snaffle bridle; no check rein, traces, driving tugs or noseband.
 strap('cheekpiece_'+side,[[s*.096,.0175,-.060],[s*.123,.045,.065],[s*.096,.060,.15],[s*.088,-.11,.28],[s*.095,-.20,.39]],.018,.003,parent=head,width_axis=(0,1,0))
 ring('snaffle_ring_'+side,[s*.105,-.20,.39],.026,.026,head);anchor('bit_'+side,[s*.095,-.20,.39],head)
 # Static reins in separate root frame; future rider/flex/turn solve must move endpoints.
 hand=p['reconstructed_hand_targets_m'][0 if s==1 else 1]
 strap('riding_rein_'+side,[[s*.095,1.68,1.19],[s*.19,1.73,.92],[s*.24,1.76,.55],hand],.014,.003,width_axis=(0,1,0),extra={'grade':'reconstructed','binding':'restonly; dynamicbit/handendpoint solver absent'})
strap('crownpiece',arc_xy(0,.0175,-.060,.096,.139,0,math.pi,20),.018,.003,parent=head,width_axis=(0,0,1))
strap('browband',[[-.096,.060,.15],[-.060,.077,.18],[0,.084,.205],[.060,.077,.18],[.096,.060,.15]],.018,.003,parent=head,width_axis=(0,1,0))
tube('jointed_snaffle_mouthpiece',[[-.105,-.20,.39],[0,-.205,.40],[.105,-.20,.39]],.005,head,nickel)
# No unsupported curb, martingale or crupper added. Throatlatch pattern remains incomplete.
while len(bin)%4:bin.append(0)
d['buffers']=[{'byteLength':len(bin)}];j=json.dumps(d,separators=(',',':')).encode();j+=b' '*((-len(j))%4);raw=struct.pack('<III',0x46546c67,2,28+len(j)+len(bin))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(bin),0x004e4942)+bin
(P/(p['asset_id']+'.glb')).write_bytes(raw)
manifest={'asset_id':p['asset_id'],'license':'CC0-1.0 originalwork','grade':'original bounded1835 reconstruction study; NOTproductionaccepted','frame':{'units':'metres','up':'+Y','forward':'+Z','left':'+X'},'horse_input_sha256':hashlib.sha256(horse_raw).hexdigest(),'bytes':len(raw),'triangles':sum(v['triangles'] for v in stats.values()),'mesh_draws':len(stats),'materials':len(d['materials']),'texture_bytes':0,'anchors':anchors,'date_eligibility':p['date_eligibility'],'references':[{'external_id':'principlesofarto00lebe','title':'Lebeaud, Principles of modern horsemanship','year':1833,'locator':'pp25–30 construction text','rights':'ReasonedUSPD1833Philadelphia publication; nohostlicensegrant; noimagepixels','registry_status':'NOTregistered; source registry/primaryvisualgate requiredbeforeappacceptance'},{'external_id':'analysisofhorsem01adam','title':'JohnAdams,Analysisofhorsemanshipvol1','year':1805,'locator':'pp26–27single-snafflecomparatortext','rights':'ReasonedagebasedUSPD; noimagepixels','registry_status':'NOTregistered; no1812fullassemblyclaim'}],'bindings':[{'gear':'root','horse':'root'},{'gear':'riding_head','horse':'head'}],'missing':['sourceplate/objectviews','throatlatchandbuckleconstruction','historicalcut/dimensions','anatomicalbearing/pressure','trianglefitproof','dynamicreins','riderfit','browserandphotographicreview','authoredmaster','LODderivatives']}
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(P/'geometry-stats.json').write_text(json.dumps(stats,indent=2)+'\n');print(json.dumps({k:manifest[k] for k in ['bytes','triangles','mesh_draws','materials']}))
