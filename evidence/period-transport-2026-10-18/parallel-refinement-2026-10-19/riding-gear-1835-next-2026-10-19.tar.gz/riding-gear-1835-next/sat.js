// SPDX-License-Identifier: GPL-3.0-or-later
// Exact project SAT methodology; fixed1e-8m tolerance, no touch exemption.
export function makeSAT(T){const normal=t=>t.getNormal(new T.Vector3());
 function overlap(a,b){const av=[a.a,a.b,a.c],bv=[b.a,b.b,b.c],ae=[a.b.clone().sub(a.a),a.c.clone().sub(a.b),a.a.clone().sub(a.c)],be=[b.b.clone().sub(b.a),b.c.clone().sub(b.b),b.a.clone().sub(b.c)],an=normal(a),bn=normal(b),axes=[an,bn];for(const e of ae)for(const f of be)axes.push(e.clone().cross(f));for(const e of ae)axes.push(an.clone().cross(e));for(const e of be)axes.push(bn.clone().cross(e));for(const axis of axes){if(axis.lengthSq()<1e-20)continue;axis.normalize();const aa=av.map(p=>p.dot(axis)),bb=bv.map(p=>p.dot(axis));if(Math.max(...aa)<Math.min(...bb)-1e-8||Math.max(...bb)<Math.min(...aa)-1e-8)return false;}return true;}
return overlap;}
