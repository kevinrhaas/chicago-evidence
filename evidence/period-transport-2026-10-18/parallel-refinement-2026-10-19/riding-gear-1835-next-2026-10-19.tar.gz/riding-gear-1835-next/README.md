# T-2802 original1835 riding-gear parcel — UNAPPLIED / NOT ACCEPTED

Concrete generator+GLB+sidecars, outside checkout only. No application/ticket writes, Blender, network/source download or riding-gear browser use. Root's separate T2803 horse browser window was not used for this assembly. No human created or named person's ownership asserted.

## Evidence boundary and chosen date

Read actual T2802/T2799/T2800 requirements, retained horse/master dossiers, and the acquired riding-tack research report (RETAINED-RESEARCH.md). This pass read the report, not newly fetched originalOCR/pagebytes. The report documents prior actual readings of Lebeaud, Philadelphia1833, pp25–30:beech bows+sidebars,pairedlinenhair-filledpanels,seat/pommel/quarters,girth/stirrupstraps; Englishform described separately. Adams,London1805vol1pp26–27 supplies a single-snaffle comparator, not this precise cut. Publications are reasonedUSpublicdomain by age; no explicit hostlicense declaration or newly seen saddleplate. Source registry records for these books are currently absent; manifest uses explicit externalarchiveIDs with registry-needed status, never fabricated source_ids.

This is an ORIGINAL bounded1835English-form civilian straddle-saddle engineering study, not traced/manufacturer/owned replica or photographic master. No1870/1891/1902pattern is backdated into1835. The1902catalog's inch widths/tree construction are NOT used as1835attested dimensions;25mm strap width here is explicitly original reconstruction. Color,cut,tree/panel/stirrup/seat dimensions,hardware,mouthpiece and unseen construction all reconstructed. Primaryvisual and registry gates remain open; it is not eligible for production scene release.

## Delivered geometry and contract

- generate_riding.py,parameters.json: CC0original. Independent riding seat/jockey,woodenbows+sidebars,pairedclosedlinenpanel shapes with.11mcenterchannel,roundedquarter surfaces,girth,billets,pairedleathers/ironstirrups,single-snaffle mouthpiece/rings,crown/brow/cheek straps,static flatreins. No drafttraces,shafttugs,checkrein or breeching. Reuses only projectoriginalCC0 mesh/strap primitives and reconstructed head route, not1891catalog geometry.
- Metres,Yup,+Zforward,+Xleft; root binds horse root,riding_head binds horse head. Eight explicit seat/riderseat,pairedstirrupfoot/hand/bit anchors in manifest. They are targets, not tested rider poses. Stirrupopening planeXY permits+Zentry; no boot/riderfit claim.
- output/civilian_english_form_1835_reconstructed_01.glb:588720bytes,7892triangles,29meshdraws,5materialslots,zeroimages/texturememory. Materialcolor/roughness unmeasured. NoL0..3,authoredBlender master or qualifiedbake yet.
- Exact source horse retained in horse-input/:pairedneck assetSHA6e9b37b755ae3eda7b5cf2f492d1781b0e507664a99c88a2e6dee086f77c2296. Current app lateradds trot; this ridingproof is against retained idle/walkgeometry, not automatically accepted on newtrot.

## Meaningful actual checks and preserved failures

The generator ray-intersects actual continuous_body_neck triangles identified by sidecar semantic range. Panels follow actual top surface;girth radius bounds actual torso across fullwidth;quarters/jockey follow actual model. Test is against supplied original horse surface, not inventedbodyellipsoid/socketalone.

- geometry-validation.json finite positions/normals,no degenerate triangle(minarea4.6001e-6m²),all8anchornodes,distinctridingcomponents,noimages.
- Khronos0errors/0warnings; exact byte-identical rebuild from same parameters/input.
- fit-21walkposes.json actual CPU ThreeGLTFLoader+AnimationMixer,allassembly triangles except intended mouthpiece/rings versus actualwholehorse:21walkposes,0SATcrossings atunchanged1e-8tolerance. Zero crossing is NOT outside-volume/pressure certification; positive unsignedminimum was not computed. Torso support surfaces are rootbound; nonrigid pressure/girthstretch unresolved.
- Actual STATIC REIN FAILURE retained:bitanchor follows head butreinstart staysrootbound,maxendpointgap10.957018mm. No dynamicrein completion claim. No rider-hand match/tension solved.
- rejected-v1/:initial24quarter/bodycrossings and exactgeometry/generator retained. Originalrectangle-quarter chord cut body; conformingroute fixed geometric crossings.
- rejected-v2-scaffold/:subsequentSATpass but actually viewedCPU profile/3quarter showed openwoodscaffold/floatingflatseat and rectanglequarters. VisuallyFAIL despite collisionpass. Retained output/source/images. CurrentV3 adds lowerbows,curvedclosedseat/jockeycover,roundedquarters; actual CPU profile/3quarter opened with view_image,scaffold reduced but broadslab/leatherblock appearance and unfinishedstraps/hardware remain. STILL NOT visual/historical acceptance.
- preview_cpu.py makes original flatLambert painter diagnostics only; profile/front/threequarter images not canonicalglTF/PBR/renderacceptance. Projection may have coplanardepthsortartifacts. They intentionally reveal geometry limitations, not photographic proof.

## Reproduce

python generate_riding.py --parameters parameters.json --horse-input horse-input/equine_light_harness_skinned_prototype_01.glb --output-dir output
python check_geometry.py
node khronos.cjs
node --experimental-loader ./three-loader.mjs ./measure_fit.mjs
python preview_cpu.py

Outside measurement scripts reference already installedThree/validator paths; noinstall/networkrequired. GPLprojectSATmethod/geometrytestglue retains SPDX; geometry/generatorCC0. Retained sourcehorse also originalCC0. Publishedtextfacts referenced only; no bookpixels included orderived. ProposedLICENSE/LIBERTYtext in PROVENANCE-APPEND-PROPOSAL.md, not appapplied.

Nextgate:acquire+actuallyview cleared1833or earlier saddle/bridle/stirrup sourceimages,registerrealrefs,refine physicallycoherent tree/seat/leathercut+throatlatch/buckles,reconcilereinattachment/ringtargets,dynamicbit↔handreins,actualfulltriangleunsigneddistance+containmentscope,actualbare+riderfit for existingeligiblepeople,TROT/extrema body/gear tests,qualifiedmaster/LOD/materialwork,realbrowsercontrolledrender+mobilecost and photographiccomparison. Do not closeT2802 on this sourceparcel.
