#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Container facts only. No claimed browser draws, texture residency or frame cost."""
import argparse
import hashlib
import json
import pathlib
import struct

parser = argparse.ArgumentParser()
parser.add_argument('--app-root', type=pathlib.Path, required=True)
parser.add_argument('--output', type=pathlib.Path, required=True)
args = parser.parse_args()
rows = []
for name in [
    'wagon/wagon-w01.glb',
    'carriage/carriage-c01.glb',
    'horse/equine_light_harness_skinned_prototype_01.glb',
    'harness/light_breastcollar_harness_reconstructed_01.glb',
]:
    path = args.app_root / 'renderers/web/transport' / name
    raw = path.read_bytes()
    magic, version, length, json_length, kind = struct.unpack_from('<5I', raw)
    assert magic == 0x46546C67 and version == 2 and length == len(raw) and kind == 0x4E4F534A
    data = json.loads(raw[20:20 + json_length])
    primitives = [p for node in data.get('nodes', []) if 'mesh' in node
                  for p in data['meshes'][node['mesh']]['primitives']]
    assert all(p.get('mode', 4) == 4 for p in primitives)
    triangles = sum(data['accessors'][p['indices']]['count'] // 3
                    if 'indices' in p else data['accessors'][p['attributes']['POSITION']]['count'] // 3
                    for p in primitives)
    rows.append({
        'path': str(path.relative_to(args.app_root)),
        'sha256': hashlib.sha256(raw).hexdigest(), 'glb_bytes': len(raw),
        'triangle_instances_at_full_detail': triangles,
        'primitive_instances': len(primitives),
        'materials': len(data.get('materials', [])),
        'images': len(data.get('images', [])),
        'lod_chain_present': False,
        'browser_draws': None, 'texture_resident_bytes': None, 'p95_frame_ms': None,
        'accepted_periods': [], 'production_eligible': False,
    })
report = {
    'scope': 'Actual local GLB container/header facts; no rendering, GPU cost, anatomical or period acceptance inferred',
    'assets': rows,
    'separate_full_detail_hitch': {
        'glb_bytes': sum(r['glb_bytes'] for r in rows if not r['path'].endswith('carriage-c01.glb')),
        'triangle_instances': sum(r['triangle_instances_at_full_detail'] for r in rows if not r['path'].endswith('carriage-c01.glb')),
        'primitive_instances': sum(r['primitive_instances'] for r in rows if not r['path'].endswith('carriage-c01.glb')),
        'scope': 'Sum of separate W01/horse/harness containers, not merged LOD or measured actual coupled runtime',
    },
}
args.output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
