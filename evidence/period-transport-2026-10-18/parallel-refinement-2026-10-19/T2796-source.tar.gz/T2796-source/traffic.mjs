// SPDX-License-Identifier: GPL-3.0-or-later
// Original T-2796 engine-neutral mechanical study. No scene mounts or resource loads.
const finite = x => typeof x === 'number' && Number.isFinite(x);
const requireValue = (ok, message) => { if (!ok) throw Error(message); };
const distance = (a,b) => Math.hypot(a[0]-b[0],a[1]-b[1]);
function segmentDistance(point,a,b) {
 const d=[b[0]-a[0],b[1]-a[1]],length=d[0]**2+d[1]**2;
 const t=Math.max(0,Math.min(1,((point[0]-a[0])*d[0]+(point[1]-a[1])*d[1])/length));
 return distance(point,[a[0]+t*d[0],a[1]+t*d[1]]);
}
export function validateRoute(route) {
 requireValue(route?.format==='transport_route_study_v1'&&route.units==='m'&&route.axes==='ENU: e,n; y supplied by terrain','route contract');
 requireValue(route.production_enabled===false&&route.test_only===true,'study must not enable production traffic');
 requireValue(/^\d{4}$/.test(route.scene)&&route.grade==='reconstructed'&&route.ownership_claim===null,'explicit scene and reconstruction identity');
 requireValue(route.points?.length===2&&route.points.every(p=>p.length===2&&p.every(finite)),'first parcel supports straight route only; no invented turning clearance');
 requireValue(distance(...route.points)>0&&finite(route.corridor_half_width_m)&&route.corridor_half_width_m>0,'nonzero road corridor');
 requireValue(finite(route.actor_swept_radius_m)&&route.actor_swept_radius_m>0&&route.actor_swept_radius_m<route.corridor_half_width_m,'bounded complete hitch radius');
 requireValue(finite(route.speed_m_s)&&route.speed_m_s>0&&route.speed_m_s<=2&&finite(route.acceleration_m_s2)&&route.acceleration_m_s2>0&&route.acceleration_m_s2<=1,'bounded mechanical motion');
 requireValue(Array.isArray(route.static_collision_circles),'static proxies required, even when empty');
 for(const p of route.static_collision_circles){
  requireValue(p.id&&p.center?.length===2&&p.center.every(finite)&&finite(p.radius_m)&&p.radius_m>=0,'invalid static proxy');
  requireValue(segmentDistance(p.center,...route.points)>p.radius_m+route.actor_swept_radius_m,'route overlaps static proxy '+p.id);
 }
 requireValue(route.road_mask_status==='synthetic_fixture_only','actual road masks not qualified by this prototype');
 return route;
}
export function makeActor(route,{id,assetId,period,grade='reconstructed',wheelRadii=[.535,.685]}={}) {
 validateRoute(route);
 requireValue(typeof id==='string'&&id.length>0&&assetId&&grade==='reconstructed','stable explicit actor identity');
 requireValue(period?.scene===route.scene&&period.wardrobe_scene===route.scene&&period.vehicle_scene===route.scene,'horse/driver/vehicle period mismatch');
 requireValue(wheelRadii.length===2&&wheelRadii.every(r=>finite(r)&&r>0),'actual wheel radii required');
 const [a,b]=route.points,L=distance(a,b),v=route.speed_m_s,acc=route.acceleration_m_s2;
 const ramp=Math.min(v/acc,Math.sqrt(L/acc)),peak=acc*ramp,cruise=(L-acc*ramp*ramp)/peak,total=2*ramp+cruise;
 let elapsed=0,lastLod='far',lastPoseAt=-Infinity,lastPose=null;
 function sample(){
  const t=Math.min(elapsed,total);let s,speed;
  if(t<ramp){s=.5*acc*t*t;speed=acc*t;}
  else if(t<ramp+cruise){s=.5*acc*ramp*ramp+peak*(t-ramp);speed=peak;}
  else{const left=total-t;s=L-.5*acc*left*left;speed=acc*left;}
  return {id,asset_id:assetId,grade,scene:route.scene,owner:null,driver_person_id:null,
   distance_m:s,speed_m_s:speed,e:a[0]+(b[0]-a[0])*s/L,n:a[1]+(b[1]-a[1])*s/L,
   yaw_enu_rad:Math.atan2(b[0]-a[0],b[1]-a[1]),wheel_roll_rad:wheelRadii.map(r=>s/r),
   completed:t>=total,simulation_s:elapsed,selection_id:id};
 }
 return {sample,duration_s:total,update(dt,{paused=false,reducedMotion=false,cameraDistance=Infinity}={}){
  requireValue(finite(dt)&&dt>=0&&dt<=1,'bounded delta required; caller must substep long gaps');
  requireValue(cameraDistance===Infinity||finite(cameraDistance)&&cameraDistance>=0,'invalid camera distance');
  // Reduced motion keeps the actor stationary. Culling never resets identity/distance.
  if(!paused&&!reducedMotion)elapsed+=dt;
  const d=cameraDistance;
  if(d>260)lastLod='culled';else if(d<35)lastLod='near';else if(d<80&&lastLod!=='near')lastLod='mid';else if(d>100&&d<=240)lastLod='far';else if(lastLod==='culled'&&d<=240)lastLod=d<80?'mid':'far';else if(lastLod==='near'&&d>45)lastLod=d<=100?'mid':'far';
  const interval={near:1/30,mid:1/15,far:1/5,culled:Infinity}[lastLod];
  const current=sample(),poseUpdated=lastLod!=='culled'&&(lastPose===null||elapsed-lastPoseAt>=interval);
  if(poseUpdated){lastPoseAt=elapsed;lastPose=current;}
  return {...current,lod:lastLod,pose_updated:poseUpdated,pose_sample:lastPose,visible:lastLod!=='culled',
   note:'Continuous route transform; throttled pose sample only. Ground/hitch/gait/renderer adapter not qualified.'};
 }};
}
export function admitMeasuredPopulation({tier,baseline,actors,sharedNewTextureBytes=0,limits}){
 requireValue(['light','balanced','full'].includes(tier)&&Array.isArray(actors),'budget input');
 requireValue(limits&&['draws','triangles','textureBytes'].every(k=>finite(limits[k])&&limits[k]>=0),'explicit measured budget limits required');
 requireValue(['draws','triangles','textureBytes'].every(k=>finite(baseline?.[k])&&baseline[k]>=0),'actual same-view baseline required');
 requireValue(baseline.measured===true&&baseline.viewport&&baseline.stand&&baseline.tier===tier,'baseline provenance missing');
 requireValue(finite(sharedNewTextureBytes)&&sharedNewTextureBytes>=0,'invalid new shared texture bytes');
 const ids=new Set(),totals={draws:baseline.draws,triangles:baseline.triangles,textureBytes:baseline.textureBytes+sharedNewTextureBytes};
 for(const actor of actors){requireValue(!ids.has(actor.id),'duplicate actor identity');ids.add(actor.id);requireValue(actor.measurement?.actual===true&&actor.measurement.lod&&actor.measurement.includesShadowPass===true,'actual renderer per-actor+shadow measurement required');for(const k of ['draws','triangles']){requireValue(finite(actor.measurement[k])&&actor.measurement[k]>=0,'invalid actor cost');totals[k]+=actor.measurement[k];}}
 const effective={...limits};if(tier==='light'){effective.draws=Math.min(effective.draws,90);effective.triangles=Math.min(effective.triangles,1190000);}
 const violations=Object.keys(totals).filter(k=>totals[k]>effective[k]);
 return {admitted:violations.length===0,totals,limits:effective,violations,scope:'Arithmetic admission only; no p95/real scene clearance/historical qualification inferred'};
}
export function productionAdmission(){return{enabled:false,reasons:['T-2795 hitch acceptance open','T-1792 shared human population qualification open','period/photographic assets and driver acceptance open','actual road/static collision and all-stand published mobile costs unmeasured']};}
export function createMeasurementRecorder(context){
 requireValue(context?.viewport&&context.stand&&['light','balanced','full'].includes(context.tier)&&context.modelHashes,'measurement context required');
 const frames=[];
 return{record({frameMs,animationMs,draws,triangles,textureBytes,geometryBytes}){
  requireValue([frameMs,animationMs,draws,triangles,textureBytes,geometryBytes].every(x=>finite(x)&&x>=0)&&frameMs>0,'invalid measured frame');
  frames.push({frameMs,animationMs,draws,triangles,textureBytes,geometryBytes});if(frames.length>600)frames.shift();
 },receipt(){requireValue(frames.length>=120,'at least120 actual measured frames required');const percentile=k=>{const a=frames.map(f=>f[k]).sort((a,b)=>a-b);return a[Math.ceil(a.length*.95)-1];};return{context,frames:frames.length,p95_frame_ms:percentile('frameMs'),p95_animation_ms:percentile('animationMs'),maximum:Object.fromEntries(['draws','triangles','textureBytes','geometryBytes'].map(k=>[k,Math.max(...frames.map(f=>f[k]))])),scope:'Caller-supplied measurements; not an automatic qualification or future actor reservation'};}};
}
