# Local forechest sculpt / preexisting gear-fit finding — UNAPPLIED

No app writes/Blender/browser. Original reconstructed localforechest geometry, not measured anatomy. Baselinehorse89b048... retained via source references; actualoriginalgear was loaded read-only from app. Exactbodychangedindices/displacements, changedbody/newbridge activeindices are in outputmanifest. Allheadneckj7+, lower/soles/rig/IBMs/clips/sockets protected.

V1 source changes42bodyvertices in lateral torso rows3..5, movinglowopening up/forward; true shared-index interfaces to60newvolume vertices per forelimb.14224tris/6draws; GLBee56054a1b303e90fedc334dfc8700ef6d733f5cd40b5699a9715ebd78f2ff98;Khronos0/0, source/topology/decodednormals proof passes;43sampledwholechangedbody/bridge-vsbody/self0SAT. Actual100soles×303poses baselinepositiondelta0. BUT42pose allunchangedgear fitFAIL4116properinterior crossingpairs:collar2940/support_l714/support_r462.

V1b retains row5+ originalpositions and uses smallerlow-side aperture.43sampledself/bodyFAIL1585rawSATpairs;42pose collar0SAT butmin0.524mm belowretainedguard. WholeallgearFAIL168properinterior crossingpairs, support_l. No geometry accepted/rendered.

CRITICAL SAME-METHOD BASELINE CONTROLS: exactoriginal bodytriangle counterpart sets, no guessedproxy markers. V1mask108baselinebodytriangles vsall36originalharness meshes over42walk/trot poses1386properinterior crossingpairs:collar336/support_l630/support_r420. V1bmask84baselinebodytriangles168propercrossings:support_l. RawSATcounts preserved; strictclassification checks actual edgeendpoints opposite sides beyond1e-8m, intersectionparameter interior and facebarycentrics>1e-8. Allrawpairs were confirmedstrict, noneonlytouch/coplanar. Independent5analyticfixtures+reversedorder pass; classification source separated into proper_crossing.js. Actualintersectioncoordinates/planedistances/barycentrics retained. This is an explicit preexistingT2801finding; earlier vertexdistance/head-only proofs didnotvalidate these torso/support triangles. No containment/pressure/load/continuous-time acceptance.

Pairidentity comparison (notdepthseverity):V1matched1134baselinepairidentities,new2982,no-longer252;V1bmatched168,new0,no-longer0. Newbridge has no baselinecounterpart. Do notattribute allV1overlap solelysculpt, and do notexcusefailuresbecausebaselinealsofails.

Allnewgeometry remainsunapplied. Rootnowallows pairedanatomicalbody+harness refinement aftercapturingbaselineevidence. V1self/topology passes so could be a bounded nextpairedcandidate, but actualvisualqualitystillunseen and allgarmentfit mustpass beforebrowser. Currentfrozenapp untouched.

CC0 geometrysource;GPL tests/classifier asheaders. ExistingThree/Khronos notbundled. PriorV1failedsculptarchive503a5d209371e13e0fb54629d1d7fa6280a51578d26220b795b31c4e87068638 retained separately.
