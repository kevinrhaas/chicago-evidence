# SPDX-License-Identifier: CC0-1.0
"""Original bounded surface surgery; no copied anatomical mesh or source tracing."""
import numpy as np

def connect_shoulders(g,ranges,root_joint,upper_joints):
    faces=np.asarray(g['i'],dtype=int).reshape(-1,3).tolist()
    body=next(r for r in ranges if r['original_node']=='continuous_body_neck')
    assert body['vertex_start']==0
    sculpted={}
    # Original local forechest reconstruction, not measured anatomical dimensions.
    # Lift the low underside opening toward the existing foreupper pivot and move
    # it forward; feather within j3..5 and lateral side cells only, j6+ fixed.
    angular={19:.20,20:.90,21:1.,22:1.,23:1.,0:.75,1:.15}
    for side in [1,-1]:
        for row,row_weight,forward in [(3,.20,.035),(4,.90,.160)]:
            for angle_index,angular_weight in angular.items():
                k=angle_index if side==1 else(12-angle_index)%24
                index=row*24+k;theta=2*np.pi*angle_index/24
                shift=np.array([0.,.280*row_weight*angular_weight*max(0.,-np.sin(theta)),forward*angular_weight])
                if np.linalg.norm(shift)<1e-12:continue
                assert index not in sculpted
                sculpted[index]=shift.tolist();g['p'][index]=(np.array(g['p'][index])+shift).tolist()
    records=[];remove=set();add=[];touched=set(sculpted)
    # Adjacent vertices receive recomputed area normals when an incident face moves.
    for face in faces:
        if any(index in sculpted for index in face):touched.update(face)

    def directed_boundary(selected):
        edges={}
        for fi in selected:
            f=faces[fi]
            for a,b in zip(f,f[1:]+f[:1]):edges.setdefault(tuple(sorted((a,b))),[]).append((a,b))
        edge=[v[0] for v in edges.values()if len(v)==1]
        nxt={a:b for a,b in edge};assert len(nxt)==len(edge)
        first=min(nxt);loop=[first]
        while nxt[loop[-1]]!=first:
            loop.append(nxt[loop[-1]]);assert len(loop)<=len(edge)
        assert len(loop)==len(edge)
        return loop
    def stitch(a,b):
        i=j=0;result=[]
        while i<len(a)or j<len(b):
            na=(i+1)/len(a) if i<len(a)else float('inf');nb=(j+1)/len(b) if j<len(b)else float('inf')
            if abs(na-nb)<1e-12:
                result.extend([(a[i%len(a)],a[(i+1)%len(a)],b[(j+1)%len(b)]),(a[i%len(a)],b[(j+1)%len(b)],b[j%len(b)])]);i+=1;j+=1
            elif na<nb:result.append((a[i%len(a)],a[(i+1)%len(a)],b[j%len(b)]));i+=1
            else:result.append((a[i%len(a)],b[(j+1)%len(b)],b[j%len(b)]));j+=1
        return result
    def sample(loop,u):
        n=len(loop);f=(u%1)*n;i=int(f);q=f-i
        return (1-q)*np.array(g['p'][loop[i]])+q*np.array(g['p'][loop[(i+1)%n]])
    for side,label in [(1,'fore_l'),(-1,'fore_r')]:
        # One longitudinal torso band, four angular cells, below side midline.
        ks={22,23,0}if side==1 else{12,13,14}
        patch={j*24+k for j in [4,5]for k in ks}
        cut=[i for i,f in enumerate(faces)if set(f)<=patch]
        assert len(cut)==4
        boundary=directed_boundary(cut);assert len(boundary)==6
        remove.update(cut);touched.update(boundary)
        upper=next(r for r in ranges if r['original_node']==label+'_upper_mesh');start=upper['vertex_start'];assert upper['vertex_count']==98
        # Retain original ring2→ring3 and distal cap; remove every proximal cap/band.
        retired={start+i for i in range(48)}|{start+96}
        upper_cut=[i for i,f in enumerate(faces)if any(v in retired for v in f)]
        assert len(upper_cut)==120
        remove.update(upper_cut)
        distal=list(range(start+48,start+72))
        # Cyclic alignment only (no reversal): preserves directed lower tube edges.
        bc=np.mean([g['p'][i]for i in boundary],axis=0);dc=np.mean([g['p'][i]for i in distal],axis=0)
        def alignment(offset):
            loop=distal[offset:]+distal[:offset]
            return sum(float(np.sum(((sample(boundary,k/20)-bc)-(sample(loop,k/20)-dc))**2))for k in range(20))
        offset=min(range(24),key=alignment);distal=distal[offset:]+distal[:offset]
        previous=boundary;created=[];added_start=len(add)
        # Actual rest upper frame recovered from its original circular distal ring.
        # No inferred anatomical measurement; depths/radii are reconstruction choices.
        original_distal=list(range(start+48,start+72))
        center=np.mean([g['p'][i]for i in original_distal],axis=0)
        axis_x=(np.array(g['p'][original_distal[0]])-center)/.047
        axis_z=(np.array(g['p'][original_distal[6]])-center)/.047
        axis_down=np.cross(axis_x,axis_z);axis_down/=np.linalg.norm(axis_down)
        origin=np.array(g['p'][start+96])
        for depth,rx,rz,weight in [(.23,.095,.115,.30),(.37,.073,.085,.68),(.47,.056,.062,.93)]:
            ring=[]
            for k in range(20):
                angle=2*np.pi*(k/20+offset/24)
                position=origin+axis_down*depth+axis_x*(rx*np.cos(angle))+axis_z*(rz*np.sin(angle))
                index=len(g['p']);g['p'].append(position.tolist());g['n'].append([0.,0.,0.]);g['j'].append([root_joint,upper_joints[label],0,0]);g['w'].append([1-weight,weight,0,0]);ring.append(index);created.append(index)
            add.extend(stitch(previous,ring));previous=ring
        add.extend(stitch(previous,distal));touched.update(distal);touched.update(created)
        records.append({'label':label,'body_boundary':boundary,'distal_boundary':distal,'created_vertices':created,'removed_original_faces':sorted(set(cut+upper_cut)),'retired_unreferenced_vertices':sorted(retired),'body_patch_vertex_indices':sorted(patch),'added_triangle_offset_range':[added_start,len(add)],'offset':offset,'upper_joint_index':upper_joints[label],'frame_origin_m':origin.tolist(),'frame_x':axis_x.tolist(),'frame_z':axis_z.tolist(),'frame_down':axis_down.tolist()})
    retained=[f for i,f in enumerate(faces)if i not in remove];first=len(retained);all_faces=retained+add;g['i']=[v for f in all_faces for v in f]
    for record in records:
        record['new_triangle_range']=[first+i for i in record.pop('added_triangle_offset_range')]
        upper=next(r for r in ranges if r['original_node']==record['label']+'_upper_mesh')
        record['active_triangle_indices']=[i for i,face in enumerate(all_faces)if record['new_triangle_range'][0]<=i<record['new_triangle_range'][1] or all(upper['vertex_start']<=v<upper['vertex_start']+upper['vertex_count']for v in face)]
        record['active_surface_vertex_indices']=sorted({v for i in record['active_triangle_indices']for v in all_faces[i]})
    # Normals shared by actual indices, from every adjacent oriented triangle.
    p=np.asarray(g['p']);f=np.asarray(all_faces);weighted=np.zeros_like(p);fn=np.cross(p[f[:,1]]-p[f[:,0]],p[f[:,2]]-p[f[:,0]])
    for k in range(3):np.add.at(weighted,f[:,k],fn)
    for index in touched:
        n=weighted[index];length=float(np.linalg.norm(n));assert length>1e-12;g['n'][index]=(n/length).tolist()
    changed_body_faces=[i for i,face in enumerate(all_faces)if i<first and any(index in sculpted for index in face)]
    return {'sculpted_body_vertex_indices':sorted(sculpted),'sculpt_displacements_m':{str(k):v for k,v in sculpted.items()},'active_changed_body_triangle_indices':changed_body_faces,'active_whole_changed_triangle_indices':sorted(set(changed_body_faces+list(range(first,len(all_faces))))),'status':'original shared-index shoulder reconstruction trial, not anatomical acceptance','records':records,'new_triangle_range':[first,len(all_faces)],'changed_normal_vertex_indices':sorted(touched),'removed_face_count':len(remove),'added_face_count':len(add),'joint_policy':'body boundary original root weights; three actualupperframe volume rings upper fractions .12/.55/.88; distal original weights','topology_policy':'actual shared indices, caps/proximal bands absent from rendered triangle list; unused source vertices retained for audit'}
