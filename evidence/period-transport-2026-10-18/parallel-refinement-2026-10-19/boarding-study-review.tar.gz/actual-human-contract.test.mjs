// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';import fs from 'node:fs';
import {HumanActor} from '/workspace/chicago/chicago/4d/renderers/web/js/humans.js';
import {validatePortablePassenger} from './boarding-controller.mjs';
const reference=JSON.parse(fs.readFileSync('/workspace/chicago/chicago/4d/data/residents/reconstructed_trades/hh_rc_bardwell_otis.json','utf8'));
const actor=new HumanActor({instance:{id:'boarding-contract-only',person_id:'rc_bardwell_otis',placement:{local_e:0,local_n:0,heading_deg:0},appearance:{asset_id:'bardwell_otis_1835'},behaviour:{state:'standing'}},person:reference,assets:{release(){}}});
// Synthetic clip map tests the ACTUAL getter shape, not a claimed accepted seating asset.
actor.body={clips:new Map([['sit_passenger_test',{name:'sit_passenger_test'}]])};
assert.deepEqual(actor.clips,['sit_passenger_test']);const result=validatePortablePassenger(actor,{scene:'1835',fit:{personId:actor.personId,scene:'1835',accepted:true,role:'passenger',clip:'sit_passenger_test'}});assert.equal(result.id,'rc_bardwell_otis');assert.equal(actor.state,'standing');assert.equal(actor.instance.appearance.asset_id,'bardwell_otis_1835');
assert.throws(()=>validatePortablePassenger(actor,{scene:'1904',fit:{personId:actor.personId,scene:'1835',accepted:true,role:'passenger',clip:'sit_passenger_test'}}),/fit/);
actor.body=null;actor.dispose();assert.equal(actor.disposed,true);console.log('PASS actual HumanActor constructor/public clips Map getter/person binding/disposal; synthetic testclip is not seating acceptance');
