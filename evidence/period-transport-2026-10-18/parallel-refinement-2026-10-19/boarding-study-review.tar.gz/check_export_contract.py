# SPDX-License-Identifier: GPL-3.0-or-later
"""CPU actualGLB/socket/camera envelope proof only, not human boarding fit."""
from pathlib import Path
import json,struct,hashlib,math,subprocess
R=Path('/workspace/chicago/chicago/4d');O=Path(__file__).parent;p=R/'renderers/web/transport/carriage/carriage-c01.glb';raw=p.read_bytes();length=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+length]);binary=raw[28+length:];profile=json.loads((O/'boarding-study.json').read_text());nodes={n['name']:n for n in g['nodes']};parent={c:i for i,n in enumerate(g['nodes']) for c in n.get('children',[])}
assert g['extras']['asset_id']==profile['vehicle_asset_id'];assert g['extras']['units']=='m' and g['extras']['up_axis']=='+Y' and g['extras']['forward_axis']=='+Z';assert '1904' in g['extras']['scene_eligibility'];assert profile['scene']=='1904'
world=[]
for i,node in enumerate(g['nodes']):
 if 'mesh' not in node:continue
 for prim in g['meshes'][node['mesh']]['primitives']:
  a=g['accessors'][prim['attributes']['POSITION']];v=g['bufferViews'][a['bufferView']];off=v.get('byteOffset',0)+a.get('byteOffset',0)
  for k in range(a['count']):
   point=list(struct.unpack_from('<3f',binary,off+12*k));index=i
   while True:
    n=g['nodes'][index];q=n.get('rotation',[0,0,0,1]);x,y,z,w=q;vx,vy,vz=point;tx=2*(y*vz-z*vy);ty=2*(z*vx-x*vz);tz=2*(x*vy-y*vx);point=[vx+w*tx+y*tz-z*ty,vy+w*ty+z*tx-x*tz,vz+w*tz+x*ty-y*tx];point=[a+b for a,b in zip(point,n.get('translation',[0,0,0]))]
    if index not in parent:break
    index=parent[index]
   world.append(point)
lo=[min(p[k] for p in world) for k in range(3)];hi=[max(p[k] for p in world) for k in range(3)];seats=[]
for seat in profile['seats']:
 for name in [seat['socket'],seat['boardingSocket']]:assert name in nodes
 datum=nodes[seat['socket']]['translation'];boarding=nodes[seat['boardingSocket']]['translation'];eye=datum[1]+.60;assert eye-hi[1]>.08
 x=boarding[0]+(.55 if boarding[0]>0 else -.55);clearance=abs(x)-.18-max(abs(lo[0]),abs(hi[0]));assert clearance>0
 seats.append({'id':seat['id'],'seat_socket_m':datum,'boarding_socket_m':boarding,'seated_camera_y_m':eye,'camera_vertical_clearance_above_whole_export_m':eye-hi[1],'conservative_landing_lateral_clearance_m':clearance})
receipt={'status':'Actual exported socket/frame/camera/landing bounds in isolated rest plane; not human body, collision-safe step traversal, occupied scene or route acceptance','source_head':subprocess.check_output(['git','-C','/workspace/chicago','rev-parse','HEAD'],text=True).strip(),'glb_sha256':hashlib.sha256(raw).hexdigest(),'body_bounds':{'min':lo,'max':hi},'seats':seats,'camera_sphere_trial_radius_m':.08,'walking_eye_height_m':1.65,'walking_camera_vertical_gap_m':1.65-hi[1],'profiles_all_production_gates_false':all(not x for x in profile['production_gates'].values()),'source_hashes':{str(f.relative_to(R)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [R/'renderers/web/js/humans.js',R/'docs/HUMAN-ASSET-CONTRACT.md',R/'renderers/web/transport/carriage/fixture.js']}}
(O/'export-contract-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt['seats'],indent=2))
