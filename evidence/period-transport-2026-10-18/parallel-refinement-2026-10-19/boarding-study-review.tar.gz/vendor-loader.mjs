// Test-only resolver: use existing application vendor, no copy/install/new dependency.
import {pathToFileURL} from 'node:url';
export async function resolve(specifier,context,next){const base='/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/';if(specifier==='three')return {url:pathToFileURL(base+'three.module.js').href,shortCircuit:true};if(specifier.startsWith('three/addons/'))return {url:pathToFileURL(base+'addons/'+specifier.slice(13)).href,shortCircuit:true};return next(specifier,context);}
