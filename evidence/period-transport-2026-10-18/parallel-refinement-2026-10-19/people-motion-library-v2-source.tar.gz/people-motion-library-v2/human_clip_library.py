# SPDX-License-Identifier: GPL-3.0-or-later
"""Original source-joint engineering vocabulary; no measured/historical gesture claim."""
import math
from human_work_motion import I,add,sub,mul,mv,align,elbow
DECLARATIONS={
 'idle_alternate':{'duration_s':3.,'loop':True,'tags':['idle','alternate']},
 'talk':{'duration_s':2.,'loop':True,'tags':['talk','jaw_hook','no_audio']},
 'gesture_greet':{'duration_s':2.,'loop':False,'tags':['gesture','greeting','reconstructed']},
 'gesture_point':{'duration_s':2.,'loop':False,'tags':['gesture','point','reconstructed']},
 'work_carry_hold':{'duration_s':2.,'loop':True,'tags':['work','carry','hold','no_prop']},
 'work_inspect':{'duration_s':2.,'loop':True,'tags':['work','unloaded_reach']}}

def sample(body,name,phase):
 if name not in DECLARATIONS:raise ValueError('undeclared clip')
 if not math.isfinite(phase)or not 0<=phase<=1:raise ValueError('phase must be finite within0..1')
 b={x['name']:x for x in body['skeleton']};overrides={};t={};receipts=[]
 def update():
  t.clear()
  for n,row in b.items():
   if n in overrides:t[n]=overrides[n];continue
   parent=row['parent']
   if parent is None:t[n]=(I,list(row['head_m']))
   else:
    r,h=t[parent];t[n]=(r,add(h,mv(r,sub(row['head_m'],b[parent]['head_m']))))
 update();pulse=.5-.5*math.cos(2*math.pi*phase)
 for side,sign in [('l',1),('r',-1)]:
  a,k='upperarm_'+side,'lowerarm_'+side;origin=t[a][1]
  l1=math.dist(b[a]['head_m'],b[a]['tail_m']);l2=math.dist(b[k]['head_m'],b[k]['tail_m']);r=l1+l2
  neutral=[-sign*.08,-.91*r,.12*r]
  if name=='idle_alternate':delta=[-sign*.08,-.90*r,.12*r+.01*pulse]
  elif name=='talk':delta=[-sign*.10,-.65*r,(.40+.025*pulse)*r]
  elif name=='work_carry_hold':delta=[-sign*.10,-.44*r,.64*r]
  elif name=='work_inspect':delta=[-sign*.10,-.48*r,.58*r+.04*pulse]
  elif name=='gesture_greet':
   target=[sign*.10,.30*r,.45*r] if side=='r'else neutral
   delta=add(mul(neutral,1-pulse),mul(target,pulse))
  else:
   target=[-sign*.05,-.05*r,.90*r]if side=='r'else neutral
   delta=add(mul(neutral,1-pulse),mul(target,pulse))
  target=add(origin,delta);joint=elbow(origin,target,l1,l2,[sign,-.5,-.5])
  overrides[a]=(align(sub(b[a]['tail_m'],b[a]['head_m']),sub(joint,origin)),origin)
  overrides[k]=(align(sub(b[k]['tail_m'],b[k]['head_m']),sub(target,joint)),joint)
  update();actual=add(t[k][1],mv(t[k][0],sub(b[k]['tail_m'],b[k]['head_m'])))
  receipts.append({'side':side,'endpoint_error_m':math.dist(actual,target),'target_m':target,'segment_lengths_m':[l1,l2]})
 # Facial signals are OPTIONAL contract hooks, not authored phonemes or jawbone
 # rotation. They can feed HumanActor.setExpression where a LOD has the morphs.
 blink=math.sin(math.pi*max(0,1-abs(phase-.7)/.05))**2 if abs(phase-.7)<.05 else 0.
 jaw=.18*math.sin(4*math.pi*phase)**2 if name=='talk'else 0.
 return {'bone_global_head_rotation':{n:{'rotation_3x3':r,'head_m':h}for n,(r,h)in t.items()},'arm_ik':receipts,'face_hooks':{'eyeBlinkLeft':blink,'eyeBlinkRight':blink,'jawOpen':jaw}}
