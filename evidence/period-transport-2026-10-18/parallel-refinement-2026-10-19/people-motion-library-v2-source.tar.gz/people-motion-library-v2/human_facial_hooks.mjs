// SPDX-License-Identifier: GPL-3.0-or-later
// Optional external hook through existing HumanActor.setExpression; no audio dependency.
export function sampleFacialHooks(profile, time, loop=true) {
  if (!Number.isFinite(time) || !(profile.duration_s>0) || !profile.samples?.length) throw Error('finite declared facial sample required');
  const t=loop ? ((time%profile.duration_s)+profile.duration_s)%profile.duration_s : Math.max(0,Math.min(time,profile.duration_s));
  let i=0;while(i+1<profile.samples.length && profile.samples[i+1].time_s<=t)i++;
  const a=profile.samples[i],b=profile.samples[Math.min(i+1,profile.samples.length-1)];
  const q=b.time_s>a.time_s?(t-a.time_s)/(b.time_s-a.time_s):0;
  return Object.fromEntries(Object.keys(a.weights).map(k=>[k,a.weights[k]*(1-q)+b.weights[k]*q]));
}
export function applyFacialHooks(actor, profile, time, loop=true) {
  // Existing actor gracefully ignores unavailable morphs at LOD2/3. Caller must
  // clear these expression overrides on clip exit; they are not audio lip sync.
  return actor.setExpression(sampleFacialHooks(profile,time,loop));
}
