# SPDX-License-Identifier: GPL-3.0-or-later
import unittest,json,math,re
from pathlib import Path
from human_clip_library import DECLARATIONS,sample
R=Path('/workspace/chicago/chicago/4d')
class Library(unittest.TestCase):
 def test_actual_named_source_geometry(self):
  recipe=json.loads((R/'data/humans/recipes/worker_1835.json').read_text());contract=json.loads((R/'data/humans/contract.json').read_text());rows=[]
  for v in recipe['proof_variants']:
   body=json.loads((R/v['body_input']).read_text());rest={b['name']:b['head_m']for b in body['skeleton']}
   for name,decl in DECLARATIONS.items():
    self.assertRegex(name,contract['clips']['name_pattern']);self.assertIn(name.split('_')[0],contract['clips']['verbs']);n=round(decl['duration_s']*30);err=0;drift=0;peak=0
    for i in range(n+1):
     p=sample(body,name,i/n)
     for side in ['l','r']:
      for joint in ['thigh','calf','foot','ball']:
       drift=max(drift,math.dist(rest[joint+'_'+side],p['bone_global_head_rotation'][joint+'_'+side]['head_m']))
     self.assertEqual(rest['pelvis'],p['bone_global_head_rotation']['pelvis']['head_m'])
     err=max(err,max(x['endpoint_error_m']for x in p['arm_ik']))
     for k,val in p['face_hooks'].items():self.assertIn(k,contract['morphs']['required']);self.assertTrue(0<=val<=1)
     peak=max(peak,p['face_hooks']['jawOpen'])
    self.assertLess(err,1e-12);self.assertLess(drift,1e-14)
    a,z=sample(body,name,0),sample(body,name,1)
    for k in rest:
     self.assertLess(math.dist(a['bone_global_head_rotation'][k]['head_m'],z['bone_global_head_rotation'][k]['head_m']),1e-12)
     for ra,rz in zip(a['bone_global_head_rotation'][k]['rotation_3x3'],z['bone_global_head_rotation'][k]['rotation_3x3']):self.assertLess(math.dist(ra,rz),1e-12)
    if name=='talk':self.assertGreater(peak,.15)
    rows.append({'asset':v['id'],'person':v['person_reference_id'],'clip':name,'frames':n+1,'maximum_ik_endpoint_error_m':err,'maximum_leg_head_drift_m':drift,'jaw_hook_peak':peak,'loop':decl['loop']})
  Path('clip-math-receipt.json').write_text(json.dumps({'scope':'actual prepared source joints; not skin/clothing/finger/held-prop/Blender/GLB or historical gesture acceptance','rows':rows},indent=2)+'\n')
 def test_bad_inputs(self):
  for name,q in [('undefined',0),('talk',float('nan')),('talk',1.01)]:
   with self.assertRaises(ValueError):sample({},name,q)
if __name__=='__main__':unittest.main()
