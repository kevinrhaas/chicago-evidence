import assert from 'node:assert/strict';
import {sampleFacialHooks,applyFacialHooks} from './human_facial_hooks.mjs';
const p={duration_s:2,samples:[{time_s:0,weights:{jawOpen:0}},{time_s:1,weights:{jawOpen:.2}},{time_s:2,weights:{jawOpen:0}}]};
assert.equal(sampleFacialHooks(p,.5).jawOpen,.1);
assert.equal(sampleFacialHooks(p,2.5).jawOpen,.1);
assert.equal(sampleFacialHooks(p,2,false).jawOpen,0);
assert.throws(()=>sampleFacialHooks(p,NaN),/finite/);
let stored;applyFacialHooks({setExpression(w){stored=w;return []}},p,1);assert.equal(stored.jawOpen,.2);
console.log('PASS: facial hook interpolation, loop wrap, one-shot clamp, invalid time, existing expression API; no GLB morph playback proof');
