# SPDX-License-Identifier: GPL-3.0-or-later
"""Original unloaded inspection/reach study in source metre/Y-up/+Z frame.

No tool, cargo grip, occupational gesture, likeness or body contact is asserted.
"""
import math

def add(a,b):return [x+y for x,y in zip(a,b)]
def sub(a,b):return [x-y for x,y in zip(a,b)]
def mul(a,s):return [x*s for x in a]
def dot(a,b):return math.fsum(x*y for x,y in zip(a,b))
def unit(a):
 n=math.sqrt(dot(a,a))
 if n<1e-10:raise ValueError('degenerate IK/pole vector')
 return mul(a,1/n)
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
I=[[1.,0.,0.],[0.,1.,0.],[0.,0.,1.]]
def mv(m,v):return [dot(r,v)for r in m]
def align(a,b):
 a,b=unit(a),unit(b);v=cross(a,b);c=dot(a,b)
 if c<-.999999:raise ValueError('antiparallel IK requires explicit roll')
 k=[[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]]
 return [[I[i][j]+k[i][j]+sum(k[i][q]*k[q][j]for q in range(3))/(1+c)for j in range(3)]for i in range(3)]
def elbow(a,t,l1,l2,pole):
 d=math.dist(a,t)
 if not abs(l1-l2)+1e-8<d<l1+l2-1e-8:raise ValueError('unreachable inspection target')
 u=unit(sub(t,a));q=unit(sub(pole,mul(u,dot(pole,u))));x=(l1*l1-l2*l2+d*d)/(2*d)
 return add(a,add(mul(u,x),mul(q,math.sqrt(l1*l1-x*x))))
def work_pose(body,phase):
 if not math.isfinite(phase):raise ValueError('finite phase required')
 bones={b['name']:b for b in body['skeleton']};overrides={};transforms={};receipts=[]
 def update():
  transforms.clear()
  for n,b in bones.items():
   if n in overrides:transforms[n]=overrides[n];continue
   parent=b['parent']
   if parent is None:transforms[n]=(I,list(b['head_m']))
   else:
    r,h=transforms[parent];transforms[n]=(r,add(h,mv(r,sub(b['head_m'],bones[parent]['head_m']))))
 update()
 # Smooth cyclic 40mm unloaded forward reach; no angular guess determines endpoints.
 travel=.04*(.5-.5*math.cos(2*math.pi*(phase%1)))
 for side,sign in [('l',1),('r',-1)]:
  a,b='upperarm_'+side,'lowerarm_'+side;origin=transforms[a][1]
  l1=math.dist(bones[a]['head_m'],bones[a]['tail_m']);l2=math.dist(bones[b]['head_m'],bones[b]['tail_m']);reach=l1+l2
  target=add(origin,[-sign*.10,-.48*reach,.58*reach+travel])
  joint=elbow(origin,target,l1,l2,[sign,-.5,-.5])
  overrides[a]=(align(sub(bones[a]['tail_m'],bones[a]['head_m']),sub(joint,origin)),origin)
  overrides[b]=(align(sub(bones[b]['tail_m'],bones[b]['head_m']),sub(target,joint)),joint)
  update()
  actual=add(transforms[b][1],mv(transforms[b][0],sub(bones[b]['tail_m'],bones[b]['head_m'])))
  receipts.append({'side':side,'target_m':target,'endpoint_error_m':math.dist(actual,target),'segment_lengths_m':[l1,l2]})
 return {'bone_global_head_rotation':{n:{'rotation_3x3':r,'head_m':h}for n,(r,h)in transforms.items()},'arm_ik':receipts,'motion_basis':'Unloaded reconstructed reach/inspection study; no held object, actual work, palm grip or anatomical acceptance'}
