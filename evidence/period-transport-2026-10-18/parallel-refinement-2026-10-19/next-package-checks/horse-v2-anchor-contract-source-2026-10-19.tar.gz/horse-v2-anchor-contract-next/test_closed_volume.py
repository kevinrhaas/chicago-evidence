# SPDX-License-Identifier: GPL-3.0-or-later
"""PROPOSED analytic tests; syntax checked only, NOT executed."""
import unittest
import numpy as np
from closed_volume import audited_topology,classify

def extruded_polygon(xy,cap_triangles):
 vertices=np.array([[x,y,z]for z in [0,1]for x,y in xy],float);n=len(xy);f=[]
 for a,b,c in cap_triangles:f.extend([(a,c,b),(a+n,b+n,c+n)])
 for a in range(n):
  b=(a+1)%n;f.extend([(a,b,b+n),(a,b+n,a+n)])
 return vertices[f]
BOX=extruded_polygon([(0,0),(1,0),(1,1),(0,1)],[(0,1,2),(0,2,3)])
L=extruded_polygon([(0,0),(2,0),(2,1),(1,1),(1,2),(0,2)],[(0,1,3),(1,2,3),(0,3,5),(3,4,5)])
class Analytic(unittest.TestCase):
 def check(self,t,p,kind):self.assertEqual(classify(p,t,self_intersections_rejected=True)['classification'],kind)
 def test_box(self):
  for t in [BOX,BOX[:,::-1]]:
   for p,kind in [([.5,.5,.5],'interior'),([1.5,.5,.5],'exterior'),([0,.5,.5],'boundary'),([0,0,.5],'boundary'),([0,0,0],'boundary')]:self.check(t,p,kind)
 def test_rigid_transform(self):
  q=np.array([[0,-1,0],[1,0,0],[0,0,1]],float);d=np.array([3,-7,4]);self.check(BOX@q.T+d,np.array([.5,.5,.5])@q.T+d,'interior')
 def test_concave(self):
  self.check(L,[.5,1.5,.5],'interior');self.check(L,[1.5,1.5,.5],'exterior');self.check(L,[1,1,.5],'boundary')
 def test_open_and_degenerate_rejected(self):
  with self.assertRaises(ValueError):audited_topology(BOX[:-1])
  with self.assertRaises(ValueError):audited_topology(np.concatenate([BOX,BOX[:1]]))
  bad=BOX.copy();bad[0,1]=bad[0,0]
  with self.assertRaises(ValueError):audited_topology(bad)
 def test_missing_self_audit(self):
  with self.assertRaises(ValueError):classify([.5,.5,.5],BOX)
if __name__=='__main__':unittest.main()
