# SPDX-License-Identifier: GPL-3.0-or-later
"""UNEXECUTED proposal: closed oriented triangle-volume point classification.
No nearest-face sign. Caller must separately reject non-adjacent self-intersections.
"""
import math
import numpy as np

def audited_topology(triangles):
 t=np.asarray(triangles,dtype=float)
 if t.ndim!=3 or t.shape[1:]!=(3,3)or not np.isfinite(t).all():raise ValueError('finite triangle array required')
 _,indices=np.unique(t.reshape(-1,3),axis=0,return_inverse=True);faces=indices.reshape(-1,3);edges={}
 for f in faces:
  if len(set(f))!=3:raise ValueError('degenerate face')
  for a,b in zip(f,np.roll(f,-1)):
   key=(min(a,b),max(a,b));edges.setdefault(key,[]).append(1 if a<b else-1)
 if any(len(v)!=2 or sum(v)!=0 for v in edges.values()):raise ValueError('not closed consistently oriented two-manifold')
 areas=np.linalg.norm(np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]),axis=1)/2
 if areas.min()<=1e-12:raise ValueError('zero/tiny face')
 return {'triangles':len(t),'welded_vertices':len(set(indices)),'edges':len(edges),'minimum_area_m2':float(areas.min())}

def classify(point,triangles,*,self_intersections_rejected=False,boundary_tolerance_m=1e-7):
 """Returns interior/boundary/exterior; boundary is NOT silently interior.
 Exact unsigned distance helper required, squared point-face output.
 """
 if not self_intersections_rejected:raise ValueError('explicit actual self-intersection audit required')
 audited_topology(triangles)
 from unsigned_distance import pts_tri
 t=np.asarray(triangles,dtype=float);p=np.asarray(point,dtype=float)
 nearest=float(np.sqrt(pts_tri(np.broadcast_to(p,(len(t),3)),t).min()))
 if nearest<=boundary_tolerance_m:return {'classification':'boundary','unsigned_distance_m':nearest,'winding':None}
 a,b,c=np.moveaxis(t-p,1,0);la=np.linalg.norm(a,axis=1);lb=np.linalg.norm(b,axis=1);lc=np.linalg.norm(c,axis=1)
 numerator=np.einsum('ij,ij->i',a,np.cross(b,c));denominator=la*lb*lc+np.einsum('ij,ij->i',a,b)*lc+np.einsum('ij,ij->i',b,c)*la+np.einsum('ij,ij->i',c,a)*lb
 winding=float(np.sum(2*np.arctan2(numerator,denominator))/(4*math.pi))
 if abs(abs(winding)-1)<1e-6:kind='interior'
 elif abs(winding)<1e-6:kind='exterior'
 else:raise ValueError('ambiguous winding; reject rather than infer containment')
 return {'classification':kind,'unsigned_distance_m':nearest,'winding':winding}
