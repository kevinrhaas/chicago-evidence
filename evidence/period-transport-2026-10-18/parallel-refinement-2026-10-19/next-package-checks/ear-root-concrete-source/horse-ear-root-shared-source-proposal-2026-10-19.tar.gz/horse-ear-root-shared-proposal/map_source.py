# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only cohort mapping of frozen actual source; produces no geometry."""
from pathlib import Path
import json,hashlib,struct
import numpy as np
P=Path(__file__).parent;B=Path('/workspace/shared/horse-head-groove-coat-next');ears=json.loads((B/'trial1/ear-source-surfaces.json').read_text());raw=(B/'trial1/equine_light_harness_skinned_prototype_01.glb').read_bytes();n=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+n]);b=raw[28+n:]
def read(i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];nc={'SCALAR':1,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];return np.frombuffer(b,{5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']],count=a['count']*nc,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,nc)
rows=[]
for side in[-1,1]:
 components=[e for e in ears if e['name'].endswith('_'+str(side))];ys=sorted({v[1]for e in components for v in e['positions_local']});cut_y=ys[2];regions=[];ring={}
 for e in components:
  retired=[];protected=[];halo=[]
  for i,f in enumerate(e['faces']):
   coords=[e['positions_local'][k]for k in f]
   (retired if any(v[1]<cut_y-1e-9 for v in coords)else protected).append(i)
   if any(abs(v[1]-cut_y)<1e-9 for v in coords):halo.append(i)
  for i,v in enumerate(e['positions_local']):
   if abs(v[1]-cut_y)<1e-9:ring.setdefault(tuple(v),[]).append({'component':e['name'],'source_vertex':i})
  regions.append({'source_component':e['name'],'lower_rows0_1_faces_retire':retired,'remaining_leaf_faces_exact':protected,'normal_halo_faces_touching_cut_ring':halo})
 assert len(ring)==18
 # Count boundary ownership on the remaining combined leaf, using exact source
 # seam positions. The open cross section must be its only boundary.
 positions=sorted({tuple(v)for e in components for v in e['positions_local']});ids={v:i for i,v in enumerate(positions)};edges={}
 for e,reg in zip(components,regions):
  for fi in reg['remaining_leaf_faces_exact']:
   f=[ids[tuple(e['positions_local'][i])]for i in e['faces'][fi]]
   for a,c in zip(f,f[1:]+f[:1]):edges.setdefault(tuple(sorted((a,c))),[]).append((a,c))
 boundary=[uses[0]for uses in edges.values()if len(uses)==1];assert len(boundary)==18;assert all(len(u)==1 or(len(u)==2 and u[0]==u[1][::-1])for u in edges.values())
 out=dict(boundary);start=min(out);loop=[start]
 while out[loop[-1]]!=start:loop.append(out[loop[-1]]);assert len(loop)<=18
 assert len(loop)==18
 rows.append({'side':side,'actual_cut_ring_y_local_m':cut_y,'remaining_open_leaf_boundary_edges':18,'ordered_root_boundary':[{'position_local_m':positions[i],'source_owners':ring[positions[i]]}for i in loop],'component_face_tables':regions})
attributes=[]
for mesh in d['meshes']:
 for pi,pr in enumerate(mesh['primitives']):
  if mesh['name']!='skinned_equine_coat' or pi!=0:continue
  for i in[1033,1058,1057]:attributes.append({'mesh':mesh['name'],'primitive':pi,'vertex':i,**{k:read(pr['attributes'][k])[i].tolist()for k in['POSITION','NORMAL','JOINTS_0','WEIGHTS_0']}})
r={'status':'SOURCE-ONLY plan, no generated geometry','input_glb_sha256':hashlib.sha256(raw).hexdigest(),'actual_source_ears_sha256':hashlib.sha256((B/'trial1/ear-source-surfaces.json').read_bytes()).hexdigest(),'skull_source_face17':[8,33,32],'witness_skull_attributes':attributes,'ear_root_cohorts':rows,'skull_chart_search_cohort':{'rows':[0,1,2],'left_theta_candidate':[2,3,4,5],'right_theta_candidate':[7,8,9,10],'status':'Exact cut face/vertex IDs TBD after actual crossing footprint and constrained polygon construction; no broad exemption.'}}
(P/'SOURCE-MAP.json').write_text(json.dumps(r,indent=2)+'\n');print([(r['side'],[(q['source_component'],len(q['lower_rows0_1_faces_retire']),len(q['remaining_leaf_faces_exact']))for q in r['component_face_tables']])for r in rows])
