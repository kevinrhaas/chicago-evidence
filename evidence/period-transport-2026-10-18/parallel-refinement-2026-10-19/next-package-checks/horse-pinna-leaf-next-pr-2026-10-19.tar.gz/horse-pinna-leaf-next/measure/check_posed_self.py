# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import json,sys
import numpy as np
P=Path(__file__).parent;sys.path.insert(0,'/workspace/shared/horse-v2-anchor-contract-next');from closed_volume import audited_topology
import official_fit_predicates as predicates
meta=json.loads((P/'horse_candidate.json').read_text());data=np.memmap(P/'horse_candidate.f32',mode='r',dtype='<f4',shape=(63,meta['triangleCount'],3,3));masks=json.loads((P.parent/'invariant-receipt.json').read_text())['masks'];ids=np.array([m['start']+i for m in meta['meshes']for i in masks[m['name']]['ear_triangle_ids']]);rows=[]
for ri,pose in enumerate(meta['rows']):
 if (pose['clip'],pose['phase'])not in[('idle',0),('idle',.25),('idle',.75),('walk',.25),('walk',.75)]:continue
 for side in[-1,1]:
  selected=ids[np.sign(data[0,ids,: ,0].mean(1))==side];triangles=np.asarray(data[ri,selected],float);topology=audited_topology(triangles);_,inv=np.unique(triangles.reshape(-1,3),axis=0,return_inverse=True);faces=inv.reshape(-1,3);lo=triangles.min(1);hi=triangles.max(1);hits=[]
  for i,a in enumerate(triangles):
   ix=np.flatnonzero(np.all(hi>=a.min(0)-1e-8,axis=1)&np.all(lo<=a.max(0)+1e-8,axis=1)&(np.arange(len(triangles))>i))
   for j in ix:
    if len(set(faces[i])&set(faces[j]))>=2:continue
    if predicates.sat(a,triangles[j]):
     crossing=predicates.proper(a,triangles[j])
     if crossing is not None:hits.append([i,int(j),crossing])
  rows.append({**pose,'side':side,'topology':topology,'proper_self_crossings':hits});assert not hits
(P/'posed-self.json').write_text(json.dumps({'pass':True,'rows':rows,'scope':'Fiveactualposes:rest,±idleheadexcursion,±walkheadexcursion;2earsurfaces each; closedorientededgepairs andno strictnon-edge-adjacentcrossings.63poseareas/orientation separatelytested. Not continuous-time/provenwholeheadwatertight.'},indent=2)+'\n');print('posedself',len(rows),'pass')
