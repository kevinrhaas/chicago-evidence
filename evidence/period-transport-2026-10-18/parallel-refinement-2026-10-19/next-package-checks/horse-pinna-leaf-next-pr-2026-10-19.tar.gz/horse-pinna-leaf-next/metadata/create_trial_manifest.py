#!/usr/bin/env python3
# SPDX-License-Identifier: CC0-1.0
"""NEW a9 pinna geometry sidecar. Does not modify/relax b880 adapter or pins."""
from pathlib import Path
import hashlib,json,struct,copy
from surface_metadata import clean_surface_manifest,require
from glb_indices import coat_indices
GLB_SHA='a9b15bda426a77bca823f606794d744d9d8af21e8ce3bb6b00be7368ff31443e'
PRODUCER_SHA='764941d47d1dc82a82d50be344f4106cf9c600e57638a00f0f0c88e1da040b31'
AUDIT_SHA='45256768f6fde01790a18970c2fd49203b21e5ff1455b23d1801f13fc5a41dd0'
MEASURED_SHA='9fe64b3d91ed2d0d65d5926720aa5171ec3dcc4147ad993252f5163275d32168'
BASE_SHA='b880dce59fda746969b7fefe91d8ba0f5478208d73f821e7efa319bdb49ca8d4'
BASE_MANIFEST_SHA='3a88ff16f3fd945cd9e7f27c88a5751793eff51af9626504166b6e6d8ea3afd6'

def actual_indices(raw):
 n=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+n]);binary=raw[28+n:];result={}
 for mesh in d['meshes']:
  require(len(mesh['primitives'])==1,'Ambiguous mesh primitive');p=mesh['primitives'][0];a=d['accessors'][p['indices']];v=d['bufferViews'][a['bufferView']];require(not a.get('sparse')and not v.get('byteStride')and a['type']=='SCALAR'and a['componentType']in[5123,5125],'Unsupported indices');code='H'if a['componentType']==5123 else'I';result[mesh['name']]=list(struct.unpack_from('<'+code*a['count'],binary,v.get('byteOffset',0)+a.get('byteOffset',0)))
 return result

def validate_ear_tables(tables,index_tables):
 result={}
 for name,record in tables.items():
  require(name in index_tables,'Unknown current mesh');vertices=record['ear_vertex_ids'];tris=record['ear_triangle_ids'];raw=index_tables[name];faces=[raw[i:i+3]for i in range(0,len(raw),3)]
  require(len(vertices)==len(set(vertices))and len(tris)==len(set(tris)),'Duplicate ear table IDs');require(all(type(i)is int and i>=0 for i in vertices),'Invalid ear vertexID');require(all(type(i)is int and 0<=i<len(faces)for i in tris),'Invalid ear triangleID')
  expected={i for i,f in enumerate(faces)if set(f)<=set(vertices)}if vertices else set();require(set(tris)==expected,'Ear table disagrees with actual current triangles');require({v for i in tris for v in faces[i]}==set(vertices),'Ear vertex table unreferenced or incomplete')
  result[name]=copy.deepcopy(record)
 require({k:(len(v['ear_vertex_ids']),len(v['ear_triangle_ids']))for k,v in result.items()if v['ear_vertex_ids']}=={'skinned_equine_coat':(368,652),'skinned_equine_ear_inner':(290,496)},'Unexpected authoritative ear component footprint')
 return result

def create(glb,producer,audit,baseline_glb,baseline_manifest,proof,output):
 paths=list(map(Path,[glb,producer,audit,baseline_glb,baseline_manifest]));raw,md,ad,base,bmd=[p.read_bytes()for p in paths];expected=[GLB_SHA,PRODUCER_SHA,AUDIT_SHA,BASE_SHA,BASE_MANIFEST_SHA]
 for b,h in zip([raw,md,ad,base,bmd],expected):require(hashlib.sha256(b).hexdigest()==h,'Wrong independently pinned trial/baseline input')
 proof=Path(proof);proofraw=proof.read_bytes();require(hashlib.sha256(proofraw).hexdigest()==MEASURED_SHA,'Wrong actual63pose proof');measured=json.loads(proofraw);require(measured['completed']and measured['pass']and len(measured['rows'])==126,'Incomplete actual63pose proof')
 output=Path(output);require(output.resolve()not in{p.resolve()for p in paths},'Output must be new sidecar');source=json.loads(md);original=json.loads(bmd);require(coat_indices(raw)==coat_indices(base),'Original body/coat triangle topology changed');require(source['shoulder_join_trial']==original['shoulder_join_trial'],'Forechest cohort metadata changed')
 result=clean_surface_manifest(source,coat_indices(raw));tables=validate_ear_tables(json.loads(ad)['masks'],actual_indices(raw));require(not set(tables['skinned_equine_coat']['ear_triangle_ids'])&set(result['active_surface_regions']['regions']['forechest_changed']),'Ear/body region overlap')
 result['shoulder_join_trial']['joint_policy']['protected']='All NON-ear rest attributes, body/head-neck join, distal/lower/sole geometry, bone names/rest/IBMs/clips/sockets validated exact. Ears EXCLUDED:658earpositions/normals and143earweights deliberately changed; joint IDs exact.'
 result['pinna_reconstruction_trial']={'status':'original anatomy analogy; visual acceptance PENDING; no metric/breed/historical ear claim','source':'Cuyer1905 Fig92p239 illo262.png, actually viewed; no plate tracing','geometry':GLB_SHA,'parent_geometry':BASE_SHA,'changed_scope':'658earvertices POSITION/NORMAL;143earweightvectors; no other vertex attributes changed','active_surfaces':tables,'authoritative_space':'Current primitive vertex/triangle ordinals, decoded actualGLB; independently tested original ear-source-surface audit','head_neck_protection_excludes_ears':True,'foot_and_body_proof':'Exact non-ear posed triangle equality across63actualidle/walk/trot samples; skeleton/clips and restattributes exact','production_acceptance':False}
 result['sidecar_provenance']={'source_glb_sha256':GLB_SHA,'source_producer_manifest_sha256':PRODUCER_SHA,'source_invariant_audit_sha256':AUDIT_SHA,'actual_63pose_measurement_sha256':MEASURED_SHA,'parent_reference_glb_sha256':BASE_SHA,'parent_reference_manifest_sha256':BASE_MANIFEST_SHA,'scope':'NEW geometry-specific metadata; no reuse of b880-only45131provenance; actual triangles validated; underlyinggeometry unchanged bythiswrite'}
 with output.open('x')as f:json.dump(result,f,indent=2);f.write('\n')
 for p,b in zip(paths,[raw,md,ad,base,bmd]):require(p.read_bytes()==b,'Protected input changed')
 return result
if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('glb');ap.add_argument('producer');ap.add_argument('audit');ap.add_argument('baseline_glb');ap.add_argument('baseline_manifest');ap.add_argument('proof');ap.add_argument('output');a=ap.parse_args();create(a.glb,a.producer,a.audit,a.baseline_glb,a.baseline_manifest,a.proof,a.output)
