# SPDX-License-Identifier: CC0-1.0
import json,struct
from surface_metadata import require
def coat_indices(raw):
    magic, version, length = struct.unpack_from('<III', raw)
    require((magic, version, length) == (0x46546c67, 2, len(raw)), 'Invalid GLB header')
    json_length, kind = struct.unpack_from('<II', raw, 12)
    require(kind == 0x4e4f534a, 'Missing JSON chunk')
    document = json.loads(raw[20:20 + json_length])
    binary_header = 20 + json_length
    binary_length, kind = struct.unpack_from('<II', raw, binary_header)
    require(kind == 0x004e4942 and binary_header + 8 + binary_length == len(raw), 'Invalid BIN chunk')
    meshes = [m for m in document['meshes'] if m.get('name') == 'skinned_equine_coat']
    require(len(meshes) == 1 and len(meshes[0]['primitives']) == 1, 'Ambiguous coat primitive')
    primitive = meshes[0]['primitives'][0]
    accessor = document['accessors'][primitive['indices']]
    view = document['bufferViews'][accessor['bufferView']]
    require(primitive.get('mode', 4) == 4 and accessor['type'] == 'SCALAR', 'Nontriangle coat')
    require(not accessor.get('sparse') and not view.get('byteStride') and view.get('buffer', 0) == 0, 'Unsupported index storage')
    require(accessor['componentType'] in (5123, 5125), 'Unsupported index type')
    code = {5123: 'H', 5125: 'I'}[accessor['componentType']]
    offset = view.get('byteOffset', 0) + accessor.get('byteOffset', 0)
    return list(struct.unpack_from('<' + code * accessor['count'], raw, binary_header + 8 + offset))
