# SPDX-License-Identifier: GPL-3.0-or-later
import pathlib,json,copy,unittest,tempfile
from create_trial_manifest import validate_ear_tables,actual_indices,create
P=pathlib.Path(__file__).resolve().parent.parent
class ActualMetadata(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tables=json.loads((P/'invariant-receipt.json').read_text())['masks'];cls.indices=actual_indices((P/'trial1/equine_light_harness_skinned_prototype_01.glb').read_bytes())
 def test_actual_ear_tables(self):self.assertEqual(validate_ear_tables(self.tables,self.indices),self.tables)
 def test_dropped_ear_face(self):
  x=copy.deepcopy(self.tables);x['skinned_equine_coat']['ear_triangle_ids'].pop()
  with self.assertRaises(ValueError):validate_ear_tables(x,self.indices)
 def test_forechest_face_cannot_be_ear(self):
  x=copy.deepcopy(self.tables);face=json.loads((P/'trial1/manifest.json').read_text())['shoulder_join_trial']['active_whole_changed_triangle_indices'][0];x['skinned_equine_coat']['ear_triangle_ids'].append(face)
  with self.assertRaises(ValueError):validate_ear_tables(x,self.indices)
 def test_duplicate_ear_face(self):
  x=copy.deepcopy(self.tables);x['skinned_equine_ear_inner']['ear_triangle_ids'].append(x['skinned_equine_ear_inner']['ear_triangle_ids'][0])
  with self.assertRaises(ValueError):validate_ear_tables(x,self.indices)
 def test_real_new_pins_and_wrong_geometry(self):
  args=[P/'trial1/equine_light_harness_skinned_prototype_01.glb',P/'trial1/manifest.json',P/'invariant-receipt.json',P/'baseline-rebuilt/equine_light_harness_skinned_prototype_01.glb',P/'baseline-rebuilt/manifest.json',P/'measure/targeted.json']
  with tempfile.TemporaryDirectory()as d:
   d=pathlib.Path(d);r=create(*args,d/'new.json');self.assertTrue(r['pinna_reconstruction_trial']['head_neck_protection_excludes_ears']);bad=d/'bad.glb';bad.write_bytes(args[0].read_bytes()+b'x')
   with self.assertRaises(ValueError):create(bad,*args[1:],d/'bad.json')
   self.assertFalse((d/'bad.json').exists())
if __name__=='__main__':unittest.main()
