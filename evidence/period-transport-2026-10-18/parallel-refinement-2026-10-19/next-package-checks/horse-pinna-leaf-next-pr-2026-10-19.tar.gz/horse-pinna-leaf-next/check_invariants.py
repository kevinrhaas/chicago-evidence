# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import json,struct,hashlib
import numpy as np
P=Path(__file__).parent

def load(p):
 b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];return json.loads(b[20:20+n]),b[28+n:]
def arr(d,b,i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];dt={5126:'<f4',5123:'<u2',5125:'<u4'}[a['componentType']];size={'VEC3':3,'VEC4':4,'MAT4':16,'SCALAR':1}[a['type']];return np.frombuffer(b,dt,a['count']*size,v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(a['count'],size)
a,ab=load(P/'baseline-rebuilt/equine_light_harness_skinned_prototype_01.glb');b,bb=load(P/'trial1/equine_light_harness_skinned_prototype_01.glb');assert a['nodes']==b['nodes']and a['skins']==b['skins']and a['materials']==b['materials'];assert len(a['meshes'])==len(b['meshes'])==6
for x,y in zip(a['animations'],b['animations']):
 assert x==y
 for s in x['samplers']:
  for k in ['input','output']:assert np.array_equal(arr(a,ab,s[k]),arr(b,bb,s[k]))
for skin in a['skins']:assert np.array_equal(arr(a,ab,skin['inverseBindMatrices']),arr(b,bb,skin['inverseBindMatrices']))
audits={key:json.loads((P/directory/'ear-source-surfaces.json').read_text())for key,directory in [('old','baseline-rebuilt'),('new','trial1')]};masks={};rows=[];global_changed=[]
for mi,(x,y)in enumerate(zip(a['meshes'],b['meshes'])):
 pa=x['primitives'][0];pb=y['primitives'][0];pos=arr(a,ab,pa['attributes']['POSITION']);newpos=arr(b,bb,pb['attributes']['POSITION']);mask=np.zeros(len(pos),bool)
 for key,geometry in [('old',pos),('new',newpos)]:
  keys={tuple(v)for surface in audits[key]if surface['material']==pa['material']for v in (np.asarray(surface['positions_local'],dtype='<f4').astype(float)+[0,1.88,.80]).astype('<f4')}
  mask|=np.array([tuple(v)in keys for v in geometry])
 assert np.array_equal(arr(a,ab,pa['indices']),arr(b,bb,pb['indices']))
 changed={}
 for attr,i in pa['attributes'].items():
  aa=arr(a,ab,i);ba=arr(b,bb,pb['attributes'][attr]);assert aa.shape==ba.shape;ids=np.flatnonzero(np.any(aa!=ba,axis=1));assert np.all(mask[ids]),(x['name'],attr,ids[~mask[ids]])
  changed[attr]=len(ids)
 indices=arr(a,ab,pa['indices']).ravel().reshape(-1,3);faces=np.flatnonzero(np.any(mask[indices],axis=1));masks[x['name']]={'ear_vertex_ids':np.flatnonzero(mask).tolist(),'ear_triangle_ids':faces.tolist()};rows.append({'mesh':x['name'],'vertices':len(pos),'ear_vertices':int(mask.sum()),'ear_triangles':len(faces),'changed_attributes':changed})
r={'pass':True,'baseline_sha256':hashlib.sha256((P/'baseline-rebuilt/equine_light_harness_skinned_prototype_01.glb').read_bytes()).hexdigest(),'trial_sha256':hashlib.sha256((P/'trial1/equine_light_harness_skinned_prototype_01.glb').read_bytes()).hexdigest(),'nodes_skeleton_sockets_materials_animations_IBMs_indices_exact':True,'all_non_ear_POSITION_NORMAL_JOINTS_WEIGHTS_exact':True,'ear_owner_frames_unchanged':True,'rows':rows,'masks':masks,'scope':'Source-audit positions define actual original ear submeshes before semantic batching; no marker redefining. Ear POSITION/NORMAL/weights allowed to change; every other attribute vector exact. Bounds deliberately lower at ear tips. No gear/anatomy acceptance.'};(P/'invariant-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(rows)
