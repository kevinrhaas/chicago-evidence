# SPDX-License-Identifier: GPL-3.0-or-later
import pathlib,json,sys
import numpy as np
P=pathlib.Path(__file__).parent;sys.path.insert(0,'/workspace/shared/horse-v2-anchor-contract-next');from closed_volume import audited_topology
sys.path.insert(0,'/workspace/shared/horse-v2-gear-v5-pair-next');import official_fit_predicates as predicates
rows=[]
for folder in ['baseline-rebuilt','trial1']:
 source=json.loads((P/folder/'ear-source-surfaces.json').read_text())
 for side in [-1,1]:
  triangles=np.concatenate([np.asarray(s['positions_local'],dtype='<f4')[np.array(s['faces'])]for s in source if s['name'].endswith('_'+str(side))]);topology=audited_topology(triangles);flat,inv=np.unique(triangles.reshape(-1,3),axis=0,return_inverse=True);ids=inv.reshape(-1,3);lo=triangles.min(1);hi=triangles.max(1);proper=[]
  for i,a in enumerate(triangles):
   candidates=np.flatnonzero(np.all(hi>=a.min(0)-1e-8,axis=1)&np.all(lo<=a.max(0)+1e-8,axis=1)&(np.arange(len(triangles))>i))
   for j in candidates:
    if len(set(ids[i])&set(ids[j]))>=2:continue
    if predicates.sat(a,triangles[j]):
     crossing=predicates.proper(a,triangles[j])
     if crossing is not None:proper.append([i,int(j),crossing])
  rows.append({'folder':folder,'side':side,'topology':topology,'non_edge_adjacent_proper_crossings':proper});assert not proper
(P/'ear-topology-self-receipt.json').write_text(json.dumps({'pass':True,'rows':rows,'scope':'Closed oriented exact-welded leaf surfaces from actual float32 sourceaudit. Adjacent sharededges excluded, vertex-sharing pairs tested for strict interior crossing. Source topology only; posed proof pending.'},indent=2)+'\n');print(rows)
