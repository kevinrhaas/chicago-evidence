# Horse geometry and viewed reference audit

2026-10-19. Read-only bounded research; no app assets, source registry, model or CI changed. Six Cuyer plate images and the Muybridge photograph below were actually downloaded and visually opened. Exact bytes/hashes/dimensions are in `viewed-image-receipt.json`.

## Reusable geometry: no cleared candidate found in this bounded search

Three.js `examples/models/gltf/Horse.glb` is locatable, but unsuitable as the presumed reusable anatomy base. Actual GLB has one primitive, 796 expanded vertices, no skin, and one morph animation (`horse_A_`); no embedded license/copyright. Its example credits Mirada / ROME. Upstream original horse model is `dataarts/3-dreams-of-black/deploy/asset_viewer/files/models/animals/horse.js` (494 source vertices,984 faces). Crucially, the asset-specific license at https://github.com/dataarts/3-dreams-of-black/blob/master/deploy/files/models/LICENSE.txt states:

> 3D assets and textures for ROME "3 Dreams of Black" at http://ro.me are licensed under a Creative CommonsAttribution-NonCommercial-ShareAlike 3.0 Unported License ( http://creativecommons.org/licenses/by-nc-sa/3.0/ ).

The repository Apache code license does not clear these assets. Reject this candidate for the proposed GPL-compatible/commercially reusable asset pipeline absent a separate grant. No rendered GLB pixels were viewed, so no claimed visual anatomy assessment. Local metadata, actual source/model license and original horse source are retained here. Three targeted GitHub repository searches (`horse model CC0`, `horse anatomy`, `horse model license`) produced no independently cleared higher-anatomy base; this is a bounded negative finding, not a claim that no such asset exists. The inspected course repository provided neither an actual usable model nor asset license.

## Positive anatomy basis: Cuyer, 1905 — actually viewed

Original book: Édouard Cuyer, *Artistic Anatomy of Animals*, translated/edited George Haywood, London, Baillière,Tindall & Cox, title-page MDCCCCV (1905). Repository https://github.com/GITenberg/Artistic-Anatomy-of-Animals_38315 ; HTML `38315-h/38315-h.htm`; local complete text/HTML and metadata retained. `metadata.yaml` states `Public domain in the USA.` and links the Public Domain Mark. Gutenberg ebook issue2011-12-15 is not the original publication date. Original1905 publication is US public domain by age; remove Gutenberg branding/package references if deriving an asset, or comply with its retained packaging/trademark terms. These are original anatomical drawings, not photographs. No book-specific horse identity, Chicago breed or historical tack claim follows.

| Actually viewed file | Exact printed locator | Concrete modeling use visible in pixels |
|---|---|---|
| illo086.png | Fig40,p64, horse skeleton left lateral | Scapula above ribcage; elbow/forearm/carpus/cannon and hind stifle/hock distinguishable; long metapodials and hoof joints. Use to correct primitive joint hierarchy and bent hind limb, not infer metric size from the small scan. |
| illo169.png | Fig70,p146, superficial horse muscles | Shoulder and chest planes, sloping neck muscle bands, rib/flank and hindquarter masses; drawing crops lower limbs. Useful mass placement, not skin/coat texture. |
| illo205.png | Fig75,p182, left anterior limb external | Forearm taper, carpal prominence, slender cannon, fetlock/pastern/hoof angles; visibly separated tendon routes. |
| illo243.png | Fig86,p220, left hind limb external | Thigh/stifle-to-hock chain, rear hock projection and long lower leg; avoids treating hock as a human knee. |
| illo262.png | Fig92,p239, horse head muscles | Large masseter cheek, muzzle/lip bands, nostril opening, eye surround and ear base. No excuse for cylinder muzzle/spherical eyes; exposed muscles are not surface sculpt targets verbatim. |
| illo279.png | Fig100,p256, inferior fore-hoof left | Frog, central cleft and paired sole/outer wall layout; supports explicit underside topology, not flat circular hoof bottom. |

Image URLs are `https://github.com/GITenberg/Artistic-Anatomy-of-Animals_38315/blob/master/38315-h/images/<filename>`. Existing HTML captions establish each identification; source text labels should be read before assigning numbered muscles. No absolute measurements or photo-quality material properties were extracted. Publication1905 means anatomical analogy only for1904 and earlier scenes, not a claim the publication was available then.

## Positive photographic motion basis: Muybridge,1878 — actually viewed

Official Commons metadata request for `File:The Horse in Motion.jpg` succeeded, then its identified original file was downloaded and opened: https://commons.wikimedia.org/wiki/File:The_Horse_in_Motion.jpg ; https://upload.wikimedia.org/wikipedia/commons/7/73/The_Horse_in_Motion.jpg . Metadata retained in `muybridge-commons-response.json`, including original-date1878-06-19, creator Eadweard Muybridge, public-domain status, no attribution required, and LoC credit https://hdl.loc.gov/loc.pnp/cph.3a45870 . This is an original1878 published photograph, not a repository-code license inference.

Pixels show a12-panel grid,11 successive running silhouettes and a standing reference. Printed original caption identifies “Sallie Gardner,” owned by Leland Stanford, Palo Alto track,19th June1878; photographer Muybridge and copyright1878. Caption states successive negatives at27-inch distance intervals/about1/25second, grid four-inch horizontal elevations, exposure under1/2000second. These are printed historical claims, not remeasured capture calibration. Sequence visibly includes gathered airborne limbs and separated landing/push-off positions. It can ground gallop silhouettes, limb sequencing, rider balance and stand/run comparison; it does NOT establish walk/trot timing, draft gait, local Chicago horse/breed, exact modern rig angles or close-up photoreal coat/eyes/hooves. No attested Chicago rider identity is imported. 1878 reference postdates1812/1835/pre-fire; use comparative anatomy/motion only for those scenes, not documentary scene evidence.

## Bounded next action

Use the cleared Cuyer drawings to refine skeletal landmarks, shoulder/neck/head masses and true hoof form in an original mesh, retaining explicit reconstructed dimensions. Use Muybridge only for a separate gallop study; do not replace a walk clip with its sequence. A licensed high-resolution photographic multi-view coat/head/hooves reference and an actually cleared higher-anatomy skinned base remain gaps. No paid acquisition, blocked-host retry, source-image texture derivation, model import or acceptance claim occurred. Stop this search here; root may register these concrete sources and decide production scope.
