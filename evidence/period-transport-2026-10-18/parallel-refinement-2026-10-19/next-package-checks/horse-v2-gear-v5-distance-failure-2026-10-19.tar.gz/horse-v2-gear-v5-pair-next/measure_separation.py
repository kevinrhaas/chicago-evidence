# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import numpy as np,json,sys,time
from check_pairs import snapshot,PARTS
import check_pairs as controls
from unsigned_distance import distances
P=Path(__file__).parent;case=sys.argv[1];assert case in ['repaired_positive','candidate_changed4','candidate_all36_patch'];collision=json.loads((P/(case+'-intersections.json')).read_text());assert collision['completed']and collision['criterion_pass']and collision['raw_SAT_pairs']==0
bm,baseline=snapshot('horse_baseline');cm,candidate=snapshot('horse_candidate');gm,gear=snapshot('gear_v5');patch_record=json.loads((P/'inputs/horse_candidate_manifest.json').read_text())['shoulder_join_trial'];coat=next(m for m in cm['meshes']if m['name']=='skinned_equine_coat');patch=np.array([coat['start']+i for i in patch_record['active_whole_changed_triangle_indices']]);rows=[];started=time.time()
for ri,info in enumerate(cm['rows']):
 full=np.asarray(baseline[ri]if case=='repaired_positive'else candidate[ri],dtype=float);ids=patch if case=='candidate_all36_patch'else np.arange(len(full));horse=full[ids];lo=horse.min(1);hi=horse.max(1);groups=gm['meshes']if case=='candidate_all36_patch'else[m for m in gm['meshes']if m['name']in PARTS];best=.1;witness=None;eligible=0
 for group in groups:
  for fi,a in enumerate(gear[ri,group['start']:group['start']+group['count']]):
   a=np.asarray(a,dtype=float);gap=np.maximum(0,np.maximum(lo-a.max(0),a.min(0)-hi));lower=np.sqrt((gap*gap).sum(1));ix=np.flatnonzero(lower<best)
   if not len(ix):continue
   ds=distances(a,horse[ix]);eligible+=len(ix);k=int(ds.argmin())
   if ds[k]<best:
    best=float(ds[k]);witness={'gear':group['name'],'gear_triangle':fi,'horse_triangle_global':int(ids[ix[k]]),'gear_points_m':a.tolist(),'horse_points_m':horse[ix[k]].tolist()}
 assert witness is not None and best<.1,'Cannot certify remote100mm exclusion without actual eligiblewitness'
 rows.append({**info,'minimum_unsigned_triangle_distance_m':best,'witness':witness,'exact_candidate_pairs':eligible,'100mm_remote_exclusion_certified':True});(P/(case+'-separation-partial.json')).write_text(json.dumps({'completed':False,'rows':rows},indent=2)+'\n')
 if ri%10==0:print(case,info,best,flush=True)
 if controls.STOP:raise SystemExit(130)
minimum=min(r['minimum_unsigned_triangle_distance_m']for r in rows);required=.005 if case!='candidate_all36_patch'else 0.;report={'case':case,'completed':True,'criterion_pass':minimum>=required if required else minimum>0,'required_minimum_m':required,'minimum_m':minimum,'rows':rows,'elapsed_s':time.time()-started,'scope':'Exact vertex-face+edge-edge unsigned minimum under separatelyverified zero-SAT precondition; 100mm initial bound requires actualeligible witness, then onlyAABB lowerbounds unable to improve bestpruned. No containment/continuous-time/pressureclaim.'};(P/(case+'-separation.json')).write_text(json.dumps(report,indent=2)+'\n');print({k:report[k]for k in ['case','criterion_pass','minimum_m','elapsed_s']})
