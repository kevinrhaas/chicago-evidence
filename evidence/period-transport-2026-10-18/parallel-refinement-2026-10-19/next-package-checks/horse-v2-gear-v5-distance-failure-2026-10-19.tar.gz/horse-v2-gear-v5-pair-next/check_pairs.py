# SPDX-License-Identifier: GPL-3.0-or-later
"""Fresh63pose actualtriangle SAT/proper checks. No cached green/geometry waiver."""
from pathlib import Path
import numpy as np,json,sys,time,signal,hashlib
import official_fit_predicates as math
P=Path(__file__).parent;PARTS=math.PARTS;STOP=False

def stop(*_):
 global STOP
 STOP=True
signal.signal(signal.SIGINT,stop);signal.signal(signal.SIGTERM,stop)

def snapshot(name):
 m=json.loads((P/(name+'.json')).read_text());file=P/(name+'.f32');assert hashlib.sha256(file.read_bytes()).hexdigest()==m['buffer_sha256'];data=np.memmap(file,mode='r',dtype='<f4',shape=(63,m['triangleCount'],3,3));return m,data

def run(case):
 math.predicate_controls();bm,baseline=snapshot('horse_baseline');cm,candidate=snapshot('horse_candidate');gm,gear=snapshot('gear_v5');assert bm['triangleCount']==14172 and cm['triangleCount']==15392 and gm['triangleCount']==8012 and len(gm['meshes'])==36
 cohort=json.loads((P/'inputs/horse_candidate_manifest.json').read_text())['shoulder_join_trial']['active_whole_changed_triangle_indices'];coat=next(m for m in cm['meshes']if m['name']=='skinned_equine_coat');patch=np.array([coat['start']+i for i in cohort]);assert len(patch)==1586 and len(set(patch))==1586
 gear_groups=[m for m in gm['meshes']if m['name']in PARTS];assert len(gear_groups)==4
 # Fourchangedparts are root-authored and actually stationary in capturedposes.
 for m in gear_groups:
  part=gear[:,m['start']:m['start']+m['count']];assert np.all(part==part[0]),'Baselinecontrolcannotreuseposedmovingpart'
 old=math.load(P/'inputs/gear_original.glb');oldgroups={name:[]for name in PARTS}
 for name,fi,tri in old:
  if name in PARTS:oldgroups[name].append((fi,np.array(tri)))
 rows=[];started=time.time();completed=False
 report={'case':case,'scope':'Freshactual63GLTFLoaderposes, rawSATepsilon1e-8m plus strictedge-plane/barycentric crossings; no containment/load/continuous-time acceptance','input_receipt':json.loads((P/'input-receipt.json').read_text()),'pose_buffers':{k:v['buffer_sha256']for k,v in [('baseline',bm),('candidate',cm),('gear_v5',gm)]},'rows':rows}
 for ri,info in enumerate(cm['rows']):
  original=case in ['original_negative','repaired_positive'];hm=bm if original else cm;full=np.asarray(baseline[ri]if original else candidate[ri],dtype=float);ids=np.arange(len(full))if case!='candidate_all36_patch'else patch;horse=full[ids];lo=horse.min(1);hi=horse.max(1);union_lo=lo.min(0);union_hi=hi.max(0);hits=[];aabb=0;gear_count=0
  groups=gm['meshes']if case=='candidate_all36_patch'else gear_groups
  for group in groups:
   name=group['name'];triangles=oldgroups[name]if case=='original_negative'else [(i,np.asarray(t,dtype=float))for i,t in enumerate(gear[ri,group['start']:group['start']+group['count']])];gear_count+=len(triangles)
   for fi,a in triangles:
    amin=a.min(0);amax=a.max(0)
    if np.any(amax<union_lo-1e-8)or np.any(amin>union_hi+1e-8):continue
    eligible=np.flatnonzero(np.all(hi>=amin-1e-8,axis=1)&np.all(lo<=amax+1e-8,axis=1));aabb+=len(eligible)
    for k in eligible:
     if math.sat(a,horse[k]):
      strict=math.proper(a,horse[k]);global_id=int(ids[k]);mesh=next(m for m in hm['meshes']if m['start']<=global_id<m['start']+m['count']);hits.append({'gear':name,'gear_triangle':int(fi),'horse_mesh':mesh['name'],'horse_triangle_global':global_id,'horse_triangle_local':global_id-mesh['start'],'proper':strict,'gear_points_m':a.tolist(),'horse_points_m':horse[k].tolist()})
  rows.append({**info,'actual_horse_triangles':len(horse),'actual_gear_triangles':gear_count,'AABB_candidates':aabb,'raw_SAT_pairs':len(hits),'proper_crossings':sum(h['proper']is not None for h in hits),'pairs':hits})
  report.update(completed=False,elapsed_s=time.time()-started);(P/(case+'-partial.json')).write_text(json.dumps(report,indent=2)+'\n')
  if ri%10==0 or hits:print(case,info,len(hits),flush=True)
  if STOP:break
 else:completed=True
 report.update(completed=completed,elapsed_s=time.time()-started,raw_SAT_pairs=sum(r['raw_SAT_pairs']for r in rows),proper_crossings=sum(r['proper_crossings']for r in rows))
 report['criterion_pass']=completed and ((report['proper_crossings']>0)if case=='original_negative'else(report['raw_SAT_pairs']==0 and report['proper_crossings']==0))
 (P/(case+'-intersections.json')).write_text(json.dumps(report,indent=2)+'\n');print({k:report[k]for k in ['case','completed','criterion_pass','raw_SAT_pairs','proper_crossings','elapsed_s']},flush=True)
 if not completed:raise SystemExit(130)
if __name__=='__main__':
 case=sys.argv[1];assert case in ['original_negative','repaired_positive','candidate_changed4','candidate_all36_patch'];run(case)
