# Paired qualification setup held for root fullgate

Exactlocalinput GLBs/hashreceipts preserved. Fresh actualGLTFLoader63poses captured separately for89horse andb880horse;45930all36gear usesactualparentinverse headbinding. No collision/separation/stand-off/browser execution yet. Source ASTchecked only duringrootresourcehold.

Run independently afterrootrelease: check_pairs.py original_negative; repaired_positive; candidate_changed4; candidate_all36_patch. Eachwrites perposepartial andfinalrawSAT+properwitness receipts; preservesrealnegativecontrol. Then measure_separation.py onlyfor completedzero-SAT repaired_positive/candidate_changed4/candidate_all36_patch, unchanged5mmforchanged4; all36patch positiveglobal separation. If candidatefails, stop/reportmeasuredcause beforegeometryrepair and no browser. Stand-off/coupledviews onlyaftermechanicalpass andresourcecoordination. No app/ticket/Blender/CI changes.

Posebuffers remaininthisoutsideworkingdirectory andtheir SHA256values areinmetadata. Sourcecheckpointarchive excludeslarge regenerated.f32 buffers; exactinputs+capture sourceallow reproduction. No sourcecheckpoint is a testpass.
