# SPDX-License-Identifier: GPL-3.0-or-later
"""Original vector distance math; require separately verified zero-SAT pair before use."""
import numpy as np
def pts_tri(pt,tri):
 a=tri[:,0];u=tri[:,1]-a;v=tri[:,2]-a;n=np.cross(u,v);n2=(n*n).sum(1);d=((pt-a)*n).sum(1);projection=pt-d[:,None]*n/np.maximum(n2[:,None],1e-30);w=projection-a;uu=(u*u).sum(1);uv=(u*v).sum(1);vv=(v*v).sum(1);wu=(w*u).sum(1);wv=(w*v).sum(1);den=uu*vv-uv*uv;b=(vv*wu-uv*wv)/np.maximum(den,1e-30);c=(uu*wv-uv*wu)/np.maximum(den,1e-30);inside=(b>=0)&(c>=0)&(b+c<=1)&(den>1e-25);best=np.where(inside,d*d/np.maximum(n2,1e-30),np.inf)
 for i in range(3):
  e=tri[:,(i+1)%3]-tri[:,i];t=((pt-tri[:,i])*e).sum(1)/np.maximum((e*e).sum(1),1e-30);q=tri[:,i]+np.clip(t,0,1)[:,None]*e;best=np.minimum(best,((q-pt)**2).sum(1))
 return best
# Independent exact segment-to-segment distances, including near-parallel endpoints.
def segments(a,b,c,d):
 u=b-a;v=d-c;w=a-c;A=(u*u).sum(1);B=(u*v).sum(1);C=(v*v).sum(1);D=(u*w).sum(1);E=(v*w).sum(1);den=A*C-B*B;s=(B*E-C*D)/np.maximum(den,1e-30);t=(A*E-B*D)/np.maximum(den,1e-30);inside=(den>1e-25)&(s>=0)&(s<=1)&(t>=0)&(t<=1);best=np.where(inside,((w+s[:,None]*u-t[:,None]*v)**2).sum(1),np.inf)
 for point,x,y in [(a,c,d),(b,c,d),(c,a,b),(d,a,b)]:
  e=y-x;q=x+np.clip(((point-x)*e).sum(1)/np.maximum((e*e).sum(1),1e-30),0,1)[:,None]*e;best=np.minimum(best,((q-point)**2).sum(1))
 return best
def distances(a,bs):
 aa=np.broadcast_to(a,bs.shape);best=np.full(len(bs),np.inf)
 for i in range(3):best=np.minimum(best,pts_tri(aa[:,i],bs));best=np.minimum(best,pts_tri(bs[:,i],aa))
 for i in range(3):
  for j in range(3):best=np.minimum(best,segments(aa[:,i],aa[:,(i+1)%3],bs[:,j],bs[:,(j+1)%3]))
 return np.sqrt(best)
