# T-2794 refreshed minimal C02 base proposal — outside only, not installed

Base checkout f97ee94970385d35f469c449c6b111b0d8488057 remains unchanged. Only `base/files/` is the proposed app overlay; all other files are evidence/research replay. BASE-MANIFEST.json lists39new/eightmodified paths, preimage hashes, protected original model/source/input hashes and exact proposed hashes. `base/existing-files.patch` applies only existing files and passes git apply --check. Copy new paths separately after reviewing hashes; no central ticket or shipped changelog.js change is proposed. The new entry is changelog.d/T-2794.json.

## What changed from immutable 7d746 / bdb78d predecessors

1. Source retains the complete old pre-door scope quote under `pre_door_source_scope_history`, explicitly PROJECT source/not period text, with the earlier branch and superseding reconstructed door branch. Current liberties[2] truthfully describes rigid door/hinge geometry and endpoint transforms; forces, passengers and other mechanical/period acceptance stay absent.
2. New metadata-only GLB is **93d4020036e5c685ce95010fe64b26c55a1561db4517405f0590f7a398253331**,860956B. Sidecar **5188ab42d1c3ac2fb63dc1378f4b7f978468f67a96b98812687337fc932d8887**; generator **b3b136f37a125210effdc71c6203d7293456899996f8ff37d8723f013ff2c26d**. ALL nonextras JSON and BIN bytes are exact to original ddda. No paint, geometry, material, nodes, animation, sockets, door joint or frame changes. Two runs exact; prior flagoff enclosure exact; all10old/newdefault-four output files exact on executingPython3.12.14. No crossPythonminor byte promise.
3. Corrected checker **f7704aacc54683623a87ea911ece369993fd2997d1d2caabddc98a63c4c0acec** binds actual selected-scene triangle ancestry and uses actual hierarchy pose transforms.11512active/424moving triangles,15angles0..70by5:0SAT contacts, allcontacts retained/no exceptions; actual70degree maxtravel0.857655m. Historical old checker receipts remain explicitly closed-shape mapping+sourceposed only.
4. Cheap hierarchy regression **6c591d7f72a41ff108899ec316f5e832770e470b72844ace85dbaf19bbe73ac6** rejects all/onepartclosed-preserving reparent,orphan,duplicateactivepivot andemptyselectedscene. It deletes stale receipts and requires passed=false, exactstage/errorprefix and current fixture hash, not just nonzero exit. Normal AND python-O runs pass; unrelated childcrash with a fresh matching-fixture receipt is deliberately refused. All failure receipts survive.
5. Browser probe expected bytes/hash now93d4/860956; both actual15pose and cheapnegative check hooks are proposed. NO browser ran for new metadata bytes. Old portable screenshots remain historical identical-geometry appearance checkpoints, not a new browser pass. Root must run installed viewer on chosen head.

## Atomic scope and licensing

Minimal base supplies standalone repo-relative GPL original/derived generator, data, closedGLB/sidecars,44pxendpoint viewer, gallery, source/actualgeometry checks, control fixture, documentary receipts, exact licenses, append-only liberties/STATUS/ROADMAP and T-2794changelog entry. Existing project C01 procedural source is the licensed code basis; no missing licensed base file, external texture/photograph, archive download, private path, Blender or sibling-source runtime prerequisite. Existing vendorThree/Playwright remain separate dependencies; checker uses existing NumPy.

STATUS/ROADMAP/LIBERTIES preserve their original exact bytes as prefix. ROADMAP's existing nonUTF8 FC at425651 is retained, not normalized. Eight existing text diffs are contextual. No source/code/GLB in C01/W01/horse/harness/hitch is replaced; protected hashes in manifest. f97 root is read-only during this proposal.

Optional paint/studio archives23f021/63d57 remain immutable separate studies, NOT included or silently rebased. Their old generator/GLB hashes must not overwrite this metadata correction; root would need an explicit future rebase/regeneration and matching proofs before selecting them. This base carries no clearcoat or lighting change.

## Repo-relative commands after root installation (not executed in app here)

```sh
python3 tools/transport/generate_studies.py --only carriage-c02 --output-dir /tmp/c02-generated
python3 tools/transport/test_carriage_c02_door.py --receipt /tmp/c02-actual-door.json
python3 tools/transport/test_carriage_c02_door_hierarchy.py
node tools/transport/smoke_carriage_c02.cjs /tmp/c02-browser
```

CLIchecker/generator accept explicit inputs/output/receipt paths. Source-generated intermediates and hierarchy fixtures are owned temporary outputs. Browser owns loopback server and closes finally (optional PW_EXECUTABLE). --full-positive on hierarchy tool runs archived matrix/TRS15angle controls when needed; normal gate runs five cheap semantic negatives. Khronos on current regeneratedGLB reports0errors/0warnings,21existingempty-socket infos. Current metadata/newnormalguards pass; old source quaternion/matrix/TRS independent review remains separately scoped.

Root must install selected files, measure REAL gate-step isolation for BOTH new commands, run normal derived tail (liberties source/mirrors), exact-license/hash checks and complete final-head tools/check.sh and required browser validation. No invented isolation row/wrote[] record, derived output, fullgate or publication pass is supplied here. No full unrelated human/equine bake or town placement follows from this isolated rigid model.

## Scope remains limited

1904development-only original roofed carriage reconstruction; no1835 occupants/placement/owner/subtype/precisehistorical hardware, finish, color or photographic acceptance. No source pixels/tracing or unseen plate.15discrete triangle-surface samples do NOT prove continuous sweep, solid containment, passenger passage, forces, cloth/grip or boarding. Interval bound32.619mm exceeds submillimetre hinge gap. T-2794 stays open. Preserved source-scope quotation is not a newly discovered historical source.
