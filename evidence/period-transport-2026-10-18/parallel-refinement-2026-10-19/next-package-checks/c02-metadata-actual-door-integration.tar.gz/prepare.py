from pathlib import Path
import shutil,json,hashlib
P=Path(__file__).parent;B=P/'base/files/chicago/4d';old=Path('/workspace/shared/c02-f97-integration/base/files/chicago/4d');shutil.copytree(old,B,dirs_exist_ok=True)
f=B/'tools/transport/generate_carriage_c02.py';s=f.read_text();needle="sidecar['enclosure_repair']="
insert="""if DOOR:
 # Preserve the pre-door PROJECT source wording as history, never as a period quotation.
 sidecar['pre_door_source_scope_history']={
  'quotation':sidecar['liberties'][2],
  'quotation_origin':'Original project C02 pre-operable-door generator sidecar; not historical source text',
  'applies_to':'Earlier C02 branch without reconstructed operable door',
  'superseded_by':'operable_door_study=true adds original rigid door/hinge geometry and endpoint transforms only',
  'not_attested':'historical door hardware, dimensions, ownership, forces, passenger passage and photographic quality'}
 sidecar['liberties'][2]='The enabled operable-door study adds independently reconstructed rigid door/hinge geometry and closed/open endpoint transforms. No brake, horse/team, rider, reins, fitted harness, hinge forces or passenger passage is supplied; cabin openings and furniture remain unverified independent reconstruction.'
"""
assert s.count(needle)==1;s=s.replace(needle,insert+needle,1);f.write_text(s)
for name in['test_carriage_c02_door.py','test_carriage_c02_door_hierarchy.py']:shutil.copyfile(Path('/workspace/shared/c02-actual-door-checker-next')/name,B/'tools/transport'/name)
# Default four-model controls: same original source/inputs under old and additive orchestrators.
A=Path('/workspace/chicago/chicago/4d')
for name in['old-root','new-root']:
 root=P/name
 for rel in['tools/transport/generate_wagon.py','tools/transport/generate_carriage.py','tools/transport/generate_horse.py','tools/transport/generate_harness.py','tools/transport/horse_geometry.py',*[f'data/transport/studies/{n}.json'for n in['wagon','carriage','horse','harness']]]:
  f=root/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(A/rel,f)
 shutil.copyfile((A if name=='old-root'else B)/'tools/transport/generate_studies.py',root/'tools/transport/generate_studies.py')
print(B)
