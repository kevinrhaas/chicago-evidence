from pathlib import Path
import numpy as np,json
from check_pairs import snapshot
import official_fit_predicates as predicates
P=Path(__file__).parent
m,data=snapshot('gear_v5');groups={x['name']:x for x in m['meshes']};c=groups['breastcollar'];collar=np.asarray(data[0,c['start']:c['start']+c['count']],float);rows=[]
for name in ['trace_l','trace_r','breastcollar_support_l','breastcollar_support_r']:
 g=groups[name];b=np.asarray(data[0,g['start']:g['start']+g['count']],float);lo=b.min(1);hi=b.max(1);hits=[]
 for i,a in enumerate(collar):
  ix=np.flatnonzero(np.all(hi>=a.min(0)-1e-8,axis=1)&np.all(lo<=a.max(0)+1e-8,axis=1))
  for j in ix:
   if predicates.sat(a,b[j]):hits.append([i,int(j)])
 rows.append({'partner':name,'actual_surface_SAT_pairs':len(hits),'pairs':hits,'connected_via_intersecting_surfaces':bool(hits)})
# Collar cap rectangles in decoded actual triangles; original route endpoints also trace/socket positions.
params=json.loads((P/'parameters.json').read_text());caps=[]
for station,face in [(0,256),(32,258)]:
 corners=np.unique(collar[face:face+2].reshape(-1,3),axis=0);assert len(corners)==4
 center=corners.mean(0);socket=np.array(params['breastcollar_route_m'][station]);dist=np.linalg.norm(corners[:,None]-corners[None,:],axis=2);pairs=sorted([(dist[i,j],corners[j]-corners[i])for i in range(4)for j in range(i+1,4)],key=lambda x:x[0]);short=pairs[0][1];long=next(v for d,v in pairs if .049<d<.051);u=short/np.linalg.norm(short);v=long/np.linalg.norm(long);normal=np.cross(u,v);delta=socket-center;coords=[float(delta@u),float(delta@v),float(delta@normal)];inside=abs(coords[0])<=.0040001 and abs(coords[1])<=.0250001 and abs(coords[2])<1e-6
 caps.append({'station':station,'socket_in_actual_cap_rectangle':inside,'socket_cap_coordinates_m':coords,'center_m':center.tolist(),'socket_m':socket.tolist()})
report={'scope':'Actual decoded static geometry; intended gear-to-gear intersections show attachment overlap, not load/pressure suitability. Unchanged socket center remains inside collar endpoint cap. All four parts root-static across63poses.','partner_intersections':rows,'cap_socket_membership':caps,'pass':all(r['connected_via_intersecting_surfaces']for r in rows)and all(r['socket_in_actual_cap_rectangle']for r in caps)}
(P/'attachment-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
