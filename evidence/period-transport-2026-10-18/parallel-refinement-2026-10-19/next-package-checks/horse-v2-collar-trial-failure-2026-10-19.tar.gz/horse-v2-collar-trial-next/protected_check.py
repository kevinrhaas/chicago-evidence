import json,struct,pathlib,hashlib,math
P=pathlib.Path(__file__).parent

def load(p):
 b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);off=20+n;size,typ=struct.unpack_from('<II',b,off);return d,b[off+8:off+8+size]
def buf(d,b,a):
 a=d['accessors'][a];v=d['bufferViews'][a['bufferView']];start=v.get('byteOffset',0)+a.get('byteOffset',0);num={'VEC3':3,'VEC2':2,'SCALAR':1}[a['type']];return b[start:start+a['count']*num*4]
a,ab=load(pathlib.Path('/workspace/shared/horse-v2-gear-v5-pair-next/inputs/gear_v5.glb'));b,bb=load(P/'inputs/gear_v5.glb');assert a['nodes']==b['nodes'];assert a['materials']==b['materials'];assert len(a['meshes'])==len(b['meshes'])==36
unchanged=[];maxmove=0
for x,y in zip(a['meshes'],b['meshes']):
 assert x['name']==y['name'];pa=x['primitives'][0]['attributes'];pb=y['primitives'][0]['attributes']
 if x['name']!='breastcollar':
  for k in ['POSITION','NORMAL']:assert buf(a,ab,pa[k])==buf(b,bb,pb[k]),(x['name'],k)
  unchanged.append(x['name'])
 else:
  aa=struct.unpack('<'+'f'*(len(buf(a,ab,pa['POSITION']))//4),buf(a,ab,pa['POSITION']));ba=struct.unpack('<'+'f'*(len(buf(b,bb,pb['POSITION']))//4),buf(b,bb,pb['POSITION']));assert len(aa)==len(ba)
  maxmove=max(math.dist(aa[i:i+3],ba[i:i+3])for i in range(0,len(aa),3));assert maxmove<.0020001
assert len(unchanged)==35
r={'pass':True,'unchanged35_meshes':unchanged,'nodes_and_sockets_exact':True,'materials_exact':True,'maximum_collar_corresponding_vertex_displacement_m':maxmove,'body_sha256':hashlib.sha256((P/'inputs/horse_candidate.glb').read_bytes()).hexdigest(),'scope':'body exact;35other mesh POSITION/NORMAL exact; collar local surface normals regenerated. Attachment continuity remains unproven.'};(P/'protected-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
