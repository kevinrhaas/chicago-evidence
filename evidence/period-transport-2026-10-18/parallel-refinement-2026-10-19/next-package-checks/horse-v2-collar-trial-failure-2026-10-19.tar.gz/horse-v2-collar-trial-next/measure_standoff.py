# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import numpy as np,json,time
from check_pairs import snapshot,PARTS
import check_pairs as controls
from unsigned_distance import pts_tri
P=Path(__file__).parent
for case in ['candidate_changed4','candidate_all36_patch']:
 r=json.loads((P/(case+'-separation.json')).read_text());assert r['completed']and r['criterion_pass'],'Mechanical separation pending/failed; no standoffacceptance'
bm,baseline=snapshot('horse_baseline');cm,candidate=snapshot('horse_candidate');gm,gear=snapshot('gear_v5');groups=[m for m in gm['meshes']if m['name']in PARTS];rows=[];started=time.time()
oldP=Path('/workspace/shared/horse-v2-gear-v5-pair-next');oldmeta=json.loads((oldP/'gear_v5.json').read_text());import hashlib
assert hashlib.sha256((oldP/'gear_v5.f32').read_bytes()).hexdigest()==oldmeta['buffer_sha256']
oldgear=np.memmap(oldP/'gear_v5.f32',mode='r',dtype='<f4',shape=(63,oldmeta['triangleCount'],3,3))
for model,currentgear in [('originalV5_on_b880',oldgear),('trial154_on_b880',gear)]:
 for ri,info in enumerate(cm['rows']):
  horse=np.asarray(candidate[ri],dtype=float);lo=horse.min(1);hi=horse.max(1)
  for group in groups:
   points=np.unique(np.asarray(currentgear[ri,group['start']:group['start']+group['count']],dtype=float).reshape(-1,3),axis=0);values=[];witnesses=[]
   for point in points:
    gap=np.maximum(0,np.maximum(lo-point,point-hi));lower=np.sqrt((gap*gap).sum(1));ix=np.flatnonzero(lower<.2)
    squared=pts_tri(np.broadcast_to(point,(len(ix),3)),horse[ix])if len(ix)else np.array([]);fallback=not len(ix)or float(squared.min())>=.04
    if fallback:ix=np.arange(len(horse));squared=pts_tri(np.broadcast_to(point,(len(ix),3)),horse)
    k=int(squared.argmin());distance=float(np.sqrt(squared[k]));values.append(distance);witnesses.append({'garment_point_m':point.tolist(),'distance_m':distance,'horse_triangle_global':int(ix[k]),'horse_points_m':horse[ix[k]].tolist(),'fullscan_fallback':fallback})
   a=np.array(values);maximum=int(a.argmax());minimum=int(a.argmin());rows.append({'model':model,**info,'part':group['name'],'unique_surface_vertices':len(points),'minimum_vertex_standoff_m':float(a.min()),'median_vertex_standoff_m':float(np.median(a)),'p95_vertex_standoff_m':float(np.quantile(a,.95)),'maximum_vertex_standoff_m':float(a.max()),'minimum_witness':witnesses[minimum],'maximum_witness':witnesses[maximum],'values_m':values})
  if ri%10==0:print('stand-off',model,info,flush=True)
  (P/'stand-off-partial.json').write_text(json.dumps({'completed':False,'rows':rows},indent=2)+'\n')
  if controls.STOP:raise SystemExit(130)
comparison=[]
for part in sorted(PARTS):
 b=[r for r in rows if r['model']=='originalV5_on_b880'and r['part']==part];c=[r for r in rows if r['model']=='trial154_on_b880'and r['part']==part];comparison.append({'part':part,'baseline_maximum_vertex_standoff_m':max(r['maximum_vertex_standoff_m']for r in b),'candidate_maximum_vertex_standoff_m':max(r['maximum_vertex_standoff_m']for r in c),'maximum_corresponding_pose_vertex_maximum_delta_m':max(y['maximum_vertex_standoff_m']-x['maximum_vertex_standoff_m']for x,y in zip(b,c))})
report={'completed':True,'scope':'Actualuniquechangedgear surfacevertices vs allactiveposedhorse triangles, identical b880 body, originalV5 versus trial154 gear,63poses each; stand-offdistribution andwitnesses only, no inventeduppergaptolerance/pressure/containment/photographicacceptance','comparison':comparison,'rows':rows,'elapsed_s':time.time()-started};(P/'stand-off.json').write_text(json.dumps(report,indent=2)+'\n');print({'stand_off_completed':True,'comparison':comparison,'elapsed_s':report['elapsed_s']})
