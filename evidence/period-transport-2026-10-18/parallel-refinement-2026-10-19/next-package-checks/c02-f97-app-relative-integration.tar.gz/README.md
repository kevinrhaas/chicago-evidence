# T-2794: concrete C02 integration proposal against f97 (NOT APPLIED)

This is a review/install parcel, not an app mutation or new ticket. Base commit: f97ee94970385d35f469c449c6b111b0d8488057. Every runtime/source dependency is repo-relative. No archive download, sibling checkout, /workspace/shared, Blender or external asset acquisition is required after installation. Existing project-derived GPL C01 procedural conventions provide the licensed source basis; the new C02 generator is standalone, not an import of a missing intermediate generator. No new upstream asset/license clearance is required. Source images are not included/derived as textures. All numerical cabin/door/material parameters are reconstructed.

## Choose one atomic parcel

**Minimal recommended starting point: base only.** `base/files/` supplies the 26 new paths and eight changed existing paths in BASE-MANIFEST.json. New core paths are generator, source parameters, source-only checker, 44px endpoint viewer, exact ddda GLB/sidecars, gallery card, browser smoke, flag-off fixture, T-2794 changelog entry and focused evidence. Existing changed paths are `generate_studies.py`, `tools/check.sh`, transport gallery, transport/LICENSES.md, assets/LICENSES.md, LIBERTIES.md, STATUS.md and ROADMAP.md. No old C01/wagon/horse/harness/hitch source/output is replaced. Protected hashes cover their actual20runtime files plus four original generators/inputs.

**Optional layer AFTER base only if root selects it:** `optional/files/` adds standard glTF clearcoat recipe/variant and original studio reflection helper; replaces only C02 generator/demo plus selected license/liberty/manifest files. OPTIONAL-MANIFEST.json lists all13 paths. Baseline GLB/default null environment remain unchanged. Explicit `?environment=studio&surface=paint` selects the reconstruction. V2studio alone was mixed/not-default-accepted; paint under that SAME fixed light is a modest dark-panel improvement, still diagrammatic. No verified period varnish recipe/color/finish is asserted. No coat/town/rider photographic acceptance. Root may defer this entire optional layer.

## Applying the proposal (root only, not executed here)

Check current HEAD/preimage hashes first. Apply `base/existing-files.patch` for the eight existing text paths; `git apply --check` passed against f97. Then copy only BASE-MANIFEST.json `new_files` from base/files, preserving paths. Full existing-file copies are included for review but contextual patch avoids overwriting unrelated changes. If optional chosen, copy its manifest-listed files only after reviewing replacement hashes against base. Optional INTEGRATION-MANIFEST records the combined actual source/output hashes. Do not apply prepare_overlay.py/finish_plan.py: these are research packaging recipes with original review workspace locations, not runtime prerequisites.

STATUS/ROADMAP/LIBERTIES are append-only here: all original bytes are preserved as exact prefix. ROADMAP already contains non-UTF8 byte FC at offset425651; naive UTF8 rewrite refused in initial outside preparation. The corrected contextual patch/overlay uses surrogateescape roundtrip and LIGHT-PORTABILITY-RECEIPT.json proves all original prefix bytes retained. Do NOT normalize/re-encode those files. No shipped changelog.js edit: the proposed entry is changelog.d/T-2794.json.

## Root commands after installing chosen files (from chicago/4d)

```sh
python3 tools/transport/generate_studies.py --only carriage-c02 --output-dir /tmp/c02-base
python3 tools/transport/test_carriage_c02_door.py --asset /tmp/c02-base/carriage-c02/carriage-c02.glb --receipt /tmp/c02-mechanics.json
python3 tools/transport/generate_carriage_c02.py --parameters tools/transport/fixtures/carriage-c02-flag-off.json --output-dir /tmp/c02-flag-off
node tools/transport/smoke_carriage_c02.cjs /tmp/c02-browser
```

Base enabled GLB SHA256 ddda1b89b330c889d69acaf55b79c4a114d193ff140e9e27c11cf74fc7f16eb6,860200B,11512triangles,31batches,62nodes. Two runs matched on Python3.12.14; legacy float reductions do NOT imply cross-minor byte guarantee. Verify installed actual source geometry with existing1µm mapping tolerance, not a byte tolerance waiver. Actual CLI source is repo-relative. Existing `numpy` is checker dependency; Playwright/current vendoredThree are browser dependencies (optional PW_EXECUTABLE supported); no installation performed here.

If optional chosen:

```sh
python3 tools/transport/generate_carriage_c02.py --parameters data/transport/studies/carriage-c02.json --paint-study data/transport/studies/carriage-c02-paint.json --output-dir /tmp/c02-paint
node tools/transport/smoke_carriage_c02_studio.cjs /tmp/c02-studio-browser
node tools/transport/smoke_carriage_c02_paint.cjs /tmp/c02-paint-browser
```

Variant output SHA2566539a49534c28be95a0dabf7bc98599230752d64dd849eded257aec21e2c9466,861348B. On explicit source regeneration replace ONLY `renderers/web/transport/carriage-c02/paint-study/{carriage-c02.glb,carriage-c02.json,parameters.json}`. Original geometry/binary/nodes/scene/accessors/meshes and other six materials exact; KHR_materials_clearcoat is standard. Flagoff remains original ddda. Optional viewer loads the repo-relative paint-study folder; no private path remains. Default original-four generation must be re-compared against its unchanged source/inputs if root changes any dispatch beyond this proposal.

## Required validation and genuinely open limits

The new check.sh hook performs actual exported triangle mapping +15angles source mechanics (about10s/oneCPU at research checkpoint, not a capacity guarantee). Analytic triangle predicate controls bothorders and selected-scene negative are preserved. Exact old failure/default-list proposal bug and final portable receipts remain documentary, not fresh installed-head greens. Root must run chosen installed source CLI/Khronos and exported-node metadata checks, desktop/mobile actual served model+header/control framing and request/GLerrors, source/sidecar/license/hash verification and protected original files before integration. No shared full gate, browser or generation was repeated while assembling this f97 overlay: only CLI help, source syntax, patch check, private-path scan and byte-prefix controls.

15discrete angles with0triangle contacts/no exclusions do NOT prove continuous swept clearance, solid containment, safe passage, forces, boarding, cloth/contact or historical hardware.32.619mm interval displacement bound exceeds submillimetre hinge clearance. Root should preserve these explicit limits; T-2794 remains open. No1835 resident/person/carriage-owner or traffic placement is introduced.

After root selects/installs/reviews: run the existing normal derivation workflow (LIBERTIES append changes data/liberties.json and published mirrors), license/hash checks and required complete tools/check.sh on the final head. Root manages resulting derived files/status/roadmap truth and any publication; not precomputed/fabricated here. Do not modify ship changelog.js directly. No unnecessary humanoid/equine bake, town smoke or new ticket follows from this isolated rigid model unless root makes additional integration changes requiring it.
