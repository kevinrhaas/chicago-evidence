// SPDX-License-Identifier: GPL-3.0-or-later
// Bounded isolated viewer contract; no town/GPU/boarding acceptance.
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),crypto=require('node:crypto'),{chromium}=require('playwright');
const root=path.resolve(__dirname,'../..'),output=process.argv[2];if(!output)throw Error('Usage: node tools/transport/smoke_carriage_c02.cjs OUTPUT_DIRECTORY');fs.mkdirSync(output,{recursive:true});
const asset=path.join(root,'renderers/web/transport/carriage-c02/carriage-c02.glb'),assetSha256=crypto.createHash('sha256').update(fs.readFileSync(asset)).digest('hex');assert.equal(assetSha256,'ddda1b89b330c889d69acaf55b79c4a114d193ff140e9e27c11cf74fc7f16eb6');
const server=http.createServer((request,response)=>{let file;try{const pathname=decodeURIComponent(new URL(request.url,'http://localhost').pathname);if(pathname==='/favicon.ico'){response.writeHead(204).end();return;}file=path.resolve(root,'.'+pathname);if(!file.startsWith(root+path.sep))throw Error('Outside source tree');}catch{response.writeHead(403).end();return;}fs.readFile(file,(error,bytes)=>{if(error){response.writeHead(404).end();return;}response.setHeader('Content-Type',file.endsWith('.html')?'text/html':file.endsWith('.js')?'text/javascript':file.endsWith('.json')?'application/json':'application/octet-stream');response.end(bytes);});});
(async()=>{let browser,page;const receipt={assetSha256,rows:[],errors:[]};try{
await new Promise(r=>server.listen(0,'127.0.0.1',r));browser=await chromium.launch({headless:true,executablePath:process.env.PW_EXECUTABLE,args:['--no-sandbox','--disable-dev-shm-usage']});
for(const mobile of[false,true]){const prior={};for(const environment of['baseline','studio']){
page=await browser.newPage({viewport:mobile?{width:390,height:780}:{width:1280,height:800},deviceScaleFactor:1,hasTouch:mobile,isMobile:mobile});
page.on('pageerror',e=>receipt.errors.push(e.message));page.on('requestfailed',r=>receipt.errors.push(r.url()));page.on('response',r=>{if(r.status()>=400)receipt.errors.push('HTTP'+r.status()+':'+r.url());});
await page.goto(`http://127.0.0.1:${server.address().port}/renderers/web/transport/carriage-c02/index.html?environment=${environment}`,{waitUntil:'networkidle'});await page.waitForFunction(()=>window.c02Ready,{timeout:20000});
for(const view of['rear','side']){const state=await page.evaluate(v=>window.setView(v),view);assert.equal(state.environment,environment);assert.equal(state.glError,0);assert.equal(state.sourceTriangles,11512);assert.equal(state.bytes,860200);assert.deepEqual(state.scale,[1,1,1]);assert(state.framing.entireSelectedBoundsInside);
if(prior[view]){assert.deepEqual(prior[view].camera,state.camera);assert.deepEqual(prior[view].framing,state.framing);assert.equal(prior[view].triangles,state.triangles);assert.equal(prior[view].drawCalls,state.drawCalls);}else prior[view]=state;
const file=`${mobile?'mobile':'desktop'}-${view}-${environment}.png`;await page.screenshot({path:path.join(output,file)});receipt.rows.push({file,mobile,...state});}
await page.close();page=null;}}
assert.deepEqual(receipt.errors,[]);receipt.passed=true;
}catch(e){receipt.passed=false;receipt.failure=String(e.stack||e);if(page)await page.screenshot({path:path.join(output,'failure.png')}).catch(()=>{});process.exitCode=1;
}finally{await browser?.close();if(server.listening)await new Promise(r=>server.close(r));receipt.browserClosed=true;receipt.serverClosed=true;fs.writeFileSync(path.join(output,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({passed:receipt.passed,captures:receipt.rows.length,errors:receipt.errors,failure:receipt.failure}));}})();
