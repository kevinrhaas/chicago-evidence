# C02 enclosed door study (T-2794)

Separate1904 development-only reconstructed roofed carriage; no historic-scene placement,1835 residents, ownership/subtype/period hardware or photographic acceptance. Coarse Pullman-location photograph reference is only a silhouette lead; no photo pixels/tracing/measured dimensions or unpublished plate content. All body/window/door/hinge/step dimensions are original GPL project-derived reconstruction.

Run from chicago/4d:

```sh
python3 tools/transport/generate_studies.py --only carriage-c02 --output-dir /tmp/c02-generated
python3 tools/transport/test_carriage_c02_door.py --asset /tmp/c02-generated/carriage-c02/carriage-c02.glb --receipt /tmp/c02-door-receipt.json
node tools/transport/smoke_carriage_c02.cjs /tmp/c02-browser
```

Generator uses only repo-relative defaults/data and standard library; checker adds existing NumPy. No source archive, sibling checkout, remote download, Blender or private workspace is needed. Browser uses existing vendoredThree and Playwright; optional PW_EXECUTABLE supports configured Chromium.

BaseGLB ddda1b89b330c889d69acaf55b79c4a114d193ff140e9e27c11cf74fc7f16eb6:860200B,11512tri,31batches,62nodes. Two current-interpreter runs exact; earlier flag-off enclosure757928B byte control preserved. Default orchestrator still rebuilds original wagon/carriage/horse/harness only; C02 explicit opt-in.

Portable checker labels source primitives into owned temporary output, decodes selected active scene actual GLB and matches11512triangles, then tests all moving-door surfaces against stationary cabin/roof/interiorbench/step/wheels/chassis at15 discrete angles0..70by5. All surface contacts retained/no exemptions; zero sampled SAT contacts. Five analytic controls bothorders pass. This does NOT prove continuous clearance, solid containment, forces, passenger passage, human/cloth/grip or real boarding. Interval bound32.619mm exceeds hinge gap; no continuum certificate. Door controls therefore expose only0/70endpoints without continuous-motion simulation.

Prior portable browser8actual views checked desktop/mobile,keyboard/touch,44pxcontrols,wholeasset/header framing,gl/errors and actual exportedbytes. Browser closed. Orphaned mesh negative rejected selected-scene mapping. Receipts are exact-source checkpoints, not proof of future integration before actual served hash equality. Root must rerun installed light checks, isolated viewer, normal derived tail/full gate and license checks on chosen final head. Isolated drawcounts are not phoneGPU/town capacity. No full unrelated bake or human rerun follows from this rigid specimen.

Paint and studio are optional SEPARATE source overlays. Base defaults stay unchanged. No photographic/period acceptance or T-2794 completion is asserted.
