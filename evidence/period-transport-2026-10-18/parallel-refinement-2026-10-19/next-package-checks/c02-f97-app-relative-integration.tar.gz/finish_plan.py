from pathlib import Path
import hashlib,json,difflib,subprocess,ast
P=Path(__file__).parent;R=Path('/workspace/chicago');B=P/'base/files';O=P/'optional/files';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();manifest=json.loads((P/'BASE-MANIFEST.json').read_text());M='chicago/4d/docs/RESEARCH/period-transport-2026-10-18/c02-enclosed-door/INTEGRATION-MANIFEST.json'
manifest['new_files']=sorted(str(f.relative_to(B))for f in B.rglob('*')if f.is_file()and not(R/f.relative_to(B)).exists());manifest['proposed_file_sha256']={str(f.relative_to(B)):sha(f)for f in B.rglob('*')if f.is_file()and str(f.relative_to(B))!=M};manifest['manifest_self_hash_excluded']=True
manifest['protected_source_sha256']={str(f.relative_to(R)):sha(f)for f in[(R/'chicago/4d/tools/transport'/f'generate_{n}.py')for n in['wagon','carriage','horse','harness']]+[(R/'chicago/4d/data/transport/studies'/f'{n}.json')for n in['wagon','carriage','horse','harness']]}
for f in[P/'BASE-MANIFEST.json',B/M]:f.write_text(json.dumps(manifest,indent=2)+'\n')
optional={str(f.relative_to(O)):sha(f)for f in O.rglob('*')if f.is_file()};(P/'OPTIONAL-MANIFEST.json').write_text(json.dumps(optional,indent=2)+'\n');diff=[]
for rel in optional:
 if(B/rel).exists():
  diff.extend(difflib.unified_diff((B/rel).read_text().splitlines(True),(O/rel).read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(P/'optional/existing-files.patch').write_text(''.join(diff))
checks=[]
for rel in['chicago/4d/docs/STATUS.md','chicago/4d/docs/ROADMAP.md','chicago/4d/docs/LIBERTIES.md']:
 original=(R/rel).read_bytes();assert(B/rel).read_bytes().startswith(original);checks.append({'path':rel,'original_prefix_bytes_preserved':True,'preimage_sha256':sha(R/rel),'existing_bytes':len(original)})
for f in list(B.rglob('*.py'))+list(O.rglob('*.py')):ast.parse(f.read_bytes())
for f in list(B.rglob('*.js'))+list(B.rglob('*.cjs'))+list(O.rglob('*.js'))+list(O.rglob('*.cjs')):
 if 'vendor'in f.parts:continue
 subprocess.run(['node','--check',str(f)],check=True,capture_output=True)
private=[]
for root in[B,O]:
 for f in root.rglob('*'):
  if f.is_file()and('tools'in f.parts or 'renderers'in f.parts)and f.suffix in['.py','.js','.cjs','.html']:
   for bad in[b'/workspace/shared',b'/workspace/chicago',b'archive-download',b'source-package.tar.gz']:
    if bad in f.read_bytes():private.append(str(f))
assert not private,private
report={'proposal_against':manifest['base_commit'],'app_unchanged':subprocess.check_output(['git','-C',str(R),'status','--porcelain']).decode()=='','append_byte_controls':checks,'new_base_files':len(manifest['new_files']),'modified_base_files':len(manifest['modified_files']),'optional_files':len(optional),'runtime_private_or_archive_prerequisites':private,'source_syntax_and_optional_flags_cli':'PASS','actual_generation_browser_not_repeated_here':'Earlier immutable a185/8ce/23f021 exact-input proofs carried; root validates installed chosen head.','roadmap_existing_nonUTF8_byte':{'offset':425651,'hex':'fc','preserved':True}}
(P/'LIGHT-PORTABILITY-RECEIPT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
