# SPDX-License-Identifier: CC0-1.0
"""Original material-only partition: keep every original attribute byte unchanged."""
import json,struct,hashlib
import numpy as np

def apply(file,manifest_file,surface_file):
 raw=file.read_bytes();n=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+n]);blob=bytearray(raw[28+n:]);original=bytes(blob)
 def read(i):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];nc={'SCALAR':1,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];return np.frombuffer(blob,dtype={5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']],count=a['count']*nc,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).copy().reshape(-1,nc)
 def indices(values):
  while len(blob)%4:blob.append(0)
  vals=np.asarray(values,dtype='<u4').ravel();vi=len(d['bufferViews']);d['bufferViews'].append({'buffer':0,'byteOffset':len(blob),'byteLength':vals.nbytes,'target':34963});blob.extend(vals.tobytes());ai=len(d['accessors']);d['accessors'].append({'bufferView':vi,'componentType':5125,'count':len(vals),'type':'SCALAR','min':[int(vals.min())],'max':[int(vals.max())]});return ai
 s=json.loads(surface_file.read_text());lipfaces=[f for f,t in zip(s['faces'],s['tags'])if t in ['lip_l','lip_r']];ids=sorted({i for f in lipfaces for i in f});points=(np.asarray(s['positions'],dtype='<f4').astype(float)+[0,1.88,.8]).astype('<f4').astype(float)[ids];lookup={tuple(sorted(f))for f in lipfaces};moved=0
 coat=next(i for i,m in enumerate(d['materials'])if m['name']=='equine_coat')
 for mesh in d['meshes']:
  new=[]
  for p in mesh['primitives']:
   pos=read(p['attributes']['POSITION']).astype(float);face=read(p['indices']).ravel().reshape(-1,3);selected=[]
   for k,t in enumerate(face):
    mapped=[]
    for v in pos[t]:
     dd=np.linalg.norm(points-v,axis=1);j=int(dd.argmin())
     if dd[j]>2e-7:break
     mapped.append(ids[j])
    if len(mapped)==3 and tuple(sorted(mapped))in lookup:selected.append(k)
   if not selected:new.append(p);continue
   assert p['material']!=coat
   mask=np.ones(len(face),bool);mask[selected]=False;old=dict(p);old['indices']=indices(face[mask]);lip=dict(p);lip['indices']=indices(face[selected]);lip['material']=coat;lip['extras']={'component':'continuous_closed_lip_groove','change':'coat material only; original attributes retained'};new.extend([old,lip]);moved+=len(selected)
  mesh['primitives']=new
 assert moved==64 and bytes(blob[:len(original)])==original
 d['buffers'][0]['byteLength']=len(blob);jb=json.dumps(d,separators=(',',':')).encode();jb+=b' '*((-len(jb))%4);blob+=b'\0'*((-len(blob))%4);encoded=struct.pack('<III',0x46546c67,2,28+len(jb)+len(blob))+struct.pack('<II',len(jb),0x4e4f534a)+jb+struct.pack('<II',len(blob),0x004e4942)+blob;file.write_bytes(encoded)
 m=json.loads(manifest_file.read_text());m['bytes']=len(encoded);m['mesh_draws']=sum(len(q['primitives'])for q in d['meshes']);m['closed_lip_material_followup']={'status':'UNACCEPTED material-only followup; head-ear and bridle failures retained','triangles_reassigned':moved,'old_glb_sha256':hashlib.sha256(raw).hexdigest(),'glb_sha256':hashlib.sha256(encoded).hexdigest(),'original_binary_attribute_prefix_exact':True,'extra_draw_call':1};manifest_file.write_text(json.dumps(m,indent=2)+'\n')
