# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import json,struct,hashlib,collections
import numpy as np
P=Path(__file__).parent;OLD=Path('/workspace/shared/horse-head-closed-groove-next')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):
 b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];return json.loads(b[20:20+n]),b[28+n:]
def decode(d,b,i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];nc={'SCALAR':1,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];dt={5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']];return np.frombuffer(b,dtype=dt,count=a['count']*nc,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,nc)
def triangles(d,b):
 result=collections.Counter();materials=collections.defaultdict(collections.Counter)
 for mesh in d['meshes']:
  for p in mesh['primitives']:
   keys=sorted(p['attributes']);attrs=[decode(d,b,p['attributes'][k])for k in keys];vertex=[b''.join(a[i].tobytes()for a in attrs)for i in range(len(attrs[0]))];idx=decode(d,b,p['indices']).ravel().reshape(-1,3)
   for f in idx:
    chunks=[vertex[i]for i in f];key=min(b''.join(chunks[k:]+chunks[:k])for k in range(3));result[key]+=1;materials[p['material']][key]+=1
 return result,materials
oldfile=OLD/'trial1/equine_light_harness_skinned_prototype_01.glb';newfile=P/'trial1'/oldfile.name;a,ab=load(oldfile);b,bb=load(newfile);assert bb[:len(ab)]==ab
for k in ['nodes','skins','animations','materials','scenes','scene','asset']:assert a.get(k)==b.get(k),k
assert b['accessors'][:len(a['accessors'])]==a['accessors'];assert b['bufferViews'][:len(a['bufferViews'])]==a['bufferViews']
x,xm=triangles(a,ab);y,ym=triangles(b,bb);assert x==y;coat=next(i for i,m in enumerate(a['materials'])if m['name']=='equine_coat');changes={}
for mat in set(xm)|set(ym):
 added=ym[mat]-xm[mat];removed=xm[mat]-ym[mat]
 if added or removed:changes[mat]={'added_triangles':sum(added.values()),'removed_triangles':sum(removed.values())}
assert len(changes)==2 and changes[coat]=={'added_triangles':64,'removed_triangles':0};assert sum(r['removed_triangles']for r in changes.values())==64
for q in(P/'trial1').iterdir():
 if q.is_file():assert q.read_bytes()==(P/'trial2'/q.name).read_bytes()
r={'pass':True,'old_glb_sha256':sha(oldfile),'new_glb_sha256':sha(newfile),'old_binary_prefix_exact':True,'all_original_accessors_bufferViews_exact':True,'nodes_skin_bones_IBMs_animation_material_values_sockets_exact':True,'all_decoded_oriented_triangle_attribute_multisets_exact':True,'all_triangle_attribute_keys':['POSITION','NORMAL','JOINTS_0','WEIGHTS_0'],'triangles':sum(x.values()),'only_material_assignment_changes':changes,'two_exact_builds':True,'draws_before':sum(len(m['primitives'])for m in a['meshes']),'draws_after':sum(len(m['primitives'])for m in b['meshes']),'scope':'Fresh decoded GLB comparison; no geometry or animation change. Primitive index partition only adds1draw. Prior geometric self/gear failures remain and are not rerun or waived.'};(P/'material-only-proof.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
