# SPDX-License-Identifier: CC0-1.0
"""Source-ID topology audit; never merge unknown vertices by a broad tolerance."""
from pathlib import Path
import argparse,json,math
from planar import need

def topology(vertices,faces,portal):
 edges={};active=set()
 for fi,t in enumerate(faces):
  need(len(t)==3 and len(set(t))==3,'Duplicate triangle ID');active.update(t);a,b,c=[vertices[i]for i in t];u=[b[k]-a[k]for k in range(3)];v=[c[k]-a[k]for k in range(3)];cross=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];need(all(math.isfinite(q)for q in a+b+c)and sum(q*q for q in cross)>4e-24,'Nonfinite/zero area')
  for a,b in zip(t,t[1:]+t[:1]):edges.setdefault(tuple(sorted((a,b))),[]).append((a,b))
 allowed={tuple(sorted((a,b)))for a,b in zip(portal,portal[1:]+portal[:1])};actual=set()
 for key,use in edges.items():
  if len(use)==1:actual.add(key)
  else:need(len(use)==2 and use[0]==use[1][::-1],'Nonmanifold/inconsistent edge ownership')
 need(actual==allowed,'Unexpected hole/severed join');adj={i:set()for i in active}
 for a,b in edges:adj[a].add(b);adj[b].add(a)
 seen=set();pending=[next(iter(active))]
 while pending:
  i=pending.pop()
  if i in seen:continue
  seen.add(i);pending.extend(adj[i]-seen)
 need(seen==active,'Disconnected ear/overlay');need(len(active)-len(edges)+len(faces)==1,'Wrong head+ear Euler characteristic')
 return{'components':1,'Euler':1,'boundary_edges':len(actual),'vertices_active':len(active),'triangles':len(faces)}

def assemble(edit,head,ears):
 vertices={k:r['position']for k,r in edit['vertices'].items()};faces=[];owners=[];retire=set(edit['retire_source_head_faces'])
 for i,t in enumerate(head['faces']):
  if i not in retire:faces.append(['h:'+str(k)for k in t]);owners.append({'kind':'retained_head','source_face':i})
 faces.extend(edit['new_faces']);owners.extend(edit['new_face_owners'])
 ring={}
 for side in[-1,1]:
  for k,record in edit['vertices'].items():
   if record['kind']=='existing_ear_root_ring'and record['side']==side:ring[(side,tuple(record['position']))]=k
 for e in ears:
  side=-1 if e['name'].endswith('_-1')else 1;cohort=next(q for r in edit['ear_retirement_and_retained_boundary']if r['side']==side for q in r['component_face_tables']if q['source_component']==e['name']);mapping={}
  for i,p in enumerate(e['positions_local']):
   key=ring.get((side,tuple(p)))
   if key is None:key='ear:'+str(side)+':'+':'.join(float(x).hex()for x in p)
   if key in vertices:need(vertices[key]==p,'Source seam positions differ')
   else:vertices[key]=p
   mapping[i]=key
  for i in cohort['remaining_leaf_faces_exact']:faces.append([mapping[k]for k in e['faces'][i]]);owners.append({'kind':'retained_ear_leaf','source_component':e['name'],'source_face':i})
 return vertices,faces,owners

def main():
 ap=argparse.ArgumentParser();ap.add_argument('candidate',type=Path);ap.add_argument('--input-dir',type=Path,required=True);args=ap.parse_args();e=json.loads(args.candidate.read_text());h=json.loads((args.input_dir/'head-source-surface.json').read_text());ears=json.loads((args.input_dir/'ear-source-surfaces.json').read_text());v,f,o=assemble(e,h,ears);r=topology(v,f,['h:'+str(i)for i in h['portal']]);print(json.dumps(r));args.candidate.with_name('source-topology.json').write_text(json.dumps(r,indent=2)+'\n')
if __name__=='__main__':main()
