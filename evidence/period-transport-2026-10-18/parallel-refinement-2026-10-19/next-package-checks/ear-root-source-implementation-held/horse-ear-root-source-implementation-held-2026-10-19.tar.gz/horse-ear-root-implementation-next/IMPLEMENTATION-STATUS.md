# Ear-root implementation checkpoint — actual generation HELD

This outside-only parcel authors the approved22lower/18upper root bridge and exact6skull-face complement exception. No horse/source candidate mesh or GLB was generated, no geometry files were edited and no browser/SAT sweep ran. All app and previous archives remain untouched.

Implemented source code

- generate_source.py pins ACTUAL090GLB/head/ear/producer bytes and exact reviewed recipe/cohort bytes. Without the explicit --generate-reviewed-candidate switch it runs ONLY lightweight input/interval contract checks and exits. It refuses an existing output directory.
- Each source-face interval checks nonzero same-sign denominator at both ends and midpoint,0<rho<1, reconstructed source-plane membership and barycentric containment. Since denominator is affine on a leafedge interval, fixed endpoint sign bounds the whole denominator; numerator is fixed. Every shared source edge must have exactly2owners, both among the6approved faces. No extra face exception.
- The candidate source builder authors constrained planar graphs for each exact source triangle: every cut knot subdivides the old shared source edge on BOTH owners; each cut segment is assigned to its actual source-face interval. Original vertices remain. Every bounded graph region is triangulated, classified by the reviewed global perspective chart and retained only outside the root cut. Per-face total area/nonoverlap/containment is checked. All6faces must be partially consumed, never erased wholesale.
- Each radial bridge patch uses one actual original leafedge plane. Its lower chain includes every source-edge knot; its upper edge is retained unchanged. Patch triangulation must stay planar, cover the actual polygon exactly once, have no reversed triangles, no overlapping interiors and no escaped area. This is not a generic22/18zipper.
- audit_source.py assembles the complete candidate head+both retained leaf components using declared SOURCE ownership and exact source seam positions, not a broad distance weld. It requires one connected orientable disk, Euler1, only24neckportal boundary edges and no duplicate/degenerate/unpaired/incorrectly oriented edges. It is ready to inspect a generated source candidate, but has NOT been run on one.
- planar.py provides original constrained halfedge face walks, ear clipping retaining collinear boundary knots, independent clipping coverage and topology helpers.

Light executed scope

All scripts compile. Eight generic planar/topology controls pass under normal and optimized Python, including retained collinear knot, both-sided shared-edge partition, overlap, missing coverage, escaped triangle, reversed/duplicate triangles and Tjunction. Frozen actual source interval/input checks pass; LIGHT-CHECK.json records actual denominator/rho/source-barycentric values. No actual candidate topology result or generated mesh pass is claimed.

Important remaining implementation/qualification

The GLB exporter is NOT yet implemented. First, when root releases generation, run ONLY the source builder into a NEW output directory and audit its real topology. Preserve any source planar/topology failure before repair. Do not call the current parcel an export-ready horse.

A subsequent bounded exporter must consume actual090 decoded POS/NORMAL/JOINTS/WEIGHTS, preserve all48protected attribute vectors and all old vertices outside the explicitly declared cut-ring normal halo, replace ONLY the6source-face complements and176ear-root faces, and bind new skull-cut weights by actual source barycentrics. Existing upper18ring weights must remain exact; bridge weights interpolate actual root/head endpoints and normalize. Every material duplicate at shared seams must have identical positions/weights/normals. Only cut-ring normals may be changed for continuity; protected48normals cannot be recomputed. Export attribute/index remapping must be explicit, with new source/producer/authority pins. Original cheek/muzzle/closed-groove/color/rig/IBMs/sockets/clips/lowerlimbs/soles/body/gear remain exact. Triangle count, extra buffers/primitives and draw changes must be reported, not hidden.

After an actual candidate exists: two exact builds; all-head+ear and newbridge-versus-adjacent-neck/body strict self/SAT at63decoded poses; actual boundary/LBS equality; normal/area/topology controls; unchanged078FIRSTgear fit before any reroute; meaningful old positive/negative controls; Khronos validation. Existing832sampled inherited attachment crossings and258idle bridle crossings remain red until a new actual result. Mathematical source-plane coverage cannot waive animated or emitted-float32 intersections. No anatomy/period/breed/photographic acceptance follows this source authoring.

Commands (NOT executed on actual candidate)

    python generate_source.py --input-dir <frozen090-trial1> --output-dir <NEW-output> --generate-reviewed-candidate
    python audit_source.py <NEW-output>/candidate-source-edit.json --input-dir <frozen090-trial1>

Hold generation until root explicitly releases the critical town diagnostic window.
