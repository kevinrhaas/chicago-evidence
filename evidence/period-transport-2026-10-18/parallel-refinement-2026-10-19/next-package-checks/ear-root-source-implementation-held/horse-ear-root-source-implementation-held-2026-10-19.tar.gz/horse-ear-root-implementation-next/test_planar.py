# SPDX-License-Identifier: GPL-3.0-or-later
import unittest,copy
from planar import triangulate,bounded_faces,coverage,need
from audit_source import topology
class LightFixtures(unittest.TestCase):
 def test_constrained_collinear_boundary(self):
  p={0:[0,0],1:[.5,0],2:[1,0],3:[1,1],4:[0,1]};t=triangulate([0,1,2,3,4],p);self.assertEqual(len(t),3);self.assertEqual({k for f in t for k in f},set(p));coverage(t,p,[0,1,2,3,4])
 def test_shared_edge_partition_both_faces(self):
  p={0:[0,0],1:[1,0],2:[1,1],3:[0,1],4:[.5,.5]};edges={(0,1),(1,2),(2,3),(0,3),(0,4),(2,4)};loops=bounded_faces(p,edges);self.assertEqual(len(loops),2);self.assertTrue(all(4 in q for q in loops))
 def test_overlap_rejected(self):
  p={0:[0,0],1:[1,0],2:[1,1],3:[0,1]}
  with self.assertRaises(ValueError):coverage([[0,1,2],[0,1,2]],p,[0,1,2,3])
 def test_incomplete_coverage_rejected(self):
  p={0:[0,0],1:[1,0],2:[1,1],3:[0,1]}
  with self.assertRaises(ValueError):coverage([[0,1,2]],p,[0,1,2,3])
 def test_outside_area_rejected(self):
  p={0:[0,0],1:[1,0],2:[1,1],3:[0,1],4:[2,1]}
  with self.assertRaises(ValueError):coverage([[0,1,4],[0,4,3]],p,[0,1,2,3])
 def test_topology_disk_and_corrupted_face(self):
  v={0:[0,0,0],1:[1,0,0],2:[1,1,0],3:[0,1,0]};f=[[0,1,2],[0,2,3]];self.assertEqual(topology(v,f,[0,1,2,3])['Euler'],1)
  with self.assertRaises(ValueError):topology(v,[f[0],f[1][::-1]],[0,1,2,3])
 def test_duplicate_triangle_rejected(self):
  v={0:[0,0,0],1:[1,0,0],2:[1,1,0],3:[0,1,0]};f=[[0,1,2],[0,2,3],[0,1,2]]
  with self.assertRaises(ValueError):topology(v,f,[0,1,2,3])
 def test_actual_tjunction_pattern_rejected(self):
  v={0:[0,0,0],1:[1,0,0],2:[1,1,0],3:[0,1,0],4:[.5,.5,0]};f=[[0,1,4],[1,2,4],[0,2,3]]
  with self.assertRaises(ValueError):topology(v,f,[0,1,2,3])
if __name__=='__main__':unittest.main()
