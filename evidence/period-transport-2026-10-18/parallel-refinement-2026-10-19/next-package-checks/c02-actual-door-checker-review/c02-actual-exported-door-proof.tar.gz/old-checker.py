# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import numpy as np,json,struct,runpy,sys,math,collections,hashlib,time
ROOT=Path(__file__).resolve().parents[2]
import argparse,tempfile,contextlib,io
cli=argparse.ArgumentParser(description='C02 discrete actual exported triangle mechanics; no continuous or occupant acceptance')
cli.add_argument('--parameters',type=Path,default=ROOT/'data/transport/studies/carriage-c02.json')
cli.add_argument('--generator',type=Path,default=Path(__file__).with_name('generate_carriage_c02.py'))
cli.add_argument('--asset',type=Path,default=ROOT/'renderers/web/transport/carriage-c02/carriage-c02.glb')
cli.add_argument('--receipt',type=Path)
args=cli.parse_args();temporary=tempfile.TemporaryDirectory(prefix='c02-door-check-');P=Path(temporary.name)
# Explicit source/parameter paths; all generated files stay in owned temporary output.
original_argv=sys.argv[:]
try:
 sys.argv=[str(args.generator),'--parameters',str(args.parameters),'--output-dir',str(P)]
 with contextlib.redirect_stdout(io.StringIO()):e=runpy.run_path(str(args.generator))
finally:sys.argv=original_argv
ns=e['oldnodes'];parents={c:i for i,n in enumerate(ns) for c in n.get('children',[])}
def world(i):
 m=e['local'](ns[i])
 while i in parents:i=parents[i];m=e['local'](ns[i])@m
 return m
parts=[]
for i,n in enumerate(ns):
 if 'mesh' not in n:continue
 j=i
 while j in parents and ns[j]['name']!='vehicle_door_left':j=parents[j]
 moving=ns[j]['name']=='vehicle_door_left'
 for q in e['oldmeshes'][n['mesh']]['primitives']:
  a=e['oldaccess'][q['attributes']['POSITION']];v=e['oldviews'][a['bufferView']];xyz=np.array(struct.unpack_from('<%sf'%(a['count']*3),e['oldbinary'],v['byteOffset'])).reshape(-1,3);m=world(i);xyz=xyz@m[:3,:3].T+m[:3,3]
  parts.append({'name':n['name'],'node':i,'moving':moving,'triangles':xyz.reshape(-1,3,3)})
# Verify decoded actual final GLB triangle soup against labeled source primitives.
raw=args.asset.read_bytes();n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);binary=raw[28+n:];gp={c:i for i,n in enumerate(g['nodes']) for c in n.get('children',[])}
assert g['extras']['units']=='m' and g['extras']['up_axis']=='+Y' and g['extras']['forward_axis']=='+Z'
assert g['extras']['parameters']==e['params'],'Asset parameter metadata stale'
assert g['extras']['boarding_enabled'] is False
assert g['extras']['scene_eligibility']==e['sidecar']['scene_eligibility'] and '1904' in g['extras']['scene_eligibility'] and 'not 1835' in g['extras']['scene_eligibility']
assert sum(n.get('name')=='vehicle_door_left' for n in g['nodes'])==1,'One actual door pivot required'
def actual_local(node):
 if 'matrix' in node:return np.array(node['matrix']).reshape(4,4,order='F')
 m=e['local']({**node,'translation':node.get('translation',[0,0,0])});m[:3,:3]=m[:3,:3]@np.diag(node.get('scale',[1,1,1]));return m
def gworld(i):
 m=actual_local(g['nodes'][i])
 while i in gp:i=gp[i];m=actual_local(g['nodes'][i])@m
 return m
# Only render-active scene nodes may supply geometry; orphan meshes cannot satisfy mapping.
active=set();pending=list(g['scenes'][g.get('scene',0)]['nodes'])
while pending:
 i=pending.pop()
 if i in active:continue
 active.add(i);pending.extend(g['nodes'][i].get('children',[]))
actual=[]
for i,node in enumerate(g['nodes']):
 if i not in active or 'mesh' not in node:continue
 m=gworld(i)
 for q in g['meshes'][node['mesh']]['primitives']:
  assert q.get('mode',4)==4 and 'indices' not in q,'Expected original unindexed triangle export'
  a=g['accessors'][q['attributes']['POSITION']];v=g['bufferViews'][a['bufferView']];assert a['componentType']==5126 and a['type']=='VEC3' and v.get('byteStride',12)==12;xyz=np.array(struct.unpack_from('<%sf'%(a['count']*3),binary,v.get('byteOffset',0)+a.get('byteOffset',0))).reshape(-1,3);actual.extend((xyz@m[:3,:3].T+m[:3,3]).reshape(-1,3,3))
def key(tri):return tuple(sorted(tuple(round(float(v),5) for v in p) for p in tri))
lookup=collections.defaultdict(list)
for tri in actual:lookup[key(tri)].append(tri)
for p in parts:
 decoded=[]
 for tri in p['triangles']:
  choices=lookup[key(tri)];assert choices,(p['name'],tri.tolist());d=choices.pop();assert max(min(np.linalg.norm(d-v,axis=1)) for v in tri)<1e-6;decoded.append(d)
 p['triangles']=np.array(decoded)
assert sum(len(v) for v in lookup.values())==0
fixed=[p for p in parts if not p['moving']];moving=[p for p in parts if p['moving']];ft=np.concatenate([p['triangles'] for p in fixed]);labels=[(p['name'],p['node'],i) for p in fixed for i in range(len(p['triangles']))];flo=ft.min(1);fhi=ft.max(1)
# Triangle SAT including coplanar in-plane axes. AABB is only broad phase.
def intersects(a,b,tol=1e-8):
 ea=np.roll(a,-1,axis=0)-a;eb=np.roll(b,-1,axis=0)-b;na=np.cross(ea[0],ea[1]);nb=np.cross(eb[0],eb[1]);axes=[na,nb]+[np.cross(x,y) for x in ea for y in eb]+[np.cross(na,x) for x in ea]+[np.cross(nb,x) for x in eb]
 for axis in axes:
  length=np.linalg.norm(axis)
  if length<1e-14:continue
  axis=axis/length;pa=a@axis;pb=b@axis
  if pa.max()<pb.min()-tol or pb.max()<pa.min()-tol:return False
 return True
def predicate_controls():
 a=np.array([[0.,0,0],[1,0,0],[0,1,0]])
 cases=[(np.array([[.1,.1,0],[.4,.1,0],[.1,.4,0]]),True),(np.array([[.8,.8,0],[1,.8,0],[.8,1,0]]),False),(np.array([[0,0,.001],[1,0,.001],[0,1,.001]]),False),(np.array([[.2,.2,-1],[.2,.2,1],[.4,.2,0]]),True),(np.array([[0,0,0],[1,0,0],[0,-1,0]]),True)]
 for b,expected in cases:assert intersects(a,b)==expected and intersects(b,a)==expected,'Triangle predicate control failed'
predicate_controls()
rows=[];door_nodes=[n for n in ns if n['name']=='vehicle_door_left'];assert len(door_nodes)==1;assert np.allclose(door_nodes[0]['translation'],[.655,.82,-.28],atol=1e-12)
pivot=np.array(door_nodes[0]['translation']);began=time.time()
for degrees in range(0,71,5):
 t=math.radians(degrees);R=np.array([[math.cos(t),0,math.sin(t)],[0,1,0],[-math.sin(t),0,math.cos(t)]]);hits=collections.Counter();samples=[];candidates=0
 for p in moving:
  triangles=(p['triangles']-pivot)@R.T+pivot
  for j,a in enumerate(triangles):
   ix=np.flatnonzero(np.all(fhi>=a.min(0)-1e-8,axis=1)&np.all(flo<=a.max(0)+1e-8,axis=1));candidates+=len(ix)
   for k in ix:
    if intersects(a,ft[k]):
     name,node,tri=labels[k];hits[(p['name'],p['node'],name,node)]+=1
     if len(samples)<12:samples.append({'moving':[p['name'],p['node'],j],'fixed':[name,node,tri]})
 rows.append({'angle_deg':degrees,'broadphase_pairs':candidates,'triangle_intersections_including_contact':sum(hits.values()),'part_pairs':[{'moving':a,'moving_node':b,'fixed':c,'fixed_node':d,'triangle_pairs':count} for (a,b,c,d),count in hits.items()],'examples':samples});print(degrees,sum(hits.values()),flush=True)
report={'status':'Discrete actual GLB triangle surface SAT; all intersections retained, no whitelist','angles_deg':list(range(0,71,5)),'scope':'15 discrete rigid door angles only, triangle surfaces including contact; no continuous clearance or enclosed solid containment proof','actual_final_triangles_matched_to_source_labels':len(actual),'input_sha256':hashlib.sha256(raw).hexdigest(),'generator_sha256':hashlib.sha256(args.generator.read_bytes()).hexdigest(),'parameters_sha256':hashlib.sha256(args.parameters.read_bytes()).hexdigest(),'elapsed_s':time.time()-began,'rows':rows,'intersection_tolerance_m':1e-8,'all_contacts_preserved':True}
if args.receipt:args.receipt.write_text(json.dumps(report,indent=2)+'\n')
assert len(actual)==11512,'Unexpected C02 final geometry triangle count'
assert len(moving)>0 and len(fixed)>0,'Missing moving or fixed geometry'
assert all(r['triangle_intersections_including_contact']==0 for r in rows),'Actual discrete door surface interference; receipt preserved'
print('PASS11512actualtriangles,15discreteangles,0contacts/noexemptions; no continuous/inside/occupant acceptance')
temporary.cleanup()
