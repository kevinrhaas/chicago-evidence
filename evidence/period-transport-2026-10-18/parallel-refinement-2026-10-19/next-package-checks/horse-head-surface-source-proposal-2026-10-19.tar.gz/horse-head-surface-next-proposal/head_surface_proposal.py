# SPDX-License-Identifier: CC0-1.0
"""UNEXECUTED source core for ONE continuous cranium→muzzle skin surface.
Not integrated: orbital/nostril topology, skin weighting and color passthrough pending.
"""
import math

def build_contiguous_surface(recipe):
 vertices=[];faces=[];rings=[]
 # Exact existing24vertex head/neck portal and blend band; no global scaling.
 for x,y,z,rx,ry,rz in recipe['protected_portal_rings']:
  ids=[]
  for k in range(24):
   t=k*2*math.pi/24;ids.append(len(vertices));vertices.append([x+rx*math.cos(t),y+ry*math.sin(t),z+rz*math.sin(t)])
  rings.append(ids)
 for station in recipe['stations']:
  ids=[];cy=(station['top_y']+station['bottom_y'])/2;radius=(station['top_y']-station['bottom_y'])/2
  for k in range(48):
   t=k*2*math.pi/48;sn=math.sin(t);cs=math.cos(t)
   # Gentle broad lower-lateral cheek, not an added cheek sphere/muscle groove.
   cheek=station['cheek_lateral_bulge']*max(0,-sn)*abs(cs)
   ids.append(len(vertices));vertices.append([station['half_width']*cs*(1+cheek),cy+radius*sn,station['z']])
  rings.append(ids)
 for previous,current in zip(rings,rings[1:]):
  if len(previous)==len(current):
   for i in range(len(previous)):
    j=(i+1)%len(previous);faces.extend([(previous[i],previous[j],current[j]),(previous[i],current[j],current[i])])
  elif len(previous)==24 and len(current)==48:
   for i in range(24):
    j=(i+1)%24;a=2*i;b=(a+1)%48;c=(a+2)%48
    faces.extend([(previous[i],previous[j],current[c]),(previous[i],current[c],current[b]),(previous[i],current[b],current[a])])
  else:raise ValueError('Unsupported ring interface')
 # Rear is intentionally OPEN at exact sharedneck portal. Front closes only here.
 center=[sum(vertices[i][k]for i in rings[-1])/48 for k in range(3)];tip=len(vertices);vertices.append(center)
 for i in range(48):faces.append((tip,rings[-1][i],rings[-1][(i+1)%48]))
 return {'positions_head_local_m':vertices,'triangles':faces,'portal':rings[0],'head_blend_band':rings[1],'station_rings':rings[2:],'status':'UNEXECUTED rawcore; must validate outward winding/areas and cut orbital/nostril patches before integration'}

def almond_aperture(side,center_x,eye,segments=16):
 """UNEXECUTED palpebral boundary proposal, not a torus or floating eyeball."""
 points=[]
 for k in range(segments):
  t=2*math.pi*k/segments;s=math.sin(t);h=eye['upper_height']if s>=0 else eye['lower_height'];y=eye['center_y']+h*math.copysign(abs(s)**1.35,s);z=eye['center_z']+eye['half_length_z']*math.cos(t);points.append([side*center_x,y,z])
 return points

def bridge_patch(outer_boundary,inner_boundary):
 """Requires actual ordered shared skull indices; no unverified loose overlay.
 Stub rejects unimplemented boundary extraction rather than emitting a faux socket.
 """
 raise NotImplementedError('Must cut an actual orbital face patch and prove ordered shared boundary before creating eyelids/cornea')
