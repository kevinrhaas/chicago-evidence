# C02 portable next-PR proposal — not installed

Only files under files/ are proposed application changes. Do not overwrite other transport assets. The immutable reviewed baseline archive is preserved byte-for-byte (SHA256 fb10f0e2f9dd624831b0bf24ef9e533832dc9c847fd343721034e3703de2743a). C02 geometry is unchanged: final GLB ddda1b89b330c889d69acaf55b79c4a114d193ff140e9e27c11cf74fc7f16eb6, 860200 bytes, 11512 triangles.

Generator defaults derive the application root from __file__; explicit --parameters/--output-dir remain supported. Orchestrator defaults stay wagon/carriage/horse/harness; C02 is explicit --only carriage-c02. A real initial proposal error added C02 to defaults; the preserved failure receipt documents it and the corrected old/new default output hash comparison passes. Flag-off equals the earlier repaired enclosure output. Exact-byte tests are qualified on Python3.12.14, not a cross-minor floating-reduction guarantee.

Portable selected-active-scene checker generates source labels into an owned temporary directory, maps all11512 actual exported triangles, and performs SAT at15 discrete angles 0..70 degrees (5-degree spacing), with no contact exclusions. All sampled intersections are zero. This does NOT certify continuous swept clearance, solid containment, passengers, cloth, forces or production boarding. Checker creates only its explicit receipt, not sibling source/export paths. Requires existing NumPy; generator is standard-library Python.

From chicago/4d: python tools/transport/generate_studies.py --only carriage-c02 --output-dir /tmp/c02-export ; python tools/transport/test_carriage_c02_door.py --receipt /tmp/c02-receipt.json . Browser source probe: node tools/transport/smoke_carriage_c02.cjs /tmp/c02-browser-receipts (existing Playwright; optional PW_EXECUTABLE). Probe owns an ephemeral loopback server and closes browser/server.

NEW PORTABLE VIEWER BROWSER SMOKE IS PENDING: no browser was run for this adaptation. Prior immutable baseline screenshots are historical receipts, not new viewer validation. Proposed viewer uses application-relative vendor imports, accessible closed/open endpoints and desktop/mobile union-bound framing.

Eligibility: 1904 development reconstruction only; no1835 occupants. Source photo supports only coarse roofed silhouette. Door/window/hardware/dimensions are reconstructed; no ownership/subtype or photographic match asserted. Generator and derived original carriage geometry retain GPL-3.0-or-later (not horse CC0); global license ledger and liberties append remain root review/integration work. No photo pixels included. Existing app vendor and generator dependencies are referenced, not copied into proposed files.

All diagnostic logs and negative-input receipts are included. run_diagnostics.py is research replay documentation and contains original outside-workspace comparison paths; installed checker/generator/viewer have no such dependencies. No app/ticket/CI files were edited.
