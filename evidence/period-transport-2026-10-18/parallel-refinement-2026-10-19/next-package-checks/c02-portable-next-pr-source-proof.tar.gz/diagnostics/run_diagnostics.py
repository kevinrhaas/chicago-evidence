from pathlib import Path
import subprocess,sys,tempfile,json,hashlib,shutil
P=Path(__file__).parent;F=P/'files/chicago/4d';I=P/'immutable-source';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();rows=[]
def run(name,argv,expect=0):
 result=subprocess.run(argv,cwd='/tmp',capture_output=True,text=True);(P/(name+'.log')).write_text(result.stdout+result.stderr);assert (result.returncode==0)==(expect==0),(name,result.returncode,result.stderr);rows.append({'name':name,'returncode':result.returncode});return result
with tempfile.TemporaryDirectory(prefix='c02-portable-diagnostics-')as temp:
 T=Path(temp)
 for name in ['first','repeat']:
  run(name,[sys.executable,str(F/'tools/transport/generate_carriage_c02.py'),'--output-dir',str(T/name)])
  assert (T/name/'carriage-c02.glb').read_bytes()==(I/'export/carriage-c02.glb').read_bytes()
 assert (T/'first/carriage-c02.glb').read_bytes()==(T/'repeat/carriage-c02.glb').read_bytes()
 run('flag-off',[sys.executable,str(F/'tools/transport/generate_carriage_c02.py'),'--parameters',str(F/'tools/transport/fixtures/carriage-c02-flag-off.json'),'--output-dir',str(T/'off')])
 assert (T/'off/carriage-c02.glb').read_bytes()==Path('/workspace/shared/carriage-c02-enclosure-repair/export/carriage-c02.glb').read_bytes()
 run('open',[sys.executable,str(F/'tools/transport/generate_carriage_c02.py'),'--door-angle-deg','70','--output-dir',str(P/'generated-open')])
 for name,updates in [('nan',{'wheelbase_m':float('nan')}),('negative',{'track_m':-.5}),('bool',{'wheel_radius_front_m':True}),('cabin',{'cabin_envelope_m':[1,2,3]}),('flag',{'operable_door_study':'yes'})]:
  data=json.loads((F/'data/transport/studies/carriage-c02.json').read_text());data.update(updates);f=T/(name+'.json');f.write_text(json.dumps(data));run('invalid-'+name,[sys.executable,str(F/'tools/transport/generate_carriage_c02.py'),'--parameters',str(f),'--output-dir',str(T/name)],expect=1)
 for angle in ['-1','71','nan']:run('invalid-angle-'+angle,[sys.executable,str(F/'tools/transport/generate_carriage_c02.py'),'--door-angle-deg',angle,'--output-dir',str(T/'invalid-angle')],expect=1)
 run('old-default-orchestrator',[sys.executable,str(F/'tools/transport/generate_studies_before.py'),'--output-dir',str(T/'old')])
 run('new-default-orchestrator',[sys.executable,str(F/'tools/transport/generate_studies.py'),'--output-dir',str(T/'new')])
 old={str(f.relative_to(T/'old')):sha(f)for f in(T/'old').rglob('*')if f.is_file()};new={str(f.relative_to(T/'new')):sha(f)for f in(T/'new').rglob('*')if f.is_file()};assert old==new;assert set(f.name for f in(T/'new').iterdir())=={'wagon','carriage','horse','harness'}
 run('explicit-c02-orchestrator',[sys.executable,str(F/'tools/transport/generate_studies.py'),'--only','carriage-c02','--output-dir',str(T/'only')]);assert set(f.name for f in(T/'only').iterdir())=={'carriage-c02'};assert (T/'only/carriage-c02/carriage-c02.glb').read_bytes()==(I/'export/carriage-c02.glb').read_bytes()
 before={str(f.relative_to(F)):sha(f)for f in F.rglob('*')if f.is_file()and not f.is_symlink()};run('portable-door-checker',[sys.executable,str(F/'tools/transport/test_carriage_c02_door.py'),'--receipt',str(P/'portable-triangle-receipt.json')]);after={str(f.relative_to(F)):sha(f)for f in F.rglob('*')if f.is_file()and not f.is_symlink()};assert before==after,'Checker changed source/model tree'
 report={'rows':rows,'python':sys.version,'final_enabled_glb_sha256':sha(I/'export/carriage-c02.glb'),'reviewed_bytes_preserved':True,'same_runtime_enabled_two_runs_identical':True,'flag_off_matches_prior_repaired_C02_bytes':True,'old_vs_new_default_four_model_output_hashes':old,'explicit_c02_only_is_additive':True,'checker_does_not_write_sibling_or_asset_outputs':True,'source_mapping_and_discrete15SAT':'portable-triangle-receipt.json','negative_inputs_refused':8,'runtime_scope':'Exact-byte comparisons qualified on executinginterpreter; legacyfloatingreductions are unchanged, notcrossPythonminor byteguarantee'}; (P/'diagnostics.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in ['old_vs_new_default_four_model_output_hashes','rows']},indent=2))
