# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import json,hashlib,signal,time
import numpy as np
import official_fit_predicates as predicates
from unsigned_distance import distances
P=Path(__file__).parent;ROOT=P.parent;STOP=False

def stopped(*_):
 global STOP
 STOP=True
signal.signal(signal.SIGTERM,stopped);signal.signal(signal.SIGINT,stopped)
def load(name):
 m=json.loads((P/(name+'.json')).read_text());assert hashlib.sha256((P/(name+'.f32')).read_bytes()).hexdigest()==m['buffer_sha256'];return m,np.memmap(P/(name+'.f32'),mode='r',dtype='<f4',shape=(63,m['triangleCount'],3,3))
hm,horse=load('horse_candidate');gm,gear=load('gear_v5')
rows=[];started=time.time();headnames={'browband','noseband','crownpiece','cheekpiece_l','cheekpiece_r'};headgroups=[g for g in gm['meshes']if g['name']in headnames];assert sum(g['count']for g in headgroups)==564;predicates.predicate_controls()
for ri,info in enumerate(hm['rows']):
 for scope,ids,groups in [('five_headstraps_vs_allhorse',np.arange(hm['triangleCount']),headgroups)]:
  target=np.asarray(horse[ri,ids],float);lo=target.min(1);hi=target.max(1);unionlo=lo.min(0);unionhi=hi.max(0);best=.1;witness=None;hits=[]
  for g in groups:
   for fi,a in enumerate(gear[ri,g['start']:g['start']+g['count']]):
    a=np.asarray(a,float);amin=a.min(0);amax=a.max(0)
    if np.any(amax<unionlo-.1)or np.any(amin>unionhi+.1):continue
    touch=np.flatnonzero(np.all(hi>=amin-1e-8,axis=1)&np.all(lo<=amax+1e-8,axis=1))
    for k in touch:
     if predicates.sat(a,target[k]):hits.append({'gear':g['name'],'gear_triangle':fi,'horse_triangle_global':int(ids[k]),'proper':predicates.proper(a,target[k]),'gear_points_m':a.tolist(),'horse_points_m':target[k].tolist()})
    gap=np.maximum(0,np.maximum(lo-amax,amin-hi));eligible=np.flatnonzero(np.sqrt((gap*gap).sum(1))<best)
    if len(eligible):
     dd=distances(a,target[eligible]);k=int(dd.argmin())
     if dd[k]<best:best=float(dd[k]);witness={'gear':g['name'],'gear_triangle':fi,'horse_triangle_global':int(ids[eligible[k]]),'gear_points_m':a.tolist(),'horse_points_m':target[eligible[k]].tolist()}
  assert witness is not None and best<.1
  row={**info,'scope':scope,'raw_SAT_pairs':len(hits),'proper_crossings':sum(x['proper']is not None for x in hits),'hits':hits,'minimum_unsigned_m':best,'minimum_witness':witness};rows.append(row)
  (P/'targeted-partial.json').write_text(json.dumps({'completed':False,'rows':rows,'elapsed_s':time.time()-started},indent=2)+'\n')
  if hits or best<=0:raise SystemExit('FAIL actual gear/ear separation; preservepartial')
 if ri%10==0:print(ri,[(r['scope'],r['minimum_unsigned_m'])for r in rows[-2:]],flush=True)
 if STOP:raise SystemExit(130)
summary={s:{'minimum_unsigned_m':min(r['minimum_unsigned_m']for r in rows if r['scope']==s),'raw_SAT_pairs':sum(r['raw_SAT_pairs']for r in rows if r['scope']==s)}for s in ['five_headstraps_vs_allhorse']};(P/'targeted.json').write_text(json.dumps({'completed':True,'pass':True,'summary':summary,'rows':rows,'elapsed_s':time.time()-started,'scope':'63 discrete actual GLTFLoader poses; unchanged078 five headstraps564 triangles against ALL new horse; no continuous/load/anatomy/photo acceptance'},indent=2)+'\n');print(summary,time.time()-started,flush=True)
