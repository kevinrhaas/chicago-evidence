# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import struct,json,sys,hashlib,time
import numpy as np
P=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(P/'measure'));import official_fit_predicates as pred
OLD=Path('/workspace/shared/horse-pinna-leaf-next');raw=(OLD/'trial1/equine_light_harness_skinned_prototype_01.glb').read_bytes();assert hashlib.sha256(raw).hexdigest()=='a9b15bda426a77bca823f606794d744d9d8af21e8ce3bb6b00be7368ff31443e';n=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+n]);blob=raw[28+n:];manifest=json.loads((OLD/'trial1/manifest.json').read_text());meta=json.loads((OLD/'measure/horse_candidate.json').read_text());file=OLD/'measure/horse_candidate.f32';assert hashlib.sha256(file.read_bytes()).hexdigest()==meta['buffer_sha256'];data=np.memmap(file,mode='r',dtype='<f4',shape=(63,meta['triangleCount'],3,3));selected=[];owners={};offset=0
for mesh in d['meshes']:
 for pi,primitive in enumerate(mesh['primitives']):
  ac=d['accessors'][primitive['indices']];bv=d['bufferViews'][ac['bufferView']];idx=np.frombuffer(blob,dtype={5123:'<u2',5125:'<u4'}[ac['componentType']],count=ac['count'],offset=bv.get('byteOffset',0)+ac.get('byteOffset',0)).reshape(-1,3);ranges=[r for r in manifest['vertex_ranges']if r['joint']=='head'and r['material']==primitive['material']]
  for i,face in enumerate(idx):
   rr=[r for r in ranges if all(r['vertex_start']<=int(k)<r['vertex_start']+r['vertex_count']for k in face)]
   if rr:selected.append(offset+i);owners[offset+i]={'mesh':mesh['name'],'primitive':pi,'vertex_ids':list(map(int,face)),'source_range':rr[0]['original_node']}
  offset+=len(idx)
tris=np.asarray(data[0,selected],float);_,inv=np.unique(tris.reshape(-1,3),axis=0,return_inverse=True);faces=inv.reshape(-1,3);lo=tris.min(1);hi=tris.max(1);hits=[];started=time.time();pred.predicate_controls()
for i,a in enumerate(tris):
 ix=np.flatnonzero(np.all(hi>=a.min(0)-1e-8,axis=1)&np.all(lo<=a.max(0)+1e-8,axis=1)&(np.arange(len(tris))>i))
 for j in ix:
  if len(set(faces[i])&set(faces[j]))>=2:continue
  if pred.sat(a,tris[j]):
   crossing=pred.proper(a,tris[j])
   if crossing is not None:hits.append({'a_global':selected[i],'b_global':selected[int(j)],'a_owner':owners[selected[i]],'b_owner':owners[selected[int(j)]],'points':[a.tolist(),tris[j].tolist()],'proper':crossing})
report={'pass':not hits,'parent_sha256':hashlib.sha256(raw).hexdigest(),'pose':meta['rows'][0],'anatomical_scope':'All parent authored head component faces INCLUDING eyelid/muzzle/nostril components and both a9 ears; same head-plus-ear anatomy scope, topology differs','triangle_count':len(selected),'strict_crossings':hits,'elapsed_s':time.time()-started,'scope':'Single actual idle0 matched parent control; not all63 parent poses. Unchanged SAT1e-8/proper predicates, position-weld edge adjacency exclusion. Parent failures do not excuse new contacts.'};(P/'qualification/parent-idle-head-ear-control.json').write_text(json.dumps(report,indent=2)+'\n');print('parent',len(selected),'faces',len(hits),'strict crossings',report['elapsed_s'],flush=True)
