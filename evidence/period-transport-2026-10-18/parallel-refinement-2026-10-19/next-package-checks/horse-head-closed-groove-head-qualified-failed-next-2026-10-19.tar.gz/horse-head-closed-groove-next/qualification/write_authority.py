# SPDX-License-Identifier: GPL-3.0-or-later
"""Write a new head-scope authority receipt; never reuse old animal pins."""
from pathlib import Path
import json,hashlib,struct
P=Path(__file__).resolve().parent.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pinned(rel):return {'path':rel,'sha256':sha(P/rel)}
glb=P/'trial1/equine_light_harness_skinned_prototype_01.glb';raw=glb.read_bytes();n=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+n]);producer=json.loads((P/'trial1/manifest.json').read_text());source=json.loads((P/'trial1/head-source-surface.json').read_text());inv=json.loads((P/'invariant-remap.json').read_text());selfr=json.loads((P/'qualification/posed-head-self.json').read_text());projected=json.loads((P/'qualification/projected-chart.json').read_text());fit=json.loads((P/'measure/targeted-partial.json').read_text())
assert sha(glb)=='85484b9cffc68381e71fce8a81903771938b7d7144de1b9bd923774ba5211b9d'
assert sha(glb)==sha(P/'trial2'/glb.name)
assert inv['new_sha256']==sha(glb)
assert len(selfr['rows'])==63 and selfr['completed']
mesh_table=[]
for m in d['meshes']:
 tris=sum(d['accessors'][p['indices']]['count']//3 for p in m['primitives']);mesh_table.append({'name':m['name'],'actual_active_triangles':tris,'primitives':len(m['primitives'])})
assert sum(m['actual_active_triangles']for m in mesh_table)==producer['triangles']
files=['trial1/equine_light_harness_skinned_prototype_01.glb','trial1/manifest.json','trial1/head-source-surface.json','trial1/ear-source-surfaces.json','invariant-remap.json','source-self.json','qualification/projected-chart.json','qualification/posed-head-self.json','qualification/posed-protected-invariants.json','qualification/witness-owners.json','qualification/parent-idle-head-ear-control.json','measure/horse_candidate.json','measure/gear_v5.json','measure/targeted-partial.json']
for p in sorted((P/'source').glob('*.py')):files.append(str(p.relative_to(P)))
files.append('source/parameters.json')
a={'schema':'c4d_outside_original_head_study_authority_v1','status':'FAILED actual head/ear self embedding and unchanged078 bridle fit; NOT accepted','asset_sha256':sha(glb),'producer_manifest_sha256':sha(P/'trial1/manifest.json'),'authority_scope':'New head/retained-ear geometry and explicitly mapped protected cohorts only. Raw producer legacy vertex_ranges and old shoulder counters are not active-surface authority. No b880/a9 sidecar is attached to this new geometry.','actual_mesh_table':mesh_table,'unified_head_topology':source['topology'],'features':[{'name':r['name'],'kind':r['kind'],'source_chart_faces':len(r.get('source_faces',[]))}for r in source['records']],'rest_unified_self_crossings':0,'projected_lip_chart_global_injectivity_diagnostic':projected['pass'],'actual_head_self_63poses':{'pass':selfr['pass'],'poses':len(selfr['rows']),'strict_crossings_total':sum(len(r['strict_crossings'])for r in selfr['rows']),'includes_a9_ears':True},'unchanged078_gear_fit':{'pass':False,'tested_poses':len(fit['rows']),'failed_first_pose':{'clip':'idle','phase':0},'other62_gear_rows':'UNTESTED; stopped on first failure'},'protected_invariants':{k:v for k,v in inv.items()if k not in['triangle_remap','head_scope','rows']},'protected_oriented_face_count':sum(r['protected_triangles']for r in inv['rows']),'active_cohort_reference':'Exact actual oriented triangle/vertex remapping in pinned invariant-remap.json; ear scope explicitly retained.','protected_pose_geometry_exact':json.loads((P/'qualification/posed-protected-invariants.json').read_text())['pass'],'parent_control_scope':'Actual a9 idle0 head-plus-ear comparison; no guard waiver for inherited failures','appearance_basis':'Original unmeasured reconstruction informed qualitatively by Cuyer1905Fig92; no plate tracing, metric, breed, identity or photographic acceptance claim.','pins':[pinned(p)for p in files]}
(P/'qualification/head-authority.json').write_text(json.dumps(a,indent=2)+'\n');print(a['actual_head_self_63poses'])
