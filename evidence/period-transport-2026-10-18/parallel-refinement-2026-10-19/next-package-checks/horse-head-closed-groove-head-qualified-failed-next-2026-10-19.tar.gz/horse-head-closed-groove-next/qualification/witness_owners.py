# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import json,struct
import numpy as np
P=Path(__file__).resolve().parent.parent;raw=(P/'trial1/equine_light_harness_skinned_prototype_01.glb').read_bytes();n=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+n]);blob=raw[28+n:];m=json.loads((P/'measure/horse_candidate.json').read_text());data=np.memmap(P/'measure/horse_candidate.f32',mode='r',dtype='<f4',shape=(63,m['triangleCount'],3,3));s=json.loads((P/'trial1/head-source-surface.json').read_text());ears=json.loads((P/'trial1/ear-source-surfaces.json').read_text());r=json.loads((P/'qualification/posed-head-self.json').read_text());ids=sorted({h[k]for row in r['rows']for h in row['strict_crossings']for k in['a_global','b_global']});rows=[];offset=0
for mesh in d['meshes']:
 for pi,p in enumerate(mesh['primitives']):
  a=d['accessors'][p['indices']];v=d['bufferViews'][a['bufferView']];idx=np.frombuffer(blob,dtype={5123:'<u2',5125:'<u4'}[a['componentType']],count=a['count'],offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,3)
  for g in ids:
   if not offset<=g<offset+len(idx):continue
   local=data[0,g].astype(float)-[0,1.88,.8];matches=[]
   for name,pos,faces,tags in [('continuous_head',s['positions'],s['faces'],s['tags'])]+[(e['name'],e['positions_local'],e['faces'],None)for e in ears]:
    pos=np.asarray(pos,float);found=[int(np.linalg.norm(pos-x,axis=1).argmin())for x in local];err=max(float(np.linalg.norm(pos[i]-x))for i,x in zip(found,local))
    if err<=2e-7:
     candidates=[i for i,t in enumerate(faces)if set(t)==set(found)]
     if candidates:matches.append({'source':name,'source_vertex_ids':found,'source_face_ids':candidates,'owners':[tags[i]for i in candidates]if tags else['retained_a9_ear'],'source_position_max_error_m':err})
   rows.append({'global_triangle':g,'mesh':mesh['name'],'primitive':pi,'material_index':p['material'],'primitive_triangle':g-offset,'primitive_vertex_ids':list(map(int,idx[g-offset])),'head_local_positions_m':local.tolist(),'source_matches':matches})
  offset+=len(idx)
(P/'qualification/witness-owners.json').write_text(json.dumps({'pose':{'clip':'idle','phase':0},'origin_subtracted_m':[0,1.88,.8],'rows':rows},indent=2)+'\n');print([(r['global_triangle'],r['source_matches'])for r in rows])
