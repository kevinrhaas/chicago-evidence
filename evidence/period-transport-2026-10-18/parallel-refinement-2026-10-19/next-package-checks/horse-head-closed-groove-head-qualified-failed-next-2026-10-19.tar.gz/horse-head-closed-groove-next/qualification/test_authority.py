# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import json,hashlib,copy,unittest
P=Path(__file__).resolve().parent.parent

def verify(a):
 if a['schema']!='c4d_outside_original_head_study_authority_v1':raise ValueError('schema')
 if len(a['pins'])<10 or len({r['path']for r in a['pins']})!=len(a['pins']):raise ValueError('pins')
 for r in a['pins']:
  path=P/r['path']
  if not path.resolve().is_relative_to(P.resolve()):raise ValueError('outside pin')
  if hashlib.sha256(path.read_bytes()).hexdigest()!=r['sha256']:raise ValueError('pin mismatch')
 glb=hashlib.sha256((P/'trial1/equine_light_harness_skinned_prototype_01.glb').read_bytes()).hexdigest()
 producer=hashlib.sha256((P/'trial1/manifest.json').read_bytes()).hexdigest()
 if a['asset_sha256']!=glb or a['producer_manifest_sha256']!=producer:raise ValueError('wrong authority asset')
 proof=json.loads((P/'qualification/posed-head-self.json').read_text());claim=a['actual_head_self_63poses']
 if claim['pass']!=proof['pass']or claim['poses']!=len(proof['rows'])or claim['strict_crossings_total']!=sum(len(r['strict_crossings'])for r in proof['rows']):raise ValueError('false self claim')
 if a['unchanged078_gear_fit']['pass']or a['unchanged078_gear_fit']['tested_poses']!=1:raise ValueError('false gear claim')
 if 'FAILED'not in a['status']:raise ValueError('failure erased')
 return True
class Pins(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.a=json.loads((P/'qualification/head-authority.json').read_text())
 def test_actual(self):self.assertTrue(verify(self.a))
 def reject(self,key,value):
  a=copy.deepcopy(self.a);a[key]=value
  with self.assertRaises(ValueError):verify(a)
 def test_wrong_glb(self):self.reject('asset_sha256','0'*64)
 def test_wrong_producer(self):self.reject('producer_manifest_sha256','0'*64)
 def test_erased_failure(self):self.reject('status','accepted')
 def test_forged_head_pass(self):
  a=copy.deepcopy(self.a);a['actual_head_self_63poses']['pass']=True
  with self.assertRaises(ValueError):verify(a)
 def test_fake_gear_63(self):
  a=copy.deepcopy(self.a);a['unchanged078_gear_fit']['tested_poses']=63
  with self.assertRaises(ValueError):verify(a)
 def test_bad_source_pin(self):
  a=copy.deepcopy(self.a);a['pins'][-1]['sha256']='0'*64
  with self.assertRaises(ValueError):verify(a)
if __name__=='__main__':unittest.main()
