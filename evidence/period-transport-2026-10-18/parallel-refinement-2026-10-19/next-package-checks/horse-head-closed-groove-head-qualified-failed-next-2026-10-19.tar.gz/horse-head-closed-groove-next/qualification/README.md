This is an outside-only original continuous-head reconstruction study. Geometry remains exactly GLB85484b9cffc68381e71fce8a81903771938b7d7144de1b9bd923774ba5211b9d. It is NOT accepted.

The revised lips are continuous closed lip grooves, not slits or oral cavities. Original ordered YZ coordinates and triangle chart remain exact; X-only inward sculpt vanishes at chart boundary. Both actual32-triangle charts undergo496 pairwise convex-clipped overlap checks (including adjacent pairs), with five independent controls. This numerical injectivity diagnostic does not establish anatomy.

Topology has ten positive/negative controls, tested with normal and optimized Python. The actual head preserves9688 protected oriented faces and48 portal/band attribute vectors, a9 ears, bones, sockets, inverse binds and decoded clips. Two generated GLBs/sidecars match exactly.

The original source-only unified head self test passes at rest. Expanding to actual emitted unified head plus retained a9 ears reveals strict crossing failures; all63 decoded idle/walk/trot poses are retained in explicitly failed diagnostic mode. Source-to-actual triangle identification permits unambiguous2e-7m float32 addition-order mapping only (actual max stored in receipt); SAT1e-8 and strict proper-cross predicates remain unchanged. This is not a geometry clearance tolerance relaxation.

The unchanged078 bridle test fails at idle phase0:262 raw SAT pairs,258 strict crossings, near-zero unsigned separation. Other62 gear poses remain untested. No rerouting or geometry repair follows that failed fit. Those failures, original failed slit trials and archives remain preserved. No continuous-time, gear acceptance, period measurement, photographic or production claim follows these tests.

head-authority.json is newly pinned to this actual GLB and producer. It does not copy prior animal sidecar authority or treat retired legacy vertex ranges as current active-surface tables. Protected and new head triangle cohorts are mapped explicitly in the pinned invariant-remap.json. Current app bytes are untouched.
