# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import json,unittest
from projected_chart import overlap_area,controls
P=Path(__file__).resolve().parent.parent
class ChartControls(unittest.TestCase):
 def test_analytic_intersection_and_disjoint_controls(self):self.assertEqual(controls(),5)
 def test_actual_positive_overlap_detected(self):
  s=json.loads((P/'trial1/head-source-surface.json').read_text());r=next(r for r in s['records']if r['name']=='lip_l');tri=[[s['positions'][i][1],s['positions'][i][2]]for i in r['source_faces'][0]]
  self.assertGreater(overlap_area(tri,tri),1e-15)
 def test_actual_adjacent_shared_edge_not_area_overlap(self):
  s=json.loads((P/'trial1/head-source-surface.json').read_text());r=next(r for r in s['records']if r['name']=='lip_l');a,b=r['source_faces'][:2];self.assertEqual(len(set(a)&set(b)),2)
  self.assertLessEqual(overlap_area([s['positions'][i][1:]for i in a],[s['positions'][i][1:]for i in b]),1e-15)
if __name__=='__main__':unittest.main()
