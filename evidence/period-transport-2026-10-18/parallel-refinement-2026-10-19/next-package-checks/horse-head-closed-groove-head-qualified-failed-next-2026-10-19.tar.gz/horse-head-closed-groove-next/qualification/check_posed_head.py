# SPDX-License-Identifier: GPL-3.0-or-later
"""Actual decoded GLTFLoader head triangles: unchanged strict predicates at 63 poses."""
from pathlib import Path
import json,sys,hashlib,time
import numpy as np
P=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(P/'measure'));import official_fit_predicates as pred
m=json.loads((P/'measure/horse_candidate.json').read_text());f=P/'measure/horse_candidate.f32';assert hashlib.sha256(f.read_bytes()).hexdigest()==m['buffer_sha256'];data=np.memmap(f,mode='r',dtype='<f4',shape=(63,m['triangleCount'],3,3));s=json.loads((P/'trial1/head-source-surface.json').read_text());inv=json.loads((P/'invariant-remap.json').read_text());rest=np.asarray(data[0],float);world=(np.asarray(s['positions'],dtype='<f4').astype(float)+[0,1.88,.8]).astype('<f4').astype(float)
# Match construction source to emitted rest coordinate once. Mapping tolerance
# only resolves float32 addition order; predicates below retain epsilon1e-8.
unique,indices=np.unique(rest.reshape(-1,3),axis=0,return_inverse=True);all_faces=indices.reshape(-1,3);active=sorted({i for t in s['faces']for i in t});mapping={};errors=[]
for i in active:
 dd=np.linalg.norm(unique-world[i],axis=1);order=np.argsort(dd)[:2];assert dd[order[0]]<=2e-7;assert dd[order[1]]>2e-7,'Ambiguous source coordinate match';mapping[i]=int(order[0]);errors.append(float(dd[order[0]]))
def key(t):return min(tuple(t),tuple(t[1:]+t[:1]),tuple(t[2:]+t[:2]))
lookup={key(list(t)):i for i,t in enumerate(all_faces)};selected=[lookup[key([mapping[i]for i in t])]for t in s['faces']];assert len(set(selected))==len(s['faces'])
earids=[]
for q in json.loads((P/'trial1/ear-source-surfaces.json').read_text()):
 ev=(np.asarray(q['positions_local'],dtype='<f4').astype(float)+[0,1.88,.8]).astype('<f4').astype(float);em={}
 for i,x in enumerate(ev):
  dd=np.linalg.norm(unique-x,axis=1);order=np.argsort(dd)[:2];assert dd[order[0]]<=2e-7 and dd[order[1]]>2e-7;em[i]=int(order[0]);errors.append(float(dd[order[0]]))
 earids.extend(lookup[key([em[i]for i in t])]for t in q['faces'])
selected=sorted(set(selected)|set(earids));assert len(earids)==1148
faces=all_faces[selected];rows=[];started=time.time();pred.predicate_controls()
for ri,pose in enumerate(m['rows']):
 tris=np.asarray(data[ri,selected],float);lo=tris.min(1);hi=tris.max(1);hits=[];areas=np.linalg.norm(np.cross(tris[:,1]-tris[:,0],tris[:,2]-tris[:,0]),axis=1)/2;assert np.isfinite(tris).all()and areas.min()>1e-12
 for i,a in enumerate(tris):
  ix=np.flatnonzero(np.all(hi>=a.min(0)-1e-8,axis=1)&np.all(lo<=a.max(0)+1e-8,axis=1)&(np.arange(len(tris))>i))
  for j in ix:
   if len(set(faces[i])&set(faces[j]))>=2:continue
   if pred.sat(a,tris[j]):
    crossing=pred.proper(a,tris[j])
    if crossing is not None:hits.append({'a_global':selected[i],'b_global':selected[int(j)],'proper':crossing,'points':[a.tolist(),tris[j].tolist()]})
 rows.append({**pose,'strict_crossings':hits,'min_area_m2':float(areas.min())});report={'pass':not any(r['strict_crossings']for r in rows),'completed':len(rows)==63,'rows':rows,'unified_head_faces':len(s['faces']),'a9_ear_faces':len(earids),'total_actual_head_faces':len(selected),'selected_global_triangle_ids':selected,'source_to_actual_coordinate_match_max_m':max(errors),'match_scope':'2e-7m unambiguous source/actual float32 coordinate matching ONLY; strict SAT1e-8 and proper crossing unchanged','input_buffer_sha256':m['buffer_sha256'],'elapsed_s':time.time()-started,'scope':'Actual head surface plus both retained a9 ears at63 sampled idle/walk/trot poses; excludes lower neck/body and does not prove continuous time or photographic/anatomical quality.'};(P/'qualification/posed-head-self.json').write_text(json.dumps(report,indent=2)+'\n')
 # Failed diagnostic mode: retain every pose and witness, never claim pass.
 if ri%10==0:print('sampled pose',ri,'strict crossings',len(hits),flush=True)
print('ALL63 diagnostic complete; pass=',report['pass'],time.time()-started,flush=True)
