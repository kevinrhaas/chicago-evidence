# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import json,struct,hashlib,collections
import numpy as np
P=Path(__file__).parent;OLD=Path('/workspace/shared/horse-pinna-leaf-next')
def load(p):
 b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];return json.loads(b[20:20+n]),b[28+n:]
def arr(d,b,i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];dt={5126:'<f4',5123:'<u2',5125:'<u4'}[a['componentType']];size={'VEC3':3,'VEC4':4,'MAT4':16,'SCALAR':1}[a['type']];return np.frombuffer(b,dt,a['count']*size,v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(a['count'],size)
def model(folder):
 d,b=load(folder/'equine_light_harness_skinned_prototype_01.glb');manifest=json.loads((folder/'manifest.json').read_text());source=json.loads((folder/'ear-source-surfaces.json').read_text());parts={};globalstart=0
 for mesh in d['meshes']:
  p=mesh['primitives'][0];mat=p['material'];attributes={k:arr(d,b,i)for k,i in p['attributes'].items()};positions=attributes['POSITION'];indices=arr(d,b,p['indices']).ravel().reshape(-1,3);keys={tuple(v)for s in source if s['material']==mat for v in(np.asarray(s['positions_local'],dtype='<f4').astype(float)+[0,1.88,.8]).astype('<f4')};ear=np.array([tuple(v)in keys for v in positions]);head=np.zeros(len(positions),bool)
  for r in manifest['vertex_ranges']:
   if r['material']==mat and r['joint']=='head'and mat!=5:head[r['vertex_start']:r['vertex_start']+r['vertex_count']]=True
  head[ear]=False;portal=None
  if mat==0:
   r=next(r for r in manifest['vertex_ranges']if r['original_node']=='head_material_equine_coat');portal=np.arange(r['vertex_start'],r['vertex_start']+48);head[portal]=False;assert ear.sum()==368
  if mat==5:assert ear.sum()==290
  vec=np.concatenate([attributes[k].astype('<f4')for k in ['POSITION','NORMAL','JOINTS_0','WEIGHTS_0']],axis=1);vertexkeys=[v.tobytes()for v in vec];protected=np.flatnonzero(~np.any(head[indices],axis=1));triangles={}
  for i in protected:
   ids=indices[i];chunks=[vertexkeys[k]for k in ids];cycle=min(range(3),key=lambda k:b''.join(chunks[k:]+chunks[:k]));key=hashlib.sha256(b''.join(chunks[cycle:]+chunks[:cycle])).hexdigest();triangles.setdefault(key,[]).append({'triangle_global':globalstart+int(i),'cycle':cycle})
  parts[mat]={'name':mesh['name'],'attributes':attributes,'ear':ear,'head':head,'portal':portal,'protected_vertices':collections.Counter(vertexkeys[i]for i in np.flatnonzero(~head)),'protected_triangles':triangles,'triangle_start':globalstart,'indices':indices};globalstart+=len(indices)
 return d,b,manifest,parts
old,ob,om,op=model(OLD/'trial1');new,nb,nm,np_=model(P/'trial1');assert old['materials']==new['materials'];assert om['joint_table']==nm['joint_table']and om['sockets']==nm['sockets']
for a,b in zip(old['skins'],new['skins']):
 assert {k:v for k,v in a.items()if k!='inverseBindMatrices'}=={k:v for k,v in b.items()if k!='inverseBindMatrices'};assert np.array_equal(arr(old,ob,a['inverseBindMatrices']),arr(new,nb,b['inverseBindMatrices']))
 for i in a['joints']:assert old['nodes'][i]==new['nodes'][i]
for a,b in zip(old['animations'],new['animations']):
 assert a['name']==b['name']and a['channels']==b['channels']and a['extras']==b['extras']
 for x,y in zip(a['samplers'],b['samplers']):
  assert x['interpolation']==y['interpolation']
  for k in ['input','output']:assert np.array_equal(arr(old,ob,x[k]),arr(new,nb,y[k]))
remap=[];rows=[]
for mat in sorted(set(op)|set(np_)):
 a=op.get(mat);b=np_.get(mat)
 if not a or not b:
  x=a or b;assert not x['protected_vertices']and not x['protected_triangles'];continue
 assert a['protected_vertices']==b['protected_vertices'],('nonheadvertex attributes changed',mat, len(a['protected_vertices']-b['protected_vertices']),len(b['protected_vertices']-a['protected_vertices']))
 assert {k:len(v)for k,v in a['protected_triangles'].items()}=={k:len(v)for k,v in b['protected_triangles'].items()},('nonheadfaces changed',mat)
 for key,uses in a['protected_triangles'].items():
  for x,y in zip(uses,b['protected_triangles'][key]):remap.append({'old':x['triangle_global'],'new':y['triangle_global'],'old_cycle':x['cycle'],'new_cycle':y['cycle']})
 if mat==0:
  for attr in ['POSITION','NORMAL','JOINTS_0','WEIGHTS_0']:assert np.array_equal(a['attributes'][attr][a['portal']],b['attributes'][attr][b['portal']]),('portalband changed',attr)
 rows.append({'material':mat,'protected_vertices':sum(a['protected_vertices'].values()),'protected_triangles':sum(len(x)for x in a['protected_triangles'].values()),'ear_vertices':int(a['ear'].sum())})
r={'pass':True,'baseline_sha256':hashlib.sha256((OLD/'trial1/equine_light_harness_skinned_prototype_01.glb').read_bytes()).hexdigest(),'new_sha256':hashlib.sha256((P/'trial1/equine_light_harness_skinned_prototype_01.glb').read_bytes()).hexdigest(),'bones_rest_hierarchy_IBMs_sockets_decoded_clips_exact':True,'portalband48_all_attributes_exact':True,'protected_nonhead_and_a9ears_VERTEX_ATTRIBUTES_AND_ORIENTED_FACES_exact_after_explicit_remap':True,'rows':rows,'triangle_remap':remap,'head_scope':{str(k):{'mesh':v['name'],'declared_head_vertex_ids':np.flatnonzero(v['head']).tolist(),'ear_vertex_ids':np.flatnonzero(v['ear']).tolist(),'head_triangle_ids':np.flatnonzero(np.any(v['head'][v['indices']],axis=1)).tolist()}for k,v in np_.items()},'scope':'Rendered AND unreferenced nonhead vertices compareactualPOS/NORMAL/JOINTS/WEIGHTS; nonhead orientedtrianglecorrespondence explicit. Retiredheadpartsallowed; no anonymous broad boundingbox exemption. No gear/visual acceptance.'};(P/'invariant-remap.json').write_text(json.dumps(r,indent=2)+'\n');print(rows,'protected triangles',len(remap))
