# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import unittest,json,copy,sys
P=Path(__file__).parent;sys.path.insert(0,str(P/'source'));from head_surface import audit
class ActualPatchContracts(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.s=json.loads((P/'trial1/head-source-surface.json').read_text())
 def validate(self,s):return audit(s['positions'],s['faces'],s['portal'],s['records'],s['tags'])
 def test_actual_surface(self):self.assertEqual(self.validate(self.s)['portal_boundary_edges'],24)
 def test_missing_annulus_face(self):
  s=copy.deepcopy(self.s);i=next(i for i,t in enumerate(s['tags'])if t=='skin:eye_l');s['faces'].pop(i);s['tags'].pop(i)
  with self.assertRaises(ValueError):self.validate(s)
 def test_reversed_eye_closure(self):
  s=copy.deepcopy(self.s);i=next(i for i,t in enumerate(s['tags'])if t=='eye_l');s['faces'][i]=s['faces'][i][::-1]
  with self.assertRaises(ValueError):self.validate(s)
 def test_duplicate_nostril_face(self):
  s=copy.deepcopy(self.s);i=next(i for i,t in enumerate(s['tags'])if t=='nostril_1');s['faces'].append(s['faces'][i]);s['tags'].append(s['tags'][i])
  with self.assertRaises(ValueError):self.validate(s)
 def test_false_boundary_ownership(self):
  s=copy.deepcopy(self.s);s['records'][0]['aperture']=s['records'][1]['aperture']
  with self.assertRaises(ValueError):self.validate(s)
 def test_missing_feature_table(self):
  s=copy.deepcopy(self.s);s['records']=[]
  with self.assertRaises(ValueError):self.validate(s)
 def test_detached_closed_overlay(self):
  s=copy.deepcopy(self.s);off=len(s['positions']);s['positions'].extend([[5,5,5],[6,5,5],[5,6,5],[5,5,6]]);s['faces'].extend([[off,off+2,off+1],[off,off+1,off+3],[off+1,off+2,off+3],[off+2,off,off+3]]);s['tags'].extend(['skin']*4)
  with self.assertRaises(ValueError):self.validate(s)
if __name__=='__main__':unittest.main()
