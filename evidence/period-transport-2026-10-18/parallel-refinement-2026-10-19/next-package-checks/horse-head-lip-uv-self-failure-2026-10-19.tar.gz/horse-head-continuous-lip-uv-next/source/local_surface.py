# SPDX-License-Identifier: CC0-1.0
"""One bounded original local subdivision pass. Outside-patch edges stay intact."""
import numpy as np

def smooth_local(g,selected):
    faces=np.asarray(g['i'],dtype=int).reshape(-1,3).tolist();selected=set(selected);oldp=np.asarray(g['p'],dtype=float);oldj=[list(v)for v in g['j']];oldw=[list(v)for v in g['w']];edges={};incident={};neighbors={}
    for fi,face in enumerate(faces):
        for v in face:incident.setdefault(v,set()).add(fi)
        for a,b,c in zip(face,face[1:]+face[:1],face[2:]+face[:2]):
            edges.setdefault(tuple(sorted((a,b))),[]).append((fi,c));neighbors.setdefault(a,set()).add(b);neighbors.setdefault(b,set()).add(a)
    def mix(coefficients):
        position=sum((oldp[v]*weight for v,weight in coefficients),np.zeros(3));weights={}
        for v,fraction in coefficients:
            for joint,weight in zip(oldj[v],oldw[v]):
                if weight>0:weights[joint]=weights.get(joint,0.)+fraction*weight
        weights={j:w for j,w in weights.items()if w>1e-12};assert len(weights)<=4
        total=sum(weights.values());pairs=sorted(((j,w/total)for j,w in weights.items()),key=lambda x:(-x[1],x[0]));j=[v[0]for v in pairs];w=[v[1]for v in pairs]
        return position.tolist(),j+[0]*(4-len(j)),w+[0]*(4-len(w))
    moved=[]
    for v,uses in incident.items():
        if uses and uses<=selected and all(len(edges[tuple(sorted((v,n)))])==2 for n in neighbors[v]):
            count=len(neighbors[v]);beta=3/16 if count==3 else 3/(8*count)
            position,j,w=mix([(v,1-count*beta)]+[(n,beta)for n in sorted(neighbors[v])]);g['p'][v]=position;g['j'][v]=j;g['w'][v]=w;moved.append(v)
    midpoint={}
    for edge,uses in sorted(edges.items()):
        if len(uses)==2 and all(fi in selected for fi,_ in uses):
            a,b=edge;position,j,w=mix([(a,3/8),(b,3/8),(uses[0][1],1/8),(uses[1][1],1/8)]);index=len(g['p']);midpoint[edge]=index;g['p'].append(position);g['j'].append(j);g['w'].append(w);g['n'].append([0.,0.,0.])
    output=[];descendants={};changed=[]
    for fi,face in enumerate(faces):
        a,b,c=face;m=[midpoint.get(tuple(sorted(edge)))for edge in[(a,b),(b,c),(c,a)]];count=sum(v is not None for v in m)
        if fi not in selected:assert count==0
        if count==0:new=[(a,b,c)]
        elif count==3:
            ab,bc,ca=m;new=[(a,ab,ca),(ab,b,bc),(ca,bc,c),(ab,bc,ca)]
        elif count==1:
            k=next(i for i,v in enumerate(m)if v is not None);v=face[k:]+face[:k];a,b,c=v;ab=m[k];new=[(a,ab,c),(ab,b,c)]
        else:
            k=next(i for i,v in enumerate(m)if v is None);r=(k+1)%3;v=face[r:]+face[:r];a,b,c=v;ab=m[r];bc=m[(r+1)%3];new=[(b,bc,ab),(a,ab,bc),(a,bc,c)]
        descendants[fi]=list(range(len(output),len(output)+len(new)));output.extend(new)
        if fi in selected:changed.extend(descendants[fi])
    g['i']=[v for face in output for v in face]
    touched={v for fi in changed for v in output[fi]};p=np.asarray(g['p']);f=np.asarray(output);weighted=np.zeros_like(p);normals=np.cross(p[f[:,1]]-p[f[:,0]],p[f[:,2]]-p[f[:,0]])
    for k in range(3):np.add.at(weighted,f[:,k],normals)
    for v in touched:
        n=weighted[v];length=float(np.linalg.norm(n));assert length>1e-12;g['n'][v]=(n/length).tolist()
    return {'original_selected_faces':sorted(selected),'active_changed_faces':changed,'old_vertices_relaxed':moved,'new_edge_vertex_indices':list(midpoint.values()),'split_edges':{str(a)+','+str(b):v for(a,b),v in midpoint.items()},'face_descendants':descendants,'changed_normal_vertex_indices':sorted(touched),'method':'one local Loop-weight pass; only edges with both incident faces selected split; outside-patch geometry edges intact'}
