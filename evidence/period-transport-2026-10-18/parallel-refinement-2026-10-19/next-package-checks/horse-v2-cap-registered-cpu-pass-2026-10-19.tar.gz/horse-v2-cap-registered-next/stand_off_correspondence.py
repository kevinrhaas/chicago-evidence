from pathlib import Path
import numpy as np,json,hashlib
from check_pairs import snapshot,PARTS
P=Path(__file__).parent;old=Path('/workspace/shared/horse-v2-gear-v5-pair-next');m,new=snapshot('gear_v5');om=json.loads((old/'gear_v5.json').read_text());assert hashlib.sha256((old/'gear_v5.f32').read_bytes()).hexdigest()==om['buffer_sha256'];previous=np.memmap(old/'gear_v5.f32',mode='r',dtype='<f4',shape=(63,om['triangleCount'],3,3));report=json.loads((P/'stand-off.json').read_text());rows=[]
for group in m['meshes']:
 if group['name']not in PARTS:continue
 name=group['name'];start=group['start'];end=start+group['count'];oa,oi=np.unique(np.asarray(previous[0,start:end],float).reshape(-1,3),axis=0,return_inverse=True);na,ni=np.unique(np.asarray(new[0,start:end],float).reshape(-1,3),axis=0,return_inverse=True);mapping={}
 for a,b in zip(oi,ni):
  if int(a)in mapping:assert mapping[int(a)]==int(b)
  mapping[int(a)]=int(b)
 assert len(mapping)==len(oa)==len(na)and len(set(mapping.values()))==len(na)
 ids=np.array([mapping[i]for i in range(len(oa))]);movement=np.linalg.norm(na[ids]-oa,axis=1);observed=[]
 for ri in range(63):
  a=next(r for r in report['rows']if r['model']=='originalV5_on_b880'and r['part']==name and r['clip']==m['rows'][ri]['clip']and r['phase']==m['rows'][ri]['phase']);b=next(r for r in report['rows']if r['model']=='trial078ed2_on_b880'and r['part']==name and r['clip']==a['clip']and r['phase']==a['phase']);delta=np.abs(np.array(b['values_m'])[ids]-np.array(a['values_m']));assert np.all(delta<=movement+1e-9);observed.append(float(delta.max()))
 rows.append({'part':name,'maximum_corresponding_surfacevertex_displacement_m':float(movement.max()),'maximum_corresponding_vertex_standoff_change_m':max(observed),'point_distance_Lipschitz_bound_pass':True,'poses':63,'note':'Limits change only; does not validate absolute54mm maximum gap.'})
(P/'stand-off-correspondence.json').write_text(json.dumps({'pass':True,'rows':rows},indent=2)+'\n');print(rows)
