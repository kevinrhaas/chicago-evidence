# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import argparse,tarfile,hashlib
P=Path(__file__).parent;cli=argparse.ArgumentParser();cli.add_argument('--source-package',type=Path,required=True);cli.add_argument('--output-dir',type=Path,required=True);a=cli.parse_args();assert hashlib.sha256(a.source_package.read_bytes()).hexdigest()=='a185e7cf0105a04b772d5f690cebb2b645f7557a00ad262bd97c2f8405849aab'
with tarfile.open(a.source_package)as t:
 for m in t.getmembers():
  if m.name.startswith('files/chicago/4d/')and m.isfile():
   rel=Path(m.name).relative_to('files/chicago/4d');assert '..'not in rel.parts;f=a.output_dir/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(t.extractfile(m).read())
f=a.output_dir/'tools/transport/generate_carriage_c02.py';s=f.read_text().replace('import json,math,struct,pathlib','import json,math,struct,pathlib,hashlib')
s=s.replace('args=cli.parse_args();',"cli.add_argument('--paint-study',type=pathlib.Path);args=cli.parse_args();")
s=s.replace('def node(name,', '''paint=None
if args.paint_study:
 paint=json.loads(args.paint_study.read_text())
 if paint['material_name']!='black_lacquer':raise ValueError('Study restricted to original black_lacquer material')
 def factor(x):
  if isinstance(x,bool)or not isinstance(x,(int,float))or not math.isfinite(x)or not 0<=x<=1:raise ValueError('Paint factors must be finite unit-interval numbers')
  return x
 color=paint['baseColorFactor']
 if len(color)!=4:raise ValueError('Expected RGBA')
 materials[0]['pbrMetallicRoughness']={'baseColorFactor':[factor(x)for x in color],'metallicFactor':factor(paint['metallicFactor']),'roughnessFactor':factor(paint['roughnessFactor'])}
 materials[0]['extensions']={'KHR_materials_clearcoat':{'clearcoatFactor':factor(paint['clearcoatFactor']),'clearcoatRoughnessFactor':factor(paint['clearcoatRoughnessFactor'])}}
def node(name,''',1)
s=s.replace("j=json.dumps(g,separators=", "if paint:\n g['extensionsUsed']=['KHR_materials_clearcoat'];sidecar['surface_study']={'recipe':paint,'recipe_sha256':hashlib.sha256(args.paint_study.read_bytes()).hexdigest(),'historical_finish_attested':False,'photographic_acceptance':False}\nj=json.dumps(g,separators=",1)
f.write_text(s)
print(a.output_dir)
