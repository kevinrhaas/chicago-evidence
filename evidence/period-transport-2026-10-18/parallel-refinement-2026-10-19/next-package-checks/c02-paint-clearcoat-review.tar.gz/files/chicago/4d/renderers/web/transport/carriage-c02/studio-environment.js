// SPDX-License-Identifier: GPL-3.0-or-later
// Original reconstructed studio reflection field, not acquired photographic lighting.
import * as T from 'three';
export function createStudioEnvironment(renderer) {
  const width=256,height=128,data=new Float32Array(width*height*4);
  // Soft rectangular sources in longitude/latitude. Radiance is linear scene light.
  const panels=[{lon:-.9,lat:.48,w:.19,h:.48,power:8,color:[1,.94,.85]},
    {lon:1.5,lat:.32,w:.34,h:.32,power:5,color:[.82,.90,1]},
    {lon:3,lat:.95,w:1.1,h:.18,power:3,color:[1,1,1]}];
  const smooth=(a,b,x)=>{const t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t);};
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const lon=(x+.5)/width*Math.PI*2-Math.PI,lat=(y+.5)/height*Math.PI-Math.PI/2;
    const base=.12+.17*Math.max(0,Math.sin(lat)),rgb=[base,base,base];
    for(const p of panels){const delta=Math.abs(Math.atan2(Math.sin(lon-p.lon),Math.cos(lon-p.lon)));
      const weight=(1-smooth(p.w*.82,p.w,delta))*(1-smooth(p.h*.82,p.h,Math.abs(lat-p.lat)));
      for(let k=0;k<3;k++)rgb[k]+=weight*p.power*p.color[k];}
    const i=(y*width+x)*4;data.set([...rgb,1],i);
  }
  const input=new T.DataTexture(data,width,height,T.RGBAFormat,T.FloatType);
  input.mapping=T.EquirectangularReflectionMapping;input.colorSpace=T.LinearSRGBColorSpace;input.needsUpdate=true;
  const pmrem=new T.PMREMGenerator(renderer);const target=pmrem.fromEquirectangular(input);pmrem.dispose();input.dispose();
  return {texture:target.texture,dispose:()=>target.dispose(),definition:{width,height,base:'neutral .12 + .17 upper hemisphere',panels,environmentIntensity:1,status:'original studio illumination; not historical outdoor illumination'}};
}
