from pathlib import Path
import json,struct,hashlib
P=Path(__file__).parent;sha=lambda x:hashlib.sha256(x).hexdigest()
def decode(b):
 n=struct.unpack_from('<I',b,12)[0];return json.loads(b[20:20+n]),b[20+n:]
base=(P/'flag-off/carriage-c02.glb').read_bytes();first=(P/'paint-first/carriage-c02.glb').read_bytes();repeat=(P/'paint-repeat/carriage-c02.glb').read_bytes();assert sha(base)=='ddda1b89b330c889d69acaf55b79c4a114d193ff140e9e27c11cf74fc7f16eb6';assert first==repeat
a,ab=decode(base);b,bb=decode(first);assert ab==bb
for key in ['nodes','meshes','accessors','bufferViews','buffers','scenes','scene','asset']:assert a[key]==b[key],key
assert a['materials'][1:]==b['materials'][1:];assert b['materials'][0]['extensions']['KHR_materials_clearcoat']=={'clearcoatFactor':.85,'clearcoatRoughnessFactor':.18}
e=dict(b['extras']);e.pop('surface_study');assert a['extras']==e
report={'baseline_sha256':sha(base),'variant_sha256':sha(first),'variant_bytes':len(first),'geometry_binary_exact':True,'nodes_meshes_accessors_views_scenes_asset_exact':True,'other_six_materials_exact':True,'surface_study_only_extras_change':True,'two_run_variant_bytes_exact':True,'flag_off_original_C02_bytes_exact':True,'default_four_model_scope':'No orchestrator/default-four source or inputs modified in this parcel; inherited exact a185 opt-in source unchanged.','recipe_sha256':sha((P/'paint-recipe.json').read_bytes())}
(P/'source-proof.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
