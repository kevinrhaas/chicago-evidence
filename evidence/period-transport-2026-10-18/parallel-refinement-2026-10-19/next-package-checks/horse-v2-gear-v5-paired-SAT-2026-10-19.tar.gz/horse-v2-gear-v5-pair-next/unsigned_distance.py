# SPDX-License-Identifier: GPL-3.0-or-later
"""Original vector distance math; require separately verified zero-SAT pair before use."""
import numpy as np
