from pathlib import Path
import hashlib,json,shutil,subprocess,difflib,ast
P=Path(__file__).parent;R=Path('/workspace/chicago');S=Path('/workspace/shared/c02-metadata-next');OLD=S/'base/files';B=P/'base/files';prior=json.loads((S/'BASE-MANIFEST.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();paths=prior['modified_files'];snap={rel:(R/rel).read_bytes()for rel in paths}
head=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD']).decode().strip();merge=subprocess.check_output(['git','-C',str(R),'rev-parse','MERGE_HEAD']).decode().strip();assert head=='f97ee94970385d35f469c449c6b111b0d8488057';assert merge=='fb6a775794e1fc9d64809af5f9dfa3518537517d'
# Copy only reviewed minimal files. Optional paint/studio never enters this tree.
for rel in prior['new_files']:
 assert not(R/rel).exists(),('New-file overlap',rel)
 f=B/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(OLD/rel,f)
append_paths=['chicago/4d/assets/LICENSES.md','chicago/4d/docs/LIBERTIES.md','chicago/4d/docs/ROADMAP.md','chicago/4d/docs/STATUS.md','chicago/4d/renderers/web/transport/LICENSES.md']
for rel in append_paths:
 original=subprocess.check_output(['git','-C',str(R),'show',head+':'+rel]);reviewed=(OLD/rel).read_bytes();assert reviewed.startswith(original);suffix=reviewed[len(original):];f=B/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(snap[rel]+suffix);assert f.read_bytes().startswith(snap[rel])
rel='chicago/4d/tools/check.sh';reviewed=(OLD/rel).read_bytes();start=reviewed.index(b'# C02 actual source/export mapping');end=reviewed.index(b'step "Harness body fit reproduces original crossings');block=reviewed[start:end];anchor=b'step "Harness body fit reproduces original crossings';assert snap[rel].count(anchor)==1 and b'python3 tools/transport/test_carriage_c02_door.py'not in snap[rel];new=snap[rel].replace(anchor,block+anchor,1);f=B/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(new);assert new.replace(block,b'',1)==snap[rel]
rel='chicago/4d/renderers/web/transport/index.html';line=next(line for line in(OLD/rel).read_bytes().splitlines(keepends=True)if b'href="carriage-c02/"'in line);anchor=next(line for line in snap[rel].splitlines(keepends=True)if b'href="harness/"'in line);assert b'href="carriage-c02/"'not in snap[rel];new=snap[rel].replace(anchor,line+anchor,1);f=B/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(new);assert new.replace(line,b'',1)==snap[rel]
rel='chicago/4d/tools/transport/generate_studies.py';original=subprocess.check_output(['git','-C',str(R),'show',head+':'+rel]);assert snap[rel]==original,'Orchestrator changed; adaptive source review required';f=B/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(OLD/rel,f)
# No source-changing inputs were assumed stable without verifying both snapshots.
assert all((R/rel).read_bytes()==raw for rel,raw in snap.items()),'Authored inputs changed during rebase; wait and repeat'
M='chicago/4d/docs/RESEARCH/period-transport-2026-10-18/c02-enclosed-door/INTEGRATION-MANIFEST.json';manifest=dict(prior);manifest['base_commit']=head;manifest['merge_head']=merge;manifest['base_state']='Current authored merge-in-progress working tree; fresh eight preimages, not old f97 text replacements';manifest['preimage_sha256']={rel:sha(raw)for rel,raw in snap.items()};manifest['proposed_file_sha256']={str(f.relative_to(B)):sha(f.read_bytes())for f in B.rglob('*')if f.is_file()and str(f.relative_to(B))!=M};manifest['rebase_scope']='Same reviewed93d4 geometry/source payload; eight authored-file transplant only; evidence manifest updated';manifest['installed_gate_step_isolation']='NOT MEASURED; root must measure both actual commands after installation'
for f in[P/'BASE-MANIFEST.json',B/M]:f.write_text(json.dumps(manifest,indent=2)+'\n')
patch=[]
for rel in paths:
 patch.extend(difflib.unified_diff(snap[rel].decode('utf-8','surrogateescape').splitlines(True),(B/rel).read_bytes().decode('utf-8','surrogateescape').splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(P/'base/existing-files.patch').write_bytes(''.join(patch).encode('utf-8','surrogateescape'))
subprocess.run(['git','-C',str(R),'apply','--check',str(P/'base/existing-files.patch')],check=True)
for f in(B/'chicago/4d/tools/transport').glob('*.py'):ast.parse(f.read_bytes())
subprocess.run(['bash','-n',str(B/'chicago/4d/tools/check.sh')],check=True)
unchanged=[rel for rel in prior['new_files']if rel!=M];assert all((B/rel).read_bytes()==(OLD/rel).read_bytes()for rel in unchanged)
report={'head':head,'merge_head':merge,'fresh_preimages':manifest['preimage_sha256'],'eight_authored_snapshots_stable_before_after':True,'all_five_append_file_current_bytes_preserved_as_prefix':True,'current_check_sh_exact_bytes_preserved_except_two_inserted_hooks':True,'current_gallery_exact_bytes_preserved_except_additive_card':True,'default_four_dispatch_byte_same_as_reviewed':True,'new_reviewed_files_byte_identical_excluding_manifest':len(unchanged),'new_asset_sha256':sha((B/'chicago/4d/renderers/web/transport/carriage-c02/carriage-c02.glb').read_bytes()),'no_optional_paint_studio':True,'existing_patch_check':True,'installed_isolation_rows_generated':False,'app_writes':False,'model_generation_or_browser_run':False};(P/'REBASE-RECEIPT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
