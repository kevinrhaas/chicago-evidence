# Minimal C02 transplant onto the fb6 merge working tree (NOT APPLIED)

Rebased from independently reviewed `41d5c12303acc91436df778e085441ce8fa0278af9ee4cd652e9a7a1da3102e7`. Current authored preimages: HEAD f97ee94970385d35f469c449c6b111b0d8488057 with MERGE_HEAD fb6a775794e1fc9d64809af5f9dfa3518537517d. See BASE-MANIFEST.json for all eight fresh hashes. Root's generated rederive outputs are not part of this overlay.

Only base/files is an installation payload.39new files are unchanged from reviewed minimal metadata/articulation proposal except its documentary INTEGRATION-MANIFEST. The eight existing paths were rebased: five documents/licenses receive only the reviewed suffix AFTER all current bytes, check.sh receives only the two reviewed C02 hooks, gallery receives only the reviewed card, and original-four orchestrator gets the same opt-in C02 dispatch. All current dev check additions/root STATUS+ROADMAP append/entire LIBERTIES bytes survive. Existing nonUTF8 ROADMAP byte is preserved, never normalized. All20runtime/eightoriginalsource/input protected hashes match current working tree. No paint/studio source, recipe, asset or optional overlay is included.

Root installation, only after review/choice:

1. Recheck the eight preimage hashes against BASE-MANIFEST.json. If any differ, stop and rebase the authored delta; do not overwrite with stale whole files.
2. From repo root, `git apply --check PATH/base/existing-files.patch`, then apply that contextual patch for the eight existing files. Copy ONLY manifest `new_files` from base/files into corresponding repo paths.39paths include model/source/data/viewer/evidence/license provenance, not generated isolation rows.
3. Confirm source/sidecar/GLB hashes and original protected files. Run both installed check commands and MEASURE their actual step isolation through the existing root process; no placeholder wrote[] row is provided here. Run the installed browser and final-head normal derive/full gate chosen by root. This rebase performed no model generation/browser/full gate and claims none.

From chicago/4d, installed checks:

```sh
python3 tools/transport/test_carriage_c02_door.py --receipt /tmp/c02-door.json
python3 tools/transport/test_carriage_c02_door_hierarchy.py
node tools/transport/smoke_carriage_c02.cjs /tmp/c02-browser
```

Repo-relative generator: `python3 tools/transport/generate_studies.py --only carriage-c02 --output-dir /tmp/c02-output`. Default dispatch remains exactly wagon/carriage/horse/harness. No source archive/private workspace/remote download/Blender runtime prerequisite. Retained research preparation script is NOT an installed dependency.

Payload model remains93d4020036e5c685ce95010fe64b26c55a1561db4517405f0590f7a398253331,860956bytes,11512triangles/31batches/62nodes. Corrected actual hierarchy source/semantic negatives and truthful project-source quotation history remain as independently reviewed. Earlier provenance receipts are source checkpoints, not a new merged-head pass.1904development reconstruction only; no1835people, historical ownership/subtype/finish, actual continuous collision, passenger/cloth/forces/boarding or photographic acceptance. T-2794 stays open. No central ticket or shipped changelog.js edit.
