# Exact trial scope

Trial ba094 geometry is derived from original repaired V5 45930: breastcollar per-section max2mm outward offset, LEFT support middle-section max.75mm lateral offset. Right support is unchanged because full63pose diagnostic gives9.630428mm minimum, not an assumed symmetric failure. Only2/36 mesh POSITION/NORMAL buffers change. b880 horse GLB is exact. New gear preserves nodes/socket values/materials and topology counts;34other meshes exact. This does not mean historical/anatomical/photographic approval.

A legacy local input/snapshot filename gear_v5 identifies the NEW trial only; input-receipt.json pins actualba094 bytes. Do not confuse this with original45930 V5. Horse snapshots were rechecked against exact prior content SHA; gear is freshly GLTFLoader sampled under actual parent-inverse head binding. No root lift, pose marker changes, scales or threshold changes.

Prior controls are reusable only for exact original89/459,b880/459 inputs and unchanged SAT/distance predicates: preserved b3a86888 and127d2728 archives. Prior complete failed perpart154 diagnostic is copied with hash linked. No cached success is substituted for newba094 geometry. New acceptance requires actual new63pose SAT/proper and distance receipts.

Distance uses certified<100mm actual eligible witness before AABB lower-bound pruning. Four repaired parts require>=5mm unsigned triangle distance to ALL active horse triangles. All36gear vs1586 active changedpatch faces requirespositive distance and0SAT. Discrete63poses do not prove continuous collision avoidance or containment. SAT keeps1e-8 epsilon, proper-crossing predicate unchanged.

Attachment inspection requires actual source-geometry overlap collar with traces/supports and support with pad, plus original socket centers inside actual collar cap sections. Those intentional gear-to-gear intersections describe overlap only, not stiffness/force/pressure or a welded unified strap. Wholegear rest root parts are static and unchanged under sample poses; head binding is checked separately by source snapshot.

Stand-off reports actual surfacevertex nearest triangle min/median/p95/max and witnesses for both original45930 and newba094 on IDENTICAL b880 body. This is not continuous wholeface maximum. No source supports a biological maximum. Corresponding-point distance changes are bounded by geometry displacement2mm/.75mm; this controls trial drift but cannot excuse a pre-existing large float. Body shape, ungroomed primitive appearance, period gear attestation, loading and final visual acceptance remain open.
