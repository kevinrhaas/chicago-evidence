import pathlib,sys,contextlib,json,runpy,time
P=pathlib.Path(__file__).parent;sys.path.insert(0,str(P));import check_pairs
for case in ['candidate_changed4','candidate_all36_patch']:
 with (P/(case+'-run.log')).open('w')as f,contextlib.redirect_stdout(f):check_pairs.run(case)
 r=json.loads((P/(case+'-intersections.json')).read_text());print('SAT',case,r['criterion_pass'],r['elapsed_s'],flush=True)
 if not r['criterion_pass']:raise SystemExit('STOP first SAT failure')
for case in ['candidate_changed4','candidate_all36_patch']:
 sys.argv=['measure_separation.py',case]
 with (P/(case+'-separation-run.log')).open('w')as f,contextlib.redirect_stdout(f):runpy.run_path(str(P/'measure_separation.py'),run_name='__main__')
 r=json.loads((P/(case+'-separation.json')).read_text());print('DISTANCE',case,r['criterion_pass'],r['minimum_m'],r['elapsed_s'],flush=True)
 if not r['criterion_pass']:raise SystemExit('STOP first distance failure')
