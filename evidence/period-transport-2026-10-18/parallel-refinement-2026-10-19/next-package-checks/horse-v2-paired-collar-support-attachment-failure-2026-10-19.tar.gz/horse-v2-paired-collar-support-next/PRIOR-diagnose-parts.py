from pathlib import Path
import numpy as np,json,time
from check_pairs import snapshot,PARTS
import check_pairs as controls
from unsigned_distance import distances
P=Path(__file__).parent;cm,horse_data=snapshot('horse_candidate');gm,gear=snapshot('gear_v5');groups=[g for g in gm['meshes']if g['name']in PARTS];rows=[];started=time.time()
for ri,info in enumerate(cm['rows']):
 horse=np.asarray(horse_data[ri],float);lo=horse.min(1);hi=horse.max(1)
 for group in groups:
  best=.1;witness=None
  for fi,a in enumerate(gear[ri,group['start']:group['start']+group['count']]):
   a=np.asarray(a,float);gap=np.maximum(0,np.maximum(lo-a.max(0),a.min(0)-hi));ix=np.flatnonzero(np.sqrt((gap*gap).sum(1))<best)
   if not len(ix):continue
   ds=distances(a,horse[ix]);k=int(ds.argmin())
   if ds[k]<best:best=float(ds[k]);witness={'gear_triangle':fi,'horse_triangle_global':int(ix[k]),'gear_points_m':a.tolist(),'horse_points_m':horse[ix[k]].tolist()}
  assert witness and best<.1
  rows.append({**info,'part':group['name'],'minimum_m':best,'witness':witness})
 (P/'FAILED-diagnostic-perpart-partial.json').write_text(json.dumps({'FAILED_TRIAL_NOT_ACCEPTANCE':True,'rows':rows,'elapsed_s':time.time()-started},indent=2)+'\n')
 if ri%10==0:print(ri,{g['name']:next(r['minimum_m']for r in reversed(rows)if r['part']==g['name'])for g in groups},flush=True)
 if controls.STOP:raise SystemExit(130)
summary={g['name']:min((r for r in rows if r['part']==g['name']),key=lambda r:r['minimum_m'])for g in groups};(P/'FAILED-diagnostic-perpart.json').write_text(json.dumps({'FAILED_TRIAL_NOT_ACCEPTANCE':True,'completed':True,'summary':summary,'rows':rows,'elapsed_s':time.time()-started},indent=2)+'\n');print({k:v['minimum_m']for k,v in summary.items()},time.time()-started,flush=True)
