// SPDX-License-Identifier: GPL-3.0-or-later
import fs from 'node:fs';import assert from 'node:assert/strict';import {pathToFileURL}from'node:url';
const vendor=process.argv[2];if(!vendor)throw Error('Usage: node check_actual_field.mjs THREE_MODULE_PATH');
const shader=fs.readFileSync(vendor,'utf8');assert(shader.includes('asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5'));
let source=fs.readFileSync(new URL('./studio-environment.js',import.meta.url),'utf8');source=source.replace("import * as T from 'three';",`import * as Actual from '${pathToFileURL(vendor)}';const T={...Actual,PMREMGenerator:class{fromEquirectangular(input){globalThis.captured=input;return {texture:{},dispose(){}}}dispose(){}}};`);
const m=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));m.createStudioEnvironment({});const texture=globalThis.captured;assert.equal(texture.flipY,false);const{width,height,data}=texture.image;
const at=(lon,lat)=>{const u=lon/(2*Math.PI)+.5,v=Math.asin(Math.sin(lat))/Math.PI+.5;const x=Math.min(width-1,Math.floor(u*width)),y=Math.min(height-1,Math.floor(v*height));return{row:y,rgb:Array.from(data.slice((y*width+x)*4,(y*width+x)*4+3))};};
const rows=[];for(const[lon,lat]of[[-.9,.48],[3,.95]]){const north=at(lon,lat),south=at(lon,-lat);assert(north.rgb[0]>south.rgb[0]+2);rows.push({lon,lat,north,south});}
const report={passed:true,actualDataTextureFlipY:texture.flipY,mapping:'Actual Three shader v=asin(dir.y)/pi+.5',rows,scope:'Actual generated float field sampled with actual Three DataTexture default; PMREM GPU filtering not exercised by CPU control.'};fs.writeFileSync(new URL('./actual-field-control.json',import.meta.url),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
