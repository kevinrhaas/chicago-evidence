# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import argparse,hashlib,tarfile,json
P=Path(__file__).parent
cli=argparse.ArgumentParser();cli.add_argument('--output-dir',type=Path,required=True);cli.add_argument('--source-package',type=Path,required=True);args=cli.parse_args()
archive=args.source_package
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='a185e7cf0105a04b772d5f690cebb2b645f7557a00ad262bd97c2f8405849aab'
out=args.output_dir;out.mkdir(parents=True,exist_ok=True)
with tarfile.open(archive)as t:
 for m in t.getmembers():
  if not m.name.startswith('files/chicago/4d/')or not m.isfile():continue
  rel=Path(m.name).relative_to('files/chicago/4d');assert '..'not in rel.parts
  f=out/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(t.extractfile(m).read())
demo=out/'renderers/web/transport/carriage-c02/demo.js';s=demo.read_text()
s=s.replace("try {", "import {createStudioEnvironment} from './studio-environment.js';\ntry {",1)
s=s.replace("const response=await fetch", "const studioEnabled=new URLSearchParams(location.search).get('environment')==='studio';\nconst studio=studioEnabled?createStudioEnvironment(renderer):null;if(studio){scene.environment=studio.texture;scene.environmentIntensity=1;}\nconst response=await fetch",1)
s=s.replace("return {view:name", "return {environment:studioEnabled?'studio':'baseline',view:name",1)
s=s.replace("renderer.dispose();scene.clear();", "studio?.dispose();renderer.dispose();scene.clear();")
demo.write_text(s)
(out/'renderers/web/transport/carriage-c02/studio-environment.js').write_bytes((P/'studio-environment.js').read_bytes())
asset=out/'renderers/web/transport/carriage-c02/carriage-c02.glb';assert hashlib.sha256(asset.read_bytes()).hexdigest()=='ddda1b89b330c889d69acaf55b79c4a114d193ff140e9e27c11cf74fc7f16eb6'
(out/'BUILD.json').write_text(json.dumps({'source_package_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'asset_sha256':hashlib.sha256(asset.read_bytes()).hexdigest(),'variant':'?environment=studio','default':'baseline environment remains null; original direct lights/exposure/materials retained','scope':'Illumination only; no geometry, historical finish, material identification or photographic acceptance'},indent=2)+'\n')
(out/'tools/transport/smoke_studio.cjs').write_bytes((P/'smoke_studio.cjs').read_bytes())
print(out)
