# Actual browser qualification, 2026-10-19 — mechanical scope only

Final run `browser-followup/receipt.json`: desktop1280×800 and mobile390×780,6cases each (one/two fixture actors ×Light/Balanced/Full),1599checks perviewport, zero pageerrors or failedrequests. Chromium launched with ANGLESwiftShader; browser CLOSED/process exit0. No app writes. Actual webfixtureGLBs, Meshoptdecode, embeddedfixturePNG bound as real browserimages, actualskin/clip/morph code and existingactor/assetcache used; no CPUtexturestub in this run. Source/input SHA256s retained in receipt, controlledPNGcaptures retained. Fixture is nobody: MarkBeaubien/Abbot IDs are existing-record references solely exercising originalidentitypath, not likeness or wardrobe acceptance. Photographic/production gates open.

Preserved first failure: `browser-receipts/` plus `browser.log` contains desktop6pass, mobile calibrationfails beforeFull due harness disposingautoLODcalibration while its nextLODparse waspending. No runtime fix/waiver: final calibration explicitlyfixes allowedLOD andawaitspending. Separately finalrun intentionallydisposes originalHumanActor DURING controlled pendingactualfetch/parse, then releasesfetch and awaitsactualpending promise; noactors remain andcacheeventuallyempty. Thus eventualAPIcleanup is actually exercised rather than hidden. No newsourceengine.

Actual deformed indexedskin displacement from walk0→30%cycle is~.67273m at allLODs (syntheticmechanicalclip, not biomechanicalacceptance). Blinksurface displacement~.012836m wherefaceexists; Light omitsface. Quotas, loadedLODphasecontinuity, cull/return, personidentity, wrongdate andbacklogrefusals tested. Disposal returns actual WebGLlogicalbuffer/knowntextureallocations AND renderergeometry/textureobjectcounts to percasebaseline. RealinputPNG decodedpositivewidth/height, texturemapsbound; does not prove pixelphotographicquality.

## Measured costs

Eachcase120renderedsamples after5warmframes. Valuesinclude floor/shadowpasses, fixed1×DPR and syntheticflatfixtureenvironment; no towncostcredit. Timings distinguish wallCPUupdate, rendercommandsubmit and forcedWebGLcompletion(`gl.finish`) walltime. They are not hardwareGPUtimerquery, phoneperformance, vsynccadence or fulltownp95.

| Tier/count | Desktop draws/triangles | Mobile draws/triangles |
|---|---|---|
| Light1 |6/470|6/470|
| Light2 |11/938|11/938|
| Balanced1 |11/4026|11/4026|
| Balanced2 |21/8050|21/8050|
| Full1 |11/7338|11/4026|
| Full2 |21/14674|21/11362|

Fullmobile automaticallyselects coarser/mixedLODs at actualcamera distances; counts are observed, not normalized acrosscameras. CalibrationfixedhighestallowedLOD provides conservative fixtureadmissioncost. Worst sampledCPUupdatep95.3ms; forcedcompletionwallp95 desktop1.9ms/mobile.8ms. Do not infer fastermobilehardware from smallerbuffer. ActualLight oneactoradds5calls to1callfloor; cannot fit town's existing1callheadroom. Baseline/traffic share no futurebudgetcredit.

Onevs twoactors on sameLOD holdslogicalgeometrybufferstorage identical (Light12068B, Balanced41300B, Full71108B desktop including140Bfloor). Extraactor adds20480Blogicaltexturestorage in these cases despite sharedgeometry: independent skeletonpalettes have realcost. Actual postrenderCPUskinnedpalettearrays are20480B peractor,40960B twoactors; Three pads boneMatrices when creating bone textures, so preupload rawpalettebytes are smaller. Currentgenerousfixturecap remainedsafe; preuploadpalettecount alone is not a tight GPUadmissionbound. Use actualpostuploadreceipt/capacity beforeproduction.

MobileFull retains112268Blogicalbufferstorage afterLOD0→LOD1 swap because currentprototype holdsallallowedLODsourcecache refs. This is real conservative memoryoverhead, not efficientpopulationLODresidency. IdenticalfixturePNG images acrossdifferentLODfiles are separatedecodedtextures. Sharedgeometry/material reuse is proven within sameasset/LOD clones, not crossLOD image/componentatlas dedup. T1792componentassembly/sharedimageoptimization remainsopen.

Allocationtelemetry instruments actualWebGLallocationcalls: logicalbufferdata lengths and knowntextureformat/mipstorage, deletion returns tobaseline140Blogicalbuffers/1048604Bknowntexturestorage. Two initial texturecalls remainunclassified; counterretained. Driverpadding/VRAMresidency/renderbuffers/programs/VAOs/OSGPUmemory remainunknown. Never label knownbytes totalphysicalGPUmemory.

## Visual gap still open

Actuallyopened desktopfull2 and mobilefull2 PNGs with view_image. Realfixtureweave isvisible ongarments; primitivegreyheads/Tpose areintentionally mechanical. Mobile2actor captures crop outerhands at viewportedges. Therefore all12functional/GPUcleanup casespass, but fullbodyimageframing has NOTqualified. Capturesarekept unchanged; no extra browserstarted after windowclosed. Separateoutsidecamera-fit proposal can resolve before laterimagequalification. No claim that these screenshots demonstrate photographicpeople.

Portablepatch stagedseparately; root owns anyapplication/CIintegration. Existingactorbrowserworkflow stillneeded; namedresidentart/policyqualification, realcomponentassembly, actualsharedtownhumans+trafficbudget/allstands and physicalphoneproof areunfinished.
