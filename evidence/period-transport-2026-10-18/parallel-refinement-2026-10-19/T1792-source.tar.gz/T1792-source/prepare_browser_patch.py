# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import difflib
D=Path(__file__).resolve().parent
runner=(D/'browser-runner.mjs').read_text().replace("import{createServer}from'node:http';", "import{createServer}from'node:http';import{execSync}from'node:child_process';")
a=runner.index("const module=await import(");b=runner.index('const pw=',a)
runner=runner[:a]+"let module;try{module=await import(process.env.PW_MODULE_PATH??'playwright');}catch(error){if(process.env.PW_MODULE_PATH)throw error;const modules=execSync('npm root -g',{encoding:'utf8'}).trim();module=await import(path.join(modules,'playwright/index.js'));}"+runner[b:]
(D/'portable-browser-runner.mjs').write_text(runner)
files={
 'tools/human_population.html':(D/'human_population.html').read_text(),
 'tools/human_population_allocations.js':(D/'gpu-allocation.js').read_text(),
 'tools/human_population_browser.mjs':runner,
 'tools/test_human_population_allocations.mjs':(D/'test-allocations.mjs').read_text().replace("'./gpu-allocation.js'","'./human_population_allocations.js'"),
 'docs/RESEARCH/human-population-T1792/BROWSER-REVIEW.md':(D/'BROWSER-REVIEW.md').read_text(),
}
patch=[]
for name,s in files.items():patch.extend(difflib.unified_diff([],s.splitlines(True),fromfile='/dev/null',tofile='b/chicago/4d/'+name))
(D/'browser-harness.patch').write_text(''.join(patch))
