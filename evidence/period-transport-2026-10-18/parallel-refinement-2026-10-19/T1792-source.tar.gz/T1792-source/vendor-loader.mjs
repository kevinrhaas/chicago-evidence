// Test-only Node adapter: resolves application's existing browser import-map targets.
import {pathToFileURL}from'node:url';
const vendor='/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/';
export async function resolve(specifier,context,next){if(specifier==='three')return{url:pathToFileURL(vendor+'three.module.js').href,shortCircuit:true};if(specifier.startsWith('three/addons/'))return{url:pathToFileURL(vendor+'addons/'+specifier.slice(13)).href,shortCircuit:true};return next(specifier,context);}
