// SPDX-License-Identifier: GPL-3.0-or-later
// Logical storage requested at the actual WebGL API, NOT measured physical VRAM.
export function instrumentLogicalAllocations(gl){
 const buffers=new Map(),textures=new Map(),original=new Map();let unknownTextureCalls=0;
 const bufferBinding=target=>({[gl.ARRAY_BUFFER]:gl.ARRAY_BUFFER_BINDING,[gl.ELEMENT_ARRAY_BUFFER]:gl.ELEMENT_ARRAY_BUFFER_BINDING,[gl.UNIFORM_BUFFER]:gl.UNIFORM_BUFFER_BINDING,[gl.COPY_READ_BUFFER]:gl.COPY_READ_BUFFER_BINDING,[gl.COPY_WRITE_BUFFER]:gl.COPY_WRITE_BUFFER_BINDING})[target];
 const texture=target=>gl.getParameter(target===gl.TEXTURE_2D?gl.TEXTURE_BINDING_2D:gl.TEXTURE_BINDING_CUBE_MAP);
 const bytes=(format,type)=>{
  if(format===gl.RGBA32F)return 16;if(format===gl.RGBA16F)return 8;
  if([gl.RGBA,gl.RGBA8,gl.SRGB8_ALPHA8].includes(format)&&type===gl.UNSIGNED_BYTE)return 4;
  if([gl.RGB,gl.RGB8,gl.SRGB8].includes(format)&&type===gl.UNSIGNED_BYTE)return 3;
  if([gl.RED,gl.R8].includes(format)&&type===gl.UNSIGNED_BYTE)return 1;
  if([gl.RG,gl.RG8].includes(format)&&type===gl.UNSIGNED_BYTE)return 2;
  return null;
 };
 const remember=(target,level,width,height,bpp,explicit=null)=>{
  const t=texture(target);if(!t||!Number.isInteger(width)||!Number.isInteger(height)||(bpp===null&&explicit===null)){unknownTextureCalls++;return;}
  let levels=textures.get(t);if(!levels){levels=new Map();textures.set(t,levels);}levels.set(`${target}:${level}`,{target,level,width,height,bpp,bytes:explicit??width*height*bpp});
 };
 const wrap=(name,after)=>{if(typeof gl[name]!=='function')return;const old=gl[name];original.set(name,old);gl[name]=function(...args){const out=old.apply(this,args);after(args);return out;};};
 wrap('bufferData',a=>{const binding=bufferBinding(a[0]),buffer=binding===undefined?null:gl.getParameter(binding);if(buffer)buffers.set(buffer,typeof a[1]==='number'?a[1]:a[1]?.byteLength??0);});
 wrap('deleteBuffer',a=>buffers.delete(a[0]));
 wrap('texImage2D',a=>{const isImage=a.length===6,width=isImage?a[5]?.width:a[3],height=isImage?a[5]?.height:a[4],type=isImage?a[4]:a[7];remember(a[0],a[1],width,height,bytes(a[2],type));});
 wrap('compressedTexImage2D',a=>remember(a[0],a[1],a[3],a[4],null,a.at(-1)?.byteLength??null));
 wrap('texStorage2D',a=>{const bpp=bytes(a[2],gl.UNSIGNED_BYTE);for(let i=0;i<a[1];i++)remember(a[0],i,Math.max(1,a[3]>>i),Math.max(1,a[4]>>i),bpp);});
 wrap('generateMipmap',a=>{const levels=textures.get(texture(a[0]));if(!levels)return;for(const base of [...levels.values()].filter(l=>l.level===0&&l.bpp!==null)){let w=base.width,h=base.height,level=0;while(w>1||h>1){w=Math.max(1,w>>1);h=Math.max(1,h>>1);remember(base.target,++level,w,h,base.bpp);}}});
 wrap('deleteTexture',a=>textures.delete(a[0]));
 return{snapshot(){return{logical_buffer_storage_bytes:[...buffers.values()].reduce((n,b)=>n+b,0),logical_known_texture_storage_bytes:[...textures.values()].reduce((n,m)=>n+[...m.values()].reduce((s,v)=>s+v.bytes,0),0),buffer_objects:buffers.size,texture_objects:textures.size,unclassified_texture_calls:unknownTextureCalls,scope:'Actual WebGL allocation-call logical storage; excludes driver padding/VRAM residency, renderbuffers/programs/VAOs/OSGPU memory. Texture storage may differ physically.'};},restore(){for(const[name,fn]of original)gl[name]=fn;}};
}
