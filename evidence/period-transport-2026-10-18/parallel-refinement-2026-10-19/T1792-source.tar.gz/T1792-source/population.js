// SPDX-License-Identifier: GPL-3.0-or-later
// T-1792 additive mechanical study over the existing human layer, never a scene mount.
import { resolveHumanIdentity } from './human-identity.js';
import { HUMAN_TIERS } from './humans.js';
const insist=(ok,msg)=>{if(!ok)throw Error('human population: '+msg);};
const finite=x=>typeof x==='number'&&Number.isFinite(x);
export function measureSharedHumanResources(gltfs){
 const buffers=new Set(),textures=new Set(),geometries=new Set(),materials=new Set(),skeletons=new Set();let cpuGeometryBytes=0,primitiveSubmissions=0,triangleInstances=0,undecodedTextures=0;
 for(const gltf of gltfs)gltf.scene.traverse(o=>{if(!o.isMesh)return;if(o.skeleton)skeletons.add(o.skeleton);geometries.add(o.geometry);for(const m of[].concat(o.material)){materials.add(m);for(const v of Object.values(m))if(v?.isTexture)textures.add(v);}
  const g=o.geometry;for(const a of[g.index,...Object.values(g.attributes),...Object.values(g.morphAttributes).flat()].filter(Boolean)){const array=a.array??a.data?.array;if(array&&!buffers.has(array.buffer)){buffers.add(array.buffer);cpuGeometryBytes+=array.buffer.byteLength;}}
  primitiveSubmissions+=Array.isArray(o.material)?Math.max(1,g.groups.length):1;triangleInstances+=(g.index?.count??g.attributes.position.count)/3;
 });
 for(const texture of textures)if(!(texture.image?.width>0&&texture.image?.height>0))undecodedTextures++;
 return{cpu_geometry_backing_bytes:cpuGeometryBytes,cpu_skeleton_palette_bytes:[...skeletons].reduce((n,s)=>n+(s.boneMatrices?.byteLength??0),0),unique_geometries:geometries.size,unique_materials:materials.size,unique_textures:textures.size,undecoded_textures:undecodedTextures,primitive_submissions:primitiveSubmissions,triangle_instances:triangleInstances,gpu_geometry_bytes:null,gpu_texture_bytes:null,scope:'Actual decoded object/buffer ownership; backing buffers count whole allocations. Primitive count is not measured renderer draws; GPU bytes remain unmeasured.'};
}
export function makePopulationScheduler({maxActors,maxAnimationUpdatesPerFrame,maxFaceUpdatesPerFrame,maxBacklog_s=.5}){
 insist([maxActors,maxAnimationUpdatesPerFrame,maxFaceUpdatesPerFrame].every(Number.isInteger)&&maxActors>0&&maxAnimationUpdatesPerFrame>0&&maxFaceUpdatesPerFrame>=0&&maxBacklog_s>0,'bounded scheduler limits');
 const clocks=new Map();let cursor=0;
 return{plan(actors,dt,cameraPosition){
  insist(finite(dt)&&dt>=0&&dt<=.1,'substep population frames to at most100ms');insist(actors.length<=maxActors,'actor cap exceeded');
  const result=new Map(),ids=new Set(actors.map(a=>a.id));for(const id of clocks.keys())if(!ids.has(id))clocks.delete(id);
  let animationLeft=maxAnimationUpdatesPerFrame,faceLeft=maxFaceUpdatesPerFrame;const ordered=[...actors].sort((a,b)=>a.id.localeCompare(b.id));
  for(let i=0;i<ordered.length;i++){
   const a=ordered[(i+cursor)%ordered.length],d=cameraPosition.distanceTo(a.root.position),interval=d<8?1/30:d<20?1/15:1/5;
   let clock=clocks.get(a.id);if(!clock){clock={animation:0,face:0};clocks.set(a.id,clock);}
   if(d<70)clock.animation+=dt;else clock.animation=0;
   if(d<20&&maxFaceUpdatesPerFrame>0)clock.face+=dt;else clock.face=0;
   insist(clock.animation<=maxBacklog_s+1e-9,'animation backlog exceeds qualified update budget for '+a.id);
   const animate=d<70&&clock.animation+1e-12>=interval&&animationLeft>0;
   const face=d<20&&clock.face+1e-12>=1/15&&faceLeft>0;
   const work={animate,face,animationDt:animate?clock.animation:0,faceDt:face?clock.face:0};
   if(animate){clock.animation=0;animationLeft--;}if(face){clock.face=0;faceLeft--;}
   result.set(a.id,work);
  }
  if(ordered.length)cursor=(cursor+1)%ordered.length;
  return result;
 },remove(id){clocks.delete(id);},get tracked(){return clocks.size;}};
}
export function createHumanPopulationStudy({layer,sceneId,people,assets,limits,qualification,measurement}){
 insist(layer?.add&&layer?.update&&layer?.remove,'existing human layer required');
 insist(qualification?.mode==='fixture_mechanical_only'&&qualification.assetId==='c4d_fixture','named resident assets remain unaccepted; only explicit mechanical fixture allowed');
 insist(qualification.scene===String(sceneId)&&Array.isArray(people),'fixture scene/date membership required');
 insist(measurement?.scope==='synthetic_test_budget_only'||measurement?.scope==='actual_fixture_browser','explicit fixture measurement scope');
 insist(['geometryBytes','textureBytes','draws','triangles'].every(k=>finite(limits?.[k])&&limits[k]>=0&&finite(measurement[k])&&measurement[k]>=0),'bounded actual/synthetic-tagged fixture resource preconditions');
 insist(measurement.baseline?.tier===limits.tier&&measurement.baseline.viewport&&measurement.baseline.stand&&['draws','triangles'].every(k=>finite(measurement.baseline[k])&&measurement.baseline[k]>=0),'same-tier measured/synthetic-tagged baseline required');
 insist(Number.isInteger(limits.maxActors)&&limits.maxActors>0,'actor cap');insist(finite(limits.skeletonBytes)&&limits.skeletonBytes>=0,'explicit skeleton palette allocation cap');
 if(limits.tier==='light')insist(limits.totalSceneDrawLimit<=90&&limits.totalSceneTriangleLimit<=1190000,'strict Light ceilings');
 const scheduler=makePopulationScheduler(limits),reservations=new Map();let shared=null,sharedHeld=false,disposed=false,preparing=null;
 insist(layer.count===0,'study requires its own existing empty human layer');
 insist(HUMAN_TIERS[limits.tier],'known tier required');
 const sharedLods=HUMAN_TIERS[limits.tier];
 async function prepare(){
  if(shared)return shared;
  if(preparing)return preparing;
  preparing=(async()=>{
   const acquired=[];
   try{const gltfs=[];for(const lod of sharedLods){gltfs.push(await assets.acquire(qualification.assetId,lod));acquired.push(lod);}const facts=measureSharedHumanResources(gltfs);insist(!disposed,'disposed during shared prepare');insist(facts.cpu_geometry_backing_bytes<=limits.geometryBytes,'actual shared decoded geometry exceeds cap');shared=facts;sharedHeld=true;return shared;}
   catch(error){for(const lod of acquired)assets.release(qualification.assetId,lod);throw error;}
  })();
  try{return await preparing;}finally{preparing=null;}
 }
 return{productionEnabled:false,qualification,async add(instance){
  insist(!disposed,'disposed');insist(!instance.anonymous_profile_id&&instance.person_id,'no anonymous fallback in population study');
  const identity=resolveHumanIdentity(instance,{sceneId,people});insist(instance.appearance?.asset_id===qualification.assetId,'unaccepted body/wardrobe asset');
  insist(instance.display==='shown'&&identity.person&&!reservations.has(instance.id)&&!layer.get(instance.person_id)&&![...reservations.values()].some(r=>r.personId===instance.person_id),'duplicate/withheld identity');
  insist(!(identity.person.review_required||identity.person.touches_removal)||instance.review_required,'person review metadata dropped');
  insist(reservations.size<limits.maxActors,'population cap');
  const count=reservations.size+1;
  insist(measurement.draws*count<=limits.draws&&measurement.triangles*count<=limits.triangles,'measured/synthetic-tagged peractor frame allowance exceeded');
  insist(measurement.baseline.draws+measurement.draws*count<=limits.totalSceneDrawLimit&&measurement.baseline.triangles+measurement.triangles*count<=limits.totalSceneTriangleLimit,'total scene including prior humans/traffic exceeds cap');
  insist(measurement.geometryBytes<=limits.geometryBytes&&measurement.textureBytes<=limits.textureBytes,'shared allocation cap');
  reservations.set(instance.id,{personId:instance.person_id});
  try{await prepare();insist(!disposed,'disposed during prepare');const actor=layer.add(instance,{person:identity.person,identity});try{insist(actor.tier===limits.tier,'layer tier differs from resource qualification');await actor.setLod(limits.tier==='light'?2:limits.tier==='balanced'?1:0);insist(!disposed,'disposed during actor load');const group=measureSharedHumanResources([{scene:layer.group}]);insist(group.cpu_skeleton_palette_bytes+shared.cpu_skeleton_palette_bytes<=limits.skeletonBytes,'actual source+clone skeleton palettes exceed cap');}catch(error){layer.remove(actor.id);throw error;}return actor;}
  catch(error){reservations.delete(instance.id);throw error;}
 },update(dt,camera,visitor=null){insist(!disposed,'disposed');insist(layer.count===reservations.size&&layer.actors.every(a=>reservations.has(a.id)&&a.tier===limits.tier&&(a.lod<0||sharedLods.includes(a.lod))),'unbudgeted external actor');const eye=camera.getWorldPosition?camera.getWorldPosition(camera.position.clone()):camera.position;const plan=scheduler.plan(layer.actors,dt,eye);layer.update(dt,camera,visitor,plan);return plan;},remove(id){reservations.delete(id);scheduler.remove(id);return layer.remove(id);},get facts(){return shared;},get groupFacts(){return measureSharedHumanResources([{scene:layer.group}]);},get count(){return reservations.size;},dispose(){if(disposed)return;disposed=true;for(const id of reservations.keys())layer.remove(id);reservations.clear();if(sharedHeld)for(const lod of sharedLods)assets.release(qualification.assetId,lod);sharedHeld=false;}};
}
