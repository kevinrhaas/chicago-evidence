# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import difflib
D=Path(__file__).resolve().parent
out=[]
old=Path('/workspace/chicago/chicago/4d/renderers/web/js/humans.js').read_text()
new=(D/'humans.js').read_text()
out.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/chicago/4d/renderers/web/js/humans.js',tofile='b/chicago/4d/renderers/web/js/humans.js'))
loader=(D/'vendor-loader.mjs').read_text().replace("import {pathToFileURL}from'node:url';", "import {pathToFileURL,fileURLToPath}from'node:url';import path from'node:path';").replace("const vendor='/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/';", "const vendor=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../renderers/web/vendor/three-0.185.1')+'/';")
test=(D/'test.mjs').read_text().replace("from'./staging/humans.js'", "from'../renderers/web/js/humans.js'").replace("from'./staging/population.js'", "from'../renderers/web/js/human-population.js'").replace("import assert from 'node:assert/strict';", "import assert from 'node:assert/strict';import path from'node:path';import{fileURLToPath}from'node:url';").replace("const ROOT='/workspace/chicago/chicago/4d',", "const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),")
for target,s in [('renderers/web/js/human-population.js',(D/'population.js').read_text()),('tools/test_human_population.mjs',test),('tools/human_population_vendor_loader.mjs',loader),('docs/RESEARCH/human-population-T1792/README.md',(D/'README.md').read_text()),('docs/RESEARCH/human-population-T1792/cpu-receipt.json',(D/'cpu-receipt.json').read_text())]:
 out.extend(difflib.unified_diff([],s.splitlines(True),fromfile='/dev/null',tofile='b/chicago/4d/'+target))
(D/'population-parcel.patch').write_text(''.join(out))
