# Isolated finite horse transition player study

Original outside-app proposal. No app files changed. Browser study source is ready but has NOT been run; no rendered, coupled-gear, arbitrary-entry, photographic or production acceptance is claimed.

## Inputs and executed proof

The assets are the previously measured original finite stop10 and start/change20 clips. Exact input SHA256 values are in asset-inputs.json; broader 1001-pose source receipts remain in the separate immutable stop/transition archives. cpu-player-validation.json records this actual Three GLTFLoader/AnimationMixer/SkinnedMesh player test: 30 profiles at 101 poses, actor translated (2,0,-1) and yaw .41rad, unchanged 100 authored sole vertices; worst sole Y -0.000020736825631189172m and maximum wrapper distance error 2.220446049250313e-16m. This samples finite poses only, not continuous-time contact or anatomical acceptance.

Executed command (local proof loader only; its absolute vendor path is not an installation proposal):

    node --experimental-loader ./three-loader.mjs ./test_cpu.mjs

No local Blender used. index.html/study.js were syntax checked only. Root requested a browser/CPU-heavy hold during full preflight; do not confuse the ready harness with actual browser acceptance.

## Stable player API

Import createFinitePlayer from finite-player.js. Construct with {T,actor,mixer,clips,profiles,locomotion,onState}. actor must contain the complete skeleton and skinned meshes. Supply cyclic clips plus the 30 finite clips. Normalize stop profiles with exit_clip:'idle', exit_phase:0. Unit scale, fixed yaw and straight wrapper motion only. Suspend other mixer clocks while this player owns motion.

playFinite({profileName,entry,signal}) requires exact entry {clip,phase,speed_m_s,heading_change_rad,remaining_distance_m,distance_m}. It checks the actual source bone pose as well as metadata before mutation, rejects unsupported cases, and plays LoopOnce/clamp without joint crossfade, root lift or scaling. tick(dt) advances finite clip time and exact nonuniform exported wrapper distance. Finite completion enters the explicitly exported cyclic exit phase, preserving overflow time, or holds true idle0 after a stop.

A caller AbortSignal rejects only its waiter with AbortError; it does not interrupt the privately owned recovery. recoverNeutral() returns the same private completion Promise while an idle-exit stop is active. Mounted stopToNeutral must choose only a supported exact stop_walk/trot_phase_000/013/037/062/089 entry, then call playFinite. Repeated/immediate/cancel cleanup must reattach recoverNeutral and keep tick alive until completion. There is no arbitrary-phase stop selector. Moving-exit starts/changes reject recoverNeutral.

Default dispose() requires neutral recovery, awaits it before freezing clocks, and never resets the actor pose. Removing renderer/actor/seat before that Promise resolves is unsafe. Explicit dispose({requireNeutral:false}) is only an unmounted diagnostic convenience; it waits for moving finite completion and returns finalNeutral:false, not a mounted cleanup success.

Result: {completed:true,finalNeutral,distance_m,profileName,generation}. Result distance is the finite boundary; status may include subsequent cyclic overflow. status also exposes observer_errors; telemetry exceptions are recorded without interrupting private recovery. No unsupported success or instantaneous neutral pop is implemented.

CPU tests cover cancellation without motion reset, repeated recovery Promise identity, disposal waiting for neutral, no post-dispose tick effects, actual wrong-pose rejection, unsupported entry without mutation, moving-exit recovery/default-dispose refusal, and clock overflow. Busy rejection and late-abort race deserve explicit additional tests; actual browser lifecycle/UI/gear proofs remain pending.

## Browser study contract

Serve this directory privately with /vendor/ mapped read-only to the pinned app Three directory. The page hash-checks actual assets and exposes window.study for bounded automation. prepare() is an explicit independent study reset to an exact supported entry, not a live transition. setAuto(false) before manual tick sampling. No town actor capacity, phone cost or historical appearance conclusions follow from this isolated scene.

## Licensing

Original procedural horse geometry, finite authored poses and profile data retain CC0-1.0 reconstruction status from their source archives; no external model or plate tracing. Original player/browser/test glue is GPL-3.0-or-later as its headers declare. Three is an external existing dependency, not copied in this parcel. All appearance/anatomy/master/gear/continuous-motion gates remain open.
