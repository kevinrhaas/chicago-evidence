// SPDX-License-Identifier: GPL-3.0-or-later
import {validateProfile, validateEntry, motionState} from './finite-profile.js';
const failure=(name,message)=>Object.assign(new Error(message),{name});
const deferred=()=>{let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no;});return{promise,resolve,reject};};
export function createFinitePlayer({T,actor,mixer,clips,profiles,locomotion,onState=()=>{}}) {
  const clipMap=new Map(clips.map(c=>[c.name,c]));
  const profileMap=new Map(profiles.map(p=>[p.name,p]));
  for(const p of profiles)validateProfile(p,locomotion);
  let generation=0,operation=null,disposed=false,disposing=false,lastResult=null;
  let active=null,activeName=null,observerErrors=[],mode='held',cycle=null,currentDistance=0,currentPhase=0;
  function emit(){try{onState({mode,distance_m:currentDistance,phase:currentPhase,clip:activeName,disposed});}catch(error){observerErrors.push(String(error));}}
  function updateWorld(){actor.updateMatrixWorld(true);actor.traverse(o=>{if(o.isSkinnedMesh)o.skeleton.update();});}
  function activate(name,once,time){
    const clip=clipMap.get(name);if(!clip)throw failure('ContractError','Missing animation '+name);
    mixer.stopAllAction();activeName=name;active=mixer.clipAction(clip);active.reset();active.setLoop(once?T.LoopOnce:T.LoopRepeat,once?1:Infinity);active.clampWhenFinished=once;active.play();active.paused=false;mixer.setTime(time);
  }
  function checkActualEntry(profile,entry){
    validateEntry(profile,entry,locomotion);
    if(!Number.isFinite(entry.distance_m))throw failure('UnsupportedEntryError','Missing owned absolute route distance');
    if(Math.abs(actor.scale.x-1)>1e-9||Math.abs(actor.scale.y-1)>1e-9||Math.abs(actor.scale.z-1)>1e-9||Math.abs(actor.quaternion.x)>1e-9||Math.abs(actor.quaternion.z)>1e-9)throw failure('UnsupportedEntryError','Only unit scale and fixed yaw wrapper supported');
    const source=clipMap.get(profile.initial_clip);if(!source)throw failure('ContractError','Missing source gait');
    let maximumAngle=0;
    for(const track of source.tracks){
      const parsed=T.PropertyBinding.parseTrackName(track.name);
      if(parsed.propertyName!=='quaternion')throw failure('ContractError','Unexpected entry track property');
      const node=actor.getObjectByName(parsed.nodeName);if(!node)throw failure('ContractError','Missing entry bone');
      const values=track.createInterpolant().evaluate(profile.initial_phase*source.duration);
      const expected=new T.Quaternion().fromArray(values).normalize();
      maximumAngle=Math.max(maximumAngle,node.quaternion.clone().normalize().angleTo(expected));
    }
    if(maximumAngle>1e-5)throw failure('UnsupportedEntryError','Actual entry bone pose does not match supported source phase');
    return maximumAngle;
  }
  function distancePosition(op,distance){
    actor.position.copy(op.origin).addScaledVector(op.forward,distance);
    currentDistance=op.baseDistance+distance;
  }
  function callerAbort(op){
    if(operation!==op||op.generation!==generation||op.finished)return;
    op.callerAborted=true;op.waiter.reject(failure('AbortError','Caller canceled; owned finite recovery continues'));
    op.removeAbort();
  }
  function complete(op){
    if(operation!==op||op.generation!==generation)return;
    op.finished=true;op.removeAbort();
    const neutral=op.profile.exit_clip==='idle';
    const result={completed:true,finalNeutral:neutral,distance_m:currentDistance,profileName:op.profile.name,generation:op.generation};
    lastResult=result;operation=null;
    if(neutral){activate('idle',false,0);mode='idle';cycle=null;currentPhase=0;}
    else if(disposing){active.paused=true;mode='held';cycle=null;currentPhase=op.profile.exit_phase;}
    else{activate(op.profile.exit_clip,false,op.profile.exit_phase*clipMap.get(op.profile.exit_clip).duration);mode='cycle';cycle={clip:op.profile.exit_clip,phase:op.profile.exit_phase,elapsed:0,baseDistance:op.baseDistance+op.profile.root_distance_m,origin:actor.position.clone(),forward:op.forward.clone()};currentPhase=op.profile.exit_phase;}
    updateWorld();emit();op.owner.resolve(result);if(!op.callerAborted)op.waiter.resolve(result);
  }
  const api={
    playFinite({profileName,entry,signal}={}){
      try{
        if(disposed||disposing)throw failure('DisposedError','Player disposed or disposing');
        if(operation)throw failure('BusyError','Owned finite motion still active');
        if(signal?.aborted)throw failure('AbortError','Already canceled; nothing moved');
        const profile=profileMap.get(profileName);if(!profile)throw failure('UnsupportedEntryError','Unknown finite case');
        checkActualEntry(profile,entry);
        const waiter=deferred(),owner=deferred(),origin=actor.position.clone();
        const op={generation:++generation,profile,waiter,owner,origin,forward:new T.Vector3(0,0,1).applyQuaternion(actor.quaternion),baseDistance:entry.distance_m,elapsed:0,callerAborted:false,finished:false,removeAbort:()=>{}};
        operation=op;cycle=null;mode='finite';lastResult=null;currentPhase=0;
        const abort=()=>callerAbort(op);if(signal){signal.addEventListener('abort',abort,{once:true});op.removeAbort=()=>signal.removeEventListener('abort',abort);}
        activate(profile.name,true,0);distancePosition(op,0);updateWorld();emit();return waiter.promise;
      }catch(error){return Promise.reject(error);}
    },
    tick(delta){
      if(disposed)return;
      if(!Number.isFinite(delta)||delta<0)throw failure('ClockError','Invalid motion delta');
      if(operation){const op=operation;const overflow=Math.max(0,op.elapsed+delta-op.profile.duration_s);op.elapsed=Math.min(op.profile.duration_s,op.elapsed+delta);currentPhase=op.elapsed/op.profile.duration_s;const state=motionState(op.profile,op.elapsed,locomotion);active.paused=false;mixer.setTime(state.time_s);distancePosition(op,state.distance_m);updateWorld();emit();if(op.elapsed>=op.profile.duration_s){complete(op);if(overflow>0&&mode==='cycle')api.tick(overflow);}}
      else if(mode==='cycle'&&cycle){cycle.elapsed+=delta;const gait=locomotion[cycle.clip],advance=gait.speed_m_s*cycle.elapsed;currentPhase=(cycle.phase+advance/gait.stride_m)%1;actor.position.copy(cycle.origin).addScaledVector(cycle.forward,advance);currentDistance=cycle.baseDistance+advance;active.paused=false;mixer.setTime(currentPhase*clipMap.get(cycle.clip).duration);updateWorld();emit();}
    },
    recoverNeutral(){
      if(operation){if(operation.profile.exit_clip!=='idle')return Promise.reject(failure('RecoveryRequiredError','Moving-exit study has no validated neutral recovery'));return operation.owner.promise;}
      if(lastResult?.finalNeutral)return Promise.resolve(lastResult);
      return Promise.reject(failure('RecoveryRequiredError','No completed or owned neutral recovery'));
    },
    async dispose({requireNeutral=true}={}){
      if(disposed)return{disposed:true,finalNeutral:!!lastResult?.finalNeutral};
      if(requireNeutral&&((operation&&operation.profile.exit_clip!=='idle')||(!operation&&!lastResult?.finalNeutral)))throw failure('RecoveryRequiredError','Neutral recovery required before disposal');
      disposing=true;
      let result=lastResult;
      if(operation)result=await operation.owner.promise;
      disposed=true;generation++;if(active)active.paused=true;mode='disposed';cycle=null;emit();return{...result,disposed:true,finalNeutral:!!result?.finalNeutral};
    },
    get status(){return{mode,generation,clip:activeName,time_s:operation?.elapsed??null,observer_errors:[...observerErrors],activeProfile:operation?.profile.name||null,disposed,disposing,distance_m:currentDistance,phase:currentPhase,lastResult:lastResult?{...lastResult}:null};},
  };
  return api;
}
