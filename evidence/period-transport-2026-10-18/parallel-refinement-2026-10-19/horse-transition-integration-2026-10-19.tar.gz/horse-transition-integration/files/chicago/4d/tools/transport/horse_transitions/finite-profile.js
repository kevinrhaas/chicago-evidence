// SPDX-License-Identifier: GPL-3.0-or-later
// Pure engine-neutral playback math; not a route, mixer, cancel or riding adapter.
export function validateProfile(profile, locomotion) {
  const finite = Number.isFinite;
  if (!profile || !Array.isArray(profile.samples) || profile.samples.length < 2) throw Error('Missing finite distance profile');
  if (!finite(profile.duration_s) || profile.duration_s <= 0 || !finite(profile.root_distance_m)) throw Error('Invalid profile duration/distance');
  if (!finite(profile.exit_phase) || profile.exit_phase < 0 || profile.exit_phase >= 1 || !locomotion[profile.exit_clip]) throw Error('Invalid exit gait/phase');
  let previousTime = -Infinity, previousDistance = -Infinity;
  for (const sample of profile.samples) {
    if (!finite(sample.time_s) || !finite(sample.distance_m) || sample.time_s <= previousTime || sample.distance_m < previousDistance) throw Error('Nonfinite/nonmonotonic profile');
    previousTime = sample.time_s; previousDistance = sample.distance_m;
  }
  const first = profile.samples[0], last = profile.samples.at(-1);
  if (first.time_s !== 0 || first.distance_m !== 0 || Math.abs(last.time_s-profile.duration_s)>1e-7 || Math.abs(last.distance_m-profile.root_distance_m)>1e-9) throw Error('Profile boundary mismatch');
  const gait=locomotion[profile.exit_clip];
  if (!finite(gait.stride_m) || gait.stride_m <= 0 || !finite(gait.speed_m_s) || gait.speed_m_s <= 0) throw Error('Invalid moving exit gait');
  return true;
}
export function sampleDistance(profile, time) {
  if (!Number.isFinite(time) || time < 0 || time > profile.duration_s) throw Error('Outside finite profile time');
  const samples=profile.samples;
  let lo=0, hi=samples.length-1;
  while(hi-lo>1) { const middle=(lo+hi)>>1; if(samples[middle].time_s<=time)lo=middle;else hi=middle; }
  const a=samples[lo], b=samples[hi], fraction=(time-a.time_s)/(b.time_s-a.time_s);
  return a.distance_m+(b.distance_m-a.distance_m)*fraction;
}
export function motionState(profile, elapsed, locomotion) {
  if (!Number.isFinite(elapsed) || elapsed < 0) throw Error('Invalid elapsed time');
  if (elapsed <= profile.duration_s) return {mode:'finite',clip:profile.name,time_s:elapsed,distance_m:sampleDistance(profile,elapsed)};
  const gait=locomotion[profile.exit_clip], distanceAfter=gait.speed_m_s*(elapsed-profile.duration_s);
  return {mode:'cycle',clip:profile.exit_clip,phase:((profile.exit_phase+distanceAfter/gait.stride_m)%1+1)%1,distance_m:profile.root_distance_m+distanceAfter};
}
// Necessary metadata preconditions only, not sufficient actual bone/pose or route safety proof.
export function validateEntry(profile, current, locomotion) {
  const expectedSpeed=profile.initial_clip==='idle'?0:locomotion[profile.initial_clip].speed_m_s;
  if(current.clip!==profile.initial_clip || !Number.isFinite(current.phase) || Math.abs(current.phase-profile.initial_phase)>1e-8)throw Error('Unsupported entry clip/phase; never snap to nearest case');
  if(!Number.isFinite(current.speed_m_s)||Math.abs(current.speed_m_s-expectedSpeed)>1e-8)throw Error('Unsupported entry velocity');
  if(!Number.isFinite(current.heading_change_rad)||Math.abs(current.heading_change_rad)>1e-9)throw Error('Turning transition unverified');
  if(!Number.isFinite(current.remaining_distance_m)||current.remaining_distance_m<profile.root_distance_m)throw Error('Insufficient finite-profile route distance');
  return true;
}
