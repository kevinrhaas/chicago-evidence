// SPDX-License-Identifier: GPL-3.0-or-later
export function resolve(specifier,context,nextResolve){if(specifier==='three')return{url:new URL('../../../renderers/web/vendor/three-0.185.1/three.module.js',import.meta.url).href,shortCircuit:true};return nextResolve(specifier,context);}
