# SPDX-License-Identifier: CC0-1.0
"""Generate isolated contact-transition study from exact original input + recipe.
No app mutation except the explicit --output-dir. No Blender/Node/thirdparty Python.
"""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,tempfile
HERE=Path(__file__).resolve().parent;PROJECT=HERE.parents[2]
parser=argparse.ArgumentParser();parser.add_argument('--horse',type=Path,default=PROJECT/'renderers/web/transport/horse/equine_light_harness_skinned_prototype_01.glb');parser.add_argument('--manifest',type=Path,default=PROJECT/'renderers/web/transport/horse/manifest.json');parser.add_argument('--recipe',type=Path,default=PROJECT/'data/transport/studies/horse-transitions.json');parser.add_argument('--output-dir',type=Path,required=True);args=parser.parse_args();recipe=json.loads(args.recipe.read_text())
def digest(file):return hashlib.sha256(file.read_bytes()).hexdigest()
if digest(args.horse)!=recipe['input_horse_sha256'] or digest(args.manifest)!=recipe['input_manifest_sha256']:raise SystemExit('Transition recipe requires exact licensed/source-sampled horse+manifest; input changed, explicitly re-sample/revalidate. No phase/geometry fallback.')
with tempfile.TemporaryDirectory(prefix='equine-transition-')as temp:
 stop=Path(temp)/'stop';start=Path(temp)/'start';(stop/'input').mkdir(parents=True);start.mkdir();shutil.copyfile(args.horse,stop/'input/equine_light_harness_skinned_prototype_01.glb');shutil.copyfile(args.manifest,stop/'input/manifest.json');(stop/'sampled-initial-states.json').write_text(json.dumps(recipe['sampled_initial_states']))
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TRANSITION_WORK_DIR=str(stop),STOP_DECEL_S=str(recipe['parameters']['deceleration_s']),STOP_STEP_S=str(recipe['parameters']['replant_step_s']),STOP_LIFT_M=str(recipe['parameters']['hoof_lift_m']),STOP_PREFIX='')
 subprocess.run([sys.executable,str(HERE/'plan_stop.py')],env=env,check=True,capture_output=True)
 failures=json.loads((stop/'planner-failures.json').read_text())
 if failures:raise SystemExit('Unreachable/unsettled transition states: '+json.dumps(failures))
 env.update(TRANSITION_WORK_DIR=str(start),TRANSITION_STOP_DIR=str(stop))
 subprocess.run([sys.executable,str(HERE/'plan_starts.py')],env=env,check=True,capture_output=True);subprocess.run([sys.executable,str(HERE/'export_transitions.py')],env=env,check=True,capture_output=True)
 args.output_dir.mkdir(parents=True,exist_ok=True)
 for name in ['start_change_study.glb','transition-profiles.json']:shutil.copyfile(start/name,args.output_dir/name)
 stats={'asset_id':recipe['asset_id'],'status':recipe['status'],'license':recipe['license'],'source_horse_sha256':digest(args.horse),'source_manifest_sha256':digest(args.manifest),'recipe_sha256':digest(args.recipe),'glb_sha256':digest(args.output_dir/'start_change_study.glb'),'glb_bytes':(args.output_dir/'start_change_study.glb').stat().st_size,'finite_clips':len(json.loads((args.output_dir/'transition-profiles.json').read_text())['profiles']),'unchanged_geometry_triangles':14172,'unchanged_mesh_draws':6,'texture_bytes':0,'contract':'finiteLoopOnce+exactexternal+Zdistance/time; targetgaitexitphaseoffset mandatory; noYlift/scale/markers; slowstopthroughneutralNOTdirectgaitblend','open_gates':recipe['open_gates']};(args.output_dir/'manifest.json').write_text(json.dumps(stats,indent=2)+'\n');print(json.dumps(stats))
