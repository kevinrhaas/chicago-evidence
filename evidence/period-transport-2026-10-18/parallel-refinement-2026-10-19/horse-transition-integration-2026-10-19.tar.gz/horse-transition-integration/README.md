# T-2803 portable start/change integration PROPOSAL — unapplied

Actual source proof passed after root releasedCPU. No app/queue writes or new browser. This proposes an ISOLATED data-driven study generator,recipe,assets and pure playback math; it does not modify existing cyclic horse/hitch/T2805 controller or place actors in scenes. Root reviews and applies later. Original source-only and stop archives immutable.

## Exact install map and generation

files/chicago/4d/ contains only proposednewpaths:tools/transport/horse_transitions/,data/transport/studies/horse-transitions.json,andrenderers/web/transport/horse-transitions/{GLB,profiles,manifest}. Newtextpatch in source-data.patch; binaryGLB via replacement-manifest.json old/newSHAmap. No viewer/index or defaultdemo change supplied, so no untestedproductflow activation. Runtimehelper is pureengine-neutral source, not an asyncroute/mixeradapter.

From4dproject:

python tools/transport/horse_transitions/generate.py --output-dir /tmp/equine-transition-rebuild

Tool is stdlibPython, paths derive from its installedlocation, accepts --horse/--manifest/--recipe, writes only outputdir (childbytecode disabled). Recipe contains exacthash-bound actualsampledentry states/secondaryquaternions and declared reconstructionparameters. Changed horse OR manifest bytes reject before output (2realnegativecases). This prevents oldposeevidence silently carrying onto alteredanatomy. Original10stopplans are regenerated internally, then10starts+10slowgaitchanges. No dependency on /workspace paths or siblingarchives in installedsources. Portablegenerator regeneratedGLB/profiles/manifest byte-identically to provenoutputs.

Underlyinghorse frozenSHA89b048...,manifestSHA6d5ccc...; fullhashes in recipe and evidence. Original geometry/nodes/materials/skin/rest/socket/accessor/binaryprefix and all3oldanimations exact. NewGLB2858348bytes,SHA5743122fb7c74e68802ec6b4325962894b1a592aeb33e1de1c90c1fa829c1fda. Same14172geometrytriangles,6materialmeshes,15joints,0textures. Extra animationbytes are an isolatedstudycost, not a town/mobilecapacity claim.

## Actual proof and preserved failures

Actual GLTFLoader+AnimationMixer+SkinnedMesh,1001poses EACH20clips,unchanged100authoredsolevertices and fullmeshsurface endpoints. All20pass unchanged20mmslide/5mmheight/−1mmpenetration gates;24headneckjoinpairs0. WorstsoleY−30.075µm,maxplannedplantedheight.239020mm,worldZdrift.021566mm,full3Dplanteddriftbound.250064mm. Sampledcontactflags conservatively classify intervals; no replacement/shiftedfootmarkers. Fullmeshsurfaceentrydelta≤.085µm,exitactualtargetgaitdelta≤.102µm (100µm gateunchanged).

First endpointFAIL start_walk_exit_490=139.690625µm retained under evidence/rejected-v1-endpoint includingexactfailedGLB/source/receipt. Mirroredsourcegait resampling was not exact at thisphase. Corrected with actualsourcegaitFK ankletargets, quinticcorrection during precedingAIRBORNE block then constantlandedtarget; no plantedjointblend/rootYlift/scale. Actualcorrectedall20rerun passes. Original−22.9066mm walk→idle jointblendfail also retained as context; priorstoplong-decel unreachablefailures remain in immutable stoparchive.

Khronos0errors/0warnings; twoindependent portablegeneration outputs exact; actualportablevalidator runpassed. evidence/ includes receipts. Purefiniteprofile math validates20actualprofiles,analyticnonuniforminterpolation,9negativeprofilecases and100unsupportedentryclip/phase/speed/turn/remainingdistance cases,withoutinputmutation. These metadata preconditions are necessary but not sufficient actualpose/route safety proof.

## Mandatory finite distance/phase/frame contract

Use one-shot LoopOnce+clampWhenFinished and matching exact external+Zdistance/time sample (binarysearch interpolation; never constantstride duringfiniteclip). Translate the common horse actorwrapper containing BOTHskinnedmeshes andbones; rootY=0,scale1. Do not also translate rootjoint or add asecondconstantstride term. No phase-wrap/modulo on finiteplayback, no quaternioncrossfade/nearestphase snap.

At exit, activate actualtargetcyclicgait at explicit exit_phase and continue distanceD+speed*elapsed; phase=exit_phase+(distance−D)/stride modulo1. Keep this offset; resettingphase0 creates a jump. finite-profile.js implements only that puremath; actualmixer/actionownership/cancel lifecycle awaits tests. Start contains preparatorysteps while stationary thenaccelerates; changes are a finiteSTOP/replant→START sequence throughtrue neutral, not a directcontinuousspeed blend. Starts.946–1.5s,changes up to2.675s. Finitecoast distance requires route space; noafter-routeend fallback.

Currentproof only idle0starts and5exactwalk/trotentryphases at exportedvelocity/straightheading. Verifyactualcurrentpose; never choose nearestcase and snap. Geometry is unchanged but newgear/rider contact at replant extrema NOTtested. Coupledhead/worldbinding needs correct parentinverse:gearroot followsactor; gearhead LOCAL transform=inverse(gearrootworld)*horseheadworld, not rawworldtranslation copied underalreadytranslatedgearroot (would doublemotion). Camera/hand/bit/rein constraints require their own actualproof. No browser,turn/cancel,mountedcamera,pressure,biomechanics/sourcephoto/master/LOD acceptance follows.

## Verification after root applies proposal

node --experimental-loader ./tools/transport/horse_transitions/three-loader.mjs tools/transport/horse_transitions/validate_actual_mesh.mjs /tmp/equine-transition-rebuild

node tools/transport/horse_transitions/test_finite_profile.mjs /tmp/equine-transition-rebuild

node tools/transport/horse_transitions/validate_khronos.cjs /tmp/equine-transition-rebuild/start_change_study.glb /tmp/transition-khronos.json

Three resolves pinnedprojectvendor via hook; gltf-validator resolves ordinaryNode dependency or caller's existingNODE_PATH (no install/download performed). OptionalCLI paths default to installedprojecthorse/manifest. Currentportableactualrun used retainedexactbase,matchingappfreeze. Root must still run approvedbrowsercontrolledviews/finiteplayback/atomicmixer handoff,gear/route/asyncguardsandappropriate fullgate before treating nextcheckpoint as accepted. License/liberty append proposals included; no ticketclosure recommended.
