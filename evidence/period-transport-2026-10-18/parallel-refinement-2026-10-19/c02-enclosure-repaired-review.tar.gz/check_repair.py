import json,struct,hashlib
from pathlib import Path
p=Path(__file__).parent;b=p.parent/'carriage-c02-next'
def glb(path):
 raw=path.read_bytes();n=struct.unpack_from('<I',raw,12)[0];return json.loads(raw[20:20+n]),raw[28+n:]
a,ab=glb(b/'export/carriage-c02.glb');c,cb=glb(p/'export/carriage-c02.glb')
def skeleton(g):
 return [{k:v for k,v in n.items() if k not in ['children']} for n in g['nodes'] if 'mesh' not in n]
assert skeleton(a)==skeleton(c),'Articulation/socket transforms changed'
def meshbytes(g,raw,mesh):
 vals=[]
 for q in mesh['primitives']:
  for name,i in q['attributes'].items():
   acc=g['accessors'][i];v=g['bufferViews'][acc['bufferView']];o=v.get('byteOffset',0);vals.append((name,raw[o:o+v['byteLength']]))
 return vals
protected=[]
for old,new in zip(a['meshes'],c['meshes']):
 if not old['name'].startswith('surface_1_'):
  assert meshbytes(a,ab,old)==meshbytes(c,cb,new),old['name'];protected.append(old['name'])
m=json.loads((p/'export/carriage-c02.json').read_text());bounds=m['cabin_component_bounds'];eps=1e-6
for side in [-1,1]:
 pane=bounds[f'side_glazing_{side}'];sill=bounds[f'window_sill_rail_{side}'];rail=bounds[f'window_roof_rail_{side}']
 assert pane['min_m'][1]<sill['max_m'][1] and pane['max_m'][1]>rail['min_m'][1]
 for z in [-1.025,.525]:
  post=bounds[f'cabin_corner_pillar_{side}_{z}'];assert pane['min_m'][2]<=post['max_m'][2] and pane['max_m'][2]>=post['min_m'][2]
for end in ['rear','front']:
 f=bounds[end+'_upper_crown_fascia'];header=bounds[end+'_upper_header'];assert f['min_m'][1]<header['max_m'][1]
report={'articulation_and_socket_local_transforms_identical':True,'nonbody_mesh_attribute_buffers_identical':protected,'actual_side_pane_frame_bounds_overlap':True,'actual_end_fascia_header_overlap':True,'limits':'Bounds overlap proves coverage of these axis-aligned pane/frame interfaces, not watertight welded assembly or cloth/collision qualification. Chamfered rails may intersect adjacent panels deliberately; reconstructed construction only.'}
(p/'repair-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
