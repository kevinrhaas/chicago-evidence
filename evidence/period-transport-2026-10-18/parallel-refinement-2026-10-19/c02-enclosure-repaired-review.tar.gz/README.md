# C02 reconstructed enclosure repair

Separate outside-app checkpoint; no C01/app/queue mutation. Replaces the prior *proposal* only after explicit integration review. Original source photo supplies only coarse dark roofed cabin/open-underbody analogy. Window/door divisions, dimensions, glazing, rails and fascia remain independent engineering reconstruction, not a measured historic carriage or ownership claim. No operable door, accepted boarding, driver/horses, physics or1835 eligibility.

`repair.py` records the edit from prior generator. Run `generate_carriage_c02.py --parameters parameters.json --output-dir export`; Python+NumPy only. `c02-source-context.patch` introduces separate C02 source/data/sidecars; copy exported GLB separately. Existing source-only and failed visual archives remain untouched in sibling carriage-c02-next.

Actual exported geometry10152triangles (+176),27material batches/49nodes,757928bytes. Repeat-byte identity, Khronos0errors/0warnings, retained articulation/socket transforms and nonbody mesh attribute buffers unchanged. Bounds overlap at pane/frame interfaces is checked; welded watertightness, cloth/contact and mechanics are not claimed. Closed roof winding remains verified. Six protected C01 files match original recorded hashes.

Eight actualGLB images inspected desktop1280x800/mobile390x780 under identical camera/light/exposure/framing to prior failed review. Former roof/window holes are visibly closed. Fullbody rear/side fits below header, cabin close intentionally crops running gear.29/56drawcalls without/with shadow unchanged; no page/request/GL errors. Browser closed. Flat materials/coarse wheel/furniture geometry remain development quality.
