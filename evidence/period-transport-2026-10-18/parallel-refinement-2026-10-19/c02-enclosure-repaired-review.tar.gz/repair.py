from pathlib import Path
p=Path(__file__).parent/'generate_carriage_c02.py'
s=p.read_text()
pos=s.index('def ring(')
s=s[:pos]+'''def chamfered_rail(name,parent,size,t,mat=0,bevel=.008):
 x,y,z=[v/2 for v in size];b=min(bevel,x*.45,y*.45)
 section=[(-x+b,-y),(x-b,-y),(x,-y+b),(x,y-b),(x-b,y),(-x+b,y),(-x,y-b),(-x,-y+b)]
 vs=[[a,c,d] for d in [-z,z] for a,c in section]
 fs=[list(range(7,-1,-1)),list(range(8,16))]+[[i,(i+1)%8,(i+1)%8+8,i+8] for i in range(8)]
 return geom(name,parent,vs,fs,mat,t)
''' +s[pos:]
s=s.replace("box('side_glazing_'+str(side),body,(.015,.53,1.12),(side*.605,1.625,-.25),6)","box('side_glazing_'+str(side),body,(.025,.66,1.50),(side*.595,1.67,-.25),6)\n chamfered_rail('window_roof_rail_'+str(side),body,(.075,.085,1.62),(side*.595,1.995,-.25),0)\n chamfered_rail('window_sill_rail_'+str(side),body,(.075,.065,1.62),(side*.595,1.34,-.25),0)")
s=s.replace("(.065,.74,.065),(side*.595,1.67,z)","(.075,.75,.075),(side*.595,1.665,z)")
s=s.replace("(.045,.025,1.15),(side*.612,1.36,-.25)","(.045,.025,1.52),(side*.612,1.36,-.25)")
s=s.replace("(.045,.025,1.15),(side*.612,1.90,-.25)","(.045,.025,1.52),(side*.612,1.98,-.25)")
needle="vs=[]\nfor z in [-1.10,.60]:"
insert="""# Continuous invented crown fascia seals the former end gap to roof underside.
# Not an inferred historical construction or door/window arrangement.
for label,z in [('rear',-1.045),('front',.535)]:
 top=[(max(-.62,min(.62,x)),y-.044) for x,y in profile]
 # Retain monotonic x and close a thin solid between upper panel and crown.
 cross=[(-.62,1.92),(.62,1.92)]+list(reversed(top))
 vs_f=[[x,y,z+d] for d in [-.033,.033] for x,y in cross];n=len(cross)
 fs_f=[list(range(n-1,-1,-1)),list(range(n,2*n))]+[[i,(i+1)%n,(i+1)%n+n,i+n] for i in range(n)]
 geom(label+'_upper_crown_fascia',body,vs_f,fs_f,0)
vs=[]
for z in [-1.10,.60]:"""
assert needle in s;s=s.replace(needle,insert)
s=s.replace("'revision':1","'revision':2")
s=s.replace("'boarding_enabled']=False","'boarding_enabled']=False\nsidecar['enclosure_repair']={'status':'independently reconstructed continuous roof rails, sill rails, full side panes and crown fascia; historical layout unproven','side_pane_y_bounds_m':[1.34,2.0],'side_pane_z_bounds_m':[-1.0,.5],'roof_rail_y_bounds_m':[1.9525,2.0375],'sill_rail_y_bounds_m':[1.3075,1.3725],'fascia_lower_y_m':1.92,'rail_edge_chamfer_m':.008}")
p.write_text(s)
