# Proposed separate C02 license entry

Original project-derivedGPL-3.0-or-later generator/data/geometry/materials. No externalphototexture or imagecopied. Existingphoto recordrights statement preserved separately; it is not re-licensed here. No ownership/subtype/dimension/photographicacceptance.

| Path | SHA-256 |
| --- | --- |
| `tools/transport/generate_carriage_c02.py` | `93fac9c6927962bd642187accaa00455b1ddc4c1097d592a4d13d82ce823d726` |
| `data/transport/studies/carriage-c02.json` | `7d3f97aa563cd6a768d1785ff51d83872f6ec9df4f011ea560f96f40dc2dbc97` |
| `renderers/web/transport/carriage-c02/carriage-c02.json` | `4b882862f35088021cfc325d3328cfa2db0e5429da34f331b8719605d2ff3bf7` |
| `renderers/web/transport/carriage-c02/parameters.json` | `7d3f97aa563cd6a768d1785ff51d83872f6ec9df4f011ea560f96f40dc2dbc97` |
| `renderers/web/transport/carriage-c02/carriage-c02.glb` | `a509e57f81d279c135ff7d3f9fda121b4a2de4402bb106b34b47a3be7f41b5f6` |
