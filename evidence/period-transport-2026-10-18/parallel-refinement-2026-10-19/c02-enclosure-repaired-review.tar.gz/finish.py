from pathlib import Path
import json,hashlib,tarfile
p=Path(__file__).parent;b=p.parent/'carriage-c02-next';r=json.loads((p/'render-receipt.json').read_text());old=json.loads((b/'render-receipt.json').read_text())
for a,c in zip(old['rows'],r['rows']):
 assert a['file']==c['file']
 for mode in ['shadow','unshadowed']:
  assert a[mode]['camera']==c[mode]['camera']
  assert a[mode]['framing']==c[mode]['framing']
  assert a[mode]['drawCalls']==c[mode]['drawCalls']
note={'status':'Repaired original development enclosure; historical/photographic acceptance open','actually_inspected':[x['file'] for x in r['rows']],'browser_closed':True,'same_camera_light_header_framing':True,'visible_result':'Prior unfilled roof-end band and side panel surround gaps are closed. Crown fascia meets roof, full side panes meet continuous sill/roof rails and posts. Chamfered rails give restrained edge highlights.','not_a_door':'No intentional open door aperture, operable door or boarding traversal modeled; all pane divisions are reconstructed.','remaining_visual_limits':['Dark opaque glass is a provisional flat material','Cabin body remains box-like with hard lower panel joints','Spokes/tyres are coarse and faceted','Close views intentionally crop running gear'],'reference_limits':'No ownership, diagnosed subtype, source window/door details, measured dimensions or photographic match asserted;1904 development-only','initial_failure_preserved':str(b/'c02-visual-review.tar.gz'),'instrument_correction':'Initial exact entire-node-list comparison failed because batched surface names include original primitive frame indices. Corrected comparison verifies retained articulation/socket local transforms and all nonbody mesh attribute bytes; no geometry failure hidden.'}
(p/'VISUAL-REVIEW.json').write_text(json.dumps(note,indent=2)+'\n')
(p/'README.md').write_text('''# C02 reconstructed enclosure repair

Separate outside-app checkpoint; no C01/app/queue mutation. Replaces the prior *proposal* only after explicit integration review. Original source photo supplies only coarse dark roofed cabin/open-underbody analogy. Window/door divisions, dimensions, glazing, rails and fascia remain independent engineering reconstruction, not a measured historic carriage or ownership claim. No operable door, accepted boarding, driver/horses, physics or1835 eligibility.

`repair.py` records the edit from prior generator. Run `generate_carriage_c02.py --parameters parameters.json --output-dir export`; Python+NumPy only. `c02-source-context.patch` introduces separate C02 source/data/sidecars; copy exported GLB separately. Existing source-only and failed visual archives remain untouched in sibling carriage-c02-next.

Actual exported geometry10152triangles (+176),27material batches/49nodes,757928bytes. Repeat-byte identity, Khronos0errors/0warnings, retained articulation/socket transforms and nonbody mesh attribute buffers unchanged. Bounds overlap at pane/frame interfaces is checked; welded watertightness, cloth/contact and mechanics are not claimed. Closed roof winding remains verified. Six protected C01 files match original recorded hashes.

Eight actualGLB images inspected desktop1280x800/mobile390x780 under identical camera/light/exposure/framing to prior failed review. Former roof/window holes are visibly closed. Fullbody rear/side fits below header, cabin close intentionally crops running gear.29/56drawcalls without/with shadow unchanged; no page/request/GL errors. Browser closed. Flat materials/coarse wheel/furniture geometry remain development quality.
''')
files=sorted(x for x in p.rglob('*') if x.is_file() and not x.name.endswith('.tar.gz') and x.name!='archive-receipt.json' and 'repeat' not in x.parts)
a=p/'c02-enclosure-repaired-review.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(p)),recursive=False)
rows=[{'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files]
with tarfile.open(a) as t:
 for row in rows:assert hashlib.sha256(t.extractfile(row['path']).read()).hexdigest()==row['sha256']
receipt={'archive':str(a),'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'bytes':a.stat().st_size,'members':rows}
(p/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print({k:v for k,v in receipt.items() if k!='members'});print('members',len(rows))
