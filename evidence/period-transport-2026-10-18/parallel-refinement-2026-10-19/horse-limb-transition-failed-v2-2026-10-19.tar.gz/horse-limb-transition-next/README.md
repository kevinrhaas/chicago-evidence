# Upper-limb transition original reconstruction trial — UNAPPLIED

Baseline source reproduces frozen horse89b048b7cda748e6f3a7111aa8e4f3198b01fabf6015cae644c78ed02d385bc6 exactly. All source and outputs outside app. No browser yet.

V1 replaces only4upper limb meshes with broader shoulder/haunch lofts and smoothly root-fixed proximal weights. All other20geometry/normal/weight ranges, nodes/skeleton/IBMs/animation arrays/sockets/gait metadata remain exact (source-invariants.json). 14940tris vs14172,6draws. Minimumtrianglearea3.48e-11m2, no zeroarea. This is an overlapping proximal construction, not a watertight anatomical join.

V1 Khronos0errors/100warnings from nonzero joint IDs at zero-weight components, retained. V2 filters zero entries; same geometric trial; Khronos0errors/0warnings. V2 actual unchanged breastcollar triangle fit FAIL:21discrete walk and21trot poses,3306SAT crossing pairs, minimumunsignedtriangle distance0. Actual source geometry measured via GLTFLoader/AnimationMixer/SkinnedMesh; SATepsilon unchanged1e-8m. Exact crossing pair IDs are retained. No gear reroute or margin weakening.

The script's2.590mm conservative separation target is taken from prior reported vertical AABB gap; it is NOT a newly measured baseline unsignedtriangle minimum, and source unchanged torso does not prove changed-upper clearance. The trial fails zero-crossing independently of this target. Baseline same-method comparison and whole tack/torso/head checks remain unrun. This failed trial must not be integrated.

Root fullpreflight resource hold began immediately after bounded sweep completed. No new browser/dense sweep during hold. Next source-only hypothesis: preserve baseline hind geometry, restrict fore proximal cap within original torso and keep visible shoulder growth below collar height. Must remeasure before any acceptance; no photographic/anatomical claim.

Original geometry/math are CC0; measurement glue GPL as headers state. External pinnedThree and Khronos validator are existing dependencies, not bundled.
