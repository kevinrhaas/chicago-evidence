# T-1883 — 1808 Prairie, Keith / Field house

This pass replaces the remaining generic street-front finish with a procedural
interpretation of the owner-approved February 1888 Inland Architect photograph.
**Photographic acceptance remains open.** The new comparisons deliberately retain
`differs` where ornament, stone courses or proportions have not converged. A green
code/package check is not a declaration that the house matches every photograph.

## Evidence and date

The owner said on 2026-10-16: “Ok to use that image, go ahead and proceed on that
ticket and merge to green.” This approves the 1888 Keith plate for the project;
the canonical source records the quote and scope. It does not re-license the later
photographs. [Reference credits](../../../data/sources/assets/inland_architect_1888_02_keith/README.md)
retain each image's library attribution and rights statement. No photograph pixels
are baked into the model or used as a material texture.

Three contemporary notices were inspected at full resolution:

* **Inland Architect, September 1886, p. 28**, right column near the foot:
  “For O. R. Keith, three story dwelling, 38 by 80 feet, 1808 Prairie avenue,
  granite front; cost $40,000; John Angus, mason.” Canonical source
  `inland_architect_1886_09_keith_notice`, tier 1. It establishes granite, not
  a quarry or a calibrated colour. The permit dimensions do not replace the
  accepted mapped footprint.
* **American Architect and Building News**, vol. XX, no. 557, permit notice:
  O. R. Keith, three-story Prairie Avenue dwelling, $30,000, Cobb & Frost.
  No quarry or colour was found in the inspected notice.
* **Real Estate and Building Journal, 1886-08-28, p. 493**: Prairie Avenue
  No. 1808, three-story dwelling, 38 by 80 feet, $30,000. No quarry or colour
  was found. The scanned initials are reported by the library as D. R. Keith;
  that reading is not silently substituted for the other sources' O. R.

The target remains 1904-07-01. The early photographs show a low stone boundary;
1965's iron infill, ivy, and later neighbouring buildings are evidence of their
own dates. Later chimneys cannot be backdated solely from those pictures.
The 1874 Hitchcock/Galloway double-house engraving predates Keith's 1886 house:
it is excluded, with no camera or claim that Keith matches it.

The mid-1950s library photograph's direction is corrected to southeast looking
northwest: 1812 is nearest on the left, and Glessner recedes on the right.

## What changed

* Two open rows of stone lattice, corner pinnacles, a rock-faced checker band,
  five colonnettes between the six upper windows, and the solid short north return.
  The roof deck sits below the openings; they show actual sky, not a painted grid.
* Paired Ionic capitals, pierced lower porch panels, curved balcony coping with
  finial piers, shallow carved motifs, and concave stair cheeks with scrolls.
* Principal floor raised from 1.5 to 2.0 m, twelve equal risers, the second and
  third floors retained at 5.9 and 9.8 m. The principal bay has three tall transom
  openings, three shorter basement lights, and four second-storey windows.
* Coursed granite relief around real recessed bay openings; stone avoids the
  raised sill/head sockets. Convex flat quads are clipped once before bending,
  avoiding redundant diagonal subdivision. Light keeps the true curved wall,
  openings and texture while omitting the shallow relief.
* Low stone posts/rails, with a clear stair opening, replace the generic tall
  iron fence, piers and urns.
* Keith alone receives the separate load-time granite and dressed-stone tints
  in `renderers/web/js/keith-stone.js`. Glessner's tint is unchanged. The colour
  is a reconstruction constrained by the pale monochrome front and blue-cast,
  shaded 1965 print, not a claimed measured quarry colour.

The main footprint, placement, Glessner clearance, rear bay and service walls
remain the accepted assembly. Fine carving sections, concealed roof, rear
openings and exact material colour remain declared reconstructions under
`L-k01-keith-finish-1883`; superseded principal-floor liberty coverage is retired.
Other houses do not opt into these finish parameters.

## Comparisons and remaining work

Every listed Keith photograph has a camera and comparison under
[`data/reference_views/keith_house_1808_prairie`](../../../data/reference_views/keith_house_1808_prairie)
and [`docs/RESEARCH/photo-match/keith_house_1808_prairie`](../photo-match/keith_house_1808_prairie).
The Taylor reference is translated from the existing Glessner calibration;
reproductions of the same captures are registered with SIFT/RANSAC. Other
cameras use manually picked controls, with their residuals and assumptions
recorded. A numerical registration residual is not a visual match verdict.
The rotated Inland Architect Glessner plate is rendered with camera roll;
the source photograph is not altered.

The 1888 primary view has a before render made from dev commit `378a925` and
an after render from the same camera. `before/inland-1888-side-by-side.jpg`
retains the old generic finish. The actual-app front stand is also the same as
T-2500's recorded front stand.

Remaining differences are recorded per view rather than suppressed: the carved
balcony/pedestal ornament and scroll sections are schematic; granite face and
course variation are still more regular than the photographs; the fine pinnacle
and upper capital profiles need further convergence. The independent street
camera fits retain visible residuals, especially where only a sliver of Keith
is visible beside Glessner. The 1965 close view constrains the entrance strongly
but does not independently date all of its later surface and fence details.
Hidden rear surfaces, colour in monochrome prints, and features below a picture's
resolution are explicitly not shown. These are reasons to keep the image gate
open, not to mark an imperfect comparison `matches`.

## Validation

The K07 entrance gate checks every riser, walk clearance, sockets, closed surfaces
and overlapping coplanar faces. The K08 gate checks all kit and house bays at both
tiers, including genuine holes, curve normals, closure, silhouette and budgets.
Keith's south bay is **15,476 triangles full / 4,522 light**, below the unchanged
20,000 / 7,000 component ceilings. The K01 asset measurement reports **68,535
triangles, 25 primitives, zero coincident faces**, with scale, origin and metric
UV checks passing for both master and web derivative. Master **8,037,484 bytes**;
compressed browser asset **2,416,576 bytes**.

Browser evidence is captured from the actual published `/1904/` application,
1280×800 full desktop and 390×780 light mobile, with front, oblique, rear, roof
and entrance stands. JSON records include loader errors, scene costs and timed
frames. Software-renderer frame timings are not physical-GPU performance claims.
Repository and browser gate receipts follow.

Final mobile run: all seven stands passed, 96–104 draws and 445,870–727,112
triangles, zero page/HTTP/loader errors; all 28 Images-tab thumbnails loaded with
credits. Software-renderer cold boot was 230,937 ms under concurrent validation.
This is not a device-load benchmark.

The deterministic summation repair re-emitted the master byte-identically
(SHA-256 `1eae71eff559bb077f9ea8048e73b726074131ed399d8a418b98587b4c6cd1e4`).
Every other K01/K12/K13/K16 master also re-emits byte-identically to dev; their
manifest input hashes change because the shared helper set changes.

`tools/check.sh`: **PASS, 895 steps, none red (357 self-tests)**. Three
initial pooled failures were resolved before the quiet reruns: deterministic
`math.fsum` in the new helper, removal of the five newly cleared Keith citations
from the unresolved-rights ledger, and a resident-synthesizer drift comparison
that observed a concurrently written photo-match record. No drift baseline was
expanded. The gate reran each quietly and passed.

[Stone channel measurements](stone-colour-measurement.json) preserve exact patch
boxes and image hashes. The 1965 shaded bow sample is r/g **1.0067**, b/g **1.1316**;
the lighter lower bow patch in the actual app is **0.9148 / 1.0648**. The app still
has tree shadows and blue sky light, so this is not a calibrated sunlit-material
comparison. It documents the remaining colour difference rather than declaring
that a tint has passed. A neutral-light swatch and better matched illumination
remain part of photographic convergence.

Final desktop run: all five final stands (front, rear, roof, loggia and northeast)
passed with zero page/HTTP/loader errors, 126–143 draws and
3,333,536–3,904,661 triangles, inside the unchanged 360 / 4,600,000 scene
budgets. The earlier whole-front and southeast captures are labelled preliminary.
The published stage-14 mobile smoke also passed: 128 checks, zero failures.
This is staged coverage, not a claim that the complete 15-stage smoke ran.

Integration with dev `1d8fb34` preserves the new 1621 side stoop and 1637 paired
opening support. All K01/K12/K13/K16 masters were regenerated after the rebase;
only Keith differs from that dev tree, and Keith retains the master and browser
hashes used for the captures above. Browser receipts precede this integration;
they are not represented as a fresh full-district smoke of the rebased tree.

Required preflight on the rebased implementation (`d6b76b2`) passed in an
isolated clean checkout: full repository gate, changelog entry and ticket-ID
checks. No assertions or drift baselines were relaxed.

Published stage-14 desktop smoke: **128 passed, zero failed**, including the
1904 front door and zero-page-errors checks (115 stage checks and 13 always-on
checks). It took 29m05s on software GL, exceeding the steward timing target;
the unchanged assertions passed. Mobile took 14m52s. Both receipts identify
pre-rebase smoke tree `sha256:95aa65b69bca4e67`; the desktop receipt was filed
after rebase, so its provenance is restored from the captured test-time hash
and the matching mobile receipt rather than attributed to the later tree.

## T-2566 — the granite surface (piece 3 of 4)

**Read off the photograph.** The Glessner House archive print of the 1888 photograph
(`a18-gh-1808-keith-field-front`, the clearest reproduction) was read at full
resolution. From the basement to the third-floor line, the front runs a deep
rock-faced course of about 0.5 m and a thin one of about 0.2 m in turn. The basement
courses are the tallest. The third storey is laid in even, much shallower-faced
courses. The 1965 close view shows the same alternation on the south pier and on the
bow. The checker band is not a square grid: it is rows of rough lumps whose joints
break over the row below, standing out by different amounts, with a moulded head
band under it and corbelled bands over it.

**What changed.** `stone_front.coursing` (new, opt-in, Keith alone) lays the walling
high and low in turn (low = 0.4 of high, or the profile's 0.19 m least) below 9.8 m,
and evenly above. Deep courses take the upper half of the granite profile's
rock-face range, thin courses the lower half, and the even upper courses the bottom
35%. Every value stays inside `k02_stone_profiles.json`, whose `course_rule` already
allowed alternating courses. The checker rows are staggered by half a stone, with
each proud stone's projection and every face's rock height drawn from its seed. The
three plain bands became stepped mouldings of the same heights. The upper
colonnettes' capitals gained a neck ring under a flaring bell. Other houses do not
opt in, so their masters re-emit byte-identically; only their manifest input hashes
moved. Keith grew from 68,535 to 71,003 triangles (master 8,260,408 bytes; web
2,471,040).

**The tint, under neutral light.** Texture mean × load tint, with no sky or shade:
the old tint made the granite r/g 0.898, b/g 1.044, a green-grey. The 1965 print's
shaded bow reads r/g 1.007 even under its blue cast, and sky shade raises blue
without lowering red against green. Both stones are now neutral at the same
lightness (granite r/g 1.000, b/g 1.001). The reading is recorded with its tier,
`reconstructed`, in [stone-colour-measurement.json](stone-colour-measurement.json).

**Comparisons.** All sixteen views were re-rendered. The new rows are `fixed` only in
views that show them: the four reproductions of the 1888 front, and the 1965 close
view for the south pier. In the 1967 view they are below resolution (`not shown`).
The other oblique views keep an `open` row until someone compares them at their own
scale. Still open everywhere: the bow's own masonry keeps even courses, and the
joints, capital carving and moulding sections are drawn to the photograph's shadows
rather than read. No view is `matches`.

## T-2564 — the north return (piece 1 of the split)

T-1883 was split on 2026-10-16 into T-2564 (this north return and the pinnacle caps),
T-2565 (the carved loggia), T-2566 (the granite surface and tint) and T-2567 (the
camera re-fits and the image gate, which carries the house's `## Image gate`).

* **What the pictures show.** The 1887 construction view, the c. 1888 view beside
  Glessner, Taylor's c. 1889 view and the 1948 view all show the return as a solid
  block of large dressed courses, not a smooth face: a rounded coping on top that rises
  in a concave sweep into the corner pinnacle (the front coping does the same), a second,
  similar pinnacle at the rear end, and a lower brick parapet beyond.
* **Its length.** Course counts along the return give about twelve course heights in
  the Taylor view and at least ten in the 1948 view, and the c. 1888 view shows it about
  twice as long as the 2.8 m model from the same camera, so it is now 5.5 m, bounded
  4.5 to 7 m while the cameras carry residuals.
* **What was built.** `stone_finish.return_ashlar` (course 0.46 m, bond 0.9 to 1.5 m,
  coping rise 0.35 m over 0.85 m) lays one bonded field of K02 stones from the third
  floor to the coping, its face 15 mm inside the lot line; a swept rounded coping; ogival
  caps with collar and finial on all three pinnacles. The brick north parapet and its
  wall head stop at the return's back (`k01_frontage.py`), so no brick crosses the stone.
  A record without `return_ashlar` builds exactly as before; every other K01 master
  re-emits byte-identical.
* **Measured.** Keith full and web, integrated with T-2566's surface (#862): 74,160 triangles, 25 primitives, zero
  coincident faces; scale, origin and metric UV ok (`k01_contract.mjs --measure-asset`).
* **Still differs**, written into each match record: the carving (T-2565), the brown
  cornice-box band under the lattice where the pictures show stone (still there after T-2566), the camera
  residuals (T-2567), a cowl ventilator on the deck in the 1887-89 pictures, and where the
  full-height stone ends behind the rear pinnacle.
* **Browser receipts (T-2564).** The published `/1904/` app, `QA_VIEWS=front,roof,northeast
  node tools/qa_k01_t1883.mjs`: desktop 1280x800 full and mobile 390x780 light both PASS,
  zero page errors and zero bad loads, serving asset `2cf09f8b92e9…` (re-taken after merging T-2566, #862)
  (`browser-validation-after.json`; the `after-*-front|roof|northeast.jpg` captures are
  re-taken). Smoke: desktop part 1 PASS (87/0); mobile part 14 PASS (128/0, the 1904
  door); desktop part 14 passed 102 checks before the 590 s cap, without reaching its 1904
  section (dev's last reading of that part took 29 min), so the app QA above stands for it.

## T-2565 — the carved loggia and the bow's heights (piece 2 of 4)

**Read off the pictures.** The Inland Architect plate (`plate.jpg`, native 1559 × 2400)
was cropped round the loggia and read beside the 1965 close view
(`a18-gh-1808-porch-1965`). Both show, where the model had something else:

* **One capital to a pair.** Each corner's two columns share one carved capital, a
  band spanning both shafts under a thin abacus. The model gave each column its own.
* **A level balcony.** The balcony's coping runs level between two square dies in both
  pictures; the curved top T-1883 drew is in neither. Over the flight-side die the 1888
  plate shows a stepped stone finial; the far die stops flat against the wall. By 1965
  both dies are capped flat. The 1904 state follows the earlier picture.
* **A deep cornice.** The balcony stands on a heavy cornice whose corona throws the
  darkest shadow on the loggia in 1888, and reads as a stepped moulding in 1965.
* **Rolled feet.** Both stair cheeks sweep down from the deck and end at the street in
  a rounded stone roll. The model put a scroll at the cheek's head and cut the foot off
  square.

**What changed** (`k07_entrances.py`, behind `finish: ionic_carved`, Keith's alone, so
the other houses' entrances re-emit byte for byte): `_paired_capital` builds one capital
over each pair, a band with an Ionic volute (two and a half turns closing to an eye)
at each end of its front and back, a volute on each end face, and an egg row between.
`_carved_balcony` builds the level panel, coping and plinth between two square dies
with stepped caps, and the stepped base, pyramid and ball finial on the flight-side die.
The cornice steps out in three to 0.22 m. `_scrolled_cheek` ends the sweep tangent
onto a 0.2 m roll lying across the cheek, its outer end 30 mm proud and carved with a
volute on both ends. The new `_tube` helper gives every carved bead's faces a hint
pointing outward from its centreline.

**The bow's heights.** The model's bow heights were projected through the
`inland-1888` camera onto the plate at native resolution. Floors, the cap and the
string course stay where T-2499 put them. Read through the camera, the second-storey
lights are about 198 px tall in the plate where the model's 2.2 m projected to 170 px.
Their heads stand about 30 px under the cap's band where the model's stood 73 px under
it. They are now 2.5 m on the same 0.75 m sill. The principal lights (plate about
233 px, model 243 px) and the basement lights (80 px against 85 px) sit within the fit's
14 px residual, so they keep their heights. At its own fit, the 1965 view reads the
principal lights shorter (about 2.5 m), but the plate does not. A later transom change
and the 1965 camera's 18 px residual are not yet told apart, so that row stays `open`.

**Measured.** On top of T-2564's north return, Keith went from 74,160 to 75,688
triangles (master 8,661,196 bytes, web 2,588,460), with zero coincident or degenerate
faces in either tier. The volute's eye stays wider than its bead, so the web tier's
quantization leaves no sliver triangles. Its house entrance is 17,701
triangles inside the K07 budget. All sixteen views were re-rendered. The new rows are
`fixed` in the four reproductions of the 1888 front and, except the finial, in the 1965
view. The smaller views keep an `open` row until someone compares them at their own
scale. No view is `matches` yet: the volutes' turns, the egg row and the panels'
foliage are still drawn to the pictures' shadows.

## T-2578 — the cowl ventilator and the corner behind the rear pinnacle (piece 2 of T-2567)

Read from the pictures themselves, cropped at full resolution: the 1887 construction view and
Taylor 2135 show an inclined pipe rising from just inside the rear pinnacle to an upright cowl,
a bowl under a broad flat disc; the rotated 1888 Glessner plate and the c. 1888 view looking SW
show the same cowl over the return; the 1948 view shows only a low dark stub at its foot. Sizes
are read against the return's 0.46 m courses and the rear pinnacle in Taylor 2135 (cap about 1.85
times the pinnacle's height over the coping; pipe about 0.28 m, cap about 0.58 m across). The
cap's place along the return reads 0.48 (Taylor 2135), 0.62 (1887) and 0.58 (c. 1888); it is built
at 3.3 m of the 5.5 m return and renders at 0.51 to 0.59 in the same cameras.

Every view that sees the corner behind the rear pinnacle shows sky straight behind it (1948: a
darker wall about a course lower), so the stone parapet stops there; the model's drop stands.
Left open for T-2580 and T-2579: the hall stack showing over the coping beside the cowl in the
renders where the pictures show sky, and the c. 1888 view's higher-seeming cap.

## T-2579 — the five independent cameras re-fitted

The T-1883 cameras for the 1948 Florian view, the Glessner-front view, the 1888
Inland Architect Glessner plate, the 1965 porch view and Reed's 1941 view were
fitted to hand-read controls with 4.5-28.8 px RMS, and three of them shared one
set of six control coordinates. Each is now a least-squares fit of a level camera
(eye 1.7 m, reconstructed) to controls read from its own picture at full
resolution, every control a point of the committed GLB (a pinnacle apex, or a
jamb, head or sill found by ray-casting the render). The numbers — controls,
projections, per-control residuals, RMS and the scale at the subject — are in each
camera's `solve`; points read but not fitted are written there as checks.

| view | controls | RMS | at the subject |
|---|---|---|---|
| Reed 1941 | 6 | 4.6 px | 0.22 m at 58 m |
| Florian 1948 | 6 | 4.0 px | 0.09 m at 60 m |
| Glessner front | 5 | 0.9 px | 0.01 m at 34 m |
| Inland Architect plate | 5 | 1.3 px | 0.04 m at 71 m |
| porch 1965 | 7 | 1.7 px | 0.04 m at 16 m |

With the cameras in register the remaining differences are the building's, and
each match record now names them (still `differs`): the crown's band of small
diamond-pointed units directly under the lattice, where the model lays larger
rock-faced blocks lower under a plain band; a carved boss on the north-east pier at
the lattice's foot; that pier about 0.3 m wider, its pinnacle on the pier's middle;
the loggia's columns about 0.4 m taller; dressed stone on the south face behind the
south-east pinnacle (T-2581); and Keith's slice not fitting one level camera with
Glessner's front as the two models are placed. The 1965 porch view's bow lights,
which read "shorter" at the old 18 px fit, land within 2.5 px of the model at head
and sill. No geometry changed; the GLB is the one T-2577 shipped.

## T-2712 — the hall stack stopped under the return's coping (piece 1 of T-2586)

T-2578 left the hall stack standing 0.8 m over the return's coping beside the cowl, where the
1887 construction view, Taylor 2135, the rotated 1888 Glessner plate and the c. 1888 view
looking SW all show sky. A flat roof's stack may now carry its own `top_m` (K01 params; it must
clear the deck it stands on, the stone finish's 1.45 m drop taken, by 0.6 m), and the hall stack
tops at 16.1 m, 0.14 m under the coping: hidden from every street camera, with the cowl's pipe
rising 0.05 m clear of its cap before it bends over the coping (L-k01-keith-hall-stack-2586).
All sixteen views were re-rendered and each new render diffed against the reviewed one: four are
pixel-identical, four front views change by a sliver seen through the lattice's north openings,
and the rest change only where the stack stood. The 1887 view, the 1888 Glessner plate and both
Taylor 2135 records had the stack as their last open difference and now read `matches`; the
c. 1888 SW view keeps its cap-height reading open, and the Glessner-front view its cap over the
coping. The 1948 view's low stub at the cowl's foot is later fabric and is not read back.

## T-2713 — the cowl's cap ruled (piece 2 of T-2586)

T-2712 left two readings of the cowl's cap open, and they pull opposite ways: the c. 1888 view
looking SW reads the cap higher over the coping than the render, and the undated Glessner-front
view shows clean sky over the whole coping. Through T-2579's re-fitted Glessner-front camera
(0.74 px) no cowl inside the record's bounds hides behind the return: at the 0.6 m set-back the
cap clears the return's skyline by 45-129 px across the whole 0.4-1.6 m height range, and only at
the 1.5 m limit, with the cap at 0.95 m or lower, does it drop behind, and then against the
front's crown. Every other picture of 1887-89 shows the cowl, and by 1948 only its stub is
left, so the Glessner-front view (probably 1890s-1920s, T-2216) is read as later than the
cowl's removal and its cap item reads `not shown`.

The height is taken from the best camera that sees the cap: T-2579's re-fit on the 1888 Glessner
plate, where the photograph's cap top stood 3.5 px (0.1 m at 37 px/m) beyond the render's. The
cap now stands 1.05 m over the coping (0.95 before), and on the plate the two tops agree to
1-2 px. The c. 1888 SW view reads more again (about 0.94 m apparent over the coping against
the render's 0.64 m, measured against the return's own courses under it), but its T-1883 camera
puts the rear pinnacle about 60 px right of and 40 px below the photograph's, so the return's
run and fall there are the camera's; that view keeps a new open item for its re-fit, which the
print's faint apexes make a job of its own. All sixteen views were re-rendered; the verdicts
stand where they were (the 1887 view, the plate and both Taylor 2135 records still read
`matches`: on the plate the cap now agrees to 1-2 px, and in the two older registrations it moves
toward the photograph's, which still reads it a little higher).

## T-2811 — the cowl's set-back read on two cameras (piece 1 of T-2751)

T-2748's re-fit of the c. 1888 view looking SW (4.1 px RMS, the rear pinnacle held to 1.5 px
across) read the cowl's cap 11 px left of and 7 px under the print's, and put both on the cowl's
reconstructed depth behind the return's face. Rendered at a 0.3 m set-back the cap's centre
stands at x 1241 against the print's 1242.5 and its top at y 108 against 106: in this low view a
cowl nearer the face also stands higher, so the height excess was the set-back's, not the cap's.

The 1888 Glessner plate disagrees. Its T-2579 camera holds both return pinnacles to 1-4 px, and
it read the cap where it was built (centre y 630.5 against the plate's 629.5 at 0.6 m); at 0.3 m
it reads 10.5 px off. Measured sensitivities, per 0.3 m (cap centre, then cap top):

| move | c. 1888 SW (x, y) | 1888 plate (y, x) |
|---|---|---|
| 0.3 m nearer the face | +9, -5 | +9.5, +1 |
| 0.3 m further back along the return | +10.5, +4 | +6, -3 |

Both cameras see a move along the return almost as a change of set-back, so a place that meets
both prints needs the cowl 0.75 m further back and 0.5 m deeper, with its cap raised 0.25 m by the
plate's reading and 0.54 m by the photograph's — fitting the cameras' residuals, not the cowl.
Least squares over the four readings gives a set-back of 0.42 m alone, or 0.41 m with the place
along the return free (which then moves 0.01 m, to 3.29 m). The cowl is built at **0.45 m**; its
place (3.3 m) and its cap's height (1.05 m) stand. The c. 1888 view's cap now reads 6 px across
and 5 px high from the print's, the plate's 5.5 px along the return and 0 px in height: the two
cameras' disagreement, which no placement of the cowl removes. The c. 1888 view's cowl item is
closed on that; the view still differs on its stoop (T-2812).

All seventeen views were re-rendered. Every changed pixel sits in one cluster at the cowl, and
four views (the 1965 porch, the mid-1950s, the owner's crop and Reed 1941) are unchanged to the
pixel. The verdicts stand where they were, and the plate, Taylor 2135 and the 1887 view still
read `matches`.

## T-2815 — the 1888 plate's bow lights, bow cap band and south pedestal side (piece 5 of T-2751)

Three items the 1888 plate (inland-1888, native 1559 px) drew and the model did not:

- **The principal bow lights in three tiers.** T-2765 read them on the south light's column
  with no camera (heights fitted to one scale, 77.8 px/m): the main sash's head at y 1480
  (4.05 m), the lower bar's top at 1468 (4.21 m), the upper bar at 1418 (4.85 m) and the head at
  1382 (5.32 m). The K06 transom sash learns `tiers` (`generators/archetypes/k06_windows.py`
  `_tiers`): each fixed light stands on a bar in the wall's own stone (the `mullion` role), its
  face on the wall's face, back to the frame's back. Keith's bow takes two 0.15 m bars under a
  0.5 m light and a 0.45 m top light, so the sash runs from the 2.35 m sill to 4.05 m. In the
  render the three tiers and their bars stand where the print's do.
- **The carved band under the bow's cap.** Median intensity down the bow at x 400-640 puts the
  print's dark band from y 1006 to 1054 and the cap's light top over it (975-1005, a fillet's
  shadow at 993); the band's foot is about 9.54 m on T-2765's scale, 27 px over the second-storey
  heads (y 1081). The model had plain coursed wall from the heads to the cap's seat at 9.8 m.
  K08 learns `cap_band` (`generators/archetypes/k08_bays.py` `_cap_band`, sharing T-2778's
  guilloche through `_guilloche`, so 1623's frieze keeps its bytes): Keith's bow carries a
  dressed band 0.26 m deep, 0.045 m proud (clear of the 0.036 m rock face) under the seat, its
  top 2 mm under the seat's underside, which the mitred moulding already draws. In the render
  its foot stands 33 px over the heads against the print's 27. The print draws the carving
  only as dark texture through the street tree, so the guilloche is reconstructed, and the
  neutral review render lights the band where the print holds it in shadow (its own `not shown`
  item in the match record).
- **The south pedestal's side field.** The plate sees the south pedestal's south face (x
  872-886, y 1590-1650) and draws a field in a border like its front's; K07's loggia now lays the
  same 35 mm bead on that face, 0.1 m in from its arrises. No picture shows the north
  pedestal's north side, so it stays plain.

`inland-1888` now reads `matches`: every difference is fixed, or not shown (the colonnettes'
capitals, the head bands' sections, the rear, the colour and the band's carving). The kit
code is an input to every K01, K13 and K16 master, so all of them were re-emitted; only
Keith's bytes changed. All sixteen views were re-rendered. In the three that see the bow's
front (mid-1950s, Nickel 1967, the owner's view looking SW) the print shows the principal lights
tiered as now built, and the verdicts stand where they were.
