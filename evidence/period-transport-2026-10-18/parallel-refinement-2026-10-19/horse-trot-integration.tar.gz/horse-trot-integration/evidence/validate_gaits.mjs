// SPDX-License-Identifier: GPL-3.0-or-later
// Pure CPU: actual GLTFLoader + Three AnimationMixer/SkinnedMesh, no browser/GPU.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import * as T from '/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/three.module.js';
import {GLTFLoader} from '/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/addons/loaders/GLTFLoader.js';
const root=path.dirname(new URL(import.meta.url).pathname);
const bytes=fs.readFileSync(root+'/output/equine_light_harness_skinned_prototype_01.glb');
const gltf=await new GLTFLoader().parseAsync(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),'');
const manifest=JSON.parse(fs.readFileSync(root+'/output/manifest.json'));
const horse=gltf.scene,mesh=horse.getObjectByName('skinned_equine_hooves');
const soles=[];for(let i=0;i<mesh.geometry.attributes.position.count;i++){
 const v=new T.Vector3().fromBufferAttribute(mesh.geometry.attributes.position,i);
 if(Math.abs(v.y)<.00001)soles.push({id:i,label:(v.z>0?'fore':'hind')+(v.x>0?'_l':'_r')});
}
assert(soles.length>=100);
const reports=[];
for(const clip of gltf.animations){
 const mixer=new T.AnimationMixer(horse);mixer.clipAction(clip).play();const gait=manifest.locomotion[clip.name];const groups={},rows=[];let minY=Infinity,maxStanceHeight=0,maxGap=0,maxEndpointError=0,minReachMargin=Infinity;
 const samples=1441;
 for(let k=0;k<samples;k++){
  const phase=k/(samples-1);mixer.setTime(phase*clip.duration);horse.updateMatrixWorld(true);horse.traverse(o=>{if(o.isSkinnedMesh)o.skeleton.update();});
  for(const sole of soles){const v=mesh.getVertexPosition(sole.id,new T.Vector3()).applyMatrix4(mesh.matrixWorld);minY=Math.min(minY,v.y);const offset=gait.phase_offsets[sole.label]||0;const absolute=phase+offset;const contact=clip.name==='idle'||absolute%1<gait.stance_fraction;
   if(contact){maxStanceHeight=Math.max(maxStanceHeight,Math.abs(v.y));const key=sole.id+':'+Math.floor(absolute);(groups[key]??=[]).push(v.z+phase*gait.stride_m);}
  }
  const coat=horse.getObjectByName('skinned_equine_coat'),r=manifest.join_trial.records;
  for(let j=0;j<24;j++)maxGap=Math.max(maxGap,coat.getVertexPosition(r.neck.interface[j],new T.Vector3()).distanceTo(coat.getVertexPosition(r.head.interface[j],new T.Vector3())));
  for(const label of['fore_l','fore_r','hind_l','hind_r']){
   const hip=horse.getObjectByName(label+'_upper').getWorldPosition(new T.Vector3());
   const ankle=horse.getObjectByName(label+'_fetlock').getWorldPosition(new T.Vector3());minReachMargin=Math.min(minReachMargin,1.2-ankle.distanceTo(hip));
  }
 }
 const drift=Math.max(...Object.values(groups).map(v=>Math.max(...v)-Math.min(...v)));
 const report={clip:clip.name,samples,actual_sole_vertices:soles.length,actual_stance_slide_m:drift,max_stance_height_m:maxStanceHeight,min_actual_sole_y_m:minY,max_join_gap_m:maxGap,min_extension_margin_m:minReachMargin,contract:gait};reports.push(report);
 mixer.stopAllAction();
}
const result={status:'CPU exported actual geometry/AnimationMixer study, no browser or photographic acceptance',reports};fs.writeFileSync(root+'/actual-gait-validation.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(reports.map(({clip,actual_stance_slide_m,max_stance_height_m,min_actual_sole_y_m,min_extension_margin_m})=>({clip,actual_stance_slide_m,max_stance_height_m,min_actual_sole_y_m,min_extension_margin_m})),null,2));
for(const r of reports){assert(r.actual_stance_slide_m<.020);assert(r.max_stance_height_m<.005);assert(r.min_actual_sole_y_m>-.001);assert.equal(r.max_join_gap_m,0);assert(r.min_extension_margin_m>0);}
