# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import struct,json,hashlib,numpy as np
p=Path(__file__).parent;project=Path('/workspace/chicago/chicago/4d')
def load(file):
 b=file.read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);blob=b[28+n:]
 def read(i):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];return np.frombuffer(blob,dtype={5126:'<f4',5123:'<u2',5125:'<u4'}[a['componentType']],offset=v.get('byteOffset',0)+a.get('byteOffset',0),count=a['count']*{'SCALAR':1,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']])
 return d,read
old,oread=load(project/'renderers/web/transport/horse/equine_light_harness_skinned_prototype_01.glb');new,nread=load(p/'output/equine_light_harness_skinned_prototype_01.glb');checks={}
checks['nodes_exact']=old['nodes']==new['nodes'];checks['materials_exact']=old['materials']==new['materials'];checks['skin_joint_table_exact']=old['skins'][0]['joints']==new['skins'][0]['joints'];checks['inverse_bind_exact']=np.array_equal(oread(old['skins'][0]['inverseBindMatrices']),nread(new['skins'][0]['inverseBindMatrices']))
for om,nm in zip(old['meshes'],new['meshes']):
 for op,np_ in zip(om['primitives'],nm['primitives']):
  for attr in op['attributes']:checks[om['name']+'_'+attr]=np.array_equal(oread(op['attributes'][attr]),nread(np_['attributes'][attr]))
  checks[om['name']+'_indices']=np.array_equal(oread(op['indices']),nread(np_['indices']))
for oa in old['animations']:
 na=next(x for x in new['animations'] if x['name']==oa['name']);checks[oa['name']+'_channels']=oa['channels']==na['channels'];checks[oa['name']+'_extras']=oa['extras']==na['extras'];checks[oa['name']+'_tracks_exact']=all(np.array_equal(oread(x[k]),nread(y[k])) for x,y in zip(oa['samplers'],na['samplers']) for k in ('input','output'))
trot=next(x for x in new['animations'] if x['name']=='trot');checks['trot_loop_quaternion_closure']=all(np.linalg.norm(nread(s['output']).reshape(-1,4)[0]-nread(s['output']).reshape(-1,4)[-1])<1e-7 for s in trot['samplers']);checks['diagonal_pairs']=trot['extras']['phase_offsets']=={'fore_l':0,'hind_r':0,'fore_r':.5,'hind_l':.5}
result={'passed':all(checks.values()),'checks':{k:bool(v) for k,v in checks.items()},'baseline_sha256':hashlib.sha256((project/'renderers/web/transport/horse/equine_light_harness_skinned_prototype_01.glb').read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256((p/'output/equine_light_harness_skinned_prototype_01.glb').read_bytes()).hexdigest()};(p/'preservation-validation.json').write_text(json.dumps(result,indent=2)+'\n');print({'passed':result['passed'],'failures':[k for k,v in checks.items() if not v]});assert result['passed']
