# SPDX-License-Identifier: CC0-1.0
import ast,math,pathlib,json,random
p=pathlib.Path(__file__).parent;tree=ast.parse((p/'horse_geometry.py').read_text());names={'qmul','qinv','qrotate','from_down','solve_limb_3d'};scope={'math':math};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),'original solver','exec'),scope)
rng=random.Random(2803);errors=[];maxerr=0;maxlevel=0
for fore in (True,False):
 for i in range(500):
  target=[rng.uniform(-.15,.15),rng.uniform(-1.12,-.8),rng.uniform(-.35,.35)]
  a,b,c=scope['solve_limb_3d'](target,fore);u=scope['qrotate'](a,[0,-.65,0]);v=scope['qrotate'](scope['qmul'](a,b),[0,-.55,0]);endpoint=[u[j]+v[j] for j in range(3)];maxerr=max(maxerr,math.dist(endpoint,target));foot=scope['qrotate'](scope['qmul'](scope['qmul'](a,b),c),[0,-.10,.025]);maxlevel=max(maxlevel,math.dist(foot,[0,-.10,.025]))
for target in ([0,-1.201,0],[0,-.099,0],[0,0,0]):
 try:scope['solve_limb_3d'](target,True);raise AssertionError('unreachable accepted')
 except ValueError:pass
assert maxerr<1e-12 and maxlevel<1e-12
result={'random3dtargets':1000,'seed':2803,'maximum_endpoint_error_m':maxerr,'maximum_flat_hoof_orientation_error_m':maxlevel,'rejected_unreachable_cases':3,'scope':'original2bonegeometric solver, not biological joint range/tissue acceptance'};(p/'solver-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
