# Pre-browser setup failures retained

Before the first actual fixture run, two launch attempts stopped without opening a browser:

1. Default restricted sandbox: Node reported `Detected unsettled top-level await` at the loopback server listen promise, exit13. The authorized loopback command was rerun with approved sandbox escalation.
2. Existing `/workspace/chicago/node_modules/playwright/index.js` did not resolve (`ERR_MODULE_NOT_FOUND`). No package was installed. Runner reused the already-installed Python Playwright distribution's bundled Node driver at `/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages/playwright/driver/package/index.mjs`.

These are source/setup observations from tool outputs, not failures of human model loading. Original first actual browser failure remains in browser.log/browser-receipts: mobile Full calibration cache disposal while an autoLOD parse was pending. Final corrected run is separately preserved in browser-followup.log/browser-followup. See BROWSER-REVIEW.md.
