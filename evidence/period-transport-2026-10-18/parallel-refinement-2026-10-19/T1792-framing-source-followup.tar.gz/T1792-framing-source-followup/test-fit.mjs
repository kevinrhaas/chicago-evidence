// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';
import * as T from 'three';
import {populationCapturePoints, fitPopulationCapture} from './human_population_capture_fit.js';
function actor(e=0){
 const position=[-.3,0,0,.3,0,0,.3,1.7,0,-.3,1.7,0,-.3,0,.2,.3,0,.2,.3,1.7,.2,-.3,1.7,.2,-2.6,1.2,.1,2.8,1.2,.1,1000,1000,1000];
 const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(position,3));geometry.setIndex([0,1,2,2,3,0,4,5,6,6,7,4,8,4,9]);
 geometry.setAttribute('skinIndex',new T.Uint16BufferAttribute(new Array(44).fill(0),4));geometry.setAttribute('skinWeight',new T.Float32BufferAttribute(Array.from({length:44},(_,i)=>i%4===0?1:0),4));
 const morph=new Float32Array(33);morph[8*3]=-.2;morph[9*3]=.2;geometry.morphAttributes.position=[new T.Float32BufferAttribute(morph,3)];geometry.morphTargetsRelative=true;
 const mesh=new T.SkinnedMesh(geometry,new T.MeshBasicMaterial()),bone=new T.Bone();mesh.add(bone);mesh.bind(new T.Skeleton([bone]));mesh.morphTargetInfluences[0]=1;bone.rotation.z=.04;
 const root=new T.Group(),scene=new T.Group();root.position.set(e,-.07,0);root.add(scene);scene.add(mesh);return{root,body:{scene,meshes:[mesh]}};
}
const actors=[actor(-1),actor(1)],points=populationCapturePoints(actors);assert.equal(points.length,60);assert.ok(Math.min(...points.filter((_,i)=>i%3===0))<-3.7,'hand morph+bone pose contributes extrema');assert.ok(Math.max(...points)<10,'unused unindexed outlier excluded');
const input=JSON.stringify(actors.map(a=>Array.from(a.body.meshes[0].geometry.attributes.position.array))),placements=actors.map(a=>a.root.position.toArray());
let fits=0;
for(const [width,height,uiBottom] of [[390,780,192],[1280,800,192],[320,640,250]])for(const theta of[0,Math.PI/4,Math.PI/2])for(const chosen of[points,points.slice(0,30),points.map((x,i)=>i%3===1?x*1.3:x)]){
 const camera=new T.PerspectiveCamera(35,width/height,.03,300);camera.position.set(Math.sin(theta)*9,2.3,Math.cos(theta)*9);camera.lookAt(0,.9,0);const quaternion=camera.quaternion.toArray();const rect={left:8,right:288,top:8,bottom:uiBottom};
 const controls={left:8,right:width-8,top:uiBottom+3,bottom:uiBottom+30};const receipt=fitPopulationCapture(camera,chosen,{width,height,uiRects:[rect,controls]});assert.ok(receipt.passed);assert.equal(receipt.vertices_covered_by_ui,0);assert.deepEqual(camera.quaternion.toArray(),quaternion,'orientation is preserved');
 for(let i=0;i<chosen.length;i+=3){const v=new T.Vector3().fromArray(chosen,i),depth=-v.clone().applyMatrix4(camera.matrixWorldInverse).z;v.project(camera);assert.ok(depth>camera.near&&depth<camera.far);assert.ok(v.x>=-.96&&v.x<=.96);assert.ok((1-v.y)/2>=(uiBottom+30)/height+.02);assert.ok((1-v.y)/2<=.98);}
 fits++;
}
assert.equal(JSON.stringify(actors.map(a=>Array.from(a.body.meshes[0].geometry.attributes.position.array))),input);assert.deepEqual(actors.map(a=>a.root.position.toArray()),placements);
actors[0].root.visible=false;assert.equal(populationCapturePoints(actors).length,30,'hidden ancestor omitted');actors[0].root.visible=true;
assert.throws(()=>fitPopulationCapture(new T.PerspectiveCamera(35,.5,.03,300),points,{width:320,height:640,uiRects:[{left:0,right:300,top:0,bottom:635}]}),/no capture/);
actors[0].root.visible=false;const mesh=actors[1].body.meshes[0],material=mesh.material;mesh.material=[material];assert.throws(()=>populationCapturePoints(actors),/No finite/,'array material without groups submits no vertices');mesh.material=material;actors[0].root.visible=true;
console.log(`PASS ${fits} actual Three CPU fits incl deformed indexed hand extrema, perspective/depth/UI margins/orientation, hidden ancestor, unused vertex exclusion and no actor mutation. Browser UNRUN.`);
