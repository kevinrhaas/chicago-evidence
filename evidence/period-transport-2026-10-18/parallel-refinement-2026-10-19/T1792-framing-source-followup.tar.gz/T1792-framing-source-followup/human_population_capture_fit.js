// SPDX-License-Identifier: GPL-3.0-or-later
import * as T from 'three';

/** Actual drawn vertex positions, including finger/hand extrema. No actor changes. */
export function populationCapturePoints(actors) {
  const points = [];
  const vertex = new T.Vector3();
  for (const actor of actors) {
    actor.root.updateWorldMatrix(true, true);
    actor.body.scene.traverse(mesh => {
      if (!mesh.isMesh) return;
      for (let parent = mesh; parent; parent = parent.parent) if (!parent.visible) return;
      if (mesh.isSkinnedMesh) mesh.skeleton.update();
      const geometry = mesh.geometry;
      const count = geometry.index?.count ?? geometry.attributes.position.count;
      const start = geometry.drawRange.start;
      const end = Math.min(count, start + geometry.drawRange.count);
      const materials = [].concat(mesh.material);
      const groups = Array.isArray(mesh.material)
        ? geometry.groups : [{start: 0, count, materialIndex: 0}];
      const indices = new Set();
      for (const group of groups) {
        if (!materials[group.materialIndex]?.visible) continue;
        const from = Math.max(start, group.start);
        const to = Math.min(end, group.start + group.count);
        for (let i = from; i < to; i++) indices.add(geometry.index?.getX(i) ?? i);
      }
      for (const index of indices) {
        mesh.getVertexPosition(index, vertex).applyMatrix4(mesh.matrixWorld);
        points.push(vertex.x, vertex.y, vertex.z);
      }
    });
  }
  if (!points.length || !points.every(Number.isFinite)) throw Error('No finite drawn population vertices');
  return points;
}

/** Preserve current perspective orientation; fit camera position into measured free UI space. */
export function fitPopulationCapture(camera, points, {width, height, uiRects, margin = .02}) {
  if (!points.length || points.length % 3 || !points.every(Number.isFinite)
      || !Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0
      || !uiRects.length || uiRects.some(r => ![r.left, r.right, r.top, r.bottom].every(Number.isFinite))
      || margin !== .02) throw Error('Finite geometry, viewport and complete UI rectangles required');
  if (camera.view?.enabled || camera.filmOffset) throw Error('Unsupported camera view/film offset');
  const rectangle = {
    left: margin, right: 1 - margin,
    top: Math.max(margin, ...uiRects.map(r => r.bottom / height + margin)),
    bottom: 1 - margin,
  };
  if (rectangle.top >= rectangle.bottom) throw Error('UI leaves no capture rectangle');
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  const center = new T.Vector3();
  const box = new T.Box3();
  const vertex = new T.Vector3();
  for (let i = 0; i < points.length; i += 3) box.expandByPoint(vertex.fromArray(points, i));
  box.getCenter(center);
  const right = new T.Vector3(1, 0, 0).applyQuaternion(camera.quaternion);
  const up = new T.Vector3(0, 1, 0).applyQuaternion(camera.quaternion);
  const outward = new T.Vector3(0, 0, 1).applyQuaternion(camera.quaternion);
  const tangentY = Math.tan(T.MathUtils.degToRad(camera.fov) / 2) / camera.zoom;
  const tangentX = tangentY * camera.aspect;
  const centerX = rectangle.left + rectangle.right - 1;
  const centerY = 1 - rectangle.top - rectangle.bottom;
  function project(distance) {
    camera.position.copy(center).addScaledVector(outward, distance)
      .addScaledVector(right, -centerX * distance * tangentX)
      .addScaledVector(up, -centerY * distance * tangentY);
    camera.updateMatrixWorld(true);
    const bounds = {left: Infinity, right: -Infinity, top: Infinity, bottom: -Infinity};
    let valid = true;
    let covered = 0;
    for (let i = 0; i < points.length; i += 3) {
      vertex.fromArray(points, i);
      const depth = -vertex.clone().applyMatrix4(camera.matrixWorldInverse).z;
      vertex.project(camera);
      const x = (vertex.x + 1) / 2;
      const y = (1 - vertex.y) / 2;
      valid &&= Number.isFinite(x) && Number.isFinite(y) && depth > camera.near && depth < camera.far;
      bounds.left = Math.min(bounds.left, x); bounds.right = Math.max(bounds.right, x);
      bounds.top = Math.min(bounds.top, y); bounds.bottom = Math.max(bounds.bottom, y);
      if (uiRects.some(r => x * width >= r.left && x * width <= r.right
          && y * height >= r.top && y * height <= r.bottom)) covered++;
    }
    return {distance_m: distance, bounds, vertices_covered_by_ui: covered,
      passed: valid && covered === 0 && bounds.left >= rectangle.left && bounds.right <= rectangle.right
        && bounds.top >= rectangle.top && bounds.bottom <= rectangle.bottom};
  }
  let low = camera.near;
  let high = Math.max(box.getSize(vertex).length(), camera.near * 2);
  let receipt;
  for (let i = 0; i < 40; i++) {
    receipt = project(high);
    if (receipt.passed) break;
    high *= 1.5;
    if (high >= camera.far) throw Error('No capture fit within clipping range');
  }
  if (!receipt.passed) throw Error('Capture fit did not converge');
  for (let i = 0; i < 55; i++) {
    const mid = (low + high) / 2;
    if (project(mid).passed) high = mid; else low = mid;
  }
  receipt = project(high * 1.00001);
  if (!receipt.passed) throw Error('Final capture fit violates strict bounds');
  return {...receipt, available_rectangle: rectangle, viewport: {width, height},
    vertex_count: points.length / 3, margin_fraction: margin, ui_rectangles: uiRects,
    camera_position: camera.position.toArray(), camera_quaternion: camera.quaternion.toArray(),
    scope: 'Actual deformed indexed visible geometry including hands; camera motion only; capture not performance view'};
}
