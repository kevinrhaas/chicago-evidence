# T-2803 additive grounded trot engineering study — unapplied

Scope: original synthetic in-place grounded diagonal trot on existing15joint skinned fixture; no new horse/identity/source photograph. Read T-2803/T-2800, retained horses/carriages/viewer-survey research and horse-master-spec. First production anatomical horse master, full joint chains, ear controls, anatomical rig/skin quality, Blender bake, portable LODs, sourced motion, load/gear/rider/transition/visual acceptance remain open. No app or ticket edits, no Blender, no browser. CPU-only actual Three GLTFLoader/AnimationMixer/SkinnedMesh tests below are not browser/GPU acceptance.

## Concrete additions

`horse_geometry.py` adds original `solve_limb_3d`: sphere-intersection knee solve with explicit reconstructed lateral bend axis, shortest-arc bone quaternion rotations, and fetlock counterrotation. Targets outside strict two-bone reach throw; there is no target clipping or moving contact marker. Existing walk/idle solver and animation outputs remain byte-for-byte exact. Real trot trajectory targets have no lateral motion, but independent1000seeded3Dtarget tests exercise lateral target coordinates as well. It remains a2boneengineering approximation, not full equine scapula/humerus/radius/carpus/cannon/fetlock articulation.

New `parameters.json.trot_reconstruction`: cycle.72s,stance.52,sweep.68m,lift.12m. Engineering choices, no measured period timing. Diagonal phases fore_l=hind_r=0,fore_r=hind_l=.5. Stance>half cycle gives brief double-pair support; deliberately grounded, no aerial phase. Existing Hermite swing preserves endpoint travel velocity; actual quaternion samples include lift-off knots. Loopquaternions close within1e-7.

Manifest existing locomotion contract automatically exports `trot`: in_place=true,+Zforward/metres,cycle_duration_s=.72,stance_fraction=.52,stride_m=1.3076923076923077,speed_m_s=1.8162393162393164. Actor translation distance is phase*stride_m; stance rootrelative Z travels backward at the matching speed. Phase=time/cycle. This metadata enables later distance-compatible transitions but **does not implement them**. Phase-continuous distance-preserving walk↔trot blending/start/stop, hitch/adaptive turning and gear/rider load remain untested/unaccepted.

`runtime-proposal/` and `source-runtime.patch` add actual clip dropdown and use active clip duration/stride instead of hardcoded walk duration. This avoids running.72second trot at1.25second walk phase. Browser proposal not yet exercised. Do not merge without actual browser/gait/gear/coupled validation.

## Actual evidence retained

- `solver-validation.json`:1000seeded3Dtargets,endpoint maxerror7.22e-16m,flat-sole orientationerror1.43e-16m,3unreachabletargetnegativecases rejected.
- `preservation-validation.json`: current integrated horsebaseline bytes SHA plus candidateSHA; exact allmesh POSITION/NORMAL/JOINTS/WEIGHTS/index arrays,scene nodes/materials,15jointtable/inversebind,all named socket/rest frames,oldidle/walk tracks+times+extras unchanged. Includes trot diagonal and quaternionloopclosure assertions.
- `rejected-contact-alias-validation.json`: first attempt accidentally reused contactmetadata dict across walk/trot, failing exact walk extras preservation. Retained failure; fixed with clip-local contact dict, not a weaker test. No rejected GLB represented as accepted. Initial Node module import failed before geometry load, resolved by original explicit local Three import hook (no app module edits).
- `actual-gait-validation.json`: actual decoded GLB;1441AnimationMixerposes EACH idle/walk/trot; all same existing authoredrestsole vertices, all24headneckboundarypairs. Idle slide0,height9.4nm. Walk slide20.34µm,maxstanceheight40.16µm,minsoleY−40.16µm. Trot slide8.12µm,maxstanceheight24.68µm,minsoleY−24.68µm,minextensionmargin7.43mm. Boundarygap0allclips. Existing meaningful20mmslide/5mmheight/−1mmpenetration gates unchanged. No marker reposition or relabeling.
- `deformation-validation.json`: actual exportedLBS surfaces33poses/clip,467676triangleevaluations EACH clip,no nonfinitevertices,mintrianglearea3.4817e-11m². Does not prove selfcollision-free, silhouette/anatomical quality or correct volumes.
- `khronos-validation.json`:0errors/0warnings. Candidate repeat regeneration byte-identical. Sixmaterialdraws/14172triangles/15joints unchanged; animation bytes increase only.

## Reproduction (existing installed dependencies, no browser)

```
python generate_horse.py --parameters parameters.json --output-dir output
python test_solver.py
python check_preservation.py
node --experimental-loader ./three-loader.mjs ./validate_gaits.mjs
node --experimental-loader ./three-loader.mjs ./check_deformation.mjs
node khronos.cjs
```

Scripts currently explicit local installed Three/validator paths for outside proof; root can port along existing transport test conventions before integration. No new source assets or provenance license dependencies. Original generator/solver CC0-1.0; actual Three validation glue follows GPLproject license. Preserve current head/neck+gear hashes and anatomy liberty declarations.

NEXT: after root resource release run real browser displayed trot including near/far actual views, actual sole checks, framecost and looping; rerun current pairedheadstrap and forelimb/torso clearances for trot (old walk-only21phase fit is NOT trotproof), then address distance-matched transitions and full anatomical pivots/skin. Retain any new failure; do not close T-2803 on this bounded study.
