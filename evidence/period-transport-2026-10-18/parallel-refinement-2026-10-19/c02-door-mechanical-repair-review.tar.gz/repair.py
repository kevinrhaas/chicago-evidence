from pathlib import Path
p=Path(__file__).parent/'generate_carriage_c02.py';s=p.read_text().replace("(.07,.035,.79),(.60,.795,.065)","(.07,.025,.79),(.60,.79,.065)").replace("for z in [-.35,.49]:box('cabin_door_jamb_lower_'+str(z),body,(.07,.22,.12),(.60,1.23,z),0)","for z in [-.38,.51]:box('cabin_door_jamb_lower_'+str(z),body,(.07,.22,.04),(.60,1.23,z),0)").replace("(.075,.08,.73),(.60,1.33,-.675)","(.075,.08,.69),(.60,1.33,-.675)").replace("for z in [-.335,.475]","for z in [-.335,.49]")
# Keep panel/wood inward from independent pin axis; fixed/moving leaves attach to different knuckles.
s=s.replace("(-.035,.26,.355)","(-.045,.26,.355)").replace("(-.035,.815,.355)","(-.045,.815,.355)").replace("(-.035,.54,z)","(-.045,.54,z)").replace("(-.035,y,.355)","(-.045,y,.355)").replace("(.025,.70,.62)","(.015,.70,.62)")
a=s.index('  # Hinge barrels at two heights');b=s.index("  box('door_handle'",a)
s=s[:a]+'''  # Original engineering hinge: two fixed knuckles alternate around one moving
  # knuckle. Pin radius5mm/bore6mm leaves1mm radial running gap, no contact waiver.
  for hy in [1.30,1.80]:
   for dy in [-.04,.04]:
    kn=node('door_fixed_knuckle',body,t=(.645,hy+dy,-.28),rotation=[0,0,math.sin(math.pi/4),math.cos(math.pi/4)])
    ring('hinge_fixed_knuckle',kn,.014,.006,.03,3)
    beam('hinge_fixed_arm',body,(.645,hy+dy,-.28),(.60,hy+dy,-.36),.008,3)
   pin=node('door_pin_frame',body,t=(.645,hy,-.28),rotation=[0,0,math.sin(math.pi/4),math.cos(math.pi/4)])
   ring('hinge_pin_tube',pin,.005,.001,.13,3)
   kn=node('door_moving_knuckle',door,t=(0,hy-.82,0),rotation=[0,0,math.sin(math.pi/4),math.cos(math.pi/4)])
   ring('hinge_moving_knuckle',kn,.014,.006,.03,3)
   beam('hinge_moving_arm',door,(0,hy-.82,0),(-.045,hy-.82,.055),.008,3)
''' +s[b:]
p.write_text(s)
