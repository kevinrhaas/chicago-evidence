from pathlib import Path
import json,hashlib,difflib,tarfile,struct,math
p=Path(__file__).parent;b=p.parent/'carriage-c02-door-next';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
r=json.loads((p/'triangle-receipt.json').read_text());assert all(x['triangle_intersections_including_contact']==0 for x in r['rows']);assert r['input_sha256']==sha(p/'export/carriage-c02.glb');assert r['generator_sha256']==sha(p/'generate_carriage_c02.py')
raw=(p/'export/carriage-c02.glb').read_bytes();ln=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+ln]);binary=raw[28+ln:];door=next(n for n in g['nodes'] if n['name']=='vehicle_door_left');radius=0
for i in door['children']:
 node=g['nodes'][i]
 if 'mesh' not in node:continue
 for q in g['meshes'][node['mesh']]['primitives']:
  a=g['accessors'][q['attributes']['POSITION']];v=g['bufferViews'][a['bufferView']]
  for j in range(a['count']):
   x,y,z=struct.unpack_from('<3f',binary,v['byteOffset']+12*j);radius=max(radius,math.hypot(x,z))
bound=2*radius*math.sin(math.radians(1.25));(p/'interval-bound.json').write_text(json.dumps({'max_actual_vertex_hinge_radius_m':radius,'nearest_sample_angle_max_deg':2.5,'rigid_surface_displacement_to_nearest_sample_upper_bound_m':bound,'continuous_global_clearance_certified':False,'reason':'Positive sampled triangle nonintersection does not supply a minimum distance larger than this displacement bound.16gon bore inscribedradius minus pinouterradius=.0008847117m, much smaller than globalbound. Discrete15angle proof only; no full interval or enclosedsolidcontainment claim.'},indent=2)+'\n')
render=json.loads((p/'render-receipt.json').read_text());assert not render['errors'];assert all(row['bytes']==len(raw) for row in render['rows'])
for a,c in zip(render['rows'][::2],render['rows'][1::2]):assert a['camera']==c['camera'] and a['framing']==c['framing']
protected=json.loads((p.parent/'carriage-c02-enclosure-repair/source-receipt.json').read_text())['protected_C01_hashes']
for name,h in protected.items():assert sha(Path('/workspace/chicago/chicago/4d')/name)==h
(p/'preservation-receipt.json').write_text(json.dumps({'C01_hashes':protected,'C01_unchanged':True,'flag_off_repaired_C02_byteidentity':(p/'baseline/carriage-c02.glb').read_bytes()==(p.parent/'carriage-c02-enclosure-repair/export/carriage-c02.glb').read_bytes(),'two_enabled_closed_runs_identical':raw==(p/'repeat/carriage-c02.glb').read_bytes(),'prior_visual_mechanical_fail_archive':str(b/'c02-rigid-door-visual-review.tar.gz'),'prior_visual_sha256':sha(b/'c02-rigid-door-visual-review.tar.gz'),'prior_triangle_fail_archive':str(p.parent/'carriage-c02-door-mechanics/c02-door-mechanical-failure-proof.tar.gz'),'prior_triangle_fail_sha256':sha(p.parent/'carriage-c02-door-mechanics/c02-door-mechanical-failure-proof.tar.gz')},indent=2)+'\n')
old=(b/'generate_carriage_c02.py').read_text();new=(p/'generate_carriage_c02.py').read_text();(p/'mechanical-repair-context.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/tools/transport/generate_carriage_c02.py',tofile='b/tools/transport/generate_carriage_c02.py')))
(p/'VISUAL-REVIEW.json').write_text(json.dumps({'actually_inspected':[x['file'] for x in render['rows']],'current_bytes':len(raw),'result':'All8 corrected currentbyte images inspected: shortenedjamb/sill/waist keep closed silhouette coherent, narrow seams remain. Sideopen view exposesfloor. Newspindlypin/alternatingknuckle hinges visible but small. No accidental daylightpaneholes seen. Bothviewports fullbodyandcontrols visible.','browser_closed':True,'errors':render['errors'],'shadowed_draws':render['rows'][0]['drawCalls'],'limits':['Flatdarkengineeringmaterials','No productionhinge/doorhistoricalsourceattestation','No occupant/boardingfit/cloth/passage/forces acceptance','No continuouscollisioninterval proof']},indent=2)+'\n')
(p/'README.md').write_text('''# C02 door mechanical repair — original development study

No app/queue writes. Independent1904development-only reconstruction; coarse photo silhouette only, no diagnosed subtype, owner, attested hinge/door/window design or photographic quality claim. Defaultflagoff retains repairedC02 bytes and all6protectedC01 hashes remain exact.

Original whole-door mechanical failure preserved separately; first hinge reconstruction failed too (copied exactloadedsource/GLB/receipt underrejected-first-hinge, including explicit loaded-generator hash correction). Current repair shortens/repositions fixedjamb/sill/waist, moves hingeaxis10mm outward to(.655,.82,-.28), moves woodenleaf10mminward tokeepclosedbodyposition, and replaces overlappinghingeboxes with pin+alternatingknuckles+separateattachedarms. Pin5mmradius/bore6mmradius;16gonbores give conservative.8847mmradialgap;30mmknuckles at40mmcenteroffsets have10mmaxialgap. No hingecontact whitelist; requirezero triangleintersections INCLUDINGtouches.

`check_triangles.py` matches everyactualGLBtriangle tosourcepartlabel within1µm, then moves allactualdoor/frame/pane/handle/knuckle/arm triangles against EVERYfixed triangle (cabin, roof, interiorbench, step,wheels,chassis,hinges). AABBonlybroadphase then triangleSAT. All11512triangles accounted,15discreteangles0..70by5degrees:ZEROintersections/contact, noexemptions. Triangle tolerance10nm, candidate mappingrounding10µm followedactual1µmverification. Surface test does not proveabsenceofcompletecontainment or continuousintervalclearance. interval-bound.json derives actualrigidmotionbound to nearestsample; cannot certifyglobalsweep fromsamplednonintersection. No passenger/boardingfit/cloth/grasp/forces acceptance.

Current11512triangles31batches62nodes,closed860200B/open860232B;enabledclosedtworunsbyteidentical,Khronos0errors/0warningsbothstates. Morehingegeometrythanpriorfailed10416tri,drawcallsremain64shadowed inactualfixture. Existingwheel/pivot/seat/hitchcontract unchanged.

Eight NEWactualcurrentbyte desktop/mobile rear/side closed/open captures inspected aftermechanicalrepair, same unioncamera/light eachpair,fullbody+44pxcontrols visible,zeroJS/request/GLerrors. Closedbodycoherent withnarrowintentionaljoints; openviewshowsrealcabin floor. PriorvisualimagesareNOTreused. Browserclosed; noserverstarted. Newhinge armslookspindlyandmaterialsuntextured: developmentqualityonly. Source/recordlicensingbounds unchangedGPLoriginalgeometryandglue;nophotoassetscopied.

Reproduce `python check_triangles.py`; generates onlyoutsideinput. `generate_carriage_c02.py --parameters door-parameters.json --output-dir export`, `--door-angle-deg 70` foropen. NumPyexistingdependency,noBlender. Contextpatch appliesagainstpreviousdoorproposal only; rootreview/integration required, notappapplied. Priorimmutablearchives named+hashedinpreservationreceipt.
''')
files=sorted(f for f in p.rglob('*') if f.is_file() and not f.name.endswith('.tar.gz') and f.name!='archive-receipt.json' and 'baseline' not in f.parts and 'repeat' not in f.parts);a=p/'c02-door-mechanical-repair-review.tar.gz';rows=[{'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':sha(f)} for f in files]
with tarfile.open(a,'w:gz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(p)),recursive=False)
with tarfile.open(a) as t:
 for row in rows:assert hashlib.sha256(t.extractfile(row['path']).read()).hexdigest()==row['sha256']
out={'archive':str(a),'sha256':sha(a),'bytes':a.stat().st_size,'members':rows};(p/'archive-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k!='members'});print('members',len(rows))
