# SPDX-License-Identifier: GPL-3.0-or-later
import unittest,json,math
from pathlib import Path
from human_work_motion import work_pose
ROOT=Path('/workspace/chicago/chicago/4d')
class Motion(unittest.TestCase):
 def test_actual_named_bodies(self):
  recipe=json.loads((ROOT/'data/humans/recipes/worker_1835.json').read_text());self.rows=[]
  for v in recipe['proof_variants']:
   body=json.loads((ROOT/v['body_input']).read_text());rest={b['name']:b['head_m']for b in body['skeleton']};maximum=0
   for i in range(61):
    p=work_pose(body,i/60)
    self.assertEqual(set(rest),set(p['bone_global_head_rotation']))
    for side in ['l','r']:
     for n in ['thigh','calf','foot','ball']:
      self.assertLess(math.dist(p['bone_global_head_rotation'][n+'_'+side]['head_m'],rest[n+'_'+side]),1e-14)
    self.assertEqual(p['bone_global_head_rotation']['pelvis']['head_m'],rest['pelvis'])
    maximum=max(maximum,max(x['endpoint_error_m']for x in p['arm_ik']))
   self.assertLess(maximum,1e-12)
   self.assertEqual(work_pose(body,0),work_pose(body,1))
   self.rows.append({'variant':v['id'],'person':v['person_reference_id'],'sampled_frames':61,'max_arm_endpoint_error_m':maximum,'root_translation_m':0,'leg_joint_translation_m':0})
  Path('work-motion-receipt.json').write_text(json.dumps({'scope':'actual prepared source-joint math only; no Blender/GLB/skin/garment or work acceptance','rows':self.rows},indent=2)+'\n')
 def test_nonfinite_refused(self):
  with self.assertRaises(ValueError):work_pose({},float('nan'))
if __name__=='__main__':unittest.main()
