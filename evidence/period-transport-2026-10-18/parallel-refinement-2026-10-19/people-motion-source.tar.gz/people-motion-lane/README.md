# Shared resident motion and driver lane — unaccepted outside proposal

Actual advance: `human_work_motion.py` implements a pure source-frame two-segment arm IK loop using each prepared body's actual segment lengths. Feet, pelvis and leg joints remain stationary. The hands make a40mm unloaded reach, not a claimed tool operation or palm grip. No anonymous identity is introduced. Two stdlib tests sample61frames for each existing reconstructed1835 reference (Otis Bardwell, Joseph Dufresne, Martin Flynn), prove cyclic endpoints, unchanged leg joints/root, reject nonfinite phase, and measure maximum arm endpoint residual3.11e-16m. `work-motion-receipt.json` is joint-math evidence ONLY, not skin/garment/historical movement acceptance.

`human_motion_library_blend.py` is an additive CI-only authoring proposal loading an EXISTING resident canonical master. It requires matching person/asset/body/scene metadata, actual56bones and matching prepared rest heads, leaves existing idle/walk actions intact and refuses overwriting actions. It adds work_inspect, and optionally the corrected source-bound physical-bench sit_drive study. It converts global source deformations through ACTUAL Blender rest matrices, keys location/quaternion/scale, uses the existing Blender4.5-aware linearizer and saves REST. The authoring module has only been syntax checked; no Blender execution or master output exists from this task. No new idle/walk implementation competes with existing grounded gait.

Before root CI use, install the three helper modules under app tools (or place them beside this script), review the patch independently, and supply an actual qualified input master. Example remote CI invocation, NOT a local instruction:

```
blender -b --python human_motion_library_blend.py -- --app-root APP --master RESIDENT.blend --output RESIDENT-motion-study.blend --variant bardwell_otis_1835
```

Optional seated study adds `--sit-drive-study PATH/resident-driver-bindings-triangle-corrected.json --sit-drive-vehicle ACTUAL_BENCH_EXPORT.json`. Use only the corrected pose files from `/workspace/shared/resident-wagon-driver-draft/` and the actual exported bench study; default W01 empty seat socket is not physical furniture. `human_seated_study.py` is the prior source-bound helper copied with its license. Its vehicle/body/pose hash gates remain enforced. Current C01 is1904only; this1835 wardrobe must never be fitted as an accepted1904coachman.

T1790: recommend root claim an isolated shared-library subset while preserving T1789 dependency and open completion. Idle/walk already exist but are not new acceptance from this task. Full ticket still needs alternate idle, talk/face/gesture/carry, real actor transitions, exported foot/skin/contact measurements and CPU/frame performance. work_inspect is a bounded unloaded arm study, not enough to satisfy an actual work/held-object motion by itself.

T2804: recommend consume the triangle-corrected W01 static fit AFTER physical bench integration and canonical garment/shoe/self-contact export verification. Do not claim sit_drive transport synchronization, rein grasp/slack or driving forces. Do not add sit_ride until an actual physical saddle/tack and horse gait fit are available; an empty socket is not saddle support. Dependencies listed in T2804 (T2672,T1789,T1790,T1792,T2801,T2802,T2803) remain open proofs, not skipped by this authoring draft.1812 candidate and contract gaps are in1812-candidate-audit.md.1904namedGlessner requires independently period-qualified wardrobe and resident role.

No app/queue mutation, browser, CI dispatch or local Blender. Root remains sole app/ticket writer. All production/photographic acceptance remains open.
