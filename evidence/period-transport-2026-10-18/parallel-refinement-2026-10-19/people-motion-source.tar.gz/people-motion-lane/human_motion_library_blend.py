# SPDX-License-Identifier: GPL-3.0-or-later
"""CI-only additive canonical-master motion study. Never execute Blender locally.

Loads an existing 1835 resident master; preserves its idle/walk actions, appends
work_inspect and optionally hash-bound W01 sit_drive. No mounted riding clip.
"""
import argparse,hashlib,json,sys
from pathlib import Path

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--app-root',required=True,type=Path);p.add_argument('--master',required=True,type=Path);p.add_argument('--output',required=True,type=Path)
 p.add_argument('--variant',required=True);p.add_argument('--sit-drive-study',type=Path);p.add_argument('--sit-drive-vehicle',type=Path)
 args=p.parse_args(sys.argv[sys.argv.index('--')+1:] if '--'in sys.argv else [])
 if args.master.resolve()==args.output.resolve():raise ValueError('preserve input master: distinct output required')
 if bool(args.sit_drive_study)!=bool(args.sit_drive_vehicle):raise ValueError('both study and physical vehicle sidecar required')
 root=args.app_root.resolve();sys.path.insert(0,str(root/'tools'))
 from human_grounded_gait import linearize_action
 from human_seated_study import load_study,desired_matrix,local_basis
 from human_work_motion import work_pose
 recipe=json.loads((root/'data/humans/recipes/worker_1835.json').read_text());variants=[v for v in recipe['proof_variants']if v['id']==args.variant]
 if len(variants)!=1:raise ValueError('existing named1835 recipe variant required')
 v=variants[0];bodypath=root/v['body_input'];body=json.loads(bodypath.read_text());contract=json.loads((root/'data/humans/contract.json').read_text());parents=dict(contract['skeleton']['bones'])
 import bpy
 from mathutils import Matrix
 bpy.ops.wm.open_mainfile(filepath=str(args.master))
 scene=bpy.context.scene;meta=scene.get('chicago4d_human')
 if meta is None or meta.get('person_reference_id')!=v['person_reference_id'] or str(meta.get('person_reference_scene'))!='1835':raise ValueError('canonical master identity/scene mismatch')
 if meta.get('asset_id')!=v['id'] or meta.get('body_input')!=v['body_input']:raise ValueError('canonical master body/asset mismatch')
 rigs=[o for o in scene.objects if o.type=='ARMATURE']
 if len(rigs)!=1:raise ValueError('exactly one canonical armature required')
 rig=rigs[0]
 if set(rig.data.bones.keys())!=set(parents):raise ValueError('canonical56-joint rig required')
 if any(abs(x-1)>1e-9 for x in rig.scale) or rig.location.length>1e-9:raise ValueError('metre canonical root must retain unit scale and zero location')
 for bone in body['skeleton']:
  x,y,z=bone['head_m'];actual=rig.data.bones[bone['name']].head_local
  if sum((actual[i]-target)**2 for i,target in enumerate((x,-z,y)))>1e-12:raise ValueError('canonical rest heads differ from prepared body: '+bone['name'])
 if not {'idle','walk'}.issubset({a.name for a in bpy.data.actions}):raise ValueError('preserve actual existing idle/walk; do not substitute placeholders')
 rests={n:[list(row)for row in rig.data.bones[n].matrix_local]for n in parents};rig.animation_data_create()
 def author(name,frames,length,sample,details):
  if bpy.data.actions.get(name):raise ValueError('refuse overwriting existing action '+name)
  act=bpy.data.actions.new(name);act.use_fake_user=True;rig.animation_data.action=act
  act['loop']=True;act['cycle_duration_s']=length/30;act['speed_m_s']=0.;act['motion_basis']=details;act['person_reference_id']=v['person_reference_id'];act['scene']='1835'
  for frame in frames:
   pose=sample((frame-1)/length);desired={n:desired_matrix(pose[n],rests[n])for n in parents}
   for n,parent in parents.items():
    pb=rig.pose.bones[n];pb.rotation_mode='QUATERNION';pb.matrix_basis=Matrix(local_basis(rests[n],desired[n],rests[parent]if parent else None,desired[parent]if parent else None))
    # Canonical rigid-frame exporter refuses even identity authored scale curves.
    if any(abs(x-1)>1e-7 for x in pb.scale):raise ValueError('source pose introduced bone scale')
    pb.scale=(1,1,1)
    for attr in ('rotation_quaternion','location'):pb.keyframe_insert(attr,frame=frame)
  linearize_action(act)
  return act
 author('work_inspect',range(1,62),60,lambda q:work_pose(body,q)['bone_global_head_rotation'],'Original unloaded reach/inspection source-IK study; no tool or cargo grip, no occupational gesture attestation; skin/cloth/contact acceptance pending')
 if args.sit_drive_study:
  pose,receipt=load_study(args.sit_drive_study,v,bodypath,1.,args.sit_drive_vehicle)
  if set(pose)!=set(parents):raise ValueError('seated pose joint mismatch')
  act=author('sit_drive',(1,31),30,lambda q:pose,'Original static W01 bench IK study; not driving dynamics, rein grasp or canonical garment/contact acceptance')
  act['driver_study_json']=json.dumps(receipt,sort_keys=True)
 rig.animation_data.action=None
 for pb in rig.pose.bones:pb.matrix_basis=Matrix.Identity(4)
 scene.frame_set(1)
 scene['motion_library_study_json']=json.dumps({'source_master_sha256':hashlib.sha256(args.master.read_bytes()).hexdigest(),'source_body_sha256':hashlib.sha256(bodypath.read_bytes()).hexdigest(),'person_reference_id':v['person_reference_id'],'scene':'1835','new_clips':['work_inspect']+(['sit_drive']if args.sit_drive_study else []),'status':'CI authoring study; actual exported deformation/cloth/contact/playback acceptance required'},sort_keys=True)
 args.output.parent.mkdir(parents=True,exist_ok=True);bpy.ops.wm.save_as_mainfile(filepath=str(args.output))
if __name__=='__main__':main()
