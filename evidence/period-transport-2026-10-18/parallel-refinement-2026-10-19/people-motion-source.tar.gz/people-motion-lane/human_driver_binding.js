// SPDX-License-Identifier: GPL-3.0-or-later
// Opt-in isolated study adapter; no scene placement or production acceptance.
export function validateDriverFit({ profile, personId, scene, vehicle }) {
  if (scene !== '1835' || profile.scene !== scene) throw Error('1835 driver study only');
  if (vehicle.asset_id !== 'wagon_w01_driver_bench_study' || profile.vehicle_variant !== vehicle.asset_id) throw Error('physical W01 bench variant required');
  const f = vehicle.driver_furniture;
  if (f?.variant !== 'removable_bench_study' || JSON.stringify(f.seat_surface_m) !== '[0,1.58,0.65]' || JSON.stringify(f.footboard_bounds_xz_m) !== '[-0.425,0.425,1.12,1.42]' || f.footboard_top_m !== 1.12) throw Error('furniture changed: solve actual geometry again');
  const rows = profile.resident_bindings.filter(r => r.person_reference_id === personId);
  if (rows.length !== 1) throw Error('unique existing named resident binding required');
  return rows[0];
}
export function requireMountedFit(input) {
  // Empty horse sockets are deliberately insufficient. No accepted tack fit exists
  // in this proposal, so do not turn a future boolean into riding acceptance.
  throw Error('mounted human fit unavailable: actual saddle/tack geometry and canonical contact/gait evidence required');
}
export function bindDriverStudy({ actor, vehicleRoot, vehicle, profile, scene, engineeringStudy = false }) {
  if (!engineeringStudy) throw Error('unaccepted study must be explicitly opted in');
  const row = validateDriverFit({profile, personId: actor.personId, scene, vehicle});
  if (actor.instance.appearance.asset_id !== row.asset_id || !actor.clips.includes('sit_drive')) throw Error('matching loaded resident asset and exact sit_drive clip required');
  if (actor.route?.length) throw Error('seated driver cannot retain a pedestrian route');
  // HumanActor.update measures camera distance using root.position directly, so
  // do NOT parent its root below the vehicle: that would make distance local.
  // Copy the vehicle world transform into the existing identity-world parent.
  const parent = actor.root.parent;
  const identityParent = () => {
    parent?.updateWorldMatrix(true, false);
    if (parent && parent.matrixWorld.elements.some((x,i) => Math.abs(x-(i%5===0?1:0)) > 1e-8)) throw Error('HumanActor requires identity-world parent for existing distance API');
  };
  identityParent();
  const saved = {state:actor.state,clip:actor.clipName,e:actor.e,n:actor.n,heading:actor.heading};
  actor.state = 'standing';
  if (!actor.play('sit_drive',{fade:0,loop:true,time:0})) throw Error('sit_drive failed to play');
  let closed=false;
  function update(dt, cameraWorldPosition) {
    if (closed) throw Error('driver study binding disposed');
    identityParent();vehicleRoot.updateWorldMatrix(true,false);
    vehicleRoot.matrixWorld.decompose(actor.root.position,actor.root.quaternion,actor.root.scale);
    if ([actor.root.scale.x,actor.root.scale.y,actor.root.scale.z].some(x=>Math.abs(x-1)>1e-8)) throw Error('metre-scale vehicle root required');
    // sit_drive contains the full pelvis placement relative to wagon origin.
    // No extra seat socket translation is added.
    actor.root.updateMatrixWorld(true);
    return actor.update(dt,cameraWorldPosition);
  }
  return { row, update, dispose() {
    if (closed) return;closed=true;
    actor.state=saved.state;actor.e=saved.e;actor.n=saved.n;actor.heading=saved.heading;
    actor.root.scale.set(1,1,1);actor.place();
    if (saved.clip) actor.play(saved.clip,{fade:0});
  }};
}
