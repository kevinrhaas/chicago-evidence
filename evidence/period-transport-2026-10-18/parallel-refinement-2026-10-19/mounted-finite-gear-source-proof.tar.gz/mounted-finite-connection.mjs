// SPDX-License-Identifier: GPL-3.0-or-later
import{createAwaitedFiniteStop}from'./finite-stop-adapter.mjs';
export function selectExactStop(profiles,entry){
 if(!entry||Math.abs(entry.heading_change_rad)>1e-9)return null;
 return profiles.find(p=>p.initial_clip===entry.clip&&Math.abs(p.initial_phase-entry.phase)<1e-8&&Math.abs(p.initial_speed_m_s-entry.speed_m_s)<1e-7&&entry.remaining_distance_m>=p.root_distance_m+1e-6)??null;
}
export function connectMountedFiniteStop({player,stopProfiles,getEntry,isNeutral}){
 const stopVehicle=createAwaitedFiniteStop({player,isNeutral,selectStop(){const entry=getEntry();const p=selectExactStop(stopProfiles,entry);return p?{profileName:p.name,entry}:null;}});
 return {stopVehicle,beforeRide(){stopVehicle.resetForRide();},tick(dt){player.tick(dt);},async dispose(){await stopVehicle({immediate:true});await player.dispose();}};
}
