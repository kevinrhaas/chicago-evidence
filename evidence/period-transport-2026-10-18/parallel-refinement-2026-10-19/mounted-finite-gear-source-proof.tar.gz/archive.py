from pathlib import Path
import hashlib,json,tarfile
p=Path(__file__).parent
readme=p/'README.md';s=readme.read_text().replace('Await actual finite player source before final integration/browser verification. No actual rendered tack/rider or full fixture claim in this parcel.','Actual stable finite player modules copied verbatim into player-baseline; hashes match archive09de08f. Single actual GLB stop_walk_phase_013 connection test passes: leave interrupted by disposal stays attached/reserved until actual final idle0, then detaches once without resolving exit. Two finite pose samples only; no dense rerun during root gate. No coupled browser test, actual rendered tack/rider or full fixture claim in this parcel.');readme.write_text(s)
paths=[p/'player-baseline/finite-player.js',p/'player-baseline/finite-profile.js',Path('/workspace/shared/horse-finite-player-next-2026-10-19.tar.gz')]
(p/'player-baseline-hashes.json').write_text(json.dumps({str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in paths},indent=2)+'\n')
receipt={'passed':['actual30clip gear head matrices180samples','single actualGLB finite player+strict core cancellation/disposal connection','deferred stop adapter ownership','failed recovery retains seat and blocks dispose then successful retry','deferred leave canceled bydispose holds attachment untilneutral','existing mounted/passenger regression files'],'not_claimed':['arbitraryphase stop selection','turning recovery','remainingroute planning','occupied rider/saddle/tack acceptance','coupled browser proof','gear collision clearance','production acceptance'],'browser':'not launched','application_changes':False}
(p/'SUMMARY.json').write_text(json.dumps(receipt,indent=2)+'\n')
files=sorted(x for x in p.rglob('*') if x.is_file() and not x.name.endswith('.tar.gz') and x.name!='archive-receipt.json');a=p/'mounted-finite-gear-source-proof.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(p)),recursive=False)
rows=[{'path':str(f.relative_to(p)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in files]
with tarfile.open(a) as t:
 for row in rows:assert hashlib.sha256(t.extractfile(row['path']).read()).hexdigest()==row['sha256']
out={'archive':str(a),'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'bytes':a.stat().st_size,'members':rows};(p/'archive-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k!='members'});print('members',len(rows))
