// SPDX-License-Identifier: GPL-3.0-or-later
// Separate opt-in helper: does not mutate standalone attachment defaults.
export function bindHeadToActualParent(gearHead,horseHead){
 if(!gearHead?.parent||!horseHead)throw Error('Actual gear-head parent and horse-head nodes required');
 horseHead.updateWorldMatrix(true,false);gearHead.parent.updateWorldMatrix(true,false);
 const local=gearHead.parent.matrixWorld.clone().invert().multiply(horseHead.matrixWorld);
 local.decompose(gearHead.position,gearHead.quaternion,gearHead.scale);
 if(gearHead.scale.toArray().some(v=>Math.abs(v-1)>1e-6))throw Error('Scaled attachment frames unsupported by this study');
 gearHead.updateWorldMatrix(false,true);return local;
}
