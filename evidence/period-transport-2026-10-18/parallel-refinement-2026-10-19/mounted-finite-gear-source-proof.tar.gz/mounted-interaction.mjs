// SPDX-License-Identifier: GPL-3.0-or-later
// Thin domain gate; SAME shared asynchronous interaction/occupancy controller.
import {BoardingController,createSeatRegistry} from './interaction-core-finite-proposed.mjs';
export {createSeatRegistry};
export function validateHorseAnchors(manifest,nodes){
 const required=['socket_equine_saddle','socket_equine_rider_seat'];const anchors={};const parents=new Map();for(const node of nodes)for(const child of node.children??[])parents.set(nodes[child]?.name,node.name);
 for(const name of required){const entry=manifest.sockets?.find(s=>s.name===name),node=nodes.find(n=>n.name===name);if(!entry||!node)throw Error(`Actual exported horse anchor missing:${name}`);if(parents.get(name)!==entry.parent)throw Error(`Horse anchor parent differs from manifest:${name}`);const p=node.translation??[0,0,0];if(!entry.translation_m.every((v,i)=>Math.abs(v-p[i])<1e-7))throw Error(`Horse anchor differs from manifest:${name}`);anchors[name]={...entry};}
 return anchors;
}
export function createMountedInteraction({instanceId,manifest,nodes,scene,adapter,registry=createSeatRegistry(),mode='camera-study',person=null,gates={},reducedMotion=false}){
 if(!instanceId)throw Error('Explicit horse instance identity required');
 if(!['1835','1904'].includes(scene))throw Error('Explicit supported study scene required');
 const anchors=validateHorseAnchors(manifest,nodes);
 if(mode==='occupied-production'&&Object.values(anchors).some(a=>a.status==='provisional_unfitted'))throw Error('Provisional horse sockets are not fitted riding gear');
 const seats=[{id:'rider',role:'rider',socket:'socket_equine_rider_seat',boardingSocket:'socket_equine_saddle',eligibleScenes:[scene],mountLanding:'Derived from actual horse envelope on fixture floor, NOT an exported or accepted groundmount anchor'}];
 const controller=new BoardingController({vehicleId:instanceId,scene,seats,adapter,registry,mode,person,gates,reducedMotion,role:'rider'});
 return {controller,anchors,limits:['No accepted groundmount anchor','Saddle/rider sockets provisional until qualified','Camera-study has no rider/saddle/physicalmount acceptance']};
}
export function travelPhase(distance,stride){if(!Number.isFinite(distance)||distance<0||!Number.isFinite(stride)||stride<=0)throw Error('Finite nonnegative travel and positive exported stride required');return (distance/stride)%1;}
export function integrateHorsePath(pose,ds,steer,limit=.12){if(!Number.isFinite(ds)||ds<0||!Number.isFinite(steer)||Math.abs(steer)>limit)throw Error('Bounded positive travel/steering required');const yaw=pose.yaw+ds*steer;return {x:pose.x+(Math.abs(steer)>1e-9?(Math.cos(pose.yaw)-Math.cos(yaw))/steer:Math.sin(pose.yaw)*ds),z:pose.z+(Math.abs(steer)>1e-9?(Math.sin(yaw)-Math.sin(pose.yaw))/steer:Math.cos(pose.yaw)*ds),yaw,distance:pose.distance+ds};}
