// SPDX-License-Identifier: GPL-3.0-or-later
const abortError=()=>Object.assign(Error('Stop waiter canceled; owned recovery continues'),{name:'AbortError'});
export function createAwaitedFiniteStop({player,selectStop,isNeutral}){
 let owned=null,completed=null;
 function wait(promise,signal){if(!signal)return promise;if(signal.aborted)return Promise.reject(abortError());return new Promise((resolve,reject)=>{const abort=()=>{signal.removeEventListener('abort',abort);reject(abortError());};signal.addEventListener('abort',abort,{once:true});promise.then(v=>{signal.removeEventListener('abort',abort);resolve(v);},e=>{signal.removeEventListener('abort',abort);reject(e);});});}
 const stopVehicle=async function stopVehicle({signal,immediate=false}={}){
  // 'immediate' from generic rollback deliberately does NOT snap pose or abort recovery.
  if(signal?.aborted)throw abortError();
  if(!owned){if(isNeutral())return {completed:true,finalNeutral:true,alreadyNeutral:true};const request=selectStop();if(!request)throw Error('No qualified finite stop for current exact entry; attachment must remain held');
   owned=Promise.resolve().then(()=>player.playFinite(request)).then(result=>{if(!result?.completed||!result?.finalNeutral||!isNeutral())throw Error('Finite player did not qualify final neutral; attachment must remain held');completed=result;return result;});
   // Keep rejection owned for subsequent rollback callers, never convert it to success.
   owned.catch(()=>{});
  }
  const result=await wait(owned,signal);return {...result,rollbackWait:immediate};
 };
 stopVehicle.resetForRide=()=>{if(owned&&!completed)throw Error('Recovery still pending or failed; cannot start another ride');owned=null;completed=null;};
 return stopVehicle;
}
