import runpy,sys,struct,json,hashlib,math
from pathlib import Path
import numpy as np
p=Path(__file__).parent;sys.argv=[str(p/'generate_carriage_c02.py'),'--parameters',str(p/'door-parameters.json'),'--output-dir',str(p/'export')];e=runpy.run_path(str(p/'generate_carriage_c02.py'));ns=e['oldnodes'];parent={c:i for i,n in enumerate(ns) for c in n.get('children',[])}
def world(i):
 m=e['local'](ns[i])
 while i in parent:i=parent[i];m=e['local'](ns[i])@m
 return m
parts={};moving=[]
for i,n in enumerate(ns):
 if 'mesh' not in n:continue
 tri=[]
 for q in e['oldmeshes'][n['mesh']]['primitives']:
  a=e['oldaccess'][q['attributes']['POSITION']];v=e['oldviews'][a['bufferView']];xyz=np.array(struct.unpack_from('<%sf'%(a['count']*3),e['oldbinary'],v['byteOffset'])).reshape(-1,3);m=world(i);tri.extend(xyz@m[:3,:3].T+m[:3,3])
 arr=np.array(tri);parts.setdefault(n['name'],[]).append(arr)
 j=i
 while j in parent and ns[j]['name']!='vehicle_door_left':j=parent[j]
 if ns[j]['name']=='vehicle_door_left':moving.append(arr)
d=np.concatenate(moving);bottom=float(d[:,1].min());top=float(d[:,1].max());checks=[]
for label,prefixes,direction in [('rear_mudguards',['rear_mudguard'],'above'),('wheels',['iron_tyre','felloe','hub'],'above'),('step',['door_step_tread'],'above'),('roof_surround',['window_roof_rail_1','crowned_cabin_roof'],'below')]:
 arr=np.concatenate([a for name,groups in parts.items() if any(name.startswith(x) for x in prefixes) for a in groups]);gap=bottom-float(arr[:,1].max()) if direction=='above' else float(arr[:,1].min())-top
 checks.append({'fixed_parts':label,'separating_axis':'+Y','gap_m':gap,'all_hinge_angles_safe_by_constant_Y':gap>0});assert gap>0,(label,gap)
# Fixed-jamb/hinge furniture and lowerwall require exact interference proof separately.
receipt={'status':'Bounded actual decoded source geometry separation, no complete swept collision acceptance','checks':checks,'door_y_bounds_m':[bottom,top],'hinge_angles_deg':[0,35,70],'source_C01_protected':json.load(open(p.parent/'carriage-c02-enclosure-repair/source-receipt.json'))['protected_C01_hashes'],'limitations':['Fixedjamb/hinge interfaces intentionally close fitting; no complete triangle-vs-triangle swept clearance proof yet','No occupant, grasp, clothing, passage width or production door-function acceptance','All dimensions/door/window/step/hinge layout reconstructed,1904developmentonly']}
for name,h in receipt['source_C01_protected'].items():assert hashlib.sha256((Path('/workspace/chicago/chicago/4d')/name).read_bytes()).hexdigest()==h
(p/'clearance-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
