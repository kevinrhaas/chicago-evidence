from pathlib import Path
import json
p=Path(__file__).parent;s=(p/'generate_carriage_c02.py').read_text();s=s.replace("# C02: separate enclosed", "DOOR=params.get('operable_door_study',False)\nif not isinstance(DOOR,bool):raise ValueError('operable_door_study must be boolean')\ndoor=node('vehicle_door_left',body,t=(.645,1.12,-.93)) if DOOR else None\n# C02: separate enclosed")
s=s.replace("geom('cabin_lower_side_'+str(side),body,vs,faces,0)","""if DOOR and side==1:
  # Original lower fixed wall retains the full silhouette but stops beneath leaf.
  lowvs=[[v[0],min(v[1],1.12),v[2]] for v in vs]
  geom('cabin_lower_fixed_door_sill',body,lowvs,faces,0)
  # Leaf lower panel and fixed end jambs fill the former upper lower-wall band.
  box('door_lower_panel',door,(.045,.22,1.34),(-.035,.11,.68),0)
  for z in [-1.00,.48]:box('cabin_door_jamb_lower_'+str(z),body,(.07,.22,.12),(.60,1.23,z),0)
 else:geom('cabin_lower_side_'+str(side),body,vs,faces,0)""")
s=s.replace("box('side_glazing_'+str(side),body,(.025,.66,1.50),(side*.595,1.67,-.25),6)","""if DOOR and side==1:
  box('door_glazing',door,(.025,.55,1.24),(-.035,.53,.68),6)
  for z in [0,1.36]:box('door_vertical_stile',door,(.065,.87,.065),(-.035,.435,z),0)
  for y in [.025,.235,.835]:chamfered_rail('door_horizontal_rail',door,(.065,.065,1.40),(-.035,y,.68),0)
  # Hinge barrels at two heights; static pintles and moving leaves are original.
  for y in [1.30,1.80]:
   box('door_fixed_hinge',body,(.065,.10,.035),(.645,y,-.93),3)
   box('door_hinge_leaf',door,(.015,.08,.10),(0,y-1.12,.05),3)
  box('door_handle',door,(.055,.018,.09),(.025,.39,1.25),3)
  # Wider tread and two supports remain stationary below the swing.
  box('door_step_tread',body,(.34,.055,.62),(.80,.38,-.25),4)
  for z in [-.48,-.02]:beam('door_step_support',body,(.49,.74,z),(.80,.38,z),.032,4)
 else:box('side_glazing_'+str(side),body,(.025,.66,1.50),(side*.595,1.67,-.25),6)""")
s=s.replace("if DOOR else None", "if DOOR else None")
s=s.replace("frames={i for i,n in enumerate(nodes) if n['name'] in", "frames={i for i,n in enumerate(nodes) if n['name']=='vehicle_door_left' or n['name'] in")
s=s.replace("sidecar['boarding_enabled']=False", "sidecar['boarding_enabled']=False\nif DOOR:sidecar['door_study']={'node':'vehicle_door_left','hinge_axis':'+Y','closed_angle_deg':0,'open_angle_deg':70,'hinge_parent_translation_m':[.645,1.12,-.93],'status':'original reconstructed rigid door/hinge/step layout; no sourced design or occupant acceptance','production_enabled':False}")
# Fixed waist and upper/lower decorative frames would cross the door opening: replace those moving-span lines only in study.
s=s.replace("box('waist_rail_'+str(side),body,(.055,.055,1.62),(side*.60,1.325,-.25),0)","if not(DOOR and side==1):box('waist_rail_'+str(side),body,(.055,.055,1.62),(side*.60,1.325,-.25),0)")
s=s.replace("box('window_lower_frame_'+str(side),body,(.045,.025,1.52),(side*.612,1.36,-.25),0)","if not(DOOR and side==1):box('window_lower_frame_'+str(side),body,(.045,.025,1.52),(side*.612,1.36,-.25),0)")
s=s.replace("box('window_upper_frame_'+str(side),body,(.045,.025,1.52),(side*.612,1.98,-.25),0)","if not(DOOR and side==1):box('window_upper_frame_'+str(side),body,(.045,.025,1.52),(side*.612,1.98,-.25),0)")
(p/'generate_carriage_c02.py').write_text(s);d=json.loads((p/'parameters.json').read_text());d['operable_door_study']=True;(p/'door-parameters.json').write_text(json.dumps(d,indent=2)+'\n')
