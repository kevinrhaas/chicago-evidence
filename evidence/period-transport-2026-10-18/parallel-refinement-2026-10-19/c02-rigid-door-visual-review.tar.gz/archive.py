from pathlib import Path
import json,hashlib,struct,difflib,tarfile
p=Path(__file__).parent;b=p.parent/'carriage-c02-enclosure-repair'
old=(b/'generate_carriage_c02.py').read_text();new=(p/'generate_carriage_c02.py').read_text();(p/'door-context.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/tools/transport/generate_carriage_c02.py',tofile='b/tools/transport/generate_carriage_c02.py')))
def decode(path):
 raw=path.read_bytes();n=struct.unpack_from('<I',raw,12)[0];return json.loads(raw[20:20+n]),raw[28+n:]
a,ab=decode(p/'export/carriage-c02.glb');c,cb=decode(p/'open/carriage-c02.glb');assert ab==cb
na={n['name']:n for n in a['nodes']};nc={n['name']:n for n in c['nodes']}
for name in na:
 if name!='vehicle_door_left':assert na[name]==nc[name],name
assert (p/'baseline/carriage-c02.glb').read_bytes()==(b/'export/carriage-c02.glb').read_bytes();assert (p/'export/carriage-c02.glb').read_bytes()==(p/'repeat/carriage-c02.glb').read_bytes()
report={'closed_open_geometry_buffer_bytes_identical':True,'closed_open_only_door_node_rotation_changes':True,'closed_repeat_bytes_identical':True,'flag_off_repaired_C02_bytes_identical':True,'triangles':10416,'material_batches':31,'nodes':54,'closed_bytes':(p/'export/carriage-c02.glb').stat().st_size,'open_bytes':(p/'open/carriage-c02.glb').stat().st_size,'render_status':'Actual corrected8desktop/mobile images inspected; first8visualfails preserved; browserclosed','source_reference':'a16-pullman-det-4a08065 coarse silhouette only; no owner/subtype/door construction measured','licensing':'Original project-derived GPL-3.0-or-later source/geometry; no photo pixels or textures copied'}
(p/'state-receipt.json').write_text(json.dumps(report,indent=2)+'\n')
(p/'README.md').write_text('''# C02 original rigid door study — source-only checkpoint

No app/queue writes. Separate opt-in `operable_door_study:true` parameter. Default off reproduces repaired C02 GLB byte-for-byte. Original repaired and failed visuals preserved in sibling directories. Source photo supports coarse roofed silhouette only; side, window/door layout, hinges, threshold, handle, step and dimensions are independently reconstructed.1904development only, no Pullman ownership/subtype claim.

Current narrow door cuts a real opening through stationary sidewall: fixed rear/front portions remain, floor sill follows cabin floor. Hinge(.645,.82,-.28),rigid+Y0..70degrees; pane/rails/lower panel move as one frame. Separate rear fixed pane and transom close surrounding body. No door across a full opaque stationary panel. Leaf loweredge.8125m, cabin floor top.78m, treadtop.4075m. These are provisional engineering dimensions, not accepted passage/boarding or human fit.

Generate Python+NumPy: `generate_carriage_c02.py --parameters door-parameters.json --output-dir export`; add `--door-angle-deg70` as TWO arguments (`--door-angle-deg 70`) for open state. Actual closed/open GLBs have identical geometry buffer bytes; only door node rotation changes (aside from state extras).10416triangles,31batches/54nodes; repeat closed bytes deterministic; Khronos0errors/0warnings both states. Current closed780300B/open780332B.31batches increases4from baseline27. Pivot/seat/wheel/hitch transforms unchanged apart from new door hierarchy.

`check_door.py` decodes actual source primitive geometry. ConstantY and analyticZ extrema over ALL angles0..70 prove separation from rear mudguards16.59mm, fixed rear/front lowerwalls7.5/4.44mm, roof25mm and tread405mm. This is stronger than sampled AABB poses for those named parts, but does not qualify fixed hinge/trim/frame interfaces, upholstery/interior complete swept collisions, grasp, clothing or occupant passage. No triangle/watertight/contact acceptance claim. Full articulated running gear sweep separate. Six C01 hashes unchanged.

Initial conservative mudguardYrange failure−9.934mm retained. Raised high-threshold candidate was rejected as poor passage geometry (source and clearance receipt preserved), then narrower lower-threshold leaf replaced it. New parser JSON numpybool serialization error was corrected; no geometry tolerance changed. Actual corrected8 rear/side closed/opendesktop/mobile images inspected. Initial pane/frame daylight gaps and missing fixedrearwaist strip preserved as failures, then corrected with pane overlap and stationary waist strip. Actual open side shows cabin floor through real opening. Closed/open fullbody+44pxcontrols fit below140pxheader, same unionbounds camera/light for eachpair;64shadowed drawcalls,0page/request/GLerrors. No occupied/production function claim. Browserclosed.

`door-context.patch` is contextual diff against prior repaired proposal generator, not app-ready until C02base proposal integrated. Register source/data/GLBs GPL provenance/hashes in root ledger if integrated; do not apply original procedural-asset licensing blindly to photograph. No external photographic content included.
''')
files=sorted(x for x in p.rglob('*') if x.is_file() and not x.name.endswith('.tar.gz') and x.name!='archive-receipt.json' and 'repeat' not in x.parts and 'baseline' not in x.parts)
rows=[{'path':str(f.relative_to(p)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in files];a=p/'c02-rigid-door-visual-review.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(p)),recursive=False)
with tarfile.open(a) as t:
 for row in rows:assert hashlib.sha256(t.extractfile(row['path']).read()).hexdigest()==row['sha256']
out={'archive':str(a),'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'bytes':a.stat().st_size,'members':rows};(p/'archive-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k!='members'});print('members',len(rows))
