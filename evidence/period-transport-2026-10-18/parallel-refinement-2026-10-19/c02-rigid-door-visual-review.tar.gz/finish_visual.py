from pathlib import Path
import json
p=Path(__file__).parent;r=json.loads((p/'render-receipt.json').read_text())
for a,b in zip(r['rows'][::2],r['rows'][1::2]):
 assert a['camera']==b['camera'];assert a['framing']==b['framing'];assert a['doorAngleDeg']==0 and abs(b['doorAngleDeg']-70)<1e-9
(p/'VISUAL-REVIEW.json').write_text(json.dumps({'actually_inspected':[x['file'] for x in r['rows']],'initial_failure':'initial8pane/framedaylight gaps+missing fixedrearwaist infill preserved with actualgenerator/images/receipt','corrected_result':'Former accidental strips closed; side-open shows actual cabin floor through opening cut in sidewall. Rearview outward leaf visible. Fullbody and44pxcontrols fit desktop/mobile.','camera_controls':'Sameunionclosed/openfullbodybounds,40degFOV,unitmodelscale,fixedlight/exposure/header140 for eachpair','renderer_errors':r['errors'],'shadowed_calls':64,'browser_closed':True,'limitations':['No complete fixedhinge/trim/interior swept triangle collision proof','No occupant/passage/cloth/grasp/productiondoor acceptance','Pane/door/hinge/step arrangement anddimensions entirelyreconstructed','No owner/subtype/photoquality claim']},indent=2)+'\n')
