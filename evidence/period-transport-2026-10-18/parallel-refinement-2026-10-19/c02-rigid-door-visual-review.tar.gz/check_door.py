import runpy,sys,struct,json,hashlib,math
from pathlib import Path
import numpy as np
p=Path(__file__).parent;sys.argv=[str(p/'generate_carriage_c02.py'),'--parameters',str(p/'door-parameters.json'),'--output-dir',str(p/'export')];e=runpy.run_path(str(p/'generate_carriage_c02.py'));ns=e['oldnodes'];parent={c:i for i,n in enumerate(ns) for c in n.get('children',[])}
def world(i):
 m=e['local'](ns[i])
 while i in parent:i=parent[i];m=e['local'](ns[i])@m
 return m
parts={};moving=[]
for i,n in enumerate(ns):
 if 'mesh' not in n:continue
 tri=[]
 for q in e['oldmeshes'][n['mesh']]['primitives']:
  a=e['oldaccess'][q['attributes']['POSITION']];v=e['oldviews'][a['bufferView']];xyz=np.array(struct.unpack_from('<%sf'%(a['count']*3),e['oldbinary'],v['byteOffset'])).reshape(-1,3);m=world(i);tri.extend(xyz@m[:3,:3].T+m[:3,3])
 arr=np.array(tri);parts.setdefault(n['name'],[]).append(arr)
 j=i
 while j in parent and ns[j]['name']!='vehicle_door_left':j=parent[j]
 if ns[j]['name']=='vehicle_door_left':moving.append(arr)
d=np.concatenate(moving);bottom=float(d[:,1].min());top=float(d[:,1].max());checks=[]
pivot=np.array([.645,.82,-.28]);local=d-pivot
zvalues=[]
for x,y,z in local:
 angles=[0,math.radians(70)]
 for t in [math.atan2(-x,z)+k*math.pi for k in range(-2,3)]:
  if 0<=t<=math.radians(70):angles.append(t)
 zvalues.extend(pivot[2]+z*math.cos(t)-x*math.sin(t) for t in angles)
sweepz=[min(zvalues),max(zvalues)]
for label,prefixes,direction in [('step',['door_step_tread'],'above'),('roof_surround',['window_roof_rail_1','crowned_cabin_roof'],'below'),('rear_mudguards',['rear_mudguard'],'forward'),('fixed_rear_wall',['cabin_lower_fixed_door_rear'],'forward'),('fixed_front_wall',['cabin_lower_fixed_door_front'],'rearward')]:
 arr=np.concatenate([a for name,groups in parts.items() if any(name.startswith(x) for x in prefixes) for a in groups])
 if direction=='above':gap=bottom-float(arr[:,1].max());axis='+Y'
 elif direction=='below':gap=float(arr[:,1].min())-top;axis='+Y'
 elif direction=='forward':gap=sweepz[0]-float(arr[:,2].max());axis='+Z'
 else:gap=float(arr[:,2].min())-sweepz[1];axis='+Z'
 checks.append({'fixed_parts':label,'separating_axis':axis,'gap_m':gap,'all_hinge_angles_0_to70_safe_by_analytic_extrema':bool(gap>0)});assert gap>0,(label,gap)
# Fixed-jamb/hinge furniture and lowerwall require exact interference proof separately.
receipt={'status':'Bounded actual decoded source geometry separation, no complete swept collision acceptance','checks':checks,'door_y_bounds_m':[bottom,top],'analytic_all_angle_door_z_bounds_m':sweepz,'hinge_angles_deg':[0,35,70],'source_C01_protected':json.load(open(p.parent/'carriage-c02-enclosure-repair/source-receipt.json'))['protected_C01_hashes'],'limitations':['Fixedjamb/hinge interfaces intentionally close fitting; no complete triangle-vs-triangle swept clearance proof yet','No occupant, grasp, clothing, passage width or production door-function acceptance','All dimensions/door/window/step/hinge layout reconstructed,1904developmentonly']}
for name,h in receipt['source_C01_protected'].items():assert hashlib.sha256((Path('/workspace/chicago/chicago/4d')/name).read_bytes()).hexdigest()==h
(p/'clearance-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
