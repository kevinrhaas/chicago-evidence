from pathlib import Path
import difflib
out=Path('/workspace/shared/human-normal-probe-recovery-2679');old=(out/'human_teamster_blend.9cc7.frozen.py').read_text();new=old
anchor="    argv = sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []\n    return p.parse_args(argv)"
replacement="""    p.add_argument('--experimental-normal-probes',action='store_true',help='Explicit isolated-CI experiment only; no default normal method change')
    p.add_argument('--normal-probe-receipts',type=Path,help='Required /tmp directory for experimental normal diagnostics')
    argv = sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
    args=p.parse_args(argv)
    if args.experimental_normal_probes:
        if args.normal_probe_receipts is None or not args.normal_probe_receipts.resolve().is_relative_to(Path('/tmp')):
            p.error('--experimental-normal-probes requires --normal-probe-receipts under /tmp')
    elif args.normal_probe_receipts is not None:
        p.error('--normal-probe-receipts requires explicit --experimental-normal-probes')
    return args"""
assert anchor in new;new=new.replace(anchor,replacement)
anchor="            mesh.normals_split_custom_set([converted[loop.vertex_index] for loop in mesh.loops])\n            if ratio == 1:"
replacement="""            mesh.normals_split_custom_set([converted[loop.vertex_index] for loop in mesh.loops])
            if ratio == 1 and args.experimental_normal_probes:
                # UNEXECUTED prototype until an explicitly opted-in pinned CI run.
                # Existing RAW1e-3 readback audit below remains unchanged.
                from human_normal_probe import experiment
                receipt_path=args.normal_probe_receipts/(asset+'-'+hashlib.sha256(name.encode()).hexdigest()+'-normal-probe.json')
                probe_receipt=experiment(mesh,converted,source_vertex_indices,receipt_path,
                    context={'blender_version':bpy.app.version_string,'asset_id':asset,'explicit_opt_in':True})
                print(json.dumps({'experimental_normal_probe':{'mesh':name,'receipt':str(receipt_path),
                    'maximum_raw_delta':probe_receipt['after']['maximum_raw_vector_delta'],
                    'scope':'experimental LOD0 body packed-normal readback only; not export/appearance acceptance'}}),flush=True)
            if ratio == 1:"""
assert anchor in new;new=new.replace(anchor,replacement)
(out/'human_teamster_blend.proposed.py').write_text(new)
patch=[]
for name,a,b in [('tools/human_teamster_blend.py',old,new),('tools/human_normal_probe.py','',(out/'human_normal_probe.py').read_text()),('tools/human_normal_probe_math.py','',(out/'human_normal_probe_math.py').read_text())]+[('tools/'+name,'',(out/name).read_text())for name in ['test_human_normal_probe_math.py','test_human_normal_probe_adapter.py','test_human_normal_probe_optin.py']]:
 patch.extend(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+name if a else '/dev/null',tofile='b/'+name))
(out/'UNEXECUTED-normal-probe-CONTEXT-9cc7-4D-ROOT.patch').write_text(''.join(patch))
