# Reversible raw Short2 fan-frame recovery — UNEXECUTED BPy prototype

**Actual next-CI failure metrics are still required before an integration decision.** No local Blender/browser execution, app edits, artifact downloads or dispatch occurred. This folder contains mathematical recovery, explicit API mocks and an opt-in context patch against frozen9cc7b9ac8a2fe304ce844ed266677af786f541bc. It is not a demonstrated resident repair or a threshold waiver.

## Exact pinned decode and frame identification

Official Blender4.5.3 source already retained at sibling human-ci-watch-2679d6c98/Blender453-mesh_normals.audit.cc698–733 reconstructs a decoded direction from N (auto normal), R (reference), O (orthogonal), A=ref_alpha and B=ref_beta:

`n = N*cos(alpha) + sin(alpha)*(R*cos(beta) + O*sin(beta))`

For a positive alpha short a, alpha=A*a/32767; for negative a, alpha=(2pi-A)*a/32767 (the wrapped negative branch). Beta uses B or2pi-B in the same way. Alpha short0 returns N regardless of beta. Source625–626 defines O=normalize(cross(N,R)), fixing orientation; no sign guessing is needed.

Uniform raw-code probes identify the actual frame without reconstructing mesh adjacency:

1. (0,0) gives N.
2. (32767,0) gives P=N*cos(A)+R*sin(A). For0<A<pi, `A=acos(dot(N,P))`, `R=normalize(P-N*dot(N,P))`, `O=normalize(cross(N,R))`.
3. (32767,8192) gives Q. With f=8192/32767, `B=atan2(dot(Q,O),dot(Q,R))/f`. The common sin(A)>0 cancels from atan2.

The8192 fraction is **slightly above1/4**, not below: atB=2pi its angle ispi/2+4.794e-5. This is still far inside atan2's unambiguous(-pi,pi) interval.8191 would be strictly below1/4, but this implementation uses8192 consistently and testsB=2pi explicitly.

Two independent held-out probes (-8192,0) and (16384,-16384) exercise the decoder's negative alpha and negative beta branches. Recovered parameters must predict all five raw probe outputs within the prototype2e-5 residual criterion, after checking finite/unit probe values and conditioning. This threshold is a model-fit precondition, **not a replacement for the final raw1e-3 target guard**.

## Inverse decoded direction, not the ordinary snapped encoder

For a desired unit t, use its components in recovered(N,R,O):

`alpha=atan2(hypot(R·t,O·t),N·t)` and `beta=atan2(O·t,R·t) mod2pi`.

Invert the appropriate positive/negative decode branch and round usingfloor(x*32767+.5), matching source's sign/tie convention. The direct integer code does not execute the ordinary input encoder's deliberate beta-zero region. Raw code range is restricted to[-32767,32767];-32768 is rejected. BoundaryB=2pi never divides by its zero complement because beta<=B uses the positive branch. No artistic target normal is altered to obtain a pass.

This is mathematically feasible for valid, well-conditioned frames. It does not prove every actual Blender fan will be recoverable. Small sin(A), small projected beta response, zero/invalid vectors, inconsistent held-outs, unknown/nonfinite data and unrepresentable codes reject before authoring can be accepted. Valid but poorly conditioned fans can also reject; there is no fallback that bypasses the guard.

## Fan-code coherence

mesh_normals.cc1198–1204 averages the two integer codes over each actual fan before decoding. During recovery every corner receives the **same global pair** for that probe, so averaging preserves it exactly. The adapter refuses per-vertex corner counts over65535 to keep even32767 uniform sums inside int32; fan cardinality is no greater than that point's corner count.

At1304–1308 the source copies the one computed fan_normal to every corner in that fan. Therefore a point ID plus its exact five-probe signature identifies a fan-equivalent group without adjacency reconstruction. The algorithm solves one code pair per such group and writes it to all members. If equivalent frames in distinct fans share a signature, sharing is safe only when their desired normals agree; mismatches reject. UV-split points remain separate groups because their vertex IDs differ. No code pair is copied blindly across different frames.

The real final readback remains authoritative even if grouping/model inference is wrong: target errors use the **raw actual and expected vectors**, with no normalization that could hide readback error. A separate prototype seam-pair spread limit1e-3 also fails closed. Original root caller's raw1e-3 audit remains intact after the optional experiment.

## Supported raw API and cache evidence

Official pinned rna_attribute.cc38/69 exposes INT16_2D;1306–1343 defines Short2AttributeValue.value as a writable two-integer array. The mesh codec uses custom_normal on CORNER at mesh_normals.cc1594. The adapter requires that existing attribute, correct type/domain/count and mesh.has_custom_normals; it never creates or removes a layer. It reads `.value` and writes `attribute.data.foreach_set('value',flat_codes)`.

RNA attribute update413–421 merely tags dependency updates when the data has users. A fresh body Mesh can have no users at this authoring point, and that callback does not explicitly dirty normal caches. The adapter therefore calls `mesh.update()` **after every code write** and before reading mesh.corner_normals. Pinned rna_mesh_api.cc180–201 explicitly dirties vertex, face, corner and true-normal caches. Probe writes change no geometry, sharpness, UV, weights or morph data, so the true fan frame should stay fixed; this is still awaiting real BPy verification.

The original setter already established sharp edges/custom-normal data. The prototype touches only packed values. It does not run the setter again while probing, so cannot accidentally reclassify sharp edges to improve a target. A complete before/after mesh digest covers positions, vertex groups, edge sharpness, loops, polygon flags/material slots, UVs, shape keys and material names. Scene metadata/actions are outside the Mesh adapter's reach; the surrounding source/control/export checks must remain.

## Transaction and diagnostics

The actual-API adapter is in human_normal_probe.py, but **has never received a real BPy Mesh**. Its code path is tested only under explicit API mocks.

It snapshots original packed codes and original synchronized derived normals, records a bounded pre-probe target audit, then performs uniform recovery probes and the final code write. Success requires unchanged mesh invariant digest, finite/unit outputs, current raw1e-3 target error and prototype seam agreement. A bounded receipt includes max/mean, bad count and five worst loop/vertex/source IDs with actual/expected vectors; packed arrays and mesh payloads are never logged. Receipts remain under/tmp.

Any caught failure, including final audit or receipt I/O failure, restores original packed values, updates caches, verifies original codes, mesh digest and restored derived normals, and rethrows. Failure is never converted into a pass. A killed process cannot execute Python cleanup; that must remain an isolated authoring process whose unsaved model is discarded. No incomplete master may be exported or published.

## Context patch

UNEXECUTED-normal-probe-CONTEXT-9cc7-4D-ROOT.patch applies from4d to frozen9cc7. Default authoring is unchanged. New `--experimental-normal-probes` requires a separate `/tmp` receipt directory; directory without explicit flag rejects. The optional LOD0 body-only call occurs after the ordinary custom setter and **before the existing unchanged raw1e-3 audit**. Hair, garments, rig, gait, source targets, legacy fixture, export kwargs and workflow dispatch are untouched. No workflow activates this flag. Decimated LODs are outside this experiment and remain unproven.

The patch includes portable math/adapter/CLI-mock tests but does not add them to check.sh automatically. Proposed focused commands after a reviewed integration would be:

```
python3 tools/test_human_normal_probe_math.py
python3 tools/test_human_normal_probe_adapter.py
python3 tools/test_human_normal_probe_optin.py
```

An actual pinned-CI trial would additionally need the explicit builder flags and an isolated authoring output, followed by unchanged original readback, emitted GLB NORMAL/UV/position/morph checks, normal/seam visual review, source/control world-surface proof and source/web gait/hair/camera gates. Root owns that decision and any dispatch.

## Evidence actually obtained

-7 mathematical tests pass: beta-hole counterexample recovery;1000 seeded valid frames/10000 target directions with final probe vectors roundedfloat32; max measured model error0.0001171951;B=2pi and signed branches; degenerate/nonfinite/inconsistent probe rejection; coherent fan codes; final-readback failure restoration; malformed codes/targets.
-4 actual adapter-function tests under explicit API mocks pass: successful bounded raw-vector receipts and invariant preservation; stale-cache and corrupted final normals fail and restore; wrong attribute/range/type rejects; receipt I/O failure restores packed values.
-2 actual proposed parse_args AST tests pass: defaults off; explicit/tmp opt-in only.
-The integrated math test writes no in-tree output; temporary receipt tests use temporary directories only. Outside9cc7 apply-check passes; adapter/math/builder syntax parses without importing bpy.

The seeded sweep is **not** an exhaustive bound, IEEE754 replica, Blender execution, actual resident geometry test or photographic acceptance. Source algebra supports an experiment; only actual failed-run metrics and a successful observed pinned-CI trial can support an authoring repair decision.

## Subsequent actual diagnostics and independent review

Root supplied the next actual9cc run39192083053's failed pre-export audit:80268corners, maximum rawvector error0.0012906586516, mean0.00002201877,21corners above1e-3. Actual UV seams1122groups, maxspread0.00108215827, one sourcegroup9902 above1e-3; worst target error source12036/vertex13077. No later resident exports or decoded qualification ran. These observations support retaining the strict guard and testing a real authoring correction; they do not identify the specific encoder branch per corner.

viewer_survey independently reviewed the outside math/adapter and found no definite acceptance bypass: raw final vectors stay unnormalized for the guard, signed held-outs/coherence/seam checks remain, and receipt I/O failures restore codes/invariants before rethrowing. A second I/O failure may obscure the original diagnostic but cannot accept/export a model. Actual BPy cache/frame behavior remains unexecuted.

FLOAT_PATH_LIMIT.md records why a superficially simpler FLOAT_VECTOR attribute is not adopted: the pinned mesh getter supports it, but the project's morph-normal export invokes a separate shape-key path still typed as short2. No FLOAT fallback is hidden in the proposed Short2 context.
