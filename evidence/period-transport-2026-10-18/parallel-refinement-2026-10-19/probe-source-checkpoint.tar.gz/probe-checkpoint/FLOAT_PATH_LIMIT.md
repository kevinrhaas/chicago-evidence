# FLOAT_VECTOR custom_normal route: real getter support, unresolved morph export

Kept separate from the Short2 trial; no FLOAT branch is in the context patch.

Official Blender4.5.3 source has direct float3 custom_normal support. mesh_normals.cc294–311 chooses its explicit attribute domain;458–483 returns float3 CORNER values directly. mesh_attributes.cc964–981 supplies generic corner attributes and does not fix custom_normal to a built-in short type;839–840 tags normal changes. attribute.cc391–432 implements generic named creation. mesh.cc577–584 recognizes a named custom_normal attribute in object mode. This supports a plausible normal-authoring data representation, pending actual BPy attribute readback.

It does NOT prove this project's glTF/morph path. Pinned primitive_extract.py1428–1448 uses basis_key.normals_split_get() when morph normals are enabled, and only otherwise uses mesh.corner_normals. The pinned key.cc2277–2293 shape-key normal path still requests lookup<short2>('custom_normal',CORNER) and executes the ordinary fan decoder. Whether generic lookup rejects, converts or falls back for FLOAT_VECTOR must not be guessed. Silent conversion/fallback could reintroduce the UV-seam normal problem even after float BPy mesh readback passed.

Disabling morph normals or changing the glTF exporter to force a different base path would be additional behavior changes with facial lighting implications; neither is in this proposal. Therefore prefer an explicitly isolated Short2 probe trial that retains the existing authored/exported attribute type and its shape-key path, with unchanged raw1e-3 and seam checks. This is a trial decision, not proof of success. Actual source/web emitted NORMALs and morphs still require qualification.
