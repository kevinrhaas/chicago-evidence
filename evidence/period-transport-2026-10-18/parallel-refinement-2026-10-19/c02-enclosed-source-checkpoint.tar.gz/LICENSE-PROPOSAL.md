# Proposed separate C02 license entry

Original project-derivedGPL-3.0-or-later generator/data/geometry/materials. No externalphototexture or imagecopied. Existingphoto recordrights statement preserved separately; it is not re-licensed here. No ownership/subtype/dimension/photographicacceptance.

| Path | SHA-256 |
| --- | --- |
| `tools/transport/generate_carriage_c02.py` | `7bb7df5f9131364dc61e99d050eeee94c0bf80af8ab1a13e1f4bd25f41efeff0` |
| `data/transport/studies/carriage-c02.json` | `7d3f97aa563cd6a768d1785ff51d83872f6ec9df4f011ea560f96f40dc2dbc97` |
| `renderers/web/transport/carriage-c02/carriage-c02.json` | `f58bdf2b8c657d9a80031492690ba440d42d70c04abaa437ebdf79380013e1ee` |
| `renderers/web/transport/carriage-c02/parameters.json` | `7d3f97aa563cd6a768d1785ff51d83872f6ec9df4f011ea560f96f40dc2dbc97` |
| `renderers/web/transport/carriage-c02/carriage-c02.glb` | `748fa654ebb8d9b6b707f61bca2a05ecdce1c1345a0ae8c160e5ad655c999a44` |
