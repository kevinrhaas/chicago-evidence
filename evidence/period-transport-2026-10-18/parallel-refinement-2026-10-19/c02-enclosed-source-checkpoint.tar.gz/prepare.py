# SPDX-License-Identifier: GPL-3.0-or-later
"""Separate original C02 study; reuse GPL C01 geometry/export helpers only."""
from pathlib import Path
import json,hashlib
R=Path('/workspace/chicago/chicago/4d');O=Path(__file__).parent
source=R/'tools/transport/generate_carriage.py';original=source.read_text();protected={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [source,*sorted((R/'renderers/web/transport/carriage').glob('*'))] if p.is_file()}
s=original.replace("if params.get('body_envelope_m') != [1.20,2.20]:raise ValueError('body_envelope_m describes fixed study furniture; only [1.2,2.2] supported')", "if params.get('cabin_envelope_m') != [1.32,1.70,1.44]:raise ValueError('cabin_envelope_m is the fixed original C02 study envelope')")
# C02 upholstery is its own simple original reconstruction; do not copy C01 refinements/flag.
s=s.replace("rounded=params.get('rounded_upholstery_study',False)","rounded=False")
start=s.index('# Tapered passenger tub:');end=s.index('# Running gear, articulated',start)
body='''# C02: separate enclosed town-carriage silhouette, not a diagnosed subtype.
# Photograph supports only coarse dark roofed cell and exposed running gear.
# ALL dimensions, glass/door divisions and furniture below are reconstructed.
box('cabin_floor',body,(1.16,.08,1.62),(0,.74,-.25),1)
# Sloping lower side panels narrow toward the exposed underbody.
for side in [-1,1]:
 x=side
 vs=[[x*.50,.78,-1.04],[x*.50,.78,.50],[x*.60,1.30,.50],[x*.60,1.30,-1.04],[x*.54,.78,-1.04],[x*.54,.78,.50],[x*.62,1.30,.50],[x*.62,1.30,-1.04]]
 faces=[[0,3,2,1],[4,5,6,7],[0,4,7,3],[1,2,6,5],[3,7,6,2],[0,1,5,4]]
 center=[sum(v[k] for v in vs)/len(vs) for k in range(3)]
 for face in faces:
  p,q,r=[vs[i] for i in face[:3]];u=[q[k]-p[k] for k in range(3)];v=[r[k]-p[k] for k in range(3)];normal=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];d=[sum(vs[i][k] for i in face)/len(face)-center[k] for k in range(3)]
  if sum(a*b for a,b in zip(normal,d))<0:face.reverse()
 geom('cabin_lower_side_'+str(side),body,vs,faces,0)
 # Closed independent window/pillar treatment, not read from tiny source pixels.
 box('waist_rail_'+str(side),body,(.055,.055,1.62),(side*.60,1.325,-.25),0)
 box('side_glazing_'+str(side),body,(.015,.53,1.12),(side*.605,1.625,-.25),6)
 for z in [-1.025,.525]:box('cabin_corner_pillar_'+str(side)+'_'+str(z),body,(.065,.74,.065),(side*.595,1.67,z),0)
 box('window_lower_frame_'+str(side),body,(.045,.025,1.15),(side*.612,1.36,-.25),0)
 box('window_upper_frame_'+str(side),body,(.045,.025,1.15),(side*.612,1.90,-.25),0)
 # No hinges, handles or working door falsely inferred from the photograph.
 box('step_'+str(side),body,(.24,.04,.44),(side*.76,.36,-.12),4)
 for z in [-.29,.05]:beam('step_bracket_'+str(side),body,(side*.49,.74,z),(side*.76,.36,z),.025,4)
 for k in range(18):
  a=math.pi*(.06+.88*k/18);b=math.pi*(.06+.88*(k+1)/18)
  beam('rear_mudguard',body,(side*.70,RR+.61*math.sin(a),-WB/2+.61*math.cos(a)),(side*.70,RR+.61*math.sin(b),-WB/2+.61*math.cos(b)),.045,0)
# Rear and front panel frames with provisional dark glass rather than false detailed doors.
for label,z in [('rear',-1.045),('front',.535)]:
 box(label+'_lower_panel',body,(1.18,.55,.055),(0,1.055,z),0)
 box(label+'_window_panel',body,(1.16,.60,.03),(0,1.64,z),0)
 box(label+'_dark_glass',body,(.58,.38,.012),(0,1.68,z+(-.023 if label=='rear' else .023)),6)
 box(label+'_upper_header',body,(1.22,.09,.065),(0,1.98,z),0)
# Shallow crowned closed roof, explicitly invented contour/thickness.
profile=[(-.66,2.025),(-.53,2.075),(-.30,2.122),(0,2.14),(.30,2.122),(.53,2.075),(.66,2.025)]
vs=[]
for z in [-1.10,.60]:
 for depth in [0,-.045]:
  for x,y in profile:vs.append([x,y+depth,z])
N=len(profile);faces=[]
for k in range(N-1):faces.extend([[k,k+1,2*N+k+1,2*N+k],[N+k+1,N+k,3*N+k,3*N+k+1],[k,N+k,N+k+1,k+1],[2*N+k+1,3*N+k+1,3*N+k,2*N+k]])
faces.extend([[0,2*N,3*N,N],[N-1,2*N-1,4*N-1,3*N-1]])
# Explicit consistent winding: top/up, underside/down, rear/front/endcaps outward.
for face in faces:face.reverse()
geom('crowned_cabin_roof',body,vs,faces,0)
# Empty internal bench and external perch are original fit candidates, not sourced furniture.
box('passenger_bench_base',body,(1.00,.25,.43),(0,.905,-.68),0)
box('passenger_cushion',body,(1.00,.12,.43),(0,1.09,-.68),2)
box('passenger_back',body,(1.00,.45,.06),(0,1.39,-.94),2)
for x in [-.37,.37]:beam('driver_perch_support',body,(x,.74,.79),(x,1.22,.86),.045,4)
box('driver_seat',body,(.92,.11,.38),(0,1.26,.86),2)
box('driver_back',body,(.92,.20,.055),(0,1.40,.66),0)
box('driver_footboard',body,(.90,.04,.40),(0,.83,1.20),1)
for x in [-.53,.53]:
 beam('lamp_bracket',body,(x,.90,.76),(x,1.45,.76),.020,4)
 box('lamp_body',body,(.11,.15,.11),(x,1.48,.76),5)
 for y in [1.39,1.57]:box('lamp_cap',body,(.14,.025,.14),(x,y,.76),4)
'''
s=s[:start]+body+s[end:]
s=s.replace("('lamp_glass',[.75,.64,.38,1],.1,.2)","('lamp_glass',[.35,.34,.29,1],.1,.2),('provisional_dark_glazing',[.035,.055,.06,1],0,.18)")
s=s.replace("for z,r in [(-.95,.55),(.95,.45)]:", "for z,r in [(-WB/2,RR),(WB/2,RF)]:")
s=s.replace("('vehicle_seat_driver',(0,1.31,.60)),('vehicle_seat_passenger_01',(.25,1.07,-.52)),('vehicle_seat_passenger_02',(-.25,1.07,-.52)),('vehicle_board_left',(.85,.35,.35)),('vehicle_board_right',(-.85,.35,.35)),('vehicle_camera_ride',(0,1.80,-.45))", "('vehicle_seat_driver',(0,1.32,.86)),('vehicle_seat_passenger_01',(.24,1.155,-.68)),('vehicle_seat_passenger_02',(-.24,1.155,-.68)),('vehicle_board_left',(.85,.38,-.12)),('vehicle_board_right',(-.85,.38,-.12)),('vehicle_camera_ride',(0,1.82,-.60))")
s=s.replace("'carriage_c01_study'","'carriage_c02_enclosed_study'").replace('Original C01 Python geometry','Original separate C02 Python geometry').replace('carriage-c01','carriage-c02').replace("'body_envelope_m'", "'cabin_envelope_m'")
s=s.replace("'Original open carriage family study, not a named manufacturer or owner replica'", "'Separate enclosed roofed town-carriage silhouette study, not a named owner, manufacturer or diagnosed subtype'")
s=s.replace("'No brake, reins, harness, horse, doors, cloth hood or physics'", "'No working door/hinge, brake, horse/team, rider, reins, harness or physics; cabin openings and furniture are unproven independent reconstruction'")
s=s.replace("'proposed empty boarding/seat/hitch transforms; no occupant or harness validated'", "'new C02 empty boarding/seat/hitch transforms; no door traversal, occupant, gear fit or camera validated; do not reuse C01fit'")
# Add bounded existing-registry reference without fabricating a 4Dsource ID.
s=s.replace("for exported_node in nodes:","sidecar['reference_scope']={'reference_record_id':'a16-pullman-det-4a08065','registry':'prairie_1904_v1/research/images/stream-1600-1700.json','catalog_url':'https://www.loc.gov/item/2016801921/','date_bounds':[1890,1901],'rights':'No known restrictions on publication, existing catalog record; not an unconditional license','actually_viewed':True,'used':'Coarse roofed dark cabin and open underbody silhouette only; no pixels/textures/tracing or physical dimensions extracted','unresolved':['vehicle ownership','manufacturer/subtype','door/window layout','wheel count/radii from photograph','horses/team','lamp construction','absolute dimensions'],'scene_eligibility':'1904 development-only period analogy; no specific carriage presence/date/ownership inferred'}\nsidecar['boarding_enabled']=False\nsidecar['cabin_bounds_basis']='All dimensions, roof/window/seat/step construction independently reconstructed; fixed envelope, not measured photograph'\n\nfor exported_node in nodes:")
# Retain actual decoded component bounds for the new cabin rather than guessing from a whole-vehicle box.
s=s.replace("batches={}\nfor i,n in enumerate(oldnodes):", "batches={};cabin_components={}\nfor i,n in enumerate(oldnodes):")
s=s.replace("key=(j,prim['material']);batches.setdefault", "key=(j,prim['material']);\n  if n['name'].startswith(('cabin_','crowned_cabin_','waist_rail_','side_glazing_','window_','rear_lower_','rear_window_','rear_dark_','rear_upper_','front_lower_','front_window_','front_dark_','front_upper_')):cabin_components[n['name']]={'min_m':vs.min(axis=0).tolist(),'max_m':vs.max(axis=0).tolist()}\n  batches.setdefault")
s=s.replace("sidecar['boarding_enabled']=False", "sidecar['boarding_enabled']=False\nsidecar['cabin_component_bounds']=cabin_components\nsidecar['cabin_geometry_subset']='Cabin floor, sidewalls, pillars, glass/frame and roof; excludes steps, driverfurniture, lamps and runninggear'")
# Remove dormant C01 upholstery-only helper/metadata, keeping C02 source self-contained.
a=s.index('# Original rounded cushion shell');b=s.index('def box(',a);s=s[:a]+s[b:]
s=s.replace("rounded=False\nif not isinstance(rounded,bool):raise ValueError('rounded_upholstery_study must be boolean')\n",'')
s=s.replace(" if rounded and name in ('passenger_cushion','passenger_back_cushion','driver_seat'):return rounded_cushion(name,parent,size,t,mat,rx)\n",'')
a=s.index('if rounded:\n');b=s.index("sidecar['reference_scope']",a);s=s[:a]+s[b:]
s=s.replace('brass lamps','simple lamps')
(O/'generate_carriage_c02.py').write_text(s)
p={'cabin_envelope_m':[1.32,1.70,1.44],'wheelbase_m':1.9,'track_m':1.4,'wheel_radius_front_m':.45,'wheel_radius_rear_m':.55,'shaft_length_m':2.2,'shaft_inner_spacing_tip_m':.773,'steering_limit_deg':8}
(O/'parameters.json').write_text(json.dumps(p,indent=2)+'\n')
photo=Path('/workspace/chicago-images/prairie-1904/files/a16-pullman-det-4a08065.jpg');records=json.loads(Path('/workspace/shared/period-transport-photo-followup/existing-reference-records.json').read_text());record=next(r for r in records if r['id']=='a16-pullman-det-4a08065');(O/'reference-record.json').write_text(json.dumps(record,indent=2)+'\n')
(O/'source-receipt.json').write_text(json.dumps({'status':'Separate C02 original engineering proposal; no render yet; no app/C01writes','c01_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'protected_C01_hashes':protected,'reference_local_file':str(photo),'reference_local_sha256':hashlib.sha256(photo.read_bytes()).hexdigest(),'source_registry_record':'a16-pullman-det-4a08065','registered_4D_source_id':None,'photo_scope':'Actualpixelsviewed, coarse qualitative cabin/rungear silhouette only; dimensions/doors/ownerunproven'},indent=2)+'\n')
