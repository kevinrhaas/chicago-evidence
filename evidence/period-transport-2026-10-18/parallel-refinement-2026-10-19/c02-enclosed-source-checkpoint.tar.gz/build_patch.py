from pathlib import Path
import difflib,json,hashlib
O=Path(__file__).parent;R=Path('/workspace/chicago/chicago/4d')
files={'tools/transport/generate_carriage_c02.py':O/'generate_carriage_c02.py','data/transport/studies/carriage-c02.json':O/'parameters.json','renderers/web/transport/carriage-c02/carriage-c02.json':O/'export/carriage-c02.json','renderers/web/transport/carriage-c02/parameters.json':O/'export/parameters.json'}
patch=''
for name,p in files.items():
 assert not (R/name).exists(),'Existing C02 target requires explicit review'
 patch+=''.join(difflib.unified_diff([],p.read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+name))
(O/'c02-source-context.patch').write_text(patch)
rows={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in files.items()};rows['renderers/web/transport/carriage-c02/carriage-c02.glb']=hashlib.sha256((O/'export/carriage-c02.glb').read_bytes()).hexdigest()
text='# Proposed separate C02 license entry\n\nOriginal project-derivedGPL-3.0-or-later generator/data/geometry/materials. No externalphototexture or imagecopied. Existingphoto recordrights statement preserved separately; it is not re-licensed here. No ownership/subtype/dimension/photographicacceptance.\n\n| Path | SHA-256 |\n| --- | --- |\n'
for path,digest in rows.items():text+=f'| `{path}` | `{digest}` |\n'
(O/'LICENSE-PROPOSAL.md').write_text(text);(O/'output-hashes.json').write_text(json.dumps(rows,indent=2)+'\n')
