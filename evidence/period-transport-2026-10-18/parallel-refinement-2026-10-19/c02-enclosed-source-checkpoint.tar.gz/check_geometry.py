# SPDX-License-Identifier: GPL-3.0-or-later
import json,hashlib,struct,collections,runpy,sys,math
from pathlib import Path
O=Path(__file__).parent;R=Path('/workspace/chicago/chicago/4d');snapshot=json.loads((O/'source-receipt.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for path,h in snapshot['protected_C01_hashes'].items():assert sha(R/path)==h,path
sys.argv=[str(O/'generate_carriage_c02.py'),'--parameters',str(O/'parameters.json'),'--output-dir',str(O/'export')];env=runpy.run_path(str(O/'generate_carriage_c02.py'))
roof=next(n for n in env['oldnodes'] if n['name']=='crowned_cabin_roof');mesh=env['oldmeshes'][roof['mesh']];a=env['oldaccess'][mesh['primitives'][0]['attributes']['POSITION']];v=env['oldviews'][a['bufferView']];positions=[struct.unpack_from('<3f',env['oldbinary'],v['byteOffset']+12*i) for i in range(a['count'])];ids={};edges=collections.Counter();directed=collections.Counter();volume=0
for j in range(0,len(positions),3):
 tri=positions[j:j+3];index=[]
 for p in tri:
  if p not in ids:ids[p]=len(ids)
  index.append(ids[p])
 for k in range(3):x,y=index[k],index[(k+1)%3];edges[tuple(sorted((x,y)))]+=1;directed[(x,y)]+=1
 p,q,r=tri;volume+=(p[0]*(q[1]*r[2]-q[2]*r[1])+p[1]*(q[2]*r[0]-q[0]*r[2])+p[2]*(q[0]*r[1]-q[1]*r[0]))/6
assert all(n==2 for n in edges.values());assert all(directed[(a,b)]==directed[(b,a)]==1 for a,b in edges);assert volume>0
m=json.loads((O/'export/carriage-c02.json').read_text());components=m['cabin_component_bounds'];lo=[min(v['min_m'][k] for v in components.values()) for k in range(3)];hi=[max(v['max_m'][k] for v in components.values()) for k in range(3)];extent=[hi[k]-lo[k] for k in range(3)];expected=[1.32,1.44,1.70]
assert max(abs(a-b) for a,b in zip(extent,expected))<1e-6
# Decode actual finalGLB to confirm source points appear in final mesh and wheel bounds remain ground-correct.
raw=(O/'export/carriage-c02.glb').read_bytes();n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);binary=raw[28+n:];allpos=[]
for mesh in g['meshes']:
 for prim in mesh['primitives']:
  a=g['accessors'][prim['attributes']['POSITION']];v=g['bufferViews'][a['bufferView']];allpos.extend(struct.unpack_from('<3f',binary,v['byteOffset']+12*i) for i in range(a['count']))
finalset=set(allpos);assert all(v in finalset for v in positions)
assert m['boarding_enabled'] is False and len(g['meshes'])==27
report={'status':'Source-only actualgeometry/portable export checks, not rendered/photo/fit acceptance','protected_C01_files':len(snapshot['protected_C01_hashes']),'all_C01_hashes_unchanged':True,'roof_closed_edge_incidence_two':True,'roof_consistent_outward_winding':True,'roof_signed_volume_m3':volume,'all_roof_vertices_in_actual_final_export':True,'actual_cabin_bounds_m':{'min':lo,'max':hi,'extent_xyz':extent},'selected_cabin_envelope_width_length_height_m':m['parameters']['cabin_envelope_m'],'two_run_glb_bytes_equal':(O/'export/carriage-c02.glb').read_bytes()==(O/'repeat/carriage-c02.glb').read_bytes(),'glb_sha256':sha(O/'export/carriage-c02.glb'),'glb_bytes':len(raw),'statistics':m['statistics'],'photo_reference_local_sha256':snapshot['reference_local_sha256'],'boarding_enabled':False}
(O/'geometry-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
