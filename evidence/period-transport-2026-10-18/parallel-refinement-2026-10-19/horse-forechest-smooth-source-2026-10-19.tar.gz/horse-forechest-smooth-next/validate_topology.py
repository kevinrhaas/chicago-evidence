# SPDX-License-Identifier: GPL-3.0-or-later
import pathlib,json,struct,hashlib,collections,numpy as np
P=pathlib.Path(__file__).parent
import sys
variant=sys.argv[1]if len(sys.argv)>1 else'trial-v2'

def load(folder):
 b=(folder/'equine_light_harness_skinned_prototype_01.glb').read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);blob=b[28+n:]
 def read(i):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];c={'SCALAR':1,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];return np.frombuffer(blob,dtype={5126:'<f4',5123:'<u2',5125:'<u4'}[a['componentType']],count=a['count']*c,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,c).copy()
 return b,d,read
bb,b,br=load(pathlib.Path('/workspace/shared/horse-limb-transition-next/baseline'));tb,t,tr=load(P/variant);m=json.loads((P/variant/'manifest.json').read_text());record=m['shoulder_join_trial'];ba=b['meshes'][0]['primitives'][0]['attributes'];ta=t['meshes'][0]['primitives'][0]['attributes'];n=br(ba['POSITION']).shape[0];changed=set(record['changed_normal_vertex_indices'])
weight_mask=set(record['changed_original_weight_vertex_indices'])
for attr in ['JOINTS_0','WEIGHTS_0']:
 for index,(before,after)in enumerate(zip(br(ba[attr]),tr(ta[attr])[:n])):
  if index not in weight_mask:assert np.array_equal(before,after),(attr,index)
weights=tr(ta['WEIGHTS_0']);assert np.isfinite(weights).all()and np.max(np.abs(weights.sum(axis=1)-1))<1e-6 and np.min(weights)>=0
original_positions=br(ba['POSITION']);new_positions=tr(ta['POSITION'])[:n];mask=set(record['sculpted_body_vertex_indices']);max_sculpt_error=0.
for index in range(n):
 if index not in mask:assert np.array_equal(original_positions[index],new_positions[index]),index
 else:max_sculpt_error=max(max_sculpt_error,float(np.linalg.norm(new_positions[index]-original_positions[index]-np.array(record['sculpt_displacements_m'][str(index)]))))
assert max_sculpt_error<2e-7
assert all(index<7*24 for index in mask)
for i,(old,new)in enumerate(zip(br(ba['NORMAL']),tr(ta['NORMAL'])[:n])):
 if i not in changed:assert np.array_equal(old,new),i
assert b['nodes']==t['nodes'];assert np.array_equal(br(b['skins'][0]['inverseBindMatrices']),tr(t['skins'][0]['inverseBindMatrices']))
for ba,ta in zip(b['animations'],t['animations']):
 assert ba['channels']==ta['channels']
 for x,y in zip(ba['samplers'],ta['samplers']):
  for key in ['input','output']:assert np.array_equal(br(x[key]),tr(y[key]))
p=tr(t['meshes'][0]['primitives'][0]['attributes']['POSITION']);f=tr(t['meshes'][0]['primitives'][0]['indices']).reshape(-1,3);edges=collections.defaultdict(list)
for fi,face in enumerate(f):
 for a,b in zip(face,np.roll(face,-1)):edges[tuple(sorted((int(a),int(b))))].append((int(a),int(b),fi))
rows=[]
for r in record['records']:
 for loopname in ['body_boundary','distal_boundary']:
  loop=r[loopname]
  for a,b in zip(loop,loop[1:]+loop[:1]):
   uses=edges[tuple(sorted((a,b)))];assert len(uses)==2,(a,b,uses);assert uses[0][:2]==uses[1][:2][::-1],uses
 for edge,uses in edges.items():
  if any(v in r['created_vertices']for v in edge):assert len(uses)==2 and uses[0][:2]==uses[1][:2][::-1],(edge,uses)
 assert not set(r['retired_unreferenced_vertices'])&set(f.ravel())
 assert set(r['active_surface_vertex_indices'])=={int(v)for i in r['active_triangle_indices']for v in f[i]}
 start,end=r['new_triangle_range'];nf=f[start:end];areas=np.linalg.norm(np.cross(p[nf[:,1]]-p[nf[:,0]],p[nf[:,2]]-p[nf[:,0]]),axis=1)/2;assert min(areas)>1e-12
 rows.append({'label':r['label'],'body_shared_boundary_vertices':len(r['body_boundary']),'distal_shared_boundary_vertices':len(r['distal_boundary']),'new_vertices':len(r['created_vertices']),'new_triangles':len(nf),'minimum_new_triangle_area_m2':float(min(areas)),'all_boundary_and_new_edges_two_oppositely_directed_faces':True,'all_retired_caps_bands_unreferenced':True,'boundary_position_gap_m':0,'boundary_weight_gap':0,'boundary_normal_gap':0})
normals=tr(t['meshes'][0]['primitives'][0]['attributes']['NORMAL']);weighted=np.zeros_like(p);face_normals=np.cross(p[f[:,1]]-p[f[:,0]],p[f[:,2]]-p[f[:,0]])
for k in range(3):np.add.at(weighted,f[:,k],face_normals)
normal_errors=[]
for index in record['changed_normal_vertex_indices']:
 expected=weighted[index]/np.linalg.norm(weighted[index]);normal_errors.append(float(np.linalg.norm(expected-normals[index])))
assert np.isfinite(normals).all()and max(normal_errors)<1e-5
receipt={'decoded_join_normal_max_vector_error':max(normal_errors),'decoded_join_normal_tolerance':1e-5,'pass':True,'baseline_sha256':hashlib.sha256(bb).hexdigest(),'trial_sha256':hashlib.sha256(tb).hexdigest(),'original_positions_exact_except_declared_sculpt':True,'original_joints_weights_exact_except_declared_local_weight_mask':True,'changed_old_weight_indices':sorted(weight_mask),'sculpt_indices':sorted(mask),'maximum_encoded_sculpt_delta_error_m':max_sculpt_error,'protected_headneck_j7_plus_exact':True,'normals_only_declared_join_vertices_changed':True,'rig_ibm_nodes_clips_exact':True,'new_triangle_scope':'body-to-foreupper actual shared-index bridge; does not assert whole horse watertightness','rows':rows,'triangles':m['triangles'],'draws':m['mesh_draws']};(P/(variant+'-topology-validation.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
