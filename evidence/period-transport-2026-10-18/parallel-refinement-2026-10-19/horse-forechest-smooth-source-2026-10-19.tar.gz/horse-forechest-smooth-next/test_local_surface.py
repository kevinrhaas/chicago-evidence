# SPDX-License-Identifier: GPL-3.0-or-later
import sys,pathlib,numpy as np
sys.path.insert(0,str(pathlib.Path(__file__).parent/'source'))
from local_surface import smooth_local

def data(points,faces):return {'p':[list(v)for v in points],'i':[v for f in faces for v in f],'n':[[0.,0.,1.]for _ in points],'j':[[0,0,0,0]for _ in points],'w':[[1.,0.,0.,0.]for _ in points]}
# Independent planar two-triangle fixture: outside polygon must remain exact;
# only shared interior diagonal can split, and no old vertex may relax.
g=data([(0,0,0),(1,0,0),(1,1,0),(0,1,0)],[(0,1,2),(0,2,3)]);before=np.asarray(g['p']).copy();r=smooth_local(g,[0,1]);assert np.array_equal(g['p'][:4],before);assert len(g['p'])==5 and len(g['i'])==12;assert np.allclose(g['p'][4],[.5,.5,0]);assert not r['old_vertices_relaxed']
# Independent closed tetrahedron known Loop result: each old corner at one
# quarter original, edge01 midpoint [0,0,.5], 4→16 faces, 4+6 vertices.
points=[(1,1,1),(-1,-1,1),(-1,1,-1),(1,-1,-1)];g=data(points,[(0,2,1),(0,1,3),(0,3,2),(1,2,3)]);r=smooth_local(g,range(4));assert np.allclose(g['p'][:4],np.asarray(points)*.25);assert np.allclose(g['p'][r['split_edges']['0,1']],[0,0,.5]);assert len(g['i'])//3==16 and len(g['p'])==10
# A single selected face cannot split any edge or alter its unselected neighbor.
g=data([(0,0,0),(1,0,0),(1,1,0),(0,1,0)],[(0,1,2),(0,2,3)]);before=[list(v)for v in g['p']];r=smooth_local(g,[0]);assert g['p']==before and g['i']==[0,1,2,0,2,3]
print({'independent_fixtures':3,'pass':True})
