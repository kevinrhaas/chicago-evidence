# Bounded capture and first-frame correction

Original receipt.json remains FAIL because first RAF delta was negative; its30case numerical and actual abort/recovery/disposal assertions passed. No dense proof was repeated.

capture-fixed.cjs serves a transformed outside-only study.js: previous timestamp starts null, first delta0, subsequent delta clamped0..50ms. Negative-delta refusal remains in finite-player.js unchanged. Both pages ran500ms actual RAF without page errors before manual supported start sampling. For deterministic captures only, a captureRender flag prevents competing RAF camera writes; manual sampling still uses the real player and renderer. Exact available three-quarter label selected. Corrected camera positions/viewports are in capture-receipt.json.

Viewed corrected desktop three-quarter and mobile side: entire horse now framed, controls clear of horse on mobile; model remains plainly primitive with rigid thick ears and abrupt leg/body junctions. No anatomy/photographic acceptance. Correction-attempt images retain the intermediate camera-overwrite failure. Original *-three images remain duplicated side views; only *-corrected-three-quarter images show intended three-quarter framing.

Owned browser and loopback server closed after each run. No app writes. Source module and original finite-player archive remain immutable. Future integration must implement this first-frame/camera handling explicitly; capture response transformation is diagnostic scaffolding, not app integration.
