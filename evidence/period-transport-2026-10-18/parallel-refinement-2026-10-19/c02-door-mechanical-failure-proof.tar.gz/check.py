from pathlib import Path
import numpy as np,json,struct,runpy,sys,math,collections,hashlib,time
P=Path(__file__).parent;B=P.parent/'carriage-c02-door-next';sys.argv=[str(B/'generate_carriage_c02.py'),'--parameters',str(B/'door-parameters.json'),'--output-dir',str(P/'input')];e=runpy.run_path(str(B/'generate_carriage_c02.py'));ns=e['oldnodes'];parents={c:i for i,n in enumerate(ns) for c in n.get('children',[])}
def world(i):
 m=e['local'](ns[i])
 while i in parents:i=parents[i];m=e['local'](ns[i])@m
 return m
parts=[]
for i,n in enumerate(ns):
 if 'mesh' not in n:continue
 j=i
 while j in parents and ns[j]['name']!='vehicle_door_left':j=parents[j]
 moving=ns[j]['name']=='vehicle_door_left'
 for q in e['oldmeshes'][n['mesh']]['primitives']:
  a=e['oldaccess'][q['attributes']['POSITION']];v=e['oldviews'][a['bufferView']];xyz=np.array(struct.unpack_from('<%sf'%(a['count']*3),e['oldbinary'],v['byteOffset'])).reshape(-1,3);m=world(i);xyz=xyz@m[:3,:3].T+m[:3,3]
  parts.append({'name':n['name'],'node':i,'moving':moving,'triangles':xyz.reshape(-1,3,3)})
# Verify decoded actual final GLB triangle soup against labeled source primitives.
raw=(P/'input/carriage-c02.glb').read_bytes();n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);binary=raw[28+n:];gp={c:i for i,n in enumerate(g['nodes']) for c in n.get('children',[])}
def gworld(i):
 m=e['local']({**g['nodes'][i],'translation':g['nodes'][i].get('translation',[0,0,0])})
 while i in gp:i=gp[i];m=e['local']({**g['nodes'][i],'translation':g['nodes'][i].get('translation',[0,0,0])})@m
 return m
actual=[]
for i,node in enumerate(g['nodes']):
 if 'mesh' not in node:continue
 m=gworld(i)
 for q in g['meshes'][node['mesh']]['primitives']:
  a=g['accessors'][q['attributes']['POSITION']];v=g['bufferViews'][a['bufferView']];xyz=np.array(struct.unpack_from('<%sf'%(a['count']*3),binary,v['byteOffset'])).reshape(-1,3);actual.extend((xyz@m[:3,:3].T+m[:3,3]).reshape(-1,3,3))
def key(tri):return tuple(sorted(tuple(round(float(v),5) for v in p) for p in tri))
lookup=collections.defaultdict(list)
for tri in actual:lookup[key(tri)].append(tri)
for p in parts:
 decoded=[]
 for tri in p['triangles']:
  choices=lookup[key(tri)];assert choices,(p['name'],tri.tolist());d=choices.pop();assert max(min(np.linalg.norm(d-v,axis=1)) for v in tri)<1e-6;decoded.append(d)
 p['triangles']=np.array(decoded)
assert sum(len(v) for v in lookup.values())==0
fixed=[p for p in parts if not p['moving']];moving=[p for p in parts if p['moving']];ft=np.concatenate([p['triangles'] for p in fixed]);labels=[(p['name'],p['node'],i) for p in fixed for i in range(len(p['triangles']))];flo=ft.min(1);fhi=ft.max(1)
# Triangle SAT including coplanar in-plane axes. AABB is only broad phase.
def intersects(a,b,tol=1e-8):
 ea=np.roll(a,-1,axis=0)-a;eb=np.roll(b,-1,axis=0)-b;na=np.cross(ea[0],ea[1]);nb=np.cross(eb[0],eb[1]);axes=[na,nb]+[np.cross(x,y) for x in ea for y in eb]+[np.cross(na,x) for x in ea]+[np.cross(nb,x) for x in eb]
 for axis in axes:
  length=np.linalg.norm(axis)
  if length<1e-14:continue
  axis=axis/length;pa=a@axis;pb=b@axis
  if pa.max()<pb.min()-tol or pb.max()<pa.min()-tol:return False
 return True
rows=[];pivot=np.array([.645,.82,-.28]);began=time.time()
for degrees in range(0,71,5):
 t=math.radians(degrees);R=np.array([[math.cos(t),0,math.sin(t)],[0,1,0],[-math.sin(t),0,math.cos(t)]]);hits=collections.Counter();samples=[];candidates=0
 for p in moving:
  triangles=(p['triangles']-pivot)@R.T+pivot
  for j,a in enumerate(triangles):
   ix=np.flatnonzero(np.all(fhi>=a.min(0)-1e-8,axis=1)&np.all(flo<=a.max(0)+1e-8,axis=1));candidates+=len(ix)
   for k in ix:
    if intersects(a,ft[k]):
     name,node,tri=labels[k];hits[(p['name'],p['node'],name,node)]+=1
     if len(samples)<12:samples.append({'moving':[p['name'],p['node'],j],'fixed':[name,node,tri]})
 rows.append({'angle_deg':degrees,'broadphase_pairs':candidates,'triangle_intersections_including_contact':sum(hits.values()),'part_pairs':[{'moving':a,'moving_node':b,'fixed':c,'fixed_node':d,'triangle_pairs':count} for (a,b,c,d),count in hits.items()],'examples':samples});print(degrees,sum(hits.values()),flush=True)
report={'status':'Discrete actual GLB triangle surface SAT; all intersections retained, no whitelist','angles_deg':list(range(0,71,5)),'scope':'15 discrete rigid door angles only, triangle surfaces including contact; no continuous clearance or enclosed solid containment proof','actual_final_triangles_matched_to_source_labels':len(actual),'input_sha256':hashlib.sha256(raw).hexdigest(),'generator_sha256':hashlib.sha256((B/'generate_carriage_c02.py').read_bytes()).hexdigest(),'parameters_sha256':hashlib.sha256((B/'door-parameters.json').read_bytes()).hexdigest(),'elapsed_s':time.time()-began,'rows':rows,'intersection_tolerance_m':1e-8,'all_contacts_preserved':True}
(P/'triangle-receipt.json').write_text(json.dumps(report,indent=2)+'\n')
