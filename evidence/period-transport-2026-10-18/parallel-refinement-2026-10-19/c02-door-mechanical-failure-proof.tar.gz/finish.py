from pathlib import Path
import json,hashlib,tarfile,collections
p=Path(__file__).parent;r=json.loads((p/'triangle-receipt.json').read_text());counts=collections.Counter();angles=collections.defaultdict(set)
for row in r['rows']:
 for x in row['part_pairs']:
  k=(x['moving'],x['fixed']);counts[k]+=x['triangle_pairs'];angles[k].add(row['angle_deg'])
summary={'status':'FAIL whole-door surface interference qualification; no integration acceptance','discrete_angles':r['angles_deg'],'total_surface_pairs_including_touches':sum(counts.values()),'pairs':[{'moving':a,'fixed':b,'count':n,'angles_deg':sorted(angles[(a,b)])} for (a,b),n in counts.most_common()],'intentional_contact_exemptions':[],'bearing_basis':'Existing fixed_hinge and hinge_leaf are solid rectangular plates; their overlaps cannot be justified as a pin inside a cleared bearing bore because no pin/bore geometry exists. No hinge-region whitelist applied.','distinguish_contact':'Triangle SAT includes exact/tolerance touches. Lowerrail-bottom/sill-top shareY=.8125, so sill pairs can be tangency rather than volume overlap. Rear/front jambs are axis-aligned boxes with positive closed-state XYZ overlap, a true interference; whole failed receipt is not canceled by contact interpretation.','known_closed_jamb_overlap_m':{'rear_jamb_vs_hinge_stile_Z':.0225,'front_jamb_vs_latch_stile_Z':.0325},'prior_receipt_scope':'Five selected part-axis separation receipts were bounded and remain valid; they did not prove all stationary parts. This test finds untested jamb/hinge problems.','limitations':['15discrete angles only; not fullcontinuous collision proof','Surfaceintersections includingcontact; no all-solidcontainment test','No occupant/boarding/cloth/historic/photographic acceptance']}
(p/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
(p/'README.md').write_text('''# C02 actual triangle mechanical surface qualification — failed

Outside app only, no browser. Exact closed source checkpointGLB/source/parameters copied underinput. All10416 actual final GLB triangles matched one-for-one to unbatched source part labels within1µm (quantized candidate lookup followed by actualvertex-distance check); no triangle omitted. Transform actualmovingdoor/frame/pane/handle triangles through0..70degrees at5degree intervals. Use vectorized AABB broadphase only for candidates, then triangle SAT with normals/edgecross/inplane axes. Intersection tolerance10nm, includes contact; all contacts/intersections retained without whitelist. About2.6sCPU, no denseLBS or sharedgate.

Result FAIL for whole-door clearance. Door vs fixedlowerrear/frontjambs and trim/waist produces surfaceintersections beyond represented hinge mechanism. Actual closed axis-aligned rear/frontjamb/stile boxes overlap22.5/32.5mm alongZ pluspositiveX/Y. Doorhorizontalrail bottom and fixedsill top bothY=.8125m, so some sill pairs are tangency (not automatically volumepenetration). Hinge geometry currentlyconsists of intersecting boxes; not a physical pin in a bearingbore, so no intentional pin/bearing exemption can be supported. Source contains no narrow qualified bearingcontact to whitelist.

Prior limited analyticaxis gaps for five selected parts did not cover every stationary object. They are not revoked or broadened; this separate receipt demonstrates why overall mechanicalfunction remains unaccepted. No new visual geometry fix applied, previous fail/success visuals preserved.15discreteangles do not provecontinuousinterval clearance, and surface tests do not prove absenceofsolidcontainment. No occupants, boardingfit, perioddetail, ownership orphotographicacceptance.

Run `python check.py` using existingPython+NumPy and source generator path; it regenerates onlyoutsideinput. No thirdpartyprogramlogic orBlender. Original projectGPLsource/geometryprovenance unchanged; nophoto copied. The inputgenerator/parameter hashes and generatedGLBhash are in triangle-receipt.json; archive receipt recordsallbytes.
''')
files=sorted(x for x in p.rglob('*') if x.is_file() and not x.name.endswith('.tar.gz') and x.name!='archive-receipt.json');a=p/'c02-door-mechanical-failure-proof.tar.gz';rows=[{'path':str(f.relative_to(p)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in files]
with tarfile.open(a,'w:gz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(p)),recursive=False)
with tarfile.open(a) as t:
 for row in rows:assert hashlib.sha256(t.extractfile(row['path']).read()).hexdigest()==row['sha256']
out={'archive':str(a),'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'bytes':a.stat().st_size,'members':rows};(p/'archive-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k!='members'});print('members',len(rows))
