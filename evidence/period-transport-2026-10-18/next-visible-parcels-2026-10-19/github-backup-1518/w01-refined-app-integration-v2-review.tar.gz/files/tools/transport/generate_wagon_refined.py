#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Reproduce ONE separate W01 refined study; never rewrites defaultW01/driver."""
import argparse,hashlib,json,pathlib,shutil,struct,subprocess,sys,tempfile
P=pathlib.Path(__file__).resolve().parent;S=P/'wagon_refined'
ap=argparse.ArgumentParser();ap.add_argument('--parameters',type=pathlib.Path,required=True);ap.add_argument('--output-dir',type=pathlib.Path,required=True);ap.add_argument('--texture-output-dir',type=pathlib.Path);ap.add_argument('--verify',action='store_true');a=ap.parse_args();cfg=json.loads(a.parameters.read_text())
def require(c,msg):
 if not c:raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
require(cfg['schema']=='w01_refined_separate_study_v1'and cfg['study_id']=='wagon_w01_refined_study','Separate reviewed study recipe required')
require(cfg['hardware_parameters'].get('hardware_refinement')is True,'Explicit hardwareoptin required')
require(cfg['expected_glb_sha256']=='0138ad2565f3e8b08029ef788c5196c65c80c79643313e944c726b993ff31ee4','Reviewed combinedcandidate pin')
with tempfile.TemporaryDirectory(prefix='w01-refined-')as folder:
 t=pathlib.Path(folder);hp=t/'hardware-parameters.json';mp=t/'material-parameters.json';hp.write_text(json.dumps(cfg['hardware_parameters']));mp.write_text(json.dumps(cfg['materials']))
 subprocess.run([sys.executable,str(S/'generate_wagon_hardware.py'),'--parameters',str(hp),'--output-dir',str(t/'hardware')],check=True,capture_output=True)
 subprocess.run([sys.executable,str(S/'apply_materials.py'),'--vehicle',str(t/'hardware/wagon-w01.glb'),'--parts',str(t/'hardware/authored-parts.json'),'--parameters',str(mp),'--output',str(t/'material')],check=True,capture_output=True)
 raw=(t/'material/wagon-w01.glb').read_bytes();require(sha(raw)==cfg['expected_glb_sha256'],'Generated combined GLB differs; no copiedcachedgreen')
 n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);material=json.loads((t/'material/receipt.json').read_text());sidecar=dict(g['extras']);sidecar['geometry_family_asset_id']=sidecar['asset_id'];sidecar['asset_id']=cfg['study_id'];sidecar['glb_sha256']=sha(raw);sidecar['status']='separate refined engineering study; historical and photographic acceptance open';sidecar['license']='GPL-3.0-or-later geometry; CC0-1.0 original embedded procedural maps';sidecar['study_parameters']=cfg;sidecar['statistics']['triangles']=12104;sidecar['statistics']['meshes']=23;sidecar['statistics']['nodes']=50;sidecar['texture_memory_estimate']={'RGBA8_plus_mips_bytes':material['decoded_RGBA8_mips_total_bytes_estimate'],'scope':'actualembeddedimagedimensions, not measuredGPUallocation'};sidecar['source_sha256']={'generate_wagon_refined.py':sha(pathlib.Path(__file__).read_bytes()),**{'wagon_refined/'+p.name:sha(p.read_bytes())for p in sorted(S.iterdir())if p.is_file()and p.suffix in['.py','.json']}};sidecar['recipe_sha256']=sha(a.parameters.read_bytes());sidecar['limitations']=cfg['physical_and_visual_limits']
 products={'wagon-w01.glb':raw,'wagon-w01.json':(json.dumps(sidecar,indent=2,sort_keys=True)+'\n').encode()}
 for name,data in products.items():
  target=a.output_dir/name
  if a.verify:require(target.is_file()and target.read_bytes()==data,'Stale/missinggenerated '+str(target))
  else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 if a.texture_output_dir:
  for source in sorted((t/'material/textures').glob('*.png')):
   target=a.texture_output_dir/source.name
   if a.verify:require(target.is_file()and target.read_bytes()==source.read_bytes(),'Stale/missingoriginalmap '+str(target))
   else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
 print(json.dumps({'verified':a.verify,'asset_id':cfg['study_id'],'glb_sha256':sha(raw),'triangles':12104,'draw_batches':23,'estimated_RGBA8_mips_bytes':material['decoded_RGBA8_mips_total_bytes_estimate']}))
