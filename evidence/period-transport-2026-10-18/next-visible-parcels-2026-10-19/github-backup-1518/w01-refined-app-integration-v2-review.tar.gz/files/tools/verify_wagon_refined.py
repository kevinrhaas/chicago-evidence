#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Flat isolation-discoverable entry for the separate W01 byte verification."""
from pathlib import Path
import runpy,sys
if '--verify'not in sys.argv:raise SystemExit('Verification wrapper requires --verify; use producer explicitly to write outputs')
runpy.run_path(str(Path(__file__).resolve().parent/'transport/generate_wagon_refined.py'),run_name='__main__')
