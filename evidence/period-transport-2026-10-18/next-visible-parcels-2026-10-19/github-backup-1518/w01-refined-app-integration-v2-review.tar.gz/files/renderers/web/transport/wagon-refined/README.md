# Separate refined W01 study

Original reconstructed timbergrain and ironhardware on the supported W01.12104triangles/23batches, standaloneGLB with9embeddedmaps (6MiB RGBA8+mipsestimate). Geometry isGPL-3.0-or-later; original procedural map pixelsCC0-1.0, authoredsource+notice inassets/authored/transport/wagon_refined. No photographpixels or attestedperiodbolt dimensions. Endgrain/hubdetail, mipneutrality, photographicfinish, clothingcontact andload/forces remain open.

Reproduce with tools/transport/generate_wagon_refined.py and data/transport/studies/wagon-refined.json. This directory is a separate opt-instudy; defaultwagon, existingwagon-driver and namedresidentposes are unchanged. Actualcombined model received a twelve-view desktop/mobile engineering A/B; installedpublishedviewer still requires currentheadsource+published smokes.
