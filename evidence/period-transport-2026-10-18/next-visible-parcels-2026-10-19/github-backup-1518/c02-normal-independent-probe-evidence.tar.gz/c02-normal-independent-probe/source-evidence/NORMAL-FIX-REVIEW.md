# One targeted normal-only correction

Actual original candidate43a has bilateral normal asymmetry even though its authored positions are symmetric: max component error0.277700 cushion and0.267225 welt. See normal-mirror-audit.json. The source accumulates each triangle's area normal at its three vertices. Each quad's fixed diagonal consequently contributes twice at two corners, once at the others; long straight segments meeting small rounded corners amplify this shading bias. This is a concrete shading defect. It does not establish that the rendered dark corner is exclusively normal shading rather than self-shadow interaction.

Proposed single correction: triangulation-independent authored normals. Cushion normals sum each original polygon's oriented area vector once per polygon corner, so serialization diagonals no longer select shading weights. Welt normals use the radial unit vectors already used to construct its tube. Geometry, topology, triangle order, material, bounds, socket and door transforms remain exact. No shadow/environment change.

Pure authored-source math compares old/new vertices and triangles exactly; mirror-normal error falls below1.1e-15. All triangle-corner normals remain outward (minimum dot0.793865 cushion,0.917021 welt). No corrected GLB has yet been generated or rendered. Request independent source review before one fresh candidate/readback/Khronos and the same close A/B. If the corner remains, do not claim resolved or search parameters blindly.

Original source, actual43a and a5c403 A/B evidence remain immutable. New source is c02-driver-cushion-normal-fix-next; only cushion_shapes.py differs substantively. Copied predecessor manifests are historical, not hashes of this revision.
