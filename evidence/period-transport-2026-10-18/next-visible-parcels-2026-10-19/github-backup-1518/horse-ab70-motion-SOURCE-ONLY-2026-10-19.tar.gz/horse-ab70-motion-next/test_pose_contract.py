# SPDX-License-Identifier: CC0-1.0
import unittest,tempfile,json,hashlib,copy,struct
from pathlib import Path
from unittest.mock import patch
import pose_contract as c
I=[1.,0.,0.,0.,0.,1.,0.,0.,0.,0.,1.,0.,0.,0.,0.,1.]
class CaptureContract(unittest.TestCase):
 def test_actual_source_grids_have_unique_clip_times_and_closed_endpoints(self):
  q=c.plans('quarter8');f=c.plans('full63');self.assertEqual(len(q),8);self.assertEqual(len(f),63);self.assertEqual(len({(p['clip'],p['time_s'])for p in q}),8);self.assertEqual(len({(p['clip'],p['time_s'])for p in f}),63)
  for name in ['idle','walk','trot']:
   rows=[p for p in f if p['clip']==name];self.assertEqual(rows[0]['time_s'],0);self.assertEqual(rows[-1]['time_s'],rows[-1]['duration_s']);self.assertEqual(rows[-1]['loop'],'LoopOnce_clamp')
 def exercise(self,mutation=None,payload_override=None):
  with tempfile.TemporaryDirectory()as td:
   p=Path(td);cap=p/'idle-fit/capture';cap.mkdir(parents=True);pose={'clip':'walk','phase':.25,'time_s':.25,'duration_s':1.,'loop':'LoopOnce_clamp'};pb=(json.dumps(pose)+'\n').encode();(p/'pose.json').write_bytes(pb);groups=[{'name':'part'+str(i),'sourceMesh':i,'sourcePrimitive':0,'start':i,'count':1,'positionCount':3,'indexCount':3,'indexed':True,'indexStreamSHA256':hashlib.sha256(struct.pack('<III',0,1,2)).hexdigest()}for i in range(36)];payload=struct.pack('<9d',0,0,0,1,0,0,0,1,0)*36;payload=payload if payload_override is None else payload_override;bindings={name:{'horse_world':I[:],'gear_world':I[:],'max_abs_error':0.}for name in ['root','head']};m={'input':list(c.INPUTS['candidate']),'pose':copy.deepcopy(pose),'pose_sha256':hashlib.sha256(pb).hexdigest(),'precision':'float64_world','post_world_rounding':False,'root_world':I[:],'head_world':I[:],'triangleCount':36,'meshes':copy.deepcopy(groups),'buffer_sha256':hashlib.sha256(payload).hexdigest(),'bindings':bindings}
   if mutation:mutation(m)
   mb=(json.dumps(m)+'\n').encode();(cap/'candidate.json').write_bytes(mb);receipt={'PASS':True,'pose':pose,'pose_sha256':hashlib.sha256(pb).hexdigest(),'capture_source_sha256':hashlib.sha256((c.P/'capture_pose.mjs').read_bytes()).hexdigest(),'files':[{'label':k,'input_sha256':v[1],'metadata_sha256':hashlib.sha256(mb).hexdigest(),'buffer_sha256':hashlib.sha256(payload).hexdigest(),'triangleCount':m['triangleCount']}for k,v in c.INPUTS.items()]};(cap/'capture-receipt.json').write_text(json.dumps(receipt))
   with patch.object(c,'owned_pose',return_value=(p,pose)),patch.object(c,'source_expected',return_value=groups):return c.validate('candidate',m,payload)
 def test_complete_synthetic_contract(self):self.exercise()
 def test_truncated_payload_count_zero_duplicate_and_wrong_attribution_refused(self):
  bad=[lambda m:m.update(triangleCount=0),lambda m:m['meshes'][0].update(count=0),lambda m:m['meshes'].pop(),lambda m:m['meshes'][1].update(name='part0'),lambda m:m['meshes'][0].update(sourcePrimitive=1),lambda m:m['meshes'][0].update(sourceMesh=False),lambda m:m['meshes'][0].update(indexed=1),lambda m:m['pose'].update(phase=True),lambda m:m['meshes'][0].update(indexStreamSHA256='0'*64),lambda m:m.update(post_world_rounding=True),lambda m:m['pose'].update(clip='trot'),lambda m:m['bindings']['head']['gear_world'].__setitem__(13,.01)]
  for mutate in bad:
   with self.subTest(mutate=mutate):
    with self.assertRaises(ValueError):self.exercise(mutate)
 def test_degenerate_zero_geometry_refused_even_with_consistent_hashes(self):
  with self.assertRaises(ValueError):self.exercise(payload_override=b'\0'*(36*72))
if __name__=='__main__':unittest.main()
