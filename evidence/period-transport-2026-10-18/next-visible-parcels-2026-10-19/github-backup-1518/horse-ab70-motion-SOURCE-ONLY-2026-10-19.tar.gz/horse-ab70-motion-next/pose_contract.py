# SPDX-License-Identifier: GPL-3.0-or-later
"""Pinned immutable inputs, decoded clip times and complete posed capture contract."""
from pathlib import Path
import json,struct,hashlib,collections,math,os
import numpy as np
P=Path(__file__).parent
AB70=Path('/workspace/shared/horse-combined-oral-neck-mane-prefix-next/candidate-one/candidate.glb')
INPUTS={'horse':(str(AB70),'ab70aff958bc8a2780458d37212be1866c730817f485fbebbf53bd3c0e3931c3'),'baseline':('/workspace/shared/horse-v2-cap-registered-next/build1/light_breastcollar_harness_reconstructed_01.glb','078ed2cebc01dba52d28f2ae737f170f0fe28fd20523aed9bb8869f4cd7b35bd'),'candidate':('/workspace/shared/horse-hindgear-support-hull-candidate/candidate-one/light_breastcollar_harness_reconstructed_01.glb','fe76c95b49234da64700a1e20741b4998e8cfbae69571387d49bf5bb23ef04b1')}
def require(c,msg):
 if not c:raise ValueError(msg)
def load(label):
 path,want=INPUTS[label];raw=Path(path).read_bytes();require(hashlib.sha256(raw).hexdigest()==want,'actualimmutableGLBpin');magic,version,total=struct.unpack_from('<III',raw);require(magic==0x46546c67 and version==2 and total==len(raw),'GLBheader');n,kind=struct.unpack_from('<II',raw,12);require(kind==0x4e4f534a,'JSONchunk');bn,bk=struct.unpack_from('<II',raw,20+n);require(bk==0x004e4942 and 28+n+bn==len(raw),'BINchunk');return json.loads(raw[20:20+n]),raw[28+n:]
def source_clips():
 d,b=load('horse');out={}
 for a in d['animations']:
  require(a['name']not in out,'uniqueclipname');times=[]
  for sampler in a['samplers']:
   ac=d['accessors'][sampler['input']];v=d['bufferViews'][ac['bufferView']];require(ac['componentType']==5126 and ac['type']=='SCALAR'and'sparse'not in ac and'byteStride'not in v,'plainactualFLOATtime');require(type(ac['count'])is int and ac['count']>0,'nonemptyactualtime');off=v.get('byteOffset',0)+ac.get('byteOffset',0);vals=struct.unpack_from('<'+'f'*ac['count'],b,off);require(all(math.isfinite(x)and x>=0 for x in vals)and all(y>x for x,y in zip(vals,vals[1:])),'finiteordereddecodedtime');times.extend(vals)
  duration=max(times);require(min(times)==0 and duration>0,'actualzerooriginduration');out[a['name']]={'duration_s':duration,'source_time_sha256':hashlib.sha256(struct.pack('<'+'d'*len(times),*times)).hexdigest()}
 require(set(out)=={'idle','walk','trot'},'actualthreeclips');return out

def plans(stage):
 clips=source_clips();grid=[(c,k/4)for c in['walk','trot']for k in range(4)]if stage=='quarter8'else[(c,k/20)for c in['idle','walk','trot']for k in range(21)]if stage=='full63'else None;require(grid is not None,'knownstage');return[{'stage':stage,'index':i,'clip':c,'phase':phase,'duration_s':clips[c]['duration_s'],'time_s':phase*clips[c]['duration_s'],'source_time_sha256':clips[c]['source_time_sha256'],'loop':'LoopOnce_clamp','input_sha256':{k:v[1]for k,v in INPUTS.items()}}for i,(c,phase)in enumerate(grid)]
def real_pose(r):return isinstance(r,dict)and all(type(r.get(k))in[int,float]and math.isfinite(r[k])for k in ['phase','time_s','duration_s'])
def owned_pose():
 p=Path(os.environ['CHICAGO_POSE_DIR']).resolve();r=json.loads((p/'pose.json').read_text());grid=plans(r.get('stage'));i=r.get('index');require(type(i)is int and 0<=i<len(grid)and real_pose(r)and r==grid[i],'actualposeplanexactrederive');return p,r

def source_expected(label):
 d,b=load(label);active=set()
 def visit(i):
  require(type(i)is int and 0<=i<len(d['nodes'])and i not in active,'uniqueactivenode');active.add(i)
  for c in d['nodes'][i].get('children',[]):visit(c)
 for i in d['scenes'][d.get('scene',0)]['nodes']:visit(i)
 result=[]
 for i in active:
  n=d['nodes'][i]
  if'mesh'not in n:continue
  for pi,pr in enumerate(d['meshes'][n['mesh']]['primitives']):
   require(pr.get('mode',4)==4,'actualtriangles');pc=d['accessors'][pr['attributes']['POSITION']]['count'];a=d['accessors'][pr['indices']];v=d['bufferViews'][a['bufferView']];fmt,size={5121:('B',1),5123:('H',2),5125:('I',4)}[a['componentType']];off=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',size);ids=[struct.unpack_from('<'+fmt,b,off+k*stride)[0]for k in range(a['count'])];require(len(ids)>0 and len(ids)%3==0 and all(0<=x<pc for x in ids),'actualindices');result.append({'name':d['meshes'][n['mesh']]['name'],'sourceMesh':n['mesh'],'sourcePrimitive':pi,'positionCount':pc,'indexCount':len(ids),'indexed':True,'indexStreamSHA256':hashlib.sha256(struct.pack('<'+'I'*len(ids),*ids)).hexdigest()})
 return result
FIELDS=('name','sourceMesh','sourcePrimitive','positionCount','indexCount','indexed','indexStreamSHA256')
def matrix(x):return isinstance(x,list)and len(x)==16 and all(type(v)in[int,float]and math.isfinite(v)for v in x)
def validate(label,m,payload):
 directory,pose=owned_pose();posebytes=(directory/'pose.json').read_bytes();receipt=json.loads((directory/'idle-fit/capture/capture-receipt.json').read_text());require(receipt.get('PASS')is True and receipt.get('pose')==pose and receipt.get('pose_sha256')==hashlib.sha256(posebytes).hexdigest() and receipt.get('capture_source_sha256')==hashlib.sha256((P/'capture_pose.mjs').read_bytes()).hexdigest(),'freshcompletedcapturewithactualsourcehash');files=receipt.get('files',[]);require(len(files)==3 and {r['label']for r in files}==set(INPUTS),'all3freshcapturefiles');row=next(r for r in files if r['label']==label);require(row['metadata_sha256']==hashlib.sha256((directory/'idle-fit/capture'/f'{label}.json').read_bytes()).hexdigest() and row['buffer_sha256']==hashlib.sha256(payload).hexdigest() and row['input_sha256']==INPUTS[label][1] and row.get('triangleCount')==m.get('triangleCount') and m.get('pose_sha256')==hashlib.sha256(posebytes).hexdigest(),'freshmetadata/buffer/pose/inputhashlinks');require(m.get('input')==list(INPUTS[label])and real_pose(m.get('pose'))and m.get('pose')==pose,'exactinputandpose');require(m.get('precision')=='float64_world'and m.get('post_world_rounding')is False,'binary64worldnorequantization');require(hashlib.sha256(payload).hexdigest()==m.get('buffer_sha256'),'actualbufferhash');require(matrix(m.get('root_world'))and matrix(m.get('head_world')),'finiteactualboneframes');groups=m.get('meshes');require(isinstance(groups,list)and bool(groups),'nonemptyprimitivecoverage');start=0
 for g in groups:
  require(g.get('indexed')is True and isinstance(g.get('name'),str)and bool(g['name'])and all(type(g.get(k))is int and g[k]>=0 for k in ['sourceMesh','sourcePrimitive'])and type(g.get('positionCount'))is int and g['positionCount']>0 and type(g.get('indexCount'))is int and g['indexCount']>0,'strictsourcefieldtypes')
  require(type(g.get('count'))is int and g['count']>0 and type(g.get('start'))is int and g['start']==start and g.get('indexCount')==3*g['count'],'completecontiguousnonzerocoverage');start+=g['count']
 require(type(m.get('triangleCount'))is int and m['triangleCount']==start and len(payload)==start*72,'fullpayloadcoverage');tri=np.frombuffer(payload,dtype='<f8').reshape(-1,3,3);require(np.isfinite(tri).all(),'finiteactualworldsurface');areas=np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1)/2;require(float(areas.min())>1e-12,'existingcapturenondegeneracyguard');require(collections.Counter(tuple(g[k]for k in FIELDS)for g in groups)==collections.Counter(tuple(g[k]for k in FIELDS)for g in source_expected(label)),'actualsourceprimitive/name/indexbinding')
 if label!='horse':
  require(len(groups)==36 and len({g['name']for g in groups})==36,'all36uniquenamedparts');bind=m.get('bindings',{});require(set(bind)=={'root','head'},'explicitrootheadbindings')
  for name,key in [('root','root_world'),('head','head_world')]:
   row=bind[name];require(matrix(row.get('horse_world'))and matrix(row.get('gear_world'))and row['horse_world']==m[key],'bindingactualframe');bound=128*2**-52*max(1.,max(abs(v)for v in row['horse_world']));error=max(abs(a-b)for a,b in zip(row['horse_world'],row['gear_world']));require(math.isfinite(error)and error<=bound and type(row.get('max_abs_error'))in[int,float]and row.get('max_abs_error')==error,'actualbindingrecompositionroundoffbound')
 return m
