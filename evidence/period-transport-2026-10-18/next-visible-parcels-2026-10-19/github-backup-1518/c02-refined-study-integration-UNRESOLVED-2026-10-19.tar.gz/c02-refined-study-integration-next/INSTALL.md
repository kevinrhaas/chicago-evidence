# Optional technical study; NOT appearance accepted

Do not install automatically. Copy files/ into chicago/4d only after root review. Keep carriage-c02/ and its producer/default gallery entry intact. Add gallery-entry.html as an additional explicit transport/index.html article. This new gallery page reuses the unchanged original C02 viewer; its newly added disclosure is untested as an installed page. Prior A/B responsive evidence applies to the independent fixture, not this new page. No main-scene placement or isolation row is supplied.

Reproduce into a FRESH directory:
python tools/transport/c02_cushion/produce.py --baseline renderers/web/transport/carriage-c02/carriage-c02.glb --out /tmp/c02-cushion-fresh
Compare output SHA to recipe. Requires numpy and the existing Python environment. The original baseline SHA is mandatory. No Blender/network required. Copy only the generated GLB after exact match; sidecar/recipe are supplied separately and must remain in sync.

The cc469 correction removes a proven normal symmetry defect. Actual close A/B STILL shows the right rear corner mark. Do not call it visibly repaired, photographic, occupant-qualified, or ready to replace baseline. Future source-root isolation (geometry/normal/self-shadow junction) remains necessary. All original doors/hitch/period claims stay unchanged. The original43a evidence and its failure remain preserved.

Before commit: existing full check per AGENTS, independent installed gallery/producer verification and protected baseline hash check. Add flat verifier enumeration only if the existing checker actually requires registration; no fabricated isolation row. No test threshold/budget changes.
