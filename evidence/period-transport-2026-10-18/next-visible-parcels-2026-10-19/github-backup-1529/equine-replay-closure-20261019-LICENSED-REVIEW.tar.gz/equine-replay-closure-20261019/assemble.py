from pathlib import Path
import hashlib,json,re,shutil
ROOT=Path(__file__).parent; files={}; pins={}; missing=[]
def add(p,expected=None):
 p=Path(p)
 if not p.is_file():
  if expected:missing.append(str(p))
  return
 if p.is_symlink():raise ValueError('symlink '+str(p))
 h=hashlib.sha256(p.read_bytes()).hexdigest()
 if expected and expected!=h:raise ValueError('PIN MISMATCH '+str(p))
 if expected:pins[str(p)]=expected
 files[str(p)]=h
S=Path('/workspace/shared')
for d in ['horse-combined-oral-neck-mane-prefix-next','horse-ab70-motion-next','horse-ab70-motion-nonindexed-next','horse-hindgear-support-hull-candidate','horse-mane-fitted-next','horse-neck-hybrid-pipeline-next']:
 q=S/d
 for n in ['SOURCE-HASHES.json','EXTERNAL-HASHES.json','operator-source-pins.json','SOURCE-FREEZE.json']:
  p=q/n
  if p.exists():
   add(p);data=json.loads(p.read_text())
   if isinstance(data,dict):
    for k,v in data.items():
     if isinstance(v,str) and re.fullmatch('[0-9a-f]{64}',v):add(Path(k) if k.startswith('/') else q/k,v)
 for p in q.iterdir():
  if p.is_file() and p.suffix in ['.py','.mjs','.cjs','.json','.md']:add(p)
for d in ['horse-combined-oral-neck-mane-prefix-next/candidate-one','horse-mane-fitted-first-local-trial/payload','horse-neck-hybrid-first-local-trial/payload','horse-hindgear-support-hull-candidate/source','horse-hindgear-support-hull-candidate/candidate-one','horse-hindgear-threepart-candidate/source','horse-hindgear-threepart-candidate/candidate-one','horse-headgear-exact078-rebase','horse-ear-root-idle-checker-f64-unique-next/provenance']:
 for p in (S/d).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:add(p)
for d,names in {
 'horse-head-groove-coat-next/trial1':['equine_light_harness_skinned_prototype_01.glb','manifest.json','head-source-surface.json','ear-source-surfaces.json'],
 'horse-ear-root-exporter-source-reviewed-next/export-trial1':['equine_ear_root_candidate.glb','export-local-proof.json','manifest.json','authority.json'],
 'horse-ear-root-exporter-source-reviewed-next/source-trial1':['candidate-source-edit.json'],
 'horse-ear-root-first-idle-binary64-trial/results':['candidate-head_vs_all_rest.json'],
 'horse-headgear-first-idle-plan-v3/capture':['horse.json','horse.f64'],
 'horse-oral-channel-diagonal-candidate/candidate-one':['equine_light_harness_skinned_prototype_01.glb','head-source-surface.json'],
}.items():
 for n in names:add(S/d/n)
# Follow existing absolute literal file dependencies transitively; never execute source.
for _ in range(12):
 before=len(files)
 for s in list(files):
  p=Path(s)
  if p.suffix not in ['.py','.mjs','.cjs','.json']:continue
  for ref in re.findall(r'/workspace/[A-Za-z0-9_./+-]+',p.read_text(errors='replace')):
   q=Path(ref)
   if q.is_file() and not q.is_symlink() and '/bin/' not in ref:add(q)
 if len(files)==before:break
for p in Path('/workspace/shared/transport-tools/node_modules/gltf-validator').iterdir():
 if p.is_file():add(p)
for p in [Path('/usr/share/common-licenses/GPL-3'),Path('/workspace/chicago/chicago/4d/assets/LICENSES.md'),Path('/workspace/chicago/chicago/4d/renderers/web/vendor/MANIFEST')]:add(p)
# Actual installed Three license, not inferred text.
for base in [Path('/workspace/shared/transport-tools/node_modules/three'),Path('/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1')]:
 for n in ['LICENSE','LICENSE.txt','package.json']:
  if (base/n).is_file():add(base/n)
if missing:raise ValueError('Missing pinned files '+str(missing))
for s,h in sorted(files.items()):
 dest=ROOT/'payload'/s.lstrip('/');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(s,dest)
 if hashlib.sha256(dest.read_bytes()).hexdigest()!=h:raise ValueError('copy mismatch')
(ROOT/'FILES.json').write_text(json.dumps(files,indent=2,sort_keys=True)+'\n')
(ROOT/'DECLARED-PINS.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
print(json.dumps({'files':len(files),'declared_pins':len(pins),'bytes':sum(Path(p).stat().st_size for p in files)},indent=2))
