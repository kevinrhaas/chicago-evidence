"""Verify exact archived bytes; stdlib only, no model evaluation/network."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
files=json.loads((root/'FILES.json').read_text())
for original,want in files.items():
 p=root/'payload'/original.lstrip('/')
 if not p.is_file() or p.is_symlink():raise SystemExit('Missing/unsafe '+original)
 if hashlib.sha256(p.read_bytes()).hexdigest()!=want:raise SystemExit('SHA mismatch '+original)
for p in (root/'payload').rglob('*'):
 if p.is_file() and '/'+p.relative_to(root/'payload').as_posix() not in files:raise SystemExit('Unlisted '+str(p))
print(json.dumps({'passed':True,'files':len(files),'scope':'snapshot-byte-identity only; no replay/geometry/motion acceptance'}))
