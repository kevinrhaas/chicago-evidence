// SPDX-License-Identifier: CC0-1.0
// Actual Three loader/skinning endpoint check; no renderer, horse collision or rider fit.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import * as T from '/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/three.module.js';
import {GLTFLoader} from '/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/addons/loaders/GLTFLoader.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const [candidateName, outputName, proofName] = process.argv.slice(2);
assert(candidateName && outputName && proofName && !fs.existsSync(outputName), 'fresh candidate, receipt and proof paths required');
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const horseName = path.join(here,'horse-source.glb');
const sourceName = path.join(here,'source.glb');
const horseBytes = fs.readFileSync(horseName), sourceBytes = fs.readFileSync(sourceName);
assert.equal(sha(horseBytes),'6e9b37b755ae3eda7b5cf2f492d1781b0e507664a99c88a2e6dee086f77c2296');
assert.equal(sha(sourceBytes),'2d9ae61220747eab0b44fdfea3f504f5310c83540de9ab1d8d1a79cf32e5df91');
const sourceProof = JSON.parse(fs.readFileSync(proofName));
const candidateBytes = fs.readFileSync(candidateName);
assert.equal(sha(candidateBytes),sourceProof.output_sha256);
const loader = new GLTFLoader();
const load = b => loader.parseAsync(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),'');
const horse = await load(horseBytes), source = await load(sourceBytes), candidate = await load(candidateBytes);
const wrapper = new T.Group(); wrapper.add(horse.scene,source.scene,candidate.scene);
const clip = horse.animations.find(c => c.name === 'walk'); assert(clip);
const mixer = new T.AnimationMixer(horse.scene);
const action = mixer.clipAction(clip); action.setLoop(T.LoopOnce,1); action.clampWhenFinished = true; action.play();
const named = (scene,name) => {const o = scene.getObjectByName(name); assert(o,`missing ${name}`); return o;};
function bind(gear) {
  const root = named(gear.scene,'root'), head = named(gear.scene,'riding_head');
  root.matrixAutoUpdate = false;
  root.matrix.copy(root.parent.matrixWorld).invert().multiply(named(horse.scene,'root').matrixWorld);
  gear.scene.updateMatrixWorld(true);
  head.matrixAutoUpdate = false;
  head.matrix.copy(head.parent.matrixWorld).invert().multiply(named(horse.scene,'head').matrixWorld);
  gear.scene.updateMatrixWorld(true);
  gear.scene.traverse(o => {if(o.isSkinnedMesh)o.skeleton.update();});
}
function centroid(mesh, indices) {
  const p = new T.Vector3(), c = new T.Vector3();
  assert.equal(indices.length,4); assert.equal(new Set(indices).size,4);
  for(const i of indices){mesh.getVertexPosition(i,p); c.add(p.applyMatrix4(mesh.matrixWorld));}
  return c.multiplyScalar(.25);
}
const rows=[];
let failure = null;
try {
  for(const transform of ['identity','common-parent']){
    wrapper.position.set(transform==='identity'?0:3.25,transform==='identity'?0:-.4,transform==='identity'?0:7.5);
    wrapper.rotation.set(transform==='identity'?0:.17,transform==='identity'?0:-.43,transform==='identity'?0:.11);
    wrapper.scale.set(transform==='identity'?1:1.2,transform==='identity'?1:.9,transform==='identity'?1:1.1);
    for(let k=0;k<=20;k++){
      action.reset().play();mixer.setTime(k/20*clip.duration);wrapper.updateMatrixWorld(true);
      bind(source);bind(candidate);
      for(const side of ['l','r']){
        const indices=sourceProof.rings[side], cm=named(candidate.scene,'riding_rein_'+side), sm=named(source.scene,'riding_rein_'+side);
        assert(cm.isSkinnedMesh && !sm.isSkinnedMesh);
        assert.equal(cm.geometry.attributes.position.count,84);
        const bit=named(candidate.scene,'socket_riding_bit_'+side).getWorldPosition(new T.Vector3());
        const hand=named(candidate.scene,'socket_riding_rein_hand_'+side).getWorldPosition(new T.Vector3());
        const bitGap=centroid(cm,indices.first_ring_rows).distanceTo(bit);
        const handGap=centroid(cm,indices.last_ring_rows).distanceTo(hand);
        const oldGap=centroid(sm,indices.first_ring_rows).distanceTo(named(source.scene,'socket_riding_bit_'+side).getWorldPosition(new T.Vector3()));
        const row={transform,sample:k,clip:'walk',time_s:k/20*clip.duration,side,bit_gap_m:bitGap,hand_gap_m:handGap,original_static_gap_m:oldGap};rows.push(row);
        assert(Number.isFinite(bitGap)&&Number.isFinite(handGap)&&Number.isFinite(oldGap));
        assert(bitGap<1e-6 && handGap<1e-6,JSON.stringify(row));
      }
    }
  }
  assert.equal(rows.length,84);
  assert(Math.max(...rows.filter(r=>r.transform==='identity').map(r=>r.original_static_gap_m))>.010,'old measured static failure must reproduce');
} catch(e) {failure=String(e.stack||e);}
const result={scope:'Actual loaded endpoint deformation only: old horse6e9b and original riding gear; no collision, rider, pressure or photographic acceptance',horse_sha256:sha(horseBytes),source_sha256:sha(sourceBytes),candidate_sha256:sha(candidateBytes),passed:!failure,failure,rows,max_bit_gap_m:Math.max(...rows.map(r=>r.bit_gap_m)),max_hand_gap_m:Math.max(...rows.map(r=>r.hand_gap_m)),max_original_static_gap_m:Math.max(...rows.map(r=>r.original_static_gap_m))};
fs.writeFileSync(outputName,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({passed:result.passed,rows:rows.length,max_bit_gap_m:result.max_bit_gap_m,max_hand_gap_m:result.max_hand_gap_m,max_original_static_gap_m:result.max_original_static_gap_m,failure}));
if(failure)process.exitCode=1;
