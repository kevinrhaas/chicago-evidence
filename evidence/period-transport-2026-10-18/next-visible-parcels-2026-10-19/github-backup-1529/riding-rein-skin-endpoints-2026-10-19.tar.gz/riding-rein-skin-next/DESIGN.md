# Portable rein endpoint correction — outside application

The retained original 1835 riding study has a measured 10.957018 mm maximum
bit-to-rein gap over its 21 walk samples. Its bridle follows the horse head,
but both reins are rigid children of the actor root. This parcel adds a glTF
skin to the two existing rein primitives. It preserves all source geometry,
other components and reconstructed hand targets.

The four authored rein cross-sections receive head weights 1, 2/3, 1/3, 0,
with the remaining weight on actor root. Root and riding_head are existing
actual glTF nodes; inverse bind matrices are their actual inverse rest-world
matrices. The emitted float32 complementary weights are normalized. Only
new JOINTS_0/WEIGHTS_0 accessors, one shared skin, and explicit metadata are
added. Every old BIN byte and old geometry accessor must remain exact.

The cross-section mapping comes from the retained generator's exact expanded
triangle order, verified against reconstructed source ring positions before
any output is emitted. No nearest-neighbour assignment or inferred vertex
order is allowed. Each actual loaded first-ring centroid must coincide with
its loaded head-bound bit socket, and its final-ring centroid with the root
hand socket, through all 21 old walk samples. The actual source model's
static error must reproduce as a negative control. Common transformed actor
parents and exact inverse-parent head binding must be exercised as well.

This only corrects endpoints. Linear blend deformation does not solve leather
tension, rein slack, hand motion, physical forces or horse/rider collisions.
The old riding bridle and saddle remain unfinished and are not qualified on
the new ab70 horse. The retained horse is the exact old 6e9b source, not a
substitute for the frozen ab70/fe76 harness-motion pair. No anonymous person,
period likeness, production scene, photographic quality or riding acceptance
is claimed. No app files, original studies or qualification receipts change.

Required proof: source/stored-geometry identity, deterministic result,
independent source review, actual Three loaded endpoint checks and Khronos
issue accounting. Any actual failure is saved before a new source revision.
