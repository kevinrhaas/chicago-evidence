# SPDX-License-Identifier: CC0-1.0
"""Append endpoint skinning to the exact original riding-study GLB.

This is a portable glTF deformation study, not a leather physics solver.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import struct

SOURCE_SHA = "2d9ae61220747eab0b44fdfea3f504f5310c83540de9ab1d8d1a79cf32e5df91"


def decode(raw):
    magic, version, size = struct.unpack_from("<III", raw)
    assert (magic, version, size) == (0x46546C67, 2, len(raw))
    count, kind = struct.unpack_from("<II", raw, 12)
    assert kind == 0x4E4F534A
    doc = json.loads(raw[20:20 + count])
    n, kind = struct.unpack_from("<II", raw, 20 + count)
    assert kind == 0x004E4942 and 28 + count + n == len(raw)
    return doc, bytearray(raw[28 + count:])


def source_sections(sign):
    points = [[sign * .095, 1.68, 1.19], [sign * .19, 1.73, .92],
              [sign * .24, 1.76, .55], [sign * .17, 1.84, .16]]
    def unit(v):
        n = math.sqrt(sum(x*x for x in v))
        assert n > 1e-9
        return [x/n for x in v]
    vertices = []
    for j, c in enumerate(points):
        tangent = unit([points[min(3, j+1)][k] - points[max(0, j-1)][k] for k in range(3)])
        dot = tangent[1]
        side = unit([(1 if k == 1 else 0) - tangent[k]*dot for k in range(3)])
        normal = [tangent[1]*side[2]-tangent[2]*side[1],
                  tangent[2]*side[0]-tangent[0]*side[2],
                  tangent[0]*side[1]-tangent[1]*side[0]]
        for sw, st in [(-1, -1), (1, -1), (1, 1), (-1, 1)]:
            vertices.append([c[k] + side[k]*sw*.014/2 + normal[k]*st*.003/2 for k in range(3)])
    faces = []
    for j in range(3):
        for k in range(4):
            a = j*4+k; b = j*4+(k+1) % 4; c = b+4; e = a+4
            faces.extend([(a,b,c), (a,c,e)])
    faces.extend([(0,2,1), (0,3,2), (12,13,14), (12,14,15)])
    ids = [i for face in faces for i in face]
    expanded = struct.pack('<' + 'f'*(len(ids)*3), *(v for i in ids for v in vertices[i]))
    return ids, expanded


def produce(source, output):
    raw = source.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == SOURCE_SHA
    doc, binary = decode(raw)
    before = len(binary)
    assert 'skins' not in doc
    root = next(i for i,n in enumerate(doc['nodes']) if n['name'] == 'root')
    head = next(i for i,n in enumerate(doc['nodes']) if n['name'] == 'riding_head')
    assert root == 0 and doc['scenes'][doc['scene']]['nodes'] == [root]
    assert head in doc['nodes'][root]['children']
    assert set(doc['nodes'][root]) <= {'name','extras','children'}
    assert doc['nodes'][head]['translation'] == [0,1.88,.8]
    assert set(doc['nodes'][head]) <= {'name','translation','extras','children'}
    def append(rows, kind, component, fmt):
        while len(binary) % 4: binary.append(0)
        off = len(binary)
        values = [v for row in rows for v in row]
        binary.extend(struct.pack('<'+fmt*len(values), *values))
        vi = len(doc['bufferViews'])
        doc['bufferViews'].append({'buffer':0,'byteOffset':off,'byteLength':len(binary)-off})
        ai = len(doc['accessors'])
        doc['accessors'].append({'bufferView':vi,'componentType':component,'count':len(rows),'type':kind})
        return ai
    ident = [1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]
    inv_head = ident.copy(); inv_head[13] = -1.88; inv_head[14] = -.8
    matrices = append([ident,inv_head], 'MAT4', 5126, 'f')
    doc['skins'] = [{'name':'original_riding_rein_endpoints', 'joints':[root,head],
                     'skeleton':root,'inverseBindMatrices':matrices}]
    receipts = {}
    for side, sign in [('l',1),('r',-1)]:
        name = 'riding_rein_'+side
        mesh = next(m for m in doc['meshes'] if m['name'] == name)
        node = next(n for n in doc['nodes'] if n.get('mesh') == doc['meshes'].index(mesh))
        assert len(mesh['primitives']) == 1
        prim = mesh['primitives'][0]; assert 'indices' not in prim and prim.get('mode',4) == 4
        assert set(prim['attributes']) == {'POSITION','NORMAL'}
        a = doc['accessors'][prim['attributes']['POSITION']]
        v = doc['bufferViews'][a['bufferView']]
        ids, expected = source_sections(sign)
        assert a['componentType'] == 5126 and a['type'] == 'VEC3' and a['count'] == len(ids)
        assert v.get('byteStride',12) == 12 and not a.get('sparse')
        off = v.get('byteOffset',0) + a.get('byteOffset',0)
        assert bytes(binary[off:off+len(expected)]) == expected, 'source expanded section stream changed'
        weights = []
        for i in ids:
            head_weight = struct.unpack('<f', struct.pack('<f',1-(i//4)/3))[0]
            root_weight = struct.unpack('<f', struct.pack('<f',1-head_weight))[0]
            weights.append([root_weight,head_weight,0,0])
        prim['attributes']['JOINTS_0'] = append([[0,1,0,0] for _ in ids],'VEC4',5123,'H')
        prim['attributes']['WEIGHTS_0'] = append(weights,'VEC4',5126,'f')
        node['skin'] = 0
        node.setdefault('extras',{})['binding'] = 'two-anchor linear blend; root hand/head bit; reconstructed, not physical tension or rider fit'
        receipts[side] = {'expanded_count':len(ids),'source_cross_sections':[i//4 for i in ids],
                          'first_ring_rows':[ids.index(i) for i in range(4)],
                          'last_ring_rows':[ids.index(i) for i in range(12,16)]}
    doc['buffers'][0]['byteLength'] = len(binary)
    assert bytes(binary[:before]) == raw[len(raw)-before:]
    encoded = json.dumps(doc,separators=(',',':')).encode()
    encoded += b' '*(-len(encoded)%4)
    while len(binary)%4:binary.append(0)
    result = struct.pack('<III',0x46546C67,2,28+len(encoded)+len(binary))
    result += struct.pack('<II',len(encoded),0x4E4F534A)+encoded
    result += struct.pack('<II',len(binary),0x004E4942)+binary
    assert not output.exists(), 'refuse overwrite'
    output.write_bytes(result)
    return {'source_sha256':SOURCE_SHA,'output_sha256':hashlib.sha256(result).hexdigest(),
            'source_binary_prefix_bytes':before,'unchanged_geometry':True,'rings':receipts,
            'scope':'Endpoint deformation study only; no leather/rider/horse collision or photographic acceptance'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--receipt',type=Path,required=True)
    args = parser.parse_args()
    assert not args.receipt.exists(), 'refuse receipt overwrite'
    proof = produce(args.source,args.output)
    args.receipt.write_text(json.dumps(proof,indent=2)+'\n')
