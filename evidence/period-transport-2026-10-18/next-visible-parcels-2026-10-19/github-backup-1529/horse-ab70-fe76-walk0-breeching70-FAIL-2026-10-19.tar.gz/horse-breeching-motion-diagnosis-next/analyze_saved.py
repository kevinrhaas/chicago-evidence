# SPDX-License-Identifier: GPL-3.0-or-later
"""Saved source/capture ownership diagnosis only; no SAT/capture/generation."""
from pathlib import Path
import sys,json,hashlib,collections
import numpy as np
sys.path.insert(0,'/workspace/shared/horse-combined-oral-neck-mane-prefix-next')
from analyze_graft import Model
P=Path(__file__).parent;GLB=Path('/workspace/shared/horse-combined-oral-neck-mane-prefix-next/candidate-one/candidate.glb');raw=GLB.read_bytes()
if hashlib.sha256(raw).hexdigest()!='ab70aff958bc8a2780458d37212be1866c730817f485fbebbf53bd3c0e3931c3':raise ValueError('horse pin')
m=Model(raw);original=json.loads(Path('/workspace/shared/horse-head-groove-coat-next/trial1/manifest.json').read_text());root=Path('/workspace/shared/horse-ab70-motion-nonindexed-next/runs/quarter8/pose-00-walk');fitpath=root/'idle-fit/results/actual-idle-results.json';fit=json.loads(fitpath.read_text());row=next(r for r in fit['rows']if r['label']=='candidate');
if not(row['raw_SAT_pairs']==row['proper_crossings']==70):raise ValueError('savedactual70witnessscope')
params=json.loads(Path('/workspace/shared/horse-hindgear-support-hull-candidate/source/parameters.json').read_text());route=params['hindgear_contour_study']['breeching_route_m']
def data(directory):
 meta=json.loads((directory/'horse.json').read_text());b=(directory/'horse.f64').read_bytes()
 if hashlib.sha256(b).hexdigest()!=meta['buffer_sha256']:raise ValueError('savedf64hash')
 v=np.frombuffer(b,dtype='<f8').reshape(-1,3,3);out=np.empty_like(v)
 for g in meta['meshes']:
  k=g['sourceMesh'],g['sourcePrimitive'];start=m.start[k];out[start:start+g['count']]=v[g['start']:g['start']+g['count']]
 return out,meta
idle,im=data(Path('/workspace/shared/horse-combined-oral-neck-mane-prefix-next/idle-fit/capture'));walk,wm=data(root/'idle-fit/capture');details=[];components=collections.Counter();faces=set();segments=set()
for h in row['hits']:
 g=h['horse_triangle_global'];d=m.descriptor(g);k=d['mesh'],d['primitive'];ids=m.views[k]['indices'][d['primitive_triangle']].tolist();owners=[]
 for vi in ids:
  found=[r for r in original['vertex_ranges']if r['material']==m.views[k]['base_material']and r['vertex_start']<=vi<r['vertex_start']+r['vertex_count']]
  if len(found)!=1:raise ValueError('uniqueoriginalvertexowner')
  owners.append(found[0]['original_node'])
 names=sorted(set(owners));components.update(names);faces.add(g);f=h['gear_triangle'];segment=f//8;segments.add(segment);delta=walk[g]-idle[g];details.append({**h,'horse_descriptor':d,'horse_vertex_ids':ids,'original_component_per_vertex':owners,'breeching_segment':segment,'section_face':(f%8)//2,'triangle_in_section_face':f%2,'route_centres_m':[route[segment],route[segment+1]],'actual_idle_triangle_world':idle[g].tolist(),'actual_walk_minus_idle_vertices_m':delta.tolist()})
points=np.array([h['proper']['point_m']for h in row['hits']]);dist=np.array([h['proper']['edge_signed_distances_m']for h in row['hits']]);r={'scope':'Actual saved walk0 first-failure diagnosis; no new SAT/model/capture','inputs':{'horse':hashlib.sha256(raw).hexdigest(),'gear':'fe76c95b49234da64700a1e20741b4998e8cfbae69571387d49bf5bb23ef04b1','fit_receipt':hashlib.sha256(fitpath.read_bytes()).hexdigest(),'idle_f64':im['buffer_sha256'],'walk_f64':wm['buffer_sha256']},'complete_saved_witness_count':len(details),'component_counts_per_witness':dict(components),'horse_faces':sorted(faces),'breeching_segments':sorted(segments),'witness_point_bounds_m':[points.min(0).tolist(),points.max(0).tolist()],'edge_signed_distance_bounds_m':[float(dist.min()),float(dist.max())],'signed_distance_caution':'These are witness edge endpoint distances to opposing face planes, NOT an anatomical penetration-depth measurement.','width_m':.052,'thickness_m':.007,'route_y_m':sorted({p[1]for p in route}),'details':details};(P/'ACTUAL70-OWNERSHIP.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='details'}))
