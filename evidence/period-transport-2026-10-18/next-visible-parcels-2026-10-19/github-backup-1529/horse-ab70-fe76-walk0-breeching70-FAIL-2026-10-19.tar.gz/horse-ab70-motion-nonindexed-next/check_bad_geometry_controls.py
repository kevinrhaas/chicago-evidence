# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicitly rerun existing bad actual geometry controls, no new geometry/capture."""
from pathlib import Path
import sys,json,hashlib,time,os
sys.path.insert(0,'/workspace/shared/horse-mane-fitted-next')
from mane_chain import load
from ownership import triangle_labels,PINS
from check_idle import load_capture,world_aliases,scan,write
from source_edges import owned_adjacency
from baseline_negatives import verify_negative_cohort
from check_threeway import require_parent_negative,PARENT_NEGATIVE_SHA,source_signature
from sparse_rules import require
import official_fit_predicates as predicates
P=Path(__file__).parent

def once(out):
 out=Path(out);require(not out.exists(),'exclusivecontrolresults');out.mkdir();r={'PASS':False,'scope':'Explicit re-evaluation of immutable original090/260 binary64 idle0 captures and original source signatures; not currentab70pose qualification'};start=time.monotonic()
 try:
  c=load('/workspace/shared/horse-mane-fitted-first-local-trial/payload/packet.json','5f716ee2583aad96c2e0c8c1107e91f9d4d511f717683b8274eab04d1c1dd23a');predicates.predicate_controls();r['predicate_controls']='existing seven controls executed';capture=Path('/workspace/shared/horse-mane-fitted-first-idle-trial/capture');prior=Path('/workspace/shared/horse-ear-root-first-idle-binary64-trial/results/candidate-head_vs_all_rest.json').read_bytes();require(hashlib.sha256(prior).hexdigest()==PARENT_NEGATIVE_SHA and any(source_signature(w)for w in json.loads(prior)['unexpected_witnesses']),'original260necknegativeprovenance');r['controls']={}
  for name in['baseline','ear_parent']:
   model,labels,head,owners=c[name];model.source_face_owners=owners;records=triangle_labels(model,labels);aa,bb,_=owned_adjacency(records,head,model.total,3 if name=='baseline'else 1,5 if name=='baseline'else 1);meta,data,_=load_capture(capture,name,model,PINS['baseline']if name=='baseline'else PINS['candidate']);world_aliases(records,data);results=[]
   for scope,edges in [('head_internal',aa),('head_vs_all_rest',bb)]:results.append(scan(name,scope,model,records,head,data,edges,out,False))
   if name=='baseline':
    result=verify_negative_cohort(results,Path('/workspace/shared/horse-ear-root-idle-checker-f64-unique-next/provenance'));require(result['complete'],'explicitoriginal090known12control');r['controls'][name]=result
   else:r['controls'][name]={'matched_actual_source_owned_necknegative':require_parent_negative(results)}
  r['PASS']=True
 except BaseException as e:r['error']=repr(e);raise
 finally:r['elapsed_s']=time.monotonic()-start;write(out/'RESULT.json',r)
if __name__=='__main__':once(Path(os.environ['CHICAGO_MOTION_STAGE_DIR'])/'controls')
