# SPDX-License-Identifier: GPL-3.0-or-later
"""Actual selected-pose bit/head positive distance; virtual caps are ANALYSIS ONLY."""
from pathlib import Path
import sys,json,time
import numpy as np
sys.path.insert(0,'/workspace/shared/horse-combined-oral-neck-mane-prefix-next')
from check_graft import checked
sys.path.insert(0,str(Path(__file__).parent))
from pose_contract import owned_pose,validate
from ownership import triangle_labels
from sparse_rules import require
from hybrid_geometry import SEAM
from unsigned_distance import distances
P,POSE=owned_pose()

def once():
 started=time.monotonic();r={'PASS':False,'pose':POSE,'scope':'Actualbinary64 posed completebit sides+analysisvirtualcaps vs sourceowned fullhead; caps NEVER emittedactualgeometry'}
 def save():r['elapsed_s']=time.monotonic()-started;(P/'idle-fit/actual-bit-volume-result.json').write_text(json.dumps(r,indent=2)+'\n')
 try:
  pass # actual capture validation imported from motion source
  model,labels,head,owners,scopes,raw=checked();struct=json.loads((P/'idle-fit/structural-results/RESULT.json').read_text());gearfit=json.loads((P/'idle-fit/results/actual-idle-results.json').read_text());require(struct['PASS']is True and struct['candidate_sha256']==__import__('hashlib').sha256(raw).hexdigest()and gearfit['fit_passed']is True,'precedingactualstructural/gearPASSrequired')
  def load(name):
   meta=json.loads((P/'idle-fit/capture'/f'{name}.json').read_text());b=(P/'idle-fit/capture'/f'{name}.f64').read_bytes();validate(name,meta,b);return meta,np.frombuffer(b,dtype='<f8').reshape(-1,3,3)
  hm,h=load('horse');gm,gear=load('candidate');require(hm['head_world']==gm['head_world']and hm['pose']==gm['pose'],'actualsameheadframe');data=np.empty_like(h)
  for g in hm['meshes']:
   key=g['sourceMesh'],g['sourcePrimitive'];start=model.start[key];data[start:start+g['count']]=h[g['start']:g['start']+g['count']]
  t=data[sorted(head)];part=[g for g in gm['meshes']if g['name']=='bit_bar'];require(len(part)==1 and part[0]['count']==32,'actualfull32bitsides');g=part[0];bit=gear[g['start']:g['start']+g['count']];minimum=min(float(distances(a,t).min())for a in bit);r['actual_bit_full_side_minimum_unsigned_m']=minimum;save();require(np.isfinite(minimum)and minimum>.001,'actualbit fullside1mmpositiveclearance')
  H=np.array(hm['head_world']).reshape(4,4,order='F')
  def world(p):return(H@np.r_[p,1])[:3]
  unique=np.unique(bit.reshape(-1,3),axis=0);require(len(unique)==24,'actual3rings8uniquevertices');virtual=[];usedend=set()
  for local in [[-.105,-.20,.39],[.105,-.20,.39]]:
   center=world(local);ids=np.argsort(np.linalg.norm(unique-center,axis=1))[:8];require(not(set(map(int,ids))&usedend),'disjointactualendrings');usedend.update(map(int,ids));ring=unique[ids];require(np.linalg.norm(ring.mean(0)-center)<1e-6 and np.all(abs(np.linalg.norm(ring-center,axis=1)-.006)<1e-6),'actualsourceendpointcenter6mmring');a=H[:3,1];b=H[:3,2];theta=np.arctan2((ring-center)@b,(ring-center)@a);ring=ring[np.argsort(theta)]
   for v,w in zip(ring,np.roll(ring,-1,axis=0)):virtual.append(np.array([center,v,w]))
  capmin=min(float(distances(a,t).min())for a in virtual);r['virtual_bit_endcaps']={'triangles':16,'minimum_to_head_m':capmin,'semantics':'analysis-only fulltube volume closure; noaddedactualbitfaces'};save();require(np.isfinite(capmin)and capmin>.001,'virtualbitcap1mmpositiveclearance')
  records=triangle_labels(model,labels);points={}
  for gi in head:
   for name,p in zip(records[gi],data[gi]):
    if name.startswith('h:')and int(name[2:])in SEAM:points[name]=p
  require(set(points)=={'h:'+str(v)for v in SEAM},'fullactualheadboundary28');center=np.array(list(points.values())).mean(0);cap=np.array([[center,points['h:'+str(b)],points['h:'+str(a)]]for a,b in zip(SEAM,SEAM[1:]+SEAM[:1])]);closed=np.concatenate([t,cap]);samples=np.concatenate([unique,bit.mean(1),world([0,-.205,.40])[None,:]])
  def parity(point,d):
   e1=closed[:,1]-closed[:,0];e2=closed[:,2]-closed[:,0];pv=np.cross(d,e2);det=(e1*pv).sum(1);iv=np.divide(1,det,out=np.zeros_like(det),where=abs(det)>1e-13);tv=point-closed[:,0];u=(tv*pv).sum(1)*iv;q=np.cross(tv,e1);w=q@d*iv;distance=(e2*q).sum(1)*iv;mask=(abs(det)>1e-13)&(u>=0)&(w>=0)&(u+w<=1)&(distance>1e-8)
   if np.any(mask&((u<1e-7)|(w<1e-7)|(1-u-w<1e-7))):return None
   return int(mask.sum()%2)
  outcomes=[]
  for point in samples:
   values=[parity(point,np.array(d)/np.linalg.norm(d))for d in [[1,.371,.113],[-.19,.91,.137],[.21,-.31,.93]]];valid=[x for x in values if x is not None];require(len(valid)>=2 and len(set(valid))==1,'ambiguousclosedheadclassification');outcomes.append(valid[0])
  r['virtual_closed_head_bit_samples']={'samples':len(samples),'inside_head_material':sum(outcomes),'virtual_head_cap_triangles':len(cap),'semantics':'analysis-only28boundaryhead closure, NOTactualheadfaces'};save();require(not any(outcomes),'bit samplesinside actualhead material');r['PASS']=True;save()
 except BaseException as e:r['error']=repr(e);save();raise
if __name__=='__main__':once()
