# SPDX-License-Identifier: CC0-1.0
import unittest,tempfile
from pathlib import Path
from run_stage import claim_stage
class Ownership(unittest.TestCase):
 def test_existing_stage_bytes_unchanged(self):
  with tempfile.TemporaryDirectory()as td:
   p=Path(td);d=claim_stage(p,'quarter8');f=d/'RESULT.json';f.write_bytes(b'old actual evidence\n')
   with self.assertRaises(FileExistsError):claim_stage(p,'quarter8')
   self.assertEqual(f.read_bytes(),b'old actual evidence\n');self.assertEqual(list(d.iterdir()),[f])
if __name__=='__main__':unittest.main()
