# SPDX-License-Identifier: GPL-3.0-or-later
"""ONE serial bounded stage; full63 requires complete same-source quarter8 PASS."""
from pathlib import Path
import json,hashlib,subprocess,sys,os,time,signal,argparse
from pose_contract import plans,require,INPUTS,source_expected
P=Path(__file__).parent

def claim_stage(root,stage):
 require(stage in['quarter8','full63'],'knownstage');parent=Path(root)/'runs';parent.mkdir(parents=True,exist_ok=True);out=parent/stage;out.mkdir();return out

def main(stage):
 out=claim_stage(P,stage) # Refusal BEFORE any owned try/finally: never overwrite history.
 start=time.monotonic();limit=480 if stage=='quarter8'else 2700;source_sha=None;grid=[];r={'PASS':False,'stage':stage,'planned_poses':None,'completed_poses':[],'stages':[],'source_inventory_sha256':source_sha,'input_sha256':{k:v[1]for k,v in INPUTS.items()},'total_bound_s':limit,'workers':1,'scope':'Discrete selected fit only; not continuous gait/grounding/photo/production acceptance'}
 def save():r['elapsed_s']=time.monotonic()-start;(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
 def run(name,cmd,cap,env,where,pose_start=None):
  budget=min(cap,limit-(time.monotonic()-start),90-(time.monotonic()-pose_start)if pose_start is not None else cap);require(budget>0,'stage/perposewallbound');before=time.monotonic()
  with(where/(name+'.stdout')).open('xb')as stdout,(where/(name+'.stderr')).open('xb')as stderr:
   child=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,env=env,start_new_session=True)
   try:code=child.wait(timeout=budget)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait();code=124
   except BaseException:os.killpg(child.pid,signal.SIGKILL);child.wait();raise
  r['stages'].append({'name':name,'pose':str(where.relative_to(out)),'exit':code,'elapsed_s':time.monotonic()-before});save();require(code==0,'FIRSTfailure '+name+' exit '+str(code))
 try:
  save();source_sha=hashlib.sha256((P/'SOURCE-HASHES.json').read_bytes()).hexdigest();grid=plans(stage);r.update(source_inventory_sha256=source_sha,planned_poses=len(grid));save()
  for name,want in json.loads((P/'SOURCE-HASHES.json').read_text()).items():require(hashlib.sha256((P/name).read_bytes()).hexdigest()==want,'sourcepin '+name)
  for name,want in json.loads((P/'EXTERNAL-HASHES.json').read_text()).items():require(hashlib.sha256(Path(name).read_bytes()).hexdigest()==want,'externalpin '+name)
  if stage=='full63':
   q=json.loads((P/'runs/quarter8/RESULT.json').read_text());require(q.get('PASS')is True and q.get('source_inventory_sha256')==source_sha and q.get('input_sha256')==r['input_sha256']and len(q.get('completed_poses',[]))==8,'full63requiresactualsame-sourceall8PASS');require([x['pose']for x in q['completed_poses']]==plans('quarter8')and all(x['PASS']is True for x in q['completed_poses']),'actualquarter8coverage')
   for row in q['completed_poses']:
    old=Path(P/'runs/quarter8')/f"pose-{row['pose']['index']:02d}-{row['pose']['clip']}";require(bool(row.get('artifact_hashes')),'nonemptyquarter8actualartifacts')
    for name,want in row['artifact_hashes'].items():
     f=old/name;require(not Path(name).is_absolute()and'..'not in Path(name).parts and hashlib.sha256(f.read_bytes()).hexdigest()==want,'quarter8preservedactualartifacthash')
  env={**os.environ,'CHICAGO_MOTION_STAGE_DIR':str(out)};run('explicit_original_badgeometry_controls',[sys.executable,str(P/'check_bad_geometry_controls.py')],90,env,out);control=json.loads((out/'controls/RESULT.json').read_text());require(control.get('PASS')is True,'badgeometrycontrolsPASS')
  for pose in grid:
   pose_start=time.monotonic();pd=out/f"pose-{pose['index']:02d}-{pose['clip']}";pd.mkdir();(pd/'pose.json').write_text(json.dumps(pose,sort_keys=True,indent=2)+'\n');env={**os.environ,'CHICAGO_POSE_DIR':str(pd),'CHICAGO_MOTION_STAGE_DIR':str(out)}
   for name,cmd,cap in [('capture',['node','--loader',str(P/'three-loader.mjs'),str(P/'capture_pose.mjs')],15),('structure',[sys.executable,str(P/'check_structure.py')],60),('gear36',[sys.executable,str(P/'check_gear.py')],30),('bit_volume',[sys.executable,str(P/'check_bit_volume.py')],15)]:run(name,cmd,cap,env,pd,pose_start)
   structure=json.loads((pd/'idle-fit/structural-results/RESULT.json').read_text());gear=json.loads((pd/'idle-fit/results/actual-idle-results.json').read_text());bit=json.loads((pd/'idle-fit/actual-bit-volume-result.json').read_text());candidate=[x for x in gear['rows']if x['label']=='candidate'];require(structure.get('PASS')is True and structure.get('pose')==pose and structure['candidate_sha256']==INPUTS['horse'][1]and bit.get('PASS')is True and bit.get('pose')==pose and gear.get('measurement_complete')is True and gear.get('fit_passed')is True and gear.get('pose')==pose and len(candidate)==1,'allactualposegatescomplete');parts=candidate[0]['parts'];require(len(parts)==36 and set(parts)=={g['name']for g in source_expected('candidate')}and all(type(v['raw_SAT_pairs'])is int and v['raw_SAT_pairs']==0 and type(v['proper_crossings'])is int and v['proper_crossings']==0 for v in parts.values()),'all36actualzerocollisions')
   hashes={str(f.relative_to(pd)):hashlib.sha256(f.read_bytes()).hexdigest()for f in pd.rglob('*')if f.is_file()and'__pycache__'not in f.parts};r['completed_poses'].append({'PASS':True,'pose':pose,'artifact_hashes':hashes,'elapsed_s':time.monotonic()-pose_start});save()
  require(len(r['completed_poses'])==len(grid),'fullselectedcoverage');r['PASS']=True;save();return 0
 except BaseException as e:r['error']=repr(e);save();return 2
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['quarter8','full63'],required=True);a=ap.parse_args();sys.exit(main(a.stage))
