# SPDX-License-Identifier: CC0-1.0
"""Actual decoded storage, component topology, bow envelope and seam checks."""
from pathlib import Path
import argparse,hashlib,json,struct,collections,math
import numpy as np
CHANGED={'seat_jockey','jockey_l','jockey_r','quarter_l','quarter_r'}
def need(ok,msg):
 if not ok:raise ValueError(msg)
def load(p):
 raw=p.read_bytes();need(struct.unpack_from('<III',raw)==(0x46546c67,2,len(raw)),'GLB header');n,t=struct.unpack_from('<II',raw,12);need(t==0x4e4f534a,'JSON type');size,t=struct.unpack_from('<II',raw,20+n);need(t==0x004e4942 and 28+n+size==len(raw),'BIN type/length');return json.loads(raw[20:20+n]),raw[28+n:],raw
def array(d,b,i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];need('byteStride'not in v and'sparse'not in a,'Plain accessor');dtype={5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']];c={'SCALAR':1,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];return np.frombuffer(b,dtype=dtype,count=a['count']*c,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,c)
def topology(P,F):
 need(len(P)>0 and len(F)>0 and int(F.min())>=0 and int(F.max())<len(P),'Component bounds');edges=collections.defaultdict(list);adj=collections.defaultdict(set)
 for f in F:
  need(len(set(f))==3,'Repeated triangle ID')
  for u,v in zip(f,np.roll(f,-1)):u=int(u);v=int(v);edges[tuple(sorted((u,v)))].append((u,v));adj[u].add(v);adj[v].add(u)
 need(all(len(e)==2 and e[0]==e[1][::-1]for e in edges.values()),'Closed opposite edges');seen=set();todo=[0]
 while todo:
  i=todo.pop()
  if i in seen:continue
  seen.add(i);todo.extend(adj[i]-seen)
 need(len(seen)==len(P) and len(P)-len(edges)+len(F)==2,'Connected Euler2');A=P[F];cross=np.cross(A[:,1]-A[:,0],A[:,2]-A[:,0]);area=np.linalg.norm(cross,axis=1)/2;need(float(area.min())>1e-11,'Actual nondegenerate triangle');volume=float(np.einsum('ij,ij->i',A[:,0],np.cross(A[:,1],A[:,2])).sum()/6);need(volume>0,'Actual outward volume');return {'vertices':len(P),'triangles':len(F),'minimum_area_m2':float(area.min()),'volume_m3':volume,'Euler':2}
def check(oldpath,newpath,params,out):
 out.mkdir();r={'passed':False,'scope':'Actual storage/component/bow envelope/shared-seam only; no horsefit/pressure/rider/period/photo acceptance'}
 try:
  old,ob,raw=load(oldpath);d,b,nraw=load(newpath);p=json.loads(params.read_text());need(hashlib.sha256(raw).hexdigest()=='a457874a81b624f5e9642d3296b1350eb49b17d21d38099fbe66080711c17021','A457 pin');r['candidate_sha256']=hashlib.sha256(nraw).hexdigest();r['parameters_sha256']=hashlib.sha256(params.read_bytes()).hexdigest();need(b[:len(ob)]==ob,'Old BIN prefix');need(d['accessors'][:len(old['accessors'])]==old['accessors']and d['bufferViews'][:len(old['bufferViews'])]==old['bufferViews'],'Old storage refs');need(len(d['meshes'])==len(old['meshes'])==29,'Exact29mesh cohort')
  for k in ['nodes','skins','animations','materials','scenes','scene']:need(old.get(k)==d.get(k),'Protected '+k)
  parts={};total=0;protected=[];rows={}
  for om,nm in zip(old['meshes'],d['meshes']):
   name=om['name'];need(nm['name']==name,'Name/order')
   for pr in nm['primitives']:total+=(len(array(d,b,pr['indices']))if'indices'in pr else len(array(d,b,pr['attributes']['POSITION'])))//3
   if name not in CHANGED:need(om==nm,'Protected mesh '+name);protected.append(name);continue
   need(len(nm['primitives'])==1,'Single changed primitive');pr=nm['primitives'][0];need(set(pr['attributes'])=={'POSITION','NORMAL'}and pr['material']==om['primitives'][0]['material'],'Rigid material/attributes');P=array(d,b,pr['attributes']['POSITION']).astype(float);N=array(d,b,pr['attributes']['NORMAL']).astype(float);F=array(d,b,pr['indices']).reshape(-1,3);need(np.isfinite(P).all()and np.isfinite(N).all(),'Finite geometry');need(np.max(abs(np.linalg.norm(N,axis=1)-1))<1e-6,'Unit normals');parts[name]=(P,F)
   if name=='seat_jockey':
    need(P.shape==(1082,3)and F.shape==(2152,3),'Three authored seatbatch components');specs=[('seat',0,1026,0,2048),('front_bow_leather_envelope',1026,28,2048,52),('rear_bow_leather_envelope',1054,28,2100,52)];rows[name]=[]
    for label,vo,vn,fo,fn in specs:rows[name].append({'component':label,**topology(P[vo:vo+vn],F[fo:fo+fn]-vo)})
   else:need(P.shape==((306,3)if name.startswith('jockey')else(850,3)),'Actual source lattice');rows[name]=topology(P,F)
  need(len(protected)==24 and total==10548,'Actual protected/count contracts');r['active_triangles']=total;r['primitive_batches']=29;r['protected_meshes']=protected;r['components']=rows;r['seams']={}
  for side,sign in [('l',1),('r',-1)]:
   J=parts['jockey_'+side][0];Q=parts['quarter_'+side][0];outer=J[np.arange(17)*9+8];expected=outer+np.array([sign*math.cos(p['quarter_top_angle_rad']),math.sin(p['quarter_top_angle_rad']),0])*p['seam_overlap_m'];errors=np.linalg.norm(Q[:17]-expected,axis=1);need(float(errors.max())<=2e-7,'Actual shared seam float32 registration');r['seams'][side]={'stations':17,'maximum_float32_registration_error_m':float(errors.max()),'lap_m':p['seam_overlap_m'],'scope':'Registered outer overlap, not solidcloth/pressure certificate'}
  r['bow_envelopes']={}
  for name,start in [('front_bow',1026),('rear_bow',1054)]:
   om=next(m for m in old['meshes']if m['name']==name);pr=om['primitives'][0];need('indices'not in pr,'Original expanded bow');P=array(old,ob,pr['attributes']['POSITION']).astype(float);faces=[]
   for j in range(6):
    for k in range(4):a=j*4+k;c=j*4+(k+1)%4;faces.extend([(a,c,c+4),(a,c+4,a+4)])
   faces.extend([(0,2,1),(0,3,2),(24,25,26),(24,26,27)]);need(len(P)==156,'Exact bow expanded length');aliases={}
   for i,q in zip([i for f in faces for i in f],P):
    if i in aliases:need(np.array_equal(aliases[i],q),'Actual source ring alias')
    aliases[i]=q
   expect=[];centers=np.array([[aliases[j*4+k]for k in range(4)]for j in range(7)]).mean(axis=1)
   for j in range(7):
    C=np.array([aliases[j*4+k]for k in range(4)]);u=C[1]-C[0];v=C[3]-C[0];w=np.linalg.norm(u);t=np.linalg.norm(v);need(abs(w-.04)<1e-6 and abs(t-.025)<1e-6,'Source cross-section');u/=w;v/=t;need(abs(np.dot(u,v))<1e-6,'Source section frame')
    shift=np.zeros(3)
    if j in (0,6):
     other=1 if j==0 else 5;direction=centers[j]-centers[other];direction/=np.linalg.norm(direction);shift=direction*p['bow_end_overhang_m']
    for k,(sw,st)in enumerate([(-1,-1),(1,-1),(1,1),(-1,1)]):expect.append(C[k]+p['bow_outer_envelope_standoff_m']*(sw*u+st*v)+shift)
   actual=parts['seat_jockey'][0][start:start+28];err=float(np.linalg.norm(actual-np.array(expect),axis=1).max());need(err<=2e-7,'Actual cover envelope/source binding');r['bow_envelopes'][name]={'maximum_float32_corner_error_m':err,'stand_off_m':p['bow_outer_envelope_standoff_m'],'end_overhang_m':p['bow_end_overhang_m'],'corners':28,'wood_exact':True,'outer_envelope_not_leather_solid':True}
  r['passed']=True
 except BaseException as e:r['error']=repr(e);raise
 finally:(out/'readback.json').write_text(json.dumps(r,indent=2)+'\n')
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('old',type=Path);a.add_argument('new',type=Path);a.add_argument('parameters',type=Path);a.add_argument('out',type=Path);o=a.parse_args();check(o.old,o.new,o.parameters,o.out)
