# SPDX-License-Identifier: CC0-1.0
"""DRAFT ONLY: source-owned bow envelopes and joined shorter upper leathers.
No file IO/model evaluation occurs at import. Not built, fit or visual accepted.
"""
import math
from base_surfaces import finish,shell,seat_height,halfwidth

def bow_envelope(expanded_positions,offset_m=.003,end_overhang_m=.003):
 """Exact authored52-triangle/7-ring strap order; never nearest-point matching.
 Outer render envelope of wood + declared stand-off, NOT solid leather pressure.
 Caller must bind protected actual bow mesh/source hash before invoking.
 """
 N=7;faces=[]
 for j in range(N-1):
  for k in range(4):a=j*4+k;b=j*4+(k+1)%4;c=b+4;e=a+4;faces.extend([(a,b,c),(a,c,e)])
 faces.extend([(0,2,1),(0,3,2)]);k=(N-1)*4;faces.extend([(k,k+1,k+2),(k,k+2,k+3)])
 if len(expanded_positions)!=len(faces)*3:raise ValueError('Expected exact original bow expanded stream')
 rings={}
 for face,row in zip([i for f in faces for i in f],expanded_positions):
  q=tuple(row)
  if face in rings and rings[face]!=q:raise ValueError('Authored ring alias mismatch')
  rings[face]=q
 def unit(q):
  n=math.sqrt(math.fsum(x*x for x in q))
  if n<1e-9:raise ValueError('Degenerate actual bow section')
  return [x/n for x in q],n
 if not math.isfinite(offset_m)or not 0<offset_m<.01:raise ValueError('Bounded original envelope stand-off')
 if not math.isfinite(end_overhang_m)or not 0<end_overhang_m<.01:raise ValueError('Positive bounded longitudinal end cover')
 centers=[[math.fsum(rings[j*4+k][i]for k in range(4))/4 for i in range(3)]for j in range(N)]
 outer=[]
 for j in range(N):
  q=[rings[j*4+k]for k in range(4)];u,w=unit([q[1][i]-q[0][i]for i in range(3)]);v,t=unit([q[3][i]-q[0][i]for i in range(3)])
  if abs(w-.040)>1e-6 or abs(t-.025)>1e-6 or abs(math.fsum(u[i]*v[i]for i in range(3)))>1e-6:raise ValueError('Actual pinned bow section dimensions/frame')
  shift=[0.,0.,0.]
  if j in (0,N-1):
   other=1 if j==0 else N-2;tangent,_=unit([centers[j][i]-centers[other][i]for i in range(3)]);shift=[end_overhang_m*x for x in tangent]
  for k,(sw,st)in enumerate([(-1,-1),(1,-1),(1,1),(-1,1)]):outer.append([q[k][i]+offset_m*(sw*u[i]+st*v[i])+shift[i]for i in range(3)])
 return finish(outer,faces)

def seam(z,sign,p,top):
 z0,z1=p['jockey_z_range_m'];t=(z-z0)/(z1-z0);s0,s1=p['seat_z_range_m'];zc=(s0+s1)/2;zh=(s1-s0)/2;u=(z-zc)/zh;inner=halfwidth(z,p)*max(0.,1-u*u)**(p['plan_exponent']/2);outer=p['short_jockey_outer_x_m']-.008*abs(2*t-1)**4
 if outer<=inner+.008:raise ValueError('Short jockey authored width')
 start=seat_height(z,p)+p['cross_rise_m']*(inner/p['waist_halfwidth_m'])**2-p['edge_roll_m']-.004;end=top(sign*outer,z)+p['short_jockey_offset_m']+p['jockey_corner_lift_m']*abs(2*t-1)**4
 return inner,outer,start,end

def jockey(sign,p,top):
 a=[];b=[];N=p['jockey_length_segments']+1;M=p['jockey_width_segments']+1;z0,z1=p['jockey_z_range_m']
 for j in range(N):
  z=z0+(z1-z0)*j/(N-1);inner,outer,start,end=seam(z,sign,p,top)
  for k in range(M):
   t=k/(M-1);x=sign*(inner+(outer-inner)*t);y=max(start*(1-t)+end*t,top(x,z)+p['jockey_min_body_gap_m']);a.append([x,y,z]);b.append([x,y-p['leather_thickness_m'],z])
 return shell(a,b,N,M)

def quarter(sign,p,ray,top):
 a=[];b=[];N=p['quarter_vertical_segments']+1;M=p['quarter_length_segments']+1;
 if p['quarter_length_segments']!=p['jockey_length_segments']:raise ValueError('Shared seam station count required')
 z0,z1=p['jockey_z_range_m'];topcenter=(z0+z1)/2;tophalf=(z1-z0)/2
 for j in range(N):
  t=j/(N-1);half=tophalf*(1-t)+p['quarter_halfwidth_bottom_m']*t;center=topcenter*(1-t)+p['quarter_center_z_m']*t
  for k in range(M):
   u=2*k/(M-1)-1;z=center+half*u;seamz=z0+(z1-z0)*k/(M-1);_,outer,_,end=seam(seamz,sign,p,top);start=[sign*outer,end,seamz];angle=p['quarter_top_angle_rad']*(1-t)+p['quarter_bottom_angle_rad']*t+p['quarter_corner_lift_rad']*t**3*u*u;direction=[sign*math.cos(angle),math.sin(angle),0];r=ray([0,p['quarter_ray_height_m'],z],direction);target=[(r+p['quarter_offset_m'])*direction[0],p['quarter_ray_height_m']+(r+p['quarter_offset_m'])*direction[1],z];q=min(1.,t/p['quarter_join_fraction']);q=q*q*(3-2*q);v=[start[i]*(1-q)+target[i]*q for i in range(3)];v[0]+=direction[0]*p['seam_overlap_m']*(1-q);v[1]+=direction[1]*p['seam_overlap_m']*(1-q);a.append(v);b.append([v[0]-direction[0]*p['leather_thickness_m'],v[1]-direction[1]*p['leather_thickness_m'],v[2]])
 return shell(a,b,N,M)
