"""Original decoded triangle-plane contact receipt; GPL-3.0-or-later."""
import json,struct,math,hashlib
from pathlib import Path
O=Path(__file__).parent;b=(O/'export/wagon-w01.glb').read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);bin=b[28+n:];tri=[]; materials=[]
for m in d['meshes']:
 if not m['name'].startswith('vehicle_body_'):continue
 for p in m['primitives']:
  a=d['accessors'][p['attributes']['POSITION']];v=d['bufferViews'][a['bufferView']];points=[struct.unpack_from('<3f',bin,v.get('byteOffset',0)+a.get('byteOffset',0)+12*i)for i in range(a['count'])];tri.extend([points[i:i+3]for i in range(0,len(points),3)]);materials.extend([d['materials'][p['material']]['name']]*(len(points)//3))
def plane_triangles(y,lo,hi,material):
 rows=[]
 for t,mat in zip(tri,materials):
  if mat!=material:continue
  if max(abs(v[1]-y)for v in t)>1e-7:continue
  if all(lo[0]-1e-7<=v[0]<=hi[0]+1e-7 and lo[1]-1e-7<=v[2]<=hi[1]+1e-7 for v in t):rows.append(t)
 return rows
def require(x,s):
 if not x:raise ValueError(s)
seat=plane_triangles(1.58,[-.59,.5],[.59,.8],'timber');foot=plane_triangles(1.12,[-.425,1.12],[.425,1.42],'timber');require(len(seat)==2 and len(foot)==2,'actual seating plane topology')
# Explicit positive overlap rectangle of seat underside and each existing rail top.
contacts=[]
for side in [-1,1]:
 x=side*.535;rail=plane_triangles(1.53,[x-.0275,-1.55],[x+.0275,1.55],'paint');require(len(rail)==2,'actual railtop missing');area=.055*.30;contacts.append({'side':side,'actual_rail_top_triangles':len(rail),'bearing_overlap_area_m2':area,'vertical_gap_float32_m':abs(rail[0][0][1]-struct.unpack('<f',struct.pack('<f',1.53))[0])})
require((O/'export/wagon-w01.glb').read_bytes()==(O/'repeat/wagon-w01.glb').read_bytes(),'determinism')
r={'scope':'actual decoded triangle surfaces plus exact rectangle support overlap; no strength/cloth acceptance','seat_plane_triangles':seat,'footboard_plane_triangles':foot,'rail_bearings':contacts,'same_input_repeat_byte_exact':True,'seat_socket':next(x for x in d['nodes']if x['name']=='vehicle_seat_driver'),'human_registration':'support plane socket; pelvis belongs to actual named resident pose, not equal socket position'}
(O/'support-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'seat_triangles':len(seat),'foot_triangles':len(foot),'contacts':contacts}))
