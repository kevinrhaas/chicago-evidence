# Original provisional 1812 clothed authoring input

This parcel supplies actual portable garment arrays on the separately prepared age49 body. It changes no app file and does not register, export, place or render a person. The preceding identity/body archive stays immutable, and the 1835 builder is unchanged.

Selected identity is John Kinzie the elder, inferred on 1812-08-14 from existing historical text and the house already in the scene. Age is 48–49 from birth year1763;49 and1.75m remain original body-authoring choices. No face, physique, historical outfit, action or likeness is attested by this clothing. Existing identity and full source reasoning remain in the previous archive.

## Actual produced construction

`garments1812.py` consumes only the pinned actual age49 prepared body SHA `8dfb1a536eac2e505c5192093fb63ec03906d464ff3321380c862543d668570e`. Original clipping, body-surface normal offsets and ease produce four components: plain shirt, open-front waistcoat, trousers and low shoes. Actual output contains19,881 triangles and59,643 per-triangle vertices. Portable influence interpolation is normalized and pruned to four influences; maximum new pruned fraction is3.241%, explicitly reported for later deformation review. UVs derive from the cleared body atlas and have no accepted textile scale or seam layout.

Every cut, ease value, colour, material pairing, front opening, footwear choice and omitted closure is **conjectural**. The existing1812 dossier provides a provisional plain civilian clothing family, not a source-matched cut. No historical garment image/object/pattern was newly acquired or traced; `garment_sources` is empty. The regional Bradbury hunting coat belonged to a different traveler, so no hunting coat is assigned to Kinzie. No hat, buttons, fall-front flap or closure is modeled. The earlier recipe's proposed fall-front requirement remains unfulfilled and cannot be counted as accepted by this simple front-envelope trouser study.

The geometry is body-derived shells, **not sewn tailoring**. Clipped trim edges are open/unhemmed. No garment thickness, seam continuity, collision, cloth physics, smooth-boundary quality, fitting, seated/walk deformation or photographic appearance has passed. The waistcoat front/armhole clipping and trouser lower-torso front envelope may fold or intersect. The shoe shell has no proven sole, upper construction or closure. Per-triangle vertices preserve construction simplicity but are unoptimized; source-body UV seams and facet normals require actual BPy/export review.

## Explicit guarded BPy seam

`clothed_authoring_adapter.create_clothed_study` requires the exact named1812 unaccepted standing/walking authoring context, actual body hash, full original body skeleton/portable parents, CC0/metre/Y-up/+Z frame and explicit conjectural garment metadata. Before BPy, it validates all finite arrays, indices and normalized skin weights and invokes the immutable prior body adapter's identity/date/body validation. The prior adapter refuses a nonempty scene; this creates only an isolated authoring collection. Clothing uses that same freshly constructed rig, avoiding a names-only attachment to an unrelated rig.

The adapter has no automatic CLI, registration or scene path. It creates provisional flat original materials; no cloth/skin/hair textures or photographic shader are supplied. BPy has not been installed, imported or executed. Bone roll, normal transfer, modifier behavior, materials and export remain unverified. No animation, canonical master, fourLODs, GLB or eligible actor exists from this parcel. An integrator must assign a real LIBERTIES entry before app integration, then run ordinary source/master/export/LOD/visual/scene-date gates.

## Actual checks

Stored arrays pass full finite positions/UVs, index bounds, positive triangle-area checks, normalized at-most-four portable influences, exact body skeleton/parent correspondence and explicit identity/date/conjecture metadata. Eleven planted faults are refused, including wrong era/person, invented source claim, appearance upgrade, production flag, driver role, changed body bytes, bad parent, nonfinite coordinates, invalid influence and implicit scene caller before BPy. This verifies the authoring interface only. All fit/appearance/production gates remain open.

Reproduce into a fresh output directory without Blender or network:

```
PYTHONDONTWRITEBYTECODE=1 python /workspace/shared/period-1812-clothed-source-next/garments1812.py --output NEW_DIRECTORY
PYTHONDONTWRITEBYTECODE=1 python /workspace/shared/period-1812-clothed-source-next/check_arrays.py
```

The latter checks the supplied actual-one arrays and writes its source-check receipt. No regeneration is needed for independent review.

Original Python code: GPL-3.0-or-later. Original generated garment arrays: CC0-1.0, derived from the cleared CC0 prepared body/graphical inputs already documented by the previous immutable source archive. No unknown-rights image-derived assets are used.
