# SPDX-License-Identifier: GPL-3.0-or-later
"""Actual prepared arrays plus refusal checks; no BPy or new geometry generation."""
from pathlib import Path
import copy
import hashlib
import json
import math
import sys
from clothed_authoring_adapter import validate, create_clothed_study

ROOT = Path("/workspace/chicago/chicago/4d")
BASE = Path(__file__).parent
OUTPUT = Path("/workspace/shared/period-1812-clothed-actual-one/kinzie1812.garments.json")
BODY = Path("/workspace/shared/period-1812-kinzie-next/kinzie_age49.body.json")


def main():
    garment = json.loads(OUTPUT.read_bytes())
    body = BODY.read_bytes()
    contract = json.loads((ROOT/"data/humans/contract.json").read_text())
    context = {"person_reference_id": "kinzie_john_elder", "scene_date": "1812-08-14",
               "identity_grade": "inferred", "appearance_grade": "reconstructed",
               "roles": ["standing", "walking"], "authoring_only": True,
               "production_eligible": False}
    validate(garment, body, contract, context)
    rows = []
    for mesh in garment["meshes"]:
        minimum = math.inf
        for triangle in mesh["triangles"]:
            a, b, c = [mesh["positions_m"][i] for i in triangle]
            u, v = [b[k]-a[k] for k in range(3)], [c[k]-a[k] for k in range(3)]
            cross = [u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0]]
            area = math.fsum(x*x for x in cross)
            assert area > 1e-20
            minimum = min(minimum, area)
        rows.append({"name": mesh["name"], "vertices": len(mesh["positions_m"]),
                     "triangles": len(mesh["triangles"]), "minimum_squared_double_area_m4": minimum,
                     "maximum_new_influence_pruning": mesh["max_interpolated_influence_pruning"]})
    refused = []
    def refuse(name, change=None, actor=None, actual_body=body):
        data = copy.deepcopy(garment)
        if change:
            change(data)
        try:
            validate(data, actual_body, contract, actor or context)
        except (ValueError, KeyError):
            refused.append(name)
        else:
            raise AssertionError("Accepted planted fault: " + name)
    refuse("wrong era", lambda g: g.update(scene_date="1835-07-01"))
    refuse("wrong person", lambda g: g.update(person_reference_id="kinzie_john_h"))
    refuse("source-matched clothing claim", lambda g: g.update(garment_sources=["invented"]))
    refuse("photographic appearance upgrade", lambda g: g.update(appearance_grade="attested"))
    refuse("production eligibility", lambda g: g.update(production_eligible=True))
    refuse("driver role", actor={**context, "roles": ["driver"]})
    refuse("wrong actual body", actual_body=body+b" ")
    refuse("bad parent", lambda g: g["skeleton"][1].update(parent="head"))
    refuse("nonfinite vertex", lambda g: g["meshes"][0]["positions_m"][0].__setitem__(0, math.nan))
    refuse("bad influence", lambda g: g["meshes"][0]["weights"][0].update(invented_joint=1.))
    try:
        create_clothed_study(ROOT, garment, body, contract,
                             actor_context={**context, "authoring_only": False})
    except ValueError:
        refused.append("implicit scene caller before BPy")
    else:
        raise AssertionError("Implicit authoring call accepted")
    assert "bpy" not in sys.modules
    result = {"PASS": True, "scope": "Actual stored source/garment arrays and eleven refusal controls only",
              "body_sha256": hashlib.sha256(body).hexdigest(),
              "garment_sha256": hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
              "components": rows, "refused": refused, "bpy_executed": False,
              "collision_or_deformation_accepted": False, "ready_for_scene": False}
    (BASE/"ARRAY-CHECKS.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
