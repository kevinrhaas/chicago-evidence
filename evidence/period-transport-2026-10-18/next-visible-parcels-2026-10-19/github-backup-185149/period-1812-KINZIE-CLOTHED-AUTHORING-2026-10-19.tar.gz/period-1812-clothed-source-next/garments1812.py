# SPDX-License-Identifier: GPL-3.0-or-later
"""Original provisional body-derived 1812 clothing arrays, never a sewn pattern.

Cloth cuts, ease, closures, palette and every measured dimension below are
conjectural. No historical garment pixels or pattern have been used. The
body-derived surfaces are a practical authoring starting point, not accepted
tailoring, collision fit, deformation, normal fields or photographic people.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math

DATE = "1812-08-14"
BODY_SHA = "8dfb1a536eac2e505c5192093fb63ec03906d464ff3321380c862543d668570e"
BODY = Path("/workspace/shared/period-1812-kinzie-next/kinzie_age49.body.json")


def require(value, message):
    if not value:
        raise ValueError(message)


def mix(a, b, t):
    return [x + (y - x) * t for x, y in zip(a, b)]


def interpolate(a, b, t):
    weights = {name: (1-t)*a["w"].get(name, 0) + t*b["w"].get(name, 0)
               for name in set(a["w"]) | set(b["w"])}
    return {"p": mix(a["p"], b["p"], t), "uv": mix(a["uv"], b["uv"], t),
            "n": mix(a["n"], b["n"], t), "w": weights}


def clip(polygon, field):
    """Sutherland-Hodgman with linear field interpolation on each triangle."""
    result = []
    for a, b in zip(polygon, polygon[1:] + polygon[:1]):
        x, y = field(a), field(b)
        if x >= 0:
            result.append(a)
        if (x >= 0) != (y >= 0):
            result.append(interpolate(a, b, x/(x-y)))
    return result


def cross(a, b):
    return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]


def normal_fields(source):
    """Share body source-vertex normals across UV splits without welding UVs."""
    normals = {}
    ids = source["source_vertex_indices"]
    positions = source["positions_m"]
    for tri in source["triangles"]:
        a, b, c = [positions[i] for i in tri]
        n = cross([b[k]-a[k] for k in range(3)], [c[k]-a[k] for k in range(3)])
        for i in tri:
            sid = ids[i]
            value = normals.setdefault(sid, [0., 0., 0.])
            for k in range(3):
                value[k] += n[k]
    return [normals[sid] for sid in ids]


def normalized_weights(weights):
    chosen = sorted(((k, v) for k, v in weights.items() if v > 1e-12),
                    key=lambda item: (-item[1], item[0]))[:4]
    total = math.fsum(v for _, v in chosen)
    require(total > 0, "No valid portable skin influences")
    return {k: v/total for k, v in chosen}


def garment(source, normals, name, material, fields, offset, lower_front=False):
    positions, triangles, uvs, weights = [], [], [], []
    pruning = 0.
    for face in source["triangles"]:
        polygon = [{"p": source["positions_m"][i], "uv": source["uvs"][i],
                    "w": source["weights"][i], "n": normals[i]} for i in face]
        for field in fields:
            polygon = clip(polygon, field)
            if len(polygon) < 3:
                break
        if len(polygon) < 3:
            continue
        for j in range(1, len(polygon)-1):
            rows = [polygon[0], polygon[j], polygon[j+1]]
            points = []
            for row in rows:
                n = row["n"]
                length = math.sqrt(math.fsum(x*x for x in n))
                require(length > 1e-15, "Degenerate source-derived normal")
                p = [v + offset*d/length for v, d in zip(row["p"], n)]
                # Explicit original ease, not historical pattern or cloth physics.
                if abs(p[0]) > .015:
                    p[0] += math.copysign(.006, p[0])
                # Suppress skin-tight lower-torso anatomy in the trouser study.
                # This unmeasured front envelope is not a tailored fall-front cut.
                if lower_front and .67 < p[1] < 1.06 and p[2] > 0:
                    p[2] = max(p[2], .105)
                points.append(p)
            area = cross([points[1][k]-points[0][k] for k in range(3)],
                         [points[2][k]-points[0][k] for k in range(3)])
            if math.fsum(x*x for x in area) <= 1e-20:
                continue
            first = len(positions)
            for row, p in zip(rows, points):
                selected = normalized_weights(row["w"])
                pruning = max(pruning, 1 - math.fsum(row["w"].get(k, 0) for k in selected))
                positions.append(p)
                uvs.append(row["uv"])
                weights.append(selected)
            triangles.append([first, first+1, first+2])
    require(triangles, "Empty garment component")
    return {"name": name, "material": material, "positions_m": positions,
            "triangles": triangles, "uvs": uvs, "weights": weights,
            "max_interpolated_influence_pruning": max(0, pruning),
            "construction": "Original clipped body-surface shell with reconstructed ease; open edges, not a sewn pattern"}


def produce(body_bytes):
    require(hashlib.sha256(body_bytes).hexdigest() == BODY_SHA,
            "Only the reviewed age49 actual body may drive these cuts")
    body = json.loads(body_bytes)
    bones = {b["name"]: b for b in body["skeleton"]}
    height = body["report"]["chosen_height_m"]
    require(body["target_blend"]["phenotype"]["chosen_age_years"] == 49 and
            len(bones) == 56 and body["license"] == "CC0-1.0" and
            body["units"] == "m" and body["up_axis"] == "+Y" and
            body["forward_axis"] == "+Z", "Wrong mature portable body")
    waist = height*.598
    hem = height*.548
    neck = bones["neck_01"]["head_m"][1] - .025
    cuffs = abs(bones["hand_l"]["head_m"][0]) - .020
    ankle = bones["foot_l"]["head_m"][1] + .047
    shoulder = bones["upperarm_l"]["head_m"][1] + .025
    source = body["meshes"][0]
    normals = normal_fields(source)
    shirt = garment(source, normals, "plain_shirt_conjectural_cut", "plain_linen_conjectural",
                    [lambda r: r["p"][1]-hem, lambda r: neck-r["p"][1],
                     lambda r: cuffs-r["p"][0], lambda r: cuffs+r["p"][0]], .014)
    arm_names = {name for name in bones if name.startswith(("clavicle", "upperarm", "lowerarm", "hand"))}
    def v_opening(r):
        if r["p"][2] < .012:
            return 1.
        width = max(.015, .105*(r["p"][1]-waist)/max(.01, shoulder-waist))
        return abs(r["p"][0])-width
    waistcoat = garment(source, normals, "plain_waistcoat_conjectural_open_front", "plain_wool_dark_conjectural",
                        [lambda r: r["p"][1]-(waist-.055), lambda r: shoulder-r["p"][1],
                         lambda r: .12-math.fsum(r["w"].get(k, 0) for k in arm_names),
                         v_opening], .025)
    trousers = garment(source, normals, "plain_trousers_conjectural_front_envelope", "plain_wool_trousers_conjectural",
                       [lambda r: waist-r["p"][1], lambda r: r["p"][1]-ankle], .021, True)
    shoes = garment(source, normals, "plain_low_shoes_conjectural", "plain_leather_conjectural",
                    [lambda r: ankle+.012-r["p"][1]], .008)
    return {"format": "chicago4d_prepared_garment_study_v1", "license": "CC0-1.0",
            "units": "m", "up_axis": "+Y", "forward_axis": "+Z",
            "scene_date": DATE, "person_reference_id": "kinzie_john_elder",
            "identity_grade": "inferred", "appearance_grade": "reconstructed",
            "garment_geometry_grade": "conjectural", "action_grade": "reconstructed",
            "allowed_study_roles": ["standing", "walking"], "registered": False,
            "production_eligible": False, "ready_for_scene": False,
            "body_input_sha256": BODY_SHA, "skeleton": body["skeleton"],
            "meshes": [shirt, waistcoat, trousers, shoes],
            "materials": {"plain_linen_conjectural": [.64,.58,.46,1],
                          "plain_wool_dark_conjectural": [.13,.12,.10,1],
                          "plain_wool_trousers_conjectural": [.19,.17,.13,1],
                          "plain_leather_conjectural": [.045,.032,.023,1]},
            "garment_sources": [],
            "period_basis": "Previously recorded original plain civilian1812 wardrobe proposal; no dated garment cut/object or named outfit has been visually verified",
            "dimensions": {"waist_m": waist, "shirt_hem_m": hem, "neck_cut_m": neck,
                           "cuff_halfspan_m": cuffs, "ankle_cut_m": ankle,
                           "basis": "All original unmeasured engineering fit choices"},
            "limitations": ["Body-derived shells retain anatomy and source-body UVs; no sewn pattern, cloth weave or textile-scale claim",
                            "Open neck/cuffs/armholes/hem/waist/ankles are not hemmed and trim boundaries may show angular cuts",
                            "Waistcoat front/armhole clipping and lower-torso trouser front envelope may fold or self-intersect; no collision accepted",
                            "No historical front-fall closure has been constructed; closures/buttons/hat/hunting coat omitted",
                            "No textures, skin/hair, canonical master, fourLODs, GLB, animation, image or scene placement",
                            "All colour, material pairing, cut, ease and footwear are conjectural; no photographic or named clothing claim"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    data = produce(BODY.read_bytes())
    (args.output/"kinzie1812.garments.json").write_text(json.dumps(data, separators=(",", ":"))+"\n")
    print(json.dumps({"components": len(data["meshes"]),
                      "triangles": sum(len(m["triangles"]) for m in data["meshes"]),
                      "ready_for_scene": False}))


if __name__ == "__main__":
    main()
