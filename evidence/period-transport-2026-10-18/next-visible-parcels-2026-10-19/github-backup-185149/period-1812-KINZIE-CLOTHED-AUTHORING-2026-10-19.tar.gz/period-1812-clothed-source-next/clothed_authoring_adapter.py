# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicit isolated clothed1812 study seam; BPy execution is unverified."""
from pathlib import Path
import hashlib
import importlib.util
import json
import math

PERSON = "kinzie_john_elder"
DATE = "1812-08-14"
BASE = Path("/workspace/shared/period-1812-kinzie-next")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def validate(garment, body_bytes, contract, actor_context):
    require(actor_context == {"person_reference_id": PERSON, "scene_date": DATE,
                              "identity_grade": "inferred", "appearance_grade": "reconstructed",
                              "roles": ["standing", "walking"], "authoring_only": True,
                              "production_eligible": False},
            "Only the explicit unregistered1812 named standing/walking study is allowed")
    require(garment.get("person_reference_id") == PERSON and
            garment.get("scene_date") == DATE and garment.get("identity_grade") == "inferred" and
            garment.get("appearance_grade") == "reconstructed" and
            garment.get("garment_geometry_grade") == "conjectural" and
            garment.get("ready_for_scene") is False and garment.get("registered") is False and
            garment.get("production_eligible") is False and garment.get("garment_sources") == [],
            "Identity/period/conjectural garment limits must remain explicit")
    require(garment.get("body_input_sha256") == hashlib.sha256(body_bytes).hexdigest(),
            "Actual garment/body bytes differ")
    body = json.loads(body_bytes)
    for value in [garment, body]:
        require(value.get("license") == "CC0-1.0" and value.get("units") == "m" and
                value.get("up_axis") == "+Y" and value.get("forward_axis") == "+Z",
                "CC0 metre/Y-up/+Z graphical inputs required")
    parents = dict(contract["skeleton"]["bones"])
    require(garment["skeleton"] == body["skeleton"] and len(garment["skeleton"]) == 56 and
            {b["name"]: b["parent"] for b in garment["skeleton"]} == parents,
            "Actual body skeleton and portable parents must remain exact")
    require(body["target_blend"]["phenotype"]["chosen_age_years"] == 49,
            "Separate mature body required")
    require([m["name"] for m in garment["meshes"]] ==
            ["plain_shirt_conjectural_cut", "plain_waistcoat_conjectural_open_front",
             "plain_trousers_conjectural_front_envelope", "plain_low_shoes_conjectural"],
            "Only reviewed provisional garment components are allowed")
    for mesh in garment["meshes"]:
        count = len(mesh["positions_m"])
        require(count and count == len(mesh["uvs"]) == len(mesh["weights"]),
                "Incomplete garment arrays")
        require(all(len(p) == 3 and all(math.isfinite(x) for x in p)
                    for p in mesh["positions_m"]), "Invalid garment coordinates")
        require(all(len(uv) == 2 and all(math.isfinite(x) for x in uv)
                    for uv in mesh["uvs"]), "Invalid garment UVs")
        require(mesh["material"] in garment["materials"], "Missing material specification")
        for triangle in mesh["triangles"]:
            require(len(triangle) == len(set(triangle)) == 3 and
                    all(type(i) is int and 0 <= i < count for i in triangle),
                    "Invalid garment triangle")
        for weights in mesh["weights"]:
            require(1 <= len(weights) <= 4 and not(set(weights) - set(parents)) and
                    all(math.isfinite(w) and w > 0 for w in weights.values()) and
                    abs(math.fsum(weights.values())-1) < 1e-8,
                    "Invalid garment skin influences")
    return body


def create_clothed_study(root, garment, body_bytes, contract, *, actor_context):
    """Build only in the empty authoring scene enforced by the body adapter.

    No animation, export, LOD, scene registration, placement or photo acceptance.
    The root caller must qualify actual BPy creation and every emitted result.
    """
    validate(garment, body_bytes, contract, actor_context)
    # The reviewed prior body adapter remains immutable; verify before import.
    pinned = json.loads((Path(__file__).parent/"EXTERNAL-HASHES.json").read_text())
    path = BASE/"body_authoring_adapter.py"
    require(hashlib.sha256(path.read_bytes()).hexdigest() == pinned[str(path)],
            "Changed standalone body authoring adapter")
    spec = importlib.util.spec_from_file_location("period1812_body_authoring", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.validate(root, BASE, body_bytes)
    study = module.create_body_study(root, BASE, body_bytes, caller_authoring_only=True,
                                     name="kinzie_elder_1812_unaccepted_clothed_study")
    import bpy
    materials = {}
    for name, color in garment["materials"].items():
        material = bpy.data.materials.new(name)
        material.use_nodes = True
        shader = material.node_tree.nodes.get("Principled BSDF")
        shader.inputs["Base Color"].default_value = color
        shader.inputs["Roughness"].default_value = .85
        material["historical_status"] = "Entirely conjectural palette/material pairing; no sampled textile"
        materials[name] = material
    for source in garment["meshes"]:
        mesh = bpy.data.meshes.new(source["name"])
        mesh.from_pydata([(p[0], -p[2], p[1]) for p in source["positions_m"]], [], source["triangles"])
        mesh.update()
        uv = mesh.uv_layers.new(name="UVMap")
        for poly in mesh.polygons:
            poly.use_smooth = True
            for loop in poly.loop_indices:
                uv.data[loop].uv = source["uvs"][mesh.loops[loop].vertex_index]
        obj = bpy.data.objects.new(source["name"], mesh)
        study["collection"].objects.link(obj)
        mesh.materials.append(materials[source["material"]])
        for name, _ in contract["skeleton"]["bones"]:
            obj.vertex_groups.new(name=name)
        for i, weights in enumerate(source["weights"]):
            for name, weight in weights.items():
                obj.vertex_groups[name].add([i], weight, "REPLACE")
        obj.modifiers.new("skin", "ARMATURE").object = study["rig"]
        obj["garment_geometry_grade"] = "conjectural"
        obj["production_eligible"] = False
        obj["scope"] = "Unaccepted original body-derived garment shell; no sewn pattern or fit qualification"
        study["objects"].append(obj)
    study["collection"]["ready_for_scene"] = False
    return study
