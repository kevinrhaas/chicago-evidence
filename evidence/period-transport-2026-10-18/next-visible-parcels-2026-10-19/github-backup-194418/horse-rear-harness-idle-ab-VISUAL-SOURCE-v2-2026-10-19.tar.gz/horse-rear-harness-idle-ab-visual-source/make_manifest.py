from pathlib import Path
import json,hashlib,struct
P=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
paths={'horse':'/workspace/shared/horse-combined-oral-neck-mane-prefix-next/candidate-one/candidate.glb','baseline':'/workspace/shared/horse-breeching-swept-route-next/candidate-one/light_breastcollar_harness_reconstructed_01.glb','fitted':'/workspace/shared/horse-rear-harness-current-support-actual-idle-v5-one/candidate/candidate.glb'}
def component(path):
 b=Path(path).read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);binary=b[28+n:];rows=[]
 for mi,m in enumerate(d['meshes']):
  for pi,p in enumerate(m['primitives']):
   a=d['accessors'][p['attributes']['POSITION']];indexed='indices'in p
   if indexed:
    ac=d['accessors'][p['indices']];v=d['bufferViews'][ac['bufferView']];fmt={5121:'B',5123:'H',5125:'I'}[ac['componentType']];step=struct.calcsize(fmt);assert v.get('byteStride',step)==step
    ix=struct.unpack_from('<'+fmt*ac['count'],binary,v.get('byteOffset',0)+ac.get('byteOffset',0))
   else:ix=range(a['count'])
   rows.append(dict(name=m['name'],sourceMesh=mi,sourcePrimitive=pi,positionCount=a['count'],indexCount=len(ix),indexed=indexed,indexStreamSHA256=sha(struct.pack('<'+'I'*len(ix),*ix))))
 return dict(path=path,sha256=sha(b),primitives=rows)
S='/workspace/shared/horse-rear-harness-current-support-source/'
A='/workspace/shared/horse-rear-harness-current-support-actual-idle-v5-one/'
evidence={'sidecar':A+'candidate/SIDECAR.json','serialized':A+'candidate/SERIALIZED-CHECK.json','operator':A+'OPERATOR.json','storedReview':'/workspace/shared/horse-current-support-v5-period1904-stored-evidence-review.json'}
d=dict(study_id='rear-harness-idle-ab-v1',scope='Actual qualified idle0 only; visual comparison; no motion, forces, complete hitch, or photographic acceptance',qualifiedSourceInventorySHA256=sha(Path(S+'SOURCE-INVENTORY.json').read_bytes()),components={k:component(p)for k,p in paths.items()},evidence={k:dict(path=p,sha256=sha(Path(p).read_bytes()))for k,p in evidence.items()},qualifiedSource=S,vendor='/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1',viewports=[dict(width=1280,height=800),dict(width=390,height=780)],views=['side','rear'])
(P/'study.json').write_text(json.dumps(d,indent=2)+'\n')
