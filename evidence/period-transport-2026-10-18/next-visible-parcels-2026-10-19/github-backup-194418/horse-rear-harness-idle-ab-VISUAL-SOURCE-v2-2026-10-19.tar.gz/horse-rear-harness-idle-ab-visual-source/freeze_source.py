from pathlib import Path
import hashlib,json
P=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((P/'study.json').read_text());external={}
V=Path(d['vendor'])
# Pin the entire small vendored JS module dependency closure, not an import alias.
for p in V.rglob('*.js'):external[str(p)]=sha(p)
for c in list(d['components'].values())+list(d['evidence'].values()):external[c['path']]=sha(Path(c['path']))
for n in ['controller.mjs','evaluate.mjs','SOURCE-INVENTORY.json']:
 p=Path(d['qualifiedSource'])/n;external[str(p)]=sha(p)
(P/'EXTERNAL-HASHES.json').write_text(json.dumps(external,indent=2,sort_keys=True)+'\n')
files={p.name:sha(p)for p in sorted(P.iterdir())if p.is_file()and p.name!='SOURCE-HASHES.json'}
(P/'SOURCE-HASHES.json').write_text(json.dumps(files,indent=2,sort_keys=True)+'\n')
print(json.dumps({'sourceInventorySHA256':sha(P/'SOURCE-HASHES.json'),'owned':len(files),'external':len(external)}))
