# SPDX-License-Identifier: GPL-3.0-or-later
"""Decode immutable stored798e GLB/index/owner/capture only. No evaluator imports."""
from pathlib import Path
import json,hashlib,sys
import numpy as np
DATA=Path('/workspace/shared/horse-neutral-rail-closed-producer-next')
HELP=Path('/workspace/shared/horse-neck-hybrid-pipeline-next')
CANDIDATE='798e864bd34dd52de5fa5e19acbb3a08ae6bcc5c5731a44820671871219e699b'
sys.path.insert(0,str(HELP))
from ownership import Model,triangle_labels
from sparse_rules import require
from source_edges import edge_table
from check_idle import scan,write,world_aliases

def checked():
 raw=(DATA/'candidate-one/candidate.glb').read_bytes();require(hashlib.sha256(raw).hexdigest()==CANDIDATE,'Immutable798e model hash');rb=json.loads((DATA/'candidate-one/readback.json').read_text());require(rb['PASS']is True and rb['candidate_sha256']==CANDIDATE,'Frozen decoded-source readback identity');model=Model(raw);labels={(r['mesh'],r['vertex']):r['label']for r in rb['source_labels']};owners={int(k):v for k,v in rb['source_face_owners'].items()};model.source_face_owners=owners;graft=json.loads(Path('/workspace/shared/horse-combined-oral-neck-mane-prefix-next/candidate-one/graft-proof.json').read_text());oldhead=set(graft['head_faces']);remap={int(k):int(v)for k,v in rb['old_to_new'].items()};head={v for k,v in remap.items()if k in oldhead}|{i for i,o in owners.items()if o['kind']=='conforming_mouth'};proof=json.loads((DATA/'candidate-one/proof.json').read_text());require(proof['candidate_sha256']==CANDIDATE,'Stored producer proof identity');posterior={int(k)for k in proof['detail']['preserved110_posterior']};require(len(posterior)==110,'Exact stored110posterior');scopes={'lips':{remap[i]for i in posterior}|{i for i,o in owners.items()if o['kind']=='conforming_mouth'},'hybrid':{i for i,o in owners.items()if o['kind']=='hybrid_neck'},'mane':{i for i,o in owners.items()if o['kind']=='fitted_mane'}};require(model.total==15068 and len(owners)==15068 and len(head)==4964 and len(scopes['lips'])==2176 and len(scopes['hybrid'])==1492 and len(scopes['mane'])==456,'Complete immutable source-owned cohorts');return model,labels,head,owners,scopes,raw

def capture_data(model,labels):
 # The original validator reads exact original data paths and source indices.
 sys.path.insert(0,str(DATA/'idle-fit'));from validate_capture import validate
 meta=json.loads((DATA/'idle-fit/capture/horse.json').read_text());buf=(DATA/'idle-fit/capture/horse.f64').read_bytes();validate('horse',meta,buf);captured=np.frombuffer(buf,dtype='<f8').reshape(-1,3,3);data=np.empty_like(captured);seen=set()
 for g in meta['meshes']:
  key=g['sourceMesh'],g['sourcePrimitive'];require(key in model.views and key not in seen and g['count']==len(model.views[key]['indices']),'Actual source capture primitive/index association');seen.add(key);data[model.start[key]:model.start[key]+g['count']]=captured[g['start']:g['start']+g['count']]
 require(seen==set(model.views),'ALL actual immutable primitives');records=triangle_labels(model,labels);aliases=world_aliases(records,data);return records,data,aliases
