# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import sys,json,hashlib
from stored_input import checked,capture_data,CANDIDATE,scan,write,require
from selected_edges import selected_edges
from prior_receipts import prior
import official_fit_predicates as predicates
OUT=Path(sys.argv[1]);SCOPES=OUT/'mouth-scopes';SCOPES.mkdir()
model,labels,head,owners,scopes,raw=checked();records,data,aliases=capture_data(model,labels);old=prior();aa,bb=selected_edges(records,scopes['lips'],1120,-1,66,3231);predicates.predicate_controls();new=[]
for scope,edges in[('head_internal',aa),('head_vs_all_rest',bb)]:
 result=scan('immutable_mouth2176',scope,model,records,scopes['lips'],data,edges,SCOPES,True,declared_scope='FULL immutable mouth2176 internal'if scope=='head_internal'else'FULL immutable mouth2176 vsALL15068remaininghorse');require(result['complete']and result['completed_head_triangle_prefix']==2176 and result['counts']['strict_proper']==0 and result['counts']['unexpected_SAT']==0,'First failure actual mouth '+scope);path=SCOPES/('immutable_mouth2176-'+scope+'.json');new.append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'complete':True,'counts':result['counts']})
require(prior()==old,'Original six receipt hashes stable after mouth check');write(OUT/'STRUCTURAL-AGGREGATE.json',{'PASS':True,'candidate_sha256':CANDIDATE,'scope':'EIGHT full structural scopes for SAME immutable798e;6prior+2fresh mouth. This is combined bounded evidence, NOT original75s structural caller or150s wholeoperator PASS.','old_operator_remains_FAILED':True,'prior_six':old,'new_mouth_two':new,'source_aliases':aliases,'geometry_evaluated_or_captured':False})
