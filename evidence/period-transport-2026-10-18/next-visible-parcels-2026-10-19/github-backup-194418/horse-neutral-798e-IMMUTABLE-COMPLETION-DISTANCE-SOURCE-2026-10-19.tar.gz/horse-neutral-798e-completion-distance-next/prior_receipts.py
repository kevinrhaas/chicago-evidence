# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import json,hashlib
from stored_input import DATA,CANDIDATE
from sparse_rules import require
SIX=[('conforming_head4964-head_internal.json',4964),('conforming_head4964-head_vs_all_rest.json',4964),('hybrid1492-head_internal.json',1492),('hybrid1492-head_vs_all_rest.json',1492),('fittedmane456-head_internal.json',456),('fittedmane456-head_vs_all_rest.json',456)]
def prior():
 rows=[];old=json.loads((DATA/'operator-receipt.json').read_text());require(old['PASS']is False and old['phase']=='full_structural'and old['stages'][-1]['exit']==124,'Original timeout must remain FAILED/incomplete');r=json.loads((DATA/'idle-fit/structural-results/RESULT.json').read_text());require(r['PASS']is False and r['candidate_sha256']==CANDIDATE,'Original incomplete structural identity')
 for name,n in SIX:
  p=DATA/'idle-fit/structural-results'/name;b=p.read_bytes();d=json.loads(b);c=d['counts'];require(d['complete']is True and d['completed_head_triangle_prefix']==n and c['strict_proper']==0 and c['unexpected_SAT']==0 and c['uncertified_source_edge_pairs']==0,'Complete exact original scope:'+name);require(d['SAT_epsilon_unchanged']==1e-8 and d['point_certificate_tolerance']is None,'Unchanged actual predicates');require(len(d['accepted_point_certificates'])==c['proven_source_vertex_only']==c['raw_SAT']and len(d['actual_source_edge_certificates'])==c['source_edge_wholepairs_certified']and d['unexpected_witnesses']==[],'Full stored contact/certificate receipt');rows.append({'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'complete':True,'head_prefix':n,'counts':c})
 return rows
