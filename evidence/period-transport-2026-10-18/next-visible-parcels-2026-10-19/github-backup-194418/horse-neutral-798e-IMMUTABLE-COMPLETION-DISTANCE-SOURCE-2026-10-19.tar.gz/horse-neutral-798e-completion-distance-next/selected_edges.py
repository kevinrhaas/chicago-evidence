# SPDX-License-Identifier: GPL-3.0-or-later
# Exact original actual topology guard; no numeric/source changes.
from source_edges import edge_table
from sparse_rules import require
def selected_edges(records,selected,expected_v,expected_euler,boundary_count,internal_count):
 edges=edge_table(records,selected);vertices={v for i in selected for v in records[i]};boundary={e for e,u in edges.items()if len(u)==1};require(len(vertices)==expected_v and len(vertices)-len(edges)+len(selected)==expected_euler and len(boundary)==boundary_count,'complete scoped topology');alluses=edge_table(records,set(range(len(records))));internal=set();external=set();neighbors={v:set()for v in vertices}
 for(a,b),u in edges.items():
  neighbors[a].add(b);neighbors[b].add(a)
  full=alluses[a,b];require(len(full)==2 and full[0][1:]==full[1][1:][::-1],'unique opposite actualsourceedgeowners');pair=tuple(sorted(x[0]for x in full));(internal if all(x[0]in selected for x in full)else external).add(pair)
 seen=set();todo=[next(iter(vertices))]
 while todo:
  v=todo.pop()
  if v in seen:continue
  seen.add(v);todo.extend(neighbors[v]-seen)
 require(seen==vertices and len(internal)==internal_count and len(external)==boundary_count,'fullconnectedscopedsourceadjacency');return internal,external
