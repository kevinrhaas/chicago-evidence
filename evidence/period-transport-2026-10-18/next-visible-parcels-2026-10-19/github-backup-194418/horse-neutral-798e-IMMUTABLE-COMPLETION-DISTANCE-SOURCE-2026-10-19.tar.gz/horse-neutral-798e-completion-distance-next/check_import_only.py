# SPDX-License-Identifier: CC0-1.0
"""Availability only: import exact distance definitions, invoke NO geometry query."""
from pathlib import Path
import sys,json,hashlib
P=Path(__file__).parent
sys.path.insert(0,'/workspace/shared/horse-neck-hybrid-pipeline-next')
import unsigned_distance
wanted=P/'unsigned_distance.py';actual=Path(unsigned_distance.__file__)
if actual.resolve()!=wanted.resolve():raise ValueError('Distance dependency resolved outside exact completion source')
sha=hashlib.sha256(actual.read_bytes()).hexdigest()
if sha!='c4650c9fd557c4a1f97a5ac505775698710047e6744e4936aa307793efe058b7':raise ValueError('Distance helper byte mismatch')
for name in['pts_tri','segments','distances']:
 if not callable(getattr(unsigned_distance,name,None)):raise ValueError('Missing distance definition:'+name)
forbidden={'conforming_variant','checked_conforming','closed_fields','lip_variant','graft','quality_variant'}
if forbidden.intersection(sys.modules):raise ValueError('Forbidden horse evaluator loaded by distance import')
print(json.dumps({'PASS_IMPORT_ONLY':True,'helper':str(actual),'sha256':sha,'functions_defined':['pts_tri','segments','distances'],'geometry_queries_invoked':False,'horse_model_evaluator_capture_browser_invoked':False,'forbidden_horse_modules_loaded':[]},indent=2))
