# SPDX-License-Identifier: GPL-3.0-or-later
"""One root-released immutable-data completion. NO producer/evaluator/capture."""
from pathlib import Path
import sys,os,signal,time,json,hashlib,subprocess
P=Path(__file__).parent
START=time.monotonic()
def require(v,msg):
 if not v:raise ValueError(msg)
def main():
 require(len(sys.argv)==3 and sys.argv[1]=='ROOT_RELEASE_ONE_IMMUTABLE_798E_COMPLETION','Root release and fresh exclusive output required');out=Path(sys.argv[2]);out.mkdir();r={'complete':False,'original_operator_PASS':False,'scope':'Combined bounded immutable798e idle engineering evidence ONLY:6original completed scopes+2fresh mouth+all36gear+bit. Never original150swholeoperator PASS; no photo/motion/pressure acceptance.','bound_s':150,'stages':[],'phase':'source_pins','cpu_affinity':sorted(os.sched_getaffinity(0)),'math_threads':{k:os.environ.get(k)for k in['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']}}
 def save():r['elapsed_s']=time.monotonic()-START;(out/'COMPLETION-RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
 def pins():
  d=json.loads((P/'PINS.json').read_text())
  for f,w in d.items():
   require(hashlib.sha256(Path(f).read_bytes()).hexdigest()==w,'Frozen source/actualinput changed:'+f);require(time.monotonic()-START<150,'150s total completion bound during pins')
  return {'count':len(d),'manifest_sha256':hashlib.sha256((P/'PINS.json').read_bytes()).hexdigest(),'all_exact':True}
 save()
 try:
  require(r['cpu_affinity']==[0]and all(v=='1'for v in r['math_threads'].values()),'Exactly CPU0 and one math thread required');r['before_pins']=pins();from prior_receipts import prior
  before=prior();r['before_six']=before;save()
  for name,script,cap in[('full_mouth_two','check_mouth.py',75),('all36gear','check_gear.py',90),('actual_bit_volume','check_bit.py',30)]:
   remain=min(cap,150-(time.monotonic()-START));require(remain>0,'150s total completion bound');r['phase']=name;save()
   with(out/(name+'.stdout')).open('xb')as stdout,(out/(name+'.stderr')).open('xb')as stderr:
    child=subprocess.Popen([sys.executable,str(P/script),str(out)],stdout=stdout,stderr=stderr,start_new_session=True)
    try:code=child.wait(timeout=remain)
    except BaseException as exc:
     try:os.killpg(child.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     child.wait()
     if isinstance(exc,subprocess.TimeoutExpired):code=124
     else:raise
   r['stages'].append({'name':name,'exit':code,'elapsed_s':time.monotonic()-START});save();require(code==0,'FIRSTFAIL immutable completion '+name+' exit'+str(code))
  r['phase']='final_frozen_aggregate';r['after_pins']=pins();require(r['after_pins']==r['before_pins'],'Frozen manifest identity changed during completion');after=prior();require(after==before,'Prior six exact receipts changed');r['after_six']=after;struct=json.loads((out/'STRUCTURAL-AGGREGATE.json').read_text());gear=json.loads((out/'gear-results/actual-idle-results.json').read_text());bit=json.loads((out/'actual-bit-volume-result.json').read_text());require(struct['PASS']is True and struct['candidate_sha256']=='798e864bd34dd52de5fa5e19acbb3a08ae6bcc5c5731a44820671871219e699b'and len(struct['prior_six'])==6 and len(struct['new_mouth_two'])==2,'Eight exact complete scope aggregate');require(gear['measurement_complete']is True and gear['fit_passed']is True,'Complete actual gear fit');candidate=[x for x in gear['rows']if x['label']=='candidate'];baseline=[x for x in gear['rows']if x['label']=='baseline'];require(len(candidate)==1 and len(candidate[0]['parts'])==36 and candidate[0]['raw_SAT_pairs']==candidate[0]['proper_crossings']==0,'All36gear actual0/0');require(len(baseline)==1 and baseline[0]['raw_SAT_pairs']>0 and baseline[0]['proper_crossings']>0,'Old078 actual negative preserved');require(bit['PASS']is True,'Actual fullside/cap/volume bitPASS');require(time.monotonic()-START<150,'150s total completion bound');r.update(complete=True,candidate_sha256=struct['candidate_sha256'],structural_scope_count=8,gear_parts=36,actual_bit_PASS=True,scope_note='Immutable evidence combined across separately bounded runs; original fc87ba timeout remains FAILED and unchanged')
 except BaseException as e:r['error']=repr(e)
 finally:save()
 return 0 if r['complete']else 2
if __name__=='__main__':raise SystemExit(main())
