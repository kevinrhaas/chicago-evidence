# SPDX-License-Identifier: CC0-1.0
"""Exact rational scalar partition controls only; no rail/horse evaluation."""
from pathlib import Path
from fractions import Fraction as Q
import ast,json
p=Path(__file__).parent/'closed_fields.py';tree=ast.parse(p.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in['require','convex_coefficients']];ns={'Q':Q};exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'<exact-scalar-partition>','exec'),ns)
def check(x):
 if not x:raise ValueError('Scalar control failed')
for t in[Q(1,4),Q(1,2),Q(3,4)]:
 c=ns['convex_coefficients'](t);check(all(v>0 for v in c));check(sum(c)==1);check(c[2]+c[3]<=Q(1,10))
check(ns['convex_coefficients'](Q(1,2))==[Q(9,20),Q(9,20),Q(1,20),Q(1,20)])
for t in[Q(-1),Q(0),Q(1),Q(2)]:
 try:ns['convex_coefficients'](t)
 except ValueError:pass
 else:raise ValueError('Invalid source ring accepted')
check(set(ns)-{'Q','__builtins__'}=={'require','convex_coefficients'})
print(json.dumps({'PASS':True,'controls':15,'scope':'Pure rational scalar positivity/partition/refusal only; no new horse P/JW/rail evaluation'}))
