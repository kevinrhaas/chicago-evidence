# SPDX-License-Identifier: GPL-3.0-or-later
"""Complete source-owned actual idle0 head/hybrid/mane internal and vs ALL."""
from pathlib import Path
import sys,json,hashlib,time,signal
import numpy as np
from checked_conforming import checked
from ownership import triangle_labels
from source_edges import owned_adjacency,edge_table
from check_idle import scan,write,world_aliases
from hybrid_geometry import SEAM
from sparse_rules import require
import official_fit_predicates as predicates
P=Path(__file__).parent;OUT=P/'idle-fit/structural-results'

def selected_edges(records,selected,expected_v,expected_euler,boundary_count,internal_count):
 edges=edge_table(records,selected);vertices={v for i in selected for v in records[i]};boundary={e for e,u in edges.items()if len(u)==1};require(len(vertices)==expected_v and len(vertices)-len(edges)+len(selected)==expected_euler and len(boundary)==boundary_count,'complete scoped topology');alluses=edge_table(records,set(range(len(records))));internal=set();external=set();neighbors={v:set()for v in vertices}
 for(a,b),u in edges.items():
  neighbors[a].add(b);neighbors[b].add(a)
  full=alluses[a,b];require(len(full)==2 and full[0][1:]==full[1][1:][::-1],'unique opposite actualsourceedgeowners');pair=tuple(sorted(x[0]for x in full));(internal if all(x[0]in selected for x in full)else external).add(pair)
 seen=set();todo=[next(iter(vertices))]
 while todo:
  v=todo.pop()
  if v in seen:continue
  seen.add(v);todo.extend(neighbors[v]-seen)
 require(seen==vertices and len(internal)==internal_count and len(external)==boundary_count,'fullconnectedscopedsourceadjacency');return internal,external

def once():
 require(not OUT.exists(),'exclusive structural output');OUT.mkdir();r={'PASS':False,'scope':'ONE actualbinary64 idle0 fullhead4964/hybrid1492/mane456 eachinternal/vsALL; no63pose/photo acceptance'};started=time.monotonic()
 def save():r['elapsed_s']=time.monotonic()-started;write(OUT/'RESULT.json',r)
 try:
  model,labels,head,owners,scopes,raw=checked();sys.path.insert(0,str(P/'idle-fit'));from validate_capture import validate
  meta=json.loads((P/'idle-fit/capture/horse.json').read_text());buf=(P/'idle-fit/capture/horse.f64').read_bytes();validate('horse',meta,buf);captured=np.frombuffer(buf,dtype='<f8').reshape(-1,3,3);require(np.isfinite(captured).all(),'actualfiniteworld');data=np.empty_like(captured);seen=set()
  for g in meta['meshes']:
   key=g['sourceMesh'],g['sourcePrimitive'];require(key in model.views and key not in seen,'unique actualassociation');seen.add(key);start=model.start[key];count=len(model.views[key]['indices']);require(g['count']==count,'actualprimitivecount');data[start:start+count]=captured[g['start']:g['start']+count]
  require(seen==set(model.views),'ALLactualprimitives');records=triangle_labels(model,labels);aliases=world_aliases(records,data);ha,hb,ht=owned_adjacency(records,head,model.total,1,-1,boundary_loop=['h:'+str(x)for x in SEAM]);na,nb=selected_edges(records,scopes['hybrid'],772,0,52,2212);ma,mb=selected_edges(records,scopes['mane'],230,2,0,684);la,lb=selected_edges(records,scopes['lips'],1120,-1,66,3231);predicates.predicate_controls();r['candidate_sha256']=hashlib.sha256(raw).hexdigest();r['source_aliases_verified']=aliases;r['head_topology']=ht;save()
  for label,selected,aa,bb in [('conforming_head4964',head,ha,hb),('hybrid1492',scopes['hybrid'],na,nb),('fittedmane456',scopes['mane'],ma,mb),('conformingmouth2176',scopes['lips'],la,lb)]:
   for scope,edges in [('head_internal',aa),('head_vs_all_rest',bb)]:
    result=scan(label,scope,model,records,selected,data,edges,OUT,True,declared_scope='FULLsourcecohort internal'if scope=='head_internal'else'FULLsourcecohort versus ALLremainingactivehorse');require(result['complete']and result['counts']['unexpected_SAT']==0 and result['counts']['strict_proper']==0,'actual scoped collision STOP '+label+' '+scope)
  r['PASS']=True;save();return True
 except BaseException as e:r['error']=repr(e);save();raise
if __name__=='__main__':once()
