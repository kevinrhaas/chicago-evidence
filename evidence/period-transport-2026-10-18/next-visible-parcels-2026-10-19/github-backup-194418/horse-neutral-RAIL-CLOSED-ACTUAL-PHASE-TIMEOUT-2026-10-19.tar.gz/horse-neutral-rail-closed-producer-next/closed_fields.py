# SPDX-License-Identifier: GPL-3.0-or-later
"""Source-rail constrained fixed tissue field definitions; no invocation/import IO.
No free XYZ curve/offset. All new P is a positive partition of declared rails.
"""
from fractions import Fraction as Q
import bisect
import numpy as np
from lip_variant import weights

def require(value,message):
 if not value:raise ValueError(message)
def convex_coefficients(t):
 require(0<t<1,'Interior source ring fraction');d=Q(1,10)*(4*t*(1-t))**4
 return[(1-d)*(1-t),(1-d)*t,d*(1-t),d*t]
def extend(old_resolve,ctx,bindings,sourceproof):
 A=ctx['assembly'];table={k:{Q(q):tag for q,tag in v['by_phase'].items()}for k,v in A['source_ring_parameters'].items()};cache={}
 def rail(side,q):
  rows=table[side];keys=sorted(rows)
  if q in rows:
   sourceproof['seal_rail:'+side+':'+str(q)]={'source_alias':rows[q],'fraction':'0'}
   return old_resolve(rows[q])
  i=bisect.bisect_left(keys,q);require(0<i<len(keys),'Declared nonwrapped rail interpolation');a,b=keys[i-1],keys[i];fraction=(q-a)/(b-a);sourceproof['seal_rail:'+side+':'+str(q)]={'source_aliases':[rows[a],rows[b]],'fraction':str(fraction)};t=float(fraction);va,vb=old_resolve(rows[a]),old_resolve(rows[b]);J,W=weights([(1-t,va[1],va[2]),(t,vb[1],vb[2])]);return(1-t)*va[0]+t*vb[0],J,W,None
 def resolve(tag):
  if not tag.startswith('seal:'):return old_resolve(tag)
  if tag in cache:return cache[tag]
  _,row,phase=tag.split(':');r=int(row);q=Q(phase);require(r in[1,2,3],'Exactly three declared tissue rings');t=Q(r,4)
  if 0<=q<=1:
   qi=Q(21,10)-q;values=[rail('upper',q),rail('lower',q),rail('upper',qi),rail('lower',qi)];coeff=convex_coefficients(t);region='outer_lip_with_source_bounded_recess';refs=['seal_rail:upper:'+str(q),'seal_rail:lower:'+str(q),'seal_rail:upper:'+str(qi),'seal_rail:lower:'+str(qi)]
  else:
   require(Q(11,10)<=q<=Q(21,10),'Declared inner U, no invented corner nodes');values=[rail('upper',q),rail('lower',q)];coeff=[1-t,t];region='actual_inner_labial_wall';refs=['seal_rail:upper:'+str(q),'seal_rail:lower:'+str(q)]
  require(all(a>0 for a in coeff)and sum(coeff)==1,'Positive exact source partition');pos=sum((float(a)*v[0]for a,v in zip(coeff,values)),np.zeros(3));J,W=weights([(float(a),v[1],v[2])for a,v in zip(coeff,values)]);require(np.isfinite(pos).all()and abs(sum(W)-1)<2e-6 and all(w>=0 for w in W),'Finite normalized source tissue field');value=(pos,J,W,None);cache[tag]=value;sourceproof[tag]={'region':region,'fixed_ring':r,'phase':str(q),'source_rail_receipts':refs,'positive_exact_coefficients':[str(a)for a in coeff],'field':'ONLY convex source-rail P and JW; no free XYZ curve or displacement','neutral_apposed_lip_approximation':True};return value
 return resolve,bindings,sourceproof
