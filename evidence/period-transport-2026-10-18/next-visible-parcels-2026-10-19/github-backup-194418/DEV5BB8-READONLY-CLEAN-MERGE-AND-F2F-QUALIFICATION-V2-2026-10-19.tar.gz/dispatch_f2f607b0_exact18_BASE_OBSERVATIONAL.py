#!/usr/bin/env python3
"""Once-only exactremote/object-bound18 smoke dispatch. No request without --execute."""
import argparse,datetime,hashlib,importlib.util,json,pathlib,subprocess,time,sys
S=pathlib.Path('/workspace/shared');R=pathlib.Path('/workspace/chicago');M=S/'f2f607b0-exact18-qualification-MANIFEST.json';V=S/'verify_normal_dev_gates_v8_aedc80126.py';VHASH='87ad8568b3e4704a125122160f68d6686b5a7f51facdb71a8e50aca8cbc0b5e9'
def need(c,m):
 if not c:raise ValueError(m)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
MANIFEST_SHA256='c142a323864ecc9d77bbf2a313b4d75cb4201b7267690a401eb5d3b4662e73a6'
def load_manifest():
 need(hashlib.sha256(M.read_bytes()).hexdigest()==MANIFEST_SHA256,'Reviewed manifest bytes changed');m=json.loads(M.read_text());need(m['sha']=='f2f607b0b6a82e9973c260d55c57fc4b661fb0b4'and m['tree']=='955d48d151c6a00e87a5d636f07a0dfcf5de505a'and m['base_sha']=='0d739a9ecc08b18d5e8f3e3dc700a83343cc4aba','Manifest identity changed');need(m['repository']=='kevinrhaas/chicago'and m['branch']=='steward/period-transport-2793'and m['workflow']=='chicago-4d-smoke.yml','Manifest route changed');need(set(m['viewports'])=={'desktop','mobile'}and m['ranges']==['1-2','3-4','5','6-7','8','9-12','13','14','15'],'Manifest grid changed');need(m['observer']=={'max_seconds':10800,'poll_seconds':60,'api_timeout_seconds':45,'retry':False},'Observer limits changed');return m
def cells(m):
 grid=[(v,s)for v in m['viewports']for s in m['ranges']];priority=[tuple(x)for x in m['priority']];ordered=priority+[x for x in grid if x not in priority];need(len(ordered)==len(set(ordered))==18 and set(ordered)==set(grid),'Exactly18 unique complete cells required');return ordered
def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');x=a.parse_args();m=load_manifest();grid=cells(m)
 if not x.execute:print(json.dumps({'execute':False,'manifest':str(M),'manifest_sha256':hashlib.sha256(M.read_bytes()).hexdigest(),'cells':grid,'known_normal_runs':m['known_normal_runs'],'scope':m['scope']},indent=2));return 0
 need(hashlib.sha256(V.read_bytes()).hexdigest()==VHASH,'Source-contract helper changed');sp=importlib.util.spec_from_file_location('v8',V);v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
 def git(*aa):return subprocess.check_output(['git','-C',str(R),*aa])
 need(git('rev-parse',m['sha']+'^{commit}').decode().strip()==m['sha']and git('rev-parse',m['sha']+'^{tree}').decode().strip()==m['tree'],'Exact committed source/tree unavailable');v.source_ok({p:git('show',m['sha']+':'+p)for p in v.PINS})
 prior_path=S/'f2f607b0-exact18-dispatch/receipt.json';prior=json.loads(prior_path.read_text());need(prior.get('source_sha256')=='9cc1911b6a9b629a44872cfa80127474fc168ae48424fa6b76493458c95d1518'and prior.get('sha')==m['sha']and prior.get('dispatches')==[]and prior.get('discovered_runs')==[]and prior.get('error')=='Dev/PRbase drift'and bool(prior.get('finished_utc')),'Prior reviewed caller must be proven finished with zero POST attempts');out=S/'f2f607b0-exact18-dispatch-v2';out.mkdir(exist_ok=False);(S/'f2f607b0-exact18-dispatch-v2.once-lock').mkdir(exist_ok=False);deadline=time.monotonic()+180;counter=0
 receipt={'repository':m['repository'],'branch':m['branch'],'sha':m['sha'],'tree':m['tree'],'workflow':m['workflow'],'manifest_sha256':hashlib.sha256(M.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'previous_zero_post_receipt_sha256':hashlib.sha256(prior_path.read_bytes()).hexdigest(),'started_utc':now(),'dispatches':[],'discovered_runs':[],'coverage_status':'UNPROVEN until actual qualification; no run-to-input pairing inferred','no_retry':True}
 def checkpoint():save(out/'receipt.json',receipt)
 def api(name,endpoint,body=None):
  nonlocal counter
  remaining=deadline-time.monotonic();need(remaining>0,'180s caller deadline; no further request');counter+=1;method='GET'if body is None else'POST';cmd=['gh','api','--hostname','github.com','--method',method,'repos/'+m['repository']+'/'+endpoint]
  if body is not None:cmd+=['--input','-']
  save(out/(str(counter).zfill(3)+'-'+name+'.request.json'),{'at':now(),'method':method,'endpoint':endpoint,'body':body})
  r=subprocess.run(cmd,input=None if body is None else json.dumps(body),capture_output=True,text=True,timeout=min(45,remaining));(out/(str(counter).zfill(3)+'-'+name+'.stdout.json')).write_text(r.stdout);(out/(str(counter).zfill(3)+'-'+name+'.stderr.txt')).write_text(r.stderr);need(r.returncode==0,name+' API failure/ambiguity; no retry');return json.loads(r.stdout)if r.stdout.strip()else None
 def head():return api('branch','git/ref/heads/'+m['branch'])['object']['sha']
 listing='actions/workflows/'+m['workflow']+'/runs?head_sha='+m['sha']+'&per_page=100'
 try:
  need(head()==m['sha'],'Remote branch drift');commit=api('commit','git/commits/'+m['sha']);dev=api('dev','git/ref/heads/dev');pr=api('pr','pulls/1041');before=api('runs-before',listing)
  need(commit['sha']==m['sha']and commit['tree']['sha']==m['tree'],'Remote tree drift');receipt['dev_snapshot']={'actual_dev':dev['object']['sha'],'pr_base_metadata':pr['base']['sha'],'mergeable':pr.get('mergeable'),'mergeable_state':pr.get('mergeable_state'),'scope':'Observed integration state only; dev advancement does not change frozen branch qualification'};need(pr['state']=='open'and pr['head']['sha']==m['sha']and pr['head']['ref']==m['branch']and pr['head']['repo']['full_name']==m['repository']and pr['base']['ref']=='dev' ,'PR identity drift');need(before['total_count']==len(before['workflow_runs'])==0,'Smoke workflow already present for exacthead; inspect before duplicating');receipt['before_run_ids']=[];checkpoint()
  for viewport,stage in grid:
   need(head()==m['sha'],'Remote branch changed before POST; reconcile, never redispatch');d={'viewport':viewport,'stage':stage,'requested_utc':now(),'post_attempted':True,'post_succeeded':False};receipt['dispatches'].append(d);checkpoint();api('dispatch', 'actions/workflows/'+m['workflow']+'/dispatches',{'ref':m['branch'],'inputs':{'viewport':viewport,'stage':stage}});d['post_succeeded']=True;checkpoint()
  need(deadline-time.monotonic()>2,'No discovery time; receipts preserved');time.sleep(2);after=api('runs-after',listing);need(after['total_count']==len(after['workflow_runs'])==18,'Run discovery incomplete/extra; reconcile without new POST')
  for run in after['workflow_runs']:need(run['head_sha']==m['sha']and run['head_branch']==m['branch']and run['event']=='workflow_dispatch'and run['path']=='.github/workflows/'+m['workflow']and run['run_attempt']==1,'Discovered run identity changed')
  receipt['discovered_runs']=[{k:r.get(k)for k in ['id','head_sha','head_branch','run_attempt','status','conclusion','event','path','created_at','html_url']}for r in after['workflow_runs']];need(len({r['id']for r in receipt['discovered_runs']})==18,'Duplicate run IDs');receipt['remote_head_after']=head();need(receipt['remote_head_after']==m['sha'],'Branch changed after dispatch');receipt['dispatch_complete']=True
 except Exception as e:receipt['error']=str(e)
 finally:receipt['finished_utc']=now();receipt['api_requests']=counter;checkpoint();print(json.dumps({'receipt':str(out/'receipt.json'),'sha':m['sha'],'dispatch_complete':receipt.get('dispatch_complete',False),'posted_successfully':sum(d['post_succeeded']for d in receipt['dispatches']),'error':receipt.get('error')},indent=2))
 return 0 if receipt.get('dispatch_complete')and not receipt.get('error')else 1
if __name__=='__main__':sys.exit(main())
