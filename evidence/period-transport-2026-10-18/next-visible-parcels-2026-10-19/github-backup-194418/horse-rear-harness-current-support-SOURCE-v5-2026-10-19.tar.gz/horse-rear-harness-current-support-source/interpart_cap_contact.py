# SPDX-License-Identifier: GPL-3.0-or-later
"""Exact registered separate-solid hip-cap simplex contact, never a tolerance.

This deliberately does not reuse an intra-surface directed-edge adjacency
condition. Triangle orientation cannot change their physical intersection.
Caller must prove all four original cap aliases/coordinates on both closed
parts, run unchanged SAT/proper first, and reject every proper crossing.
"""
import math
from exact_contact import lattice,sub,cross,dot,source_vertex_only

CAP_ALIASES={f'shared_hip_top:{i}'for i in range(4)}
PARTS={'hip_support_l','hip_support_r'}

def certify_cap_contact(a,b,row_a,row_b,registry,part_a,part_b,proper):
    if proper is not None or {part_a,part_b}!=PARTS:return None
    if set(registry)!={'coordinates','vertices','triangles','edges'}:return None
    coordinates=registry.get('coordinates',{})
    if set(coordinates)!=CAP_ALIASES or len(registry.get('vertices',[]))!=4 or set(registry.get('vertices',[]))!=CAP_ALIASES:return None
    if any(len(p)!=3 or not all(math.isfinite(float(x))for x in p)for p in coordinates.values())or len({tuple(map(float,p))for p in coordinates.values()})!=4:return None
    triangles={tuple(sorted(t))for t in registry.get('triangles',[])}
    if len(registry.get('triangles',[]))!=2 or len(triangles)!=2 or any(len(t)!=3 or len(set(t))!=3 or not set(t)<=CAP_ALIASES for t in triangles):return None
    actual_edges={tuple(sorted((t[j],t[(j+1)%3])))for t in triangles for j in range(3)}
    if len(registry.get('edges',[]))!=len(actual_edges)or {tuple(sorted(e))for e in registry.get('edges',[])}!=actual_edges:return None
    if len(row_a)!=3 or len(row_b)!=3 or len(set(row_a))!=3 or len(set(row_b))!=3:return None
    for triangle,row,part in [(a,row_a,part_a),(b,row_b,part_b)]:
        for point,alias in zip(triangle,row):
            if len(point)!=3 or not all(math.isfinite(float(x))for x in point):return None
            if alias in coordinates:
                if tuple(map(float,point))!=tuple(map(float,coordinates[alias])):return None
            elif not alias.startswith(part+':'):return None
    shared=set(row_a)&set(row_b)
    if not shared or not shared<=CAP_ALIASES:return None
    if len(shared)==1:
        alias=next(iter(shared));proof=source_vertex_only(a,b,row_a.index(alias),row_b.index(alias))
        return {'kind':'EXACT_registered_interpart_cap_vertex_only','registeredSimplex':[alias],'proof':proof,'toleranceUsed':False}if proof else None
    lattice_points,exponent=lattice(list(a)+list(b));A,B=lattice_points[:3],lattice_points[3:]
    if len(shared)==3:
        if tuple(sorted(shared))not in triangles:return None
        na=cross(sub(A[1],A[0]),sub(A[2],A[0]));nb=cross(sub(B[1],B[0]),sub(B[2],B[0]))
        if na==(0,0,0)or nb==(0,0,0)or cross(na,nb)!=(0,0,0)or dot(na,nb)>=0:return None
        return {'kind':'EXACT_registered_opposed_identical_cap_triangle','registeredSimplex':sorted(shared),'integerLatticeBinaryExponent':exponent,'normalDotInteger':dot(na,nb),'toleranceUsed':False}
    if len(shared)!=2:return None
    if tuple(sorted(shared))not in actual_edges:return None
    labels=sorted(shared);ia,ja=(row_a.index(v)for v in labels);ib,jb=(row_b.index(v)for v in labels)
    if A[ia]!=B[ib]or A[ja]!=B[jb]:return None
    p,q=A[ia],A[ja];edge=sub(q,p)
    va=sub(A[next(i for i in range(3)if i not in [ia,ja])],p);vb=sub(B[next(i for i in range(3)if i not in [ib,jb])],p)
    na,nb=cross(edge,va),cross(edge,vb)
    if na==(0,0,0)or nb==(0,0,0):return None
    triple,half=dot(na,vb),dot(na,nb)
    if triple!=0:case='distinct_exact_planes_meet_only_on_registered_edge_line'
    elif half<0:case='exact_coplanar_third_vertices_in_opposite_edge_halfplanes'
    else:return None
    return {'kind':'EXACT_registered_interpart_cap_edge_only','registeredSimplex':labels,'edgeWorld':[list(map(float,a[ia])),list(map(float,a[ja]))],'integerLatticeBinaryExponent':exponent,'scalarTripleInteger':triple,'normalDotInteger':half,'case':case,'directedIntrasurfaceAdjacencyNotClaimed':True,'toleranceUsed':False}
