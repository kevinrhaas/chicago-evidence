# SPDX-License-Identifier: GPL-3.0-or-later
"""Registered cap-simplex exact-contact controls; no new candidate or fit."""
from pathlib import Path
import copy,itertools,json,sys
sys.path.insert(0,'/workspace/shared/horse-neck-hybrid-pipeline-next')
from interpart_cap_contact import certify_cap_contact

P=Path(__file__).resolve().parent
labels=[f'shared_hip_top:{i}'for i in range(4)]
points=[[0.,0.,0.],[0.,1.,0.],[0.,1.,1.],[0.,0.,1.]]
triangles=[[labels[0],labels[1],labels[2]],[labels[0],labels[2],labels[3]]]
edges=sorted({tuple(sorted((t[j],t[(j+1)%3])))for t in triangles for j in range(3)})
registry={'coordinates':dict(zip(labels,points)),'vertices':labels,'triangles':triangles,'edges':edges}
part_a,part_b='hip_support_l','hip_support_r'
row_a=[labels[0],labels[1],part_a+':10'];row_b=[labels[0],labels[1],part_b+':20']
a=[points[0],points[1],[1.,0.,.2]];b=[points[0],points[1],[-1.,0.,.4]]
def cert(a,b,ra=row_a,rb=row_b,r=registry,proper=None,pa=part_a,pb=part_b):return certify_cap_contact(a,b,ra,rb,r,pa,pb,proper)
count=0
for ia in itertools.permutations(range(3)):
    for ib in itertools.permutations(range(3)):
        proof=cert([a[i]for i in ia],[b[i]for i in ib],[row_a[i]for i in ia],[row_b[i]for i in ib]);assert proof and proof['case']=='distinct_exact_planes_meet_only_on_registered_edge_line';count+=1
opposite=cert([points[0],points[1],[1.,0.,0.]],[points[0],points[1],[-1.,0.,0.]])
assert opposite and opposite['case']=='exact_coplanar_third_vertices_in_opposite_edge_halfplanes';count+=1
assert cert([points[0],points[1],[1.,0.,0.]],[points[0],points[1],[.5,0.,0.]])is None;count+=1
bad=copy.deepcopy(b);bad[0][0]=.001;assert cert(a,bad)is None;count+=1
assert cert(a,b,row_a,[labels[0],labels[0],part_b+':20'])is None;count+=1
assert cert(a,b,row_a,['shared_hip_top:4',labels[1],part_b+':20'])is None;count+=1
noncap_a=[points[1],points[3],[1.,0.,0.]];noncap_b=[points[1],points[3],[-1.,0.,.4]]
assert cert(noncap_a,noncap_b,[labels[1],labels[3],part_a+':10'],[labels[1],labels[3],part_b+':20'])is None;count+=1
assert cert([points[0],points[1],points[3]],[points[0],points[3],points[1]],[labels[0],labels[1],labels[3]],[labels[0],labels[3],labels[1]])is None;count+=1
assert cert([points[0],points[1],[0.,2.,0.]],b)is None;count+=1
assert cert(a,b,proper={'unconditional':'strict proper witnesses must be fatal'})is None;count+=1
cap_a=[points[0],points[1],points[2]];cap_row=[labels[0],labels[1],labels[2]]
assert cert(cap_a,cap_a,cap_row,cap_row)is None;count+=1
proof=cert(cap_a,list(reversed(cap_a)),cap_row,list(reversed(cap_row)));assert proof and proof['kind']=='EXACT_registered_opposed_identical_cap_triangle';count+=1
point_rows=([labels[0],part_a+':11',part_a+':12'],[labels[0],part_b+':21',part_b+':22'])
point_a=[points[0],[1.,0.,0.],[0.,1.,0.]];point_b=[points[0],[-1.,0.,1.],[0.,-1.,1.]]
assert cert(point_a,point_b,*point_rows)is not None;count+=1
assert cert(point_a,[points[0],[.5,0.,0.],[0.,.5,0.]],*point_rows)is None;count+=1
for mutate in ['edge','point','vertex_duplicates']:
    bad=copy.deepcopy(registry)
    if mutate=='edge':bad['edges'].append([labels[1],labels[3]])
    elif mutate=='point':bad['coordinates'][labels[2]]=[float('nan'),0.,0.]
    else:bad['vertices'].append(labels[0])
    assert cert(a,b,r=bad)is None;count+=1
assert cert(a,b,pa='breeching')is None;count+=1
# The retained actual first failure is only a single immutable captured
# witness/control, never a re-execution of the102pair or all-horse fit scan.
retained=json.loads((P/'RETAINED-v4-CAP-WITNESS.json').read_text())
proof=cert(*retained['actualTriangles'],*retained['sourceRows'],retained['registry'])
assert proof and proof['kind']=='EXACT_registered_interpart_cap_edge_only';count+=1
assert proof['scalarTripleInteger']!=0
print(json.dumps({'PASS':True,'scope':'Analytic registered-source cap simplex and retained captured single-witness controls only; no evaluator, new candidate, capture, full fit or browser','controls':count,'retainedWitnessCase':proof['case']}))
