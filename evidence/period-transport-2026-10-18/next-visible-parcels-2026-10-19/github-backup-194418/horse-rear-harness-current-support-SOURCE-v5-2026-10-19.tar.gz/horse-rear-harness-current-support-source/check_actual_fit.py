# SPDX-License-Identifier: GPL-3.0-or-later
"""One actual idle: ALL36gear vs ALLhorse and new3 vs ALLgear.

Unchanged SAT/proper predicates. Raw contacts retained. Only individually
proved source contacts at two declared stitched interfaces are admissible;
every strict proper crossing is fatal. No continuous, force or photo claim.
"""
from pathlib import Path
import hashlib,json,sys,time,signal
import numpy as np
sys.path.insert(0,'/workspace/shared/horse-combined-oral-neck-mane-prefix-next/idle-fit')
import official_fit_predicates as predicates
sys.path.insert(0,'/workspace/shared/horse-neck-hybrid-pipeline-next')
from interpart_cap_contact import certify_cap_contact,CAP_ALIASES

P=Path(__file__).parent
CHANGED={'breeching','hip_support_l','hip_support_r'}
HORSE_SHA='ab70aff958bc8a2780458d37212be1866c730817f485fbebbf53bd3c0e3931c3'
BASELINE_SHA='078ed2cebc01dba52d28f2ae737f170f0fe28fd20523aed9bb8869f4cd7b35bd'
CHECKER_ONLY_CANDIDATE_SHA='1fb25fbe561e8d2607431f7f569caaf594217263437151df98fa8c91c66da948'
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(v,m):
    if not v:raise ValueError(m)

def require_triangle_array(value,label):
    need(isinstance(value,np.ndarray)and value.ndim==3 and value.shape[0]>0 and value.shape[1:]==(3,3)and np.isfinite(value).all(),'complete actual triangle array at consumer boundary: '+label)
    return value

def main():
    need(len(sys.argv)==2,'explicit candidate dir');d=Path(sys.argv[1]);out=d/'ACTUAL-IDLE-FIT.json';need(not out.exists(),'exclusive actual fit output')
    started=time.monotonic();r={'PASS':False,'scope':'One freshly captured actual idle0 only; ALL36vsALLhorse, new3self previously checked, new3vsALLgear; no containment/continuous/force/photo acceptance','interpart':[],'horse':[]}
    save=lambda:out.write_text(json.dumps(r,indent=2)+'\n')
    def deadline(*_):raise TimeoutError('90second oneCPU actual fit bound')
    signal.signal(signal.SIGALRM,deadline);signal.alarm(90)
    try:
        side=json.loads((d/'SIDECAR.json').read_text());check=json.loads((d/'SERIALIZED-CHECK.json').read_text());receipt=json.loads((d/'capture/RECEIPT.json').read_text())
        need(check['PASS']is True and receipt['PASS']is True and receipt['candidateSHA256']==check['candidateSHA256']==side['candidateSHA256']==sha((d/'candidate.glb').read_bytes()),'actual same-candidate completed source and capture prerequisites')
        need(side['candidateSHA256']==CHECKER_ONLY_CANDIDATE_SHA,'checker-only requalification preserves exact previous actual model bytes')
        inventory_sha=sha((P/'SOURCE-INVENTORY.json').read_bytes());need(receipt['sourceInventorySHA256']==inventory_sha==side['sourceInventorySHA256'],'current frozen executable identity')
        records={x['name']:x for x in receipt['files']};need(set(records)=={'horse','baseline','candidate'} and len(receipt['files'])==3,'complete actual capture receipt')
        def load(name,want):
            mr=(d/'capture'/f'{name}.json').read_bytes();b=(d/'capture'/f'{name}.f64').read_bytes();m=json.loads(mr)
            need(m['input'][1]==want and sha(mr)==records[name]['metadataSHA256'] and sha(b)==m['bufferSHA256']==records[name]['bufferSHA256'],'actual source/capture buffer identity '+name)
            need(m['sourceInventorySHA256']==inventory_sha and m['precision']=='float64_world' and m['post_world_rounding']is False,'actual current capture format')
            pose=m['pose'];need(pose['clip']=='idle' and pose['timeS']==pose['phase']==pose['actualActionTime']==0 and pose['loop']=='LoopOnce_clamp','actual idle0 evaluated action')
            need(len(b)==m['triangleCount']*72 and m['triangleCount']==records[name]['triangleCount'],'complete actual buffer bytes')
            a=np.frombuffer(b,dtype='<f8').reshape(-1,3,3);need(np.isfinite(a).all(),'actual finite world triangles')
            start=0;seen=set()
            for g in m['meshes']:
                key=g['sourceMesh'],g['sourcePrimitive'];need(key not in seen and g['start']==start and g['count']>0,'complete unique ordered source primitive coverage');seen.add(key);start+=g['count']
            need(start==m['triangleCount'],'complete actual primitive end')
            return m,a
        hm,h=load('horse',HORSE_SHA);gm,g=load('candidate',side['candidateSHA256']);bm,baseline_triangles=load('baseline',BASELINE_SHA)
        need(hm['triangleCount']==13226 and len(gm['meshes'])==36 and len({x['name']for x in gm['meshes']})==36,'ALLhorse and ALL36 gear coverage')
        need(hm['pose']==gm['pose']==bm['pose'] and hm['rootWorld']==gm['rootWorld']==bm['rootWorld'] and hm['headWorld']==gm['headWorld']==bm['headWorld'],'fresh actual shared pose and frames')
        need(gm['rootWorld']==[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],'source-owned idle contacts evaluated in exact identity root')
        logical=json.loads((d/'LOGICAL-SOURCE.json').read_text());logical_parts={x['name']:x for x in logical['parts']};groups={x['name']:x for x in gm['meshes']}
        need(set(logical_parts)==CHANGED,'all three source-owned contact surfaces')
        global_aliases={};hip_top_ownership={}
        for name,s in logical_parts.items():
            group=groups[name];v=np.array(s['verticesFloat32']);faces=s['faces'];actual=g[group['start']:group['start']+group['count']]
            need(np.array_equal(v[np.array(faces)],actual),'actual fresh world geometry equals independently checked source-owned serialized idle '+name)
            aliases=[name+':'+str(i)for i in range(len(v))]
            if name.startswith('hip_support'):
                clip=s['clipOwnership'];need(clip['axis']==1 and clip['value']==side['policy']['hipBottomY'],'declared source cap clipping plane')
                source_count=len(clip['inputVerticesRootM'])
                last=source_count-4
                need({frozenset(f)for f in clip['inputFaces'][-2:]}=={frozenset([last,last+1,last+2]),frozenset([last,last+2,last+3])},'original last-ring closing cap source triangles exactly owned')
                for i,owner in enumerate(clip['outputVertexOwners']):
                    if owner['kind']=='original_strip_vertex' and owner['vertex']>=source_count-4:aliases[i]='shared_hip_top:'+str(owner['vertex']-(source_count-4))
                top_vertices={aliases[i]:{'logicalVertex':i,'originalStripVertex':clip['outputVertexOwners'][i]['vertex'],'actualCoordinate':v[i].tolist()}for i in range(len(v))if aliases[i]in CAP_ALIASES}
                need(set(top_vertices)==CAP_ALIASES,'all4actual original last-ring top aliases owned on each hip')
                top_faces=[i for i,owner in enumerate(clip['outputFaceOwners'])if owner['kind']=='clipped_original_strip_face'and owner['face']in [len(clip['inputFaces'])-2,len(clip['inputFaces'])-1]]
                need(len(top_faces)==2 and all(set(aliases[j]for j in faces[i])<=CAP_ALIASES for i in top_faces),'both original closing cap facets retain exact top-alias ownership')
                hip_top_ownership[name]={'vertices':top_vertices,'closingCapFaces':top_faces,'originalCapFaces':[len(clip['inputFaces'])-2,len(clip['inputFaces'])-1],'originalLastRingVertices':list(range(last,last+4))}
            global_aliases[name]=[[aliases[i]for i in f]for f in faces]
        need(set(hip_top_ownership)=={'hip_support_l','hip_support_r'},'exact two separate-solid top cap owners')
        cap_coordinates={alias:hip_top_ownership['hip_support_l']['vertices'][alias]['actualCoordinate']for alias in sorted(CAP_ALIASES)}
        need(all(hip_top_ownership['hip_support_r']['vertices'][alias]['actualCoordinate']==point for alias,point in cap_coordinates.items()),'all4actual separate-solid cap aliases match exactly')
        cap_sets={name:{frozenset(global_aliases[name][fi]):fi for fi in owner['closingCapFaces']}for name,owner in hip_top_ownership.items()}
        need(cap_sets['hip_support_l'].keys()==cap_sets['hip_support_r'].keys() and len(cap_sets['hip_support_l'])==2,'complete identical owned cap tessellations')
        cap_triangles=sorted(sorted(key)for key in cap_sets['hip_support_l'])
        cap_edges=sorted({tuple(sorted((t[j],t[(j+1)%3])))for t in cap_triangles for j in range(3)})
        cap_registry={'coordinates':cap_coordinates,'vertices':sorted(CAP_ALIASES),'triangles':cap_triangles,'edges':cap_edges}
        r['interpartCapRegistry']={'registry':cap_registry,'sourceOwnership':hip_top_ownership,'sharedMaterialVertexClaim':False,'closedSurfaceProof':'SERIALIZED-CHECK.json all3topology/self PASS prerequisite','orientationAndContact':'Each actual rawSAT still runs unchanged proper first, then exact simplex proof; no pair skip'}
        r['visualJunctions']={}
        for side_name,record in side['junctions'].items():
            point=record['innerPointRootM'];rear=logical_parts['breeching'];rv=record['rearLogicalVertex'];hip=logical_parts['hip_support_'+side_name];a,b=record['hipCapBoundaryEdge'];loop=hip['clipOwnership']['boundary']
            need(rv%4==1 and rear['verticesFloat32'][rv]==point,'actual rear inner-top source vertex owns exact serialized visual point')
            need((a,b)in set(zip(loop,loop[1:]+loop[:1])),'actual hip cap edge belongs to complete owned clipping boundary')
            u,v=hip['verticesFloat32'][a],hip['verticesFloat32'][b]
            need(u[0]==v[0]==point[0] and u[1]==v[1]==point[1] and u[2]!=v[2] and min(u[2],v[2])<=point[2]<=max(u[2],v[2]),'exact actual visual point on source-owned cap edge, no proximity tolerance')
            r['visualJunctions'][side_name]={'rearLogicalVertex':rv,'hipCapBoundaryEdge':[a,b],'point':point,'toleranceUsed':False,'sharedMaterialVertexClaim':False}
        predicates.predicate_controls()
        # Every new/remaining-part pair is evaluated. No pair-wide skip for
        # stitching; all broad-phase SAT and proper predicates run first.
        names=list(groups)
        for ai,a_name in enumerate(names):
            for b_name in names[ai+1:]:
                if a_name not in CHANGED and b_name not in CHANGED:continue
                ag,bg=groups[a_name],groups[b_name];aa=g[ag['start']:ag['start']+ag['count']];bb=g[bg['start']:bg['start']+bg['count']];lo,hi=bb.min(1),bb.max(1)
                row={'parts':[a_name,b_name],'complete':False,'rawSAT':0,'strictProper':0,'certifiedBoundaryContacts':[]};r['interpart'].append(row)
                for i,a in enumerate(aa):
                    for j in np.flatnonzero(np.all(hi>=a.min(0)-1e-8,axis=1)&np.all(lo<=a.max(0)+1e-8,axis=1)):
                        j=int(j);target=bb[j]
                        if not predicates.sat(a,target):continue
                        row['rawSAT']+=1;proper=predicates.proper(a,target);row['strictProper']+=int(proper is not None)
                        if proper is not None:
                            r['firstFailure']={'parts':[a_name,b_name],'faces':[i,j],'actualTriangles':[a.tolist(),target.tolist()],'proper':proper}
                            raise ValueError('first actual new-gear interpart strict proper crossing '+a_name+'/'+b_name)
                        cert=None;pair={a_name,b_name}
                        if 'breeching'in pair and any(n.startswith('hip_support')for n in pair):
                            hip=target if b_name.startswith('hip_support')else a;rear=a if a_name=='breeching'else target;plane=float(np.float32(side['policy']['hipBottomY']))
                            if np.all(hip[:,1]>=plane)and np.all(rear[:,1]<=plane)and np.any(hip[:,1]==plane)and np.any(rear[:,1]==plane):
                                cert={'kind':'EXACT_source_owned_hip_cap_and_rear_top_plane','axis':1,'actualFloat32Plane':plane,'hipSignedDistances':(hip[:,1]-plane).tolist(),'rearSignedDistances':(rear[:,1]-plane).tolist(),'toleranceUsed':False}
                        elif pair=={'hip_support_l','hip_support_r'}:
                            x,y=global_aliases[a_name][i],global_aliases[b_name][j]
                            cert=certify_cap_contact(a,target,x,y,cap_registry,a_name,b_name,proper)
                        if cert is None:
                            r['firstFailure']={'parts':[a_name,b_name],'faces':[i,j],'actualTriangles':[a.tolist(),target.tolist()],'proper':proper};raise ValueError('first uncertified actual interpart rawSAT')
                        row['certifiedBoundaryContacts'].append({'faces':[i,j],'proof':cert})
                row['complete']=True;save()
        need(len(r['interpart'])==102,'all3changed vs33fixed plus3changed/changed pairs')
        hlo,hhi=h.min(1),h.max(1)
        def against_horse(label,triangles,group_rows):
            require_triangle_array(triangles,label)
            row={'label':label,'complete':False,'parts':{},'rawSAT':0,'strictProper':0};r['horse'].append(row)
            for part in group_rows:
                raw=proper_count=0
                for i,a in enumerate(triangles[part['start']:part['start']+part['count']]):
                    for j in np.flatnonzero(np.all(hhi>=a.min(0)-1e-8,axis=1)&np.all(hlo<=a.max(0)+1e-8,axis=1)):
                        j=int(j)
                        if predicates.sat(a,h[j]):
                            raw+=1;proper=predicates.proper(a,h[j]);proper_count+=int(proper is not None)
                            if label=='candidate':
                                row['parts'][part['name']]={'rawSAT':raw,'strictProper':proper_count,'complete':False};row['rawSAT']+=raw;row['strictProper']+=proper_count
                                r['firstFailure']={'part':part['name'],'gearFace':i,'horseFace':j,'actualTriangles':[a.tolist(),h[j].tolist()],'proper':proper}
                                raise ValueError('first actual ALL36 vs ALLhorse contact')
                row['parts'][part['name']]={'rawSAT':raw,'strictProper':proper_count};row['rawSAT']+=raw;row['strictProper']+=proper_count
            row['complete']=True;save();return row
        control=against_horse('original078_negative',baseline_triangles,[x for x in bm['meshes']if x['name']in {'cheekpiece_l','cheekpiece_r','crownpiece','browband','noseband'}])
        need(control['rawSAT']>0 and control['strictProper']>0,'original unchanged078 penetration control must remain negative')
        against_horse('candidate',g,gm['meshes']);r['PASS']=True;r['candidateSHA256']=side['candidateSHA256']
    except BaseException as error:r['error']=repr(error);raise
    finally:signal.alarm(0);r['elapsedS']=time.monotonic()-started;save()

if __name__=='__main__':main()
