# SPDX-License-Identifier: CC0-1.0
"""Original dimensional fiber/pores/pits, no external imagery or photomeasurement."""
import numpy as np,json,io,hashlib
from PIL import Image
from pathlib import Path

def make_tiles(recipe,output):
 output=Path(output);output.mkdir();reports={}
 for fi,family in enumerate(['wood','paint','iron']):
  p=recipe[family];w,h=p['pixels'];sx,sy=p['tile_m'];rng=np.random.default_rng(recipe['seed']+fi);x=np.arange(w)[None,:]*sx/w;y=np.arange(h)[:,None]*sy/h;height=np.zeros((h,w));field=np.zeros((h,w))
  if family!='iron':
   # A periodic longitudinal fiber coordinate, sparse elongated pore cavities.
   phase=y/sy*round(sy/p['fiber_spacing_m'])+.15*np.sin(2*np.pi*x/sx*3)+.06*np.sin(2*np.pi*x/sx*11)
   field=.60*np.cos(2*np.pi*phase)+.22*np.cos(2*np.pi*(phase*2+.13*np.sin(2*np.pi*x/sx*7)))+.12*np.cos(2*np.pi*(y/sy*3+x/sx))
   height=p['fiber_height_m']*field
   for _ in range(p['pore_count']):
    cx=rng.uniform(0,sx);cy=rng.uniform(0,sy);lx=rng.uniform(.003,.014);ly=rng.uniform(.0006,.0011);dx=np.minimum(abs(x-cx),sx-abs(x-cx));dy=np.minimum(abs(y-cy),sy-abs(y-cy));pore=np.exp(-((dx/lx)**4+(dy/ly)**2)*2);field-=.65*pore;height-=.000020*pore
  else:
   for _ in range(p['pit_count']):
    cx=rng.uniform(0,sx);cy=rng.uniform(0,sy);r=rng.uniform(.001,.003);dx=np.minimum(abs(x-cx),sx-abs(x-cx));dy=np.minimum(abs(y-cy),sy-abs(y-cy));pit=np.exp(-(dx*dx+dy*dy)/(r*r));field-=pit;height-=.000035*pit
   field-=field.mean();field/=max(float(abs(field).max()),1)
  field-=field.mean();field/=max(float(abs(field).max()),1);albedo=.5*(1+p['color_contrast']*field);rough=np.clip(p['roughness']+.04*field,0,1)
  # Physical derivatives: normal intensity comes from micron height/metre spacing.
  dzdx=(np.roll(height,-1,1)-np.roll(height,1,1))/(2*sx/w);dzdy=(np.roll(height,-1,0)-np.roll(height,1,0))/(2*sy/h);normal=np.stack([-dzdx,-dzdy,np.ones_like(field)],axis=2);normal/=np.linalg.norm(normal,axis=2,keepdims=True)
  # Explicit neutral 4x4 texels are a declared constant-material chart for cutends/hubs.
  albedo[:4,:4]=.5;normal[:4,:4]=[0,0,1];rough[:4,:4]=p['roughness']
  srgb=np.where(albedo<=.0031308,albedo*12.92,1.055*albedo**(1/2.4)-.055);color=np.repeat(np.round(srgb*255).astype('uint8')[:,:,None],3,axis=2);nn=np.round((normal*.5+.5)*255).astype('uint8');orm=np.stack([np.full_like(field,255),np.round(rough*255),np.full_like(field,255 if family=='iron'else 0)],2).astype('uint8')
  hashes={}
  for kind,array in [('color',color),('normal',nn),('orm',orm)]:
   f=output/(family+'_'+kind+'.png');Image.fromarray(array).save(f,compress_level=9);hashes[kind]=hashlib.sha256(f.read_bytes()).hexdigest()
  reports[family]={'pixels':[w,h],'tile_m':[sx,sy],'px_per_m':[w/sx,h/sy],'decoded_RGBA8_mips_bytes_estimate':w*h*4*4/3*3,'mean_linear_albedo':float(albedo.mean()),'height_range_m':[float(height.min()),float(height.max())],'map_sha256':hashes,'flat_chart_uv':[2/w,2/h],'note':'original analytic fibers/pores/pits; unmeasured optical design, no sourcephoto'}
 return reports
