# Irregular cell-integrated wagon material study — unaccepted

Root reviewed source plan and released ONE corrected generation. Actualcandidate464e430dfb55f37b14d349705ec94199ecc211cb437f951273a9b5a74372c2e0 now exists. SOURCE-PLAN.md retains the earlier pre-generation review status; this receipt supersedes only that temporal status, not its limitations. Prior1463/1d739 source/assets/actualA-B archives untouched.

Actualgeometry/normal orientedtriangle multiset, nodes/rig/socket hierarchy andoldBINexact. Original23primitivebatches retained, actualembeddedimageheaders2048×128wood,1024×64paint,256²iron,3maps/family;6MiB RGBA8+mipsestimate (not measuredGPUallocation). TBNmaxNdot6.33e-8, maxmetricbevelanisotropy1.7321. Flatconstantneutralcharts5436triangles, nonconstant5596; no claimallmipneutral or endgrainanatomy. Khronos0errors0warnings19infos.

IrregularoriginalGaussianfibers vary spacing/width/amplitude/slowwander/longitudinalenvelope; broadlayers and pores break regularity. ExactGaussianY pixelcellintegration,4pointXfiber/8pointXporesquadrature and GaussianXYpitcellaverages. This is originalCC0 output, not photographs, speciesattestation, naturalgrowthringreconstruction or measuredfinish. Scipy authoring only; GLB carries pixels and standardPBR, no new runtime dependency. Actualgeneratedwoodtile inspected; more irregular and lessregularcomb than1d739, visual improvement still awaits actual matchedrenderer A/B.

Reproduce: python build.py --vehicle F415.glb --parts AUTHORED_PARTS.json --parameters parameters.json --output FRESH_DIR. Originalparts extraction script included, currenttrial used hash-bound authoredparts from coherentstudy; no runtimeprivatepathdependency.
