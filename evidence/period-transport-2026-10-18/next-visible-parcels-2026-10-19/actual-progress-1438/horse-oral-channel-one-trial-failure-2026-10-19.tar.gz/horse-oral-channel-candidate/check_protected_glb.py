# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import json,hashlib,struct,collections,numpy as np
P=Path(__file__).parent
old=Path('/workspace/shared/horse-head-groove-coat-next/trial1/equine_light_harness_skinned_prototype_01.glb');new=P/'candidate-one/equine_light_harness_skinned_prototype_01.glb';source=json.loads((P/'source/frozen-head.json').read_text());made=json.loads((P/'candidate-one/head-source-surface.json').read_text())
def require(c,m):
 if not c:raise ValueError(m)
def load(path):
 raw=path.read_bytes();n=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+n]);b=raw[28+n:]
 def arr(i):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];dt={5126:'<f4',5123:'<u2',5125:'<u4'}[a['componentType']];size={'VEC3':3,'VEC4':4,'MAT4':16,'SCALAR':1}[a['type']];return np.frombuffer(b,dt,a['count']*size,v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(a['count'],size)
 return d,arr
require(hashlib.sha256(old.read_bytes()).hexdigest()=='090be8fdc2516ee5b5c8f886026f441850cc208f17b6ede71fed9007ab80f12f','oldhorsepin');a,ar=load(old);b,br=load(new)
checks={'node_ids_names_hierarchy_transforms_meshskinrefs_exact':a['nodes']==b['nodes'],'materials_exact':a['materials']==b['materials'],'scenes_exact':a['scenes']==b['scenes']}
def semantic_animations(d,arrays):
 result=[]
 for anim in d['animations']:
  x=dict(anim);x['samplers']=[{**s,'input':arrays(s['input']).tobytes().hex(),'output':arrays(s['output']).tobytes().hex()}for s in anim['samplers']];result.append(x)
 return result
checks['animations_timing_channels_values_exact']=semantic_animations(a,ar)==semantic_animations(b,br)
checks['rig_joint_node_ids_skeleton_inversebind_exact']=[{**s,'inverseBindMatrices':ar(s['inverseBindMatrices']).tobytes().hex()}for s in a['skins']]==[{**s,'inverseBindMatrices':br(s['inverseBindMatrices']).tobytes().hex()}for s in b['skins']]
retired=set(made['oral_authority']['retired_source_faces']);allowed=set(made['oral_authority']['normal_halo_nonprotected']);allowedfaces=retired|{i for i,f in enumerate(source['faces'])if any(v in allowed for v in f)}
wp=(np.asarray(source['positions'],dtype='<f4').astype(float)+[0,1.88,.8]).astype('<f4')
def poskey(p):return b''.join(sorted(np.asarray(x,dtype='<f4').tobytes()for x in p))
allowedkeys={poskey(wp[source['faces'][i]])for i in allowedfaces}
def counters(d,arrays,exclude=False):
 counter=collections.Counter();ex=0
 for mesh in d['meshes']:
  for pr in mesh['primitives']:
   attrs=[arrays(pr['attributes'][k])for k in ['POSITION','NORMAL','JOINTS_0','WEIGHTS_0']];indices=arrays(pr['indices']).ravel().reshape(-1,3)
   for ix in indices:
    if exclude and poskey(attrs[0][ix])in allowedkeys:ex+=1;continue
    pieces=[b''.join(x[i].tobytes()for x in attrs)for i in ix];cycles=[b''.join(pieces[k:]+pieces[:k])for k in range(3)];counter[min(cycles)]+=1
 return counter,ex
protected,removed=counters(a,ar,True);actual,_=counters(b,br);missing=protected-actual;checks['all_old_protected_oriented_P_N_J_W_triangles_exact']=not missing
checks['exact124retirement_and_declared_normal_faces_only']=removed==len(allowedfaces)
# Bind EVERY replacement/normal-halo source triangle to decoded export attributes.
# These source vertices are outside all .17m neighbor weighting zones; otherwise refuse.
headnode=next(i for i,n in enumerate(b['nodes'])if n['name']=='head')
headji=b['skins'][0]['joints'].index(headnode)
parent={c:i for i,n in enumerate(b['nodes'])for c in n.get('children',[])}
def world(i):
 n=b['nodes'][i];require(not n.get('matrix') and n.get('rotation',[0,0,0,1])==[0,0,0,1] and n.get('scale',[1,1,1])==[1,1,1],'unexpected rest frame')
 return np.asarray(n.get('translation',[0,0,0]),float)+(world(parent[i])if i in parent else 0)
require(np.array_equal(world(headnode),[0,1.88,.8]),'head source frame mismatch')
replacement=[i for i,o in enumerate(made['source_owners'])if o['kind']!='retained_source' or any(v in allowed for v in made['faces'][i])]
mp=(np.asarray(made['positions'],dtype='<f4').astype(float)+world(headnode)).astype('<f4');mn=np.asarray(made['normals'],dtype='<f4')
used={v for i in replacement for v in made['faces'][i]}
require(all(np.linalg.norm(mp[v].astype(float)-world(j))>=.17 for v in used for j in b['skins'][0]['joints']if j!=headnode),'replacement reaches source weight blending zone')
jv=np.array([headji,0,0,0],dtype='<u2').tobytes();wv=np.array([1,0,0,0],dtype='<f4').tobytes()
expected=collections.Counter()
for i in replacement:
 pieces=[mp[v].tobytes()+mn[v].tobytes()+jv+wv for v in made['faces'][i]]
 expected[min(b''.join(pieces[k:]+pieces[:k])for k in range(3))]+=1
checks['every_new_or_normal_changed_oriented_source_P_N_J_W_triangle_decodes_exact']=actual==protected+expected
r={'PASS':all(checks.values()),'checks':checks,'baseline_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'old_allowed_head_face_count_including_normal_halo':len(allowedfaces),'actual_old_excluded_faces':removed,'protected_oriented_triangles':sum(protected.values()),'missing_protected_triangles':sum(missing.values()),'source_bound_replacement_triangles':sum(expected.values()),'source_sha256':hashlib.sha256((P/'candidate-one/head-source-surface.json').read_bytes()).hexdigest(),'scope':'Actual GLB exact whole oriented P/N/J/W inventory equals protected old plus source-bound replacement; strict source embedding separately checked'};(P/'protected-glb-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));require(r['PASS'],'actual protectedGLBguardfailed')
