# SPDX-License-Identifier: CC0-1.0
"""Original eight-chart oral channel; source-controlled 124face replacement, not accepted anatomy."""
import json,hashlib,math
from pathlib import Path
P=Path(__file__).parent
def require(value,msg):
 if not value:raise ValueError(msg)
def sub(a,b):return [a[k]-b[k]for k in range(3)]
def cross(a,b):return[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def norm(a):return math.sqrt(sum(v*v for v in a))
def build(recipe):
 raw=(P/'frozen-head.json').read_bytes();require(hashlib.sha256(raw).hexdigest()=='ac4d96ab6ae8d0ef5956686a3a9c213ebce1dd9e76f5e91c4e376b319429b5b3','wrong frozen head')
 require(hashlib.sha256(json.dumps(recipe,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='4c18a98a49ff2deea4785c5f1acbcf31d0ea9e782303b9fab18708a04ace565f','wrong frozen head recipe');patchraw=(P/'oral-patch.json').read_bytes();require(hashlib.sha256(patchraw).hexdigest()=='4b7fe911945903d43d518e496ea55cb09614233d7bfd7583f56724a7e4ac4182','oral patch authority mismatch');base=json.loads(raw);patch=json.loads(patchraw);oldv=base['positions'];oldf=base['faces'];rim=patch['rim_source_vertex_loop'];retired=set(patch['proposed_retired_source_face_ids']);require(len(retired)==124 and len(rim)==66,'oral source cohort')
 require(patch['head_sha256']==hashlib.sha256(raw).hexdigest(),'patch source pin');require(rim[0]==337 and[rim[i]for i in[4,9,23,28,32,38,60]]==[341,581,595,355,359,647,625],'eight chart anchors')
 v=[p[:]for p in oldv];faces=[];tags=[];owners=[]
 for i,(f,t)in enumerate(zip(oldf,base['tags'])):
  if i not in retired:faces.append(f[:]);tags.append(t);owners.append({'kind':'retained_source','source_face':i})
 retained_count=len(faces)
 def vertex(p):require(all(math.isfinite(x)for x in p),'nonfinite vertex');v.append(list(p));return len(v)-1
 def tri(a,b,c,tag,owner):require(len({a,b,c})==3,'duplicate face vertex');faces.append([a,b,c]);tags.append(tag);owners.append(owner)
 # Inner channel boundary is exactly eight arcs, matching ordered 66outerrim.
 # Engineering coordinates: full6mm bit surface lies below roof,above floor,anterior backwall.
 X=.045;roof=-.185;floor=-.218;back=.370;front=.500
 breaks=[0,4,9,23,28,32,38,60,66]
 corners=[[-X,roof,back],[-X,floor,back],[-X,floor,front],[X,floor,front],[X,floor,back],[X,roof,back],[X,roof,front],[-X,roof,front],[-X,roof,back]]
 inner=[];chartowners=[]
 for c,(start,end)in enumerate(zip(breaks,breaks[1:])):
  for i in range(start,end):
   if c in[1,3,5,7]:
    za=oldv[rim[start]][2];zb=oldv[rim[end%66]][2];t=(oldv[rim[i]][2]-za)/(zb-za)
   else:t=(i-start)/(end-start)
   p=[corners[c][k]*(1-t)+corners[c+1][k]*t for k in range(3)];inner.append(vertex(p));chartowners.append(c)
 require(len(inner)==66,'inner66')
 for i,a in enumerate(rim):
  j=(i+1)%66;owner={'kind':'oral_rim_connector','chart':chartowners[i],'outer_source_edge':[a,rim[j]],'inner_edge':[inner[i],inner[j]]}
  tri(a,rim[j],inner[j],'mouth_oral',owner);tri(a,inner[j],inner[i],'mouth_oral',owner)
 # Backwall gets shared top/bottom edge knots; roof/floor surfaces use planar fans.
 rearx=sorted(set([v[inner[i]][0]for i in range(9,24)]+[v[inner[i]][0]for i in range(38,61)]))
 rearroof=[];rearfloor=[]
 for x in rearx:
  def shared(y,first,last):
   if abs(x+X)<1e-14:return inner[first]
   if abs(x-X)<1e-14:return inner[last]
   return vertex([x,y,back])
  rearroof.append(shared(roof,0,32));rearfloor.append(shared(floor,4,28))
 def fan(boundary,name):
  require(len(boundary)==len(set(boundary)),'duplicate planar boundary '+name);center=vertex([sum(v[i][k]for i in boundary)/len(boundary)for k in range(3)])
  for a,b in zip(boundary,boundary[1:]+boundary[:1]):tri(center,a,b,'mouth_oral',{'kind':name,'boundary_edge':[a,b]})
 roofboundary=inner[32:66]+[inner[0]]+rearroof[1:-1]
 floorboundary=inner[4:29]+rearfloor[-2:0:-1]
 backboundary=inner[0:5]+rearfloor[1:]+inner[29:33]+rearroof[-2:0:-1]
 fan(roofboundary,'oral_roof');fan(floorboundary,'oral_floor');fan(backboundary,'oral_back')
 # Area normal accumulation; only exact declared NONPROTECTED halo may change.
 normals=[[0.,0.,0.]for _ in v]
 for face in faces:
  a,b,c=[v[i]for i in face];n=cross(sub(b,a),sub(c,a));require(norm(n)>2e-12,'zero area oral/retained triangle')
  for i in face:normals[i]=[normals[i][k]+n[k]for k in range(3)]
 for i,n in enumerate(normals):
  length=norm(n)
  normals[i]=[x/length for x in n]if length else[0.,0.,0.]
 protected=set(range(48))
 for record in base['records']:
  if record['name'].startswith(('eye','nostril')):
   selected=[f for f,t in zip(oldf,base['tags'])if t==record['name']or t=='skin:'+record['name']];protected.update(a for f in selected for a in f)
 protected.update(a for i in[4,6,7,16,17,19]for a in oldf[i])
 allowed=set(patch['proposed_normal_halo_vertices'])-protected
 for i in range(len(oldv)):
  if i not in allowed:normals[i]=base['normals'][i][:]
 # Removed lips are explicitly superseded; remaining source lip geometry retained,not mislabeled complete oldgroove.
 records=[r for r in base['records']if not r['name'].startswith('lip')]
 records.append({'name':'mouth_oral','kind':'single_connected_open_mouth_channel','outer':rim,'inner':inner,'retired_source_faces':sorted(retired),'retained_lip_source_faces':[i for i,t in enumerate(base['tags'])if t.startswith('lip')and i not in retired],'allowed_normal_vertex_ids':sorted(allowed),'protected_normal_vertex_ids':sorted(protected),'engineering_channel':{'half_width_m':X,'roof_y_m':roof,'floor_y_m':floor,'back_z_m':back,'front_z_m':front},'bit_surface_semantics':'actual32open-ended6mmradius sides unchanged; virtual endcaps onlydesign volume,not emittedbit geometry','not_accepted':['embedding','positive fulltube clearance','allgear fit','photographic anatomy','teeth/tongue','pressure','oral motion']})
 result={'positions':v,'faces':faces,'tags':tags,'normals':normals,'portal':base['portal'],'band':base['band'],'records':records,'source_owners':owners,'oral_authority':{'frozen_head_sha256':hashlib.sha256(raw).hexdigest(),'retired_source_faces':sorted(retired),'old_vertices_exact':len(oldv),'retained_source_faces':retained_count,'normal_halo_nonprotected':sorted(allowed),'source_status':'neworiginaloral geometry; validationpending'},'status':'SOURCE ORIGINAL mouthchannel candidate; embedding/bitfit/period/photo acceptance unproved'}
 audit(result,base,retired,protected,allowed)
 return result

def audit(s,base,retired,protected,allowed):
 uses={};adj={}
 for i,f in enumerate(s['faces']):
  for a,b in zip(f,f[1:]+f[:1]):uses.setdefault(tuple(sorted((a,b))),[]).append((a,b));adj.setdefault(a,set()).add(b);adj.setdefault(b,set()).add(a)
 boundary={k for k,u in uses.items()if len(u)==1};portal=s['portal'];expect={tuple(sorted((a,b)))for a,b in zip(portal,portal[1:]+portal[:1])};require(boundary==expect,'unexpected mouth hole')
 for edge,u in uses.items():require(len(u)==1 or(len(u)==2 and u[0]==u[1][::-1]),'bad oral edge ownership')
 seen=set();todo=[next(iter(adj))]
 while todo:
  i=todo.pop()
  if i in seen:continue
  seen.add(i);todo.extend(adj[i]-seen)
 require(len(seen)==len(adj),'detached oral component');require(len(adj)-len(uses)+len(s['faces'])==1,'oral genus changed')
 require(s['positions'][:len(base['positions'])]==base['positions'],'old source positions changed')
 for i in range(len(base['normals'])):
  if i not in allowed:require(s['normals'][i]==base['normals'][i],'protected normal changed')
 expected=[f for i,f in enumerate(base['faces'])if i not in retired];require(s['faces'][:len(expected)]==expected,'wrong retired source cohort')
 s['topology']={'connected_components':1,'euler_characteristic':1,'portal_boundary_edges':len(boundary),'triangles':len(s['faces']),'source_vertices':len(s['positions']),'old_source_vertices_exact':len(base['positions']),'source_retired_faces':len(retired)}
