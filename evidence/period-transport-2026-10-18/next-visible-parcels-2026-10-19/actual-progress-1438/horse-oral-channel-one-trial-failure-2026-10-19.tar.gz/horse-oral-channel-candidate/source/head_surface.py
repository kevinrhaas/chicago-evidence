# SPDX-License-Identifier: CC0-1.0
"""New explicit oral authority; frozen originalhead/source cohorts checked by oral_channel."""
from oral_channel import build
