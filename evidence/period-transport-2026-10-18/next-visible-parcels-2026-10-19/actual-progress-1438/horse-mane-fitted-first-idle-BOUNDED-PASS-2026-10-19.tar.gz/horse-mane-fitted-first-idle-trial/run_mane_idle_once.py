from pathlib import Path
import json,hashlib,time,subprocess,signal,os,sys
start=time.monotonic();src=Path('/workspace/shared/horse-mane-fitted-next');out=Path('/workspace/shared/horse-mane-fitted-first-idle-trial');out.mkdir(parents=True,exist_ok=False)
for path,want in json.loads((src/'operator-source-pins.json').read_text()).items():
 if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=want:raise ValueError('SOURCEPIN MISMATCH '+path)
packet='/workspace/shared/horse-mane-fitted-first-local-trial/payload/packet.json';packet_sha='5f716ee2583aad96c2e0c8c1107e91f9d4d511f717683b8274eab04d1c1dd23a'
commands=[['node','--loader','/workspace/shared/horse-ear-root-idle-checker-f64-unique-next/three-loader.mjs','/workspace/shared/horse-neck-hybrid-pipeline-next/capture_threeway.mjs','--output-dir',str(out/'capture'),'--baseline','/workspace/shared/horse-head-groove-coat-next/trial1/equine_light_harness_skinned_prototype_01.glb','--ear-parent','/workspace/shared/horse-ear-root-exporter-source-reviewed-next/export-trial1/equine_ear_root_candidate.glb','--chain',packet,'--chain-sha256',packet_sha],['/workspace/shared/chicago-venv/bin/python','-c',"import sys;from pathlib import Path;sys.path.insert(0,"+repr(str(src))+");from check_mane import once;ok=once("+repr(packet)+","+repr(packet_sha)+","+repr(str(out/'capture'))+","+repr(str(out/'results'))+");sys.exit(0 if ok else 1)"]]
r={'status':'STARTED','packet_sha256':packet_sha,'candidate_sha256':'1eee14e7d80ef8dcbe7e9d2ab3250cc7ea711a74f4cda730dd4b2af954cfcd89','source_archive_sha256':'d625d62fdc85a1167c98919de02db9142701e6dfe925a18d4dfe46425de2d294','deadline_s':120,'stages':[]}
def save():(out/'run-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
save()
for i,cmd in enumerate(commands,1):
 budget=120-(time.monotonic()-start)
 if budget<=0:r.update(status='FIRSTFAIL deadlineSTOP');save();sys.exit(124)
 with(out/f'stage{i}.stdout.log').open('wb')as stdout,(out/f'stage{i}.stderr.log').open('wb')as stderr:
  p=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,start_new_session=True)
  try:code=p.wait(timeout=budget)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();code=124
 r['stages'].append({'command':cmd,'returncode':code,'elapsed_s':time.monotonic()-start});save()
 if code:r.update(status='FIRSTFAIL STOP; no retry/repair');save();sys.exit(code)
r.update(status='DISCRETEidle0ONLY; UNACCEPTEDoverall',elapsed_s=time.monotonic()-start);save()
