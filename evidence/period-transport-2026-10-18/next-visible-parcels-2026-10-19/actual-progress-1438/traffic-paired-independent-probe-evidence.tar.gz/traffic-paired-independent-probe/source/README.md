# Concrete western Lake1835 paired drawbar candidate — outside app

Source/design handoff BEFORE any new browser. No main installation, route authorization, performance/photo acceptance or completed physical pulling claim. Immutable previous onehorse/independent-wagon GPU evidence archive remains SHA236cb787814ae39d272244b5de86a7841daf3017866a9ab366604d49477f788b.

## One visible outcome selected

Actual declared1835 Lake Street western segment0, existing rendered centreline fallback because this record has no drawn_track override. Ends trimmed10m: ENU[-512.025329,-105.542126]→[-329.999671,-107.018874],182.031648m. Street geometry attested, surface inferred; moving traffic/identity/hitch arrangement reconstructed. No owner/driver invented. Existing source IDs chicago_dpw_1891_streets,hathaway_1834,wright_1834,osm_streets_2026,thompson_plat_1830 resolve to repository files. A later retrospective source is not proof of a particular wagon schedule. target1835-07-01 lies in actual epoch e1834_harbor_cut interval1833-07-01..1848-12-31.

index.html is an isolated visible viewer ready for later reviewed run: actual epoch Heightfield, narrow terrain context patch, unchanged current W01 plus TWO independently rigged current horses, shared one-material GPU batch. It shows the actual centre pole between animals, raised by actual tongue pivot to1m tip, pair roots x±0.72,z4.035401m. Reconstructed geometry/motion grade explicit. UI states missing yoke,traces,harness,driver. It does NOT attach incompatible tack, float/scale horses, backdate C01 shafts, or pretend W01 single socket is a shaft pair. This is paired drawbar kinematics, NOT horses visibly connected by finished working equipment or force/pulling approval.

Full/Balanced only, hard Light rejection with existing scene preserved and no fake onehorse fallback. No filled seats. Current named1835 residents remain the future driver path only after body/wardrobe/bench/reins acceptance.

## Actual source/terrain/geometry work completed

Actual unchanged source hashes: W01 7749a019..., horse89b048b7..., manifest6d5ccc...; fully recorded in pair-source-receipt.json.39,136tri,46,880vertices,36matrix palette(30horse+4wheel+1pole+1static),2304float32 uniform bytes,0newtextures. Original geometry/material families/radii/rigclips retained; only articulated pole/wheel/horse transforms change. Team has half-cycle walk offset. New36matrix shader NOT WebGL-tested. Vertex uniform use must be checked on actual browser; prior20matrix PASS is not transferred.

route-terrain-receipt.json: exact existing Heightfield class reused from pinned terrain.js in a source-isolated Node context, actual int16→float32 grid semantics.184stations at1m including both exact endpoints ×25swept-envelope probes,0water/0out-of-grid. Water boundary uses actual terrain SHORE_Y=-0.10. Whole rig ground spans up to49.57mm so NOT silently treated as flat. support.mjs fits independent rigid support planes with actual(e,y,-n), +Z actor yaw pi-bearing.184positions×wagon+2horse support footprints max residual0.595726mm, within explicit5mm study bound; maximum grade orientation1.0188deg. Ground contact offsets use actual wheel/horse rest-contact locations; animated sole contact/continuous suspension still NOT qualified.

CPU actual geometry21walkphase samples: centralpole lateral clearance>=0.369m; horse/horse lateral gap>=0.8m; horse/vehicle longitudinal gap>=1.244988m. Full source-point radii<=6m asserted. combine-study conservatively encloses sampled21poses×184groundframes via maximum rotation/ground-offset displacement0.223019m; residual lower bounds pole0.145981m,pair0.576981m,vehicle1.021969m. These are sufficient sampled envelope separation checks, NOT head self-intersection, continuousSAT, full hoof ground, tree/static-object corridor clearance, source-animal acceptance or missing hitch hardware proof. No illegal gear was added merely to make a connected-looking picture.

Exactsource CPU tests passed; audit-route/test-pair/combine-study commands use three-loader.mjs and complete under1second. Actual GLSL/PNG/frame/published-scene costs remain pending.

## Conscious Full/Balanced budget proposal for later measurement

full-balanced-budget-proposal.json preserves old absolute margins18,059/16,806 plus source-counted39,136 addition and5,000rounding. Historical diagnostic tightstand prairie_west: Full3,449,919+39,136+18,059 rounds3,510,000; Balanced2,607,952+39,136+16,806 rounds2,665,000. These are PROPOSALS, no budgets/tests changed. Under current3,470,000/2,625,000 the bare pair does not fit that worststand. General330 callcap unchanged; historical maxima319/314 plus predictedonebatch320/315. Light1,190,000/90 unchanged and paired candidate disabled. Existing diagnostic is split historical run, not current09a actual main delta. Actual reviewed new shader/perpass cost, tightstand main and allstand/viewport visibility/CPU tests must support any owner-approved rebudget. No waiver or threshold edit made here. Missingfuturegear/person will need separately priced additions; do not let bare39,136 substitute for equipped traffic cost.

## Next bounded actual probe, not yet authorized

Root can review source then allow one isolated local server/browser run. Serve with python serve.py --port8797; URL http://127.0.0.1:8797/index.html. pairedStudy.frame({time:0,tier:'full',visible:true,mode:'plain',width:1280,height:800}) supports explicittime,full/balanced,normal/tint/ghost. RequestingLight mustthrow. Camera follows actualroute at~100m. Baseline terrain patch stays in off/on/restored measurements; candidate expected onebatch39,136tri must be actually measured, not asserted from source. Retain PNGs missinggear text, actual shader/page/network errors, uniform limits and scripted/animation timing; actualmain scene untouched.

## Independent review correction revision

Predecessor81813 remains frozen. combine-study now uses ACTUAL maximum|team0Y-team1Y|=0.006903546m for horse/horse enclosure, separately from maximum|teamY-wagonY|=0.009657674m; it does not reuse that bound incorrectly. Updated pair lower gap0.579735m; pole0.145981m and body1.021969m unchanged.

test-independent-pose.mjs separately loads all THREE ORIGINAL GLTF hierarchies and actual AnimationMixers, sets original wheel/tongue node rotations, and uses original SkinnedMesh.getVertexPosition per vertex.12cases cover5Hz boundary/just-before, phases, loop/just-before, wheel rotation,1000cycles,1e6m and reversal. Independent46,880vertex float32-uniform CPU emulation differences maxposition4.76837158e-7m/maxnormal5.96046448e-8. CPU PASS, not newGPU/pixel equivalence or continuousphysical acceptance.

Owned probe.cjs prepared/syntax checked, NOT RUN by author. Root delegated sole actual execution to viewer_survey after source review: NODE_PATH=/workspace/shared/chicago-browser/node_modules node probe.cjs --root-browser-release --out FRESH_DIR, approved socket/Chromium environment.120s ownserver/browser cleanup, actualDirectperpass rows,12off/on/restored pairs bothviews×Full/Balanced×plain/tint/ghost, explicit caughtLight refusal, start/middle/endroutePNGs,120timing samples/view and actualGLlimits. First unexpected error/cost/restoration stops; no retries or errors filtered. Author must not start duplicate browser.
