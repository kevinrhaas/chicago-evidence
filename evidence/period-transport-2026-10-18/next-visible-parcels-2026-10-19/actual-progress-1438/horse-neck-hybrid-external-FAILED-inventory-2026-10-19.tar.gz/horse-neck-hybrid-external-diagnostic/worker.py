from pathlib import Path
import sys,json,hashlib
src=Path('/workspace/shared/horse-neck-hybrid-pipeline-next');sys.path.insert(0,str(src))
from hybrid_chain import load_chain
from hybrid_scope import patch_ownership
from ownership import triangle_labels
from check_idle import load_capture,world_aliases,scan
out=Path(__file__).parent
packet=Path('/workspace/shared/horse-neck-hybrid-first-local-trial/payload/packet.json');packetsha='cb6987a5403bf4b83f9c644203936bf181d1b4a38c24e0e76246d2d51f3d41aa'
for f,h in json.loads((src/'operator-source-pins.json').read_text()).items():
 if hashlib.sha256(Path(f).read_bytes()).hexdigest()!=h:raise ValueError('source changed '+f)
v=load_chain(packet,packetsha,Path('/workspace/shared/horse-head-groove-coat-next/trial1'),Path('/workspace/shared/horse-ear-root-exporter-source-reviewed-next/export-trial1'),Path('/workspace/shared/horse-ear-root-exporter-source-reviewed-next/source-trial1/candidate-source-edit.json'))
m,labels,head,owners=v['neck_candidate'];records=triangle_labels(m,labels);selected,internal,external=patch_ownership(m,records,v['proof']);meta,data,_=load_capture(Path('/workspace/shared/horse-neck-hybrid-first-idle-trial/capture'),'neck_candidate',m,v['neck_sha256']);world_aliases(records,data)
(out/'declared-scope.json').write_text(json.dumps({'status':'FAILED candidate diagnostic inventory ONLY; original FIRSTFAIL preserved','packet_sha256':packetsha,'candidate_sha256':v['neck_sha256'],'actual_capture_buffer_sha256':meta['buffer_sha256'],'selected1492':sorted(selected),'targets':'ALL remaining active horse triangles','no_new_capture_or_export':True},indent=2)+'\n')
r=scan('FAILED_hybrid1492_inventory','head_vs_all_rest',m,records,selected,data,external,out,False,declared_scope='FAILED diagnostic COMPLETE1492 vs ALLotheractivehorse; NO acceptance/waiver')
summary={}
for w in r['unexpected_witnesses']:
 key=w['b_owner']['mesh_name']+':material'+str(w['b_owner']['material']);row=summary.setdefault(key,{'unexpected':0,'proper':0,'actual_primitive_triangles':set()});row['unexpected']+=1;row['proper']+=int(w['kind']=='unexpected_strict_proper');row['actual_primitive_triangles'].add(w['b_owner']['primitive_triangle'])
for row in summary.values():row['actual_primitive_triangles']=sorted(row['actual_primitive_triangles'])
(out/'summary.json').write_text(json.dumps({'status':'FAILED diagnostic ONLY','complete':r['complete'],'counts':r['counts'],'semantic_parts':summary},indent=2)+'\n')
