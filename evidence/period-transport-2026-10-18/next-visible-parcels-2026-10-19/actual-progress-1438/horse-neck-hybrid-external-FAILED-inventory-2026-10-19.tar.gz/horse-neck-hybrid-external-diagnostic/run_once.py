from pathlib import Path
import subprocess,time,os,signal,json
start=time.monotonic();out=Path(__file__).parent
with(out/'stdout.log').open('xb')as a,(out/'stderr.log').open('xb')as b:
 p=subprocess.Popen(['/workspace/shared/chicago-venv/bin/python',str(out/'worker.py')],stdout=a,stderr=b,start_new_session=True)
 try:code=p.wait(timeout=90-(time.monotonic()-start))
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();code=124
(out/'operator-receipt.json').write_text(json.dumps({'status':'FAILED CANDIDATE diagnostic ONLY; no acceptance','returncode':code,'elapsed_s':time.monotonic()-start,'cap_s':90,'no_new_capture_or_export':True},indent=2)+'\n')
raise SystemExit(code)
