// SPDX-License-Identifier: GPL-3.0-or-later
import * as T from'three';
const need=(x,m)=>{if(!x)throw Error(m);};
function fitPlane(points){const a=Array.from({length:3},()=>[0,0,0,0]);for(const [x,z,h]of points){const v=[x,z,1];for(let i=0;i<3;i++){for(let j=0;j<3;j++)a[i][j]+=v[i]*v[j];a[i][3]+=v[i]*h;}}for(let k=0;k<3;k++){let pivot=k;for(let i=k+1;i<3;i++)if(Math.abs(a[i][k])>Math.abs(a[pivot][k]))pivot=i;[a[k],a[pivot]]=[a[pivot],a[k]];need(Math.abs(a[k][k])>1e-12,'support plane rank');const d=a[k][k];for(let j=k;j<4;j++)a[k][j]/=d;for(let i=0;i<3;i++)if(i!==k){const s=a[i][k];for(let j=k;j<4;j++)a[i][j]-=s*a[k][j];}}return a.map(row=>row[3]);}
export function sampleGroundFrame({e,n,bearing,contacts,field,maxResidualM=.005}){
 const yaw=Math.PI-bearing,rotation=new T.Matrix4().makeRotationY(yaw),samples=[];
 for(const [x,,z]of contacts){const p=new T.Vector3(x,0,z).applyMatrix4(rotation),pe=e+p.x,pn=n-p.z;need(field.contains(pe,pn),'support outside measured epoch');const h=field.sample(pe,pn);need(Number.isFinite(h)&&h>=-.10,'support water/nonfinite');samples.push([x,z,h]);}
 const [a,b,c]=fitPlane(samples);need(Math.hypot(a,b)<=.08,'reconstructed study grade limit8percent');
 const normal=new T.Vector3(-a,1,-b).normalize().transformDirection(rotation),forward=new T.Vector3(0,0,1).transformDirection(rotation);forward.addScaledVector(normal,-forward.dot(normal)).normalize();const left=new T.Vector3().crossVectors(normal,forward).normalize(),matrix=new T.Matrix4().makeBasis(left,normal,forward),q=new T.Quaternion().setFromRotationMatrix(matrix);
 const rotated=contacts.map(p=>new T.Vector3(...p).applyQuaternion(q));let y=0;
 for(const p of rotated){const pe=e+p.x,pn=n-p.z;need(field.contains(pe,pn)&&field.sample(pe,pn)>=-.10,'rotated support water/outside grid');y+=field.sample(pe,pn)-p.y;}y/=rotated.length;
 const errors=rotated.map(p=>Math.abs(y+p.y-field.sample(e+p.x,n-p.z)));need(Math.max(...errors)<=maxResidualM,'actual sampled support residual exceeds5mm');
 return{world_position:[e,y,-n],world_quaternion:q.toArray(),maximum_sampled_contact_residual_m:Math.max(...errors),local_grade:[a,b],scope:'rigid sampled support plane; actual animated hoof sole/continuous contact remains unqualified'};
}
export function localRootENU(e,n,bearing,[x,,z]){return[e-x*Math.cos(bearing)+z*Math.sin(bearing),n+x*Math.sin(bearing)+z*Math.cos(bearing)];}
