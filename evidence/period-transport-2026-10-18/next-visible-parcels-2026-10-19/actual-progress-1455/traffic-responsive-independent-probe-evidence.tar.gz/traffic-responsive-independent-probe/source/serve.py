# SPDX-License-Identifier: GPL-3.0-or-later
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import argparse
ROOT=Path(__file__).resolve().parent;APP=Path('/workspace/chicago/chicago/4d')
class Handler(SimpleHTTPRequestHandler):
 def translate_path(self,path):
  from urllib.parse import unquote,urlsplit
  p=unquote(urlsplit(path).path);base=ROOT;relative=p.lstrip('/')
  for prefix,target in [('/web/',APP/'renderers/web'),('/data/',APP/'data')]:
   if p.startswith(prefix):base=target;relative=p[len(prefix):];break
  f=(base/relative).resolve();return str(f)if f.is_relative_to(base.resolve())else'/dev/null'
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--port',type=int,default=8797);a=ap.parse_args();ThreadingHTTPServer(('127.0.0.1',a.port),Handler).serve_forever()
