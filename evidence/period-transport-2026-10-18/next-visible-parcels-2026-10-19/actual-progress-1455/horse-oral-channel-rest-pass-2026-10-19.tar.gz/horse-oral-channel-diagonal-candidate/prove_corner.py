# SPDX-License-Identifier: CC0-1.0
"""Read-only source chart proof; does not generate or alter model geometry."""
from pathlib import Path
import json,hashlib,itertools
P=Path(__file__).parent
f=Path('/workspace/shared/horse-oral-channel-candidate/candidate-one/head-source-surface.json');raw=f.read_bytes()
if hashlib.sha256(raw).hexdigest()!='32c5b270c34f93fc9a62f3b95f583f713fc3adf2902e3ac35673963eed3265b9':raise ValueError('source pin')
s=json.loads(raw);p={i:[s['positions'][i][0],s['positions'][i][2]]for i in [626,625,577,1032,1033,1034]}
def orient(a,b,c):return(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def area(q):return sum(a[0]*b[1]-a[1]*b[0]for a,b in zip(q,q[1:]+q[:1]))/2
boundary=[626,625,577,1034,1033,1032];old=[[626,625,1033],[626,1033,1032],[625,577,1034],[625,1034,1033]];new=[[626,625,1033],[626,1033,1032],[625,577,1033],[577,1034,1033]]
for i in range(6):
 for j in range(i+1,6):
  if j==i+1 or(i==0 and j==5):continue
  a,b=p[boundary[i]],p[boundary[(i+1)%6]];c,d=p[boundary[j]],p[boundary[(j+1)%6]]
  if orient(a,b,c)*orient(a,b,d)<=0 and orient(c,d,a)*orient(c,d,b)<=0:raise ValueError('non-simple boundary')
def clip(q,tri):
 for a,b in zip(tri,tri[1:]+tri[:1]):
  result=[]
  for c,d in zip(q,q[1:]+q[:1]):
   u,v=orient(a,b,c),orient(a,b,d)
   if u>=0:result.append(c)
   if(u<0)!=(v<0):result.append([c[k]+(d[k]-c[k])*u/(u-v)for k in range(2)])
  q=result
  if not q:break
 return q
newareas=[orient(*(p[i]for i in face))/2 for face in new]
if min(newareas)<=1e-10:raise ValueError('nonpositive graph triangle')
pairs=[]
for i,j in itertools.combinations(range(4),2):
 q=clip([p[k]for k in new[i]],[p[k]for k in new[j]]);overlap=abs(area(q))if len(q)>=3 else 0.
 if overlap>1e-16:raise ValueError('projected triangle interior overlap')
 pairs.append({'faces':[i,j],'intersection_area_m2':overlap})
unionarea=area([p[i]for i in boundary])
if abs(sum(newareas)-unionarea)>1e-16:raise ValueError('coverage area mismatch')
r={'PASS':True,'scope':'numeric XZ local six-boundary simple polygon, positive graph triangulation and full pairwise interior nonoverlap. Not whole-head/bit/posed proof.','frozen_candidate_source_sha256':hashlib.sha256(raw).hexdigest(),'boundary':boundary,'projected_coordinates':p,'old_faces':old,'old_signed_area_m2':[orient(*(p[i]for i in face))/2 for face in old],'replacement_faces':new,'replacement_signed_area_m2':newareas,'boundary_area_m2':unionarea,'new_pairwise_intersections':pairs,'old_to_new_ownership':'Only source connector edge625→577 oldfaces1856/1857 are retriangulated; all vertex coordinates and exterior boundary edges exact. Normals only within already-declared authority.'}
(P/'CORNER-PROOF.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
