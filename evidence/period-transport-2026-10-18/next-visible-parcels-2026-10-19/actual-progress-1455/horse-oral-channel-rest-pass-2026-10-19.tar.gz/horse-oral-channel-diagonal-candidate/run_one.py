# SPDX-License-Identifier: CC0-1.0
"""ONE source-pinned exclusive fresh candidate, no retry or parameter search."""
from pathlib import Path
import json,hashlib,subprocess,sys,time,traceback,signal
P=Path(__file__).parent
started=time.monotonic();result={'PASS':False,'scope':'ONE oral original geometry candidate, source-rest only; paired posed fit untested','stages':[]}
def persist():(P/'trial-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
def alarm(*_):raise TimeoutError('120s TOTAL trial bound')
signal.signal(signal.SIGALRM,alarm);signal.alarm(120)
try:
 inventory=json.loads((P/'SOURCE-HASHES.json').read_text())
 for name,sha in inventory.items():
  if hashlib.sha256((P/name).read_bytes()).hexdigest()!=sha:raise ValueError('source hash mismatch '+name)
 (P/'candidate-one').mkdir(exist_ok=False)
 for stage,cmd,cap in [
 ('build',[sys.executable,str(P/'source/generate_horse.py'),'--output-dir',str(P/'candidate-one')],25),
 ('decoded_protected_and_new_source_binding',[sys.executable,str(P/'check_protected_glb.py')],10),
 ('rest_embedding_and_full_bit_clearance',[sys.executable,str(P/'check_rest.py')],90)]:
  before=time.monotonic()
  with (P/(stage+'.stdout')).open('xb')as out,(P/(stage+'.stderr')).open('xb')as err:
   r=subprocess.run(cmd,stdout=out,stderr=err,timeout=min(cap,max(.001,119-(time.monotonic()-started))))
  result['stages'].append({'name':stage,'exit':r.returncode,'elapsed_s':time.monotonic()-before});persist()
  if stage=='build' and r.returncode==0:
   (P/'build-result.json').write_text(json.dumps({'source_inventory_sha256':hashlib.sha256((P/'SOURCE-HASHES.json').read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256((P/'candidate-one/equine_light_harness_skinned_prototype_01.glb').read_bytes()).hexdigest(),'head_source_sha256':hashlib.sha256((P/'candidate-one/head-source-surface.json').read_bytes()).hexdigest()},indent=2)+'\n')
  if r.returncode:raise RuntimeError('trial STOP '+stage+' exit '+str(r.returncode))
 result['PASS']=True
except BaseException as e:
 result['error']=repr(e);result['traceback']=traceback.format_exc()
finally:
 signal.alarm(0);result['elapsed_s']=time.monotonic()-started;persist()
print(json.dumps(result));sys.exit(0 if result['PASS']else 2)
