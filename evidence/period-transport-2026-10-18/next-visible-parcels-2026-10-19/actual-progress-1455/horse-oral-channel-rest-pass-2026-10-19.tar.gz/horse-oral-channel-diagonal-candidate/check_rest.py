# SPDX-License-Identifier: GPL-3.0-or-later
"""Actual candidate source REST only. Unchanged SAT/proper; no posed pair fit."""
from pathlib import Path
import json,hashlib,struct,signal,time
import numpy as np
import sys
sys.path.insert(0,str(Path(__file__).parent))
import official_fit_predicates as pred
from unsigned_distance import distances
P=Path(__file__).parent;R=P;O=P/'candidate-one';started=time.monotonic();rows={};report={'PASS':False,'checks':rows,'scope':'Sourcecandidate rest embedding/fullbit-side+virtualcap clearance; no posed actualpair proof'}
def save():report['elapsed_s']=time.monotonic()-started;(R/'rest-geometry-result.json').write_text(json.dumps(report,indent=2)+'\n')
def require(c,msg):
 if not c:raise ValueError(msg)
def timeout(*_):raise TimeoutError('90second rest checker bound')
signal.signal(signal.SIGALRM,timeout);signal.alarm(90)
try:
 build=json.loads((P/'build-result.json').read_text());require(build['source_inventory_sha256']==hashlib.sha256((P/'SOURCE-HASHES.json').read_bytes()).hexdigest(),'build source inventory binding');require(build['candidate_sha256']==hashlib.sha256((O/'equine_light_harness_skinned_prototype_01.glb').read_bytes()).hexdigest() and build['head_source_sha256']==hashlib.sha256((O/'head-source-surface.json').read_bytes()).hexdigest(),'exact built candidate/source pin')
 link=json.loads((R/'protected-glb-result.json').read_text());require(link.get('PASS')is True and link['candidate_sha256']==hashlib.sha256((O/'equine_light_harness_skinned_prototype_01.glb').read_bytes()).hexdigest() and link['source_sha256']==hashlib.sha256((O/'head-source-surface.json').read_bytes()).hexdigest(),'decoded source binding required')
 s=json.loads((O/'head-source-surface.json').read_text());base=json.loads((P/'source/frozen-head.json').read_text());v=(np.array(s['positions'],dtype='<f4').astype(float)+[0,1.88,.8]).astype('<f4').astype(float);f=np.array(s['faces']);t=v[f];lo=t.min(1);hi=t.max(1);hits=[]
 for i,a in enumerate(t):
  ix=np.flatnonzero(np.all(hi>=a.min(0)-1e-8,axis=1)&np.all(lo<=a.max(0)+1e-8,axis=1)&(np.arange(len(t))>i))
  for j in ix:
   if len(set(f[i])&set(f[j]))>=2:continue
   if pred.sat(a,t[j]):
    proper=pred.proper(a,t[j])
    if proper:hits.append({'a':i,'b':int(j),'source_owners':[s['source_owners'][i],s['source_owners'][j]],'proper':proper})
 rows['actual_float32_head_source_self']={'strict_crossings':len(hits),'witnesses':hits};save();require(not hits,'neworal head self-crosses')
 # Full frozenactualbit sides; virtual endcaps onlyclose its analysis volume.
 gear=Path('/workspace/shared/horse-hindgear-support-hull-candidate/candidate-one/light_breastcollar_harness_reconstructed_01.glb');require(hashlib.sha256(gear.read_bytes()).hexdigest()=='fe76c95b49234da64700a1e20741b4998e8cfbae69571387d49bf5bb23ef04b1','wrongbitinput')
 bit=np.array([a for name,i,a in pred.load(gear)if name=='bit_bar']);require(len(bit)==32,'full32bit sides');hits=[]
 for i,a in enumerate(bit):
  ix=np.flatnonzero(np.all(hi>=a.min(0)-1e-8,axis=1)&np.all(lo<=a.max(0)+1e-8,axis=1))
  for j in ix:
   if pred.sat(a,t[j]):hits.append({'bit_triangle':i,'head_face':int(j),'owner':s['source_owners'][j],'proper':pred.proper(a,t[j])})
 rows['actual_bit_sides_vs_head']={'raw_SAT_pairs':len(hits),'proper_crossings':sum(bool(x['proper'])for x in hits),'witnesses':hits};save();require(not hits,'actualbit sides intersectnewhead')
 minimum=min(float(distances(a,t).min())for a in bit);rows['actual_full_side_surface_minimum_unsigned_m']=minimum;save();require(np.isfinite(minimum)and minimum>.001,'fullside positive1mm engineering clearance unmet')
 # Close onlyvalidationbitvolume with virtualcap triangles at actualeightvertex endrings.
 unique=np.unique(bit.reshape(-1,3),axis=0);virtual=[]
 for center in [np.array([-.105,1.68,1.19]),np.array([.105,1.68,1.19])]:
  order=np.argsort(np.linalg.norm(unique-center,axis=1))[:8];ring=unique[order];direction=np.array([1.,0,0]);a=np.array([0.,1,0]);b=np.cross(direction,a);theta=np.arctan2((ring-center)@b,(ring-center)@a);ring=ring[np.argsort(theta)]
  for p,q in zip(ring,np.roll(ring,-1,axis=0)):virtual.append(np.array([center,p,q]))
 capmin=min(float(distances(a,t).min())for a in virtual);rows['virtual_bit_endcaps']={'triangles':16,'minimum_to_head_m':capmin,'semantics':'analysis-only endcaps, NOTemittedactualbit'};require(capmin>.001,'virtual endcap clearance')
 # Cavity interval is a meaningful engineeringvolume for centralbit region; neckvirtualcap permits closedsolid parity below.
 portal=s['portal'];uses={}
 for face in s['faces']:
  for a,b in zip(face,face[1:]+face[:1]):uses.setdefault(tuple(sorted((a,b))),[]).append((a,b))
 edges=[u[0]for u in uses.values()if len(u)==1];center=v[portal].mean(0);cap=np.array([[center,v[b],v[a]]for a,b in edges]);closed=np.concatenate([t,cap]);samples=np.concatenate([unique,bit.mean(1),np.array([[0,1.675,1.20]])]);ambiguous=inside=0
 def parity(point,d):
  e1=closed[:,1]-closed[:,0];e2=closed[:,2]-closed[:,0];pv=np.cross(d,e2);det=(e1*pv).sum(1);iv=np.divide(1,det,out=np.zeros_like(det),where=abs(det)>1e-13);tv=point-closed[:,0];u=(tv*pv).sum(1)*iv;q=np.cross(tv,e1);w=q@d*iv;distance=(e2*q).sum(1)*iv;mask=(abs(det)>1e-13)&(u>=0)&(w>=0)&(u+w<=1)&(distance>1e-8)
  if np.any(mask&((u<1e-7)|(w<1e-7)|(1-u-w<1e-7))):return None
  return int(mask.sum()%2)
 outcomes=[]
 for point in samples:
  values=[parity(point,np.array(d)/np.linalg.norm(d))for d in [[1,.371,.113],[-.19,.91,.137],[.21,-.31,.93]]];valid=[x for x in values if x is not None];require(len(valid)>=2 and len(set(valid))==1,'ambiguous virtualclosed-head inside classification');outcomes.append(valid[0])
 rows['virtual_closed_head_bit_samples']={'samples':len(samples),'inside_head_material':sum(outcomes),'virtual_neck_cap_triangles':len(cap),'semantics':'analysis-only neckcap; emittedhead rearportal remainsopen; classification not actualpairedanimation'};save();require(not any(outcomes),'bit samples insidehead material')
 report['PASS']=True;save();print(json.dumps({k:v for k,v in report.items()if k!='checks'}))
except Exception as e:report['error']=repr(e);save();raise
finally:signal.alarm(0)
