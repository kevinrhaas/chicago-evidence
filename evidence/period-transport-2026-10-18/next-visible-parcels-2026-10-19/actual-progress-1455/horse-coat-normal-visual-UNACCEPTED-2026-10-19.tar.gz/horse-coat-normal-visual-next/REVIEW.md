# Actual twelve-frame normal-only A/B

All twelve desktop/mobile before/after profile, frontquarter and whole-horse images were inspected. Actual1eee and03884 bytes verified by browser SHA; cameras/targets/light/pose/exposure match. Zero request/page/console/GL errors; owned browser/server closed in finally.

Frontquarter views show the long hard shaded strip behind the jaw down the front side of the neck substantially reduced. The cheek/throat surface now reads more continuously, with exactly unchanged silhouette and collision geometry. At whole-horse distance the change is modest but visible in neck shading.

Profile still has an angular poll/ear-root region and a broad faceted head/neck outline. The new normal field does not solve those geometric contours. Protected ear-root normals remain unchanged, deliberately avoiding a false smooth blend across inner-ear materials. Eyes, thin ears, muzzle, rigid roached crest, legs and tail remain primitive. No photographic/anatomical/groom acceptance is claimed.

No collision sweep was rerun: independent decodedP/index/JW/rig proof establishes identical deformation geometry. Existing1eee idle CPU scope remains the only mechanical study evidence, with all original failure archives preserved. Root must inspect images before adopting this normal-only component; no source app/model integration.
