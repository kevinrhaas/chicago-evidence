# SPDX-License-Identifier: CC0-1.0
"""Normal-only original quality study. Indexed component ownership, no position weld."""
from pathlib import Path
import sys,json,hashlib,copy
import numpy as np
sys.path.insert(0,'/workspace/shared/horse-mane-fitted-next')
from mane_chain import load
from ownership import Model,ATTRS
from glb_data import append,encode
from sparse_rules import require
PARENT=Path('/workspace/shared/horse-mane-fitted-first-local-trial/payload/packet.json');PACKET='5f716ee2583aad96c2e0c8c1107e91f9d4d511f717683b8274eab04d1c1dd23a';GLB='1eee14e7d80ef8dcbe7e9d2ab3250cc7ea711a74f4cda730dd4b2af954cfcd89'

def area_normals(p,indices,old,labels=None,protected=()):
 p=np.asarray(p,dtype=float);faces=np.asarray(indices,dtype=int);tri=p[faces];area=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);require(np.isfinite(area).all()and np.all(np.linalg.norm(area,axis=1)>2e-12),'Actualactivecoat triangles finite/nondegenerate');active=sorted(set(map(int,faces.ravel())));acc=np.zeros_like(p)
 names={i:labels[i]if labels is not None else str(i)for i in active};groups={}
 for i in active:groups.setdefault(names[i],[]).append(i)
 for name,ids in groups.items():require(all(np.array_equal(p[i],p[ids[0]])for i in ids),'Namedsourcealiases POSITIONexact')
 grouped={name:np.zeros(3)for name in groups}
 for face,vector in zip(faces,area):
  tags=[names[int(i)]for i in face];require(len(set(tags))==3,'No self-aliased activeface')
  for tag in tags:grouped[tag]+=vector
 for name,ids in groups.items():acc[ids]=grouped[name]
 length=np.linalg.norm(acc[active],axis=1);require(np.isfinite(length).all()and np.all(length>1e-12),'Orientedincident sums finite/nonzero');result=np.asarray(old).copy();result[active]=(acc[active]/length[:,None]).astype(result.dtype);result[list(protected)]=np.asarray(old)[list(protected)];return result,[i for i in active if i not in set(protected)]

def audit(oldraw,newraw,intended,active,labels):
 a,b=Model(oldraw),Model(newraw);require(a.total==b.total==13016 and set(a.views)==set(b.views),'Unchangedtriangle/primitivecounts')
 for key,v in a.views.items():
  w=b.views[key];require(v['material']==w['material']and v['mesh_name']==w['mesh_name']and np.array_equal(v['indices'],w['indices']),'Allowners/indices exact')
  for attr in ATTRS:
   x,y=v['attributes'][attr],w['attributes'][attr]
   if key==(0,0)and attr=='NORMAL':require(np.array_equal(y,intended),'Actualserializedintendednormalfield')
   else:require(x.tobytes()==y.tobytes(),'ALLprotectedP/JW/otherattribute bytes exact')
 # Independent vertex-incident loop, not the vectorized producer scatter.
 p=a.views[0,0]['attributes']['POSITION'].astype(float);idx=a.views[0,0]['indices'];inc={labels[v]:[]for v in active};groupids={}
 for v in active:groupids.setdefault(labels[v],[]).append(v)
 for fi,face in enumerate(idx):
  x,y,z=p[face];cross=np.cross(y-x,z-x)
  for v in face:
   if labels[int(v)]in inc:inc[labels[int(v)]].append(cross)
 expected=a.views[0,0]['attributes']['NORMAL'].copy()
 for name,rows in inc.items():
  q=np.zeros(3)
  for row in rows:q+=row
  q/=np.linalg.norm(q)
  for v in groupids[name]:expected[v]=q.astype('<f4')
 require(np.array_equal(expected,intended),'Independentincidentnormalreadback')
 mask=np.ones(len(expected),bool);mask[active]=False;require(expected[mask].tobytes()==a.views[0,0]['attributes']['NORMAL'][mask].tobytes(),'InactiveNunchanged')
 d,e=a.d,b.d;na,nv=len(d['accessors']),len(d['bufferViews']);require(len(e['accessors'])==na+1 and len(e['bufferViews'])==nv+1 and e['accessors'][:na]==d['accessors']and e['bufferViews'][:nv]==d['bufferViews'],'OnlyoneappendedNstorage');require(bytes(b.b[:len(a.b)])==bytes(a.b),'OriginalBINprefix exact');ref=e['meshes'][0]['primitives'][0]['attributes']['NORMAL'];require(ref==na and e['accessors'][ref]['bufferView']==nv,'Actualnewnormalaccessorref');ac=e['accessors'][ref];require(ac=={'bufferView':nv,'componentType':5126,'count':len(intended),'type':'VEC3','min':intended.min(0).tolist(),'max':intended.max(0).tolist()},'ExactnewNaccessormetadata');require(e['bufferViews'][nv]=={'buffer':0,'byteOffset':len(a.b),'byteLength':intended.nbytes,'target':34962}and len(b.b)==len(a.b)+intended.nbytes==e['buffers'][0]['byteLength'],'ExactnewNviewandBINextent');x,y=copy.deepcopy(d),copy.deepcopy(e)
 for doc in[x,y]:
  doc['meshes'][0]['primitives'][0]['attributes'].pop('NORMAL');doc.pop('accessors');doc.pop('bufferViews');doc['buffers'][0].pop('byteLength')
 require(x==y,'Allrig/material/document exact');return{'all_POSITION_indices_JOINTS_WEIGHTS_rig_exact':True,'all_other_material_attributes_exact':True,'inactive_N_exact':True,'independent_activecoat_incident_normals_exact':True,'collision_geometry_identical_no_repeat_SAT':True}

def run(out):
 out=Path(out);out.mkdir(parents=True,exist_ok=False);v=load(PARENT,PACKET);oldraw=(PARENT.parent/'candidate.glb').read_bytes();require(hashlib.sha256(oldraw).hexdigest()==GLB,'ActualparentSHA');m=Model(oldraw);view=m.views[0,0];require(view['material']==0,'Coat0only');source_labels=v['neck_candidate'][1];labels={i:source_labels.get((0,i),'body:0:'+str(i))for i in range(len(view['attributes']['POSITION']))};groups={}
 for i in sorted(set(map(int,view['indices'].ravel()))):groups.setdefault(labels[i],[]).append(i)
 for label,ids in groups.items():
  for attr in['POSITION','JOINTS_0','WEIGHTS_0']:require(all(view['attributes'][attr][i].tobytes()==view['attributes'][attr][ids[0]].tobytes()for i in ids),'Actual sourcealias P/JWbytes:'+label+':'+attr)
 otherlabels=set()
 for key,other in m.views.items():
  if key==(0,0):continue
  for i in set(map(int,other['indices'].ravel())):otherlabels.add(source_labels.get((key[0],i),'body:'+str(key[0])+':'+str(i)))
 protected={i for i,label in labels.items()if label in otherlabels};earowners={g for g,row in v['neck_candidate'][3].items()if row.get('kind')in['baseline_ear','radial_bridge','skull_complement']}
 for g in earowners:
  desc=m.descriptor(g)
  if desc['mesh']==0:protected.update(desc['primitive_vertices'])
 protected &= set(map(int,view['indices'].ravel()))
 normal,active=area_normals(view['attributes']['POSITION'],view['indices'],view['attributes']['NORMAL'],labels,protected);d=copy.deepcopy(m.d);b=bytearray(m.b);ref=append(d,b,normal,'VEC3');d['meshes'][0]['primitives'][0]['attributes']['NORMAL']=ref;raw=encode(d,b);(out/'UNVALIDATED-candidate.glb').write_bytes(raw);proof=audit(oldraw,raw,normal,active,labels);oldn=view['attributes']['NORMAL'].astype(float);newn=normal.astype(float);dot=np.sum(oldn[active]*newn[active],axis=1)/(np.linalg.norm(oldn[active],axis=1)*np.linalg.norm(newn[active],axis=1));angle=np.degrees(np.arccos(np.clip(dot,-1,1)));changed=np.flatnonzero(np.any(normal!=view['attributes']['NORMAL'],axis=1));proof.update(status='NORMALONLYqualitystudy UNACCEPTED appearance',parent_sha256=GLB,parent_packet_sha256=PACKET,output_sha256=hashlib.sha256(raw).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),active_coat_vertices=active,changed_normal_vertices=changed.tolist(),normal_angle_max_degrees=float(angle.max()),normal_angle_p95_degrees=float(np.quantile(angle,.95)),normal_method='orientedareaweighted; pinned samecoat sourcealias incidence, exact P/JW; no crossmaterial/positionwelding',shared_source_groups={k:ids for k,ids in groups.items()if len(ids)>1},protected_ear_and_crossmaterial_normal_vertices=sorted(protected),normal_scope='activecoat/headneck EXCLUDING ear/source-ear-root and declaredcrossmaterialboundaries',not_run=['visual','63poses','newgearfit']);(out/'candidate.glb').write_bytes(raw);(out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:proof[k]for k in['output_sha256','normal_angle_max_degrees','normal_angle_p95_degrees']}))
if __name__=='__main__':run(sys.argv[1])
