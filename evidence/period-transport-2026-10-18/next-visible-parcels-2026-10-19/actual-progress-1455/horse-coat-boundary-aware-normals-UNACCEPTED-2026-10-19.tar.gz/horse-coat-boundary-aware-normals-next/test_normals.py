import unittest,numpy as np
from normal_variant import area_normals
class NormalTests(unittest.TestCase):
 def test_oriented_planar(self):
  p=np.array([[0,0,0],[1,0,0],[1,1,0],[0,1,0]],dtype='<f4');n,ids=area_normals(p,[[0,1,2],[0,2,3]],np.zeros_like(p));self.assertTrue(np.array_equal(n,np.tile([0,0,1],(4,1))));self.assertEqual(ids,[0,1,2,3])
 def test_no_position_welding(self):
  p=np.array([[0,0,0],[1,0,0],[0,1,0],[0,0,0],[0,0,1],[1,0,0]],dtype='<f4');n,ids=area_normals(p,[[0,1,2],[3,4,5]],np.zeros_like(p));self.assertTrue(np.array_equal(n[0],[0,0,1]));self.assertTrue(np.array_equal(n[3],[0,1,0]))
 def test_declared_alias_shares_only_its_field(self):
  p=np.array([[0,0,0],[1,0,0],[0,1,0],[0,0,0],[0,0,1],[1,0,0]],dtype='<f4');labels={i:str(i)for i in range(6)};labels[3]=labels[0];n,ids=area_normals(p,[[0,1,2],[3,4,5]],np.zeros_like(p),labels);self.assertTrue(np.array_equal(n[0],n[3]));self.assertTrue(np.allclose(n[0],[0,2**-.5,2**-.5]));self.assertTrue(np.array_equal(n[1],[0,0,1]))
 def test_false_alias_refused(self):
  p=np.array([[0,0,0],[1,0,0],[0,1,0]],dtype='<f4')
  with self.assertRaises(ValueError):area_normals(p,[[0,1,2]],np.zeros_like(p),{0:'a',1:'a',2:'c'})
 def test_declared_material_boundary_preserved(self):
  p=np.array([[0,0,0],[1,0,0],[0,1,0]],dtype='<f4');old=np.array([[1,0,0]]*3,dtype='<f4');n,ids=area_normals(p,[[0,1,2]],old,protected=[0]);self.assertTrue(np.array_equal(n[0],old[0]));self.assertEqual(ids,[1,2]);self.assertTrue(np.array_equal(n[1],[0,0,1]))
 def test_inactive_preserved(self):
  p=np.array([[0,0,0],[1,0,0],[0,1,0],[0,0,2]],dtype='<f4');old=np.array([[1,0,0]]*4,dtype='<f4');n,ids=area_normals(p,[[0,1,2]],old);self.assertTrue(np.array_equal(n[3],old[3]));self.assertTrue(np.array_equal(old,np.array([[1,0,0]]*4)))
 def test_degenerate_refused(self):
  p=np.array([[0,0,0],[1,0,0],[2,0,0]],dtype='<f4')
  with self.assertRaises(ValueError):area_normals(p,[[0,1,2]],np.zeros_like(p))
if __name__=='__main__':unittest.main()
