# Normal-only coat/head/neck quality variant

Parent1eee remains immutable. Candidate03884 changes only the active material0 coat/head/neck NORMAL field. All POSITION, triangle indices, JOINTS, WEIGHTS, rig/actions/IBMs, other materials and original BIN/storage prefix remain exact. No collision test was repeated because actual decoded collision geometry and deformation inputs are byte-identical.

Oriented area-weighted incidence uses source-owned same-coat labels with exact P/JW guards, never nearest-position welding. All source ear/ear-root owner vertices (baseline_ear, radial_bridge, skull_complement) and coat aliases used in another active material are explicitly protected. This respects the eye/nose/ear boundaries; no normal averaging across materials. Inactive normals remain exact. Every eligible serialized normal equals an independent incident-face summation. One NORMAL accessor/view is appended; all other document/storage fields are preserved.

Seven synthetic controls pass: oriented area, independent coincident surfaces stay separate, declared source-alias grouping, false alias refusal, inactive preservation, material-boundary preservation, degenerate refusal. Actual readback PASS; Khronos0errors/0warnings. Max eligible normal-angle change30.99635deg;95thpercentile0.00012782deg, showing the field mostly preserves existing smooth regions while repairing obsolete changed-surface normals.

The earlier broad material0 trial90fb is preserved in archives40cf6115/20dfaca3 and was not rendered: its source scope included ear-root material-boundary fragments, producing111deg changes. The refined boundary-aware proposal protects that region rather than blending unrelated materials or treating the fragment normal as a body repair.

This is not silhouette/anatomical/groom/photographic acceptance. Cuyer1905 Fig92/70/40 and the cleared Muybridge1878 sheet were actually opened for a future shape proposal; they provide qualitative anatomy and silhouette, not measured breed geometry or coat/eye photographic texture. Root may compare matched1eee/03884 renders after independent review. No app/model integration.
