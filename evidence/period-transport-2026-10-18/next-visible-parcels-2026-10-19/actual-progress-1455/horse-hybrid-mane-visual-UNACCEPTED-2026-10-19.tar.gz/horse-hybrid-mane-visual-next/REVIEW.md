# Actual twelve-frame review — intermediate reconstruction only

I inspected every saved before/after desktop/mobile profile, frontquarter and whole-horse PNG. Matching cameras/targets, lighting, idle0 and exposure are retained; assets verified by actual browser SHA256. No gear is present. Browser/server closed in finally; twelve captures, zero request/page/console/GL errors.

The rear jaw/neck attachment has a continuous silhouette rather than the former squared, detached-looking overlap. This accompanies the actual idle self-embedding improvement; it does not establish anatomical/photo acceptance. A hard polygonal shading strip remains behind the cheek and along the throat/neck join. The old boundary normals were explicitly preserved, so the new incident surface may need a separately reviewed normal-halo repair; these images alone do not prove the sole cause.

The new narrow dark crest is visible and follows the neck, rather than remaining partly buried in it. It still reads as a rigid raised ridge, not convincing individual hairs or a finished groom. A fine light root line is visible in close profile. The reconstructed25mm short/roached mass, root stand-off and appearance remain unaccepted. No physical attachment/period-groom claim is made.

Whole-horse views still show long tubular lower legs, abrupt joint/pastern transitions, simple hooves, thin flat tail and broadly primitive body/head shading. Eyes and muzzle remain simplified; the actual overall result is far below photographic quality. Desktop/mobile full-horse frames include the complete active horse; detail views intentionally crop unrelated torso/legs and are labelled HEAD DETAIL.

No63-pose, gear/saddle/rider or production gate is inferred. Existing260parent attachment/neck failures are preserved; the new1eee candidate has bounded idle-only CPU pass. No geometry or source-app edits occurred during this single visual study.
