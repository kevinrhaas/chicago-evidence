# SPDX-License-Identifier: GPL-3.0-or-later
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import argparse
ROOT=Path(__file__).resolve().parent;WEB=Path('/workspace/chicago/chicago/4d/renderers/web')
class Handler(SimpleHTTPRequestHandler):
 def translate_path(self,path):
  from urllib.parse import unquote,urlsplit
  p=unquote(urlsplit(path).path)
  if p=='/baseline.glb':return str(WEB/'transport/carriage-c02/carriage-c02.glb')
  if p=='/candidate.glb':return'/workspace/shared/c02-driver-cushion-candidate-one/carriage-c02.glb'
  if p.startswith('/web/'):base=WEB;relative=p[5:]
  else:base=ROOT;relative=p.lstrip('/')
  f=(base/relative).resolve();return str(f)if f.is_relative_to(base.resolve())else'/dev/null'
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--port',type=int,default=8798);a=ap.parse_args();ThreadingHTTPServer(('127.0.0.1',a.port),Handler).serve_forever()
