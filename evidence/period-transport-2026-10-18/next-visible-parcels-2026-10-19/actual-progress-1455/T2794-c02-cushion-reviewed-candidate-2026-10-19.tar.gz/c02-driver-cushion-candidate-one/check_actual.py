import json,struct,hashlib
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np
ROOT=Path(__file__).parent
INPUT=Path('/workspace/chicago/chicago/4d/renderers/web/transport/carriage-c02/carriage-c02.glb')
def load(p):
 raw=p.read_bytes();magic,version,total=struct.unpack_from('<III',raw);assert magic==0x46546c67 and version==2 and total==len(raw);n,k=struct.unpack_from('<II',raw,12);assert k==0x4e4f534a;d=json.loads(raw[20:20+n]);m,t=struct.unpack_from('<II',raw,20+n);assert t==0x004e4942 and 28+n+m==len(raw);return d,raw[28+n:],raw

def attr(d,b,ai):
 a=d['accessors'][ai];v=d['bufferViews'][a['bufferView']];assert a['componentType']==5126 and a['type']=='VEC3'and'byteStride'not in v and'sparse'not in a;start=v.get('byteOffset',0)+a.get('byteOffset',0);assert start+a['count']*12<=len(b);return np.frombuffer(b,dtype='<f4',count=a['count']*3,offset=start).copy().reshape(-1,3)
old,ob,oraw=load(INPUT);new,nb,nraw=load(ROOT/'carriage-c02.glb');results={}
try:
 assert hashlib.sha256(oraw).hexdigest()=='93d4020036e5c685ce95010fe64b26c55a1561db4517405f0590f7a398253331'
 assert old['nodes']==new['nodes']and old['materials']==new['materials'];assert len(new['meshes'])==31 and len(new['nodes'])==62;assert new['extras']['scene_eligibility']==old['extras']['scene_eligibility'];assert new['extras']['parameters']==old['extras']['parameters'];assert new['extras']['door_study']==old['extras']['door_study'];assert new['extras']['license']=='GPL-3.0-or-later'
 for mi,(a,b)in enumerate(zip(old['meshes'],new['meshes'])):
  if mi!=8:assert a==b
  for pi,(ap,bp)in enumerate(zip(a['primitives'],b['primitives'])):
   for k,ai in ap['attributes'].items():
    if mi!=8:assert np.array_equal(attr(old,ob,ai),attr(new,nb,bp['attributes'][k]))
 assert nb[:len(ob)]==ob
 attrs=new['meshes'][8]['primitives'][0]['attributes'];p=attr(new,nb,attrs['POSITION']);n=attr(new,nb,attrs['NORMAL']);op=attr(old,ob,old['meshes'][8]['primitives'][0]['attributes']['POSITION']);on=attr(old,ob,old['meshes'][8]['primitives'][0]['attributes']['NORMAL']);assert p.shape==(2256,3)and np.isfinite(p).all()and np.isfinite(n).all();assert np.array_equal(p[:72],op[:72])and np.array_equal(n[:72],on[:72]);assert np.max(np.abs(np.linalg.norm(n,axis=1)-1))<1e-5
 oldseat=op[72:];minimum=oldseat.min(0);maximum=oldseat.max(0);assert np.all(p[72:]>=minimum)and np.all(p[72:]<=maximum)
 parts=[]
 for name,start,count in [('crowned',24,280),('welt',304,448)]:
  tris=p.reshape(-1,3,3)[start:start+count].astype(float);norms=n.reshape(-1,3,3)[start:start+count].astype(float);edges=Counter();directed=Counter();points={};ids=[]
  for tri in tris:
   row=[]
   for point in tri:
    key=tuple(point);row.append(points.setdefault(key,len(points)))
   assert len(set(row))==3;ids.append(row)
   for a,b in zip(row,row[1:]+row[:1]):edges[tuple(sorted((a,b)))]+=1;directed[a,b]+=1
  assert all(x==2 for x in edges.values());assert all(directed[a,b]==1 and directed[b,a]==1 for a,b in edges)
  assert len({tuple(sorted(t))for t in ids})==count
  area=np.cross(tris[:,1]-tris[:,0],tris[:,2]-tris[:,0]);length=np.linalg.norm(area,axis=1);assert np.all(length>1e-12);alignment=np.sum(area*np.sum(norms,axis=1),axis=1);assert np.all(alignment>0)
  centered=tris-tris.reshape(-1,3).mean(0);volume=float(np.sum(np.einsum('ij,ij->i',centered[:,0],np.cross(centered[:,1],centered[:,2])))/6);assert volume>0
  parts.append({'name':name,'triangles':count,'welded_vertices':len(points),'manifold_edges':len(edges),'all_edges_two_opposite_owners':True,'minimum_double_area_m2':float(length.min()),'signed_volume_m3':volume,'minimum_normal_alignment':float(alignment.min())})
 total=sum(new['accessors'][pr['attributes']['POSITION']]['count']//3 for m in new['meshes']for pr in m['primitives']);assert total==12228
 results={'status':'INDEPENDENT ACTUAL READBACK/TOPOLOGY PASS','input_sha256':hashlib.sha256(oraw).hexdigest(),'output_sha256':hashlib.sha256(nraw).hexdigest(),'triangles':total,'delta_triangles':716,'meshes':31,'nodes':62,'actual_parts':parts,'all_other_meshes_attrs_materials_nodes_door_and_parameters_exact':True,'passenger_triangles_and_normals_exact':True,'new_vertices_inside_exact_old_source_seat_AABB':{'minimum':minimum.tolist(),'maximum':maximum.tolist()},'scope':'closed orientable component/manifold/winding/normals/source containment; welt intentionally decorative overlapping cushion, not Boolean solid union or seated-body/photo/door-traversal acceptance'}
except BaseException as e:
 results={'status':'FIRST ACTUAL CHECK FAILURE STOP','error':repr(e)};raise
finally:(ROOT/'independent-actual-readback.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
