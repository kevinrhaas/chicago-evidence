# ONE actual C02 original driver-cushion candidate

Created only after independent source review and narrowed dependency review. Initial import-only failure preserved separately; missing exact CC0planar dependency added in NEWsource-complete directory before any geometry. ONE successful geometry/application call, no candidate repair/retry.

Actual candidate GLB SHA43a31988adb01d8c695b12d127f21471b4d57794dd8e4e2425fda6b0f2101aa4.12,228triangles(+716),31meshes62nodes, same original upholsterymaterial. Actual independent readback: original materials/nodes/door/params/othermesh attrs and first24passenger triangles+normals exact. Newparts within EXACT original source driverseatAABB. Cushion280tri/welt448tri, each closed manifold with every weldededge two oppositeowners, no duplicatefaces, finite unitnormals/nondegenerate faces, outward normal alignment and positivesignedvolume. Welt decorative overlap intentional, no Boolean union/occupant proof.

Khronos0errors0warnings,23infos (empty original sockets and unused oldaccessors retained by append-only preservation). No sourceparts/collider/seat sockets changed. No boarding/door traversal or seatedhuman accepted.

Actual renderer/pixel/material appearance is still UNRUN, no photographic improvement claim. Prepared source fixture /workspace/shared/c02-driver-cushion-ab-next uses same currentC02 demo lighting/material/door implementation and fixedfullbody framing, plus explicit driverdetail viewport with selectedbounds. Baseline/candidate selector, samecameras expected. Needs root independent viewer/lane release; no browser started here. The detail view intentionally excludes mostvehicle and is not fullbody/framing acceptance. Existing1904only, reconstructed subtype/owner/clothing context unchanged; no Pullmanownership.
