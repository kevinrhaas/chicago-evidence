from pathlib import Path
from fractions import Fraction as Q
from collections import defaultdict,Counter
import json,struct,hashlib
P=Path('/workspace/shared/horse-natural-labial-corner-producer-next');OLD=Path('/workspace/shared/horse-neutral-rail-closed-producer-next')
def need(v,m):
 if not v:raise ValueError(m)
def edge_map(T):
 d=defaultdict(list)
 for fi,t in enumerate(T):
  need(len(t)==3 and len(set(t))==3,'triangle')
  for a,b in zip(t,t[1:]+t[:1]):d[tuple(sorted([a,b]))].append((fi,a,b))
 return d
def proof(T,expected=None):
 need(len(set(tuple(sorted(t))for t in T))==len(T),'unique faces');E=edge_map(T);V={v for t in T for v in t};B={e for e,u in E.items()if len(u)==1}
 need(all(len(u)==1 or len(u)==2 and u[0][1:]==u[1][1:][::-1] for u in E.values()),'directed incidence')
 if expected is not None:need(B==expected,'exact boundary')
 boundaryV={v for e in B for v in e};links=defaultdict(list)
 for t in T:
  for i,v in enumerate(t):links[v].append((t[(i+1)%3],t[(i+2)%3]))
 for v,L in links.items():
  adj=defaultdict(set)
  for a,b in L:adj[a].add(b);adj[b].add(a)
  seen=set();todo=[next(iter(adj))]
  while todo:
   x=todo.pop()
   if x not in seen:seen.add(x);todo.extend(adj[x]-seen)
  need(len(seen)==len(adj),'vertex link connected');degrees=Counter(map(len,adj.values()));need(degrees==(Counter({1:2,2:len(adj)-2})if v in boundaryV else Counter({2:len(adj)})),'disk/half-disk link')
 adj=defaultdict(set)
 for u in E.values():
  if len(u)==2:adj[u[0][0]].add(u[1][0]);adj[u[1][0]].add(u[0][0])
 seen=set();todo=[0]
 while todo:
  x=todo.pop()
  if x not in seen:seen.add(x);todo.extend(adj[x]-seen)
 need(len(seen)==len(T),'one face component')
 return {'V':len(V),'E':len(E),'F':len(T),'Euler':len(V)-len(E)+len(T),'boundary':len(B),'all_vertex_links':len(V),'connected':True,'directed_manifold':True},B

raw=(OLD/'candidate-one/candidate.glb').read_bytes();need(hashlib.sha256(raw).hexdigest()=='798e864bd34dd52de5fa5e19acbb3a08ae6bcc5c5731a44820671871219e699b','parent798e');n=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+n]);buf=raw[28+n:];rb=json.loads((OLD/'candidate-one/readback.json').read_text());labels={(r['mesh'],r['vertex']):r['label']for r in rb['source_labels']};owners={int(k):v for k,v in rb['source_face_owners'].items()};pr=json.loads((OLD/'candidate-one/proof.json').read_text());graft=json.loads(Path('/workspace/shared/horse-combined-oral-neck-mane-prefix-next/candidate-one/graft-proof.json').read_text());oldhead=set(graft['head_faces']);remap={int(k):v for k,v in rb['old_to_new'].items()};head={v for k,v in remap.items()if k in oldhead}|{i for i,o in owners.items()if o['kind']=='conforming_mouth'};mouth={remap[int(k)]for k in pr['detail']['preserved110_posterior']}|{i for i,o in owners.items()if o['kind']=='conforming_mouth'};T=[];M=[];descs=[]
for mi,m in enumerate(doc['meshes']):
 for pi,p in enumerate(m['primitives']):
  a=doc['accessors'][p['indices']];v=doc['bufferViews'][a['bufferView']];fmt={5121:'B',5123:'H',5125:'I'}[a['componentType']];size=struct.calcsize('<'+fmt);off=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',size);ids=[struct.unpack_from('<'+fmt,buf,off+j*stride)[0]for j in range(a['count'])]
  for j in range(0,len(ids),3):T.append([labels[mi,i]for i in ids[j:j+3]]);M.append(p['material']);descs.append((mi,pi))
E=defaultdict(list)
for i in head:
 for a,b in zip(T[i],T[i][1:]+T[i][:1]):E[tuple(sorted([a,b]))].append(i)
bd={e for e,u in E.items()if sum(i in mouth for i in u)==1};vertices={v for e in bd for v in e};halo={i for i in head-mouth if any(v in vertices for v in T[i])};retired=mouth|halo;kept=head-retired;inv=json.loads((P/'EXACT-SCOPE-INVENTORY.json').read_text());need(retired==set(inv['proposed_full_retirement'])and kept==set(inv['unrelated_head_faces_preserved'])and len(retired)==2313 and len(kept)==2651,'independent exact retirement');need(len(halo)==137 and all(owners[i]['kind']=='oral_channel'and owners[i]['source_owner']['kind']=='retained_source'for i in halo),'skin halo authority');print('ACTUAL_RETIRED_PRIMITIVES',Counter(descs[i]for i in retired)); print('HALO_PRIMITIVES',Counter(descs[i]for i in halo))
retproof,retB=proof([T[i]for i in sorted(retired)]);outer=inv['unchanged_outer_boundary'];need(retB=={tuple(sorted([a,b]))for a,b in zip(outer,outer[1:]+outer[:1])}and len(outer)==71,'exact old71 loop')
# The implementation selects first retained face for seam normals: prove every
# such source-facing boundary choice is exterior coat material0.
materials={v:set()for v in outer}
for i in kept:
 for v in set(T[i])&set(outer):materials[v].add(M[i])
need(all(x=={0}for x in materials.values()),'all retained seam aliases actual exterior coat normal authority')
source=json.loads(Path('/workspace/shared/horse-oral-channel-diagonal-candidate/source/frozen-head.json').read_text());oral=json.loads(Path('/workspace/shared/horse-oral-channel-diagonal-candidate/candidate-one/head-source-surface.json').read_text());nativeids=set(oral['oral_authority']['retired_source_faces'])|{owners[i]['source_owner']['source_face']for i in halo};need(len(nativeids)==261,'native261');native=[['h:'+str(v)for v in source['faces'][i]]for i in sorted(nativeids)];nativeproof,nativeB=proof(native,retB);need(nativeproof['Euler']==1,'native closed substrate disk')
A=json.loads((P/'PROPOSED-SYMBOLIC-PORTALS.json').read_text());regions=[];removed=set()
for r in A['regions']:
 hit=r['hit_source_face'];vv=set(source['faces'][hit]);star={i for i in nativeids if vv&set(source['faces'][i])};need(star==set(r['retired_native_source_faces'])and len(star)==13,'source facet closed star');need(not star&removed,'disjoint source stars');removed|=star;tp,bd=proof([['h:'+str(v)for v in source['faces'][i]]for i in sorted(star)]);need(tp['Euler']==1 and len(bd)==9 and not({v for e in bd for v in e}&set(outer)),'strict interior nine edge disk');regions.append({'side':r['side'],'source_facet':hit,'source_disk':tp,'retired_native_faces':sorted(star)})
remaining=nativeids-removed;need(len(remaining)==235 and sorted(remaining)==A['native_faces_retained_in_new_patch'],'235 restored native');new=A['proposed_patch_faces'];newowners=A['proposed_patch_face_owners'];nativeindex=[o['source_face']for o in newowners if o['kind']=='restored_native_skin'];need(nativeindex==sorted(remaining),'native owner order')
for t,o in zip(new,newowners):
 if o['kind']=='restored_native_skin':need(t==[('h:'+str(i))if'h:'+str(i)in outer else'labial-native:'+str(i)for i in source['faces'][o['source_face']]],'native source oriented indices')
counts=Counter(o['kind']for o in newowners);sidecounts=Counter(o.get('side')for o in newowners if o['kind']!='restored_native_skin'and o['kind']!='inner_labial_vestibule');need(counts=={'restored_native_skin':235,'outer_blend_zipper':82,'exterior_labial_blend':256,'inner_labial_vestibule':128}and sidecounts=={'l':169,'r':169},'fixed owner cardinalities')
patch,pB=proof(new,retB);need(patch['V']==385 and patch['E']==1087 and patch['F']==701 and patch['Euler']==-1,'patch full topology');oldproof,oldB=proof([T[i]for i in sorted(head)]);whole,wholeB=proof([T[i]for i in sorted(kept)]+new,oldB);need(whole['V']==1689 and whole['E']==5042 and whole['F']==3352 and whole['Euler']==-1 and len(wholeB)==28,'full independent head')
r={'PASS':True,'scope':'Independent actual old798e JSON/index/owner and original native face tables only; all directed edges, every vertex link and components. No proposed P/N/J/W, Model, producer, scan, SAT or capture.','retired_primitive_counts':{str(k):v for k,v in Counter(descs[i]for i in retired).items()},'halo_primitive_counts':{str(k):v for k,v in Counter(descs[i]for i in halo).items()},'retired':retproof,'preserved_other_head':len(kept),'native_substrate':nativeproof,'regions':regions,'restored_native_faces':len(remaining),'new_owner_counts':dict(counts),'new_side_annulus_faces':dict(sidecounts),'new_patch':patch,'full_head':whole,'all71_retained_boundary_normal_sources_material0':True,'whole_horse_faces':len(T)-len(retired)+len(new),'geometry_embedding_claimed':False};Path('/workspace/shared/horse-natural-labial-INDEPENDENT-TOPOLOGY.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
