"""Exact original native facets and authored bar ONLY; no proposed tissue field."""
from pathlib import Path
from fractions import Fraction as Q
import json,hashlib
P=Path('/workspace/shared/horse-natural-labial-corner-three-primitives-next');S=Path('/workspace/shared/horse-oral-channel-diagonal-candidate/source/frozen-head.json');s=json.loads(S.read_text(),parse_float=Q);facts=json.loads((P/'NATIVE-SKIN-INDEX-PROOF.json').read_text());corr=json.loads((P/'NATIVE-BIT-CORRESPONDENCE.json').read_text());line=[tuple(map(Q,x))for x in[('-.105','-.20','.39'),('0','-.205','.40'),('.105','-.20','.39')]]
def need(v,m):
 if not v:raise ValueError(m)
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return(a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
hits=[]
for si,(a,b)in enumerate(zip(line,line[1:])):
 d=sub(b,a)
 for fi in facts['native_source_face_ids']:
  tri=[s['positions'][v]for v in s['faces'][fi]];normal=cross(sub(tri[1],tri[0]),sub(tri[2],tri[0]));den=dot(normal,d)
  if not den:continue
  t=dot(normal,sub(tri[0],a))/den
  if not 0<=t<=1:continue
  # Existing-source plane intersection only. Find exact barycentrics in a
  # nondegenerate coordinate projection, independently of producer helpers.
  point=tuple(a[k]+t*d[k]for k in range(3));drop=max(range(3),key=lambda k:abs(normal[k]));axes=[k for k in range(3)if k!=drop];project=lambda p:tuple(p[k]for k in axes);v0,v1,v2=map(project,tri);p=project(point)
  def cross2(a,b):return a[0]*b[1]-a[1]*b[0]
  area=cross2(sub(v1,v0),sub(v2,v0));u=cross2(sub(p,v0),sub(v2,v0))/area;v=cross2(sub(v1,v0),sub(p,v0))/area;w=[1-u-v,u,v]
  if min(w)>=0:hits.append({'segment':si,'face':fi,'fraction':str(t),'barycentric':list(map(str,w)),'strict_interior':min(w)>0})
need(len(hits)==2 and [h['face']for h in hits]==[726,760]and all(h['strict_interior']for h in hits),'exact two old-source intersections')
for h,c in zip(hits,corr['hits']):need(h['segment']==c['segment']and h['face']==c['source_face']and h['fraction']==c['segment_fraction_exact']and h['barycentric']==c['facet_barycentric_exact'],'correspondence exact')
r={'PASS':True,'scope':'Original native261 facets versus original authored two-segment centerline, exact rational source correspondence only. No circle/blend/vestibule/proposed P/N/J/W, Model, producer/SAT or capture.','hits':hits,'source_sha256':hashlib.sha256(S.read_bytes()).hexdigest()};f=Path('/workspace/shared/horse-natural-labial-INDEPENDENT-EXISTING-CORRESPONDENCE.json');f.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
