"""Pure source/index/hash audit, no Node/browser/GLTFLoader invocation."""
from pathlib import Path
import hashlib,json,struct,tarfile,re
B=Path('/workspace/shared');P=B/'horse-natural-labial-419a-appearance-source-next';O=B/'horse-neutral-798e-appearance-source-next'
def need(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
local=load(P/'SOURCE-HASHES.json');external=load(P/'EXTERNAL-HASHES.json');need(len(local)==9 and len(external)==19,'pins count')
for k,v in local.items():need(sha(P/k)==v,'local '+k)
for k,v in external.items():need(sha(Path(k))==v,'external '+k)
# Confirm complete executable/UI delta equals only intended identity and label substitutions.
mapping={'e173bb8608a90e94a4f998e65ec9e09b2d2880d8639f2b1dc756f87815f485f8':'798e864bd34dd52de5fa5e19acbb3a08ae6bcc5c5731a44820671871219e699b','798e864bd34dd52de5fa5e19acbb3a08ae6bcc5c5731a44820671871219e699b':'419a6194b660bcd9ab1f7da21a2b1fcbd67d9ba620d294fd6299440dc8890c31','e173':'798e','798e':'419a'}
pat=re.compile('|'.join(re.escape(x)for x in sorted(mapping,key=len,reverse=True)))
for name in ['scene.mjs','run.cjs','index.html']:
 need(pat.sub(lambda m:mapping[m[0]],(O/name).read_text())==(P/name).read_text(),'only labels and pins '+name)
for name in ['inspection.mjs','actual_primitive.mjs']:need((P/name).read_bytes()==(O/name).read_bytes(),'unchanged helper '+name)
s=load(P/'study.json');need(s['study_id']=='798e-419a-neutral-mouth-idle'and set(s['components'])=={'before','after'},'study identity');rows=[]
for k,component in s['components'].items():
 path=Path(component['path']);need(sha(path)==component['sha256'],'component');raw=path.read_bytes();n=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+n]);buf=raw[28+n:];need(not any('uri'in x for x in doc.get('buffers',[])+doc.get('images',[])),'selfcontained');manifest=[]
 for mi,mesh in enumerate(doc['meshes']):
  for pi,p in enumerate(mesh['primitives']):
   need(p.get('mode',4)==4,'trianglemode');a=doc['accessors'][p['indices']];v=doc['bufferViews'][a['bufferView']];fmt={5121:'B',5123:'H',5125:'I'}[a['componentType']];size=struct.calcsize('<'+fmt);off=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',size);ids=[struct.unpack_from('<'+fmt,buf,off+j*stride)[0]for j in range(a['count'])];pc=doc['accessors'][p['attributes']['POSITION']]['count'];need(len(ids)%3==0 and min(ids)>=0 and max(ids)<pc,'complete source index');manifest.append({'name':mesh['name'],'sourceMesh':mi,'sourcePrimitive':pi,'positionCount':pc,'indexCount':len(ids),'indexed':True,'indexStreamSHA256':hashlib.sha256(struct.pack('<'+'I'*len(ids),*ids)).hexdigest()})
 need(manifest==component['primitives']and len(manifest)==6 and sum(x['indexCount']//3 for x in manifest)==component['triangles'],'all6 actual source primitive manifest');rows.append({'variant':k,'sha256':component['sha256'],'triangles':component['triangles'],'primitives':len(manifest),'source_index_manifests_exact':True})
a=B/'horse-NATURAL-LABIAL-419A-MATCHED-APPEARANCE-SOURCE-2026-10-19.tar.gz';need(sha(a)=='fb9d4a9e8dd44e23831c381ae206e2cd3c5990931b9d93805f3371d25372dd4b','source archive')
with tarfile.open(a)as t:
 members=[m for m in t.getmembers()if m.isfile()]
 for m in members:need(t.extractfile(m).read()==(P/Path(m.name).name).read_bytes(),'archive exact')
r={'status':'PASS_SCOPED_SOURCE_ONLY','scope':'Read/hash entire frozen minimal identity delta and unchanged frame/pose/draw/UI/lifecycle code; decode existing GLB JSON/source indices only; no evaluator/model/predicate/distance/capture/browser/renderer execution.','source_archive_sha256':sha(a),'archive_files':len(members),'local_pins':{'count':9,'manifest_sha256':sha(P/'SOURCE-HASHES.json'),'all_exact':True},'external_pins':{'count':19,'manifest_sha256':sha(P/'EXTERNAL-HASHES.json'),'all_exact':True},'exact_normalized_code_delta':'scene.mjs/run.cjs/index.html equal previous58171577 source after only old/new hashes and e173/798e→798e/419a labels/ID substitutions. inspection.mjs and actual_primitive.mjs byte-identical.','components':rows,'reviewed_unchanged_controls':['Full submitted horse primitives and actual onAfterRender coverage, original material/lighting unchanged.','Actual idle0 action/mixer and postdraw root/head matrices independently queried; exact A/B camera/projection/root/head agreement mandatory.','CPU-double2% detail framing and UI viewport bounds, fresh draw serial, keyboard/mobiletap/reset and single model fetch.','Both corrupted sourcebuffers must refuse; pending-fetch disposal, pagehide cleanup, aborts and resource disposal unchanged.','Exclusive new output; source/external pins rechecked;105s teardown timer/110s capture loop, browser/server cleanup; explicit --released-render-window required.'],'schedule':'8PNG: profile/quarter × before798e/after419a ×1280x900/390x844. Horse-only; actual harness excluded and clearly labeled.','limits':['No browser or capture run has been authorized by this review. Root release and free single-browser lane still required.','Portals represent reconstructed neutral bitted state; harness-free visualization does not establish an unbitted mouth.','Root and author must inspect actual pixels; no natural/photographic/motion/pressure/jaw-opening or app promotion claim.']};out=B/'horse-natural-labial-419a-APPEARANCE-INDEPENDENT-SOURCE-REVIEW.json';out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'report':str(out),'sha256':sha(out),'archive_files':len(members),'components':rows}))
