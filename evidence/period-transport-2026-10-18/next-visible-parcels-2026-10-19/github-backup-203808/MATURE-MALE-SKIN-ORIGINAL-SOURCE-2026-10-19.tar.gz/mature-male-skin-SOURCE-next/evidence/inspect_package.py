"""Read original Debian archive only. No install, map authoring or image edits."""
from pathlib import Path
import io,tarfile,json,hashlib
P=Path(__file__).parent;deb=P.parent/'mature-skin-makehuman-data_1.1.1-1_all.deb'
class Limited(io.RawIOBase):
 def __init__(self,f,size):self.f=f;self.remaining=size
 def readable(self):return True
 def read(self,n=-1):
  if n<0:n=self.remaining
  d=self.f.read(min(n,self.remaining));self.remaining-=len(d);return d
 def readinto(self,b):
  d=self.read(len(b));b[:len(d)]=d;return len(d)
entries=[];md5={};arrows=[];allskins=[]
with deb.open('rb')as f:
 if f.read(8)!=b'!<arch>\n':raise ValueError('Not Debian ar archive')
 while True:
  header=f.read(60)
  if not header:break
  if len(header)!=60 or header[58:60]!=b'`\n':raise ValueError('Incomplete ar record')
  name=header[:16].decode().strip().rstrip('/');size=int(header[48:58]);limited=Limited(f,size);arrows.append({'name':name,'size':size})
  if name.startswith('control.tar'):
   with tarfile.open(fileobj=limited,mode='r|*')as t:
    for m in t:
     if m.isfile() and m.name.lstrip('./')in ['control','md5sums']:
      data=t.extractfile(m).read();(P/('package-'+m.name.lstrip('./'))).write_bytes(data)
      if m.name.endswith('md5sums'):
       for line in data.decode().splitlines():digest,path=line.split(maxsplit=1);md5[path]=digest
  elif name.startswith('data.tar'):
   with tarfile.open(fileobj=limited,mode='r|*')as t:
    for m in t:
     if '/skins/'in m.name:allskins.append({'path':m.name,'size':m.size,'type':m.type.decode()})
     selected=('/skins/'in m.name and any(k in m.name for k in ['middleage_caucasian_male','old_caucasian_male','middleage_lightskinned_male_diffuse.png','old_lightskinned_male_diffuse.png'])) or m.name.endswith('/doc/makehuman-data/copyright') or m.name.endswith('/data/skins/README')
     if selected and m.isfile():
      rel=Path(m.name.lstrip('./'))
      if rel.is_absolute() or '..'in rel.parts or m.size>20000000:raise ValueError('Unsafe selected member')
      data=t.extractfile(m).read();actual=hashlib.md5(data).hexdigest();expected=md5.get(str(rel))
      if len(data)!=m.size or expected!=actual:raise ValueError('Selected member length/MD5 mismatch '+str(rel))
      dest=P/'selected'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);entries.append({'path':str(rel),'bytes':len(data),'md5_control_verified':True,'md5':actual,'sha256':hashlib.sha256(data).hexdigest()})
  while limited.remaining:
   if not limited.read(min(limited.remaining,1048576)):raise ValueError('Truncated ar member')
  if size%2:f.read(1)
r={'package_url':'https://archive.ubuntu.com/ubuntu/pool/universe/m/makehuman/makehuman-data_1.1.1-1_all.deb','package_bytes':deb.stat().st_size,'package_sha256':hashlib.sha256(deb.read_bytes()).hexdigest(),'ar_members':arrows,'full_data_tar_stream_parsed_to_EOF':True,'selected_entries':entries,'all_skin_members':allskins,'installed_or_executed':False};(P/'PACKAGE-INSPECTION.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'package_bytes':r['package_bytes'],'package_sha256':r['package_sha256'],'selected_entries':entries,'skin_members':len(allskins)},indent=2))
