-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA256

Format: 3.0 (quilt)
Source: makehuman
Binary: makehuman, makehuman-data, makehuman-doc
Architecture: all
Version: 1.1.1-1
Maintainer: Muammar El Khatib <muammar@debian.org>
Homepage: http://www.makehuman.org/
Standards-Version: 4.0.0
Build-Depends: debhelper (>= 7.0.50), python2.7, python-qt4, python-opengl, python-numpy, python-qt4-gl, dh-python, python-sphinx, python-matplotlib, python | python-all | python-dev | python-all-dev, quilt
Package-List:
 makehuman deb graphics optional arch=all
 makehuman-data deb graphics optional arch=all
 makehuman-doc deb doc optional arch=all
Checksums-Sha1:
 a448a13eac044cc7c80c6d92c3db00b1c53c7476 299807579 makehuman_1.1.1.orig.tar.bz2
 375470952cbb4072465a90d498c58ac9ddf1fba3 21112 makehuman_1.1.1-1.debian.tar.xz
Checksums-Sha256:
 a942a38a1590d0112e850cd4f0105fecc6998c4ba4783437edf3cb1de04a6251 299807579 makehuman_1.1.1.orig.tar.bz2
 9635eb9236762b4c4eb205446c41fe50301290eacda51d992f1a60c126ed3981 21112 makehuman_1.1.1-1.debian.tar.xz
Files:
 c8327dfcd0a5dd85d7940a167af054b9 299807579 makehuman_1.1.1.orig.tar.bz2
 0c547b128fc0a5856883e73879b7f3bb 21112 makehuman_1.1.1-1.debian.tar.xz
Python-Version: 2.7

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCAAdFiEEHJoldLGkjYrCQ8rlXCkTcnEkbkoFAllOl5kACgkQXCkTcnEk
bkpiUw/+NZwxKtISgHgQkKqyegpSV45Ta8VY+QNaQYwTL1W98j681SJ0o/pb4SMB
rR/YmNnSOJ9s9sTo/SW7e61HhIf/k0OMZc//hlcI1deA5Syb+ShjoRoAbmV4HNK1
DMFxC809KmxC5MRMNF/JXAUilRFBSZIX5Ql3hFPS7C0tXLrclTi72djLNG9bz3k0
RNoi9flFZKTYVbdqgBL3STttsym5MkChoNH525F1MatJCZKHZAZqAoqyLMnw+HMu
9jS1Dr0sItW7TnDL6xxL86IONnOZLunhbM6jK8In6wZfE7Th8UHaRzxjiAbpE9QV
v8HG08E8GLEkBy5ZdoDq8V4kwj9w0TmzUeGG1dM/bzbLpcBKwb3EFBieDQwOxsdl
83C+BkdfZjYzfj/aMvM9Eq+CHINtw1FHNTUYHo3vfx+JDIKOH0lSZ920vDKAfF7v
OsQkOZV9Pozg7Ca0sQUN+c6uprWu8SogK788OqUTQAZmlUdwAFlohe8Q56QjKbV5
89Px8crWrdyB6tcon5vtLkbN+4lVtg2KSCJ878Y02OPX1+8SVOzY89bu9sLt0y2T
5H+dzcj+jzar0g7RU6C8xDAflCO/emVRZaaf6ORr9klOWOM8+fEKcDEwGasWIkg1
BtGl2HRF1Lj+/V3rvENTdsMHRcHqEvvwC7XO/DyJafsvxpriVN4=
=BHwV
-----END PGP SIGNATURE-----
