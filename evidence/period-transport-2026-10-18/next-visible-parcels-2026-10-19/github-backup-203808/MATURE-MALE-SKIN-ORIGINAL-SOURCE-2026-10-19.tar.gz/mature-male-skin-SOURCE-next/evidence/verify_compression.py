from pathlib import Path
import lzma,json,hashlib
P=Path(__file__).parent;f=(P.parent/'mature-skin-makehuman-data_1.1.1-1_all.deb').open('rb');need=lambda v,m:None if v else (_ for _ in()).throw(ValueError(m));need(f.read(8)==b'!<arch>\n','ar');report=[]
while True:
 h=f.read(60)
 if not h:break
 need(len(h)==60 and h[58:]==b'`\n','ar header');name=h[:16].decode().strip().rstrip('/');n=int(h[48:58]);left=n
 if name.endswith('.xz'):
  dec=lzma.LZMADecompressor();count=0;sha=hashlib.sha256()
  while left:
   chunk=f.read(min(left,1048576));need(bool(chunk),'complete compressed member');left-=len(chunk);out=dec.decompress(chunk,max_length=1048576);count+=len(out);sha.update(out)
   while not dec.needs_input and not dec.eof:
    out=dec.decompress(b'',max_length=1048576);count+=len(out);sha.update(out)
   if dec.eof:need(not left and not dec.unused_data,'single complete XZ stream')
  need(dec.eof,'XZ footer/CRC/eof');report.append({'member':name,'compressed_bytes':n,'decoded_bytes':count,'decoded_sha256':sha.hexdigest(),'xz_footer_CRC_and_EOF_verified':True})
 else:f.seek(n,1)
 if n%2:f.read(1)
f.close();(P/'FULL-COMPRESSION-INTEGRITY.json').write_text(json.dumps({'PASS':True,'members':report,'package_bytes':(P.parent/'mature-skin-makehuman-data_1.1.1-1_all.deb').stat().st_size},indent=2)+'\n');print(json.dumps(report))
