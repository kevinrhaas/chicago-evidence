// SPDX-License-Identifier: GPL-3.0-or-later
import * as T from 'three';
import {actualTriangleStream} from './actual_primitive.mjs';
export async function checkedSurfaces(gltf, expected) {
  const surfaces = [], seen = new Set();
  gltf.scene.traverse(o => {
    if (!o.isMesh) return;
    const a = gltf.parser.associations.get(o);
    if (!a || !Number.isInteger(a.meshes) || !Number.isInteger(a.primitives)) throw Error('Actual source association missing');
    const key = a.meshes + ':' + a.primitives;
    if (seen.has(key)) throw Error('Duplicate actual primitive association');
    seen.add(key);
    const source = gltf.parser.json.meshes[a.meshes], primitive = source.primitives[a.primitives];
    const stream = actualTriangleStream(o.geometry, primitive);
    surfaces.push({object:o, stream, row:{name:source.name,sourceMesh:a.meshes,sourcePrimitive:a.primitives,positionCount:stream.positionCount,indexCount:stream.count,indexed:stream.indexed}});
  });
  if (surfaces.length !== expected.length || !surfaces.length) throw Error('Incomplete actual surfaces');
  for (const s of surfaces) {
    const bytes = new ArrayBuffer(s.stream.indices.length * 4), dv = new DataView(bytes);
    s.stream.indices.forEach((v,i) => dv.setUint32(i*4,v,true));
    s.row.indexStreamSHA256 = [...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
    const wanted = expected.filter(e=>e.sourceMesh===s.row.sourceMesh&&e.sourcePrimitive===s.row.sourcePrimitive);
    if (wanted.length!==1 || Object.keys(s.row).some(k=>wanted[0][k]!==s.row[k])) throw Error('Actual referenced source coverage disagreement');
    s.references = [...new Set(s.stream.indices)];
  }
  return surfaces;
}
export function actualWorldPoints(surfaces) {
  const out = [];
  for (const s of surfaces) {
    const o = s.object;
    if (o.isSkinnedMesh) o.skeleton.update();
    for (const i of s.references) {
      const v = o.getVertexPosition(i,new T.Vector3()).applyMatrix4(o.matrixWorld);
      if (!v.toArray().every(Number.isFinite)) throw Error('Nonfinite actual deformed vertex');
      out.push(v);
    }
  }
  if (!out.length) throw Error('Empty actual point coverage');
  return out;
}
export function projectedBounds(camera, points) {
  const b={left:Infinity,right:-Infinity,top:Infinity,bottom:-Infinity,depthValid:true};
  for (const p of points) {
    const q=p.clone().project(camera);
    if(!q.toArray().every(Number.isFinite)) throw Error('Nonfinite CPU projection');
    b.left=Math.min(b.left,(q.x+1)/2);b.right=Math.max(b.right,(q.x+1)/2);
    b.top=Math.min(b.top,(1-q.y)/2);b.bottom=Math.max(b.bottom,(1-q.y)/2);
    b.depthValid&&=q.z>=-1&&q.z<=1;
  }
  return {...b,points:points.length,precision:'CPU double projection of actual CPU-deformed referenced vertices; not GPU/Float32 skinning proof'};
}
export function fitCamera(camera, points, view) {
  const dirs={threequarter:[1,.35,1.05],side:[1,.14,0],rear:[.8,.3,-1]};
  if(!dirs[view]||!points.length) throw Error('Known camera and nonempty geometry required');
  const center=new T.Box3().setFromPoints(points).getCenter(new T.Vector3()),dir=new T.Vector3(...dirs[view]).normalize();
  camera.position.copy(center).add(dir);camera.lookAt(center);camera.updateMatrixWorld(true);
  const inv=camera.matrixWorld.clone().invert(),v=Math.tan(T.MathUtils.degToRad(camera.fov/2));let distance=0;
  for(const p of points){const q=p.clone().applyMatrix4(inv);distance=Math.max(distance,q.z+1+Math.abs(q.x)/(v*camera.aspect*.90),q.z+1+Math.abs(q.y)/(v*.90));}
  camera.position.copy(center).addScaledVector(dir,distance+.02);camera.lookAt(center);camera.updateMatrixWorld(true);
  return {position:camera.position.toArray(),target:center.toArray(),fov:camera.fov,aspect:camera.aspect};
}
