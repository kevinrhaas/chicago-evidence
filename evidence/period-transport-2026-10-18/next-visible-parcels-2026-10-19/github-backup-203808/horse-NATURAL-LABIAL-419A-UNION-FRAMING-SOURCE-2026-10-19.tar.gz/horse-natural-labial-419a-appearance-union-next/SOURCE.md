# Matched419a source: union-framing and failure-state repair — NOT RUN

Preserves the failed7/8PNG source fb9d and actual5787 capsule unchanged.
The exact419a model remains the one full30.172s idle engineering PASS, independently
stored-audited685774a8. No new horse geometry or material is evaluated or changed.

Stored successful desktop after-quarter bounds and mobile before-quarter
projection imply after mobile right=1.0007913745419814 at the old baseline-only
zoom5, beyond unchanged0.98 postdraw guard. The same affine formula reproduces
actual mobile before bounds to1e-16. This is derived from stored frame metadata,
not a new render/model query. The old caller recorded a fresh-frame wait timeout
and did NOT save window.mouthError; the derived framing violation is sufficient
and consistent, but not a directly observed browser failure state.

One camera change: fit the union of the already qualified before798e and after419a
selected actual CPU-deformed mouth points, using the same existing5%fit loop,
fixed target/view/orthographic rules and one shared camera perview/viewport.
Existing2%postdraw bound, depth, fullgeometry/coverage, actualidle0, exact A/B
camera/projection/root/headframe equality, lighting/materials, UI/mobile/reset,
corrupt-buffer and disposal checks remain unchanged. The models are both loaded
at idle0 before framing; frustumculling remains disabled for complete submitted
source geometry. No asymmetric crop, FOV trick or numeric guard waiver.

One diagnostic-only caller change: if choose() fails, save requested viewport/
variant/view plus window.mouthError, disposed/ready and explicitly LAST SUCCESSFUL
render before closing the page. Do not relabel that stale receipt as a fresh
candidate frame, do not recover or retry the failed selection.

All other code and exact models/manifests remain unchanged from fb9d. The old
operator remains FAILED: only7PNG, no mobile disposal or3negative controls finished.
Source-only node --check and hash/diff checks run; no browser/model/evaluator/
geometry/scan/capture rerun. Futurecapture needs root direction/freebrowserlane,
independent frozen-source review, one<=150s freshoutput and firstfailureSTOP.
No new actual capture is authorized by this source correction itself.

The saved images show a cleaner native closed-lip shape, but the circular drilled
portal, angular blend, faceted nostril and flatbrown skin remain natural/photo
UNACCEPTED. The port is a fixed bitted-rest approximation, not an unbitted model.
A bitted rendering can be reviewed separately; it must not hide bad tissue from
horse-only review. No motion/photo/pressure/jawopening/app promotion is implied.
