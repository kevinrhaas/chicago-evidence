# Natural labial corner: one fixed source proposal

The stored798e model passes the complete idle engineering checks. Its actual
4015 appearance capsule remains visually unacceptable: the anterior slit is
closed, but the posterior opening is rectangular, the rear wall is flat, and
several parallel ridges read as molded bands. No photographic or motion
acceptance follows from that engineering result.

## Anatomical authority and limits

I reopened the actual Cuyer1905 Fig92 head-muscle drawing (illo262.png), its
caption, and the orbicularis-oris/chin text in the cleared Gutenberg38315 copy.
The fleshy lip ring blends into neighboring tissue; this supports a continuous
labial surface and short commissure rather than a box mouth. It does not supply
photographic skin, a measured lip section, an8mm dimension, a Chicago horse
identity or a date-specific breed. The previously viewed Muybridge1878 plate
does not resolve close lip detail. Those gaps remain explicit.

The original frozen native head already contains a closed shallow lip groove,
with an authored maximum2.5mm depth. Restore that original shape as the fixed
skin substrate; do not retain the subsequent2176-face folded-lip construction.
The native shape itself has not been accepted as natural or photographic.

## Exact ownership

Retire precisely the2313 existing798e triangles in EXACT-SCOPE-INVENTORY.json:
the entire2176-face current mouth, including all110 previously protected
posterior lining faces, plus137 original oral-channel skin-halo faces. Root
explicitly authorized this posterior ownership amendment. Every other2651 head
face and every non-head face remains exact in its original oriented primitive
and material. All original stored attributes/BIN/accessor/view prefixes,
primitive extras, rig, nodes, actions and materials remain unchanged.

The retired patch is V1191/E3505/F2313/Euler−1, with exactly one71-edge outer
boundary. The original native261-face closed skin patch has exactly that SAME
oriented71-alias boundary and V167/E427/F261/Euler1. Boundary aliases refer to
actual798e P/J/W/N rows; no boundary motion, welding or normal rewrite is allowed.
Native interior positions derive directly from the frozen original native
source, translated into the existing head bind frame, then stored once as
binary32. Newly appended interior aliases have the actual head joint at weight1.
No current protected eye/nostril/ear/neck/mane vertices or triangles are retired.

## Fixed bit correspondence and local domains

The bit remains the exact fe76 gear GLB and its stored actual binary64 idle0
capture. Authored bar centerline points are(-.105,-.20,.39), (0,-.205,.40),
(.105,-.20,.39), radius6mm. Full32 actual side triangles and both576-face rings
remain guard authority; an ideal cylinder is not substituted for them.

Exact rational source correspondence gives two strict centerline intersections:
native facets726 and760. Use their recorded exact barycentrics; no nearest-point
lookup or parameter search. Each facet's three-vertex closed star is exactly13
source faces with a9-edge boundary. The two regions are disjoint and strictly
inside the71-edge skin patch. Their projected boundary polygons are strictly
star-shaped around the fixed source intersections. Stored existing-source edge
distances to the axis are10.178mm and11.239mm. These are2D source-domain facts,
not actual new tissue/gear clearance proofs.

## One geometry recipe, no sweep

Restore the235 native skin triangles outside those two13-face regions. Each
corner is a real replacement annulus: its original9-edge boundary, two32-point
blend rings, and a32-point portal. The portal has fixed8mm radius in the plane
normal to that side's existing authored bit segment, centered at the exact
native-source intersection. This gives a reconstructed nominal2mm margin over
the authored6mm tube; the unchanged actual full-side >1mm guard still decides.

The transverse u-axis is global head-local +Z projected perpendicular to the
segment; v=axis×u. The geometric32 angles are uniformly2πj/32. Source winding is
clockwise on the left and counterclockwise on the right. For each angle, intersect
that ray with the recorded projected9-edge source polygon, retain the unique
oriented source-edge alias and barycentric fraction, and lift that exact source
edge point O into3D. C is the corresponding8mm portal-circle point. The two blend
points are(2O+C)/3 and(O+2C)/3. No extra offsets, hand-picked XYZ, projection to a
different surface or shader modification is permitted. The symbolic41-triangle
outer zipper follows the frozen existing source angular order; the remaining
two strips use fixed shared-diagonal quads. All actual serialized triangles
must remain finite/nondegenerate; the full actual guards decide embedding.

Join the two portal rings with a genuine128-triangle inner labial vestibule:
one32-point8mm ring at the actual centerline knot(0,-.205,.40), transverse to +X,
and fixed corresponding32-point strips to each portal. This replaces the old
rectangular roof/floor/back construction. It is a deliberately narrow neutral
bitted rest-state approximation, not a complete teeth/tongue/mucosal anatomy,
unbitted state, pressure model, mastication or jaw-opening design. No invisible
plane, cap, occluder, shader mask or painted closure is emitted.

The exterior uses the existing coat primitive/material; the actual inner
vestibule uses the existing oral primitive/material. The original material
properties and extras remain exact. Only appended normals may be accumulated
from actual binary32 incident triangles, separately per material; all71 boundary
copies use the exact original798e exterior seam normal. This does not assert C1
geometry at the interface. If fixed gear rings intersect this anatomical
construction, stop and report incompatible reconstructed gear; do not erode
additional skin, waive a contact or move the bit automatically.

## Independently derived index topology

PROPOSED-SYMBOLIC-PORTALS.json contains every proposed oriented triangle and its
owner, with no proposed position. The235 native faces plus169 faces per exterior
corner plus128 vestibule faces give exactly701 mouth faces. The connected
manifold has V385/E1087/F701/Euler−1 and the exact same71-edge outer boundary;
all vertex links are checked by the existing manifold validator. The complete
head must independently derive V1689/E5042/F3352/Euler−1 and its unchanged28-edge
neck boundary; whole model13456 faces. Changes to exact counts are explicit
source/topology authority, never a numeric-predicate or contact exemption.

## Release and acceptance

Root authorized source implementation and exactly ONE180s CPU0/maththreads1
actual trial only AFTER independent full frozen-source/caller PASS. Source,
input and before/after manifests must be exact. Fresh exclusive output, owned
child-group cleanup, first-failure stop and immutable failures are mandatory.
No retry or evaluator extension is implied by a failure/timeout.

Require decoded full document/attribute/index/ownership preservation, Khronos,
new exact topology and original8 complete full structural scopes: head, hybrid,
mane and mouth, each internal and versusALLremaininghorse; all36 actual gear
parts, old078 negative, complete actual bit-side distance/virtual caps and
outside-head sample classification. SAT1e-8, proper crossings, source-point
and owned-edge proofs, >1mm distance and all other numeric guards stay unchanged.

Any later appearance capture is separate: inspect both horse-only and bitted
views, profile/quarter and desktop/mobile. A bit covering an ugly hole does not
establish acceptable tissue. No application install, photo/motion acceptance or
unbitted state is authorized by this source proposal or a future idle PASS.
