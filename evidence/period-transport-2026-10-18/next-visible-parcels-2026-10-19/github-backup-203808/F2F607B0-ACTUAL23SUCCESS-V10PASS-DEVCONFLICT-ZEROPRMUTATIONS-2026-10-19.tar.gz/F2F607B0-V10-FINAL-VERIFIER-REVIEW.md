# Exact f2f final metadata verifier — source review

Source: `verify_f2f607b0_normal_dev_gates_v10.py`
SHA256: `8f29a7e6fbcdee9e772138b9092a0ad5ad3b7ecffa7ca7f9ff005f51d816b8d2`

The earlier v8 helper is imported by its approved hash for strict required-step/source/auxiliary-DAG logic. The approved e7 observer is imported by its hash for the accepted v2 receipt, c142 manifest, exact18 cells and exact23 run IDs. No local checkout HEAD is used.

Compared with the old-head v8 release audit, this wrapper binds frozen f2f commit/tree, its actual eighteen attempt1 smoke runs and five normal runs. Its auxiliary DAG uses the actual f2f attempt1 six job IDs, and the ordinary PR human workflow's single optional teamster skip is bound to its exact job ID and frozen false workflow_dispatch condition. All29 actual current check IDs must equal the saved terminal job-ID union, with mandatory steps SUCCESS and only these six exact skips allowed. Extra, missing, duplicate, failed or pending checks fail.

Fresh ordinary JSON GETs have one45-second overall budget, eight workers, no retry and raw response persistence. They compare exact remote source/tree and26 CODE blobs to committed f2f Git objects, current workflow run identities, all current checks/statuses, PR head/ref/dev target, and a distinct final PR/branch observation. Dev and PR-base values are separately recorded, without holding either to the old manifest base or treating base advancement as a source failure.

`--verify` remains unexecuted. It should run once in a fresh output only after the sole observer has all23 actual workflows terminal SUCCESS and coherent mandatory job steps. The offline18-control report explicitly identifies all18 future selected records as synthetic; actual five normal records were already terminal and accepted by the strict classifiers. This is an offline harness check, never a claim that selected smoke has passed.

A PASS establishes the ordinary CI metadata gate only. The script never marks ready or merges. Final normal merge needs fresh actual mergeability/current required checks and an ordinary exact-head conditional merge into dev respecting GitHub protection. No admin/bypass. Artifact contents remain UNINSPECTED, stdout equivalence UNPROVEN and photographic acceptance OPEN.

Sole passive observer: PID1550908, session1550908, start ticks9770606, boot46893d50-d3e6-434a-98b8-fb1cd274fea9. Its original bound is180minutes from19:37:13Z, approximately22:37:13Z. No other poller or workflow dispatch is authorized by this proposal.
