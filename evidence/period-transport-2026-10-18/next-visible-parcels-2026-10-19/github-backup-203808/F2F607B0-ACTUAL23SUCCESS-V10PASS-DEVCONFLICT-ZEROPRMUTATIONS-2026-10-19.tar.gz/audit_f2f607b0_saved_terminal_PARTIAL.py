#!/usr/bin/env python3
"""Read-only saved partial terminal records; no API or release/merge actions."""
import pathlib,json,importlib.util,hashlib,datetime
s=pathlib.Path('/workspace/shared');p=s/'verify_f2f607b0_normal_dev_gates_v10.py';assert hashlib.sha256(p.read_bytes()).hexdigest()=='8f29a7e6fbcdee9e772138b9092a0ad5ad3b7ecffa7ca7f9ff005f51d816b8d2';sp=importlib.util.spec_from_file_location('v10',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);v=m.configure();o=m.load(s/'final-f2f607b0-metadata/observer.json');saved=o.get('terminal_jobs',{});audited=[]
for c in o['latest_snapshot']['check_runs']:
 if c['status']=='completed':m.need(c['conclusion']=='success'or v.auxiliary_skip_check(c)or m.optional_skip_check(c),'Actual current check failed or has an unbound skip '+str(c['id'])+' '+str(c['conclusion']))
for rid,record in saved.items():
 if o['expected_runs'][rid]['selected_smoke']:
  run=next(r for r in o['latest_snapshot']['runs']if r['id']==int(rid));m.run_ok(run,int(rid),o['expected_runs'][rid]);v.jobs_ok(record['jobs'],int(rid),{'smoke':v.SMOKE_STEPS});audited.append({'run_id':int(rid),'job_ids':[j['id']for j in record['jobs']],'actual_required_steps_success':True})
a={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only saved actual terminal selected jobs only; not full CI gate or stdout/artifact proof','snapshot':o['latest_snapshot']['at'],'audited':audited};(s/'f2f607b0-selected-terminal-partial-audit.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps({'at':a['at'],'snapshot':a['snapshot'],'strict_actual_selected_pass':len(audited),'selected_status':o['selected_conclusions'],'normal_status':o['normal_conclusions'],'observer_error':o.get('error'),'observer_finished':o.get('finished_utc')},indent=2))
