Adds a transport study gallery with an articulated W01 wagon, open C01 and enclosed C02 carriage, skinned horse, harness and coupling previews. The separate W01 driver bench has a timber seat supported on both rails, retaining hardware and a floor-supported footboard. C02 includes a movable door with collision checks.

Reconstructed 1835 residents Otis Bardwell, Joseph Dufresne and Martin Flynn supply the named workwear references. The opt-in portable `sit_drive` authoring/export path binds the pose to the supported W01 bytes and preserves identity/date checks and ordinary idle/walk authoring. Source and published browser probes check bench framing, controls, GLB binding, supported/baseline substitution and cleanup.

These remain reconstructed engineering studies. Photographic masters, complete tack/bit fit, occupied drivers/riders, main-scene traffic and boarding/riding remain open. No production promotion is included.

Validation at `f2f607b0b6a82e9973c260d55c57fc4b661fb0b4` (tree `955d48d151c6a00e87a5d636f07a0dfcf5de505a`):

- Complete local preflight passed: **1,018 steps**, including **377 refusal self-tests**, exit 0. Post-commit changelog, ID and published-mirror checks passed.
- @ACTUAL_CI_RESULTS@
- Smoke coverage uses the existing nine ranges `1-2`, `3-4`, `5`, `6-7`, `8`, `9-12`, `13`, `14`, `15`, each requested once for desktop and mobile. The unfiltered predecessor exceeded its actual 150-minute job limit; the complete split preserves all 15 parts and both viewports without changing timeouts, assertions or budgets.
- All 26 qualification source pins and the human producer inputs are unchanged from the preceding revision. Its [successful manual workwear+seated export qualification](https://github.com/kevinrhaas/chicago/actions/runs/39289017835) remains historical; it is not represented as a new-head artifact inspection.

CI stdout equivalence remains unproven and artifact contents uninspected. Workflow metadata is not photographic acceptance, and run/input pairing is not inferred from creation order. Earlier failures, setup-only failure, timeouts and stopped zero-POST recovery plans remain preserved. [Durable recovery checkpoint](https://github.com/kevinrhaas/chicago-tickets/commit/fb6476d7e7456d08d8c88a1ae9a56a3917a95a73).
