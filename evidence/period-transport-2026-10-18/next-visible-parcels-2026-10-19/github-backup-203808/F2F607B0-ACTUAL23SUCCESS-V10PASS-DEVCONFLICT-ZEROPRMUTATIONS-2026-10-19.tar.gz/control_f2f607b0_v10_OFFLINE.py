#!/usr/bin/env python3
"""Offline verifier controls only; synthetic future selected/gate data are not CI evidence."""
import pathlib,importlib.util,json,copy,hashlib
S=pathlib.Path('/workspace/shared');p=S/'verify_f2f607b0_normal_dev_gates_v10.py';sp=importlib.util.spec_from_file_location('v10',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);v=m.configure();w=m.module('observer_inputs',m.OBSERVER,m.OBSERVER_SHA);manifest,receipt,expected=w.inputs(S/'f2f607b0-exact18-dispatch-v2/receipt.json');latest=m.load(S/'final-f2f607b0-metadata/latest.json');saved=m.load(S/'final-f2f607b0-metadata/terminal-jobs.json');runs={r['id']:r for r in latest['runs']};checks=copy.deepcopy(latest['check_runs']);results=[]
def control(name,fn,reject=False):
 try:fn()
 except Exception as e:
  if not reject:raise
  results.append({'name':name,'passed':True,'expected_rejection':str(e)});return
 if reject:raise AssertionError('Control failed to reject '+name)
 results.append({'name':name,'passed':True})
control('exact dispatch source/manifest/18 cell receipt and23 IDs',lambda:m.need(len(expected)==23,'23'))
control('immutable f2f source contracts26',lambda:v.source_ok({q:m.git('show',m.SHA+':'+q)for q in v.PINS}))
control('immutable normal source contracts',lambda:m.normal_source_contracts(v,manifest))
# All five completed normal workflows are actual saved metadata. Future smoke/gate records below are explicitly synthetic only.
actual_ids=sorted(saved);synthetic=[]
for rid,spec in expected.items():
 if str(rid)in saved:continue
 synthetic.append(rid);r=runs[rid];r.update(status='completed',conclusion='success');names={'smoke':v.SMOKE_STEPS}if spec['selected_smoke']else{'gate':m.NORMAL['gate'][1]};name,steps=next(iter(names.items()));jid=900000000000+rid;j={'id':jid,'run_id':rid,'run_attempt':1,'head_sha':m.SHA,'name':name,'status':'completed','conclusion':'success','check_run_url':f'https://api.github.com/repos/{m.REPO}/check-runs/{jid}','html_url':f'https://github.com/{m.REPO}/actions/runs/{rid}/job/{jid}','steps':[{'name':n,'number':i+1,'status':'completed','conclusion':'success'}for i,n in enumerate(steps)]};saved[str(rid)]={'run_id':rid,'attempt':1,'head_sha':m.SHA,'jobs':[j]};checks=[c for c in checks if c['html_url'].split('/actions/runs/')[-1].split('/')[0]!=str(rid)];checks.append({'id':jid,'head_sha':m.SHA,'name':name,'status':'completed','conclusion':'success','html_url':j['html_url']})
def validate(s=saved,r=runs,c=checks):
 ids,aux=m.records_ok(v,s,r,expected);m.checks_ok(v,{'total_count':len(c),'check_runs':c},ids);return aux
control('actual5 normal+synthetic future positive metadata contract',validate)
smoke=next(k for k,s in expected.items()if s['selected_smoke'])
def corrupt(which):
 s=copy.deepcopy(saved);r=copy.deepcopy(runs);c=copy.deepcopy(checks)
 if which=='workflow failure':r[smoke]['conclusion']='failure'
 elif which=='wrong head':r[smoke]['head_sha']='0'*40
 elif which=='attempt drift':r[smoke]['run_attempt']=2
 elif which=='missing saved run':del s[str(smoke)]
 elif which=='job failure under green run':s[str(smoke)]['jobs'][0]['conclusion']='failure'
 elif which=='published smoke skipped':s[str(smoke)]['jobs'][0]['steps'][-1]['conclusion']='skipped'
 elif which=='missing published smoke':s[str(smoke)]['jobs'][0]['steps'].pop()
 elif which=='check binding mismatch':s[str(smoke)]['jobs'][0]['check_run_url']='https://api.github.com/check-runs/1'
 elif which=='wrong auxiliary skip identity':next(j for j in s[str(m.AUX_RUN)]['jobs']if j['name']=='bake')['id']+=1
 elif which=='auxiliary warranted failed':next(j for j in s[str(m.AUX_RUN)]['jobs']if j['name']=='warranted')['steps'][2]['conclusion']='failure'
 elif which=='optional human skip executed':next(j for j in s[str(m.HUMAN_RUN)]['jobs']if j['name']=='teamster-studies')['steps']=[{'name':'unexpected'}]
 elif which=='mandatory check skipped':next(z for z in c if z['name']=='moving-frames')['conclusion']='skipped'
 elif which=='extra current check':c.append(dict(c[0],id=123))
 elif which=='duplicate current check':c.append(copy.deepcopy(c[0]))
 validate(s,r,c)
for name in ['workflow failure','wrong head','attempt drift','missing saved run','job failure under green run','published smoke skipped','missing published smoke','check binding mismatch','wrong auxiliary skip identity','auxiliary warranted failed','optional human skip executed','mandatory check skipped','extra current check','duplicate current check']:control(name,lambda n=name:corrupt(n),True)
report={'scope':'OFFLINE CONTROLS ONLY; no CI gate PASS, no requests, no merge readiness','source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'actual_terminal_normal_ids':actual_ids,'synthetic_future_run_ids':synthetic,'passed':len(results),'results':results};(S/'f2f607b0-v10-OFFLINE-controls.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
