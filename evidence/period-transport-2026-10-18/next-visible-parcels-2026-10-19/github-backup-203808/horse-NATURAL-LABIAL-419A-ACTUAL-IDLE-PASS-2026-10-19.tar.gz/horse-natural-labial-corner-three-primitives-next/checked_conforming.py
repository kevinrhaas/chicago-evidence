# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicit future actual-file readback entry; import does not run horse functions."""
from pathlib import Path
import json
from conforming_variant import load,audit
P=Path(__file__).parent
def checked():
 ctx=load();raw=(P/'candidate-one/candidate.glb').read_bytes();proof=json.loads((P/'candidate-one/proof.json').read_text());m,l,h,o,s,report=audit(raw,ctx,proof);m.source_face_owners=o;return m,l,h,o,s,raw
if __name__=='__main__':
 m,l,h,o,s,raw=checked();import hashlib
 report={'PASS':True,'candidate_sha256':hashlib.sha256(raw).hexdigest(),'status':'SOURCE/REST only; actualXYZ/gear/bit/visual/motion UNTESTED','total_faces':m.total,'head_faces':len(h),'newlip_faces':len(s['lips'])}
 with(P/'lip-readback-result.json').open('x')as f:f.write(json.dumps(report,indent=2)+'\n')
