# SPDX-License-Identifier: CC0-1.0
"""Fixed proposed labial INDEX topology and existing-source angular diagnosis.

New vertices are labels only. Never evaluates proposed P/N/J/W or a horse Model.
Existing native coordinates determine source-chart order and radial-domain facts.
"""
from pathlib import Path
from collections import defaultdict
import math,json,hashlib,sys
P=Path(__file__).parent
sys.path.insert(0,'/workspace/shared/horse-neutral-rail-closed-symbolic-next')
from topology_guard import manifold
def require(value,message):
 if not value:raise ValueError(message)
def sub(a,b):return[x-y for x,y in zip(a,b)]
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def norm(a):return math.sqrt(dot(a,a))
def unit(a):
 n=norm(a);require(n>0,'nonzero existing-source frame');return[x/n for x in a]
def uses(tri):
 e=defaultdict(list)
 for f in tri:
  for a,b in zip(f,f[1:]+f[:1]):e[tuple(sorted((a,b)))].append((a,b))
 return e
raw=Path('/workspace/shared/horse-oral-channel-diagonal-candidate/source/frozen-head.json').read_bytes()
require(hashlib.sha256(raw).hexdigest()=='ac4d96ab6ae8d0ef5956686a3a9c213ebce1dd9e76f5e91c4e376b319429b5b3','native identity')
s=json.loads(raw);facts=json.loads((P/'NATIVE-SKIN-INDEX-PROOF.json').read_text());corr=json.loads((P/'NATIVE-BIT-CORRESPONDENCE.json').read_text());ids=set(facts['native_source_face_ids']);outer=facts['outer_boundary'];bd={tuple(sorted(e))for e in zip(outer,outer[1:]+outer[:1])};line=[[-.105,-.20,.39],[0,-.205,.4],[.105,-.20,.39]]
regions=[]
for side,h in zip(['l','r'],corr['hits']):
 vv=set(s['faces'][h['source_face']]);rr={i for i in ids if vv.intersection(s['faces'][i])};tri=[['h:'+str(v)for v in s['faces'][i]]for i in sorted(rr)];ee=uses(tri);de=[u[0]for u in ee.values()if len(u)==1];nxt=dict(de);require(len(nxt)==len(de),'one directed source successor');v=min(nxt);loop=[]
 while v not in loop:loop.append(v);v=nxt[v]
 require(v==loop[0]and len(loop)==len(de)==9,'one exact nine-edge source neighborhood');require(not set(loop)&set(outer),'portal neighborhood strictly interior')
 tp=manifold(tri,{tuple(sorted(e))for e in de},1);require(tp['F']==13 and tp['V']==12,'fixed thirteen-face source neighborhood')
 a,b=line[h['segment']:h['segment']+2];t=h['segment_fraction_float'];c=[(1-t)*x+t*y for x,y in zip(a,b)];d=unit(sub(b,a));z=[0,0,1];u=unit([z[k]-dot(z,d)*d[k]for k in range(3)]);v=cross(d,u)
 xy=[[dot(sub(s['positions'][int(tag[2:])],c),u),dot(sub(s['positions'][int(tag[2:])],c),v)]for tag in loop]
 crosses=[x[0]*y[1]-x[1]*y[0]for x,y in zip(xy,xy[1:]+xy[:1])];sign=1 if crosses[0]>0 else-1;require(all(sign*x>0 for x in crosses),'existing projected source polygon strictly star-shaped about actual source intersection')
 margins=[]
 for x,y in zip(xy,xy[1:]+xy[:1]):
  e=sub(y,x);q=max(0,min(1,-dot(x,e)/dot(e,e)));margins.append(norm([x[k]+q*e[k]for k in range(2)]))
 require(min(margins)>.008,'fixed proposed8mm portal strictly within existing projected source boundary')
 phases={tag:(sign*math.atan2(p[1],p[0]))%(2*math.pi)for tag,p in zip(loop,xy)};ordered=sorted(loop,key=phases.get);require(all(ordered[(i+1)%9]==nxt[tag]for i,tag in enumerate(ordered)),'angular order matches existing boundary topology')
 regions.append({'side':side,'hit_source_face':h['source_face'],'retired_native_source_faces':sorted(rr),'source_boundary':loop,'native_topology':tp,'existing_source_angular_orientation':sign,'existing_source_angular_phases':phases,'angular_order':ordered,'existing_source_projected_edge_distance_to_axis_m':min(margins),'distance_is':'2D existing-source domain diagnostic, NOT actual3D tissue/gear clearance','existing_source_frame':{'center_from_existing_centerline_and_facet':c,'axis':d,'u_projected_global_z':u,'v_axis_cross_u':v}})
require(not set(regions[0]['retired_native_source_faces'])&set(regions[1]['retired_native_source_faces']),'source neighborhoods disjoint')
retired=set().union(*(set(r['retired_native_source_faces'])for r in regions));remaining=ids-retired;require(len(remaining)==235,'native exterior235')
def native_alias(tag):return tag if tag in outer else'labial-native:'+tag[2:]
T=[];owners=[]
def face(f,owner):require(len(set(f))==3,'three distinct symbolic vertices');T.append(f);owners.append(owner)
for i in sorted(remaining):face([native_alias('h:'+str(v))for v in s['faces'][i]],{'kind':'restored_native_skin','source_face':i})
for r in regions:
 side=r['side'];ordered=r['angular_order'];phases=r['existing_source_angular_phases'];o=native_alias(ordered[-1]);n='labial:'+side+':blend1:0';events=[(phases[tag],0,tag)for tag in ordered]+[(2*math.pi*j/32,1,j%32)for j in range(1,33)]
 require(len({e[0]for e in events})==41,'no equal-phase symbolic zipper tie; no floating heuristic')
 for phase,kind,tag in sorted(events):
  if kind==0:
   new=native_alias(tag);face([o,new,n],{'kind':'outer_blend_zipper','side':side});o=new
  else:
   new='labial:'+side+':blend1:'+str(tag);face([o,new,n],{'kind':'outer_blend_zipper','side':side});n=new
 require(o==native_alias(ordered[-1])and n=='labial:'+side+':blend1:0','zipper closed')
 for ar,br in [('blend1','blend2'),('blend2','portal')]:
  for j in range(32):
   k=(j+1)%32;a='labial:'+side+':'+ar+':'+str(j);b='labial:'+side+':'+ar+':'+str(k);c='labial:'+side+':'+br+':'+str(k);d='labial:'+side+':'+br+':'+str(j)
   face([a,b,c],{'kind':'exterior_labial_blend','side':side,'rows':[ar,br]});face([a,c,d],{'kind':'exterior_labial_blend','side':side,'rows':[ar,br]})
require(regions[0]['existing_source_angular_orientation']==-1 and regions[1]['existing_source_angular_orientation']==1,'fixed left/right source winding')
rows=[['labial:l:portal:'+str(j)for j in range(32)],['labial:vault-center:'+str(j)for j in range(32)],['labial:r:portal:'+str((-j)%32)for j in range(32)]]
for ar,br in zip(rows,rows[1:]):
 for j in range(32):
  k=(j+1)%32;face([ar[j],ar[k],br[k]],{'kind':'inner_labial_vestibule'});face([ar[j],br[k],br[j]],{'kind':'inner_labial_vestibule'})
top=manifold(T,bd,-1);require(top=={'V':385,'E':1087,'F':701,'Euler':-1,'boundary':71,'connected':True,'directed_manifold':True},'fixed complete701 patch cardinalities')
require({u[0]for e,u in uses(T).items()if len(u)==1}==set(zip(outer,outer[1:]+outer[:1])),'new symbolic outer boundary agrees exactly oriented')
result={'scope':'Proposed701 index-only mouth patch; NO proposed P/N/J/W evaluated/exported','regions':regions,'native_faces_retained_in_new_patch':sorted(remaining),'source_boundary':outer,'proposed_patch_faces':T,'proposed_patch_face_owners':owners,'derived_proposed_topology':top,'proposed_head_faces':2651+len(T),'proposed_model_faces':15068-2313+len(T),'retired_old798e_mouth_faces':2313,'same_functional_guards':'All original8 structural scopes, all36gear, negative078, full actualbit/virtualcaps/sample classification/readback; no numeric predicate changes','not_claimed':['embedded geometry','source normals smoothness','actual clearance','natural/photo appearance','motion','oral pressure','jaw-opening topology']}
with(P/'PROPOSED-SYMBOLIC-PORTALS.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'patch':top,'head':result['proposed_head_faces'],'horse':result['proposed_model_faces'],'regions':[(r['hit_source_face'],r['existing_source_projected_edge_distance_to_axis_m'])for r in regions]}))
