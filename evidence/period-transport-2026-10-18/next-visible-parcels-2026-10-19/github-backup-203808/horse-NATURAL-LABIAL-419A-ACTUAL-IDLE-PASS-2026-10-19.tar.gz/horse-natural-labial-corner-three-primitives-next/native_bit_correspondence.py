# SPDX-License-Identifier: CC0-1.0
"""Exact-rational existing native-skin/authored-bit correspondence, not a fit test.

Only immutable source positions are read. This emits facet/barycentric facts,
never proposed horse vertices. No evaluator, Model, SAT or capture import.
"""
from pathlib import Path
from fractions import Fraction as Q
import hashlib,json
P=Path(__file__).parent
def require(value,message):
 if not value:raise ValueError(message)
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def cross(a,b):return(a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def dot(a,b):return sum(x*y for x,y in zip(a,b))
raw=Path('/workspace/shared/horse-oral-channel-diagonal-candidate/source/frozen-head.json').read_bytes()
require(hashlib.sha256(raw).hexdigest()=='ac4d96ab6ae8d0ef5956686a3a9c213ebce1dd9e76f5e91c4e376b319429b5b3','native source identity')
s=json.loads(raw,parse_float=Q);facts=json.loads((P/'NATIVE-SKIN-INDEX-PROOF.json').read_text());ids=facts['native_source_face_ids']
points=[tuple(map(Q,('-0.105','-0.20','0.39'))),tuple(map(Q,('0','-0.205','0.40'))),tuple(map(Q,('0.105','-0.20','0.39')))]
hits=[];degenerate=[]
for segment,(a,b)in enumerate(zip(points,points[1:])):
 d=sub(b,a)
 for fi in ids:
  verts=[tuple(map(Q,s['positions'][v]))for v in s['faces'][fi]];p0,p1,p2=verts;e1=sub(p1,p0);e2=sub(p2,p0);pv=cross(d,e2);det=dot(e1,pv)
  if not det:
   if dot(sub(a,p0),cross(e1,e2))==0:degenerate.append({'segment':segment,'source_face':fi,'reason':'coplanar exact; no invented intersection'})
   continue
  tv=sub(a,p0);u=dot(tv,pv)/det;qv=cross(tv,e1);v=dot(d,qv)/det;t=dot(e2,qv)/det
  if 0<=u and 0<=v and u+v<=1 and 0<=t<=1:
   hit={'segment':segment,'source_face':fi,'source_vertices':s['faces'][fi],'segment_fraction_exact':str(t),'facet_barycentric_exact':[str(1-u-v),str(u),str(v)],'strict_facet_interior':min(1-u-v,u,v)>0,'segment_fraction_float':float(t),'facet_barycentric_float':[float(1-u-v),float(u),float(v)]};hits.append(hit)
require(len(hits)==2 and {h['segment']for h in hits}=={0,1}and all(h['strict_facet_interior']for h in hits),'exactly two unambiguous native corner intersections')
result={'scope':'Exact rational correspondence of existing authored bit centerline with existing native261 source facets only; NOT proposed horse XYZ or clearance','native_sha256':hashlib.sha256(raw).hexdigest(),'source_index_proof_sha256':hashlib.sha256((P/'NATIVE-SKIN-INDEX-PROOF.json').read_bytes()).hexdigest(),'existing_centerline_head_local':[[str(v)for v in p]for p in points],'hits':hits,'coplanar_segment_facets':degenerate,'no_nearest_matching':True,'not_claimed':['continuous bit cylinder equals captured mesh','portal clearance','new tissue embedding','source skin anatomy/photo acceptance','pressure/motion']}
with(P/'NATIVE-BIT-CORRESPONDENCE.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'hits':hits,'coplanar_count':len(degenerate)},indent=2))
