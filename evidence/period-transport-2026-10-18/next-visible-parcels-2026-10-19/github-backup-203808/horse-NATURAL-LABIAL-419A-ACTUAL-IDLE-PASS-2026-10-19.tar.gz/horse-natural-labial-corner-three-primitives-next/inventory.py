# SPDX-License-Identifier: CC0-1.0
"""Read old798e index/owner/captured-bit data only; no proposed horse XYZ."""
from pathlib import Path
from collections import defaultdict,Counter
import json,struct,hashlib,sys
P=Path(__file__).parent;D=Path('/workspace/shared/horse-neutral-rail-closed-producer-next')
def require(value,message):
 if not value:raise ValueError(message)
sys.path.insert(0,'/workspace/shared/horse-neutral-rail-closed-symbolic-next')
from topology_guard import manifold
raw=(D/'candidate-one/candidate.glb').read_bytes();require(hashlib.sha256(raw).hexdigest()=='798e864bd34dd52de5fa5e19acbb3a08ae6bcc5c5731a44820671871219e699b','immutable798e identity');n=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+n]);buf=raw[28+n:];rb=json.loads((D/'candidate-one/readback.json').read_text());owners={int(k):v for k,v in rb['source_face_owners'].items()};labels={(r['mesh'],r['vertex']):r['label']for r in rb['source_labels']};proof=json.loads((D/'candidate-one/proof.json').read_text());remap={int(k):v for k,v in rb['old_to_new'].items()};g=json.loads(Path('/workspace/shared/horse-combined-oral-neck-mane-prefix-next/candidate-one/graft-proof.json').read_text());oldhead=set(g['head_faces']);head={v for k,v in remap.items()if k in oldhead}|{i for i,o in owners.items()if o['kind']=='conforming_mouth'};post={remap[int(k)]for k in proof['detail']['preserved110_posterior']};mouth=post|{i for i,o in owners.items()if o['kind']=='conforming_mouth'};T=[]
for mi,m in enumerate(doc['meshes']):
 for pi,pr in enumerate(m['primitives']):
  a=doc['accessors'][pr['indices']];v=doc['bufferViews'][a['bufferView']];fmt={5121:'B',5123:'H',5125:'I'}[a['componentType']];size=struct.calcsize('<'+fmt);offset=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',size);ids=[struct.unpack_from('<'+fmt,buf,offset+i*stride)[0]for i in range(a['count'])];T.extend([[labels[mi,i]for i in ids[j:j+3]]for j in range(0,len(ids),3)])
E=defaultdict(list)
for i in head:
 for a,b in zip(T[i],T[i][1:]+T[i][:1]):E[tuple(sorted((a,b)))].append(i)
bd={e for e,u in E.items()if sum(i in mouth for i in u)==1};vertices={v for e in bd for v in e};halo={i for i in head-mouth if any(v in vertices for v in T[i])};expanded=mouth|halo;newbd={e for e,u in E.items()if sum(i in expanded for i in u)==1};summary=manifold([T[i]for i in sorted(expanded)],newbd,-1)
# Derive oriented single new boundary and protect every other head face.
Dedges=[]
for i in expanded:
 for a,b in zip(T[i],T[i][1:]+T[i][:1]):
  if tuple(sorted((a,b)))in newbd:Dedges.append((a,b))
nxt=dict(Dedges);require(len(nxt)==len(Dedges),'unique directed boundary successor');start=Dedges[0][0];v=start;loop=[]
while v not in loop:loop.append(v);v=nxt[v]
require(v==start and len(loop)==len(Dedges),'one exact oriented boundary loop')
r={'scope':'Read-only old798e source index/owner inventory; no new positions/producer/evaluator/export/capture/SAT','candidate_sha256':hashlib.sha256(raw).hexdigest(),'old_mouth2176':sorted(mouth),'previously_preserved_original_posterior110':sorted(post),'proposed_full_retirement':sorted(expanded),'added_source_skin_halo137':sorted(halo),'added_halo_owners':{str(i):owners[i]for i in sorted(halo)},'proposed_retired_owners':{str(i):owners[i]for i in sorted(expanded)},'proposed_retired_source_triangles':{str(i):T[i]for i in sorted(expanded)},'derived_patch_topology':summary,'unchanged_outer_boundary':loop,'unrelated_head_faces_preserved':sorted(head-expanded),'skin_halo_semantic_counts':dict(Counter(owners[i]['kind']+':'+owners[i].get('source_owner',{}).get('kind','')for i in halo)),'important':'Root explicitly permitted proposing replacement of protected posterior110. This inventory is NOT geometry authority or a released model trial.'}
with(P/'EXACT-SCOPE-INVENTORY.json').open('x')as f:f.write(json.dumps(r,indent=2)+'\n')
print(json.dumps({'retire':len(expanded),'halo':len(halo),'preserved_head':len(head-expanded),'patch':summary,'boundary':len(loop),'only_h_labels':all(v.startswith('h:')for v in loop)},indent=2))
