# Frozen source status: natural labial corners

SOURCE ONLY. No proposed horse P/N/J/W, producer/evaluator/Model, actual capture,
collision/distance scan or browser run has occurred in this package. Pure existing
index/native-source/bit-source reads and12 synthetic/mocked controls completed.

PLAN.md defines the single fixed recipe and its limits. Retire precisely2313
current798e faces; preserve all2651 other head faces and unchanged71 source outer
aliases. The independently assembled proposed full head is1689V/5042E/3352F,
Euler−1,28 neck edges; new mouth385V/1087E/701F, Euler−1,71 outer edges. The old110
posterior faces are explicitly retired under root's new ownership authority.

Parent798e and its978b combined idle engineering capsule, independent c07f audit
and4015 appearance capsule remain immutable.798e appearance is UNACCEPTED.
New natural/photo/motion/unbitted/pressure/jaw-opening acceptance remains OPEN.

The unchanged actual8 structural scopes and all36 gear/old078negative/fullbit
distance+virtual-volume/readback checks remain mandatory. The structural wrapper
changes only explicitly source-derived cohort labels and mouth counts from
1120V/2176F/66boundary/3231internaledges to385V/701F/71boundary/1016internaledges.
The original full head handler derives the same genus1/28neck topology and now
must have3352 active faces. The producer additionally validates all decoded mouth
and full-head vertex links against the complete symbolic proofs.

run_once.py enforces exactlyCPU0/all4maththreads1, exclusive operator/outputs,
180s TOTAL, per-phase caps5/30/30/15/20/110/90/30s and first failure STOP. Owned
children have separate process groups; every wait BaseException kills/reaps the
whole owned group. SIGTERM is converted to KeyboardInterrupt for that cleanup.
Before/after source manifest BYTES and every pinned input must agree for PASS.
No automatic retry, completion extension, model search, browser or app work.

Root authorized ONE180s trial only after independent full frozen-source/caller
PASS. Required exact invocation after that review and CPU0 handoff:

    timeout --signal=TERM --kill-after=5s 180s taskset -c 0 env PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 python /workspace/shared/horse-natural-labial-corner-three-primitives-next/run_once.py ROOT_RELEASE_ONE_NATURAL_LABIAL_CORNER

Use the supported require_escalated execution profile because the capture stage
uses Node IPC. No new approval round is required after the source PASS, but the
single CPU0 lane must be free. No appearance trial is included in this caller.

The source archive is
/workspace/shared/horse-NATURAL-LABIAL-CORNER-THREE-PRIMITIVE-SOURCE-2026-10-19.tar.gz.
Its digest is recorded outside the archive to avoid circular manifest claims.

Independent review of d977 caught117 retired skin-halo faces in(0,0). That
archive is preserved. This successor routes precisely1218/978/117 retired faces
through(1,0)/(1,1)/(0,0). Only head primitives receive new attribute accessors;
body(0,0) preserves its original attributes and all unknown metadata, changing
only its index accessor. Seven appended accessors/views =4headattributes+3indices.
The complete geometry fields, symbolic topology, guards and180s caller are exact
to d977. A revised synthetic serializer control checks the seventh append and
body metadata/attribute preservation. No actual proposed evaluation has run.
