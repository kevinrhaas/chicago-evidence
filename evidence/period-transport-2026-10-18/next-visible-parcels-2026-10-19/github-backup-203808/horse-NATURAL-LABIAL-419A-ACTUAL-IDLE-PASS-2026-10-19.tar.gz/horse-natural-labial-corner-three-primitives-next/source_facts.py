# SPDX-License-Identifier: CC0-1.0
"""Read immutable native topology and bit capture; never generate horse geometry.

No proposed field, producer, Model, scan, capture or evaluator import. The only
position reads below are the already stored actual bit vertices.
"""
from pathlib import Path
from collections import defaultdict
import hashlib,json,struct,sys
P=Path(__file__).parent
sys.path.insert(0,'/workspace/shared/horse-neutral-rail-closed-symbolic-next')
from topology_guard import manifold
def require(value,message):
 if not value:raise ValueError(message)
def read(path):
 raw=Path(path).read_bytes();return raw,hashlib.sha256(raw).hexdigest()
invraw,invhash=read(P/'EXACT-SCOPE-INVENTORY.json');inv=json.loads(invraw)
nativepath='/workspace/shared/horse-oral-channel-diagonal-candidate/source/frozen-head.json'
nativeraw,nativehash=read(nativepath)
require(nativehash=='ac4d96ab6ae8d0ef5956686a3a9c213ebce1dd9e76f5e91c4e376b319429b5b3','native skin identity')
native=json.loads(nativeraw)
oralpath='/workspace/shared/horse-oral-channel-diagonal-candidate/candidate-one/head-source-surface.json'
oralraw,oralhash=read(oralpath);oral=json.loads(oralraw)
require(oral['oral_authority']['frozen_head_sha256']==nativehash,'native/oral association')
ids=set(oral['oral_authority']['retired_source_faces'])|{o['source_owner']['source_face']for o in inv['added_halo_owners'].values()}
require(len(ids)==261,'exact native261 skin substrate')
tri=[['h:'+str(v)for v in native['faces'][i]]for i in sorted(ids)]
loop=inv['unchanged_outer_boundary'];bd={tuple(sorted(e))for e in zip(loop,loop[1:]+loop[:1])}
proof=manifold(tri,bd,1)
directed=defaultdict(list)
for t in tri:
 for a,b in zip(t,t[1:]+t[:1]):directed[tuple(sorted((a,b)))].append((a,b))
require({u[0]for e,u in directed.items()if len(u)==1}==set(zip(loop,loop[1:]+loop[:1])),'native boundary orientation exactly agrees with retired patch')
native_result={'scope':'Existing native source INDEX proof only, no proposed P/JW','native_input':[nativepath,nativehash],'oral_input':[oralpath,oralhash],'inventory_sha256':invhash,'native_source_face_ids':sorted(ids),'native_source_triangles':{str(i):['h:'+str(v)for v in native['faces'][i]]for i in sorted(ids)},'derived_topology':proof,'outer_boundary':loop,'boundary_directed_exact':True,'not_claimed':['native skin natural/photo quality','new portal topology or geometry','bit compatibility','embedding']}
with(P/'NATIVE-SKIN-INDEX-PROOF.json').open('x')as f:json.dump(native_result,f,indent=2);f.write('\n')
capture=Path('/workspace/shared/horse-neutral-rail-closed-producer-next/idle-fit/capture')
metaraw,metahash=read(capture/'candidate.json');binraw,binhash=read(capture/'candidate.f64');meta=json.loads(metaraw)
require(meta['input'][1]=='fe76c95b49234da64700a1e20741b4998e8cfbae69571387d49bf5bb23ef04b1','fixed gear GLB identity')
require(meta['buffer_sha256']==binhash,'actual existing gear capture identity')
require(len(binraw)==meta['triangleCount']*9*8,'complete captured triangle buffer')
H=meta['head_world'];require(H==[1,0,0,0,0,1,0,0,0,0,1,0,0,1.88,.8,1],'explicit actual head-local translation')
rows=[]
for name,count in [('bit_bar',32),('bit_ring_l',576),('bit_ring_r',576)]:
 selected=[m for m in meta['meshes']if m['name']==name];require(len(selected)==1 and selected[0]['count']==count,'one full fixed bit part '+name);m=selected[0]
 values=struct.unpack_from('<'+'d'*(count*9),binraw,m['start']*9*8)
 points=[tuple(values[i:i+3])for i in range(0,len(values),3)];unique=sorted(set(points))
 local=[[p[0],p[1]-1.88,p[2]-.8]for p in unique]
 rows.append({'name':name,'source':m,'actual_world_unique_points':unique,'actual_head_local_unique_points':local,'world_aabb':[[min(p[k]for p in unique),max(p[k]for p in unique)]for k in range(3)],'unique_points':len(unique),'triangle_bytes_sha256':hashlib.sha256(binraw[m['start']*72:(m['start']+count)*72]).hexdigest()})
result={'scope':'Existing fixed actual idle0 gear coordinates read only; no new horse P/JW or fit query','capture_json':[str(capture/'candidate.json'),metahash],'capture_f64':[str(capture/'candidate.f64'),binhash],'fixed_gear_glb':meta['input'],'pose':meta['pose'],'root_world':meta['root_world'],'head_world':H,'parts':rows,'design_source_bar_centerline_head_local':[[-.105,-.20,.39],[0,-.205,.40],[.105,-.20,.39]],'design_source_radius_m':.006,'source_vs_actual':'Centerline/radius describe authored tube input; complete captured side triangles and rings above remain actual guard authority. No continuous perfect-cylinder equivalence is asserted.','not_claimed':['proposed portal coordinates','new bit clearance','native skin compatibility','pressure','motion']}
with(P/'FIXED-ACTUAL-BIT-INVENTORY.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'native_skin':proof,'actual_bit_parts':[(r['name'],r['source']['count'],r['unique_points'])for r in rows]}))
