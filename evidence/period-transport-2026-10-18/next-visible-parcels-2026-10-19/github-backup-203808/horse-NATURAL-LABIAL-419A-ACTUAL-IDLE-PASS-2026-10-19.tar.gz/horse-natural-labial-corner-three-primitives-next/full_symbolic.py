# SPDX-License-Identifier: CC0-1.0
"""Existing GLB index streams plus proposed labels only; no position reads."""
from pathlib import Path
import json,struct,hashlib,sys
P=Path(__file__).parent;OLD=Path('/workspace/shared/horse-neutral-rail-closed-producer-next')
sys.path.insert(0,'/workspace/shared/horse-neutral-rail-closed-symbolic-next')
from topology_guard import manifold
def require(value,message):
 if not value:raise ValueError(message)
raw=(OLD/'candidate-one/candidate.glb').read_bytes();require(hashlib.sha256(raw).hexdigest()=='798e864bd34dd52de5fa5e19acbb3a08ae6bcc5c5731a44820671871219e699b','old798e identity');n=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+n]);b=raw[28+n:];rb=json.loads((OLD/'candidate-one/readback.json').read_text());labels={(r['mesh'],r['vertex']):r['label']for r in rb['source_labels']};T=[]
for mi,m in enumerate(d['meshes']):
 for pr in m['primitives']:
  a=d['accessors'][pr['indices']];v=d['bufferViews'][a['bufferView']];fmt={5121:'B',5123:'H',5125:'I'}[a['componentType']];size=struct.calcsize('<'+fmt);off=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',size);ii=[struct.unpack_from('<'+fmt,b,off+k*stride)[0]for k in range(a['count'])];T.extend([[labels[mi,i]for i in ii[j:j+3]]for j in range(0,len(ii),3)])
inv=json.loads((P/'EXACT-SCOPE-INVENTORY.json').read_text());A=json.loads((P/'PROPOSED-SYMBOLIC-PORTALS.json').read_text());kept=inv['unrelated_head_faces_preserved'];whole=[T[i]for i in kept]+A['proposed_patch_faces'];seam=[24]+list(range(13))+[36]+list(range(60,72))+[48];loop=['h:'+str(v)for v in seam];bd={tuple(sorted(e))for e in zip(loop,loop[1:]+loop[:1])};tp=manifold(whole,bd,-1)
require(tp=={'V':1689,'E':5042,'F':3352,'Euler':-1,'boundary':28,'connected':True,'directed_manifold':True},'Exact independently assembled full head topology')
with(P/'FULL-HEAD-SYMBOLIC-PROOF.json').open('x')as f:json.dump({'scope':'INDEX ONLY; unchanged2651 actual source head faces plus proposed701 labels; no newP/JW/Model/evaluator','topology':tp,'retained_actual798e_head_faces':kept,'neck_boundary':loop,'retirement_count':len(inv['proposed_full_retirement']),'new_patch_count':len(A['proposed_patch_faces'])},f,indent=2);f.write('\n')
print(json.dumps(tp))
