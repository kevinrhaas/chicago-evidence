# SPDX-License-Identifier: CC0-1.0
"""Pure index, synthetic metadata and mocked caller controls; NO horse fields."""
from pathlib import Path
import ast,copy,json,hashlib,subprocess,sys,tempfile,shutil,types,signal
P=Path(__file__).parent
def require(value,message):
 if not value:raise ValueError(message)
rows=[]
for flags in[[],['-O']]:
 with tempfile.TemporaryDirectory(prefix='labial-index-only-')as directory:
  dest=Path(directory)
  for name in['symbolic_portals.py','full_symbolic.py','NATIVE-SKIN-INDEX-PROOF.json','NATIVE-BIT-CORRESPONDENCE.json','EXACT-SCOPE-INVENTORY.json']:
   shutil.copy2(P/name,dest/name)
  for script,out in[('symbolic_portals.py','PROPOSED-SYMBOLIC-PORTALS.json'),('full_symbolic.py','FULL-HEAD-SYMBOLIC-PROOF.json')]:
   r=subprocess.run([sys.executable,*flags,str(dest/script)],capture_output=True,text=True,timeout=15);require(r.returncode==0,r.stderr);require((dest/out).read_bytes()==(P/out).read_bytes(),'Deterministic index-only source result');rows.append({'control':'index-only exact replay','script':script,'optimized':bool(flags),'PASS':True})
tree=ast.parse((P/'conforming_variant.py').read_text());serialize=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='serialize');ATTRS=('POSITION','NORMAL','JOINTS_0','WEIGHTS_0');calls=[]
def append(d,b,values,typ,comp,target=34962):
 calls.append((values,typ,comp,target));d['accessors'].append({'synthetic':len(calls)});d['bufferViews'].append({'synthetic':len(calls)});b.extend(b'append');return 100+len(calls)
ns={'copy':copy,'ATTRS':ATTRS,'append':append,'encode':lambda d,b:(d,bytes(b))};exec(compile(ast.fix_missing_locations(ast.Module(body=[serialize],type_ignores=[])),'exact-source-serialize','exec'),ns)
primitive={'attributes':{'old':1},'indices':2,'material':3,'mode':4,'extras':{'coat':{'source':'preserve nested provenance'}},'extensions':{'unknown':{'keep':[1,2]}},'future_field':17}
doc={'accessors':[{'original':1}],'bufferViews':[{'original':2}],'buffers':[{'byteLength':6}],'meshes':[{'primitives':[copy.deepcopy(primitive)]},{'primitives':[copy.deepcopy(primitive),copy.deepcopy(primitive)]}],'nodes':[{'skin':0}],'skins':[{'joints':[0]}],'animations':[{'name':'idle'}]};original=copy.deepcopy(doc)
class Flat:
 def reshape(self,value):return self
old=types.SimpleNamespace(d=doc,b=bytearray(b'prefix'));d,b=ns['serialize']({'model':old},{k:object()for k in ATTRS},{(1,0):Flat(),(1,1):Flat(),(0,0):Flat()});require(doc==original,'Serializer never mutates source doc');require(b.startswith(b'prefix')and len(calls)==7,'Exact seven append operations/source prefix');require(d['meshes'][0]['primitives'][0]['attributes']==doc['meshes'][0]['primitives'][0]['attributes'],'Body attribute accessors exact')
for key,value in primitive.items():
 if key!='indices':require(d['meshes'][0]['primitives'][0][key]==value,'Body primitive changes only indices')
for p in d['meshes'][1]['primitives']:
 for key in primitive:
  if key not in['attributes','indices']:require(p[key]==primitive[key],'Unknown primitive metadata preserved')
rows.append({'control':'Exact serialize AST, wholly synthetic document/arrays,7append and unknown metadata/body attribute preservation','PASS':True})
tree=ast.parse((P/'run_once.py').read_text());candidate=[n for n in ast.walk(tree)if isinstance(n,ast.Try)and n.handlers and isinstance(n.handlers[0].type,ast.Name)and n.handlers[0].type.id=='BaseException'and any(isinstance(q,ast.Attribute)and q.attr=='wait'for q in ast.walk(n.body[0]))];require(len(candidate)==1,'One exact owned wait handler')
fun=ast.FunctionDef(name='wait_mock',args=ast.arguments(posonlyargs=[],args=[ast.arg(arg=n)for n in['child','remaining','os','signal','subprocess']],kwonlyargs=[],kw_defaults=[],defaults=[]),body=[candidate[0],ast.Return(value=ast.Name(id='code',ctx=ast.Load()))],decorator_list=[]);ns={};exec(compile(ast.fix_missing_locations(ast.Module(body=[fun],type_ignores=[])),'exact-owned-child-cleanup','exec'),ns)
for exc in[subprocess.TimeoutExpired('mock',1),KeyboardInterrupt('mock'),SystemExit('mock')]:
 for disappeared in[False,True]:
  events=[]
  class Child:
   pid=987654
   def wait(self,timeout=None):
    events.append(('wait',timeout))
    if len([x for x in events if x[0]=='wait'])==1:raise exc
    return 0
  def killpg(pid,sig):
   events.append(('killpg',pid,sig))
   if disappeared:raise ProcessLookupError('mock already gone')
  code=None;caught=None
  try:code=ns['wait_mock'](Child(),1,types.SimpleNamespace(killpg=killpg),signal,subprocess)
  except BaseException as e:caught=e
  require(events==[('wait',1),('killpg',987654,signal.SIGKILL),('wait',None)],'Kill/reap whole owned group on every exception')
  require(code==124 and caught is None if isinstance(exc,subprocess.TimeoutExpired)else caught is exc,'Exact timeout result or original BaseException rethrow');rows.append({'control':'Exact wait AST mocks','exception':type(exc).__name__,'group_disappeared':disappeared,'PASS':True})
handler=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='interrupted');ns={};exec(compile(ast.fix_missing_locations(ast.Module(body=[handler],type_ignores=[])),'exact-SIGTERM-handler','exec'),ns)
try:ns['interrupted'](15,None)
except KeyboardInterrupt:rows.append({'control':'SIGTERM becomes cleanup-routed BaseException','PASS':True})
else:raise ValueError('SIGTERM handler must raise')
for f in P.rglob('*.py'):ast.parse(f.read_text(),filename=str(f))
result={'PASS':True,'scope':'SOURCE-ONLY controls: existing index replay, wholly synthetic serializer, owned-child mocks. NO proposed horse P/N/J/W, producer/evaluator/Model/SAT/capture/browser run','controls':rows}
with(P/'SOURCE-ONLY-CONTROLS.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'PASS':True,'controls':len(rows)}))
