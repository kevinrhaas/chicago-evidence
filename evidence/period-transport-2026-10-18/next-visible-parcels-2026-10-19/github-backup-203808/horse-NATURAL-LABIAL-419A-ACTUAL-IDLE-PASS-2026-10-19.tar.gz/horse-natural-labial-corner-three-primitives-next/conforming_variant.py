# SPDX-License-Identifier: GPL-3.0-or-later
"""One fixed native-labial replacement. Import never evaluates horse geometry."""
from pathlib import Path
from fractions import Fraction as Q
import sys,json,hashlib,copy,collections,math
import numpy as np
HELP=Path('/workspace/shared/horse-neck-hybrid-pipeline-next')
sys.path.insert(1,str(HELP))
from ownership import Model,ATTRS
from glb_data import append,encode
from topology_guard import manifold
P=Path(__file__).parent
OLD=Path('/workspace/shared/horse-neutral-rail-closed-producer-next')
PARENT='798e864bd34dd52de5fa5e19acbb3a08ae6bcc5c5731a44820671871219e699b'
ORIGIN=np.array([0.,1.88,.8])
def require(value,message):
 if not value:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def load():
 for name,digest in json.loads((P/'LOCAL-PINS.json').read_text()).items():require(sha((P/name).read_bytes())==digest,'Local source pin:'+name)
 for name,digest in json.loads((P/'EXTERNAL-HASHES.json').read_text()).items():require(sha(Path(name).read_bytes())==digest,'External pin:'+name)
 raw=(OLD/'candidate-one/candidate.glb').read_bytes();require(sha(raw)==PARENT,'Immutable798e parent');m=Model(raw);rb=json.loads((OLD/'candidate-one/readback.json').read_text());require(rb['PASS']is True and rb['candidate_sha256']==PARENT,'Immutable decoded parent identity')
 labels={(r['mesh'],r['vertex']):r['label']for r in rb['source_labels']};owners={int(k):v for k,v in rb['source_face_owners'].items()};inv=json.loads((P/'EXACT-SCOPE-INVENTORY.json').read_text());A=json.loads((P/'PROPOSED-SYMBOLIC-PORTALS.json').read_text());retired=set(inv['proposed_full_retirement']);preserved=set(inv['unrelated_head_faces_preserved']);head=retired|preserved
 require(m.total==15068 and set(owners)==set(range(m.total))and len(retired)==2313 and len(preserved)==2651 and len(head)==4964 and not retired&preserved,'Exact complete parent/retirement/head ownership')
 require(inv['candidate_sha256']==PARENT and A['retired_old798e_mouth_faces']==2313 and A['proposed_model_faces']==13456 and A['proposed_head_faces']==3352,'Pinned scope amendment')
 require(A['derived_proposed_topology']=={'V':385,'E':1087,'F':701,'Euler':-1,'boundary':71,'connected':True,'directed_manifold':True}and len(A['proposed_patch_faces'])==len(A['proposed_patch_face_owners'])==701,'Reviewed exact701 symbolic manifold')
 require(A['source_boundary']==inv['unchanged_outer_boundary'],'One exact71 source boundary')
 routes=collections.Counter((m.descriptor(g)['mesh'],m.descriptor(g)['primitive'])for g in retired);require(routes=={(1,0):1218,(1,1):978,(0,0):117},'Exact independently decoded retirement routing across three primitives')
 require(all(m.views[1,0]['attributes'][a].tobytes()==m.views[1,1]['attributes'][a].tobytes()for a in ATTRS),'Actual shared head attribute source')
 source=json.loads(Path('/workspace/shared/horse-oral-channel-diagonal-candidate/source/frozen-head.json').read_text());corr=json.loads((P/'NATIVE-BIT-CORRESPONDENCE.json').read_text());skin=m.d['skins'][0];palette=[m.d['nodes'][i]['name']for i in skin['joints']];require(palette.count('head')==1,'Actual head joint identity')
 scopes={k:{g for g,o in owners.items()if o['kind']==v}for k,v in[('hybrid','hybrid_neck'),('mane','fitted_mane')]};require(len(scopes['hybrid'])==1492 and len(scopes['mane'])==456,'Unchanged complete hybrid/mane scopes')
 return dict(model=m,raw=raw,labels=labels,owners=owners,head=head,preserved=preserved,retired=retired,A=A,source=source,corr=corr,palette=palette,scopes=scopes)
def fields(ctx):
 """Future actual evaluation only: fixed original skin and one fixed portal plan."""
 m=ctx['model'];A=ctx['A'];outer=set(A['source_boundary']);bindings={};proof={};cache={};lookup=collections.defaultdict(list);retained_aliases=collections.defaultdict(list)
 for(mi,i),tag in ctx['labels'].items():lookup[tag].append((mi,i))
 for g in sorted(ctx['preserved']):
  desc=m.descriptor(g);mi=desc['mesh'];pi=desc['primitive']
  for i in desc['primitive_vertices']:retained_aliases[ctx['labels'][mi,i]].append((mi,pi,i,g))
 def raw_boundary(tag):
  require(tag in outer and retained_aliases[tag],'Actual retained71-boundary alias');rows=retained_aliases[tag];mi,pi,i,g=rows[0];a=m.views[mi,pi]['attributes'];rec=(a['POSITION'][i].astype(float),a['JOINTS_0'][i].tolist(),a['WEIGHTS_0'][i].tolist(),a['NORMAL'][i].astype(float))
  for mm,j in lookup[tag]:
   b=next(v for key,v in m.views.items()if key[0]==mm)['attributes']
   for k in['POSITION','JOINTS_0','WEIGHTS_0']:require(b[k][j].tobytes()==a[k][i].tobytes(),'All exact raw seam alias PJW:'+tag)
  bindings[tag]={'source_retained_face':g,'mesh':mi,'primitive':pi,'vertex':i,'actual_PJWN_sha256':{k:sha(a[k][i].tobytes())for k in ATTRS}}
  return rec
 head=ctx['palette'].index('head');J=[head,0,0,0];W=[1.,0.,0.,0.];line=[np.array(p,float)for p in[[-.105,-.20,.39],[0,-.205,.40],[.105,-.20,.39]]];sidefacts={r['side']:r for r in A['regions']};hit={side:h for side,h in zip(['l','r'],ctx['corr']['hits'])}
 def circle(side,j):
  r=sidefacts[side];f=r['existing_source_frame'];h=hit[side];seg=h['segment'];fraction=float(Q(h['segment_fraction_exact']));center=(1-fraction)*line[seg]+fraction*line[seg+1];axis=line[seg+1]-line[seg];axis/=np.linalg.norm(axis);z=np.array([0.,0.,1.]);u=z-z.dot(axis)*axis;u/=np.linalg.norm(u);v=np.cross(axis,u);theta=r['existing_source_angular_orientation']*2*math.pi*j/32;direction=math.cos(theta)*u+math.sin(theta)*v
  # Compare derived EXISTING correspondence/frame with frozen diagnostics;
  # this is identity validation, not a physical collision tolerance.
  require(np.max(abs(center-np.array(f['center_from_existing_centerline_and_facet'])))<1e-14 and np.max(abs(axis-np.array(f['axis'])))<1e-14,'Existing fixed source frame identity')
  return center+.008*direction,center,u,v,theta
 def lift(side,j,center,u,v,theta):
  r=sidefacts[side];loop=r['source_boundary'];direction=np.array([math.cos(theta),math.sin(theta)]);hits=[]
  def cross2(a,b):return a[0]*b[1]-a[1]*b[0]
  for ta,tb in zip(loop,loop[1:]+loop[:1]):
   a=np.array(ctx['source']['positions'][int(ta[2:])],float);b=np.array(ctx['source']['positions'][int(tb[2:])],float);aa=np.array([(a-center).dot(u),(a-center).dot(v)]);bb=np.array([(b-center).dot(u),(b-center).dot(v)]);edge=bb-aa;den=cross2(direction,edge)
   if den==0:continue
   distance=cross2(aa,edge)/den;fraction=cross2(aa,direction)/den
   if distance>0 and 0<=fraction<=1:hits.append((ta,tb,fraction,distance,(1-fraction)*a+fraction*b))
  require(len(hits)==1,'One source edge/ray ownership; no near matching or tie waiver');ta,tb,t,distance,point=hits[0];require(distance>.008,'Fixed8mm circle inside source domain at every declared phase');proof['labial:'+side+':ray:'+str(j)]={'source_edge':[ta,tb],'source_fraction':t,'existing_source_projected_distance_m':distance,'theta':theta,'recipe':'Exact prescribed angular ray/source edge algebra; no nearest/projection weld'};return point
 def resolve(tag):
  if tag in cache:return cache[tag]
  if tag in outer:rec=raw_boundary(tag)
  elif tag.startswith('labial-native:'):
   i=int(tag.split(':')[1]);require(0<=i<len(ctx['source']['positions']),'Native source range');rec=(np.array(ctx['source']['positions'][i])+ORIGIN,J,W,None);proof[tag]={'native_source_vertex':i,'recipe':'Pinned original native skin localP plus unchanged bind origin; head weight1'}
  elif tag.startswith('labial:vault-center:'):
   j=int(tag.split(':')[2]);require(0<=j<32,'Center ring32');theta=-2*math.pi*j/32;pos=line[1]+.008*np.array([0.,-math.sin(theta),math.cos(theta)]);rec=(pos+ORIGIN,J,W,None);proof[tag]={'recipe':'Existing centerline middle knot plus fixed8mm ring; axis+X,u+Z,v-XcrossZ=-Y','angle_index':j}
  elif tag.startswith('labial:'):
   _,side,row,jj=tag.split(':');j=int(jj);require(side in['l','r']and row in['blend1','blend2','portal']and 0<=j<32,'Declared local tissue ring');C,center,u,v,theta=circle(side,j)
   if row=='portal':pos=C
   else:
    O=lift(side,j,center,u,v,theta);t=1/3 if row=='blend1'else 2/3;pos=(1-t)*O+t*C
   rec=(pos+ORIGIN,J,W,None);proof[tag]={'recipe':'Fixed radial labial replacement','side':side,'row':row,'angle_index':j,'radius_m':.008,'blend_fraction':{'blend1':'1/3','blend2':'2/3','portal':'1'}[row]}
  else:raise ValueError('Foreign new labial alias:'+tag)
  require(np.isfinite(rec[0]).all()and abs(sum(rec[2])-1)<2e-6 and all(w>=0 for w in rec[2])and all(0<=v<len(ctx['palette'])for v in rec[1]),'Finite source P and normalized bounded actual rig weights');cache[tag]=rec;return rec
 return resolve,bindings,proof
def evaluate(ctx):
 m=ctx['model'];old=m.views[1,0]['attributes'];resolve,bindings,sourceproof=fields(ctx);arrays={k:old[k].copy().tolist()for k in ATTRS};copies={};newlabels={};newfaces=[];sums={};keeps={key:[i for i in range(len(v['indices']))if m.start[key]+i not in ctx['retired']]for key,v in m.views.items()}
 for ai,(t,o)in enumerate(zip(ctx['A']['proposed_patch_faces'],ctx['A']['proposed_patch_face_owners'])):
  material=1 if o['kind']=='inner_labial_vestibule'else 0;ids=[]
  for tag in t:
   key=material,tag
   if key not in copies:
    rec=resolve(tag);i=len(arrays['POSITION']);copies[key]=i;newlabels[str(i)]=tag;arrays['POSITION'].append(rec[0].tolist());arrays['JOINTS_0'].append(rec[1]);arrays['WEIGHTS_0'].append(rec[2]);arrays['NORMAL'].append([1.,0.,0.]);sums[i]=np.zeros(3)
   ids.append(copies[key])
  pos=np.asarray([arrays['POSITION'][i]for i in ids],dtype='<f4').astype(float);normal=np.cross(pos[1]-pos[0],pos[2]-pos[0]);require(np.isfinite(normal).all()and np.linalg.norm(normal)>2e-12,'Actual serialized triangle finite/nondegenerate')
  for i in ids:sums[i]+=normal
  newfaces.append({'assembly_face':ai,'material':material,'indices':ids,'source_labels':t,'source_owner':o})
 outer=set(ctx['A']['source_boundary'])
 for(mat,tag),i in copies.items():
  n=resolve(tag)[3]if tag in outer else sums[i];require(n is not None and np.isfinite(n).all()and np.linalg.norm(n)>1e-12,'Valid appended normal');arrays['NORMAL'][i]=(n if tag in outer else n/np.linalg.norm(n)).tolist()
 arrays={k:np.asarray(v,dtype=old[k].dtype)for k,v in arrays.items()};require(all(np.isfinite(v).all()for v in arrays.values())and np.all(abs(np.linalg.norm(arrays['NORMAL'].astype(float),axis=1)-1)<2e-5),'All finite attributes and unit normals')
 idx={}
 for key in[(1,0),(1,1)]:
  mat=1 if key==(1,0)else 0;addition=np.asarray([r['indices']for r in newfaces if r['material']==mat],dtype='<u4');idx[key]=np.vstack((m.views[key]['indices'][keeps[key]],addition))
 idx[0,0]=m.views[0,0]['indices'][keeps[0,0]].copy()
 detail={'retired_current_faces':sorted(ctx['retired']),'preserved_head2651':sorted(ctx['preserved']),'old_keep':{str(k[0])+':'+str(k[1]):v for k,v in keeps.items()},'new_labels':newlabels,'new_faces':newfaces,'source_bindings':bindings,'new_source_proof':sourceproof,'normal_authority':'Appended rows only; all71 source boundary copies retain actual retained source face normal; all old rows exact','status':'UNACCEPTED reconstructed neutral bitted labial patch; all actual guards/appearance pending'}
 return arrays,idx,detail
def serialize(ctx,arrays,idx):
 old=ctx['model'];d=copy.deepcopy(old.d);b=bytearray(old.b);refs={}
 for k in ATTRS:refs[k]=append(d,b,arrays[k],'VEC4'if k in['JOINTS_0','WEIGHTS_0']else'VEC3',comp=5123 if k=='JOINTS_0'else 5126)
 for key in[(1,0),(1,1)]:
  primitive=d['meshes'][key[0]]['primitives'][key[1]];primitive['attributes']=dict(refs);primitive['indices']=append(d,b,idx[key].reshape(-1),'SCALAR',comp=5125,target=34963)
 #117 source-owned halo faces are in the coat/body primitive. Only its index
 #stream is replaced: its original attribute accessors and all metadata stay exact.
 d['meshes'][0]['primitives'][0]['indices']=append(d,b,idx[0,0].reshape(-1),'SCALAR',comp=5125,target=34963)
 return encode(d,b)
def authority(ctx):return{'parent_sha256':PARENT,'retirement2313':sorted(ctx['retired']),'preserved2651':sorted(ctx['preserved']),'outer71':ctx['A']['source_boundary'],'topology':ctx['A']['derived_proposed_topology'],'geometry':'Pinned native closed skin plus fixed rounded bit-corner annuli and real inner labial vestibule; neutral bitted rest approximation','guard':'All original8 scopes/all36gear/fullbit/oldnegative unchanged; no numeric predicate waiver','status':'Natural/photo/motion/pressure/unbitted/jaw-opening acceptance remains OPEN'}
def audit(raw,ctx,proof):
 old=ctx['model'];require(proof.get('candidate_sha256')==sha(raw),'Actual candidate identity');a,idx,detail=evaluate(ctx);require(proof['detail']==detail and proof['authority']==authority(ctx),'Exact fixed source/ownership proof');require(raw==serialize(ctx,a,idx),'Full actual serialized intended recipe equality');new=Model(raw);require(set(new.views)==set(old.views)and new.total==13456,'Same primitive/material ownership and exact total')
 for key,v in old.views.items():
  w=new.views[key];require(w['material']==v['material'],'Material role exact')
  if key not in[(1,0),(1,1),(0,0)]:require(w['indices'].tobytes()==v['indices'].tobytes(),'All unaffected primitive indices exact')
  for k in ATTRS:require(w['attributes'][k][:len(v['attributes'][k])].tobytes()==v['attributes'][k].tobytes(),'EVERY original attribute row exact')
 require(new.b[:len(old.b)]==old.b,'Original BIN prefix exact');require(new.d['accessors'][:len(old.d['accessors'])]==old.d['accessors']and new.d['bufferViews'][:len(old.d['bufferViews'])]==old.d['bufferViews'],'All old accessor/view prefix metadata exact');require(len(new.d['accessors'])==len(old.d['accessors'])+7 and len(new.d['bufferViews'])==len(old.d['bufferViews'])+7,'Exactly4 head attributes+3 affected indices append')
 docs=[copy.deepcopy(x.d)for x in[old,new]]
 for d in docs:
  d.pop('accessors');d.pop('bufferViews');d['buffers'][0].pop('byteLength')
  for mi,pi in[(1,0),(1,1)]:d['meshes'][mi]['primitives'][pi].pop('attributes');d['meshes'][mi]['primitives'][pi].pop('indices')
  d['meshes'][0]['primitives'][0].pop('indices')
 require(docs[0]==docs[1],'All other document fields/unknownextras/rig/nodes/actions/materials exact');remap={};owners={};head=set();scopes={k:set()for k in ctx['scopes']};scopes['lips']=set();labels={}
 for key,v in old.views.items():
  for ni,oi in enumerate(detail['old_keep'][str(key[0])+':'+str(key[1])]):
   og=old.start[key]+oi;ng=new.start[key]+ni;require(og not in ctx['retired'],'Retired face absent');require(v['indices'][oi].tobytes()==new.views[key]['indices'][ni].tobytes(),'Every retained oriented active triangle index exact');remap[og]=ng;owners[ng]=ctx['owners'][og]
   if og in ctx['preserved']:head.add(ng)
   for name,cohort in ctx['scopes'].items():
    if og in cohort:scopes[name].add(ng)
 require(set(remap)==set(range(old.total))-ctx['retired'],'Complete exact old retirement/preservation ledger')
 for key,v in new.views.items():
  for i in set(map(int,v['indices'].ravel())):
   tag=detail['new_labels'].get(str(i))if key[0]==1 else None;labels[key[0],i]=tag or ctx['labels'].get((key[0],i),'body:'+str(key[0])+':'+str(i))
 cursors={1:len(detail['old_keep']['1:0']),0:len(detail['old_keep']['1:1'])}
 for row in detail['new_faces']:
  mat=row['material'];key=(1,0)if mat==1 else(1,1);ng=new.start[key]+cursors[mat];cursors[mat]+=1;require(new.views[key]['indices'][ng-new.start[key]].tolist()==row['indices'],'Actual new face ownership exact');owners[ng]={'kind':'natural_labial','assembly_face':row['assembly_face'],'source_owner':row['source_owner']};head.add(ng);scopes['lips'].add(ng)
 require(set(owners)==set(range(new.total))and len(head)==3352 and len(scopes['lips'])==701 and len(scopes['hybrid'])==1492 and len(scopes['mane'])==456,'All active owners and complete source cohorts');new.source_face_owners=owners
 def tags(g):
  desc=new.descriptor(g);return[labels[desc['mesh'],i]for i in desc['primitive_vertices']]
 loop=ctx['A']['source_boundary'];boundary={tuple(sorted(e))for e in zip(loop,loop[1:]+loop[:1])};require(manifold([tags(g)for g in sorted(scopes['lips'])],boundary,-1)==ctx['A']['derived_proposed_topology'],'Actual decoded complete mouth vertex links/edges/counts')
 full=json.loads((P/'FULL-HEAD-SYMBOLIC-PROOF.json').read_text());loop=full['neck_boundary'];boundary={tuple(sorted(e))for e in zip(loop,loop[1:]+loop[:1])};require(manifold([tags(g)for g in sorted(head)],boundary,-1)==full['topology'],'Actual decoded complete head vertex links/edges/counts')
 report={'PASS':True,'candidate_sha256':sha(raw),'old_to_new':{str(k):v for k,v in sorted(remap.items())},'source_face_owners':{str(k):v for k,v in sorted(owners.items())},'source_labels':[{'mesh':mi,'vertex':i,'label':v}for(mi,i),v in sorted(labels.items())],'head_faces':len(head),'newlip_faces':len(scopes['lips']),'source_scope':'Decoded intended full source/P/N/J/W/indices/storage/rig preservation; no actual embedding/gear/bit/appearance acceptance'}
 return new,labels,head,owners,scopes,report
def produce(path):
 out=Path(path);out.mkdir(parents=True,exist_ok=False);stage='load';receipt={'PASS':False,'stage':stage,'status':'ONE unaccepted natural labial trial'}
 try:
  ctx=load();stage='evaluate';a,idx,detail=evaluate(ctx);stage='serialize';raw=serialize(ctx,a,idx);(out/'UNVALIDATED-candidate.glb').write_bytes(raw);proof={'candidate_sha256':sha(raw),'authority':authority(ctx),'detail':detail};stage='source_readback';*_,rb=audit(raw,ctx,proof);(out/'candidate.glb').write_bytes(raw);(out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');(out/'readback.json').write_text(json.dumps(rb,indent=2)+'\n');receipt.update(PASS=True,stage='source_readback_complete',candidate_sha256=sha(raw))
 except BaseException as exc:receipt.update(stage=stage,error=repr(exc));raise
 finally:(out/'FIRST-TRIAL-SOURCE.json').write_text(json.dumps(receipt,indent=2)+'\n')
 return receipt
if __name__=='__main__':print(json.dumps(produce(sys.argv[1])))
