# SPDX-License-Identifier: GPL-3.0-or-later
"""Actual saved negative fixtures only; no proposed model/geometry evaluated."""
from pathlib import Path
import json,importlib.util
import numpy as np
P=Path(__file__).parent
spec=importlib.util.spec_from_file_location('unchanged_head_predicates','/workspace/shared/horse-neck-hybrid-pipeline-next/official_fit_predicates.py');predicates=importlib.util.module_from_spec(spec);spec.loader.exec_module(predicates)
def once():
 fixtures=json.loads((P/'prior-failure-fixtures.json').read_text());rows=[]
 for name,w in fixtures['fixtures'].items():
  a,b=map(lambda x:np.asarray(x,dtype=float),w['actual_triangles_world']);sat=predicates.sat(a,b);proper=predicates.proper(a,b)
  if not sat or proper is None:raise ValueError('Saved negative must remain strict proper:'+name)
  rows.append({'name':name,'raw_SAT':True,'strict_proper':True,'old_global_pair':[w['a_global'],w['b_global']]})
 if len(rows)!=5:raise ValueError('Five distinct saved failure families required')
 with(P/'prior-failure-controls-result.json').open('x')as f:f.write(json.dumps({'PASS':True,'scope':'Preserved failed ae1e witness negatives only; proposed candidate not evaluated','rows':rows},indent=2)+'\n')
if __name__=='__main__':once()
