# SPDX-License-Identifier: CC0-1.0
"""Exactly one root-released180s fixed trial; no retries/search/browser/app."""
import time
START=time.monotonic()
from pathlib import Path
import os,sys,json,hashlib,subprocess,signal
P=Path(__file__).parent
def interrupted(signum,frame):
 raise KeyboardInterrupt('Operator signal '+str(signum))
def require(value,message):
 if not value:raise ValueError(message)
def pins():
 result={}
 for name in['LOCAL-PINS.json','EXTERNAL-HASHES.json']:
  raw=(P/name).read_bytes();values=json.loads(raw);result[name]={'manifest_sha256':hashlib.sha256(raw).hexdigest(),'entries':values}
  for key,expected in values.items():
   path=P/key if name=='LOCAL-PINS.json'else Path(key);require(hashlib.sha256(path.read_bytes()).hexdigest()==expected,'Source/input pin:'+key);require(time.monotonic()-START<180,'180s total pin deadline')
 return result
def main():
 require(sys.argv[1:]==['ROOT_RELEASE_ONE_NATURAL_LABIAL_CORNER'],'Independent frozen full source PASS and root release required')
 signal.signal(signal.SIGTERM,interrupted)
 with(P/'operator-receipt.json').open('x')as f:f.write('{}\n')
 r={'PASS':False,'bound_s':180,'phase':'preflight','stages':[],'status':'UNACCEPTED neutral bitted natural-labial trial','no_browser_motion_app':True}
 def save():r['elapsed_s']=time.monotonic()-START;(P/'operator-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
 try:
  r['cpu_affinity']=sorted(os.sched_getaffinity(0));r['math_threads']={k:os.environ.get(k)for k in['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']};require(r['cpu_affinity']==[0]and all(v=='1'for v in r['math_threads'].values()),'Exactly CPU0 and all math threads1');require(all(not(P/x).exists()for x in['candidate-one','lip-readback-result.json','khronos.json','idle-fit/capture','idle-fit/results','idle-fit/structural-results','idle-fit/actual-bit-volume-result.json']),'Exclusive fresh actual outputs');r['before_pins']=pins();save()
  stages=[('prior_failure_controls',[sys.executable,str(P/'check_prior_failures.py')],5),('generate',[sys.executable,str(P/'conforming_variant.py'),str(P/'candidate-one')],30),('source_readback',[sys.executable,str(P/'checked_conforming.py')],30),('Khronos',['node',str(P/'khronos.cjs')],15),('actual_binary64_idle_capture',['node','--loader',str(P/'idle-fit/three-loader.mjs'),str(P/'idle-fit/capture_idle.mjs')],20),('full_structural',[sys.executable,str(P/'check_lip_idle.py')],110),('all36gear',[sys.executable,str(P/'idle-fit/check_idle.py')],90),('actual_bit_volume',[sys.executable,str(P/'check_actual_bit_volume.py')],30)]
  for name,cmd,cap in stages:
   remaining=min(cap,180-(time.monotonic()-START));require(remaining>0,'180s total deadline');r['phase']=name;save()
   with(P/(name+'.stdout')).open('xb')as out,(P/(name+'.stderr')).open('xb')as err:
    child=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True)
    try:code=child.wait(timeout=remaining)
    except BaseException as exc:
     try:os.killpg(child.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     child.wait()
     if isinstance(exc,subprocess.TimeoutExpired):code=124
     else:raise
   r['stages'].append({'name':name,'exit':code,'elapsed_s':time.monotonic()-START});save();require(code==0,'FIRSTFAIL '+name+' exit'+str(code))
  r['phase']='post_identity';r['after_pins']=pins();require(r['after_pins']==r['before_pins'],'Exact same before/after manifest bytes and pins');r.update(PASS=True,status='ONE bounded idle engineering trial ONLY; natural/photo/motion OPEN')
 except BaseException as exc:r['error']=repr(exc)
 finally:save()
 return 0 if r['PASS']else 2
if __name__=='__main__':raise SystemExit(main())
