# SPDX-License-Identifier: CC0-1.0
"""Original bounded sculpt fields. Dimensions are reconstruction, not plate measurements."""
import math

def bump(x,a,b):
 if not math.isfinite(x)or not a<b:raise ValueError('Finiteorderedfielddomain')
 if x<=a or x>=b:return 0.
 u=(x-a)/(b-a);return 64*u**3*(1-u)**3

def boundary_fade(distance):
 if distance<0:raise ValueError('Negativegraphdistance')
 u=min(1.,distance/3);return u**3*(10+u*(-15+6*u))

def displacement(position,label,fade,eligible=True):
 if not eligible or fade==0:return[0.,0.,0.]
 x,y,z=position;x=float(x);y=float(y)-1.88;z=float(z)-.8
 # A coherent rest-space lower-cheek field also reaches the matching throat seam.
 longitudinal=bump(z,.04,.26);dx=.012*x/math.sqrt(x*x+.0025**2)*bump(y,-.22,-.015)*longitudinal;dy=-.015*bump(y,-.32,0.)*longitudinal;dz=0.
 if label.startswith('hybrid:'):
  from fractions import Fraction as F
  parts=label.split(':');j,k=int(parts[1]),int(parts[2]);phases=sorted({F(i,24)for i in range(24)}|{F(i,28)for i in range(28)})
  if not(0<=j<15 and 0<=k<48):raise ValueError('Explicitnecksourceparameter')
  t=(j+1)/16;s=float(phases[k]);dz=-.020*bump(t,.20,1.)*max(0.,-math.sin(2*math.pi*s))**4
 return[fade*dx,fade*dy,fade*dz]

def recipe():return{'status':'UNACCEPTED bounded original cheek/throat sculpt','origin_head_rest_m':[0,1.88,.8],'cheek_support_local_z_m':[.04,.26],'cheek_lateral_support_y_m':[-.22,-.015],'cheek_ventral_support_y_m':[-.32,0.],'lateral_component_bound_m':.012,'ventral_component_bound_m':.015,'neck_posterior_component_bound_m':.020,'combined_vector_bound_m':math.sqrt(.012**2+.015**2+.020**2),'neck_support_source_t':[.20,1.],'source_boundary_fade':'three coat-source edges, quintic C2 at endpoints','new_topology':False,'eye_orbit_topology':'not modified in this first trial','primary_reference':'Cuyer1905 Fig92/70 qualitative exposed anatomy; all dimensions reconstructed','not_proven':['anatomicalshape','actualself/gearfit','poseddeformation','photographicquality']}
