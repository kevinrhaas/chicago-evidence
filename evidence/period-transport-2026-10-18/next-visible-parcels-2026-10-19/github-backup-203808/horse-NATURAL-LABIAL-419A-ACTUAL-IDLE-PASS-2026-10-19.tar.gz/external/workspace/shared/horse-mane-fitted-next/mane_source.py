# SPDX-License-Identifier: CC0-1.0
"""Original fitted-crest source. No model execution at import."""
from pathlib import Path
import sys,hashlib,json
import numpy as np
HYBRID=Path('/workspace/shared/horse-neck-hybrid-pipeline-next');sys.path.insert(0,str(HYBRID))
from hybrid_chain import load_chain
from sparse_rules import require
PARENT_PACKET=Path('/workspace/shared/horse-neck-hybrid-first-local-trial/payload/packet.json')
PACKET_SHA='cb6987a5403bf4b83f9c644203936bf181d1b4a38c24e0e76246d2d51f3d41aa'
PARENT_SHA='192204d95776c5cf675f1269f937d0b9bed89eca9df04e9db9f181384e0a4ec8'
def parent_context():
 v=load_chain(PARENT_PACKET,PACKET_SHA,Path('/workspace/shared/horse-head-groove-coat-next/trial1'),Path('/workspace/shared/horse-ear-root-exporter-source-reviewed-next/export-trial1'),Path('/workspace/shared/horse-ear-root-exporter-source-reviewed-next/source-trial1/candidate-source-edit.json'))
 require(v['neck_sha256']==PARENT_SHA,'Exactfailed192parent')
 from ownership import PINS
 raw=Path('/workspace/shared/horse-head-groove-coat-next/trial1/manifest.json').read_bytes();require(hashlib.sha256(raw).hexdigest()==PINS['producer090'],'Originalrangeauthoritypin');ranges=json.loads(raw)['vertex_ranges'];material=[r for r in ranges if r['material']==1];require([(r['original_node'],r['vertex_start'],r['vertex_count'])for r in material]==[('mane',0,122),('tail',122,122),('head_material_equine_mane_tail',244,116)],'Exactmane/tail/darkfeaturecomponentranges');return v

def recipe():return {'status':'UNACCEPTED original reconstructed fitted mane','old_mane_vertices':list(range(122)),'retired_mane_faces':240,'new_vertices':230,'new_faces':456,'sections':19,'radial_samples':12,'root_gap_m':.001,'crest_height_m':.025,'crest_halfwidth_m':.006,'terminal_height_m':.002,'terminal_halfwidth_m':.0015,'root_source_keys':['body:0:126','body:0:150','body:0:174']+[f'hybrid:{j}:12'for j in range(15)]+['h:6'],'raw_root_J_W_copied':True,'all_old_attribute_bytes_exact':True,'not_proven':['self/wholehorsefit','63poses','groom/anatomy/photo','physicalrootcontact']}

def roots(context):
 m,labels,head,owners=context['neck_candidate'];proof=context['proof'];p=m.views[0,0]['attributes']['POSITION'];base=proof['parent_coat_vertex_count'];lookup={k:base+i for i,k in enumerate(proof['index_proof']['new_vertex_keys'])};ids=[126,150,174]+[lookup[f'hybrid:{j}:12']for j in range(15)]+[proof['actual_head_source_mapping']['6']]
 require(len(set(ids))==19,'Distinctexplicitroots');idx=m.views[0,0]['indices'];tri=p[idx].astype(float);area=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);rows=[]
 for key,i in zip(recipe()['root_source_keys'],ids):
  incident=np.flatnonzero(np.any(idx==i,axis=1));require(len(incident)>=3,'Source root active incidentfaces');normal=area[incident].sum(0);length=np.linalg.norm(normal);require(np.isfinite(length)and length>1e-12,'Rootnormalfinite');normal/=length;require(np.dot(normal,[0,1,-1])>0,'Actualorientedcrest normal');tangent=np.array([1.,0,0])-normal*normal[0];tangent/=np.linalg.norm(tangent)
  a=m.views[0,0]['attributes'];rows.append({'source_key':key,'actual_coat_vertex':i,'incident_active_coat_faces':incident.tolist(),'position':p[i].tolist(),'normal':normal.tolist(),'lateral_tangent':tangent.tolist(),'J':a['JOINTS_0'][i].tolist(),'W':a['WEIGHTS_0'][i].tolist()})
 # Every consecutive root is an actual retained coat edge, not a chord through an unsampled surface.
 edges={}
 for fi,f in enumerate(idx):
  for a,b in zip(f,list(f[1:])+[f[0]]):edges.setdefault(tuple(sorted([int(a),int(b)])),[]).append(fi)
 for row,a,b in zip(rows,ids,ids[1:]):
  owners=edges.get(tuple(sorted([a,b])),[]);require(len(owners)==2,'Consecutiverootedge exactlytwoactivecoatowners');row['next_root_edge']={'vertices':[a,b],'actual_incident_coat_faces':owners}
 return rows

def shape(rows):
 import math
 require(len(rows)==19,'19sections');p=[];j=[];w=[];faces=[]
 for k,row in enumerate(rows):
  taper=min(1.,k/2,(18-k)/2);height=.002+(.025-.002)*taper;width=.0015+(.006-.0015)*taper;c=np.array(row['position'],float);n=np.array(row['normal']);x=np.array(row['lateral_tangent'])
  for q in range(12):
   theta=2*math.pi*q/12;p.append((c+n*(.001+height/2+height/2*math.sin(theta))+x*(width*math.cos(theta))).tolist());j.append(row['J']);w.append(row['W'])
 for k in range(18):
  for q in range(12):a=k*12+q;b=k*12+(q+1)%12;faces.extend([(a,b,b+12),(a,b+12,a+12)])
 for k in[0,18]:
  row=rows[k];height=.002;p.append((np.array(row['position'])+np.array(row['normal'])*(.001+height/2)).tolist());j.append(row['J']);w.append(row['W']);center=228+(k==18)
  for q in range(12):faces.append((center,(q+1)%12,q)if k==0 else(center,k*12+q,k*12+(q+1)%12))
 p=np.array(p,dtype='<f4');f=np.array(faces,dtype='<u4');volume=sum(np.dot(p[a].astype(float),np.cross(p[b].astype(float),p[c].astype(float)))for a,b,c in f)/6
 require(abs(volume)>1e-12,'Nonzeroorientedhairvolume')
 if volume<0:f=f[:,[0,2,1]]
 return p,np.array(j,dtype='<u2'),np.array(w,dtype='<f4'),f
