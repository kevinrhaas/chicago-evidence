# SPDX-License-Identifier: CC0-1.0
import unittest
from fractions import Fraction as F
from collections import defaultdict
import numpy as np
from hybrid_geometry import evaluate,recipe,SEAM
from hybrid_reference import reference

class SyntheticHybrid(unittest.TestCase):
 def fixture(self):
  # Original arbitrary synthetic inputs, NOT actual horse geometry.
  A=[[float(k),0.,0.]for k in range(24)];B=[[float(k),1.,0.]for k in range(24)]
  HP={k:[float(k),2.,float(k%7)]for k in range(120)};HW={k:[0.,1.]for k in range(120)}
  return A,B,HP,HW
 def test_independent_rational_math(self):
  args=self.fixture();got=evaluate(*args);p,w=reference(*args,recipe());self.assertTrue(np.array_equal(np.array(got['positions'],dtype='<f4'),p));self.assertTrue(np.array_equal(np.array(got['weights'],dtype='<f4'),w))
 def check_chart(self,faces):
  uses=defaultdict(list);verts=set()
  for f in faces:
   self.assertEqual(len(set(f)),3);verts.update(f)
   for a,b in zip(f,f[1:]+f[:1]):uses[tuple(sorted([a,b]))].append((a,b))
  loops=[['B:'+str(i)for i in range(168,192)],['h:'+str(h)for h in SEAM]];boundary={tuple(sorted([r[i],r[(i+1)%len(r)]]))for r in loops for i in range(len(r))}
  self.assertEqual({e for e,u in uses.items()if len(u)==1},boundary);self.assertEqual(len(verts)-len(uses)+len(faces),0);self.assertEqual(len(verts),772)
  for u in uses.values():self.assertTrue(len(u)==1 or(len(u)==2 and u[0]==u[1][::-1]))
 def test_actual_declared_chart(self):
  f=evaluate(*self.fixture())['faces'];self.assertEqual(len(f),1492);self.check_chart(f)
 def test_missing_face_refused(self):
  f=evaluate(*self.fixture())['faces']
  with self.assertRaises(AssertionError):self.check_chart(f[:-1])
 def test_winding_refused(self):
  f=evaluate(*self.fixture())['faces'];f[72]=tuple(reversed(f[72]))
  with self.assertRaises(AssertionError):self.check_chart(f)
 def test_bad_endpoint_weights_refused(self):
  a,b,p,w=self.fixture();w[25]=[1.,0.]
  with self.assertRaises(ValueError):evaluate(a,b,p,w)
if __name__=='__main__':unittest.main()
