# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only exact frozen oral delta and 1eee source-cohort compatibility."""
from pathlib import Path
import sys,json,hashlib,collections
import numpy as np
P=Path(__file__).parent
sys.path.insert(0,'/workspace/shared/horse-mane-fitted-next')
from mane_chain import load
from ownership import Model,ATTRS
from sparse_rules import require
BASE=Path('/workspace/shared/horse-head-groove-coat-next/trial1/equine_light_harness_skinned_prototype_01.glb')
ORAL=Path('/workspace/shared/horse-oral-channel-diagonal-candidate/candidate-one/equine_light_harness_skinned_prototype_01.glb')
PARENT=Path('/workspace/shared/horse-mane-fitted-first-local-trial/payload/candidate.glb')
PINS=['090be8fdc2516ee5b5c8f886026f441850cc208f17b6ede71fed9007ab80f12f','21cadaa8dc46428a5b6b119b790e03e4a2fdc8da7cb0caacc7c45482ed40ec09','1eee14e7d80ef8dcbe7e9d2ab3250cc7ea711a74f4cda730dd4b2af954cfcd89']
def sha(raw):return hashlib.sha256(raw).hexdigest()
def tri_key(m,key,i):
 v=m.views[key];pieces=[b''.join(v['attributes'][a][int(j)].tobytes()for a in ATTRS)for j in v['indices'][i]]
 return(key[0],v['material'],min(b''.join(pieces[k:]+pieces[:k])for k in range(3)))
def counter(m):return collections.Counter(tri_key(m,k,i)for k,v in m.views.items()for i in range(len(v['indices'])))
def context():
 raw=[x.read_bytes()for x in[BASE,ORAL,PARENT]];require([sha(x)for x in raw]==PINS,'allthreeactualGLBpins')
 base,oral,parent=[Model(x)for x in raw];ctx=load('/workspace/shared/horse-mane-fitted-first-local-trial/payload/packet.json','5f716ee2583aad96c2e0c8c1107e91f9d4d511f717683b8274eab04d1c1dd23a');m,labels,head,owners=ctx['neck_candidate'];require(counter(parent)==counter(m),'chainmodelactualsame')
 for x in[base,oral]:
  require(x.d['nodes']==parent.d['nodes'] and x.d['materials']==parent.d['materials']and x.d['scenes']==parent.d['scenes'],'exactnodehierarchynamesmaterialsansnewauthority')
 bc,oc,pc=[counter(x)for x in[base,oral,parent]];removed=bc-oc;added=oc-bc;require(sum(removed.values())==261 and sum(added.values())==471,'exact observed attribute delta261/471');require(not(removed-pc),'everyretiredoraltrianglepresentin1eee')
 hits=[];addedfaces=[];removedcount=collections.Counter()
 for key,v in parent.views.items():
  for i in range(len(v['indices'])):
   q=tri_key(parent,key,i)
   if q in removed:
    require(pc[q]==removed[q]==1,'uniqueretiredexacttriangle');g=parent.global_face(key,i);o=owners.get(g);require(g in head and o and o['kind']=='baseline_head','mouthnormalhaloonlyoriginalretainedhead');hits.append({'mesh':key[0],'primitive':key[1],'triangle':i,'global':g,'owner':o});removedcount[q]+=1
 require(removedcount==removed,'completedeltaretirement')
 for key,v in oral.views.items():
  for i in range(len(v['indices'])):
   q=tri_key(oral,key,i)
   if q in added:require(oc[q]==added[q]==1,'uniqueaddedtriangle');addedfaces.append({'mesh':key[0],'primitive':key[1],'triangle':i,'global':oral.global_face(key,i)})
 require(len(addedfaces)==471,'completeoraladdition')
 return base,oral,parent,ctx,hits,addedfaces
if __name__=='__main__':
 base,oral,parent,ctx,hits,added=context();retiredsource={x['owner']['source_head_face']for x in hits};oralhead=json.loads(Path('/workspace/shared/horse-oral-channel-diagonal-candidate/candidate-one/head-source-surface.json').read_text());actualretired=set(oralhead['oral_authority']['retired_source_faces']);require(actualretired<=retiredsource,'all124sourcecutcontained')
 r={'PASS':True,'scope':'Read-only source provenance/cohort graft compatibility; no new geometry emitted or fit accepted','input_sha256':PINS,'retired_1eee_actual_faces':hits,'addition_oral_actual_faces':added,'removed_count':len(hits),'added_count':len(added),'source_retired124':sorted(actualretired),'normalchanged_retained137':sorted(retiredsource-actualretired),'all_modified_1eee_owners':'baseline_head only; no ear/neckpatch/mane/tail retirement','old_triangle_total':parent.total,'proposed_total':parent.total-261+471}
 (P/'GRAFT-SOURCE-MAP.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if not isinstance(v,list)}))
