# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import json,hashlib
from lip_variant import context,audit
from sparse_rules import require
P=Path(__file__).parent
def checked():
 c=context();raw=(P/'candidate-one/candidate.glb').read_bytes();proof=json.loads((P/'candidate-one/proof.json').read_text());require(hashlib.sha256(raw).hexdigest()==proof['candidate_sha256'],'Exactneutralcandidate');m,l,h,o,s,report=audit(raw,c,proof);m.source_face_owners=o;return m,l,h,o,s,raw
if __name__=='__main__':
 m,l,h,o,s,r=checked();report={'PASS':True,'candidate_sha256':hashlib.sha256(r).hexdigest(),'status':'SOURCE/REST ONLY; actualXYZ/gear/bit/visual/motion UNTESTED','total_faces':m.total,'head_faces':len(h),'newlip_faces':len(s['lips'])}
 with(P/'lip-readback-result.json').open('x')as f:f.write(json.dumps(report,indent=2)+'\n')
