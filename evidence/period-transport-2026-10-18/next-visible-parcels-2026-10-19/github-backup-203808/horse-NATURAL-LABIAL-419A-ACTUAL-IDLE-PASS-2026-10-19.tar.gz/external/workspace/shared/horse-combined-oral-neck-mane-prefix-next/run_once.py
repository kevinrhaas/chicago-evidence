# SPDX-License-Identifier: GPL-3.0-or-later
"""ONE reviewed combined generation then ONE idle0 capture, first refusal STOP."""
from pathlib import Path
import json,hashlib,subprocess,sys,time,os,signal
P=Path(__file__).parent;started=time.monotonic();result={'PASS':False,'scope':'ONE combined original candidate/ONE actualidle0; no63pose/photo acceptance','stages':[],'total_bound_s':150}
def save():result['elapsed_s']=time.monotonic()-started;(P/'operator-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
# Acquire evidence ownership BEFORE the exception/finally handler. A refusal must
# never overwrite an earlier trial receipt.
with(P/'operator-receipt.json').open('x')as receipt:receipt.write(json.dumps(result,indent=2)+'\n')
try:
 for name,want in json.loads((P/'SOURCE-HASHES.json').read_text()).items():
  if hashlib.sha256((P/name).read_bytes()).hexdigest()!=want:raise ValueError('local sourcepin '+name)
 for name,want in json.loads((P/'EXTERNAL-HASHES.json').read_text()).items():
  if hashlib.sha256(Path(name).read_bytes()).hexdigest()!=want:raise ValueError('external source/inputpin '+name)
 save()
 commands=[('generate',[sys.executable,str(P/'graft.py')],30),('independent_decoded_readback',[sys.executable,str(P/'check_graft.py')],30),('actual_idle0_CPU_capture',['node','--loader',str(P/'idle-fit/three-loader.mjs'),str(P/'idle-fit/capture_idle.mjs')],20),('all_structural_scopes',[sys.executable,str(P/'check_combined_idle.py')],75),('all36gear_ALLhorse',[sys.executable,str(P/'idle-fit/check_idle.py')],90),('actual_bit_volume',[sys.executable,str(P/'check_actual_bit_volume.py')],30)]
 for name,cmd,cap in commands:
  budget=min(cap,150-(time.monotonic()-started))
  if budget<=0:raise TimeoutError('total150s bound')
  before=time.monotonic()
  with(P/(name+'.stdout')).open('xb')as out,(P/(name+'.stderr')).open('xb')as err:
   child=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True)
   try:code=child.wait(timeout=budget)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait();code=124
  result['stages'].append({'name':name,'exit':code,'elapsed_s':time.monotonic()-before});save()
  if code:raise RuntimeError('firstfailure '+name+' exit '+str(code))
 result['PASS']=True
except BaseException as e:result['error']=repr(e)
finally:save()
print(json.dumps(result));sys.exit(0 if result['PASS']else 2)
