# SPDX-License-Identifier: GPL-3.0-or-later
"""Independent decoded REST/index audit; does NOT call exporter/generator."""
import copy,hashlib
import numpy as np
from ownership import Model
from sparse_rules import require
from local_patch import recipe,validate_recipe,cycle

def audit_rest(parent_bytes,new_bytes,proof):
 old=Model(parent_bytes);new=Model(new_bytes);r=recipe();validate_recipe(r)
 require(old.total==new.total==11452 and set(old.views)==set(new.views),'Exact active shape')
 require(proof['retired_source_faces']==list(range(414,426)),'Sourceface retirement authority')
 require([list(f)for f in proof['appended_new_faces']]==[list(f)for f in r['new_faces']],'Appendface proofauthority')
 oldcoat=old.views[0,0]['indices'];newcoat=new.views[0,0]['indices'];retired=proof['retired_old_active_faces'];require(len(retired)==len(set(retired))==12,'Exact12unique retirement')
 require(set(cycle(oldcoat[i].tolist())for i in retired)==set(cycle(f)for f in r['old_faces']),'Retired source owner mismatch')
 keep=[i for i in range(len(oldcoat))if i not in set(retired)];require(np.array_equal(newcoat[:len(keep)],oldcoat[keep]),'Every retained triangle must be exact and ordered')
 require(np.array_equal(newcoat[len(keep):],np.array(r['new_faces'],dtype=newcoat.dtype)),'Exact12explicit appended triangle contract')
 require(proof['unchanged_old_to_new']==[{'old':i,'new':j}for j,i in enumerate(keep)],'Remap proof mismatch')
 for key,v in old.views.items():
  w=new.views[key];require(v['material']==w['material']and v['mesh_name']==w['mesh_name'],'Primitive identity')
  if key!=(0,0):require(np.array_equal(v['indices'],w['indices']),'Unrelated indices changed')
  require(v['attributes_accessors']==w['attributes_accessors'],'ANY attribute accessor ref changed')
  for k,a in v['attributes'].items():require(a.dtype==w['attributes'][k].dtype and a.shape==w['attributes'][k].shape and a.tobytes()==w['attributes'][k].tobytes(),'Attribute byte mutation:'+k)
 a,b=old.d,new.d;na,nv=len(a['accessors']),len(a['bufferViews']);ref=b['meshes'][0]['primitives'][0]['indices']
 require(len(b['accessors'])==na+1 and len(b['bufferViews'])==nv+1 and ref==na,'Exactly1appended index accessor/view/ref')
 require(b['accessors'][:na]==a['accessors']and b['bufferViews'][:nv]==a['bufferViews'],'Old storage metadata changed');require(bytes(new.b[:len(old.b)])==bytes(old.b),'Old BINprefix changed')
 av=b['accessors'][-1];view=b['bufferViews'][-1];require(av['bufferView']==nv and av['componentType']==5125 and av['type']=='SCALAR'and av['count']==newcoat.size,'Appended index type/count');require(view['buffer']==0 and view['target']==34963 and view['byteOffset']>=len(old.b)and view['byteLength']==newcoat.size*4,'Appended index view')
 require(set(av)=={'bufferView','componentType','count','type','min','max'}and av['min']==[int(newcoat.min())]and av['max']==[int(newcoat.max())],'Exact appended index metadata')
 require(set(view)=={'buffer','byteOffset','byteLength','target'}and view['byteOffset']%4==0,'Exact appended view metadata')
 require(view['byteOffset']+view['byteLength']==b['buffers'][0]['byteLength']==len(new.b),'Exact appendextent')
 x,y=copy.deepcopy(a),copy.deepcopy(b)
 for doc in[x,y]:
  doc['meshes'][0]['primitives'][0].pop('indices')
  for k in['accessors','bufferViews']:doc.pop(k)
  doc['buffers'][0].pop('byteLength')
 require(x==y,'Protected rig/IBMs/clips/materials/document changed')
 return{'status':'REST/INDEX only; no collisionacceptance','all_attributes_byte_exact':True,'all_unaffected_indices_exact':True,'retired12_new12_verified':True,'protected_document_BINprefix_exact':True,'output_sha256':hashlib.sha256(new_bytes).hexdigest()}
