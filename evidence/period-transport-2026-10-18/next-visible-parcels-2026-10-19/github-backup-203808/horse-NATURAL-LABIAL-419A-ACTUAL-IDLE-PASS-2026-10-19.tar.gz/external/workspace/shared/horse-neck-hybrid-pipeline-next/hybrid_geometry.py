# SPDX-License-Identifier: CC0-1.0
"""Original hybridthroatlatch proposal. No IO, no automatic actual invocation."""
from fractions import Fraction as F
from sparse_rules import require
TIMES=tuple(F(i,16)for i in range(1,16))
SEAM=tuple([24]+list(range(13))+[36]+list(range(60,72))+[48])
PHASES=tuple(sorted({F(i,24)for i in range(24)}|{F(i,28)for i in range(28)}))
HEAD_RETIRE=tuple(list(range(24,48))+list(range(72,96)))
def recipe():
 return{'status':'UNACCEPTED newhybridactiveconnectivity authority','neck_retired_source_faces':list(range(336,432)),'head_retired_source_faces':list(HEAD_RETIRE),'seam_head_source_vertices':list(SEAM),'fixed_body_boundary':list(range(168,192)),'retired_old_neck_ring8':list(range(192,216)),'old_neck_portal':'ALLinactive; oldattributesbyteexact','inward_source_targets':[{'seam_h':h,'terms':[[k,w.numerator,w.denominator]for k,w in inward_terms(h)]}for h in SEAM],'new_vertices':720,'new_patch_faces':1492,'new_interior_t':[float(t)for t in TIMES],'angular_phases_rational':[[p.numerator,p.denominator]for p in PHASES],'old_attribute_changes':[],'head_ear_retained_faces':2912,'head_boundary_edges':28,'patch_boundary_edges':52,'patch_Euler':0,'rig/eyes/ears/muzzle':'ALLoldattributes/rigexact','not_proven':['actual3Dselfembedding','63poses','gear','visualanatomy/photo']}

def zipper(a,pa,b,pb):
 require(len(a)==len(pa)and len(b)==len(pb)and pa[0]==pb[0]==0,'Explicitloopphaseownership');require(list(pa)==sorted(set(pa))and list(pb)==sorted(set(pb)),'Strictorderedphases')
 i=j=0;faces=[]
 while i<len(a)or j<len(b):
  na=pa[i+1]if i+1<len(a)else F(1);nb=pb[j+1]if j+1<len(b)else F(1)
  ai=a[i%len(a)];bj=b[j%len(b)]
  if na==nb:faces.extend([(ai,a[(i+1)%len(a)],b[(j+1)%len(b)]),(ai,b[(j+1)%len(b)],bj)]);i+=1;j+=1
  elif na<nb:faces.append((ai,a[(i+1)%len(a)],bj));i+=1
  else:faces.append((ai,b[(j+1)%len(b)],bj));j+=1
 require(len(faces)==len(a)+len(b),'Completeexplicit annuluszipper');return faces

def field(values,s):
 n=len(values);q=s*n;i=q.numerator//q.denominator;u=q-i;a=values[i%n];b=values[(i+1)%n]
 if isinstance(a,(tuple,list)):return tuple((1-u)*x+u*y for x,y in zip(a,b))
 return(1-u)*a+u*b

def inward_terms(h):
 if h in range(1,12):return[(h+24,F(1))]
 if h==0:return[(1,F(1,2)),(24,F(1,2))]
 if h==12:return[(11,F(1,2)),(36,F(1,2))]
 if h==24:return[(25,F(1))]
 if h==36:return[(35,F(1))]
 if h==60:return[(59,F(1,2)),(96,F(1,2))]
 if h==48:return[(49,F(1,2)),(72,F(1,2))]
 require(61<=h<=71,'Declaredheadboundarypoint');return[(72+2*(h-48),F(1))]

def evaluate(A,B,headP,headW):
 # Inputvertices already resolved by pinnedsourceIDs. Fractions make output
 # independent of floatcontrolrounding; no implicitnewskinweights or anchors.
 A=[tuple(F(float(x))for x in p)for p in A];B=[tuple(F(float(x))for x in p)for p in B];require(len(A)==len(B)==24,'Bodyanchorcount')
 HP={h:tuple(F(float(x))for x in p)for h,p in headP.items()};HW={h:tuple(F(float(w))for w in weights)for h,weights in headW.items()};Q=[HP[h]for h in SEAM];D=[];DW=[]
 for h in SEAM:
  terms=inward_terms(h);target=tuple(sum(HP[k][c]*w for k,w in terms)for c in range(3));D.append(tuple(target[c]-HP[h][c]for c in range(3)));dw=tuple(sum(HW[k][c]*w for k,w in terms)-HW[h][c]for c in range(2));require(0<=dw[1]<=3*HW[h][1]and -3*(1-HW[h][0])<=dw[0]<=0,'Monotonicnewweight endpoint condition');DW.append(dw)
 points=[];weights=[];keys=[]
 for j,t in enumerate(TIMES):
  h00=2*t**3-3*t*t+1;h10=t**3-2*t*t+t;h01=-2*t**3+3*t*t;h11=t**3-t*t
  for k,s in enumerate(PHASES):
   a,b,q,d=field(A,s),field(B,s),field(Q,s),field(D,s);points.append(tuple(float(h00*b[c]+h10*(b[c]-a[c])+h01*q[c]+h11*d[c])for c in range(3)));qw=field([HW[h]for h in SEAM],s);dw=field(DW,s);w=(h00+h01*qw[0]+h11*dw[0],h01*qw[1]+h11*dw[1]);require(all(0<=v<=1 for v in w)and abs(sum(w)-1)<F(1,1000000),'Newweight finitebounded');weights.append([float(w[0]),float(w[1]),0.,0.]);keys.append(f'hybrid:{j}:{k}')
 rows=[['B:'+str(i)for i in range(168,192)]]+[[f'hybrid:{j}:{k}'for k in range(48)]for j in range(15)]+[['h:'+str(h)for h in SEAM]];phases=[tuple(F(i,24)for i in range(24))]+[PHASES]*15+[tuple(F(i,28)for i in range(28))];faces=[]
 for a,pa,b,pb in zip(rows,phases,rows[1:],phases[1:]):faces.extend(zipper(a,pa,b,pb))
 require(len(points)==720 and len(faces)==1492,'Exact newscope');return{'positions':points,'weights':weights,'keys':keys,'faces':faces,'recipe':recipe()}
