# SPDX-License-Identifier: GPL-3.0-or-later
"""UNEXECUTED finite local pipeline, NO capture/SAT automatically."""
from pathlib import Path
import argparse,json,time,subprocess,hashlib,os,signal
ROOT=Path(__file__).parent

def run_once(output,release):
 start=time.monotonic()
 if release!='ROOT_RELEASE_ONE_FITTED_MANE':raise ValueError('Separate root release required')
 pins=json.loads((ROOT/'operator-source-pins.json').read_text())
 for name,want in pins.items():
  if hashlib.sha256(Path(name).read_bytes()).hexdigest()!=want:raise ValueError('Sourcepin mismatch:'+name)
 out=Path(output);out.mkdir(parents=True,exist_ok=False)
 from mane_source import recipe
 (out/'explicit-mane-recipe.json').write_text(json.dumps(recipe(),indent=2)+'\n')
 receipt={'status':'STARTED UNACCEPTED','source_pins':pins,'phases':[],'overall_cap_s':90,'phase_cap_s':30,'capture_SAT_gear_browser':'NOT AUTHORIZED'}
 def save():(out/'operator-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 save();commands=[['/workspace/shared/chicago-venv/bin/python',str(ROOT/'pipeline_stage.py'),stage,str(out)]for stage in['export','metadata','rest']]+[['node',str(ROOT/'local_khronos.cjs'),str(out)]]
 for i,cmd in enumerate(commands):
  budget=min(30,90-(time.monotonic()-start))
  if budget<=0:receipt.update(status='FIRST FAILURE wall deadline STOP');save();return 124
  with(out/f'phase{i+1}.stdout.log').open('wb')as stdout,(out/f'phase{i+1}.stderr.log').open('wb')as stderr:
   try:
    process=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,start_new_session=True)
    try:code=process.wait(timeout=budget)
    except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait();code=124
   except Exception as e:stderr.write((str(e)+'\n').encode());code=127
  receipt['phases'].append({'stage':i+1,'command':cmd,'returncode':code,'elapsed_s':time.monotonic()-start});save()
  if code:receipt.update(status='FIRST FAILURE STOP; no retry/search/repair');save();return code
 receipt.update(status='LOCAL FITTED MANE/REST/METADATA/KHRONOS ONLY; UNACCEPTED',elapsed_s=time.monotonic()-start);save();return 0
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output-dir',required=True);ap.add_argument('--release-token',required=True);a=ap.parse_args();raise SystemExit(run_once(a.output_dir,a.release_token))
