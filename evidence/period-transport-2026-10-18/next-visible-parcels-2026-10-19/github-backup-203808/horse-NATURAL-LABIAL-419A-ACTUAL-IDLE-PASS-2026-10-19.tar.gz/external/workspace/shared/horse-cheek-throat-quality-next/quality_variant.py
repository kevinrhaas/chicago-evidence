# SPDX-License-Identifier: CC0-1.0
"""One original source-owned position sculpt; no invocation at import."""
from pathlib import Path
import copy,json,hashlib
import numpy as np
from input_contract import context,GLB_SHA,PACKET_SHA,PROOF_SHA,SOURCE_SHA
from quality_field import displacement,boundary_fade,recipe
from ownership import Model,ATTRS
from sparse_rules import require
from glb_data import append,encode

def evaluate(c):
 m=c['model'];v=m.views[0,0];a=v['attributes'];p=a['POSITION'].copy();requested={}
 for tag,ids in sorted(c['groups'].items()):
  allow=tag in c['eligible_labels']and tag not in c['protected_labels'];fade=boundary_fade(c['distance'].get(tag,3));delta=displacement(a['POSITION'][ids[0]].astype(float).tolist(),tag,fade,allow);require(np.isfinite(delta).all(),'Finitedeclaredfield');require(abs(delta[0])<=.012 and -.015<=delta[1]<=0 and -.020<=delta[2]<=0,'Logicalcomponentbounds');new=(a['POSITION'][ids[0]].astype(float)+delta).astype('<f4')
  for i in ids:p[i]=new;requested[i]=delta
 changed=set(map(int,np.flatnonzero(np.any(p!=a['POSITION'],axis=1))));require(bool(changed),'Visiblefieldmustchangesomeactualpositions');actual=p.astype(float)-a['POSITION'].astype(float);rq=np.array([requested.get(i,[0.,0.,0.])for i in range(len(p))]);require(np.all(np.abs(actual-rq)<=.5*np.abs(np.spacing(p)).astype(float)+1e-14),'SerializedhalfULPpositionquantizationONLY')
 idx=v['indices'];changedfaces=set(map(int,np.flatnonzero(np.any(np.isin(idx,list(changed)),axis=1))));halo=set(int(i)for f in changedfaces for i in idx[f]);neighborfaces=set(map(int,np.flatnonzero(np.any(np.isin(idx,list(halo)),axis=1))));halo.update(int(i)for f in neighborfaces for i in idx[f]);halo={i for i in halo if c['keylabels'][i]not in c['protected_labels']};n=a['NORMAL'].copy();tri=p[idx].astype(float);oldtri=a['POSITION'][idx].astype(float);area=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);oldarea=np.cross(oldtri[:,1]-oldtri[:,0],oldtri[:,2]-oldtri[:,0]);require(np.isfinite(area).all()and np.all(np.linalg.norm(area,axis=1)>2e-12),'Newactivecoatfinite/nondenegenerate');require(np.all(np.sum(area[list(changedfaces)]*oldarea[list(changedfaces)],axis=1)>0),'Changedfaceorientationmustnotflip')
 sums={tag:np.zeros(3)for tag in c['groups']}
 for face,vector in zip(idx,area):
  for i in face:sums[c['keylabels'][int(i)]]+=vector
 for i in sorted(halo):
  value=sums[c['keylabels'][i]];length=np.linalg.norm(value);require(np.isfinite(length)and length>1e-12,'Nhaloarea valid');n[i]=(value/length).astype('<f4')
 return p,n,{'changed_position_vertices':sorted(changed),'changed_position_faces':sorted(changedfaces),'normal_halo_vertices':sorted(halo),'normal_halo_face_neighborhood':sorted(neighborfaces),'requested_delta_m':{str(i):requested[i]for i in sorted(changed)},'actual_delta_m':{str(i):actual[i].tolist()for i in sorted(changed)},'actual_vector_max_m':float(np.linalg.norm(actual,axis=1).max()),'position_quantization_halfULP_not_collision_tolerance':True}

def source_receipt(c):return{'qualified_parent_sha256':GLB_SHA,'qualified_parent_packet_sha256':PACKET_SHA,'qualified_parent_graft_proof_sha256':PROOF_SHA,'oral_head_source_sha256':SOURCE_SHA,'recipe':recipe(),'protected_source_labels':sorted(c['protected_labels']),'protected_actual_owner_faces':sorted(c['protected_faces']),'eligible_source_labels':sorted(c['eligible_labels']),'source_graph_boundary_distance_0to3':{k:v for k,v in sorted(c['distance'].items())},'active_source_alias_groups':{k:v for k,v in sorted(c['groups'].items())if len(v)>1}}

def audit(raw,c,proof):
 old=c['model'];new=Model(raw);require(new.total==old.total==13226 and set(new.views)==set(old.views),'Allactivecounts/owners');ep,en,expected=evaluate(c);require(proof['source']==source_receipt(c)and proof['sparse_change']==expected,'Completeactualsourceauthority/sparseproof');na=new.views[0,0]['attributes'];oa=old.views[0,0]['attributes'];require(np.array_equal(na['POSITION'],ep)and np.array_equal(na['NORMAL'],en),'ActualserializedintendedP/N');changed=set(expected['changed_position_vertices']);halo=set(expected['normal_halo_vertices']);protected={i for i,t in c['keylabels'].items()if t in c['protected_labels']};require(not(changed&protected)and not(halo&protected),'Feature/ear/oral/crossmaterialprotection')
 for key,v in old.views.items():
  w=new.views[key];require(v['material']==w['material']and v['mesh_name']==w['mesh_name']and np.array_equal(v['indices'],w['indices']),'Allmaterial/indexowners exact')
  for attr in ATTRS:
   if key==(0,0)and attr in['POSITION','NORMAL']:continue
   require(v['attributes'][attr].tobytes()==w['attributes'][attr].tobytes(),'ALLotherattributes/rigidinterfaces exact')
 require(all(na['POSITION'][i].tobytes()==oa['POSITION'][i].tobytes()for i in range(len(ep))if i not in changed),'AlloutsidePOSrows exact');require(all(na['NORMAL'][i].tobytes()==oa['NORMAL'][i].tobytes()for i in range(len(en))if i not in halo),'AlloutsideNhalo exact')
 # Verify every protected feature face exactly, including the qualified oral/nostril normals.
 for g in c['protected_faces']:
  desc=old.descriptor(g);key=desc['mesh'],desc['primitive'];ids=desc['primitive_vertices']
  for attr in ATTRS:require(old.views[key]['attributes'][attr][ids].tobytes()==new.views[key]['attributes'][attr][ids].tobytes(),'Protectedoral/eye/nostril/earface exact')
 d,e=old.d,new.d;na0,nv=len(d['accessors']),len(d['bufferViews']);require(len(e['accessors'])==na0+2 and len(e['bufferViews'])==nv+2 and e['accessors'][:na0]==d['accessors']and e['bufferViews'][:nv]==d['bufferViews'],'Only2appendedP/Nrecords');require(bytes(new.b[:len(old.b)])==bytes(old.b),'OriginalBINprefix');offset=len(old.b)
 for k,attr in enumerate(['POSITION','NORMAL']):
  ref=e['meshes'][0]['primitives'][0]['attributes'][attr];arr=new.views[0,0]['attributes'][attr];require(ref==na0+k and e['accessors'][ref]=={'bufferView':nv+k,'componentType':5126,'count':len(arr),'type':'VEC3','min':arr.min(0).tolist(),'max':arr.max(0).tolist()},'ReloadedactualP/Naccessorref/metadata');require(e['bufferViews'][nv+k]=={'buffer':0,'byteOffset':offset,'byteLength':arr.nbytes,'target':34962},'Exactappendextent');offset+=arr.nbytes
 require(offset==len(new.b)==e['buffers'][0]['byteLength'],'ExactnewBINlength');x,y=copy.deepcopy(d),copy.deepcopy(e)
 for doc in[x,y]:
  for attr in['POSITION','NORMAL']:doc['meshes'][0]['primitives'][0]['attributes'].pop(attr)
  doc.pop('accessors');doc.pop('bufferViews');doc['buffers'][0].pop('byteLength')
 require(x==y,'Allrig/IBMs/actions/socket/material/document exact')
 return{'status':'SOURCE/REST ONLY; actualself/gearfit/visual UNTESTED','all_indices_JW_rig_soles_frames_exact':True,'all_protected_oral_eye_nostril_ear_attributes_exact':True,'all_outside_sparsePOS_Nhalo_exact':True,'new_vertex_count':0,'new_triangle_count':0,'actual_changed_positions':len(changed),'actual_Nhalo':len(halo)}

def produce(out):
 out=Path(out);out.mkdir(parents=True,exist_ok=False);c=context();p,n,sparse=evaluate(c);d=copy.deepcopy(c['model'].d);b=bytearray(c['model'].b)
 for attr,array in[('POSITION',p),('NORMAL',n)]:d['meshes'][0]['primitives'][0]['attributes'][attr]=append(d,b,array,'VEC3')
 raw=encode(d,b);(out/'UNVALIDATED-candidate.glb').write_bytes(raw);proof={'status':'UNACCEPTED originalcheek/throatqualitystudy','candidate_sha256':hashlib.sha256(raw).hexdigest(),'source':source_receipt(c),'sparse_change':sparse};proof['actual_readback']=audit(raw,c,proof);(out/'candidate.glb').write_bytes(raw);(out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');return proof
if __name__=='__main__':
 import sys
 print(json.dumps(produce(sys.argv[1])['actual_readback']))
