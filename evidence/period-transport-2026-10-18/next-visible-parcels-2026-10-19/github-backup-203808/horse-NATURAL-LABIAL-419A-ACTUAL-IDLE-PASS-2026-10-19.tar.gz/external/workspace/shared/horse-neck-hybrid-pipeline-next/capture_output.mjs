// SPDX-License-Identifier: GPL-3.0-or-later
import fs from 'node:fs';
import path from 'node:path';
export function claimCaptureOutput(output){
 // Parent creation does not grant leaf ownership. EEXIST refuses before writes.
 fs.mkdirSync(path.dirname(output),{recursive:true});
 fs.mkdirSync(output);
 return output;
}
