# SPDX-License-Identifier: CC0-1.0
"""Decode only old GLB JSON/index bytes and semantic source labels, no P access."""
from pathlib import Path
import json,hashlib,struct
from topology_guard import manifold,require
from assemble import edges
P=Path(__file__).parent
raw=Path('/workspace/shared/horse-cheek-throat-quality-next/candidate-one/candidate.glb').read_bytes();require(hashlib.sha256(raw).hexdigest()=='57d63e2d7234380adeb727f5efeeed74d50629b2a8367ccea48961d6ecc5bec2','Parent exact57d');n=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+n]);buf=raw[28+n:]
g=json.loads(Path('/workspace/shared/horse-combined-oral-neck-mane-prefix-next/candidate-one/graft-proof.json').read_text());labels={(r['mesh'],r['vertex']):r['label']for r in g['source_labels']};owners=g['source_face_owners'];head=set(g['head_faces']);old=[];kept=[];removed=[];gid=0
for mi,m in enumerate(doc['meshes']):
 for pi,primitive in enumerate(m['primitives']):
  a=doc['accessors'][primitive['indices']];v=doc['bufferViews'][a['bufferView']];require(a['type']=='SCALAR'and a['count']%3==0,'Triangle index accessor');fmt={5121:'B',5123:'H',5125:'I'}[a['componentType']];size=struct.calcsize('<'+fmt);start=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',size);ids=[struct.unpack_from('<'+fmt,buf,start+i*stride)[0]for i in range(a['count'])]
  for j in range(0,len(ids),3):
   if gid in head:
    t=[labels[mi,i]for i in ids[j:j+3]];old.append(t);o=owners[str(gid)]
    if o.get('kind')=='oral_channel'and o['source_owner']['kind']in['oral_rim_connector','oral_roof','oral_floor','oral_back']:removed.append(gid)
    else:kept.append(t)
   gid+=1
require(len(old)==3122 and len(removed)==334,'Exact old head/retirement source coverage');boundary={e for e,r in edges(old).items()if len(r)==1};parent=manifold(old,boundary,1);new=json.loads((P/'symbolic-handle.json').read_text());proof=manifold(kept+new['triangles'],boundary,-1);require(len(boundary)==28 and proof['F']==3122-334+new['summary']['F'],'Derived full neutral head cardinality');report={'scope':'Stored old index buffers/source labels plus new symbolic indices ONLY; no P access or new XYZ','parent':parent,'assembled_head':proof,'mouth':new['summary'],'retired_current_mouth334':removed,'source57d_sha256':hashlib.sha256(raw).hexdigest(),'unchanged_neck_boundary':sorted(map(list,boundary)),'neutral_apposed_lip_approximation':True,'no_actual_geometry':True}
with(P/'head-proof.json').open('x')as f:f.write(json.dumps(report,indent=2)+'\n')
print(json.dumps(proof))
