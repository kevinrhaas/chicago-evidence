# SPDX-License-Identifier: CC0-1.0
"""Source index surgery only, no positions/producer/GLB export."""
from pathlib import Path
from fractions import Fraction as Q
from collections import defaultdict
import json,hashlib
from topology_guard import manifold,require
P=Path(__file__).parent
OLD=Path('/workspace/shared/horse-neutral-lip-conforming-metadata-preserving-next/complete-symbolic.json')
PIN='533327aa317f52725b16e070d48905bcc69c038879b9522b32eb632d0da86dc9'
def edges(T):
 E=defaultdict(list)
 for t in T:
  for a,b in zip(t,t[1:]+t[:1]):E[tuple(sorted((a,b)))].append((a,b))
 return E
def boundary_loop(T):
 E=edges(T);bd=[r[0]for r in E.values()if len(r)==1];nxt=dict(bd);require(len(nxt)==len(bd),'Unique boundary successor');v=bd[0][0];loop=[]
 while v not in loop:loop.append(v);v=nxt[v]
 require(v==loop[0]and len(loop)==len(bd),'Single boundary loop');return loop

def coords(label):
 kind,z,th=label.split(':');require(kind in['cut','inner'],'Owned source rail');return kind,Q(z),Q(th)
def build():
 raw=OLD.read_bytes();require(hashlib.sha256(raw).hexdigest()==PIN,'Pinned original source');a=json.loads(raw);T=a['triangles'];O=a['owners'];removed={'upper':[],'lower':[]};inverse={v:k for k,v in a['seam_equivalences'].items()}
 for i,(t,o)in enumerate(zip(T,O)):
  if o['kind']!='wet_lining':continue
  c=[coords(v if v.startswith(('cut:','inner:'))else inverse[v])for v in t]
  if not all(z>=Q('.435')for _,z,th in c):continue
  if all(th in[26,46]or z==Q('.532')for _,z,th in c):removed['upper'].append(i)
  elif all(th in[28,44]or z==Q('.530')for _,z,th in c):removed['lower'].append(i)
 params={};summaries={}
 for side,ids in removed.items():
  require(ids,'Nonempty owned disk');patch=[T[i]for i in ids];loop=boundary_loop(patch);bd={e for e,r in edges(patch).items()if len(r)==1};summaries[side]=manifold(patch,bd,1)
  def phase(label):
   kind,z,th=coords(label);lo,hi,end=(Q(26),Q(46),Q('.532'))if side=='upper'else(Q(28),Q(44),Q('.530'))
   if th==lo:q=(z-Q('.435'))/(end-Q('.435'))/3
   elif th==hi:q=1-(z-Q('.435'))/(end-Q('.435'))/3
   else:require(z==end,'Front transverse rail');q=Q(1,3)+(th-lo)/(hi-lo)/3
   require(0<=q<=1,'Rail phase bounds');return q if kind=='cut'else Q(21,10)-q
  by={phase(v):v for v in loop};require(len(by)==len(loop),'Distinct source phases');order=[by[k]for k in sorted(by)];canonical=list(zip(order,order[1:]+order[:1]));directed=set(zip(loop,loop[1:]+loop[:1]));sign=1 if all(e in directed for e in canonical)else-1;require(sign==1 or all(e[::-1]in directed for e in canonical),'Canonical loop direction');params[side]={'by_phase':by,'sign':sign}
 require(params['upper']['sign']==-params['lower']['sign'],'Opposite attachment disk orientation')
 union=sorted(set(params['upper']['by_phase'])|set(params['lower']['by_phase']));require(union[0]==0 and union[-1]==Q(21,10),'Four explicit rail/return intervals')
 rings=[params['upper']['by_phase']]+[{q:'seal:'+str(r)+':'+str(q)for q in union}for r in[1,2,3]]+[params['lower']['by_phase']];newT=[];newO=[]
 def emit(t,layer,q):
  if params['upper']['sign']<0:t=t[::-1]
  kind='closed_lip_outer_roll'if q<1 else'closed_lip_inner_wall'if Q(11,10)<=q<Q(21,10)else'closed_lip_corner_return';newT.append(t);newO.append({'kind':kind,'layer':layer,'phase':str(q),'neutral_apposed_lip_approximation':True})
 for layer,(A,B)in enumerate(zip(rings,rings[1:])):
  ka,kb=sorted(A),sorted(B);i=j=0
  while i<len(ka)or j<len(kb):
   qa,qb=ka[i%len(ka)],kb[j%len(kb)];na=ka[(i+1)%len(ka)]+(Q(11,5)if i+1>=len(ka)else 0);nb=kb[(j+1)%len(kb)]+(Q(11,5)if j+1>=len(kb)else 0);va,vb=A[qa],B[qb]
   if na==nb:emit([va,A[ka[(i+1)%len(ka)]],B[kb[(j+1)%len(kb)]]],layer,min(qa,qb));emit([va,B[kb[(j+1)%len(kb)]],vb],layer,min(qa,qb));i+=1;j+=1
   elif na<nb:emit([va,A[ka[(i+1)%len(ka)]],vb],layer,min(qa,qb));i+=1
   else:emit([va,B[kb[(j+1)%len(kb)]],vb],layer,min(qa,qb));j+=1
 retired=set(removed['upper']+removed['lower']);kept=[i for i in range(len(T))if i not in retired];new=[T[i]for i in kept]+newT;owners=[O[i]for i in kept]+newO;bd={e for e,r in edges(T).items()if len(r)==1};summary=manifold(new,bd,-1)
 return{'status':'SOURCE indices only, no new XYZ','summary':summary,'source_sha256':PIN,'removed_lining_faces':removed,'removed_patch_disks':summaries,'old_face_retained_indices':kept,'triangles':new,'owners':owners,'seam_equivalences':a['seam_equivalences'],'rings':[{str(q):v for q,v in row.items()}for row in rings],'phase_period':'11/5','source_ring_parameters':{s:{'sign':v['sign'],'by_phase':{str(q):x for q,x in v['by_phase'].items()}}for s,v in params.items()},'physical_claim':'NONE: symbolic manifold only; recipe/XYZ/serialized ownership/fit/bit/visual remain unexecuted'}
if __name__=='__main__':
 r=build()
 with(P/'symbolic-handle.json').open('x')as f:f.write(json.dumps(r,indent=2)+'\n')
 print(json.dumps({'summary':r['summary'],'retired':{k:len(v)for k,v in r['removed_lining_faces'].items()},'rings':[len(x)for x in r['rings']]}))
