# SPDX-License-Identifier: GPL-3.0-or-later
from sparse_rules import require
def storage_audit(old,new):
 a,b=old.d,new.d;na,nv=len(a['accessors']),len(a['bufferViews']);require(len(b['accessors'])==na+5 and len(b['bufferViews'])==nv+5,'Exactly5appendedstorage records')
 require(b['accessors'][:na]==a['accessors']and b['bufferViews'][:nv]==a['bufferViews'],'Oldaccessor/view metadata changed')
 require(bytes(new.b[:len(old.b)])==bytes(old.b),'OldBINprefix changed')
 prim=b['meshes'][1]['primitives'][0];spec=[('POSITION','VEC3',5126,34962),('NORMAL','VEC3',5126,34962),('JOINTS_0','VEC4',5123,34962),('WEIGHTS_0','VEC4',5126,34962),('indices','SCALAR',5125,34963)];offset=len(old.b)
 for i,(name,typ,comp,target)in enumerate(spec):
  ref=prim['indices']if name=='indices'else prim['attributes'][name];require(ref==na+i,'Orderednewactualaccessor ref');ac=b['accessors'][ref];view=b['bufferViews'][nv+i]
  require(ac['bufferView']==nv+i and ac['componentType']==comp and ac['type']==typ,'Newaccessor type/owner')
  fields={'bufferView','componentType','count','type'}|({'min','max'}if typ in['VEC3','SCALAR']else set());require(set(ac)==fields,'Exact appendedaccessor metadata')
  count=new.views[1,0]['indices'].size if name=='indices'else len(new.views[1,0]['attributes'][name]);width=1 if name=='indices'else(3 if typ=='VEC3'else 4);size=2 if comp==5123 else 4
  require(ac['count']==count and view=={'buffer':0,'byteOffset':offset,'byteLength':count*width*size,'target':target},'Exact appendextent/view')
  arr=new.views[1,0]['indices'].reshape(-1,1)if name=='indices'else new.views[1,0]['attributes'][name]
  if 'min'in ac:require(ac['min']==arr.min(0).tolist()and ac['max']==arr.max(0).tolist(),'Actual minmax')
  offset+=count*width*size;require(offset%4==0,'Appendalignment')
 require(offset==len(new.b)==b['buffers'][0]['byteLength'],'Exact newBINextent')
 import copy
 x,y=copy.deepcopy(a),copy.deepcopy(b)
 for d in[x,y]:
  p=d['meshes'][1]['primitives'][0];p.pop('indices');p.pop('attributes')
  for k in['accessors','bufferViews']:d.pop(k)
  d['buffers'][0].pop('byteLength')
 require(x==y,'Protected rig/clips/materials/otherdocument changed')
 return{'oldBINprefix_exact':True,'original_storage_metadata_exact':True,'protected_document_exact':True}

