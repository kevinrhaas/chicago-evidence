# SPDX-License-Identifier: CC0-1.0
import unittest,collections,math
import numpy as np
from lip_surface import surface,BREAKS
from chart_topology import validate_sheets,triangulate

def synthetic():
 O=[];I=[];N=[]
 # Explicit invented source chart, not horse measurements/mesh.
 Z={1:[.34,.39,.445,.48,.505],3:[.525,.505,.48,.445,.39],5:[.34,.39,.445,.48,.505,.525],7:[.535,.525,.505,.48,.445,.39]}
 corners=[[-.045,-.185,.37],[-.045,-.218,.37],[-.045,-.218,.50],[.045,-.218,.50],[.045,-.218,.37],[.045,-.185,.37],[.045,-.185,.50],[-.045,-.185,.50],[-.045,-.185,.37]]
 for a,(start,end)in enumerate(zip(BREAKS,BREAKS[1:])):
  for i in range(end-start):
   t=i/(end-start)
   if a in[0,4]:
    side=-1 if a==0 else 1;y=(-.15-.08*t)if a==0 else(-.23+.08*t);p=[side*.07,y,.34];n=[side,0,0]
   elif a in[1,3,5,7]:
    z=Z[a][i];side=-1 if a in[1,7]else 1;p=[side*.07,-.15 if a in[5,7]else-.23,z];n=[side,0,0]
   else:
    x=(-.038+.076*t)if a==2 else(.025-.05*t);p=[x,-.23 if a==2 else-.15,.525 if a==2 else.535];n=[0,0,1]
   O.append(p);N.append(n);I.append([(1-t)*corners[a][k]+t*corners[a+1][k]for k in range(3)])
 ids=list(range(1000,1066))
 for i,v in[(65,385),(5,389),(33,407),(27,403)]:ids[i]=v
 return O,I,N,[p[:]for p in O],ids
class Controls(unittest.TestCase):
 def test_exact_boundaries_and_annulus(self):
  O,I,N,S,ids=synthetic();s=surface(O,I,N,S,ids);self.assertEqual(s['positions'][:66],O);self.assertEqual(s['positions'][66:132],I);self.assertEqual(len(s['faces']),660);e=collections.defaultdict(list)
  for f in s['faces']:
   for a,b in zip(f,f[1:]+f[:1]):e[tuple(sorted((a,b)))].append((a,b))
  self.assertEqual(sum(len(x)==1 for x in e.values()),132);self.assertTrue(all(len(x)==1 or(len(x)==2 and x[0]==x[1][::-1])for x in e.values()));self.assertEqual(396-len(e)+660,0)
 def test_front_gap_and_owners(self):
  s=surface(*synthetic());self.assertEqual(collections.Counter(o['kind']for o in s['owners']),{'lip_skin':462,'oral_lining':198});self.assertEqual(len(s['aperture']),132);self.assertTrue(np.isfinite(s['positions']).all())
 def test_negative_missing_anchor(self):
  O,I,N,S,ids=synthetic();ids[5]=999
  with self.assertRaises(ValueError):surface(O,I,N,S,ids)
 def test_negative_normals(self):
  O,I,N,S,ids=synthetic();N[0]=[0,0,0]
  with self.assertRaises(ValueError):surface(O,I,N,S,ids)
 def test_negative_uv_overlap(self):
  s=surface(*synthetic());F=s['faces']+[s['faces'][0]];O=s['owners']+[s['owners'][0]]
  with self.assertRaises(ValueError):validate_sheets(s['positions'],F,O,s['source_intrinsic_uv'])
 def test_negative_uv_gap(self):
  s=surface(*synthetic())
  with self.assertRaises(ValueError):validate_sheets(s['positions'],s['faces'][1:],s['owners'][1:],s['source_intrinsic_uv'])
 def test_negative_uv_winding(self):
  s=surface(*synthetic());s['faces'][0]=s['faces'][0][::-1]
  with self.assertRaises(ValueError):validate_sheets(s['positions'],s['faces'],s['owners'],s['source_intrinsic_uv'])
 def test_negative_source_phase_reversal(self):
  O,I,N,S,ids=synthetic();S[6][2]=.38
  with self.assertRaises(ValueError):surface(O,I,N,S,ids)
 def test_negative_uv_bowtie(self):
  with self.assertRaises(ValueError):triangulate([[0,0,0]]*4,[0,1,2,3],0,[[0,0],[1,1],[0,1],[1,0]])
 def test_encoded_boundary_with_original_source_phase(self):
  O,I,N,S,ids=synthetic();origin=np.array([0.,1.88,.8]);O=((np.asarray(O)+origin).astype('<f4').astype(float)-origin).tolist();I=((np.asarray(I)+origin).astype('<f4').astype(float)-origin).tolist();self.assertNotEqual(O[5][2],.39);r=surface(O,I,N,S,ids);self.assertEqual(r['positions'][:66],O);self.assertEqual(r['positions'][66:132],I)
 def test_negative_stale_original_phase(self):
  O,I,N,S,ids=synthetic();S[5][2]=.3900001
  with self.assertRaises(ValueError):surface(O,I,N,S,ids)
 def test_negative_wrong_count(self):
  O,I,N,S,ids=synthetic()
  with self.assertRaises(ValueError):surface(O[:-1],I,N,S,ids)
if __name__=='__main__':unittest.main()
