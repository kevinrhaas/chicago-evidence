# SPDX-License-Identifier: GPL-3.0-or-later
from collections import defaultdict
from sparse_rules import require
from local_patch import recipe,cycle,boundary
from check_idle import scan,write

def patch_ownership(model,records):
 r=recipe();idx=model.views[0,0]['indices'];lookup=defaultdict(list)
 for i,f in enumerate(idx):lookup[cycle(f.tolist())].append(model.start[0,0]+i)
 selected=set()
 for f in r['new_faces']:
  hits=lookup[cycle(f)];require(len(hits)==1,'New explicitface missing/duplicate');selected.add(hits[0])
 require(len(selected)==12,'Exactpatched12scope')
 uses=defaultdict(list);vertices=set()
 for g in selected:
  t=records[g];vertices.update(t)
  for a,b in zip(t,t[1:]+t[:1]):uses[tuple(sorted([a,b]))].append((g,a,b))
 def label(i):return'h:'+str(i-216)if 216<=i<240 else'body:0:'+str(i)
 ring=[label(i)for i in r['boundary_order']];expected={tuple(sorted([ring[i],ring[(i+1)%14]]))for i in range(14)}
 require({e for e,u in uses.items()if len(u)==1}==expected and len(vertices)-len(uses)+12==1,'Source patch must14edge diskEuler1')
 alluses=defaultdict(list)
 for g,t in enumerate(records):
  for a,b in zip(t,t[1:]+t[:1]):
   e=tuple(sorted([a,b]))
   if e in uses:alluses[e].append((g,a,b))
 internal=set();external=set()
 for e,u in alluses.items():
  require(len(u)==2 and u[0][1:]==u[1][:0:-1],'Uniqueoppositeownededge required')
  pair=tuple(sorted([u[0][0],u[1][0]]));(internal if all(x in selected for x in pair)else external).add(pair)
 return selected,internal,external

def check_patch(model,records,data,out):
 selected,internal,external=patch_ownership(model,records);write(out/'patch12-ownership.json',{'active_faces':sorted(selected),'topology':'one14boundarydisk Euler1','source_recipe':recipe()})
 scopes=[]
 for engine,meaning,edges in[('head_internal','patched12_INTERNAL',internal),('head_vs_all_rest','patched12_vsALLother_active_horse',external)]:
  r=scan('patched12',engine,model,records,selected,data,edges,out,True,declared_scope=meaning);scopes.append(r)
  if r['counts']['unexpected_SAT']or r['counts']['strict_proper']:return False,scopes
 return True,scopes
