// SPDX-License-Identifier: GPL-3.0-or-later
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import assert from 'node:assert/strict';
import {claimCaptureOutput} from './capture_output.mjs';
const root=fs.mkdtempSync(path.join(os.tmpdir(),'capture-claim-control-'));
try{
 const old=path.join(root,'old');fs.mkdirSync(old);fs.writeFileSync(path.join(old,'sentinel'),'prior');fs.writeFileSync(path.join(old,'capture-receipt.json'),'original-receipt');
 const before=fs.readdirSync(old).map(n=>[n,fs.readFileSync(path.join(old,n),'hex')]);
 assert.throws(()=>claimCaptureOutput(old),{code:'EEXIST'});assert.deepEqual(fs.readdirSync(old).map(n=>[n,fs.readFileSync(path.join(old,n),'hex')]),before);
 // Inject a competing leaf creation AFTER recursive parent creation but BEFORE
 // the owned leaf mkdir, the exact old TOCTOU window. No horse modules loaded.
 const raced=path.join(root,'parent','raced'),parent=path.dirname(raced),originalMkdir=fs.mkdirSync;
 fs.mkdirSync=function(target,options){const result=originalMkdir(target,options);if(target===parent){originalMkdir(raced);fs.writeFileSync(path.join(raced,'sentinel'),'race-winner');}return result;};
 try{assert.throws(()=>claimCaptureOutput(raced),{code:'EEXIST'});}finally{fs.mkdirSync=originalMkdir;}
 assert.deepEqual(fs.readdirSync(raced),['sentinel']);assert.equal(fs.readFileSync(path.join(raced,'sentinel'),'utf8'),'race-winner');
 const fresh=path.join(root,'new-parent','owned');assert.equal(claimCaptureOutput(fresh),fresh);assert.deepEqual(fs.readdirSync(fresh),[]);
 console.log('PASS existing-output refusal, raced-leaf refusal, prior bytes unchanged, fresh exclusive claim; NO horse IO');
}finally{fs.rmSync(root,{recursive:true,force:true});}
