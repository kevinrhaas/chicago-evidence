# SPDX-License-Identifier: GPL-3.0-or-later
from collections import defaultdict
from sparse_rules import require
from check_idle import scan,write

def patch_ownership(model,records,proof):
 ip=proof['index_proof'];count=proof['parent_coat_vertex_count'];start=len(model.views[0,0]['indices'])-768;selected=set(range(model.start[0,0]+start,model.start[0,0]+start+768))
 require(len(selected)==768,'Fullnewpatch768')
 expected=[];rows=[list(range(168,192))]+[list(range(count+j*24,count+(j+1)*24))for j in range(15)]+[list(range(216,240))]
 for a,b in zip(rows,rows[1:]):
  for k in range(24):j=(k+1)%24;expected.extend([(a[k],a[j],b[j]),(a[k],b[j],b[k])])
 require(model.views[0,0]['indices'][start:].tolist()==[list(f)for f in expected],'Actualsource768faceownership')
 uses=defaultdict(list);vertices=set();graph=defaultdict(set)
 for g in selected:
  t=records[g];vertices.update(t)
  for a,b in zip(t,t[1:]+t[:1]):uses[tuple(sorted([a,b]))].append((g,a,b));graph[a].add(b);graph[b].add(a)
 expectedboundary=set()
 for ring in[[f'body:0:{i}'for i in range(168,192)],[f'h:{i}'for i in range(24)]]:expectedboundary|={tuple(sorted([ring[i],ring[(i+1)%24]]))for i in range(24)}
 require({e for e,u in uses.items()if len(u)==1}==expectedboundary and len(vertices)-len(uses)+768==0,'Two48boundaryannulusEuler0')
 seen=set();todo=[next(iter(vertices))]
 while todo:
  v=todo.pop()
  if v in seen:continue
  seen.add(v);todo.extend(graph[v]-seen)
 require(seen==vertices,'Singleconnectedpatch')
 alluses=defaultdict(list)
 for g,t in enumerate(records):
  for a,b in zip(t,t[1:]+t[:1]):
   e=tuple(sorted([a,b]))
   if e in uses:alluses[e].append((g,a,b))
 internal=set();external=set()
 for e,u in alluses.items():
  require(len(u)==2 and u[0][1:]==u[1][:0:-1],'Fullactualuniqueoppositeedgeowners')
  pair=tuple(sorted([u[0][0],u[1][0]]));(internal if all(g in selected for g in pair)else external).add(pair)
 return selected,internal,external

def check_patch(model,records,data,out,proof):
 selected,internal,external=patch_ownership(model,records,proof);write(out/'smooth768-ownership.json',{'actual_faces':sorted(selected),'topology':'oneannulus Euler0 two24boundaryloops','source_recipe':proof['source_recipe']})
 scopes=[]
 for engine,meaning,edges in[('head_internal','smooth768_INTERNAL',internal),('head_vs_all_rest','smooth768_vsALLother_active_horse',external)]:
  r=scan('smooth768',engine,model,records,selected,data,edges,out,True,declared_scope=meaning);scopes.append(r)
  if r['counts']['unexpected_SAT']or r['counts']['strict_proper']:return False,scopes
 return True,scopes
