# SPDX-License-Identifier: CC0-1.0
import unittest,math,copy
from smooth_neck_patch import *
class Controls(unittest.TestCase):
 def test_endpoint_positions_derivatives(self):
  A=(0,-1,0);B=(0,0,0);Q=(0,1,0);H=(0,2,0);c=controls(A,B,Q,H);self.assertEqual(bezier(c,0),B);self.assertEqual(bezier(c,1),Q)
  for x,y in zip(derivative(c,0),sub(B,A)):self.assertAlmostEqual(x,y)
  for x,y in zip(derivative(c,1),sub(H,Q)):self.assertAlmostEqual(x,y)
 def test_reversing_endpoint_stays_in_control_hull(self):
  c=controls((0,-1,0),(0,0,0),(0,1,0),(0,.8,-.1))
  for t in TIMES:
   p=bezier(c,t)
   for k in range(3):self.assertGreaterEqual(p[k],min(v[k]for v in c));self.assertLessEqual(p[k],max(v[k]for v in c))
 def test_weight_boundary_and_range(self):
  self.assertEqual(head_weight(0),0);self.assertAlmostEqual(head_weight(1),.5)
  for t in TIMES:self.assertTrue(0<head_weight(t)<.5)
 def test_exact_patch_topology_no_input_mutation(self):
  B=[(math.cos(i*math.tau/24),0,math.sin(i*math.tau/24))for i in range(24)];A=[(x,y-1,z)for x,y,z in B];Q=[(x,y+1,z)for x,y,z in B];H=[(x,y+2,z)for x,y,z in B];saved=copy.deepcopy([A,B,Q,H]);p=build_proposal(A,B,Q,H);self.assertEqual([A,B,Q,H],saved);self.assertEqual(len(p['new_positions']),360);self.assertEqual(len(p['faces']),768)
  edges={};verts=set()
  for f in p['faces']:
   verts.update(f)
   for a,b in zip(f,f[1:]+f[:1]):edges.setdefault(tuple(sorted([a,b])),[]).append((a,b))
  boundary=[e for e,u in edges.items()if len(u)==1];self.assertEqual(len(boundary),48);self.assertEqual(len(verts)-len(edges)+768,0)
  for u in edges.values():self.assertLessEqual(len(u),2);self.assertTrue(len(u)==1 or u[0]==tuple(reversed(u[1])))
 def test_bad_source_columns_refuse(self):
  with self.assertRaises(ValueError):build_proposal([],[],[],[])
  with self.assertRaises(ValueError):controls((0,0,0),(0,0,0),(0,1,0),(0,2,0))
  with self.assertRaises(ValueError):controls((0,0,0),(0,1,0),(0,2,0),(float('nan'),3,0))
if __name__=='__main__':unittest.main()
