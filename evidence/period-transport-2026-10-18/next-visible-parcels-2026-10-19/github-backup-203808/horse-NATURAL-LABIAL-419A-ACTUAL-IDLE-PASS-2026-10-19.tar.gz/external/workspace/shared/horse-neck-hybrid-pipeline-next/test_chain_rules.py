# SPDX-License-Identifier: GPL-3.0-or-later
import unittest,copy
from chain_rules import linked_metadata,real_sha,PINS,PARENT_AUTHORITY
from check_threeway import require_parent_negative
from source_inventory import inventory_sha
class Controls(unittest.TestCase):
 def fixture(self):
  h='ab'*32;ph='cd'*32;mh='ef'*32
  c={'parent090_glb_sha256':PINS['baseline'],'ear_parent_glb_sha256':PINS['candidate'],'neck':{r:{'sha256':h if r=='glb'else ph if r=='proof'else mh}for r in['glb','manifest','proof','authority']}}
  m={'glb_sha256':h,'parent_glb_sha256':PINS['candidate'],'sparse_proof_sha256':ph,'position_allowed':list(range(192,216)),'normal_allowed':list(range(168,216)),'all_other_attributes_exact':True,'head_ear_source_face_ownership':'unchanged_26027','status':'UNACCEPTED'}
  p={'output_sha256':h,'input_pins':PINS,'authority_sha256':PARENT_AUTHORITY};a={'glb_sha256':h,'parent_glb_sha256':PINS['candidate'],'manifest_sha256':mh};inv={'mock.py':'12'*32}
  for d in[c,m,a]:d.update(helper_source_inventory=inv,helper_source_inventory_sha256=inventory_sha(inv))
  return c,m,p,a
 def test_mock_links_only(self):self.assertEqual(linked_metadata(*self.fixture()),'ab'*32)
 def test_placeholder_fails(self):
  for x in['',None,'FUTURE_SHA','0'*64]:
   with self.assertRaises(ValueError):real_sha(x)
 def test_parent_substitution_fails(self):
  c,m,p,a=self.fixture();c['ear_parent_glb_sha256']='ab'*32
  with self.assertRaises(ValueError):linked_metadata(c,m,p,a)
 def test_authority_scope_widen_fails(self):
  c,m,p,a=self.fixture();m['normal_allowed'].append(216)
  with self.assertRaises(ValueError):linked_metadata(c,m,p,a)
 def test_broken_proof_link_fails(self):
  c,m,p,a=self.fixture();m['sparse_proof_sha256']='12'*32
  with self.assertRaises(ValueError):linked_metadata(c,m,p,a)
 def witness(self):return{'a_source_face_owner':{'source_head_face':33},'b_source_face_owner':{},'a_source_vertices':['h:16','h:41','h:40'],'b_source_vertices':['body:0:207','body:0:208','h:16'],'kind':'unexpected_strict_proper','proper_witness':{'mock':True}}
 def test_parent_actual_owner_control(self):require_parent_negative([{'complete':True,'unexpected_witnesses':[self.witness()]}])
 def test_missing_duplicate_raw_control_fail(self):
  for rows in[[],[self.witness(),self.witness()],[dict(self.witness(),kind='unexpected_raw_SAT')]]:
   with self.assertRaises(ValueError):require_parent_negative([{'complete':True,'unexpected_witnesses':rows}])
if __name__=='__main__':unittest.main()
