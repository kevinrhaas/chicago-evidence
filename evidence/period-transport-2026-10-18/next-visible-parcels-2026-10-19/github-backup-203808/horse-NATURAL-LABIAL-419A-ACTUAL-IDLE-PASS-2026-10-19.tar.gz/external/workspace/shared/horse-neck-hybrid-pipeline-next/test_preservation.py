# SPDX-License-Identifier: GPL-3.0-or-later
import unittest,tempfile
from pathlib import Path
from exclusive_output import with_exclusive_output
from chain_rules import read_pinned
from source_inventory import helper_inventory,inventory_sha
class Controls(unittest.TestCase):
 def test_existing_evidence_bytes_untouched(self):
  with tempfile.TemporaryDirectory()as d:
   p=Path(d);(p/'sentinel').write_bytes(b'original');(p/'FIRST-FAILURE.json').write_bytes(b'prior');before={f.name:f.read_bytes()for f in p.iterdir()}
   with self.assertRaises(FileExistsError):with_exclusive_output(p,lambda:None)
   self.assertEqual(before,{f.name:f.read_bytes()for f in p.iterdir()})
 def test_owned_failure_saved(self):
  with tempfile.TemporaryDirectory()as d:
   p=Path(d)/'fresh'
   with self.assertRaises(ValueError):with_exclusive_output(p,lambda:(_ for _ in()).throw(ValueError('mock')))
   self.assertIn('mock',(p/'FIRST-FAILURE.json').read_text())
 def test_escape_names_rejected_before_io(self):
  for path in['../candidate.glb','/tmp/candidate.glb','other.glb']:
   with self.assertRaises(ValueError):read_pinned({'path':path,'sha256':'ab'*32},Path('/tmp'),'glb')
 def test_inventory_binds_all_helpers(self):
  with tempfile.TemporaryDirectory()as d:
   p=Path(d);(p/'a.py').write_text('a');(p/'b.mjs').write_text('b');a=helper_inventory(p);self.assertEqual(set(a),{'a.py','b.mjs'});(p/'b.mjs').write_text('c');self.assertNotEqual(inventory_sha(a),inventory_sha(helper_inventory(p)))
if __name__=='__main__':unittest.main()
