# SPDX-License-Identifier: GPL-3.0-or-later
"""Exact frozen source→active primitive ownership; no whole-coat point welding.
This module is source preparation. Actual input reads occur only by caller.
"""
from pathlib import Path
import json,hashlib
import numpy as np
from glb_data import parse,read
from planar import need
PINS={'baseline': '090be8fdc2516ee5b5c8f886026f441850cc208f17b6ede71fed9007ab80f12f', 'candidate': '26027c225b0c2f3c6ed72543cb2e80238196a86815b7bb910744cbc65cb23ed3', 'producer090': '883fb2607a5ccb150c84b41985f62864b26d64db62052446ca45bfda9d99c5e9', 'head': 'ac4d96ab6ae8d0ef5956686a3a9c213ebce1dd9e76f5e91c4e376b319429b5b3', 'ears': 'c769254c0effdeda19aa9495bcd66da0661c71065097a5fde7e633417889deb9', 'proof': '1ed11707b8307de44d228f3dde63c7634ccabe10dce774d12fe4f0efb1438640', 'producer260': '05f7c0da4b178f773954d3e523ddb46008378c6403dc73ae4b3748eba3661967', 'source_candidate': '5522039e7e007620a0d213d1eb2ae9e976955a499f037b1cc94494fafbbe11a3'}
ORIGIN=np.array([0.,1.88,.8]);MATCH=2e-7
ATTRS=('POSITION','NORMAL','JOINTS_0','WEIGHTS_0')
def pinned(path,key):
 b=Path(path).read_bytes();need(hashlib.sha256(b).hexdigest()==PINS[key],'Pinned bytes mismatch:'+key);return b

def cycle(t):return min(tuple(t),tuple(t[1:]+t[:1]),tuple(t[2:]+t[:2]))
def ear_key(side,p):return'ear:'+str(side)+':'+':'.join(float(x).hex()for x in p)
def directed_edge(t,a,b):return any(x==a and y==b for x,y in zip(t,t[1:]+t[:1]))
def semantic_match(positions,allowed,source_position):
 ids=np.asarray(list(allowed),int);dd=np.linalg.norm(positions[ids].astype(float)-np.asarray(source_position),axis=1);hits=ids[dd<=MATCH];need(len(hits)==1,'Missing/ambiguous vertex WITHIN pinned semantic head range');return int(hits[0])

class Model:
 def __init__(self,raw):
  self.d,self.b=parse(raw);self.views={};self.start={};self.total=0;self.mesh_by_base={}
  for mi,m in enumerate(self.d['meshes']):
   base=m['primitives'][0]['material'];need(m['name']=='skinned_'+self.d['materials'][base]['name'],'Unexpected authored mesh semantic name');need(base not in self.mesh_by_base,'Repeated semantic material mesh');self.mesh_by_base[base]=mi
   for pi,p in enumerate(m['primitives']):
    attrs={k:read(self.d,self.b,i)for k,i in p['attributes'].items()};need(set(attrs)==set(ATTRS),'Unknown skin attribute set');idx=read(self.d,self.b,p['indices']).ravel().reshape(-1,3);need(idx.min()>=0 and idx.max()<len(attrs['POSITION']),'Active index bounds');self.start[mi,pi]=self.total;self.total+=len(idx);self.views[mi,pi]={'triangle_lookup':{},'attributes':attrs,'indices':idx,'material':p['material'],'base_material':base,'mesh_name':m['name'],'attributes_accessors':p['attributes']}
  for key,v in self.views.items():
   for fi,t in enumerate(v['indices']):v['triangle_lookup'].setdefault(cycle(list(map(int,t))),[]).append(fi)
  self.active_vertices={mi:set(int(i)for key,v in self.views.items()if key[0]==mi for i in v['indices'].ravel())for mi in range(len(self.d['meshes']))}
 def global_face(self,key,local):return self.start[key]+int(local)
 def descriptor(self,g):
  for key,v in self.views.items():
   start=self.start[key]
   if start<=g<start+len(v['indices']):return{'mesh':key[0],'primitive':key[1],'primitive_triangle':g-start,'primitive_vertices':v['indices'][g-start].tolist(),'material':v['material'],'mesh_name':v['mesh_name']}
  raise ValueError('Global active triangle out of bounds')

def frozen_baseline(raw,producer,head,ears):
 model=Model(raw);labels={};head_faces={};sourceowners={};ranges={}
 for mat,mi in model.mesh_by_base.items():
  rs=[r for r in producer['vertex_ranges']if r['joint']=='head'and r['material']==mat]
  if not rs:continue
  need(len(rs)==1,'Ambiguous frozen semantic head group');r=rs[0];ranges[mi]=range(r['vertex_start'],r['vertex_start']+r['vertex_count'])
  for key,v in model.views.items():
   if key[0]==mi:need(v['attributes_accessors']==model.views[mi,0]['attributes_accessors'],'Material split must share original actual attributes')
 cache={}
 def locate(mi,pos):
  key=(mi,tuple(pos))
  if key not in cache:cache[key]=semantic_match(model.views[mi,0]['attributes']['POSITION'],ranges[mi],np.asarray(pos)+ORIGIN)
  return cache[key]
 def label(mi,i,name):
  old=labels.setdefault((mi,i),name);need(old==name,'Conflicting actual source vertex ownership')
 def sourceface(mi,material,vertexids,names,owner):
  for i,name in zip(vertexids,names):label(mi,i,name)
  matches=[]
  for key,v in model.views.items():
   if key[0]!=mi or v['material']!=material:continue
   for fi in v['triangle_lookup'].get(cycle(vertexids),[]):matches.append((key,fi))
  need(len(matches)==1,'Missing/duplicate oriented active source triangle');key,fi=matches[0];g=model.global_face(key,fi);need(g not in head_faces,'Duplicate source face claim');head_faces[g]=True;sourceowners[g]=owner
 for fi,(face,tag)in enumerate(zip(head['faces'],head['tags'])):
  if tag=='skin'or tag.startswith('skin:'):base,material=0,0
  elif tag.startswith('eye_'):base,material=3,3
  elif tag.startswith('nostril_'):base,material=1,1
  elif tag.startswith('lip_'):base,material=1,0
  else:raise ValueError('Unknown frozen head source owner')
  mi=model.mesh_by_base[base];ids=[locate(mi,head['positions'][i])for i in face];sourceface(mi,material,ids,['h:'+str(i)for i in face],{'kind':'baseline_head','source_head_face':fi,'tag':tag})
 for e in ears:
  side=-1 if e['name'].endswith('_-1')else 1;mi=model.mesh_by_base[e['material']]
  for fi,face in enumerate(e['faces']):
   ids=[locate(mi,e['positions_local'][i])for i in face];sourceface(mi,e['material'],ids,[ear_key(side,e['positions_local'][i])for i in face],{'kind':'baseline_ear','component':e['name'],'source_face':fi})
 need(len(head_faces)==3008,'Frozen active baseline full head+ear cohort must be3008')
 # Explicit old neckportal pairs, NEVER a global duplicate-coordinate match.
 join=producer['join_trial']['records'];need(len(join['neck']['interface'])==len(join['head']['interface'])==24,'Portal pair contract');mi=model.mesh_by_base[0];attrs=model.views[mi,0]['attributes']
 for i,(neck,cranial)in enumerate(zip(join['neck']['interface'],join['head']['interface'])):
  need(labels[(mi,cranial)]=='h:'+str(i),'Pinned head portal mapping')
  for k in ATTRS:need(np.array_equal(attrs[k][neck],attrs[k][cranial]),'Actual neckportal seam field mismatch:'+k)
  label(mi,neck,'h:'+str(i))
 return model,labels,set(head_faces),sourceowners

def candidate_from_maps(raw,old,oldlabels,oldhead,oldowners,proof,source):
 model=Model(raw);need(model.total==11452,'Current actual active triangle count');labels=dict(oldlabels);heads=set();owners={};maps={(r['mesh'],r['primitive']):r for r in proof['actual_primitive_remaps']};reverse_old={}
 for key,v in old.views.items():
  if key in maps:
   r=maps[key];mapping={q['old']:q['new']for q in r['old_to_new_retained_triangles']};need(len(mapping)==len(r['old_to_new_retained_triangles']),'Duplicate primitive remap');retired=set(r['retired_old_triangles']);need(set(mapping)|retired==set(range(len(v['indices'])))and not(set(mapping)&retired),'Incomplete active ownership map')
  else:mapping={i:i for i in range(len(v['indices']))}
  for oi,ni in mapping.items():
   need(np.array_equal(v['indices'][oi],model.views[key]['indices'][ni]),'Actual retained index triple changed');og=old.global_face(key,oi);ng=model.global_face(key,ni);reverse_old[ng]=og
   if og in oldhead:heads.add(ng);owners[ng]=oldowners[og]
 for seam in proof['cut_and_ring_seam_records']:
  for q in seam['owners']:
   mi=model.mesh_by_base[q['material']];name=seam['source_id'];oldname=labels.get((mi,q['vertex']))
   need(oldname is None or oldname==name or(name.startswith('earring:')and oldname.startswith('ear:')),'Undeclared current source ownership override');labels[mi,q['vertex']]=name
 for q in proof['new_vertex_source_owners']:
  mi=model.mesh_by_base[q['material']];oldname=labels.setdefault((mi,q['active_vertex']),q['source_id']);need(oldname==q['source_id'],'Conflicting appended vertex owner')
 for key,r in maps.items():
  for i,owner in enumerate(r['new_face_source_owners']):
   local=r['new_faces_start']+i;t=model.views[key]['indices'][local];names=[labels[(key[0],int(j))]for j in t];expected=source['new_faces'][owner['source_new_face']];need(cycle(names)==cycle(expected),'Actual appended triangle/source ownership mismatch');g=model.global_face(key,local);need(g not in heads,'Duplicate active new face');heads.add(g);owners[g]=owner
 need(len(heads)==2960,'Current active source-mapped head+ears must be2960');return model,labels,heads,owners,reverse_old

def triangle_labels(model,labels):
 records=[]
 for key,v in model.views.items():
  for t in v['indices']:records.append([labels.get((key[0],int(i)),'body:'+str(key[0])+':'+str(int(i)))for i in t])
 need(len(records)==model.total,'Current active label table count');return records

def verify_source_seams(model,labels):
 groups={}
 for(mi,vi),name in labels.items():
  if vi not in model.active_vertices[mi]:continue
  # Read primary attribute arrays; split primitives share the exact accessors.
  a=model.views[mi,0]['attributes'];need(vi<len(a['POSITION']),'Source owner outside active accessor');field={k:a[k][vi]for k in ATTRS};groups.setdefault(name,[]).append(field)
 for name,fields in groups.items():
  for f in fields[1:]:
   for k in(['POSITION','NORMAL','JOINTS_0','WEIGHTS_0']if name.startswith('h:')and int(name[2:])<24 else['POSITION','JOINTS_0','WEIGHTS_0']):need(np.array_equal(fields[0][k],f[k]),'Actual source alias fields differ:'+name+':'+k)
 return groups
