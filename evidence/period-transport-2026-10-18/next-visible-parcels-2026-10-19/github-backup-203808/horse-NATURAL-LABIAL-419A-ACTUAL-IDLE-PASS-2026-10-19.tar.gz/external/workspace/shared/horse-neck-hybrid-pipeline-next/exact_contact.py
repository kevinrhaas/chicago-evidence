# SPDX-License-Identifier: GPL-3.0-or-later
"""Exact dyadic certificates for ONE declared shared source vertex only.
A certificate proves intersection={the actual common vertex}; it never excuses
unowned edge/coplanar overlap or relies on a distance/SAT tolerance.
"""
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return(a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def negate(a):return tuple(-x for x in a)
def lattice(points):
 ratios=[[float(x).as_integer_ratio()for x in p]for p in points];exponent=max(d.bit_length()-1 for p in ratios for _,d in p)
 values=[tuple(n<<(exponent-(d.bit_length()-1))for n,d in p)for p in ratios];return values,exponent

def ray_inside_cone(r,u,v):
 """Exact nonnegative span membership in a nondegenerate triangular plane."""
 n=cross(u,v)
 if dot(n,r)!=0:return False
 k=max(range(3),key=lambda i:abs(n[i]))
 if n[k]==0:raise ValueError('Degenerate exact cone')
 i,j=[q for q in range(3)if q!=k];den=u[i]*v[j]-u[j]*v[i];a=r[i]*v[j]-r[j]*v[i];b=u[i]*r[j]-u[j]*r[i]
 return a*den>=0 and b*den>=0

def source_vertex_only(a,b,ia,ib):
 """ia/ib identify the SAME owned vertex. Return a proof or None (FAIL).
 All coordinates must be actual captured dyadic world values. No tolerance.
 """
 if tuple(map(float,a[ia]))!=tuple(map(float,b[ib])):return None
 coords,exponent=lattice(list(a)+list(b));A=coords[:3];B=coords[3:];p=A[ia];aa=[sub(q,p)for i,q in enumerate(A)if i!=ia];bb=[sub(q,p)for i,q in enumerate(B)if i!=ib];na=cross(*aa);nb=cross(*bb)
 if na==(0,0,0)or nb==(0,0,0):return None
 ae=[*aa,sub(aa[1],aa[0])];be=[*bb,sub(bb[1],bb[0])];axes=[na,nb]+[cross(u,v)for u in ae for v in be]+[cross(n,e)for n in[na,nb]for e in ae+be];seen=set()
 for axis in axes:
  if axis==(0,0,0):continue
  for axis in[axis,negate(axis)]:
   if axis in seen:continue
   seen.add(axis);pa=[dot(axis,v)for v in aa];pb=[dot(axis,v)for v in bb]
   if min(pa)<0 or max(pb)>0:continue
   za=[v for v,q in zip(aa,pa)if q==0];zb=[v for v,q in zip(bb,pb)if q==0];reason=None
   if not za or not zb:reason='separating plane; one zero feature is only the shared point'
   elif len(za)==len(zb)==1:
    if cross(za[0],zb[0])!=(0,0,0)or dot(za[0],zb[0])<=0:reason='zero-feature rays have no common positive ray'
   elif len(za)==1 and len(zb)==2:
    if not ray_inside_cone(za[0],*zb):reason='zero ray outside opposing exact triangular cone'
   elif len(za)==2 and len(zb)==1:
    if not ray_inside_cone(zb[0],*za):reason='opposing zero ray outside exact triangular cone'
   if reason:return{'kind':'EXACT_owned_source_vertex_only','point_world':list(map(float,a[ia])),'integer_lattice_binary_exponent':exponent,'separating_axis_integer':list(axis),'a_edge_signed_projections':pa,'b_edge_signed_projections':pb,'zero_feature_reason':reason,'tolerance_used':False}
 return None

def source_edge_only(a,b,source_a,source_b):
 """Actual geometry certificate for a registered opposite source edge.
 Source orientation alone NEVER waives coplanar foldover.
 """
 shared=set(source_a)&set(source_b)
 if len(shared)!=2:return None
 edge=next(((x,y)for x,y in zip(source_a,source_a[1:]+source_a[:1])if x in shared and y in shared),None)
 if edge is None:return None
 if not any(x==edge[1]and y==edge[0]for x,y in zip(source_b,source_b[1:]+source_b[:1])):return None
 ia,ja=source_a.index(edge[0]),source_a.index(edge[1]);ib,jb=source_b.index(edge[0]),source_b.index(edge[1])
 if tuple(map(float,a[ia]))!=tuple(map(float,b[ib]))or tuple(map(float,a[ja]))!=tuple(map(float,b[jb])):return None
 coords,exponent=lattice(list(a)+list(b));A=coords[:3];B=coords[3:];p,q=A[ia],A[ja];u=sub(q,p);va=sub(A[next(i for i in range(3)if i not in[ia,ja])],p);vb=sub(B[next(i for i in range(3)if i not in[ib,jb])],p);na=cross(u,va);nb=cross(u,vb)
 if na==(0,0,0)or nb==(0,0,0):return None
 triple=dot(na,vb);half=dot(na,nb)
 if triple!=0:case='distinct_actual_planes_intersect_only_at_owned_edge_line'
 elif half<0:case='exactly_coplanar_third_vertices_on_opposite_actual_edge_halfplanes'
 else:return None
 return{'kind':'EXACT_owned_source_edge_only','source_edge':list(edge),'edge_world':[list(map(float,a[ia])),list(map(float,a[ja]))],'integer_lattice_binary_exponent':exponent,'scalar_triple_integer':triple,'normal_dot_integer':half,'case':case,'tolerance_used':False}
