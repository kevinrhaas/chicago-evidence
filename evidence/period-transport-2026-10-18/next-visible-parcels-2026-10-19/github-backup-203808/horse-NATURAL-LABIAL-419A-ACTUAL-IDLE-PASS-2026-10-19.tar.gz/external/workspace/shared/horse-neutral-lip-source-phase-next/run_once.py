# SPDX-License-Identifier: CC0-1.0
"""ONE fixed sculpt vector recipe, finite phases, firstnonzero STOP. No search/retry."""
from pathlib import Path
import json,hashlib,subprocess,sys,time,os,signal
P=Path(__file__).parent;start=time.monotonic()
def run():
 if sys.argv[1:]!=['ROOT_RELEASE_ONE_NEUTRAL_LIP_QUALITY']:raise ValueError('Independentreview androotexistingauthority required')
 # Exclusive ownership acquired outside failure writers: never modify earlier evidence.
 with(P/'operator-receipt.json').open('x')as f:f.write('{}\n')
 r={'PASS':False,'status':'UNACCEPTED firstneutral/lipqualitycandidate','total_bound_s':150,'stages':[],'recipe':'fixed source-owned neutral U lip slit; no sweep','browser/63poses/app':'NOT AUTHORIZED bythisoperator'}
 def save():r['elapsed_s']=time.monotonic()-start;(P/'operator-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
 try:
  for manifest in['SOURCE-HASHES.json','EXTERNAL-HASHES.json']:
   pins=json.loads((P/manifest).read_text());r[manifest]=pins;save()
   for name,h in pins.items():
    path=P/name if manifest=='SOURCE-HASHES.json'else Path(name)
    if hashlib.sha256(path.read_bytes()).hexdigest()!=h:raise ValueError('Frozenpin:'+name)
  commands=[('generate',[sys.executable,str(P/'lip_variant.py'),str(P/'candidate-one')],30),('independent_source_readback',[sys.executable,str(P/'checked_lip.py')],30),('Khronos',['node',str(P/'khronos.cjs')],15),('actual_binary64_idle_capture',['node','--loader',str(P/'idle-fit/three-loader.mjs'),str(P/'idle-fit/capture_idle.mjs')],20),('fullhead_neck_mane_structural',[sys.executable,str(P/'check_lip_idle.py')],75),('all36gear_vsALLhorse',[sys.executable,str(P/'idle-fit/check_idle.py')],90),('actual_bit_volume',[sys.executable,str(P/'check_actual_bit_volume.py')],30)]
  for name,cmd,cap in commands:
   remaining=min(cap,150-(time.monotonic()-start))
   if remaining<=0:raise TimeoutError('150second totaldeadline')
   with(P/(name+'.stdout')).open('xb')as stdout,(P/(name+'.stderr')).open('xb')as stderr:
    child=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,start_new_session=True)
    try:code=child.wait(timeout=remaining)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait();code=124
   r['stages'].append({'name':name,'exit':code,'elapsed_s':time.monotonic()-start});save()
   if code:raise RuntimeError('FIRSTFAILURE '+name+' exit '+str(code))
  r['PASS']=True;r['status']='Boundedqualitycandidate/idleONLY; anatomy/visual/63poses/photo OPEN'
 except BaseException as e:r['error']=repr(e)
 finally:save()
 return0=0 if r['PASS']else 2
 return return0
if __name__=='__main__':raise SystemExit(run())
