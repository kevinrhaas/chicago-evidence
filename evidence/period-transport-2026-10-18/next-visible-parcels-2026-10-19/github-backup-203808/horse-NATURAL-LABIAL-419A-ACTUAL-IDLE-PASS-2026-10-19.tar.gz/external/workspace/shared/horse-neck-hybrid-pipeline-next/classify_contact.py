# SPDX-License-Identifier: GPL-3.0-or-later
from exact_contact import source_vertex_only

def classify_raw(a,b,source_a,source_b,proper_witness):
 # Caller must run the unchanged proper predicate BEFORE this dispatch.
 if proper_witness is not None:return{'kind':'unexpected_strict_proper','proper_witness':proper_witness}
 shared=set(source_a)&set(source_b)
 if len(shared)!=1:return{'kind':'unexpected_raw_SAT','reason':'No unique registered source vertex; unowned edge/coplanar contact cannot be excused'}
 name=next(iter(shared));ia=source_a.index(name);ib=source_b.index(name);proof=source_vertex_only(a,b,ia,ib)
 if proof is None:return{'kind':'unexpected_raw_SAT','reason':'Registered point exists but no exact vertex-only intersection certificate','source_vertex':name}
 return{'kind':'proven_source_vertex_only','source_vertex':name,'proof':proof}
