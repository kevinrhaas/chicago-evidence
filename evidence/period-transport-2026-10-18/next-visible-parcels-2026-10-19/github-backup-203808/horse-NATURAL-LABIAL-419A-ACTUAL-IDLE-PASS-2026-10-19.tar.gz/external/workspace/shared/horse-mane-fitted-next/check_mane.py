# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import hashlib,json
from mane_source import HYBRID
from mane_chain import load
from ownership import triangle_labels,PINS
from check_idle import load_capture,world_aliases,scan,write
from hybrid_geometry import SEAM
from hybrid_scope import patch_ownership,check_patch
from source_edges import owned_adjacency
from check_threeway import PARENT_NEGATIVE_SHA,source_signature,require_parent_negative
from baseline_negatives import verify_negative_cohort
from sparse_rules import require
from exclusive_output import with_exclusive_output
import official_fit_predicates as predicates
from mane_scope import ownership,check

def owned(packet,packet_sha,capture,out):
 v=load(packet,packet_sha);rows={};datas={};adjs={};metas=[]
 for name in['baseline','ear_parent','neck_candidate']:
  m,labels,head,owners=v[name];rows[name]=triangle_labels(m,labels);x,y,t=owned_adjacency(rows[name],head,m.total,3 if name=='baseline'else 1,5 if name=='baseline'else 1,boundary_loop=['h:'+str(h)for h in SEAM]if name=='neck_candidate'else None);adjs[name]=[('head_internal',x),('head_vs_all_rest',y)];sha=PINS['baseline']if name=='baseline'else PINS['candidate']if name=='ear_parent'else v['neck_sha256'];meta,data,_=load_capture(capture,name,m,sha);world_aliases(rows[name],data);metas.append(meta);datas[name]=data
 require(all(m['pose']==metas[0]['pose']and m['root_world']==metas[0]['root_world']and m['head_world']==metas[0]['head_world']for m in metas),'Exactsameidleframe');m,labels,head,owners=v['neck_candidate'];patch_ownership(m,rows['neck_candidate'],v['proof']);ownership(m,rows['neck_candidate'],v['mane_proof']);predicates.predicate_controls()
 prior=Path('/workspace/shared/horse-ear-root-first-idle-binary64-trial/results/candidate-head_vs_all_rest.json').read_bytes();require(hashlib.sha256(prior).hexdigest()==PARENT_NEGATIVE_SHA and any(source_signature(w)for w in json.loads(prior)['unexpected_witnesses']),'Frozen260negativeprovenance')
 for name in['baseline','ear_parent','neck_candidate']:
  mm,ll,hh,oo=v[name];scopes=[]
  for scope,edges in adjs[name]:
   r=scan(name,scope,mm,rows[name],hh,datas[name],edges,out,name=='neck_candidate');scopes.append(r)
   if name=='neck_candidate'and(r['counts']['unexpected_SAT']or r['counts']['strict_proper']):write(out/'RESULT.json',{'pass':False,'status':'FIRST head failure STOP'});return False
  if name=='baseline':
   r=verify_negative_cohort(scopes,Path('/workspace/shared/horse-ear-root-idle-checker-f64-unique-next/provenance'));write(out/'baseline-known12.json',r);require(r['complete'],'Known12negativeincomplete')
  elif name=='ear_parent':write(out/'parent-necknegative.json',require_parent_negative(scopes))
 if not check_patch(m,rows['neck_candidate'],datas['neck_candidate'],out,v['proof'])[0]:write(out/'RESULT.json',{'pass':False,'status':'FIRST neckpatch failure STOP'});return False
 if not check(m,rows['neck_candidate'],datas['neck_candidate'],out,v['mane_proof']):write(out/'RESULT.json',{'pass':False,'status':'FIRST fittedmane failure STOP'});return False
 write(out/'RESULT.json',{'pass':True,'status':'DISCRETEidleONLY; anatomy/groom/gear/63poses/photoUNACCEPTED'});return True

def once(packet,packet_sha,capture,out):
 out=Path(out);return with_exclusive_output(out,lambda:owned(Path(packet),packet_sha,Path(capture),out))
