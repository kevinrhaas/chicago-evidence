# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import copy,hashlib,json
import numpy as np
from mane_source import parent_context,roots,shape,recipe,HYBRID,PACKET_SHA,PARENT_SHA
from ownership import Model,ATTRS,PINS
from glb_data import append,encode
from sparse_rules import require
from mane_storage import storage_audit

def old_cohort(model):
 v=model.views[1,0];idx=v['indices'];require(v['material']==1 and v['mesh_name']=='skinned_equine_mane_tail','Actualmixedmaterialowner');selected=np.flatnonzero(np.all(idx<122,axis=1));require(len(selected)==240,'Exactly240sourceownedmane');require(not np.any(np.any(idx<122,axis=1)!=np.all(idx<122,axis=1)),'No cross-range triangles');return selected

def export_once(checkpoint=None):
 c=parent_context();m=c['neck_candidate'][0];raw=(Path('/workspace/shared/horse-neck-hybrid-first-local-trial/payload/candidate.glb')).read_bytes();require(hashlib.sha256(raw).hexdigest()==PARENT_SHA,'Actual192GLB');rr=roots(c);pp,jj,ww,ff=shape(rr);a=m.views[1,0]['attributes'];n=len(a['POSITION']);retired=old_cohort(m);idx=m.views[1,0]['indices'];keep=[i for i in range(len(idx))if i not in set(retired)];fresh=ff+n;newidx=np.vstack([idx[keep],fresh]).astype('<u4');require(not np.isin(newidx,range(122)).any(),'Oldmaneallinactive');arrays={k:np.vstack([a[k],x]).astype(a[k].dtype)for k,x in[('POSITION',pp),('JOINTS_0',jj),('WEIGHTS_0',ww)]};p=arrays['POSITION'];tri=p[fresh].astype(float);area=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);require(np.isfinite(area).all()and np.all(np.linalg.norm(area,axis=1)>2e-12),'Newmanearea finite/nondegenerate');acc=np.zeros_like(pp,dtype=float)
 for k in range(3):np.add.at(acc,ff[:,k],area)
 length=np.linalg.norm(acc,axis=1);require(np.all(length>1e-12),'Newmane normals');arrays['NORMAL']=np.vstack([a['NORMAL'],acc/length[:,None]]).astype('<f4');d=copy.deepcopy(m.d);blob=bytearray(m.b);prim=d['meshes'][1]['primitives'][0]
 for k in ATTRS:prim['attributes'][k]=append(d,blob,arrays[k],'VEC3'if k in['POSITION','NORMAL']else'VEC4',5123 if k=='JOINTS_0'else 5126)
 prim['indices']=append(d,blob,newidx.reshape(-1,1),'SCALAR',5125,target=34963);candidate=encode(d,blob)
 if checkpoint:checkpoint(candidate)
 proof={'status':'UNACCEPTED reconstructedshortcrest ONLY','parent_sha256':PARENT_SHA,'parent_packet_sha256':PACKET_SHA,'output_sha256':hashlib.sha256(candidate).hexdigest(),'source_recipe':recipe(),'actual_source_roots':rr,'old_mane_vertex_count':n,'retired_old_material1_faces':retired.tolist(),'retained_old_to_new':[{'old':i,'new':j}for j,i in enumerate(keep)],'new_mane_indices':fresh.tolist()}
 proof['independent_rest']=audit_rest(raw,candidate,proof,c);return candidate,proof

def audit_rest(oldbytes,newbytes,proof,context):
 import math
 old,new=Model(oldbytes),Model(newbytes);require(old.total==12800 and new.total==13016,'Actualtrianglecount');require(proof['parent_sha256']==PARENT_SHA and proof['parent_packet_sha256']==PACKET_SHA and proof['source_recipe']==recipe(),'Exactnewauthority');require(proof['output_sha256']==hashlib.sha256(newbytes).hexdigest(),'Actualoutputhash');require(set(old.views)==set(new.views),'Allprimitiveowners');oldroots=roots(context);require(proof['actual_source_roots']==oldroots,'Actualroots/incidentIDs/rawJW');n=len(old.views[1,0]['attributes']['POSITION']);require(proof['old_mane_vertex_count']==n,'Oldmaterial1count')
 for key,v in old.views.items():
  u=new.views[key];require(v['material']==u['material']and v['mesh_name']==u['mesh_name'],'Materialowner exact')
  for k in ATTRS:
   x,y=v['attributes'][k],u['attributes'][k];require(x.dtype==y.dtype,'Dtypeexact')
   if key==(1,0):require(y.shape==(n+230,x.shape[1])and y[:n].tobytes()==x.tobytes(),'ALLold mixedmaterialattribute bytes exact')
   else:require(x.tobytes()==y.tobytes()and v['attributes_accessors']==u['attributes_accessors'],'Othercoat/head/bodyattrs exact')
  if key!=(1,0):require(np.array_equal(v['indices'],u['indices']),'Otherindicesexact')
 retired=old_cohort(old).tolist();require(proof['retired_old_material1_faces']==retired,'Actualretiredmaneonly');keep=[i for i in range(len(old.views[1,0]['indices']))if i not in set(retired)];idx=new.views[1,0]['indices'];require(np.array_equal(idx[:len(keep)],old.views[1,0]['indices'][keep]),'Tail/darkheadindices exact');require(proof['retained_old_to_new']==[{'old':i,'new':j}for j,i in enumerate(keep)],'Exactretainedmap');require(not np.isin(idx,range(122)).any(),'Oldmaneinactive')
 # Independent explicit section formula; no invocation of shape().
 expected=[];ej=[];ew=[]
 for k,r in enumerate(oldroots):
  a=min(1.,k/2,(18-k)/2);h=.002+(.025-.002)*a;w=.0015+(.006-.0015)*a
  for q in range(12):
   t=2*math.pi*q/12;expected.append([r['position'][c]+r['normal'][c]*(.001+h/2+h/2*math.sin(t))+r['lateral_tangent'][c]*(w*math.cos(t))for c in range(3)]);ej.append(r['J']);ew.append(r['W'])
 for k in[0,18]:r=oldroots[k];expected.append([r['position'][c]+r['normal'][c]*.002 for c in range(3)]);ej.append(r['J']);ew.append(r['W'])
 a=new.views[1,0]['attributes'];require(np.array_equal(a['POSITION'][n:],np.array(expected,dtype='<f4')),'IntendednewPexact');require(np.array_equal(a['JOINTS_0'][n:],np.array(ej,dtype='<u2'))and np.array_equal(a['WEIGHTS_0'][n:],np.array(ew,dtype='<f4')),'Actualsource rootJWcopied');fresh=np.array(proof['new_mane_indices']);require(fresh.shape==(456,3)and np.array_equal(idx[len(keep):],fresh)and fresh.min()==n and fresh.max()==n+229,'Actualnew456indexproof')
 # Independent ordered19x12 sourcechart including the two caps.
 expectedfaces=[]
 for j in range(18):
  for q in range(12):x=j*12+q;y=j*12+(q+1)%12;expectedfaces.extend([(x,y,y+12),(x,y+12,x+12)])
 for j in[0,18]:
  for q in range(12):expectedfaces.append((228+(j==18),(q+1)%12,q)if j==0 else(229,j*12+q,j*12+(q+1)%12))
 ep=np.array(expected,dtype='<f4');ef=np.array(expectedfaces,dtype='<u4');volume=sum(np.dot(ep[x].astype(float),np.cross(ep[y].astype(float),ep[z].astype(float)))for x,y,z in ef)/6
 require(abs(volume)>1e-12,'Independentnonzerovolume')
 if volume<0:ef=ef[:,[0,2,1]]
 require(np.array_equal(fresh,ef+n),'Exactordered456sourcechart')
 # Independent closed orientable component topology and actual normals.
 uses={};vertices=set()
 for f in fresh:
  vertices.update(map(int,f))
  for x,y in zip(f,list(f[1:])+[f[0]]):uses.setdefault(tuple(sorted([int(x),int(y)])),[]).append((int(x),int(y)))
 require(len(vertices)==230 and len(vertices)-len(uses)+456==2 and all(len(u)==2 and u[0]==u[1][::-1]for u in uses.values()),'ClosedmaneEuler2oppositeowners')
 p=a['POSITION'].astype(float);t=p[fresh];areas=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);require(np.all(np.linalg.norm(areas,axis=1)>2e-12),'Nondenegenerateactualmane');acc=np.zeros((230,3))
 for k in range(3):np.add.at(acc,fresh[:,k]-n,areas)
 length=np.linalg.norm(acc,axis=1);require(np.all(length>1e-12),'Actualnormalareas');require(np.max(np.linalg.norm(a['NORMAL'][n:]-acc/length[:,None],axis=1))<=1e-6,'Actualnewnormalsengineeringcheck');storage=storage_audit(old,new)
 return {'status':'REST ONLY UNACCEPTED','alloldattrs_exact':True,'tail_darkfeatures_otherindices_exact':True,'new_rootP_JW_exact':True,'closedmane_Euler':2,'new_vertices':230,'new_faces':456,'storage':storage}
