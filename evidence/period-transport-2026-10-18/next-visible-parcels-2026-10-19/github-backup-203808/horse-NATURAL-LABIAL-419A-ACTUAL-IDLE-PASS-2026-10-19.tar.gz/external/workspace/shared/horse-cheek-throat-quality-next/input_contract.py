# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import sys,json,hashlib,collections
import numpy as np
BASE=Path('/workspace/shared/horse-combined-oral-neck-mane-prefix-next');PACKET_SHA='a1cf5716f230298841e565fbe3660b7df5a1f1d9a26ee432dc20816f605fcaee';GLB_SHA='ab70aff958bc8a2780458d37212be1866c730817f485fbebbf53bd3c0e3931c3';PROOF_SHA='3ac3719d5cbaf065f8396aeeeda823687bbb0778ebcd86e4b0561459908eb6cf';SOURCE=Path('/workspace/shared/horse-oral-channel-diagonal-candidate/candidate-one/head-source-surface.json');SOURCE_SHA='11db17528eb564b8c65999cd38cb5968ee35503d4e79673b84b0d5e7cf3f20b2'
sys.path.insert(0,str(BASE));from check_graft import checked
from sparse_rules import require

def pinned(p,h):
 raw=Path(p).read_bytes();require(hashlib.sha256(raw).hexdigest()==h,'Frozeninput:'+str(p));return raw

def context():
 packet=json.loads(pinned(BASE/'candidate-one/packet.json',PACKET_SHA))
 for name,row in packet['files'].items():
  require(row['path']in['candidate.glb','graft-proof.json','manifest.json','authority.json']and(BASE/'candidate-one'/row['path']).resolve().parent==(BASE/'candidate-one').resolve(),'Canonicalparentpayload');pinned(BASE/'candidate-one'/row['path'],row['sha256'])
 pinned(BASE/'candidate-one/graft-proof.json',PROOF_SHA);pinned(BASE/'candidate-one/candidate.glb',GLB_SHA);source=json.loads(pinned(SOURCE,SOURCE_SHA));m,labels,head,owners,scopes,raw=checked();require(m.total==13226 and len(head)==3122,'Qualifiedcombinedsourcecohorts');v=m.views[0,0];require(v['material']==0 and v['mesh_name']=='skinned_equine_coat','Declaredcoatowner');nodes=[x for x in m.d['nodes']if x.get('name')=='head'];require(len(nodes)==1 and nodes[0].get('translation')==[0,1.88,.8]and nodes[0].get('rotation',[0,0,0,1])==[0,0,0,1],'Existingrestheadframe')
 # All protected feature and oral/ear owner faces, in ALL actual materials.
 protect_labels=set();protected_faces=set();eligible_labels=set();active=set(map(int,v['indices'].ravel()));keylabels={i:labels.get((0,i),'body:0:'+str(i))for i in active}
 for g,row in owners.items():
  protected=row.get('kind')in['oral_channel','baseline_ear','skull_complement','radial_bridge']or(row.get('kind')=='baseline_head'and row.get('tag')!='skin')
  desc=m.descriptor(g);mi=desc['mesh'];ids=desc['primitive_vertices'];tags=[labels.get((mi,i),'body:'+str(mi)+':'+str(i))for i in ids]
  if protected:protect_labels.update(tags);protected_faces.add(g)
  elif row.get('kind')in['baseline_head','hybrid_neck']:eligible_labels.update(tags)
 # Cross-material aliases remain exact, including lip-coat primitive1:1.
 for key,view in m.views.items():
  if key==(0,0):continue
  protect_labels.update(labels.get((key[0],i),'body:'+str(key[0])+':'+str(i))for i in set(map(int,view['indices'].ravel())))
 graph={tag:set()for tag in keylabels.values()}
 for f in v['indices']:
  tags=[keylabels[int(i)]for i in f];require(len(set(tags))==3,'Nondegeneratecanonicalsourceface')
  for a,b in zip(tags,tags[1:]+tags[:1]):graph[a].add(b);graph[b].add(a)
 distance={tag:0 for tag in protect_labels if tag in graph};todo=collections.deque(distance)
 while todo:
  a=todo.popleft()
  if distance[a]>=3:continue
  for b in graph[a]:
   if b not in distance:distance[b]=distance[a]+1;todo.append(b)
 groups={}
 for i,tag in keylabels.items():groups.setdefault(tag,[]).append(i)
 for tag,ids in groups.items():
  for attr in['POSITION','JOINTS_0','WEIGHTS_0']:require(all(v['attributes'][attr][i].tobytes()==v['attributes'][attr][ids[0]].tobytes()for i in ids),'SourcealiasexactP/JW')
 return{'model':m,'raw':raw,'labels':labels,'keylabels':keylabels,'head':head,'owners':owners,'scopes':scopes,'protected_labels':protect_labels,'protected_faces':protected_faces,'eligible_labels':eligible_labels,'distance':distance,'groups':groups,'source':source}
