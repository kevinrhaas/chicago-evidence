# SPDX-License-Identifier: GPL-3.0-or-later
"""Synthetic indices/GLB bytecontrols only; NEVER horse input."""
import unittest,copy
from types import SimpleNamespace
import numpy as np
from local_patch import recipe,propose_indices
from patch_scope import patch_ownership
from glb_data import append,encode,parse
from topology_rest import audit_rest
class Controls(unittest.TestCase):
 def test_patched12_complete_vsrest_ownership(self):
  old=[]
  for j in range(6,10):
   for k in range(24):
    a=j*24+k;b=j*24+(k+1)%24;old.extend([(a,b,b+24),(a,b+24,a+24)])
  new,proof=propose_indices(old);label=lambda i:'h:'+str(i-216)if 216<=i<240 else'body:0:'+str(i)
  records=[[label(i)for i in f]for f in new];model=SimpleNamespace(views={(0,0):{'indices':np.array(new)}},start={(0,0):0});selected,internal,external=patch_ownership(model,records);self.assertEqual(len(selected),12);self.assertEqual(len(external),14);self.assertEqual(len(internal),11)
 def fixture(self):
  d={'asset':{'version':'2.0'},'buffers':[{'byteLength':0,'name':'original'}],'bufferViews':[],'accessors':[],'materials':[{'name':'equine_coat'}],'meshes':[],'nodes':[{'name':'protected_rig_sentinel'}]};b=bytearray()
  attrs={k:append(d,b,a,typ,comp)for k,a,typ,comp in[('POSITION',np.arange(241*3,dtype='f4').reshape(-1,3),'VEC3',5126),('NORMAL',np.tile([0.,1.,0.],(241,1)),'VEC3',5126),('JOINTS_0',np.zeros((241,4),dtype='u2'),'VEC4',5123),('WEIGHTS_0',np.tile([1.,0.,0.,0.],(241,1)),'VEC4',5126)]}
  old=recipe()['old_faces']+[(0,1,2)]*(11452-12);ref=append(d,b,np.array(old).reshape(-1,1),'SCALAR',5125,target=34963);d['meshes']=[{'name':'skinned_equine_coat','primitives':[{'attributes':attrs,'indices':ref,'material':0}]}];raw=encode(d,b);doc,blob=parse(raw);new,proof=propose_indices(old);doc['meshes'][0]['primitives'][0]['indices']=append(doc,blob,np.array(new).reshape(-1,1),'SCALAR',5125,target=34963);return raw,doc,blob,proof
 def test_independent_rest_synthetic_bytes(self):
  raw,d,b,p=self.fixture();report=audit_rest(raw,encode(d,b),p);self.assertTrue(report['all_attributes_byte_exact'])
 def test_protected_node_mutation_refuses(self):
  raw,d,b,p=self.fixture();d['nodes'][0]['name']='mutated'
  with self.assertRaises(ValueError):audit_rest(raw,encode(d,b),p)
 def test_changed_unrelated_index_refuses(self):
  raw,d,b,p=self.fixture();a=d['accessors'][d['meshes'][0]['primitives'][0]['indices']];v=d['bufferViews'][a['bufferView']];b[v['byteOffset']]=9
  with self.assertRaises(ValueError):audit_rest(raw,encode(d,b),p)
 def test_attribute_byte_mutation_refuses(self):
  raw,d,b,p=self.fixture();a=d['accessors'][d['meshes'][0]['primitives'][0]['attributes']['NORMAL']];v=d['bufferViews'][a['bufferView']];b[v['byteOffset']]=1
  with self.assertRaises(ValueError):audit_rest(raw,encode(d,b),p)
if __name__=='__main__':unittest.main()
