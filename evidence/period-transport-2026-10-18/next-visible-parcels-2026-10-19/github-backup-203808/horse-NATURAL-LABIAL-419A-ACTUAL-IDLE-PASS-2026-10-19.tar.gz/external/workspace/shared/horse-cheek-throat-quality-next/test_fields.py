# SPDX-License-Identifier: CC0-1.0
import unittest,math
from quality_field import bump,boundary_fade,displacement,recipe
class FieldTests(unittest.TestCase):
 def test_support_C2(self):
  self.assertEqual(bump(0,0,1),0);self.assertEqual(bump(1,0,1),0);self.assertEqual(bump(.5,0,1),1)
  for h in[1e-3,1e-4]:self.assertLess(abs(bump(h,0,1)/h),.001);self.assertLess(abs(bump(h,0,1)/h**2),.065)
 def test_symmetry_and_bounds(self):
  a=displacement([.1,1.72,.95],'h:100',1);b=displacement([-.1,1.72,.95],'h:101',1);self.assertEqual(a[0],-b[0]);self.assertEqual(a[1:],b[1:]);self.assertLessEqual(abs(a[0]),.012);self.assertLessEqual(abs(a[1]),.015)
 def test_protected_refused_to_move(self):
  self.assertEqual(displacement([.1,1.72,.95],'h:100',0),[0,0,0]);self.assertEqual(displacement([.1,1.72,.95],'h:100',1,False),[0,0,0])
 def test_neck_crest_stays_exact(self):
  a=displacement([0,1.98,.72],'hybrid:8:12',1);self.assertEqual(a,[0.,0.,0.])
 def test_neck_throat_direction(self):
  # Column36 is phase3/4 in the explicit24/28 union.
  a=displacement([0,1.7,.85],'hybrid:9:36',1);self.assertLess(a[2],0);self.assertGreaterEqual(a[2],-.02)
 def test_source_bounds_refused(self):
  with self.assertRaises(ValueError):displacement([0,1.7,.85],'hybrid:99:0',1)
 def test_fade(self):
  self.assertEqual(boundary_fade(0),0);self.assertEqual(boundary_fade(3),1);self.assertLess(boundary_fade(1),boundary_fade(2))
if __name__=='__main__':unittest.main()
