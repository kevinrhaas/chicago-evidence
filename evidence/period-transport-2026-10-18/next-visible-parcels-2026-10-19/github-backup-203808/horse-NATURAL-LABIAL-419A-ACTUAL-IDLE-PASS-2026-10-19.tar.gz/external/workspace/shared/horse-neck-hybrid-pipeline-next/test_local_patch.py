# SPDX-License-Identifier: GPL-3.0-or-later
import unittest,copy
from local_patch import *
class Controls(unittest.TestCase):
 def test_boundary_and_chart(self):self.assertEqual(validate_recipe(recipe())['boundary_edges'],14)
 def test_exact_sparse_replacement(self):
  old=[(800,801,802)]+recipe()['old_faces']+[(900,901,902)];saved=copy.deepcopy(old);new,p=propose_indices(old);self.assertEqual(old,saved);self.assertEqual(len(new),len(old));self.assertEqual(new[:2],[(800,801,802),(900,901,902)]);self.assertEqual(p['unchanged_old_to_new'],[{'old':0,'new':0},{'old':13,'new':1}])
 def test_missing_ownedface_refuses(self):
  with self.assertRaises(ValueError):propose_indices(recipe()['old_faces'][:-1])
 def test_duplicate_ownedface_refuses(self):
  with self.assertRaises(ValueError):propose_indices(recipe()['old_faces']+[recipe()['old_faces'][0]])
 def test_changed_boundary_refuses(self):
  r=recipe();r['new_faces'][0]=(999,208,231)
  with self.assertRaises(ValueError):validate_recipe(r)
 def test_changed_winding_refuses(self):
  r=recipe();r['new_faces'][0]=tuple(reversed(r['new_faces'][0]))
  with self.assertRaises(ValueError):validate_recipe(r)
if __name__=='__main__':unittest.main()
