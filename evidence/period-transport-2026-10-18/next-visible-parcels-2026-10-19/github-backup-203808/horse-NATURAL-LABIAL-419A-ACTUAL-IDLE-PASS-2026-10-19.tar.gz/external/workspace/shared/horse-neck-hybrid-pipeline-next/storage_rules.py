# SPDX-License-Identifier: CC0-1.0
import copy,hashlib
from sparse_rules import require

def verify_storage(old,oldbin,new,newbin,pos_ref,normal_ref):
 oa=len(old['accessors']);ov=len(old['bufferViews'])
 refs=new['meshes'][0]['primitives'][0]['attributes']
 require(refs.get('POSITION')==pos_ref and refs.get('NORMAL')==normal_ref,'Actual reloaded primitive refs differ from intended refs')
 require(len(new['accessors'])==oa+2 and len(new['bufferViews'])==ov+2,'Exactly two appended storage records required')
 require(new['accessors'][:oa]==old['accessors'],'Original accessor metadata changed')
 require(new['bufferViews'][:ov]==old['bufferViews'],'Original view metadata changed')
 require(bytes(newbin[:len(oldbin)])==bytes(oldbin),'Original BIN prefix changed')
 require(pos_ref==oa and normal_ref==oa+1,'Only declared ordered accessor replacements permitted')
 for i in range(2):
  a=new['accessors'][oa+i];v=new['bufferViews'][ov+i]
  require(a['bufferView']==ov+i and a['componentType']==5126 and a['type']=='VEC3','Unexpected appended attribute storage')
  require(v['buffer']==0 and v['target']==34962 and v['byteOffset']>=len(oldbin),'Appended view must follow protected BIN')
  require(v['byteLength']==a['count']*12,'Appended view extent')
  require(set(a)=={'bufferView','componentType','count','type','min','max'}and set(v)=={'buffer','byteOffset','byteLength','target'},'Unexpected new storage fields')
  require(v['byteOffset']%4==0,'Append alignment')
 v0,v1=new['bufferViews'][-2:];require(v1['byteOffset']==v0['byteOffset']+v0['byteLength'],'Unexpected gap/overlap in appended views')
 end=v1['byteOffset']+v1['byteLength'];require(new['buffers'][0]['byteLength']==end and len(newbin)==end,'Exact appended BIN extent')
 buffers=copy.deepcopy(new['buffers']);buffers[0]['byteLength']=old['buffers'][0]['byteLength'];require(buffers==old['buffers'],'Original buffer metadata changed')
 a=copy.deepcopy(old);b=copy.deepcopy(new)
 for d in[a,b]:
  for k in['POSITION','NORMAL']:d['meshes'][0]['primitives'][0]['attributes'].pop(k)
  for k in['accessors','bufferViews','buffers']:d.pop(k)
 require(a==b,'Document changed beyond exact two accessor refs/storage append')
 return{'original_accessors_exact':oa,'original_views_exact':ov,'old_BIN_prefix_bytes':len(oldbin),'old_BIN_sha256':hashlib.sha256(oldbin).hexdigest(),'only_two_ordered_refs_replaced':True,'original_buffer_metadata_exact_except_byteLength':True}
