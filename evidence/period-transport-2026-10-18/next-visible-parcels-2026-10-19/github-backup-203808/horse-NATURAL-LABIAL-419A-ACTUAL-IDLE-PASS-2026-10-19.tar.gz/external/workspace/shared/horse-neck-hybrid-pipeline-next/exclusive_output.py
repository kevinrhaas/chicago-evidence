# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import json,traceback

def with_exclusive_output(output,operation):
 out=Path(output)
 # Atomic claim OUTSIDE exception handler. Existing directory/symlink/race refuses
 # without ever entering code allowed to write a failure receipt.
 out.mkdir(parents=True,exist_ok=False)
 try:return operation()
 except BaseException as error:
  (out/'FIRST-FAILURE.json').write_text(json.dumps({'status':'FIRST FAILURE STOP; owned fresh output only','error':str(error),'traceback':traceback.format_exc()},indent=2)+'\n')
  raise
