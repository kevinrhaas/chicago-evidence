# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import sys,json,hashlib
from mane_source import parent_context,recipe,PACKET_SHA,PARENT_SHA,HYBRID
from mane_export import export_once,audit_rest
from source_inventory import helper_inventory,inventory_sha

def enc(x):return(json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def stage(which,out):
 out=Path(out)
 if which=='export':
  q=out/'export';q.mkdir();raw,proof=export_once(lambda b:(q/'UNVALIDATED-candidate.glb').write_bytes(b));(q/'candidate.glb').write_bytes(raw);(q/'mane-proof.json').write_bytes(enc(proof))
 elif which=='metadata':
  q=out/'payload';q.mkdir();raw=(out/'export/candidate.glb').read_bytes();pr=(out/'export/mane-proof.json').read_bytes();proof=json.loads(pr);c=parent_context();parent=Path('/workspace/shared/horse-neck-hybrid-first-local-trial/payload/candidate.glb').read_bytes();audit_rest(parent,raw,proof,c);inv=helper_inventory(Path(__file__).parent);ih=inventory_sha(inv);manifest={'status':'UNACCEPTED','glb_sha256':sha(raw),'parent_sha256':PARENT_SHA,'parent_packet_sha256':PACKET_SHA,'proof_sha256':sha(pr),'source_recipe':recipe(),'helper_inventory':inv,'helper_inventory_sha256':ih,'not_run':['collision','63poses','gear','visual/anatomy/photo']};mr=enc(manifest);authority=enc({'status':'UNACCEPTED','glb_sha256':sha(raw),'manifest_sha256':sha(mr),'parent_packet_sha256':PACKET_SHA,'helper_inventory':inv,'helper_inventory_sha256':ih});contents={'candidate.glb':raw,'mane-proof.json':pr,'manifest.json':mr,'authority.json':authority}
  for n,b in contents.items():
   with(q/n).open('xb')as f:f.write(b)
   if(q/n).read_bytes()!=b:raise ValueError('Actualbytecopy')
  packet={'status':'UNACCEPTED','parent_sha256':PARENT_SHA,'parent_packet_sha256':PACKET_SHA,'helper_inventory':inv,'helper_inventory_sha256':ih,'files':{k:{'path':n,'sha256':sha(contents[n])}for k,n in[('glb','candidate.glb'),('proof','mane-proof.json'),('manifest','manifest.json'),('authority','authority.json')]}}
  (q/'packet.json').write_bytes(enc(packet))
 elif which=='rest':
  from mane_chain import load
  p=out/'payload/packet.json';v=load(p,sha(p.read_bytes()));(out/'independent-rest.json').write_bytes(enc(v['rest']))
 else:raise ValueError('Unknownstage')
if __name__=='__main__':stage(*sys.argv[1:])
