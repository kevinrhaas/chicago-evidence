# SPDX-License-Identifier: CC0-1.0
import unittest
import numpy as np
from graft import require_prefix_attributes,ATTRS
class PrefixGuard(unittest.TestCase):
 def rows(self,n):return{k:np.arange(n*(3 if k in['POSITION','NORMAL']else 4),dtype='<u2'if k=='JOINTS_0'else'<f4').reshape(n,-1)for k in ATTRS}
 def test_exact_shorter_prefix(self):require_prefix_attributes(self.rows(5),self.rows(3))
 def test_one_changed_component_refused(self):
  a,b=self.rows(5),self.rows(3);b['NORMAL'][1,0]+=1
  with self.assertRaises(ValueError):require_prefix_attributes(a,b)
 def test_signed_zero_difference_refused(self):
  a,b=self.rows(5),self.rows(3);a['POSITION'][0,0]=0.;b['POSITION'][0,0]=-0.
  with self.assertRaises(ValueError):require_prefix_attributes(a,b)
 def test_larger_or_incoherent_or_dtype_refused(self):
  for mutate in ['larger','incoherent','dtype']:
   a,b=self.rows(5),self.rows(3)
   if mutate=='larger':b=self.rows(6)
   if mutate=='incoherent':b['POSITION']=b['POSITION'][:2]
   if mutate=='dtype':b['JOINTS_0']=b['JOINTS_0'].astype('<u4')
   with self.assertRaises(ValueError):require_prefix_attributes(a,b)
if __name__=='__main__':unittest.main()
