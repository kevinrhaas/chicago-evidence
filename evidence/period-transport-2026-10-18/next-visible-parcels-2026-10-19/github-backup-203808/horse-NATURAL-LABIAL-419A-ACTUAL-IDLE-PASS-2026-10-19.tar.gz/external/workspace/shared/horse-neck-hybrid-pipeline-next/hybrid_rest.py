# SPDX-License-Identifier: GPL-3.0-or-later
import hashlib
import numpy as np
from ownership import Model,ATTRS
from sparse_rules import require
from smooth_rules import storage_audit,resolve_palette
from hybrid_geometry import recipe,SEAM,PHASES,zipper
from hybrid_reference import reference

def expected_faces(n,mapping):
 from fractions import Fraction as F
 rows=[list(range(168,192))]+[list(range(n+j*48,n+(j+1)*48))for j in range(15)]+[[mapping[h]for h in SEAM]]
 phases=[tuple(F(i,24)for i in range(24))]+[PHASES]*15+[tuple(F(i,28)for i in range(28))]
 return [f for a,pa,b,pb in zip(rows,phases,rows[1:],phases[1:])for f in zipper(a,pa,b,pb)]

def audit_rest(parent_bytes,new_bytes,proof,context):
 old=Model(parent_bytes);new=Model(new_bytes);require(old.total==11452 and new.total==12800,'Exacttrianglecounts');require(set(old.views)==set(new.views),'Allprimitiveowners')
 require(proof['source_recipe']==recipe(),'Exacthybridauthority');oa=old.views[0,0]['attributes'];na=new.views[0,0]['attributes'];n=len(oa['POSITION']);root,head,names=resolve_palette(old)
 require(proof['parent_coat_vertex_count']==n and proof['actual_skin_palette']=={'root':root,'head':head,'names':names},'Actualsourcepalette/count')
 for key,v in old.views.items():
  w=new.views[key];require(v['material']==w['material']and v['mesh_name']==w['mesh_name'],'Primitiveowner exact')
  if key!=(0,0):
   require(v['attributes_accessors']==w['attributes_accessors']and np.array_equal(v['indices'],w['indices']),'Otherindices/accessorrefs exact')
   for k in ATTRS:require(v['attributes'][k].tobytes()==w['attributes'][k].tobytes(),'Otherattribute exact')
 for k in ATTRS:require(na[k].dtype==oa[k].dtype and na[k].shape==(n+720,oa[k].shape[1])and na[k][:n].tobytes()==oa[k].tobytes(),'ALLoldattribute bytes exact:'+k)
 ip=proof['index_proof'];retired=set(context['neckret'])|{g-old.start[0,0]for g in context['headret']};require(len(retired)==144 and ip['retired_old_active_faces']==sorted(retired),'Exact96+48 retirement')
 require(ip['head_retired_old_global_faces']==sorted(context['headret'])and ip['head_retired_source_faces']==recipe()['head_retired_source_faces']and ip['neck_retired_source_faces']==list(range(336,432))and ip['neck_retired_old_active_faces']==context['neckret'],'Sourceowned retirement receipt')
 keep=[i for i in range(len(old.views[0,0]['indices']))if i not in retired];idx=new.views[0,0]['indices'];expected=expected_faces(n,context['mapping']);require(np.array_equal(idx[:len(keep)],old.views[0,0]['indices'][keep])and idx[len(keep):].tolist()==[list(f)for f in expected],'Actualretained/newindex exact');require(ip['unchanged_old_to_new']==[{'old':i,'new':j}for j,i in enumerate(keep)],'Retainedsource map')
 require(proof['newpatch_indices']==[list(f)for f in expected]and ip['new_vertex_keys']==[f'hybrid:{j}:{k}'for j in range(15)for k in range(48)],'New1492indices/720keys')
 require(not np.isin(idx,np.arange(192,240)).any(),'OldneckO/Q inactive')
 for h in list(range(13,24))+list(range(37,48)):require(not np.isin(idx,context['mapping'][h]).any(),'Oldlowerhead sourceinactive')
 ep,ew=reference(oa['POSITION'][144:168],oa['POSITION'][168:192],context['HP'],context['HW'],recipe());require(np.array_equal(na['POSITION'][n:],ep),'IndependentBernstein rationalP');require(np.array_equal(na['WEIGHTS_0'][n:],ew)and np.array_equal(na['JOINTS_0'][n:],np.tile([root,head,root,root],(720,1))),'Independentnewskin')
 require(proof['head_anchor_skin']==context['head_anchor_skin']and proof['actual_head_source_mapping']=={str(h):i for h,i in context['mapping'].items()},'Actualsourceanchors')
 p=na['POSITION'].astype(float);tri=p[idx];area=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);require(np.isfinite(area).all()and np.all(np.linalg.norm(area,axis=1)>2e-12),'Finite/nondegenerateallcoat')
 acc=np.zeros_like(p)
 for k in range(3):np.add.at(acc,idx[:,k],area)
 lengths=np.linalg.norm(acc[n:],axis=1);require(np.all(lengths>1e-12),'Newnormalarea');delta=np.linalg.norm(na['NORMAL'][n:].astype(float)-acc[n:]/lengths[:,None],axis=1);require(np.all(delta<=1e-6),'Newnormal alignment ONLY; SAT unchanged')
 storage=storage_audit(old,new)
 return {'status':'REST ONLY; UNACCEPTED geometry/appearance','all_old_attribute_bytes_exact':True,'old_normal_changes':[],'retired_neck_faces':96,'retired_lowerhead_faces':48,'new_vertices':720,'new_faces':1492,'new_P_W_independent_Bernstein_exact':True,'normal_alignment_max_delta':float(delta.max()),'storage':storage,'output_sha256':hashlib.sha256(new_bytes).hexdigest()}
