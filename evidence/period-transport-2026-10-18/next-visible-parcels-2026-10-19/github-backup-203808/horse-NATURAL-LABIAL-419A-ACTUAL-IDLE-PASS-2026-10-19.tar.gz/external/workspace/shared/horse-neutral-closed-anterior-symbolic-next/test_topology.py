# SPDX-License-Identifier: CC0-1.0
"""Pure symbolic manifold refusal controls; no horse XYZ."""
import copy,json
from pathlib import Path
from assemble import build,edges
from topology_guard import manifold
r=build();T=r['triangles'];boundary={e for e,rows in edges(T).items()if len(rows)==1};manifold(T,boundary,-1)
def reject(label,faces,bd=boundary,euler=-1):
 try:manifold(faces,bd,euler)
 except (AssertionError,ValueError,KeyError):return{'name':label,'PASS':True}
 raise RuntimeError('Did not reject '+label)
cases=[reject('missing triangle',T[:-1]),reject('duplicate triangle',T+[T[0]]),reject('flipped triangle',[T[0][::-1]]+T[1:]),reject('wrong intended Euler',T,euler=1),reject('undeclared boundary',T,bd=set()),reject('degenerate source face',T+[[T[0][0]]*3]),reject('disconnected second component',T+[['x','y','z']])]
print(json.dumps({'PASS':True,'normal_and_optimized_guards_active':True,'controls':cases,'scope':'Symbolic topology only, no P/XYZ/physical proof'}))
