# SPDX-License-Identifier: GPL-3.0-or-later
"""UNEXECUTED one explicit12index replacement; no attribute writes."""
from pathlib import Path
import json,hashlib,copy
import numpy as np
from ownership import PINS,Model,frozen_baseline,candidate_from_maps,verify_source_seams
from glb_data import append,encode
from sparse_rules import require
from local_patch import propose_indices,recipe,validate_recipe
PARENT_AUTHORITY='3a95abf8e9f8d3e9d5180b1c988f4334ea00f88824d4131308c22ee22d2c1f4a'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pinned(p,key):
 raw=Path(p).read_bytes();require(sha(raw)==PINS[key],'Pinned source mismatch:'+key);return raw

def parent_chain(base,ear,source):
 raw=pinned(ear/'equine_ear_root_candidate.glb','candidate');producer=json.loads(pinned(base/'manifest.json','producer090'));head=json.loads(pinned(base/'head-source-surface.json','head'));ears=json.loads(pinned(base/'ear-source-surfaces.json','ears'))
 old,ol,oh,oo=frozen_baseline(pinned(base/'equine_light_harness_skinned_prototype_01.glb','baseline'),producer,head,ears)
 proof=json.loads(pinned(ear/'export-local-proof.json','proof'));pinned(ear/'manifest.json','producer260');edit=json.loads(pinned(source,'source_candidate'));require(sha((ear/'authority.json').read_bytes())==PARENT_AUTHORITY,'Parent authority')
 m,l,h,o,_=candidate_from_maps(raw,old,ol,oh,oo,proof,edit);verify_source_seams(m,l);require(m.total==11452 and len(h)==2960,'Parent exact active scope')
 return raw,m,l,h,o,(old,ol,oh,oo)

def export_once(base,ear,source,checkpoint=None):
 raw,m,labels,head,owners,_=parent_chain(Path(base),Path(ear),Path(source));validate_recipe(recipe())
 v=m.views[0,0];require(v['material']==0 and v['mesh_name']=='skinned_equine_coat','Source neck owner')
 idx,proof=propose_indices(v['indices'].tolist());d=copy.deepcopy(m.d);blob=bytearray(m.b);d['meshes'][0]['primitives'][0]['indices']=append(d,blob,np.asarray(idx,dtype='<u4').reshape(-1,1),'SCALAR',5125,target=34963)
 candidate=encode(d,blob)
 if checkpoint:checkpoint(candidate)
 from topology_rest import audit_rest
 rest=audit_rest(raw,candidate,proof)
 return candidate,{'status':'UNACCEPTED local topologyexport ONLY','input_pins':PINS,'parent_authority_sha256':PARENT_AUTHORITY,'output_sha256':sha(candidate),'topology_recipe':recipe(),'index_proof':proof,'rest_readback':rest,'all_collision_gear_visual':'NOT RUN'}
