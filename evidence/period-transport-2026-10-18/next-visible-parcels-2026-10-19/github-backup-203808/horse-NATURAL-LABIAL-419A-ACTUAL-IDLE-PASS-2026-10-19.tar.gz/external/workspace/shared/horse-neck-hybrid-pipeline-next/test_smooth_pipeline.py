# SPDX-License-Identifier: GPL-3.0-or-later
"""Entirely artificial cylinder GLBbytes in memory, NO horse IO."""
import unittest,copy,hashlib
from pathlib import Path
import numpy as np
from glb_data import append,encode,parse
from ownership import Model,PINS,ATTRS,triangle_labels
from smooth_neck_patch import build_proposal,recipe
from smooth_rules import source_faces
from smooth_rest import audit_rest
from smooth_scope import patch_ownership
class Controls(unittest.TestCase):
 def fixture(self):
  n=1100;pos=np.zeros((n,3),dtype='<f4')
  for j in range(10):
   for k in range(24):pos[j*24+k]=[np.cos(k*np.pi/12),j/10,np.sin(k*np.pi/12)]
  pos[1049:1073]=pos[216:240]+np.array([0,.1,0],dtype='<f4');norm=np.tile([0.,1.,0.],(n,1)).astype('<f4');joints=np.tile([0,1,0,0],(n,1)).astype('<u2');weights=np.tile([1.,0.,0.,0.],(n,1)).astype('<f4');weights[216:240]=[.5,.5,0,0];weights[1049:1073]=[.2,.8,0,0]
  d={'asset':{'version':'2.0'},'buffers':[{'byteLength':0}],'bufferViews':[],'accessors':[],'materials':[{'name':'equine_coat'}],'meshes':[],'skins':[{'joints':[0,1]}],'nodes':[{'name':'root'},{'name':'head'},{'name':'coat','mesh':0,'skin':0}]};b=bytearray();a={'POSITION':pos,'NORMAL':norm,'JOINTS_0':joints,'WEIGHTS_0':weights};refs={k:append(d,b,v,'VEC3'if k in['POSITION','NORMAL']else'VEC4',5123 if k=='JOINTS_0'else 5126)for k,v in a.items()};extra=[]
  for k in range(24):
   j=(k+1)%24;extra.extend([(144+k,144+j,168+j),(144+k,168+j,168+k),(216+k,216+j,1049+j),(216+k,1049+j,1049+k)])
  idx=np.array(source_faces()+extra+[(0,1,2)]*(11452-192),dtype='<u4');iref=append(d,b,idx.reshape(-1,1),'SCALAR',5125,target=34963);d['meshes']=[{'name':'skinned_equine_coat','primitives':[{'attributes':refs,'indices':iref,'material':0}]}];parent=encode(d,b)
  s=build_proposal(pos[144:168].astype(float),pos[168:192].astype(float),pos[216:240].astype(float),pos[1049:1073].astype(float));keys=list(s['new_positions']);keymap={key:n+i for i,key in enumerate(keys)}
  def actual(k):return int(k[2:])if k.startswith('B:')else 216+int(k[3:])if k.startswith('Q:h')else keymap[k]
  faces=np.array([[actual(k)for k in f]for f in s['faces']],dtype='<u4');newidx=np.vstack([idx[96:],faces]);newpos=np.vstack([pos,np.array([s['new_positions'][k]for k in keys],dtype='<f4')]);newn=np.vstack([norm,np.zeros((360,3),dtype='<f4')]);newj=np.vstack([joints,np.tile([0,1,0,0],(360,1))]).astype('<u2');neww=np.vstack([weights,np.array([[s['new_weights'][k]['root'],s['new_weights'][k]['head'],0,0]for k in keys],dtype='<f4')]);tri=newpos[newidx].astype(float);area=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);acc=np.zeros_like(newpos,dtype=float)
  for k in range(3):np.add.at(acc,newidx[:,k],area)
  halo=list(range(168,192))+list(range(n,n+360));newn[halo]=(acc[halo]/np.linalg.norm(acc[halo],axis=1)[:,None]).astype('<f4');doc,blob=parse(parent);prim=doc['meshes'][0]['primitives'][0]
  for k,v in[('POSITION',newpos),('NORMAL',newn),('JOINTS_0',newj),('WEIGHTS_0',neww)]:prim['attributes'][k]=append(doc,blob,v,'VEC3'if k in['POSITION','NORMAL']else'VEC4',5123 if k=='JOINTS_0'else 5126)
  prim['indices']=append(doc,blob,newidx.reshape(-1,1),'SCALAR',5125,target=34963);proof={'parent_coat_vertex_count':n,'actual_skin_palette':{'root':0,'head':1,'names':['root','head']},'source_recipe':recipe(),'anchor_skin_contract_sha256':hashlib.sha256(Path(__file__).with_name('anchor-skin-contract.json').read_bytes()).hexdigest(),'actual_anchor_skin_hashes':{k:hashlib.sha256(a[k][list(range(144,192))+list(range(216,240))+list(range(1049,1073))].tobytes()).hexdigest()for k in['JOINTS_0','WEIGHTS_0']},'index_proof':{'retired_old_active_faces':list(range(96)),'new_face_count':768,'new_vertex_keys':[f'new:{j}:{k}'for j in range(15)for k in range(24)],'retired_source_faces':list(range(336,432)),'unchanged_old_to_new':[{'old':i,'new':i-96}for i in range(96,11452)]},'newpatch_indices':faces.tolist()}
  return parent,doc,blob,proof
 def test_full768_patch_scope(self):
  old,d,b,p=self.fixture();m=Model(encode(d,b));labels={(0,216+k):'h:'+str(k)for k in range(24)};labels.update({(0,1049+k):'h:'+str(24+k)for k in range(24)});labels.update({(0,1100+j*24+k):f'smooth:{j}:{k}'for j in range(15)for k in range(24)});r=triangle_labels(m,labels);selected,internal,external=patch_ownership(m,r,p);self.assertEqual(len(selected),768);self.assertEqual(len(internal),1128);self.assertEqual(len(external),48)
 def test_independent_rational_rest(self):
  old,d,b,p=self.fixture();r=audit_rest(old,encode(d,b),p);self.assertTrue(r['newP_rational_Hermite_exact'])
 def test_protected_oldP_mutation_refuses(self):
  old,d,b,p=self.fixture();v=d['bufferViews'][d['accessors'][d['meshes'][0]['primitives'][0]['attributes']['POSITION']]['bufferView']];b[v['byteOffset']]=9
  with self.assertRaises(ValueError):audit_rest(old,encode(d,b),p)
 def test_old_headnormal_mutation_refuses(self):
  old,d,b,p=self.fixture();v=d['bufferViews'][d['accessors'][d['meshes'][0]['primitives'][0]['attributes']['NORMAL']]['bufferView']];b[v['byteOffset']+1049*12]=1
  with self.assertRaises(ValueError):audit_rest(old,encode(d,b),p)
 def test_newP_wrong_recipe_refuses(self):
  old,d,b,p=self.fixture();v=d['bufferViews'][d['accessors'][d['meshes'][0]['primitives'][0]['attributes']['POSITION']]['bufferView']];b[v['byteOffset']+1100*12]=17
  with self.assertRaises(ValueError):audit_rest(old,encode(d,b),p)
if __name__=='__main__':unittest.main()
