# SPDX-License-Identifier: CC0-1.0
import unittest
import numpy as np
from mane_source import shape,recipe
class Synthetic(unittest.TestCase):
 def rows(self):return[{'position':[0.,1.,i*.1],'normal':[0.,1.,0.],'lateral_tangent':[1.,0.,0.],'J':[0,1,0,0],'W':[1.,0.,0.,0.]}for i in range(19)]
 def check(self,p,f):
  self.assertEqual(p.shape,(230,3));self.assertEqual(f.shape,(456,3));edges={}
  for tri in f:
   self.assertEqual(len(set(map(int,tri))),3)
   for a,b in zip(tri,list(tri[1:])+[tri[0]]):edges.setdefault(tuple(sorted([int(a),int(b)])),[]).append((int(a),int(b)))
  self.assertEqual(230-len(edges)+456,2)
  for u in edges.values():self.assertTrue(len(u)==2 and u[0]==u[1][::-1])
  t=p[f].astype(float);self.assertTrue(np.all(np.linalg.norm(np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]),axis=1)>2e-12))
 def test_closed_sourcechart(self):
  p,j,w,f=shape(self.rows());self.check(p,f);self.assertTrue(np.array_equal(j,np.tile([0,1,0,0],(230,1))));self.assertTrue(np.array_equal(w,np.tile([1.,0,0,0],(230,1))))
 def test_missing_face_refused(self):
  p,j,w,f=shape(self.rows())
  with self.assertRaises(AssertionError):self.check(p,f[:-1])
 def test_folded_winding_refused(self):
  p,j,w,f=shape(self.rows());f[20]=f[20][::-1]
  with self.assertRaises(AssertionError):self.check(p,f)
 def test_explicit_small_gap(self):
  p,j,w,f=shape(self.rows());self.assertAlmostEqual(float(p[9,1])-1.,.001,places=6)
if __name__=='__main__':unittest.main()
