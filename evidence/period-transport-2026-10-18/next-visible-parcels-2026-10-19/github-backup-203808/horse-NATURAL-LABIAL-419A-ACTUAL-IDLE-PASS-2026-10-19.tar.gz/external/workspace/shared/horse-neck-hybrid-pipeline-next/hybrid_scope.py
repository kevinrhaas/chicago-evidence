# SPDX-License-Identifier: GPL-3.0-or-later
from collections import defaultdict
from sparse_rules import require
from check_idle import scan,write
from hybrid_geometry import SEAM
from hybrid_rest import expected_faces

def patch_ownership(model,records,proof):
 count=proof['parent_coat_vertex_count'];start=len(model.views[0,0]['indices'])-1492;selected=set(range(model.start[0,0]+start,model.start[0,0]+start+1492));mapping={int(h):i for h,i in proof['actual_head_source_mapping'].items()};expected=expected_faces(count,mapping)
 require(model.views[0,0]['indices'][start:].tolist()==[list(f)for f in expected]and proof['newpatch_indices']==[list(f)for f in expected],'Fullactual1492sourcefaceownership')
 uses=defaultdict(list);vertices=set();graph=defaultdict(set)
 for g in selected:
  t=records[g];vertices.update(t)
  for a,b in zip(t,t[1:]+t[:1]):uses[tuple(sorted([a,b]))].append((g,a,b));graph[a].add(b);graph[b].add(a)
 expectedboundary=set()
 for ring in[[f'body:0:{i}'for i in range(168,192)],['h:'+str(h)for h in SEAM]]:expectedboundary|={tuple(sorted([ring[i],ring[(i+1)%len(ring)]]))for i in range(len(ring))}
 require(len(vertices)==772 and {e for e,u in uses.items()if len(u)==1}==expectedboundary and len(vertices)-len(uses)+1492==0,'Exact772vertex annulus Euler0 two24/28boundaries')
 seen=set();todo=[next(iter(vertices))]
 while todo:
  v=todo.pop()
  if v in seen:continue
  seen.add(v);todo.extend(graph[v]-seen)
 require(seen==vertices,'Singleconnectedpatch')
 alluses=defaultdict(list)
 for g,t in enumerate(records):
  for a,b in zip(t,t[1:]+t[:1]):
   e=tuple(sorted([a,b]))
   if e in uses:alluses[e].append((g,a,b))
 internal=set();external=set()
 for e,u in alluses.items():
  require(len(u)==2 and u[0][1:]==u[1][:0:-1],'Fullactualuniqueoppositeedgeowners')
  pair=tuple(sorted([u[0][0],u[1][0]]));(internal if all(g in selected for g in pair)else external).add(pair)
 require(len(internal)==2212 and len(external)==52,'Exactinternal/external sourceedgecounts')
 return selected,internal,external

def check_patch(model,records,data,out,proof):
 selected,internal,external=patch_ownership(model,records,proof);write(out/'hybrid1492-ownership.json',{'actual_faces':sorted(selected),'topology':'connectedannulus Euler0; 24/28 boundaryloops','source_recipe':proof['source_recipe'],'scope':'ALL1492 internal and vs ALLotheractivehorse triangles; no originalcohort restriction'})
 scopes=[]
 for engine,meaning,edges in[('head_internal','hybrid1492_INTERNAL',internal),('head_vs_all_rest','hybrid1492_vsALLother_active_horse',external)]:
  r=scan('hybrid1492',engine,model,records,selected,data,edges,out,True,declared_scope=meaning);scopes.append(r)
  if r['counts']['unexpected_SAT']or r['counts']['strict_proper']:return False,scopes
 return True,scopes
