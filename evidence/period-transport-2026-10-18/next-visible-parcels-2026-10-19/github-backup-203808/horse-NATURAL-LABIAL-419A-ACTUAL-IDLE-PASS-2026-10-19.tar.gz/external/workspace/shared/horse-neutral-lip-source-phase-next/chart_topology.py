# SPDX-License-Identifier: CC0-1.0
"""Exact dyadic local oral sheets, not one projection across a folded mouth."""
from collections import defaultdict

def require(c,m):
 if not c:raise ValueError(m)
def project(V,ids,chart,uv=None):
 if uv is not None:
  points=[(uv[i][0]+(66 if chart==7 and uv[i][0]<60 else 0),uv[i][1])for i in ids];r=[float(x).as_integer_ratio()for q in points for x in q];den=max(d for _,d in r);return[(r[2*j][0]*(den//r[2*j][1]),r[2*j+1][0]*(den//r[2*j+1][1]))for j in range(len(ids))]
 axes=(0,1)if chart in[2,6]else(1,2);r=[float(V[i][k]).as_integer_ratio()for i in ids for k in axes];den=max(d for _,d in r);return[(r[2*j][0]*(den//r[2*j][1]),r[2*j+1][0]*(den//r[2*j+1][1]))for j in range(len(ids))]
def orient(a,b,c):return(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def simple_polygon(Q):
 n=len(Q)
 def on(a,b,p):return orient(a,b,p)==0 and min(a[0],b[0])<=p[0]<=max(a[0],b[0])and min(a[1],b[1])<=p[1]<=max(a[1],b[1])
 for i in range(n):
  require(Q[i]!=Q[(i+1)%n],'Repeatedlocalpolygonpoint')
  a,b=Q[i],Q[(i+1)%n]
  for j in range(i):
   if j in[(i-1)%n,(i+1)%n]or(i==n-1 and j==0):continue
   c,d=Q[j],Q[(j+1)%n];s=[orient(a,b,c),orient(a,b,d),orient(c,d,a),orient(c,d,b)];cross=(s[0]*s[1]<0 and s[2]*s[3]<0)or on(a,b,c)or on(a,b,d)or on(c,d,a)or on(c,d,b);require(not cross,'Non-simplelocalsourcepolygon')
def triangulate(V,ids,chart,uv=None):
 Q=project(V,ids,chart,uv);simple_polygon(Q);area=sum(a[0]*b[1]-a[1]*b[0]for a,b in zip(Q,Q[1:]+Q[:1]));require(area!=0,'Zerolocalpolygon');sign=1 if area>0 else-1;active=list(range(len(ids)));out=[]
 while len(active)>3:
  found=False
  for k,b in enumerate(active):
   a,c=active[k-1],active[(k+1)%len(active)]
   if orient(Q[a],Q[b],Q[c])*sign<=0:continue
   if any(all(orient(u,v,Q[j])*sign>=0 for u,v in[(Q[a],Q[b]),(Q[b],Q[c]),(Q[c],Q[a])])for j in active if j not in[a,b,c]):continue
   out.append([ids[a],ids[b],ids[c]]);active.pop(k);found=True;break
  require(found,'Noexactconstrainedsourceear')
 require(orient(*(Q[i]for i in active))*sign>0,'Finalzero/invertedsourceear');out.append([ids[i]for i in active]);require(len(out)==len(ids)-2,'Allsourceboundaryknotsretained');return out

def validate_sheets(V,F,owners,uv=None):
 groups=defaultdict(list)
 for i,o in enumerate(owners):groups[o['kind'],o['chart']].append(i)
 checked=0
 for key,faces in groups.items():
  ids=sorted({v for i in faces for v in F[i]});Q=project(V,ids,key[1],uv);lut=dict(zip(ids,Q));tri=[[lut[v]for v in F[i]]for i in faces];areas=[orient(*t)for t in tri];require(all(a>0 for a in areas)or all(a<0 for a in areas),'Consistentlocalsheetwinding')
  require(sum(abs(a)for a in areas)==2*(max(p[0]for p in Q)-min(p[0]for p in Q))*(max(p[1]for p in Q)-min(p[1]for p in Q)),'Completeintrinsicsheetrectanglecoverage')
  for i,A in enumerate(tri):
   for B in tri[:i]:
    checked+=1
    if any(max(p[k]for p in A)<=min(p[k]for p in B)or max(p[k]for p in B)<=min(p[k]for p in A)for k in[0,1]):continue
    separated=False
    for T in[A,B]:
     for u,v in zip(T,T[1:]+T[:1]):
      axis=(v[1]-u[1],u[0]-v[0]);pa=[axis[0]*p[0]+axis[1]*p[1]for p in A];pb=[axis[0]*p[0]+axis[1]*p[1]for p in B]
      if max(pa)<=min(pb)or max(pb)<=min(pa):separated=True;break
     if separated:break
    require(separated,'Unexpectedlocalsheettriangleinterioroverlap')
 return{'exact_dyadic_projected_sheet_pairs':checked,'sheet_groups':len(groups),'source_intrinsic_chart_only':uv is not None,'not_globalXYZproof':True}
