# SPDX-License-Identifier: GPL-3.0-or-later
import hashlib,json
from pathlib import Path
from collections import defaultdict
import numpy as np
from ownership import triangle_labels
from topology_export import parent_chain
from smooth_rules import resolve_palette,source_retirement
from sparse_rules import require
from hybrid_geometry import SEAM,HEAD_RETIRE,inward_terms

def load_parent(base,ear,source):
 contractraw=Path(__file__).with_name('hybrid-seam-contract.json').read_bytes();require(hashlib.sha256(contractraw).hexdigest()=='a59d6b375fbf3cd9b219be1824b009502fc4d349ef07c20a4ac33192808a8feb','Reviewedhybridboundarycontract SHA');contract=json.loads(contractraw)
 raw,m,labels,head,owners,baseline=parent_chain(Path(base),Path(ear),Path(source));root,hjoint,names=resolve_palette(m);require(m.views[0,0]['material']==0,'Actualcoat0owner')
 neckret=source_retirement(m.views[0,0]['indices']);headret={g for g in head if owners[g].get('source_head_face')in HEAD_RETIRE};require(len(headret)==48 and sorted(headret)==contract['retired_head_active_faces'],'Exactlower48headfacecohort');keep=head-headret;records=triangle_labels(m,labels)
 edges=defaultdict(list);verts=set();graph=defaultdict(set)
 for g in keep:
  t=records[g];verts.update(t)
  for a,b in zip(t,t[1:]+t[:1]):edges[tuple(sorted([a,b]))].append((g,a,b));graph[a].add(b);graph[b].add(a)
 expected=[('h:'+str(SEAM[i]),'h:'+str(SEAM[(i+1)%28]))for i in range(28)];require({u[0][1:]for u in edges.values()if len(u)==1}==set(expected),'Exactdirectedhybridheadboundary28')
 require(all(len(u)<=2 and(len(u)==1 or u[0][1:]==u[1][:0:-1])for u in edges.values()),'Uniqueoppositeheadedgeowners');require(len(verts)-len(edges)+len(keep)==1 and len(keep)==2912,'RetainedheadEulerdisk/count')
 seen=set();todo=[next(iter(verts))]
 while todo:
  q=todo.pop()
  if q in seen:continue
  seen.add(q);todo.extend(graph[q]-seen)
 require(seen==verts,'Retainedhead+earsconnected')
 required=set(range(120));mapping={}
 for h in required:
  hits=[i for(key,i),label in labels.items()if key==0 and i>=1025 and label=='h:'+str(h)];require(len(hits)==1,'Explicitheadsourcealias:'+str(h));mapping[h]=hits[0]
 a=m.views[0,0]['attributes'];HP={h:a['POSITION'][i].astype(float).tolist()for h,i in mapping.items()};HW={};records_skin=[]
 for h,i in sorted(mapping.items()):
  sums={}
  for j,w in zip(a['JOINTS_0'][i],a['WEIGHTS_0'][i]):
   if w>0:sums[names[int(j)]]=sums.get(names[int(j)],0)+float(w)
  require(set(sums)<=set(['root','head']),'Headanchors actual semanticbones');HW[h]=[sums.get('root',0),sums.get('head',0)];records_skin.append({'source_head_vertex':h,'actual_vertex':i,'J':a['JOINTS_0'][i].tolist(),'W':a['WEIGHTS_0'][i].tolist()})
 for i in range(168,192):
  sums={}
  for j,w in zip(a['JOINTS_0'][i],a['WEIGHTS_0'][i]):
   if w>0:sums[names[int(j)]]=sums.get(names[int(j)],0)+float(w)
  require(sums=={'root':1.},'FixedBactualrootweight')
 return{'raw':raw,'model':m,'labels':labels,'head':head,'owners':owners,'baseline':baseline,'neckret':neckret,'headret':headret,'kepthead':keep,'mapping':mapping,'HP':HP,'HW':HW,'root':root,'headjoint':hjoint,'palette':names,'head_anchor_skin':records_skin}
