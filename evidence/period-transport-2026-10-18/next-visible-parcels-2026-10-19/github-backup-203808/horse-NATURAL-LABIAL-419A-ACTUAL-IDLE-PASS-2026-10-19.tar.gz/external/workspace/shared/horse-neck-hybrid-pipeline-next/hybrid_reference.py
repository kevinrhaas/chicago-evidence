# SPDX-License-Identifier: CC0-1.0
"""Independent Bernstein evaluation; does not invoke the Hermite producer."""
from fractions import Fraction as F
import numpy as np

def reference(A,B,HP,HW,authority):
 phases=[F(*p)for p in authority['angular_phases_rational']];seam=authority['seam_head_source_vertices'];terms={r['seam_h']:[(k,F(a,b))for k,a,b in r['terms']]for r in authority['inward_source_targets']}
 cast=lambda rows:[tuple(F(float(v))for v in row)for row in rows]
 aa,bb=cast(A),cast(B);hp={k:cast([v])[0]for k,v in HP.items()};hw={k:cast([v])[0]for k,v in HW.items()}
 def sample(rows,s):
  x=s*len(rows);i=x.numerator//x.denominator;u=x-i
  return tuple((1-u)*a+u*b for a,b in zip(rows[i%len(rows)],rows[(i+1)%len(rows)]))
 pp=[];ww=[]
 for j in range(1,16):
  t=F(j,16);coeff=[(1-t)**3,3*t*(1-t)**2,3*t*t*(1-t),t**3]
  for s in phases:
   a,b=sample(aa,s),sample(bb,s);q=sample([hp[h]for h in seam],s)
   d=sample([tuple(sum(w*hp[k][c]for k,w in terms[h])-hp[h][c]for c in range(3))for h in seam],s)
   controls=[b,tuple(b[c]+(b[c]-a[c])/3 for c in range(3)),tuple(q[c]-d[c]/3 for c in range(3)),q]
   pp.append([float(sum(v[c]*w for v,w in zip(controls,coeff)))for c in range(3)])
   q=sample([hw[h]for h in seam],s);d=sample([tuple(sum(w*hw[k][c]for k,w in terms[h])-hw[h][c]for c in range(2))for h in seam],s)
   controls=[(F(1),F(0)),(F(1),F(0)),tuple(q[c]-d[c]/3 for c in range(2)),q]
   ww.append([float(sum(v[c]*w for v,w in zip(controls,coeff)))for c in range(2)]+[0.,0.])
 return np.array(pp,dtype='<f4'),np.array(ww,dtype='<f4')
