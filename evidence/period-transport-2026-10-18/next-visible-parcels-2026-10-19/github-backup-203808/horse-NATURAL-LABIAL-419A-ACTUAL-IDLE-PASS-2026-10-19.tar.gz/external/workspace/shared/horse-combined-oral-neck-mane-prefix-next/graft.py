# SPDX-License-Identifier: GPL-3.0-or-later
"""Reproducible source-owned exact oral triangle delta; no coordinate adjustment."""
from pathlib import Path
import json,copy,hashlib,collections
import numpy as np
from analyze_graft import context,tri_key,counter,PINS,PARENT,ORAL,sha
from ownership import Model,ATTRS,triangle_labels
from glb_data import append,encode
from sparse_rules import require
P=Path(__file__).parent
HEADSOURCE=Path('/workspace/shared/horse-oral-channel-diagonal-candidate/candidate-one/head-source-surface.json')

def sources():
 raw=HEADSOURCE.read_bytes();require(sha(raw)=='11db17528eb564b8c65999cd38cb5968ee35503d4e79673b84b0d5e7cf3f20b2','oral head source pin')
 return json.loads(raw)
def source_lookup(oral):
 s=sources();p=(np.asarray(s['positions'],dtype='<f4').astype(float)+[0,1.88,.8]).astype('<f4');n=np.asarray(s['normals'],dtype='<f4');h=next(i for i,x in enumerate(oral.d['nodes'])if x['name']=='head');j=oral.d['skins'][0]['joints'].index(h);jb=np.array([j,0,0,0],dtype='<u2').tobytes();wb=np.array([1,0,0,0],dtype='<f4').tobytes();out=collections.defaultdict(list)
 for i in range(len(p)):out[p[i].tobytes()+n[i].tobytes()+jb+wb].append(i)
 return s,out


def require_prefix_attributes(primary,other):
 require(set(primary)==set(ATTRS)and set(other)==set(ATTRS),'exactattributecontract')
 lengths={len(primary[k])for k in ATTRS};otherlengths={len(other[k])for k in ATTRS};require(len(lengths)==len(otherlengths)==1,'coherentattributerowcounts')
 for a in ATTRS:
  require(primary[a].dtype==other[a].dtype and primary[a].ndim==other[a].ndim==2 and primary[a].shape[1:]==other[a].shape[1:] and len(other[a])<=len(primary[a]) and primary[a][:len(other[a])].tobytes()==other[a].tobytes(),'actualotherprimitiveattributeisexactprefix:'+a)

def produce(out):
 out=Path(out);require(not out.exists(),'exclusive fresh graft');out.mkdir()
 base,oral,old,c,hits,adds=context();s,lookup=source_lookup(oral);d=copy.deepcopy(old.d);binary=bytearray(old.b);oldlabels=c['neck_candidate'][1];labels=dict(oldlabels);head=c['neck_candidate'][2];owners=c['neck_candidate'][3];retired={(r['mesh'],r['primitive'],r['triangle'])for r in hits};newowners={};newhead=set();ledger=[];additionledger=[];allindices={};appended={};newarrays={};old_to_vertex={}
 for mi in sorted({a['mesh']for a in adds}):
  v=old.views[mi,0]
  for key,x in old.views.items():
   if key[0]==mi:require_prefix_attributes(v['attributes'],x['attributes'])
  newarrays[mi]={a:[x.copy()for x in v['attributes'][a]]for a in ATTRS};appended[mi]={}
 for key,v in old.views.items():
  inds=[]
  for i,f in enumerate(v['indices']):
   if (*key,i)in retired:continue
   ni=len(inds);inds.append(f.tolist());ledger.append({'old_global':old.global_face(key,i),'mesh':key[0],'primitive':key[1],'new_local':ni})
  allindices[key]=inds
 for a in adds:
  key=a['mesh'],a['primitive'];require(key in old.views and old.views[key]['material']==oral.views[key]['material'],'same material primitive ownership');v=oral.views[key];f=v['indices'][a['triangle']];newf=[];sid=[]
  for vi in f:
   vi=int(vi);token=(key[0],vi)
   if token not in old_to_vertex:
    values={k:v['attributes'][k][vi]for k in ATTRS};sig=b''.join(values[k].tobytes()for k in ATTRS);matches=lookup[sig];require(len(matches)==1,'unique authored source vertex identity');sourceid=matches[0];name='h:'+str(sourceid)if sourceid<s['oral_authority']['old_vertices_exact']else'oral:'+str(sourceid)
    ni=len(newarrays[key[0]]['POSITION']);old_to_vertex[token]=(ni,sourceid);labels[key[0],ni]=name
    for k in ATTRS:newarrays[key[0]][k].append(values[k].copy())
    appended[key[0]][str(ni)]={'oral_mesh':key[0],'oral_vertex':vi,'source_vertex':sourceid,'source_label':name}
   ni,sourceid=old_to_vertex[token];newf.append(ni);sid.append(sourceid)
  cycles=lambda q:min(tuple(q[k:]+q[:k])for k in range(3))
  sf=[i for i,f in enumerate(s['faces'])if cycles(f)==cycles(sid)];require(len(sf)==1,'unique source oral face');oi=s['source_owners'][sf[0]];owner={'kind':'oral_channel','oral_generated_face':sf[0],'source_owner':oi}
  local=len(allindices[key]);allindices[key].append(newf);additionledger.append({'oral_global':a['global'],'mesh':key[0],'primitive':key[1],'new_local':local,'source_face':sf[0],'owner':owner})
 for mi,arrays in newarrays.items():
  attrs={k:append(d,binary,arrays[k],'VEC3'if k in['POSITION','NORMAL']else'VEC4',5123 if k=='JOINTS_0'else 5126)for k in ATTRS}
  for pr in d['meshes'][mi]['primitives']:pr['attributes']=dict(attrs)
 for key,indices in allindices.items():
  if any(r['mesh']==key[0]and r['primitive']==key[1]for r in hits+adds):d['meshes'][key[0]]['primitives'][key[1]]['indices']=append(d,binary,indices,'SCALAR',5125,34963)
 raw=encode(d,binary);new=Model(raw)
 for r in ledger:
  ng=new.global_face((r['mesh'],r['primitive']),r['new_local']);r['new_global']=ng;og=r['old_global']
  if og in head:newhead.add(ng)
  if og in owners:newowners[ng]=owners[og]
 for r in additionledger:
  ng=new.global_face((r['mesh'],r['primitive']),r['new_local']);r['new_global']=ng;newhead.add(ng);newowners[ng]=r['owner']
 proof={'input_sha256':PINS,'candidate_sha256':sha(raw),'retired_parent_faces':hits,'retained_old_to_new':ledger,'added_faces':additionledger,'new_vertex_owners':appended,'head_faces':sorted(newhead),'source_face_owners':newowners,'source_labels':[{'mesh':m,'vertex':v,'label':x}for(m,v),x in sorted(labels.items())],'original_binary_bytes':len(old.b),'oral_source_sha256':sha(HEADSOURCE.read_bytes()),'status':'UNACCEPTED original reconstructed combined parcel; no fit claim'}
 (out/'candidate.glb').write_bytes(raw);(out/'graft-proof.json').write_text(json.dumps(proof,indent=2)+'\n');return proof
if __name__=='__main__':produce(P/'candidate-one')
