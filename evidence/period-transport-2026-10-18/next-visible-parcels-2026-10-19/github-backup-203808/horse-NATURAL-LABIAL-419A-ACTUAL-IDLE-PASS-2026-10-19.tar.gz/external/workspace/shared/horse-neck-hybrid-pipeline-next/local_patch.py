# SPDX-License-Identifier: GPL-3.0-or-later
"""Original source-owned six-quad topology-only proposal. NO actual invocation.
Retires12 original neck triangles, appends12 explicit triangles; attributes exact.
"""
def require(test,message):
 if not test:raise ValueError(message)
def cycle(face):
 f=list(face);return min(tuple(f),tuple(f[1:]+f[:1]),tuple(f[2:]+f[:2]))
def recipe():
 lower=list(range(207,214));upper=list(range(231,238))
 old=[]
 for a,b,c,d in zip(lower[:-1],lower[1:],upper[1:],upper[:-1]):old.extend([(a,b,c),(a,c,d)])
 new=[(a,b,upper[0])for a,b in zip(lower[:-1],lower[1:])]+[(lower[-1],b,a)for a,b in zip(upper[:-1],upper[1:])]
 return{'source_role':'continuous_body_neck','source_material':0,'strip':8,'samples_inclusive':[15,20],'retired_source_faces':list(range(414,426)),'old_faces':old,'new_faces':new,'boundary_order':lower+list(reversed(upper)),'attribute_changes':{},'status':'UNACCEPTED SOURCE topology proposal; 3Dembedding NOT TESTED'}
def boundary(faces):
 edges={}
 for f in faces:
  require(len(set(f))==3,'Repeated trianglevertex')
  for a,b in zip(f,f[1:]+f[:1]):edges.setdefault(tuple(sorted([a,b])),[]).append((a,b))
 for pair,uses in edges.items():
  require(len(uses)<=2,'Nonmanifoldsourceedge')
  if len(uses)==2:require(uses[0]==tuple(reversed(uses[1])),'Inconsistent interiorwinding')
 return{e:u[0]for e,u in edges.items()if len(u)==1}
def validate_recipe(r):
 require(len(r['old_faces'])==len(r['new_faces'])==12,'Exact12faceproposal')
 require(boundary(r['old_faces'])==boundary(r['new_faces']),'Changed fixedboundary/winding')
 vertices={v for f in r['new_faces']for v in f};require(vertices==set(r['boundary_order']),'Missing boundaryvertex/newunownedvertex')
 chart={v:(i,0)for i,v in enumerate(range(207,214))};chart.update({v:(i,1)for i,v in enumerate(range(231,238))})
 areas=[]
 for a,b,c in r['new_faces']:
  a,b,c=chart[a],chart[b],chart[c];areas.append((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))
 require(all(a>0 for a in areas)and sum(areas)==12,'Degenerate/folded/incomplete sourcechart')
 # The two fans partition the convex6x1 source rectangle along O21→Q15.
 # Every fan uses ordered boundarysegments and one opposite endpoint; positive
 # areas+ordered fan construction here is a constructive injective partition.
 expected=recipe()['new_faces'];require(r['new_faces']==expected,'Only reviewed explicitfanconstruction allowed')
 edges={tuple(sorted([a,b]))for f in r['new_faces']for a,b in zip(f,f[1:]+f[:1])}
 require((211,235)not in edges and(212,236)not in edges,'Known crossing internalcolumns retained')
 return{'source_chart':'two orderedfans partition6x1rectangle','triangles':12,'vertices':14,'Euler':1,'boundary_edges':14,'positive_chart_double_area_sum':sum(areas),'known_obstructing_internal_edges_removed':[[211,235],[212,236]],'actual3Dembedding':'UNTESTED'}
def propose_indices(indices):
 """Future source-only indexoperation, no IO. Tests use only synthetic indices."""
 r=recipe();proof=validate_recipe(r);lookup={}
 for i,t in enumerate(indices):lookup.setdefault(cycle(t),[]).append(i)
 retired=[]
 for f in r['old_faces']:
  hits=lookup.get(cycle(f),[]);require(len(hits)==1,'Missing/duplicate exact sourceownedtriangle');retired.append(hits[0])
 require(len(set(retired))==12,'Duplicate retirement')
 kept=[tuple(t)for i,t in enumerate(indices)if i not in set(retired)]
 mapping=[{'old':i,'new':j}for j,i in enumerate(i for i in range(len(indices))if i not in set(retired))]
 return kept+r['new_faces'],{'retired_old_active_faces':retired,'retired_source_faces':r['retired_source_faces'],'unchanged_old_to_new':mapping,'appended_new_faces':r['new_faces'],'topology':proof,'all_attribute_arrays':'MUST remain byteexact; not supplied or modified'}
