# SPDX-License-Identifier: CC0-1.0
import unittest,tempfile,subprocess,sys
from pathlib import Path
class Preservation(unittest.TestCase):
 def test_preexisting_receipt_refusal_never_changes_evidence(self):
  with tempfile.TemporaryDirectory()as td:
   p=Path(td);(p/'run_once.py').write_bytes(Path(__file__).with_name('run_once.py').read_bytes());original=b'{"frozen_prior_trial":"MUST_NOT_OVERWRITE"}\n';(p/'operator-receipt.json').write_bytes(original);before={x.name:x.read_bytes()for x in p.iterdir()};r=subprocess.run([sys.executable,str(p/'run_once.py')],capture_output=True)
   self.assertNotEqual(r.returncode,0);self.assertIn(b'FileExistsError',r.stderr);self.assertEqual(before,{x.name:x.read_bytes()for x in p.iterdir()})
if __name__=='__main__':unittest.main()
