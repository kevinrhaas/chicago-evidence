# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import copy,hashlib
import numpy as np
from hybrid_contract import load_parent
from hybrid_geometry import evaluate,recipe
from ownership import ATTRS,Model,PINS
from glb_data import append,encode
from sparse_rules import require
from topology_export import PARENT_AUTHORITY

def export_once(base,ear,source,checkpoint=None):
 c=load_parent(base,ear,source);m=c['model'];a=m.views[0,0]['attributes'];p=a['POSITION'];shape=evaluate(p[144:168].astype(float).tolist(),p[168:192].astype(float).tolist(),c['HP'],c['HW']);n=len(p);keys=shape['keys'];lookup={key:n+i for i,key in enumerate(keys)}
 def actual(key):
  if key.startswith('B:'):return int(key[2:])
  if key.startswith('h:'):return c['mapping'][int(key[2:])]
  return lookup[key]
 fresh=np.array([[actual(k)for k in f]for f in shape['faces']],dtype='<u4');retired=set(c['neckret'])|{g-m.start[0,0]for g in c['headret']};require(len(retired)==144,'96neck+48head only');idx=m.views[0,0]['indices'];keep=[i for i in range(len(idx))if i not in retired];indices=np.vstack([idx[keep],fresh]).astype('<u4')
 require(not np.isin(indices,np.arange(192,240)).any(),'AlloldneckO/Q inactive')
 for h in list(range(13,24))+list(range(37,48)):
  hits=[i for(key,i),label in c['labels'].items()if key==0 and i>=1025 and label=='h:'+str(h)];require(len(hits)==1 and not np.isin(indices,hits).any(),'Oldlowerrearhead sourceinactive')
 newp=np.vstack([p,np.array(shape['positions'],dtype='<f4')]);newj=np.vstack([a['JOINTS_0'],np.tile([c['root'],c['headjoint'],c['root'],c['root']],(720,1))]).astype(a['JOINTS_0'].dtype);neww=np.vstack([a['WEIGHTS_0'],np.array(shape['weights'],dtype='<f4')]);newn=np.vstack([a['NORMAL'],np.zeros((720,3),dtype='<f4')]);tri=newp[indices].astype(float);area=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);require(np.isfinite(area).all()and np.all(np.linalg.norm(area,axis=1)>2e-12),'Actual3D finite/nondegenerate')
 acc=np.zeros_like(newp,dtype=float)
 for k in range(3):np.add.at(acc,indices[:,k],area)
 norm=np.linalg.norm(acc[n:],axis=1);require(np.all(norm>1e-12),'Newnormalareas valid');newn[n:]=(acc[n:]/norm[:,None]).astype('<f4');arrays={'POSITION':newp,'NORMAL':newn,'JOINTS_0':newj,'WEIGHTS_0':neww};d=copy.deepcopy(m.d);blob=bytearray(m.b);prim=d['meshes'][0]['primitives'][0]
 for k in ATTRS:prim['attributes'][k]=append(d,blob,arrays[k],'VEC3'if k in['POSITION','NORMAL']else'VEC4',5123 if k=='JOINTS_0'else 5126)
 prim['indices']=append(d,blob,indices.reshape(-1,1),'SCALAR',5125,target=34963);candidate=encode(d,blob)
 if checkpoint:checkpoint(candidate)
 decoded=Model(candidate)
 for k in ATTRS:require(np.array_equal(decoded.views[0,0]['attributes'][k],arrays[k]),'Intendedactualreadback:'+k)
 proof={'status':'UNACCEPTED hybridlocalexportONLY','input_pins':PINS,'parent_authority_sha256':PARENT_AUTHORITY,'output_sha256':hashlib.sha256(candidate).hexdigest(),'source_recipe':recipe(),'parent_coat_vertex_count':n,'actual_skin_palette':{'root':c['root'],'head':c['headjoint'],'names':c['palette']},'head_anchor_skin':c['head_anchor_skin'],'actual_head_source_mapping':{str(h):i for h,i in c['mapping'].items()},'index_proof':{'retired_old_active_faces':sorted(retired),'neck_retired_old_active_faces':c['neckret'],'head_retired_old_global_faces':sorted(c['headret']),'head_retired_source_faces':recipe()['head_retired_source_faces'],'neck_retired_source_faces':list(range(336,432)),'unchanged_old_to_new':[{'old':i,'new':j}for j,i in enumerate(keep)],'new_vertex_keys':keys},'newpatch_indices':fresh.tolist(),'not_run':['collision','63poses','gear','render']}
 from hybrid_rest import audit_rest
 proof['rest_readback']=audit_rest(c['raw'],candidate,proof,c)
 return candidate,proof
