# SPDX-License-Identifier: GPL-3.0-or-later
"""ONE idle phase0, unchanged actual SAT/proper predicates; no generation."""
from pathlib import Path
import json,hashlib,time,signal
import numpy as np
import official_fit_predicates as predicates
from validate_capture import validate,require
P=Path(__file__).parent;OUT=P/'results';require(not OUT.exists(),'REFUSE existing results directory');OUT.mkdir();HEAD={'cheekpiece_l','cheekpiece_r','crownpiece','browband','noseband'};BODY={'breastcollar','breastcollar_support_l','breastcollar_support_r','harness_saddle_pad'}
started=time.monotonic();deadline=90
class Deadline(Exception):pass
def alarm(*_):raise Deadline('90second actual fit bound')
signal.signal(signal.SIGALRM,alarm);signal.alarm(deadline)
def load(n):
 m=json.loads((P/'capture'/(n+'.json')).read_text());b=(P/'capture'/(n+'.f64')).read_bytes();validate(n,m,b);a=np.frombuffer(b,dtype='<f8').reshape(m['triangleCount'],3,3);require(np.isfinite(a).all(),'nonfinite captured world values');return m,a
rows=[]
hm=horse=lo=hi=None
def measure(label,scope,names):
 gm,gear=load(label);groups=[g for g in gm['meshes']if names is None or g['name']in names];hits=[];by={}
 for g in groups:
  raw=proper=0
  for fi,a in enumerate(gear[g['start']:g['start']+g['count']]):
   ids=np.flatnonzero(np.all(hi>=a.min(0)-1e-8,axis=1)&np.all(lo<=a.max(0)+1e-8,axis=1))
   for k in ids:
    if predicates.sat(a,horse[k]):
     detail=predicates.proper(a,horse[k]);raw+=1;proper+=bool(detail);hits.append({'gear':g['name'],'gear_triangle':fi,'horse_triangle_global':int(k),'proper':detail,'gear_points_m':a.tolist(),'horse_points_m':horse[k].tolist()})
  by[g['name']]={'raw_SAT_pairs':raw,'proper_crossings':proper}
 row={'label':label,'scope':scope,'clip':'idle','phase':0,'raw_SAT_pairs':sum(x['raw_SAT_pairs']for x in by.values()),'proper_crossings':sum(x['proper_crossings']for x in by.values()),'parts':by,'hits':hits};rows.append(row);write(False);return row
def write(completed,error=None):
 (OUT/'actual-idle-results.json').write_text(json.dumps({'measurement_complete':completed,'fit_passed':completed and all(r['raw_SAT_pairs']==0 and r['proper_crossings']==0 for r in rows if r['label']=='candidate') and any(r['label']=='candidate'for r in rows),'error':error,'historical_f32_baseline':{'raw_SAT_pairs':262,'proper_crossings':258,'scope':'old rounded diagnostic; NOT required float64 counts'},'elapsed_s':time.monotonic()-started,'rows':rows,'scope':'ONE actual idle0 only; rawSAT/proper include signed edge distances; no volumeinside/unsigneddistance/pressure/63pose pass'},indent=2)+'\n')
try:
 hm,horse=load('horse');lo=horse.min(1);hi=horse.max(1)
 predicates.predicate_controls();r=measure('baseline','original_five_headstraps',HEAD)
 if r['raw_SAT_pairs']==0 or r['proper_crossings']==0:raise ValueError('STOP original known-negative no longer intersects in float64; investigate without tuning counts')
 # All36 candidate parts are tested separately; do not treat known unchanged bits as exceptions.
 r=measure('candidate','all36_parts',None);write(True)
 if r['raw_SAT_pairs']or r['proper_crossings']:raise SystemExit(2)
except Exception as e:write(False,repr(e));raise
finally:signal.alarm(0)
