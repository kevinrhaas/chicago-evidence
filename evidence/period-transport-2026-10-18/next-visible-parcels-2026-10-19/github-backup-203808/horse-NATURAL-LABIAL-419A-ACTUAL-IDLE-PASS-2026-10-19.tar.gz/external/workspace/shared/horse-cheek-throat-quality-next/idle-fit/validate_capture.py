# SPDX-License-Identifier: GPL-3.0-or-later
import json,struct,hashlib,collections,math
from pathlib import Path
P=Path(__file__).parent
PROOF=json.loads((P.parent/'quality-readback-result.json').read_text())
if PROOF.get('PASS')is not True:raise ValueError('decodedgraftPASSrequired')
INPUTS={'horse':(str(P/'../candidate-one/candidate.glb'),PROOF['candidate_sha256']),'baseline':('/workspace/shared/horse-v2-cap-registered-next/build1/light_breastcollar_harness_reconstructed_01.glb','078ed2cebc01dba52d28f2ae737f170f0fe28fd20523aed9bb8869f4cd7b35bd'),'candidate':('/workspace/shared/horse-hindgear-support-hull-candidate/candidate-one/light_breastcollar_harness_reconstructed_01.glb','fe76c95b49234da64700a1e20741b4998e8cfbae69571387d49bf5bb23ef04b1')}
def require(c,msg):
 if not c:raise ValueError(msg)
def source_expected(label):
 path,sha=INPUTS[label];raw=Path(path).read_bytes();require(hashlib.sha256(raw).hexdigest()==sha,'actual GLB hash');n=struct.unpack_from('<I',raw,12)[0];j=json.loads(raw[20:20+n]);b=raw[28+n:];parents={c:i for i,n in enumerate(j['nodes'])for c in n.get('children',[])};active=set()
 def visit(i):
  require(i not in active,'repeated active node');active.add(i)
  for c in j['nodes'][i].get('children',[]):visit(c)
 for i in j['scenes'][j.get('scene',0)]['nodes']:visit(i)
 out=[]
 for i in active:
  node=j['nodes'][i]
  if'mesh'not in node:continue
  primitives=j['meshes'][node['mesh']]['primitives']
  for pi,pr in enumerate(primitives):
   require(pr.get('mode',4)==4,'nontriangle source');pc=j['accessors'][pr['attributes']['POSITION']]['count']
   if'indices'in pr:
    a=j['accessors'][pr['indices']];v=j['bufferViews'][a['bufferView']];fmt,size={5121:('B',1),5123:('H',2),5125:('I',4)}[a['componentType']];offset=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',size);ids=[struct.unpack_from('<'+fmt,b,offset+k*stride)[0]for k in range(a['count'])]
   else:ids=list(range(pc))
   require(len(ids)>0 and len(ids)%3==0 and all(0<=x<pc for x in ids),'source indices')
   out.append({'name':j['meshes'][node['mesh']]['name'],'positionCount':pc,'indexCount':len(ids),'indexed':'indices'in pr,'indexStreamSHA256':hashlib.sha256(struct.pack('<'+'I'*len(ids),*ids)).hexdigest()})
 return j,out
FIELDS=('name','positionCount','indexCount','indexed','indexStreamSHA256')
def validate(label,m,payload):
 path,sha=INPUTS[label];require(m.get('input')==[path,sha],'declared inputpin');j,expected=source_expected(label);require(m.get('precision')=='float64_world','precision');pose=m.get('pose',{});require(pose.get('clip')=='idle'and type(pose.get('phase'))is int and pose['phase']==0 and type(pose.get('time_s'))is int and pose['time_s']==0 and pose.get('head_binding')=='actual_parent_inverse_head_world','pose signature');require(isinstance(pose.get('duration_s'),(int,float))and not isinstance(pose.get('duration_s'),bool)and math.isfinite(pose['duration_s'])and pose['duration_s']>0,'duration');hj,_=source_expected('horse');idle=[a for a in hj.get('animations',[])if a.get('name')=='idle'];require(len(idle)==1,'unique source idle');bounds=[hj['accessors'][s['input']].get('max',[None])[0]for s in idle[0]['samplers']];require(all(isinstance(x,(int,float))and math.isfinite(x)for x in bounds)and abs(pose['duration_s']-max(bounds))<1e-9,'source duration agreement');require(m.get('rows')==[{'clip':'idle','phase':0}],'only idle0');require(hashlib.sha256(payload).hexdigest()==m.get('buffer_sha256'),'buffer SHA');groups=m.get('meshes',[]);require(bool(groups),'nonempty groups');position=0
 for g in groups:
  require(type(g.get('count'))is int and g['count']>0 and type(g.get('start'))is int and g['start']==position,'contiguous nonempty coverage');require(g['indexCount']==3*g['count'],'declared count');position+=g['count']
 require(type(m.get('triangleCount'))is int and m['triangleCount']==position and len(payload)==position*9*8,'payload/count coverage');require(collections.Counter(tuple(g[k]for k in FIELDS)for g in groups)==collections.Counter(tuple(g[k]for k in FIELDS)for g in expected),'actual source primitive/index coverage')
 if label!='horse':require(len(groups)==36 and len({g['name']for g in groups})==36 and {g['name']for g in groups}=={g['name']for g in expected},'full unique36parts')
 return m
