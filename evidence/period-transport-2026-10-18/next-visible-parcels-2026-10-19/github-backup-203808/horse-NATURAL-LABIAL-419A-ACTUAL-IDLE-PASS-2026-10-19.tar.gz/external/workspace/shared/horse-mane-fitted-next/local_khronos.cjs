// SPDX-License-Identifier: GPL-3.0-or-later
// UNEXECUTED validator CLI, not fit/visual acceptance.
const fs=require('node:fs'),path=require('node:path'),validator=require('/workspace/shared/transport-tools/node_modules/gltf-validator');
(async()=>{let out=process.argv[2];let report=await validator.validateBytes(new Uint8Array(fs.readFileSync(path.join(out,'payload/candidate.glb'))),{uri:'candidate.glb',maxIssues:10000});fs.writeFileSync(path.join(out,'khronos.json'),JSON.stringify(report,null,2)+'\n');if(report.issues.numErrors||report.issues.numWarnings)process.exitCode=1;})().catch(e=>{console.error(e.stack);process.exitCode=1;});
