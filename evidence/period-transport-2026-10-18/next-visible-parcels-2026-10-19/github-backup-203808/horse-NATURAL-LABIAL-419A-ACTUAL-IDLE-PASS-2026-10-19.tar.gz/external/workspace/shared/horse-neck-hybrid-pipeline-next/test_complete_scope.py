# SPDX-License-Identifier: GPL-3.0-or-later
import unittest,json
from types import SimpleNamespace
import numpy as np
from neck_scope import annulus_ownership
from metadata_producer import build_metadata
from chain_rules import linked_metadata,PINS,PARENT_AUTHORITY
class Controls(unittest.TestCase):
 def mock(self):
  faces=[]
  for j in range(6,10):
   for i in range(24):
    a=j*24+i;b=j*24+(i+1)%24;faces.extend([(a,b,b+24),(a,b+24,a+24)])
  labels=lambda i:'h:'+str(i-216)if 216<=i<240 else 'body:0:'+str(i)
  rows=[[labels(i)for i in f]for f in faces];m=SimpleNamespace(views={(0,0):{'indices':np.array(faces)}},start={(0,0):0});return m,rows
 def test_annulus_scope_exact(self):
  m,r=self.mock();s,a,b,o,t=annulus_ownership(m,r);self.assertEqual(len(s),96);self.assertEqual(t['Euler'],0);self.assertEqual(t['boundary_loops'],2);self.assertEqual(len(b),48)
 def test_missing_face_fails(self):
  m,r=self.mock();m.views[0,0]['indices']=np.delete(m.views[0,0]['indices'],48,axis=0);r.pop(48)
  with self.assertRaises(ValueError):annulus_ownership(m,r)
 def test_duplicate_face_fails(self):
  m,r=self.mock();m.views[0,0]['indices']=np.vstack([m.views[0,0]['indices'],m.views[0,0]['indices'][48]]);r.append(r[48])
  with self.assertRaises(ValueError):annulus_ownership(m,r)
 def test_bad_sharededge_owner_fails(self):
  m,r=self.mock();r[47]=list(reversed(r[47]))
  with self.assertRaises(ValueError):annulus_ownership(m,r)
 def test_metadata_links_mock_only(self):
  v={'triangles':11452,'head_ear_triangles':2960,'neck_changed_source_faces':96,'all_other_attributes_exact':True,'index_ownership_exact':True,'storage_verified':True};m,a,c=map(json.loads,build_metadata('ab'*32,'cd'*32,'ef'*32,v,{'mock.py':'12'*32}));proof={'output_sha256':'ab'*32,'input_pins':PINS,'authority_sha256':PARENT_AUTHORITY};linked_metadata(c,m,proof,a)
 def test_incomplete_shape_metadata_fails(self):
  with self.assertRaises(ValueError):build_metadata('ab'*32,'cd'*32,'ef'*32,{}, {'mock.py':'12'*32})
if __name__=='__main__':unittest.main()
