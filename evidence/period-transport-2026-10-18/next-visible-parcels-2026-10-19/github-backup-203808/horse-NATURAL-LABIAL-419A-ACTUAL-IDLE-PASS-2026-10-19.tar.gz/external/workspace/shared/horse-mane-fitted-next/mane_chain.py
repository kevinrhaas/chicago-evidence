# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import hashlib,json
from mane_source import parent_context,PACKET_SHA,PARENT_SHA,recipe,HYBRID
from mane_export import audit_rest
from ownership import Model,triangle_labels
from source_inventory import helper_inventory,inventory_sha
from sparse_rules import require

def load(packet_path,packet_sha):
 p=Path(packet_path);raw=p.read_bytes();require(hashlib.sha256(raw).hexdigest()==packet_sha and len(packet_sha)==64,'Reviewedactualpacket');packet=json.loads(raw);require(packet['parent_sha256']==PARENT_SHA and packet['parent_packet_sha256']==PACKET_SHA,'Exact192parentchain');inv=helper_inventory(Path(__file__).parent);require(packet['helper_inventory']==inv and packet['helper_inventory_sha256']==inventory_sha(inv),'Completecurrentsourceinventory');data={}
 for k,n in[('glb','candidate.glb'),('proof','mane-proof.json'),('manifest','manifest.json'),('authority','authority.json')]:
  r=packet['files'][k];require(r['path']==n and(p.parent/n).resolve().parent==p.parent.resolve(),'Canonicalpacketpath');data[k]=(p.parent/n).read_bytes();require(hashlib.sha256(data[k]).hexdigest()==r['sha256'],'Actualpayloadhash')
 proof,manifest,authority=[json.loads(data[k])for k in['proof','manifest','authority']];newsha=hashlib.sha256(data['glb']).hexdigest();require(manifest['glb_sha256']==newsha and manifest['proof_sha256']==packet['files']['proof']['sha256']and manifest['source_recipe']==recipe()and manifest['status']=='UNACCEPTED','Actualmanifest');require(authority['glb_sha256']==newsha and authority['manifest_sha256']==packet['files']['manifest']['sha256'],'Actualauthority');require(all(x['parent_packet_sha256']==PACKET_SHA and x['helper_inventory']==inv and x['helper_inventory_sha256']==inventory_sha(inv)for x in[manifest,authority]),'Parent/sourceauthoritylinks')
 c=parent_context();old,labels,head,owners=c['neck_candidate'];parent=Path('/workspace/shared/horse-neck-hybrid-first-local-trial/payload/candidate.glb').read_bytes();rest=audit_rest(parent,data['glb'],proof,c);new=Model(data['glb']);newhead=set();newowners={};remap={r['old']:r['new']for r in proof['retained_old_to_new']}
 for g,owner in owners.items():
  desc=old.descriptor(g);key=(desc['mesh'],desc['primitive']);i=desc['primitive_triangle']
  if key==(1,0):
   if i not in remap:continue
   i=remap[i]
  ng=new.start[key]+i;newowners[ng]=owner
  if g in head:newhead.add(ng)
 require(len(newhead)==2912,'Allretainedheadfaces');newlabels=dict(labels);n=proof['old_mane_vertex_count']
 for i in range(230):newlabels[1,n+i]='fittedmane:'+str(i)
 start=len(new.views[1,0]['indices'])-456
 for i in range(456):newowners[new.start[1,0]+start+i]={'kind':'fitted_mane','new_face':i}
 new.source_face_owners=newowners;c['neck_candidate']=(new,newlabels,newhead,newowners);c['neck_sha256']=newsha;c['mane_proof']=proof;c['mane_packet']=packet;c['rest']=rest;return c
