# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib
from quality_variant import context,audit
from ownership import Model
from sparse_rules import require
P=Path(__file__).parent

def checked():
 c=context();raw=(P/'candidate-one/candidate.glb').read_bytes();proof=json.loads((P/'candidate-one/proof.json').read_text());require(hashlib.sha256(raw).hexdigest()==proof['candidate_sha256'],'Exactqualitycandidate');audit(raw,c,proof);m=Model(raw);m.source_face_owners=c['owners'];changed={m.start[0,0]+i for i in proof['sparse_change']['changed_position_faces']};require(changed<=c['head']|c['scopes']['hybrid'],'ALLchangedskinfaces are covered byfullhead+hybridscopes');return m,c['labels'],c['head'],c['owners'],c['scopes'],raw
if __name__=='__main__':
 m,l,h,o,s,r=checked();report={'PASS':True,'candidate_sha256':hashlib.sha256(r).hexdigest(),'status':'qualitySOURCE/REST ONLY; self/gear/visual UNTESTED','changed_geometry_scope':'completehead3122 andhybrid1492 plusunchangedmane456'}
 with(P/'quality-readback-result.json').open('x')as f:f.write(json.dumps(report,indent=2)+'\n')
