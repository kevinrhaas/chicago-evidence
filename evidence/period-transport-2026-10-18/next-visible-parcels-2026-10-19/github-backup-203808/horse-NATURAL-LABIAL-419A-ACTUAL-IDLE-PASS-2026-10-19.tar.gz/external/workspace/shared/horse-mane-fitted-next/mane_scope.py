# SPDX-License-Identifier: GPL-3.0-or-later
from collections import defaultdict
from mane_source import HYBRID
from sparse_rules import require
from check_idle import scan,write

def ownership(model,records,proof):
 start=len(model.views[1,0]['indices'])-456;selected=set(range(model.start[1,0]+start,model.start[1,0]+start+456));require(model.views[1,0]['indices'][start:].tolist()==proof['new_mane_indices'],'Actual456 indexownership');edges=defaultdict(list);vertices=set();graph=defaultdict(set)
 for g in selected:
  t=records[g];vertices.update(t)
  for a,b in zip(t,t[1:]+t[:1]):edges[tuple(sorted([a,b]))].append((g,a,b));graph[a].add(b);graph[b].add(a)
 require(len(vertices)==230 and len(vertices)-len(edges)+456==2,'ClosedmaneEuler2')
 require(all(len(u)==2 and u[0][1:]==u[1][:0:-1]for u in edges.values()),'Actualuniqueoppositemaneedges');seen=set();pending=[next(iter(vertices))]
 while pending:
  a=pending.pop()
  if a in seen:continue
  seen.add(a);pending.extend(graph[a]-seen)
 require(seen==vertices,'Singleconnectedmane');internal={tuple(sorted([u[0][0],u[1][0]]))for u in edges.values()};require(len(internal)==684,'684internaledgepairs');return selected,internal

def check(model,records,data,out,proof):
 selected,internal=ownership(model,records,proof);write(out/'fittedmane-ownership.json',{'actual456faces':sorted(selected),'topology':'closed230vertex456triangleEuler2','rootgap_is_NOT_attachment_certificate':True})
 for scope,edges in[('head_internal',internal),('head_vs_all_rest',set())]:
  r=scan('fittedmane456',scope,model,records,selected,data,edges,out,True,declared_scope='ALL modifiedmane self'if scope=='head_internal'else'ALL modifiedmane vsALLremainingactivehorse; no rootcontactwaiver')
  if r['counts']['unexpected_SAT']or r['counts']['strict_proper']:return False
 return True
