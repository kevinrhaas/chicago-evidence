# SPDX-License-Identifier: GPL-3.0-or-later
import unittest,json
from pathlib import Path
import numpy as np
from smooth_rules import verify_actual_anchors
class Controls(unittest.TestCase):
 def fixture(self):
  d=json.loads(Path(__file__).with_name('anchor-skin-contract.json').read_text());a={'JOINTS_0':np.zeros((1100,4),dtype='<u2'),'WEIGHTS_0':np.zeros((1100,4),dtype='<f4')}
  for r in d['rows']:a['JOINTS_0'][r['vertex']]=r['raw_J'];a['WEIGHTS_0'][r['vertex']]=r['raw_W']
  return a,d['palette']
 def test_recorded_real_semantics_including_upstream_fore(self):
  a,n=self.fixture();self.assertTrue(verify_actual_anchors(a,n));self.assertGreater(a['WEIGHTS_0'][157,1],0)
 def test_unused_palette_slot_still_rawprotected(self):
  a,n=self.fixture();a['JOINTS_0'][144,3]=1
  with self.assertRaises(ValueError):verify_actual_anchors(a,n)
 def test_upstream_weight_change_still_fails(self):
  a,n=self.fixture();a['WEIGHTS_0'][157,1]+=.0001
  with self.assertRaises(ValueError):verify_actual_anchors(a,n)
if __name__=='__main__':unittest.main()
