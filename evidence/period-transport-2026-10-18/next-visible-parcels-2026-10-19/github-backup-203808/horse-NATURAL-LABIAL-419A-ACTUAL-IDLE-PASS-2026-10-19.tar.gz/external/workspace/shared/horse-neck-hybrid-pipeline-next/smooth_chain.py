# SPDX-License-Identifier: GPL-3.0-or-later
import json,hashlib
from pathlib import Path
from topology_export import parent_chain,PARENT_AUTHORITY
from smooth_rest import audit_rest
from ownership import Model,PINS,verify_source_seams
from sparse_rules import require
from chain_rules import real_sha
from source_inventory import helper_inventory,inventory_sha
from smooth_neck_patch import recipe
NAMES={'glb':'candidate.glb','proof':'smooth-export-proof.json','manifest':'manifest.json','authority':'authority.json'}

def load_chain(packet_file,packet_sha,base,ear,source):
 packet_file=Path(packet_file);raw=packet_file.read_bytes();require(hashlib.sha256(raw).hexdigest()==real_sha(packet_sha),'ReviewedpacketSHA');packet=json.loads(raw);payload={}
 require(packet['parent090_sha256']==PINS['baseline']and packet['parent26027_sha256']==PINS['candidate'],'Exactparentchain');inv=helper_inventory(Path(__file__).parent);require(packet['helper_inventory']==inv and packet['helper_inventory_sha256']==inventory_sha(inv),'Fullsourceinventory')
 for key,name in NAMES.items():
  e=packet['files'][key];require(e['path']==name,'Canonicalname');p=(packet_file.parent/name).resolve();require(p.parent==packet_file.parent.resolve(),'Pathescape');payload[key]=p.read_bytes();require(hashlib.sha256(payload[key]).hexdigest()==real_sha(e['sha256']),'ActualfileSHA:'+key)
 proof=json.loads(payload['proof']);manifest=json.loads(payload['manifest']);authority=json.loads(payload['authority']);newsha=hashlib.sha256(payload['glb']).hexdigest()
 require(proof['output_sha256']==newsha and proof['input_pins']==PINS and proof['parent_authority_sha256']==PARENT_AUTHORITY,'Exportproofchain')
 require(manifest['glb_sha256']==newsha and manifest['parent_sha256']==PINS['candidate']and manifest['proof_sha256']==packet['files']['proof']['sha256'],'Manifestlinks')
 require(authority['manifest_sha256']==packet['files']['manifest']['sha256']and authority['glb_sha256']==newsha and authority['parent_authority_sha256']==PARENT_AUTHORITY,'Authoritylinks')
 require(manifest['source_recipe']==recipe()and manifest['status']=='UNACCEPTED','Exactnewsmoothscopeauthority')
 require(all(x['helper_inventory']==inv and x['helper_inventory_sha256']==inventory_sha(inv)for x in[manifest,authority]),'Inventorylinks')
 parent_raw,parent,labels,head,owners,baseline=parent_chain(Path(base),Path(ear),Path(source));audit_rest(parent_raw,payload['glb'],proof);new=Model(payload['glb']);verify_source_seams(new,labels)
 remap={r['old']:r['new']for r in proof['index_proof']['unchanged_old_to_new']};retired=set(proof['index_proof']['retired_old_active_faces']);newhead=set();newowners={}
 for g in head:
  for key,v in parent.views.items():
   start=parent.start[key]
   if start<=g<start+len(v['indices']):
    local=g-start;require(not(key==(0,0)and local in retired),'Headcohortretired');current=remap[local]if key==(0,0)else local;ng=new.start[key]+current;newhead.add(ng);newowners[ng]=owners[g];break
 require(len(newhead)==2960 and new.total==12124,'Actualnewscope')
 newlabels=dict(labels);count=proof['parent_coat_vertex_count']
 for j in range(15):
  for k in range(24):newlabels[0,count+j*24+k]=f'smooth:{j}:{k}'
 first=len(new.views[0,0]['indices'])-768
 for i in range(768):newowners[new.start[0,0]+first+i]={'kind':'smooth_neck','strip':i//48,'column':(i%48)//2,'triangle':i%2}
 for model,own in[(parent,owners),(new,newowners),(baseline[0],baseline[3])]:model.source_face_owners=own
 return{'baseline':baseline,'ear_parent':(parent,labels,head,owners),'neck_candidate':(new,newlabels,newhead,newowners),'neck_sha256':newsha,'proof':proof,'manifest':manifest,'packet':packet}
