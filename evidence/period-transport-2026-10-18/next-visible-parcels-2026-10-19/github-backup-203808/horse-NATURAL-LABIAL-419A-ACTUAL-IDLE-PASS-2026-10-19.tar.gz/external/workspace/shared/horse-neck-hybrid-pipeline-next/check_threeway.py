# SPDX-License-Identifier: GPL-3.0-or-later
"""UNEXECUTED proposal entry functions, no CLI. Preflight before ANY collision."""
from pathlib import Path
import json,hashlib
from hybrid_chain import load_chain as verify_threeway
from check_idle import load_capture,world_aliases,scan,write
from ownership import triangle_labels,PINS
from source_edges import owned_adjacency
from baseline_negatives import verify_negative_cohort
from sparse_rules import require
from hybrid_scope import patch_ownership,check_patch
from hybrid_geometry import SEAM
import official_fit_predicates as predicates
PARENT_NEGATIVE_SHA='67594ff46f31b4edbd51dba5028f0aaa0816b70bf6dd80e170e324eb4c1d3e58'
# This pin is populated only from the exact existing actual parent receipt below;
# source preparation validates the receipt hash without running any capture/SAT.

def source_signature(w):
 a,b=w['a_source_face_owner'],w['b_source_face_owner']
 if a.get('source_head_face')!=33:return False
 return w['a_source_vertices']==['h:16','h:41','h:40']and w['b_source_vertices']==['body:0:207','body:0:208','h:16']and w['kind']=='unexpected_strict_proper'and w.get('proper_witness')is not None

def require_parent_negative(scopes):
 hits=[w for r in scopes for w in r['unexpected_witnesses']if source_signature(w)]
 require(len(hits)==1 and all(r['complete']for r in scopes),'Ear parent neckface33 negative missing/duplicate/incomplete')
 return hits[0]

def _prepared_check_owned(chain_file,chain_sha,base090,ear_dir,ear_source,capture_dir,output_dir,negative_provenance,parent_receipt):
 out=Path(output_dir) # Exclusively created by run_prepared_once before this worker
 # All immutable/rest/topology/sourceownership checks complete before ANY collision.
 v=verify_threeway(chain_file,chain_sha,base090,ear_dir,ear_source)
 receipt=Path(parent_receipt).read_bytes();require(hashlib.sha256(receipt).hexdigest()==PARENT_NEGATIVE_SHA,'Actual26027parent negative receipt pin')
 parent_prior=json.loads(receipt);require(any(source_signature(w)for w in parent_prior['unexpected_witnesses']),'Actual parent source-owned negative provenance absent')
 rows={};captures={};adj={};metas=[]
 for name in['baseline','ear_parent','neck_candidate']:
  m,labels,head,owners=v[name];rows[name]=triangle_labels(m,labels)
  internal,portal,topo=owned_adjacency(rows[name],head,m.total,3 if name=='baseline'else 1,5 if name=='baseline'else 1,boundary_loop=['h:'+str(h)for h in SEAM]if name=='neck_candidate'else None);adj[name]=[('head_internal',internal),('head_vs_all_rest',portal)]
  h=PINS['baseline']if name=='baseline'else PINS['candidate']if name=='ear_parent'else v['neck_sha256']
  meta,data,_=load_capture(capture_dir,name,m,h);world_aliases(rows[name],data);captures[name]=data;metas.append(meta)
 require(all(m['pose']==metas[0]['pose']and m['root_world']==metas[0]['root_world']and m['head_world']==metas[0]['head_world']for m in metas),'Identical actual idle0 frame required')
 patch_ownership(v['neck_candidate'][0],rows['neck_candidate'],v['proof']) # Exact1492annulus preflight before ANY collision
 predicates.predicate_controls()
 for name in['baseline','ear_parent','neck_candidate']:
  m,labels,head,owners=v[name];scopes=[]
  for scope,edges in adj[name]:
   r=scan(name,scope,m,rows[name],head,captures[name],edges,out,name=='neck_candidate');scopes.append(r)
   if name=='neck_candidate'and(r['counts']['unexpected_SAT']or r['counts']['strict_proper']):
    write(out/'RESULT.json',{'pass':False,'status':'FIRST neckcandidate failure STOP','completed_scopes':[s['scope']for s in scopes if s['complete']],'other_scopes':'UNTESTED'});return False
  if name=='baseline':
   control=verify_negative_cohort(scopes,negative_provenance);write(out/'baseline-known12-negative.json',control);require(control['complete'],'All12known090 negative controls incomplete')
  elif name=='ear_parent':write(out/'parent-neck-negative.json',require_parent_negative(scopes))
 neck_ok,neck_scopes=check_patch(v['neck_candidate'][0],rows['neck_candidate'],captures['neck_candidate'],out,v['proof'])
 if not neck_ok:
  write(out/'RESULT.json',{'pass':False,'status':'FIRST hybrid1492 failure STOP','other_scopes':'UNTESTED if absent'});return False
 write(out/'RESULT.json',{'pass':True,'status':'Idle0 source/contact scope ONLY; UNACCEPTED overall','gear_63poses_render':'NOT RUN'});return True


def run_prepared_once(**kwargs):
 from exclusive_output import with_exclusive_output
 out=Path(kwargs['output_dir'])
 return with_exclusive_output(out,lambda:_prepared_check_owned(**kwargs))
