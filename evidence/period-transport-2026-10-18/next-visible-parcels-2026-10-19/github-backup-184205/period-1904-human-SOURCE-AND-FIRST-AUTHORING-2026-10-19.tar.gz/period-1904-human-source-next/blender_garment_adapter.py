# SPDX-License-Identifier: GPL-3.0-or-later
"""Reviewed-caller seam for original prepared garments; BPy execution unverified.

This does not create a person, skeleton, animation, canonical master or export.
An era-qualified canonical human builder may explicitly call attach() after its
identity, clothing provenance, liberty and body-input checks. It must then run
the ordinary human export/LOD/visual gates. Never call from the 1835 builder to
dress a 1835 resident in these clothes.
"""
import hashlib
import math


def validate(garment, body_bytes, contract):
    if garment.get("scene_date") != "1904-07-01" or garment.get("ready_for_scene") is not False:
        raise ValueError("Expected explicitly unaccepted 1904 study")
    if garment.get("body_input_sha256") != hashlib.sha256(body_bytes).hexdigest():
        raise ValueError("Garment/body input mismatch")
    names = set(dict(contract["skeleton"]["bones"]))
    if names != {row["name"] for row in garment["skeleton"]}:
        raise ValueError("Portable skeleton differs")
    for mesh in garment["meshes"]:
        n = len(mesh["positions_m"])
        if not n or n != len(mesh["weights"]) or n != len(mesh["uvs"]):
            raise ValueError("Incomplete mesh arrays")
        if any(not math.isfinite(v) for row in mesh["positions_m"]+mesh["uvs"] for v in row):
            raise ValueError("Non-finite coordinates")
        if any(len(t)!=3 or len(set(t))!=3 or min(t)<0 or max(t)>=n for t in mesh["triangles"]):
            raise ValueError("Invalid triangle")
        for weights in mesh["weights"]:
            if not weights or len(weights)>4 or set(weights)-names or any(not math.isfinite(w) or w<=0 for w in weights.values()) or abs(sum(weights.values())-1)>1e-8:
                raise ValueError("Invalid portable influences")
    return names


def attach(garment, body_bytes, contract, rig, collection, materials):
    """Explicit canonical-builder call; +Y/+Z source to +Z/-Y Blender frame."""
    names = validate(garment, body_bytes, contract)
    if set(rig.data.bones.keys()) != names:
        raise ValueError("Existing canonical rig differs")
    if {m["material"] for m in garment["meshes"]} - set(materials):
        raise ValueError("Caller must supply actual reviewed materials")
    import bpy
    objects=[]
    for source in garment["meshes"]:
        mesh=bpy.data.meshes.new(source["name"])
        points=[(p[0],-p[2],p[1]) for p in source["positions_m"]]
        mesh.from_pydata(points,[],source["triangles"]);mesh.update()
        obj=bpy.data.objects.new(source["name"],mesh);collection.objects.link(obj)
        mesh.materials.append(materials[source["material"]])
        uv=mesh.uv_layers.new(name="UVMap")
        for poly in mesh.polygons:
            for loop in poly.loop_indices:
                uv.data[loop].uv=source["uvs"][mesh.loops[loop].vertex_index]
        for name in sorted(names):obj.vertex_groups.new(name=name)
        for i,weights in enumerate(source["weights"]):
            for name,value in weights.items():obj.vertex_groups[name].add([i],value,"REPLACE")
        mod=obj.modifiers.new("skin","ARMATURE");mod.object=rig
        obj["appearance_grade"]="reconstructed"
        obj["wardrobe_scene_date"]="1904-07-01"
        obj["wardrobe_acceptance"]="unaccepted engineering construction"
        objects.append(obj)
    return objects
