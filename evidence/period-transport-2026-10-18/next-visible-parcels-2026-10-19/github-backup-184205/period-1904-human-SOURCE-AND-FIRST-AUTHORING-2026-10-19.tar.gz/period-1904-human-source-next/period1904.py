# SPDX-License-Identifier: GPL-3.0-or-later
"""Original 1904 authoring inputs; not a canonical master or accepted human asset.

This module never changes the 1835 builder or assigns a 1904 driver to a named
resident. Its mesh dictionary uses the existing prepared-human interchange:
positions_m, triangles, uvs, weights. A reviewed canonical Blender adapter is
still required. Run this module with --root CHECKOUT --output NEW_DIRECTORY.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path

SCENE_DATE = "1904-07-01"
NAMED_ROLES = frozenset(("standing", "walking", "passenger"))
SOURCE_TEXT = {
    "url": "https://archive.org/stream/sears-roebuck-catalogue-111/Sears%20Roebuck%20Catalogue%20111_djvu.txt",
    "title": "Sears, Roebuck Catalogue No.111, Spring 1902",
    "locator": "MEN'S JACKETS, article 41R742",
    "access": "Previously read OCR, mediated through docs/RESEARCH/generic-human-period-clothing.md; not newly acquired or page-collated here",
    "supported": ["black-and-white hairline checked denim coat", "buttons to neck", "turn-down collar", "multiple pockets"],
    "rights_basis": "Reasoned US public domain by 1902 publication; no archive metadata grant asserted",
    "limits": "No illustration pixels, pattern tracing, exact proportions, measured textile, actual purchase or teamster uniform evidence",
}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def resolve_named(root, profile):
    """Resolve actual scene/person/household; reject unsupported role and date drift."""
    if profile.get("scene_date") != SCENE_DATE or profile.get("person_reference_scene") != "1904":
        raise ValueError("Only the actual 1904-07-01 scene is qualified")
    if profile.get("person_reference_id") != "glessner_john_j":
        raise ValueError("This parcel resolves John J. Glessner only")
    roles = profile.get("roles", [])
    if not roles or len(set(roles)) != len(roles) or set(roles) - NAMED_ROLES:
        raise ValueError("Glessner actions are reconstructed standing/walking/passenger only")
    scene = json.loads((root / "data/scenes/1904.json").read_text())
    if scene["target_date"] != SCENE_DATE:
        raise ValueError("Scene date changed; review authoring basis")
    index = json.loads((root / "data/sidecars/1904/people.json").read_text())
    person = next(p for p in index["people"] if p["id"] == "glessner_john_j")
    record_path = root / "data/residents_1904/households/hh_glessner_john_j.json"
    record = json.loads(record_path.read_text())
    original = next(p for p in record["persons"] if p["id"] == person["id"])
    if person["grade"] != "attested" or original["grade"] != "attested" or profile["person_reference_grade"] != "attested":
        raise ValueError("Identity grade changed; reconstructed appearance does not change identity")
    if record["present_on_scene_date"]["value"] != "present" or person["present"] != "present":
        raise ValueError("Person no longer eligible for scene")
    if original["born"]["value"] != "1843" or original["occupation"]["value"] != "farm machinery executive":
        raise ValueError("Recorded age/occupation changed; review the profile")
    if profile.get("appearance_grade") != "reconstructed" or profile.get("action_grade") != "reconstructed":
        raise ValueError("No attested likeness, garments or event are claimed")
    for source in original["sources"]:
        if not (root / "data/sources" / (source + ".json")).is_file():
            raise ValueError("Unresolved identity source")
    return {"person_reference_id": person["id"], "identity_grade": "attested", "appearance_grade": "reconstructed", "roles": roles,
            "age_years_bound": [60, 61], "occupation": original["occupation"]["value"],
            "household_sha256": digest(record_path), "scene_date": SCENE_DATE,
            "sources": original["sources"], "ready_for_scene": False,
            "remaining": ["civilian wardrobe source/cut", "age-appropriate skin/hair and anatomy review", "canonical master and four LODs", "actual rendered walking/standing/passenger fit"]}


def validate_worker(recipe):
    """A worker is an unregistered fallback, never an alias for either Glessner."""
    if recipe.get("scene_date") != SCENE_DATE or recipe.get("identity_kind") != "anonymous":
        raise ValueError("Work-jacket fallback must remain anonymous and 1904-qualified")
    if recipe.get("person_reference_id") is not None or recipe.get("registered") is not False:
        raise ValueError("No named work driver is established by this parcel")
    if recipe.get("fallback_only") is not True or recipe.get("ready_for_scene") is not False:
        raise ValueError("Fallback must retain explicit unaccepted/unregistered state")
    if recipe.get("garment_text_locator") != "Sears111:41R742":
        raise ValueError("Do not silently substitute an unreviewed garment source")


def add(a, b): return [x+y for x, y in zip(a, b)]
def mul(a, b): return [x*b for x in a]


class Mesh:
    def __init__(self, name, material):
        self.data = {"name": name, "material": material, "positions_m": [], "triangles": [], "uvs": [], "weights": []}

    def grid(self, rows, cols, point, weight):
        start = len(self.data["positions_m"])
        for r in range(rows+1):
            for c in range(cols+1):
                u, v = c/cols, r/rows
                self.data["positions_m"].append(point(u, v))
                self.data["uvs"].append([u, v])
                self.data["weights"].append(weight(u, v))
        for r in range(rows):
            for c in range(cols):
                a = start+r*(cols+1)+c; b = a+1; d = a+cols+1; e = d+1
                self.data["triangles"].extend([[a, b, e], [a, e, d]])


def work_jacket(body, recipe):
    """Produce original coarse garment surfaces with portable skin weights.

    The collar, sleeves, pockets and placket are geometric components. Torso
    and sleeves are separate open cloth surfaces, not claimed sewn watertight.
    No collision, material microstructure or photographic acceptance is implied.
    """
    validate_worker(recipe)
    if body.get("license") != "CC0-1.0" or body.get("units") not in ("m", "metres") or body.get("up_axis") != "+Y" or body.get("forward_axis") != "+Z":
        raise ValueError("Expected cleared metre/Y-up/+Z prepared body")
    bones = {b["name"]: b for b in body["skeleton"]}
    if len(bones) != 56:
        raise ValueError("Portable skeleton must have exactly 56 joints")
    shoulder = bones["upperarm_l"]["head_m"][1]
    neck = bones["neck_01"]["head_m"][1]
    height = body["report"]["chosen_height_m"]
    hem = height*.505
    # These are explicit original fit choices, not dimensions read from Sears.
    width, depth, front = .235, .155, .035
    meshes = []
    coat = Mesh("jacket_torso_original_cut_study", "checked_denim_reconstructed")
    def torso(u, v):
        theta = u*2*math.pi
        ease = .92+.08*v
        return [math.sin(theta)*width*ease, hem+(shoulder-hem+.015)*v, front+math.cos(theta)*depth]
    coat.grid(12, 48, torso, lambda u,v: {"spine_02": 1.0})
    meshes.append(coat.data)
    for side, sign in (("l", 1), ("r", -1)):
        sleeve = Mesh("jacket_sleeve_"+side, "checked_denim_reconstructed")
        arm = bones["upperarm_"+side]["head_m"]
        wrist = bones["hand_"+side]["head_m"]
        elbow = bones["lowerarm_"+side]["head_m"]
        def sleeve_point(u, v, arm=arm, wrist=wrist, elbow=elbow):
            center = add(mul(arm, 1-v), mul(wrist, v))
            radius = .085*(1-v)+.053*v
            return [center[0], center[1]+math.sin(u*2*math.pi)*radius, center[2]+math.cos(u*2*math.pi)*radius]
        def sleeve_weight(u, v, side=side):
            lower = max(0, min(1, (v-.34)/.3))
            return {k:w for k,w in (("upperarm_"+side,1-lower),("lowerarm_"+side,lower)) if w>0}
        sleeve.grid(14, 24, sleeve_point, sleeve_weight)
        meshes.append(sleeve.data)
    collar = Mesh("turn_down_collar_original_cut_study", "checked_denim_reconstructed")
    collar.grid(3, 32, lambda u,v: [math.sin(2*math.pi*u)*(.075+.028*v), neck-.008-.042*v,
                                  .017+math.cos(2*math.pi*u)*(.063+.022*v)], lambda u,v: {"spine_03":1.0})
    meshes.append(collar.data)
    # Multiple pockets is supported in text; count, position and cut are choices.
    for label, x, y, w, h in (("left_breast", .10, shoulder-.16, .092, .105),
                             ("left_lower", .12, hem+.09, .12, .125),
                             ("right_lower", -.12, hem+.09, .12, .125)):
        pocket = Mesh("jacket_pocket_"+label, "checked_denim_reconstructed")
        pocket.grid(4, 4, lambda u,v,x=x,y=y,w=w,h=h: [x+(u-.5)*w, y+v*h,
            front+depth*math.sqrt(max(.01,1-((x+(u-.5)*w)/width)**2))+.004], lambda u,v:{"spine_02":1.0})
        meshes.append(pocket.data)
    placket = Mesh("jacket_front_placket", "checked_denim_reconstructed")
    placket.grid(12, 2, lambda u,v: [(u-.5)*.026, hem+(shoulder-hem)*v, front+depth+.006], lambda u,v:{"spine_02":1.0})
    meshes.append(placket.data)
    # Button form/count/color are reconstruction. A disk is geometry, no logo.
    buttons = Mesh("jacket_buttons_original", "plain_button_reconstructed")
    for j in range(6):
        y = hem+.055+j*(shoulder-hem-.11)/5
        start = len(buttons.data["positions_m"])
        buttons.data["positions_m"].append([0,y,front+depth+.010])
        buttons.data["uvs"].append([.5,.5]);buttons.data["weights"].append({"spine_02":1.0})
        for i in range(12):
            t=2*math.pi*i/12
            buttons.data["positions_m"].append([.006*math.cos(t), y+.006*math.sin(t), front+depth+.010])
            buttons.data["uvs"].append([.5+.5*math.cos(t), .5+.5*math.sin(t)])
            buttons.data["weights"].append({"spine_02":1.0})
        for i in range(12): buttons.data["triangles"].append([start,start+1+i,start+1+(i+1)%12])
    meshes.append(buttons.data)
    for mesh in meshes:
        n=len(mesh["positions_m"])
        if len(mesh["uvs"])!=n or len(mesh["weights"])!=n or not all(math.isfinite(v) for p in mesh["positions_m"] for v in p):
            raise ValueError("Invalid authoring arrays")
        for w in mesh["weights"]:
            if set(w)-set(bones) or abs(sum(w.values())-1)>1e-10:
                raise ValueError("Invalid portable influence")
        for tri in mesh["triangles"]:
            if len(set(tri))!=3 or min(tri)<0 or max(tri)>=n: raise ValueError("Invalid triangle index")
    return {"format":"chicago4d_prepared_garment_study_v1", "license":"CC0-1.0", "units":"m", "up_axis":"+Y", "forward_axis":"+Z",
            "grade":"reconstructed", "scene_date":SCENE_DATE, "identity_kind":"anonymous", "person_reference_id":None,
            "fallback_only":True, "ready_for_scene":False, "source_text":SOURCE_TEXT,
            "meshes":meshes, "skeleton":body["skeleton"],
            "limitations":["Original unmeasured cut; sleeves/armholes and seams not sewn or collision-qualified", "Torso rigid to spine_02; deformation not accepted", "UVs are parametric component charts, not measured fabric scale", "No canonical Blender master, GLB, LOD, animation, actual human image or scene placement", "Not Glessner clothing or an established named driver"]}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=False)
    base=Path(__file__).resolve().parent
    profile=json.loads((base/"glessner1904.profile.json").read_text())
    resolved=resolve_named(args.root,profile)
    recipe=json.loads((base/"worker1904.recipe.json").read_text())
    body_path=args.root/"assets/authored/humans/makehuman_hm08/prepared_adult_35.json"
    garment=work_jacket(json.loads(body_path.read_text()),recipe)
    garment["body_input_sha256"]=digest(body_path)
    (args.output/"glessner1904.identity.json").write_text(json.dumps(resolved,indent=2)+"\n")
    (args.output/"worker1904.jacket.json").write_text(json.dumps(garment,separators=(",",":"))+"\n")
    print(json.dumps({"identity_resolution":"PASS", "garment_components":len(garment["meshes"]),
        "garment_triangles":sum(len(m["triangles"]) for m in garment["meshes"]), "ready_for_scene":False}))


if __name__=="__main__":main()
