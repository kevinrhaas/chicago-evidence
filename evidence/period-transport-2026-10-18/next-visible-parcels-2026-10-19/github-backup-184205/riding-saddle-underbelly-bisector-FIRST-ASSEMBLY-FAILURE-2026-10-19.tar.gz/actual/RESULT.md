# First fixed bisector actual trial: assembly FAILED

Root released exactly one fixed trial on independently reviewed source inventory865c063f, calleraceacef6 and validator584230a2. Actual exit1 after35.692771 seconds on oneCPU. No retries, offset search, geometry changes or browser followed.

The two original actual negative controls reproduced. Build, decoded readback, Khronos, actual idle0 capture and all29 shell self scopes PASS. Candidate83f7b0b927c316ec2efb360178cace360351f1e04a1431d240599ae9cc8682bd has15108 triangles/29batches. Readback verifies exact prior50463 eleven layer primitives/storage and fifteen protected original A457 mesh definitions, rig/reins/materials. Khronos has0errors,2 inherited skin warnings,29infos; this is not a zero-warning model.

Assembly failed at pair185 of the required301 interpart pairs. Actual quarter_l face1010 intersects stirrup_leather_l face14 strictly properly. First recorded rawSAT1/proper1; no interface certificate applies. Witness point is approximately(0.3156474714,1.2992442991,-0.0675000027)m, with strict face barycentrics(0.5549821,0.1573411,0.2876768). Full coordinates and unchanged predicate witness are in fit/fit.json. This is an unchanged eleven-layer quarter against a protected original stirrup leather; the saved readback establishes that ownership, not a complete historical failure diagnosis.

Only184 interpart pairs completed before the failing185th. The remainder and all wholehorse qualification were NOT run. No final stand-off, pressure/load, rider, motion, period visual, photographic or production acceptance follows. All actual inputs, sources, readback, captures and failures are retained. Further diagnosis or authoring scope requires root review; no contact exemption or collision threshold was widened.
