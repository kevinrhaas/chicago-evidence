"""Benign owned-process controls of actual caller handler, no asset evaluation."""
from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys,time
BASE=Path('/workspace/shared')
CALLER=BASE/'riding-saddle-underbelly-bisector-caller.py'
spec=importlib.util.spec_from_file_location('reviewed_caller',CALLER)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
OUT=BASE/'riding-saddle-underbelly-bisector-HANDLER-CONTROLS.json'
rows=[]

def child():
 return subprocess.Popen([sys.executable,'-c','import time;time.sleep(30)'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)

class InterruptOnce:
 def __init__(self,p,error):self.p=p;self.pid=p.pid;self.error=error;self.calls=0
 @property
 def returncode(self):return self.p.returncode
 def wait(self,timeout=None):
  self.calls+=1
  if self.calls==1:raise self.error
  return self.p.wait(timeout=timeout)

def control(name,p,expected_error=None,timeout=2):
 stage={};caught=None
 try:result=module.wait_owned(p,timeout,stage)
 except BaseException as error:caught=error
 assert p.returncode is not None,'Owned child must be reaped'
 assert (caught is None)if expected_error is None else isinstance(caught,expected_error)
 if expected_error is not None:assert stage['timed_out']==(expected_error is subprocess.TimeoutExpired)
 rows.append({'name':name,'passed':True,'pid':p.pid,'exit_code':p.returncode,'expected_exception':expected_error.__name__ if expected_error else None,'actual_exception':type(caught).__name__ if caught else None,'stage':stage})

control('normal_exit',subprocess.Popen([sys.executable,'-c','pass'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True))
control('timeout_stops_reaps_owned',child(),subprocess.TimeoutExpired,.01)
control('keyboard_interrupt_stops_reaps_owned',InterruptOnce(child(),KeyboardInterrupt('control')),KeyboardInterrupt)
p=subprocess.Popen([sys.executable,'-c','pass'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True);p.wait(timeout=2)
control('already_gone_group_preserves_failure',InterruptOnce(p,RuntimeError('control')),RuntimeError)
receipt={'passed':True,'scope':'Actual exact wait_owned handler on benign owned local Python processes only; no model/GLB/capture/SAT/browser','caller_sha256':hashlib.sha256(CALLER.read_bytes()).hexdigest(),'rows':rows,'actual_asset_trial_run':False}
with OUT.open('x')as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt,indent=2))
