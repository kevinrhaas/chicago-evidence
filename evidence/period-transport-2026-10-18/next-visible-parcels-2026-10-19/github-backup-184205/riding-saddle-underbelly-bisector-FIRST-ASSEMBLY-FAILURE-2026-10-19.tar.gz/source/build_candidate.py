# SPDX-License-Identifier: CC0-1.0
"""SOURCE ONLY fixed eleven layers plus three underbelly bands and six leathers; exact authored A457 rein skin retained."""
from pathlib import Path
import argparse,json,struct,hashlib,math,copy
from topology import cross3
from layer_authority import Authority,CHANGED as LAYER_CHANGED
from underbelly_construction import construct,CHANGED_EXTRA
CHANGED=LAYER_CHANGED|CHANGED_EXTRA
PINS={'gear':'a457874a81b624f5e9642d3296b1350eb49b17d21d38099fbe66080711c17021','horse':'6e9b37b755ae3eda7b5cf2f492d1781b0e507664a99c88a2e6dee086f77c2296'}

def need(ok,msg):
 if not ok:raise ValueError(msg)
def decode(raw):
 need(struct.unpack_from('<III',raw)==(0x46546c67,2,len(raw)),'GLB header');n,t=struct.unpack_from('<II',raw,12);need(t==0x4e4f534a,'JSON');d=json.loads(raw[20:20+n]);size,t=struct.unpack_from('<II',raw,20+n);need(t==0x004e4942 and len(raw)==28+n+size,'BIN');return d,bytearray(raw[28+n:])
def read(d,b,i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];count={'SCALAR':1,'VEC3':3,'VEC4':4}[a['type']];fmt={5126:'f',5125:'I',5123:'H'}[a['componentType']];need('byteStride'not in v and 'sparse'not in a,'Plain source accessor');x=struct.unpack_from('<'+fmt*a['count']*count,b,v.get('byteOffset',0)+a.get('byteOffset',0));return list(zip(*[iter(x)]*count))
def append(d,b,rows,kind,component):
 while len(b)%4:b.append(0)
 off=len(b);fmt='f'if component==5126 else'I';flat=[v for row in rows for v in row];b.extend(struct.pack('<'+fmt*len(flat),*flat));vi=len(d['bufferViews']);d['bufferViews'].append({'buffer':0,'byteOffset':off,'byteLength':len(b)-off});a={'bufferView':vi,'componentType':component,'count':len(rows),'type':kind}
 if kind=='VEC3':a.update(min=[min(x[i]for x in rows)for i in range(3)],max=[max(x[i]for x in rows)for i in range(3)])
 d['accessors'].append(a);return len(d['accessors'])-1

def produce(gear_path,horse_path,manifest_path,params_path,layer_control,out):
 # Own output before model evaluation; never overwrite an earlier candidate.
 out.mkdir()
 try:
  need(hashlib.sha256(Path(__file__).with_name('layer_authority.py').read_bytes()).hexdigest()=='517795df5f6dbd6995c35a50d08b63b76eac82895cca0910d0b84a1fc022e467','Exact unchanged eleven-layer authority source')
  need(hashlib.sha256(params_path.read_bytes()).hexdigest()=='ec719b2c56ca15d0281d828b67a6d801970aa92574651b00475e7294fb798c67','Exact unchanged eleven-layer recipe')
  raw=gear_path.read_bytes();hr=horse_path.read_bytes();need(hashlib.sha256(raw).hexdigest()==PINS['gear'],'Exact A457 gear input');need(hashlib.sha256(hr).hexdigest()==PINS['horse'],'Exact retained6e9b horse');d,b=decode(raw);hd,hb=decode(hr);params=json.loads(params_path.read_text());manifest_bytes=manifest_path.read_bytes();need(hashlib.sha256(manifest_bytes).hexdigest()=='f2b4710e2d65037ad84dd059c21d1bfb3ae6f1f751b9c794931dc73397d6d094','Pinned retained horse ownership manifest');p=json.loads(manifest_bytes);need(p['license']=='CC0-1.0','Retained horse provenance');r=[x for x in p['vertex_ranges']if x['original_node']=='continuous_body_neck'];need(len(r)==1,'Unique actual torso owner');lo=r[0]['vertex_start'];hi=lo+r[0]['vertex_count'];hm=[x for x in hd['meshes']if x['name']=='skinned_equine_coat'];need(len(hm)==1,'Actual coat mesh');pr=hm[0]['primitives'][0];vs=read(hd,hb,pr['attributes']['POSITION']);ids=[x[0]for x in read(hd,hb,pr['indices'])];triangles=[[vs[ids[i+k]]for k in range(3)]for i in range(0,len(ids),3)if all(lo<=ids[i+k]<hi for k in range(3))];need(bool(triangles),'Nonempty actual torso surface')
  def ray(origin,direction):
   hits=[]
   for a,bv,c in triangles:
    e1=[bv[k]-a[k]for k in range(3)];e2=[c[k]-a[k]for k in range(3)];h=cross3(direction,e2);det=math.fsum(e1[k]*h[k]for k in range(3))
    if abs(det)<1e-12:continue
    inv=1/det;s=[origin[k]-a[k]for k in range(3)];u=inv*math.fsum(s[k]*h[k]for k in range(3));q=cross3(s,e1);v=inv*math.fsum(direction[k]*q[k]for k in range(3));t=inv*math.fsum(e2[k]*q[k]for k in range(3))
    if min(u,v)>=-1e-10 and u+v<=1+1e-10 and t>=0:hits.append(t)
   need(bool(hits),'Missing actual torso ray');return max(hits)
  surfaces,owners=Authority(params,ray).emit()
  previous,pb=decode(layer_control.read_bytes());need(hashlib.sha256(layer_control.read_bytes()).hexdigest()=='50463c358935677ce0413ae58006dba9df1cfadf21b477df18492042bd1683b5','Exact first layer control')
  for name,(v,n,faces)in surfaces.items():
   cp=next(m for m in previous['meshes']if m['name']==name)['primitives'][0]
   for kind,rows in [('POSITION',v),('NORMAL',n)]:
    expected=read(previous,pb,cp['attributes'][kind]);need(struct.pack('<'+'f'*(len(rows)*3),*(x for row in rows for x in row))==struct.pack('<'+'f'*(len(expected)*3),*(x for row in expected for x in row)),'All eleven actual layer attributes fixed '+name+'/'+kind)
   need([i for face in faces for i in face]==[x[0]for x in read(previous,pb,cp['indices'])],'All eleven actual layer indices fixed '+name)
  rebuilt,construction=construct(triangles,surfaces,params);surfaces.update(rebuilt);owners.update(construction['component_ranges'])
  names=[x['name']for x in d['meshes']];need(len(names)==29 and len(set(names))==29 and CHANGED<=set(names),'Exact original29 mesh cohort')
  before=bytes(b);ledger={}
  for name,(v,n,faces)in surfaces.items():
   mesh=d['meshes'][names.index(name)];need(len(mesh['primitives'])==1,'Original single primitive');old=mesh['primitives'][0];need(set(old['attributes'])=={'POSITION','NORMAL'},'Selected original rigid surface');mesh['primitives']=[{'attributes':{'POSITION':append(d,b,v,'VEC3',5126),'NORMAL':append(d,b,n,'VEC3',5126)},'indices':append(d,b,[(i,)for f in faces for i in f],'SCALAR',5125),'material':old['material']}];ledger[name]={'vertices':len(v),'triangles':len(faces),'bounds':{'min':[min(x[k]for x in v)for k in range(3)],'max':[max(x[k]for x in v)for k in range(3)]}}
  need(bytes(b[:len(before)])==before,'Original BIN prefix');d['buffers'][0]['byteLength']=len(b);d['asset']['generator']='Original three-underbelly-girth/six-leather construction study; exact A457 rein skin retained';j=json.dumps(d,separators=(',',':')).encode();j+=b' '*((-len(j))%4);result=struct.pack('<III',0x46546c67,2,28+len(j)+len(b))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(b),0x004e4942)+b
  (out/'candidate.glb').write_bytes(result);receipt={'passed':True,'status':'UNACCEPTED candidate; requires actualgeometry/idlefit/browser review','input_sha256':PINS,'candidate_sha256':hashlib.sha256(result).hexdigest(),'parameters_sha256':hashlib.sha256(params_path.read_bytes()).hexdigest(),'horse_manifest_sha256':hashlib.sha256(manifest_path.read_bytes()).hexdigest(),'source_binary_prefix_bytes':len(before),'changed_surfaces':ledger,'authored_part_sections':owners,'underbelly_construction':construction,'layer_control_sha256':hashlib.sha256(layer_control.read_bytes()).hexdigest(),'previous_five_part_protection_explicitly_superseded_by_fourteen_part_ownership':True,'other15meshdefs_exact':all(d['meshes'][i]==decode(raw)[0]['meshes'][i]for i,n in enumerate(names)if n not in CHANGED),'nodes_skins_animations_exact':all(d.get(k)==decode(raw)[0].get(k)for k in ['nodes','skins','animations','scenes','scene','materials']),'source_scope':'Prior retained construction-text dossier only; no primary visual/registry or1835Chicago ownership attestation','motion_fit_qualified':False,'ab70_fit_qualified':False,'rider_fit_qualified':False};(out/'proof.json').write_text(json.dumps(receipt,indent=2)+'\n');return receipt
 except BaseException as e:
  (out/'failure.json').write_text(json.dumps({'passed':False,'error':repr(e)},indent=2)+'\n');raise
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--gear-input',type=Path,required=True);a.add_argument('--horse-input',type=Path,required=True);a.add_argument('--horse-manifest',type=Path,required=True);a.add_argument('--parameters',type=Path,required=True);a.add_argument('--layer-control',type=Path,required=True);a.add_argument('--output-dir',type=Path,required=True);p=a.parse_args();print(json.dumps(produce(p.gear_input,p.horse_input,p.horse_manifest,p.parameters,p.layer_control,p.output_dir)))
