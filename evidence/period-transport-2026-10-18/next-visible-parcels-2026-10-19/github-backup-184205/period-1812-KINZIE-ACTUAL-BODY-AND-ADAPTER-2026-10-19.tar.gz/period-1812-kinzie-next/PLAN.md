# First named 1812 person: John Kinzie the elder

This is a proposed identity/card and a bounded original wardrobe design, outside the application. Nothing is installed, rendered, scene-placed or photographically accepted. No network source was fetched.

Use John Kinzie the elder, whose house already stands in the scene. The proposed person is inferred from existing source text. He is not his son John Harris Kinzie, whose existing 1835 identity must remain separate. The source gives birth year 1763; the target is 1812-08-14, so age is 48 or 49. Use 49 only as a body-authoring parameter. Do not borrow the existing age-25 or age-35 human and relabel it.

The first visible increment can be his named resident card through the existing `residents_1812/households/` compiler path. The actual `scene_people_manifest` already supports any non-1835 scene; no new identity schema or anonymous fallback is needed. Candidate record: `households/hh_kinzie_john_elder.json`. Install under `data/residents_1812/households/`, then compile scene into actual sidecars and inspect the card. The proposed record passes the existing compiler's scratch manifest validation; this is not an installed directory or world figure.

The household carries only this selected adult. It makes no population claim about omitted wife, children or staff. His presence on August 14 is inferred between the recorded August 12 council and August 15 march. It does not assert he stood at his house at 15:00. Locators are exact spans in the locally committed OCR, with compiler/family-narrative mediation stated. Claims and source-file hashes are supplied separately.

## Appearance and action

Begin with standing and walking in an isolated period study. Appearance, clothes, height and action are reconstructed. No portrait or face source was opened; no likeness is claimed. Use a separately prepared cleared CC0 mature adult body, preserve the portable 56-joint skeleton, metre/Y-up/+Z frame and all four LOD contracts. The age-49 body and age-appropriate skin/hair treatment still require actual export and close inspection. The existing generic skin atlas may be a cleared engineering input but does not identify Kinzie's complexion.

The accompanying recipe chooses a plain shirt, short waistcoat, proposed fall-front trousers and low closed shoes. These are original provisional civilian choices; the current local sources do not establish cut or an outfit worn by him. Before wardrobe acceptance, obtain a pre-1812 American garment or reliable dated pattern/object view through an allowed host and inspect the actual pixels. Do not certify an 1835 shell as 1812 by changing metadata. No fringe, ceremonial items, military insignia, culturally diagnostic ornament or named garment ownership is invented.

The locally read August 13 goods list mentions broadcloth and calico, establishing goods in the narrative, not the fibre or colour of his clothes. The Bradbury deerskin-coat comparison belongs to its own Missouri traveler, not Kinzie. No outer hunting coat is therefore assigned here. Palette and dimensions are explicitly reconstructed.

## Transport boundary

The narrative describes evacuation wagons on August 15. It does not state their body type, wheel construction, exact count, maker, dimensions, horses, ownership or an August 14 street movement. Do not identify an 1835 W01 prototype as this documented wagon. A simple early utility wagon can later be built as a reconstructed example after its era design is bounded, but cannot be called Kinzie's wagon.

Kinzie's family boat journey is also August 15. His own reported 1804 horseback journey is a lead for riding history, not evidence for a saddle or riding event on August 14. He is not labeled a professional driver. Riding/passenger/driver actions remain separate reconstructed choices requiring the actual fitted horse, reins, saddle or safe vehicle seat. No battle, evacuation procession, council or ceremony is staged in this first standing/walking example.

## Integration sequence

1. Root reviews and integrates the proposed household with a real LIBERTIES entry for appearance/action; no invented liberty number is supplied here.
2. Compile the real 1812 directory and summary bindings; inspect the named card and ensure no 1835 people leak into it. Preserve target date and existing review metadata. Do not add the legacy `residents` drawer layer blindly: it contains 1835-specific population/order-book panels.
3. Generalize the human builder's identity resolver in a separately reviewed change. Its present implementation explicitly requires scene 1835, reconstructed identity and `reconstructed_trades`; those guards must not simply be deleted or bypassed. Resolve exact scene-specific household root, actual compiled person, identity grade, presence, source snapshot and date-qualified wardrobe instead.
4. Build a distinct mature body and actual early-period clothing branch, export/validate four LODs, and inspect neutral-light desktop/mobile close views. Preserve source and published path parity, body normals, seam and deformation guards.
5. Add an eligible named portable instance only after the actual asset is accepted for 1812. Place walking/standing through terrain/collision checks with reconstructed daily position recorded. Do not place him in 1835 or 1904.

The scene note still carries a superseded figure-prohibition paragraph. The current AGENTS.md owner rulings permit evidence-bounded figures; preserve the historical review flags but update stale explanatory prose when the actual figure is integrated. Neither that prose nor research incompleteness is a new owner-approval requirement.

## Current limits

This parcel creates a concrete candidate household suitable for the existing compiler and a reviewable source-only wardrobe recipe. It does not supply a mature body, sewn garment pattern, actual model, actor, photograph match, motion, world placement or completed 1812 transport scene. The next visible card integration is straightforward; photographic human production remains substantial work.
