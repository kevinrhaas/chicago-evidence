# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicit original 1812 mature-body authoring seam; no default scene path.

No BPy import occurs until validated create_body_study(). This creates a bare
anatomy/rig authoring study, not a clothed actor, canonical master, LOD or GLB.
The existing 1835 builder and its strict identity/era guard remain untouched.
"""
from pathlib import Path
import hashlib
import json
import math

DATE = "1812-08-14"
PERSON = "kinzie_john_elder"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def validate(root, parcel, body_bytes):
    """Validate exact outside-app identity/body source before any BPy mutation."""
    root, parcel = Path(root), Path(parcel)
    pins = json.loads((parcel / "BODY-INPUT-PINS.json").read_text())
    for name, digest in pins.items():
        path = parcel / name
        require(hashlib.sha256(path.read_bytes()).hexdigest() == digest,
                "Changed authoring input: " + name)
    require(hashlib.sha256(body_bytes).hexdigest() == pins["kinzie_age49.body.json"],
            "Actual body bytes differ from reviewed age49 input")
    scene = json.loads((root / "data/scenes/1812.json").read_text())
    require(scene["target_date"] == DATE, "1812 target changed; review identity")
    record = json.loads((parcel / "households/hh_kinzie_john_elder.json").read_text())
    require(record["scene"] == "1812" and record["head"] == PERSON,
            "Wrong historical identity or era")
    require(record["present_on_scene_date"]["value"] == "present" and
            record["present_on_scene_date"]["confidence"] == "inferred",
            "Date-qualified presence changed")
    people = record["persons"]
    require(len(people) == 1 and people[0]["id"] == PERSON and
            people[0]["grade"] == "inferred", "Do not replace or upgrade identity")
    require(people[0]["born"]["value"] == "1763", "Birth-year basis changed")
    for sid in people[0]["sources"]:
        require((root / "data/sources" / (sid + ".json")).is_file(),
                "Identity source does not resolve")
    profile = json.loads((parcel / "kinzie_john_elder_1812.recipe.json").read_text())
    require(profile["scene"] == "1812" and profile["target_date"] == DATE and
            profile["person_reference_id"] == PERSON and
            profile["person_reference_grade"] == "inferred" and
            profile["appearance_grade"] == "reconstructed" and
            profile["production_eligible"] is False and
            profile["likeness_claim"] is False,
            "Only unaccepted reconstructed mature-body study is permitted")
    body = json.loads(body_bytes)
    require(body["license"] == "CC0-1.0" and body["units"] == "m" and
            body["up_axis"] == "+Y" and body["forward_axis"] == "+Z",
            "Cleared metre/Y-up/+Z body required")
    phenotype = body["target_blend"]["phenotype"]
    require(phenotype["chosen_age_years"] == 49 and
            phenotype["age_band_years"] == [48, 49], "Wrong mature-body target")
    require(abs(body["report"]["chosen_height_m"] - 1.75) < 1e-9,
            "Reconstructed height changed")
    contract = json.loads((root / "data/humans/contract.json").read_text())
    expected = dict(contract["skeleton"]["bones"])
    bones = {b["name"]: b for b in body["skeleton"]}
    require(len(bones) == len(body["skeleton"]) == 56 and set(bones) == set(expected),
            "Exactly the portable56 joints are required")
    for name, parent in expected.items():
        b = bones[name]
        require(b["parent"] == parent, "Portable parent differs: " + name)
        require(len(b["head_m"]) == len(b["tail_m"]) == 3 and
                all(math.isfinite(v) for v in b["head_m"] + b["tail_m"]) and
                math.dist(b["head_m"], b["tail_m"]) > 1e-6,
                "Invalid rest bone: " + name)
    for mesh in body["meshes"]:
        count = len(mesh["positions_m"])
        require(count and count == len(mesh["uvs"]) == len(mesh["weights"]),
                "Incomplete prepared arrays")
        require(all(len(p) == 3 and all(math.isfinite(v) for v in p)
                    for p in mesh["positions_m"]), "Nonfinite body coordinate")
        require(all(len(uv) == 2 and all(math.isfinite(v) for v in uv)
                    for uv in mesh["uvs"]), "Invalid UV")
        for tri in mesh["triangles"]:
            require(len(tri) == len(set(tri)) == 3 and
                    all(isinstance(i, int) and 0 <= i < count for i in tri),
                    "Invalid triangle")
        for weights in mesh["weights"]:
            require(1 <= len(weights) <= 4 and not(set(weights) - set(expected)) and
                    all(math.isfinite(v) and v > 0 for v in weights.values()) and
                    abs(math.fsum(weights.values()) - 1) < 1e-6,
                    "Invalid portable skin influences")
    return body, contract


def create_body_study(root, parcel, body_bytes, *, caller_authoring_only,
                      name="kinzie_elder_1812_unaccepted_anatomy"):
    """Create a separate explicit collection in an empty authoring scene.

    The caller owns an existing empty authoring scene and may save an isolated
    study. It must not export/register this as an eligible dressed person.
    """
    require(caller_authoring_only is True, "Explicit isolated authoring caller required")
    body, contract = validate(root, parcel, body_bytes)
    import bpy
    require(bpy.context.mode == "OBJECT", "Authoring caller must start in object mode")
    require(len(bpy.context.scene.objects) == 0,
            "Use an empty isolated authoring scene; never attach a bare body to a town")
    require(name not in bpy.data.collections, "Existing study must never be overwritten")
    collection = bpy.data.collections.new(name)
    bpy.context.scene.collection.children.link(collection)
    arm = bpy.data.armatures.new(name + "_skeleton")
    rig = bpy.data.objects.new(name + "_rig", arm)
    collection.objects.link(rig)
    bpy.context.view_layer.objects.active = rig
    rig.select_set(True)
    def frame(p):
        return (p[0], -p[2], p[1])
    bones = {b["name"]: b for b in body["skeleton"]}
    bpy.ops.object.mode_set(mode="EDIT")
    try:
        for joint, _ in contract["skeleton"]["bones"]:
            bone = arm.edit_bones.new(joint)
            bone.head, bone.tail = frame(bones[joint]["head_m"]), frame(bones[joint]["tail_m"])
            bone.roll = 0  # Engineering roll, not accepted anatomical roll.
        for joint, parent in contract["skeleton"]["bones"]:
            if parent:
                arm.edit_bones[joint].parent = arm.edit_bones[parent]
                arm.edit_bones[joint].use_connect = False
    finally:
        bpy.ops.object.mode_set(mode="OBJECT")
    objects = []
    for source in body["meshes"]:
        mesh = bpy.data.meshes.new(name + "_" + source["name"])
        mesh.from_pydata([frame(v) for v in source["positions_m"]], [], source["triangles"])
        mesh.update()
        uv = mesh.uv_layers.new(name="UVMap")
        for poly in mesh.polygons:
            poly.use_smooth = True
            for loop in poly.loop_indices:
                uv.data[loop].uv = source["uvs"][mesh.loops[loop].vertex_index]
        obj = bpy.data.objects.new(mesh.name, mesh)
        collection.objects.link(obj)
        for joint, _ in contract["skeleton"]["bones"]:
            obj.vertex_groups.new(name=joint)
        for i, weights in enumerate(source["weights"]):
            for joint, value in weights.items():
                obj.vertex_groups[joint].add([i], value, "REPLACE")
        obj.modifiers.new("skin", "ARMATURE").object = rig
        obj["production_eligible"] = False
        obj["appearance_grade"] = "reconstructed"
        obj["acceptance"] = "Bare anatomy authoring only; no clothes, likeness, LODs or motion"
        objects.append(obj)
    collection["person_reference_id"] = PERSON
    collection["identity_grade"] = "inferred"
    collection["scene_date"] = DATE
    collection["ready_for_scene"] = False
    return {"collection": collection, "rig": rig, "objects": objects}
