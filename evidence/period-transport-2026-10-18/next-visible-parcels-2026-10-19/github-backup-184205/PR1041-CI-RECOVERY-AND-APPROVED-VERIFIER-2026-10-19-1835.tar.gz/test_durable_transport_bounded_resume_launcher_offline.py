import pathlib,importlib.util,tempfile,unittest.mock as mock,hashlib,json,stat,subprocess,os
p=pathlib.Path('/workspace/shared/launch_durable_transport_observer_bounded_resume.py');sp=importlib.util.spec_from_file_location('d',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
root=pathlib.Path(tempfile.mkdtemp(prefix='durable-observer-offline-',dir='/workspace/shared'));source=root/'fixture.py';source.write_text('# synthetic; never executed\n');digest=hashlib.sha256(source.read_bytes()).hexdigest();results=[]
class Child:
 pid=999999
 def terminate(self):pass
 def wait(self,timeout):return 0
calls=[]
def popen(cmd,**kw):
 assert kw['stdin']==subprocess.DEVNULL and kw['start_new_session'] is True and kw['close_fds'] is True
 assert stat.S_ISREG(os.fstat(kw['stdout'].fileno()).st_mode)and stat.S_ISREG(os.fstat(kw['stderr'].fileno()).st_mode)
 assert cmd[cmd.index('--max-seconds')+1]=='4000'
 calls.append(cmd);return Child()
def call(name,out,expected,existing=None,sha=digest,bound=4000):
 args=['x','--source',str(source),'--source-sha256',sha,'--dispatch',str(root/'dispatch.json'),'--canonical',str(root/'can.json'),'--out',str(out),'--max-seconds',str(bound),'--launch']
 try:
  with mock.patch('sys.argv',args),mock.patch.object(m,'observers',return_value=existing or []),mock.patch.object(m,'identity',side_effect=lambda pid:{'pid':pid,'start_ticks':'123','boot_id':'fixture'}),mock.patch.object(m.os,'getsid',return_value=999999),mock.patch.object(m.subprocess,'Popen',side_effect=popen):m.main()
  ok=True
 except Exception:ok=False
 results.append({'name':name,'actual_accept':ok,'expected_accept':expected,'passed':ok==expected})
out=root/'evidence';call('mock detached process regular files and receipt before go',out,True);assert (root/'evidence.launch.json').exists()and(root/'evidence.owner-lock/go').exists();call('same output/lock cannot launch twice',out,False);call('existing observer refused',root/'existing',False,[{'pid':1}]);call('wrong source hash refused',root/'wronghash',False,sha='0'*64)
call('zero time refused',root/'zerotime',False,bound=0);call('more than180min refused',root/'overtime',False,bound=10801)
assert json.loads((root/'evidence.launch.json').read_text())['wall_seconds']==4000
r={'scope':'OFFLINE mock Popen only; NO process/browser/API/observer launched','controls':results,'mock_popen_calls':len(calls),'PASS':all(x['passed']for x in results)};pathlib.Path('/workspace/shared/durable-transport-bounded-resume-launcher-offline.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));assert r['PASS']and len(calls)==1
