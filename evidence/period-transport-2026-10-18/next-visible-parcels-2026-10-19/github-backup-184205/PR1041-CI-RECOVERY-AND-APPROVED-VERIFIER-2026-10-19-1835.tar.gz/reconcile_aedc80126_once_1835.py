#!/usr/bin/env python3
"""One root-authorized fresh metadata reconciliation after proved observer death; no polling or retries."""
import importlib.util,pathlib,json,time,hashlib,datetime,sys
S=pathlib.Path('/workspace/shared');W=S/'watch_transport_metadata_dev28c53.py'
assert hashlib.sha256(W.read_bytes()).hexdigest()=='e34bd7b051a91db35d17ff0e34613925c74149935089f7cfc38236ed91754ae4'
spec=importlib.util.spec_from_file_location('watch',W);w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
O=S/'aedc80126-fresh-reconciliation-1835';O.mkdir(exist_ok=False)
smoke,can,sha,expected=w.load_dispatches(S/'transport-smoke-dispatch-c02-aedc80126.json',S/'human-seated-dispatch-aedc80126.json')
assert sha=='aedc80126c6178376d3fb60f40297bec5c7c9ec7'
api=w.MetadataAPI(time.monotonic()+45,O)
report={'scope':'ONE new bounded metadata snapshot after original observer death and >1h interval; no repeated polling/logs/artifacts/POST/retry','sha':sha,'started_utc':w.now(),'success':False,'final_verifier_executed':False,'merge_qualified':False}
jobs=w.json.loads((S/'final-aedc80126-metadata/terminal-jobs.json').read_text())
try:
 listing=api.get(f'repos/{w.REPO}/actions/workflows/{w.SMOKE}/runs?head_sha={sha}&event=workflow_dispatch&per_page=100')
 smokeids={i for i,x in expected.items()if x['workflow']==w.SMOKE}
 assert listing['total_count']==len(listing['workflow_runs'])==18 and {x['id']for x in listing['workflow_runs']}==smokeids
 runs={x['id']:x for x in listing['workflow_runs']};cid=next(i for i,x in expected.items()if x['workflow']==w.CANONICAL)
 runs[cid]=api.get(f'repos/{w.REPO}/actions/runs/{cid}')
 for rid,meta in runs.items():w.validate_meta(meta,rid,expected[rid],sha,smoke['branch'])
 checks=api.get(f'repos/{w.REPO}/commits/{sha}/check-runs?per_page=100')
 pr=api.get(f'repos/{w.REPO}/pulls/1041')
 assert pr['head']['sha']==sha and pr['head']['ref']==smoke['branch'] and pr['state']=='open' and pr['base']['ref']=='dev'
 snap={'at':w.now(),'sha':sha,'pr_head':pr['head']['sha'],'pr_head_matches':True,'pr_draft':pr.get('draft'),'missing_run_ids':[],'runs':[w.run_meta(x)for _,x in sorted(runs.items())],'checks_total_count':checks['total_count'],'check_list_truncated':checks['total_count']!=len(checks['check_runs']),'check_runs':checks['check_runs']}
 w.save(O/'latest.json',snap)
 for rid,meta in sorted(runs.items()):
  if meta['status']=='completed' and str(rid) not in jobs:
   jobs[str(rid)]=w.terminal_jobs(api,rid,meta,expected[rid],sha);w.save(O/'terminal-jobs.json',jobs)
 w.save(O/'terminal-jobs.json',jobs)
 report.update(w.summary(snap,expected,jobs),success=True,statuses=dict(w.Counter(x['status']for x in snap['runs'])),conclusions=dict(w.Counter(x['conclusion']or'pending'for x in snap['runs'])),current_check_states=dict(w.Counter((x['status']+'/'+str(x['conclusion']))for x in checks['check_runs'])),current_check_list_complete=not snap['check_list_truncated'])
except Exception as e:report['error']=str(e)
finally:
 report.update(finished_utc=w.now(),metadata_requests=api.count);w.save(O/'summary.json',report);print(json.dumps(report,indent=2))
sys.exit(0 if report['success']else 1)
