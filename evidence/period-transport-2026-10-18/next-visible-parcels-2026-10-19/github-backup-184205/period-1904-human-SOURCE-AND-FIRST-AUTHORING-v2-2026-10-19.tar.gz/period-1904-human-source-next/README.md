# 1904 human authoring inputs — unaccepted construction parcel

This parcel changes no application file or person record. It supplies concrete original source and generated authoring arrays, not a production character or a canonical Blender master. John Glessner's attested identity is kept separate from reconstructed appearance and demonstration actions.

## Actual work

* Read the actual 1904 scene, compiled people index and Glessner household. Only John and Frances are present in the existing people index; the household explicitly excludes unnamed staff. No existing named driver can be selected from these records. No source search outside the already committed dossier was attempted through blocked network hosts.
* Prepared a mature engineering body using verified CC0 MakeHuman graphical target data and the existing preprocessor. John's 1843 year-only birth record bounds age to 60–61 on July 1, 1904. The age61/1.75m body is an authoring choice, not a portrait, physical measurement, or exact birth-date claim. The software-category blend is not an ethnicity inference. Age-specific skin/hair and anatomy are not completed.
* `period1904.resolve_named` checks the real scene, compiled identity, household, sources, grade, presence, birth year and occupation. It accepts only reconstructed standing, walking and passenger roles; it rejects a driver/rider claim and wrong-era residents. This is a caller safeguard, not historical evidence of a particular event.
* Generated a separate reusable checked-denim working-jacket construction: 9 components, 2,904 triangles, portable weights and UV arrays. The earlier dossier's actual Sears Spring1902 OCR reading, article41R742, supports only the component vocabulary (black/white hairline checked denim; coat buttons to neck; turn-down collar; multiple pockets). No page pixels or garment patterns were read here. Exact cut, dimensions, pocket count/position, buttons, fabric scale, drape and combination with other garments are original reconstruction. It is an anonymous, unregistered fallback study; it is NOT assigned to either Glessner and does not mint a coachman's identity.
* Added an explicit-caller Blender adapter using the existing 56-joint rig and source +Y/+Z to Blender +Z/-Y frame. It checks exact body bytes, source license/axes, exact body skeleton and contract parents, and anonymous fallback metadata. Its required actor_context rejects named people before BPy/rig access. BPy was not installed or executed. The existing 1835 builder was not edited or generalized around its strict era guard.
* Actual source/array checks and sixteen refusal controls pass. No collision test, browser image, canonical master, exported GLB, four-LOD result, animation or person placement is claimed.

## Important geometry limits

The working-jacket output is a coarse construction, not accepted tailoring: open torso and sleeve surfaces are separate, with unsewn/overlapping armhole boundaries. The torso binds rigidly to spine02. Pocket/placket/collar surfaces are independent. No collision, seam continuity, thickness, deformation, cloth material, body fit or photographic review is established. The material name is a specification only; no actual checked textile image or shader has been generated. Do not install this coarse output as a photographic asset or count it as a finished 1904 person.

John's civilian wardrobe remains a separate missing source/cut task. The Sears work jacket does not establish the clothing of a farm-machinery executive. A named passenger must not silently acquire a work-driver uniform to make an interaction demo available sooner.

## Reproduce authoring inputs

From the application checkout (no Blender/network):

```
python tools/human_base_prepare.py --target-recipe /workspace/shared/period-1904-human-source-next/glessner_age61.recipe.json --output NEW_BODY.json
python /workspace/shared/period-1904-human-source-next/period1904.py --root "$PWD" --output NEW_OUTPUT_DIRECTORY
```

The latter requires a new output directory, refusing to overwrite an earlier receipt. `blender_garment_adapter.attach` is a future explicit integration seam only; no default code path calls it.

## Sources and licenses

Identity sources resolve in the existing source registry: `habs_glessner_house_il_1015_data_pages` and `glessner_house_family_page`. The resolved receipt preserves these IDs and the actual household hash; their evidence concerns identity and occupation, not a new likeness or wardrobe. The Sears OCR URL is a text citation, not a fabricated source registry ID. Publication1902 gives a reasoned US public-domain basis; archive metadata rights have not been independently verified here. No unknown-rights image-derived geometry or pixels are used.

Original Python source: GPL-3.0-or-later. Original garment geometry and new body target recipe/output dedication: CC0-1.0. Body inputs depend on the checkout's MakeHuman `SOURCE.json` and original per-file CC0 headers/notices, checked by `human_base_prepare.py`; they retain their existing provenance. Source-code license is separate from the upstream graphical data and generated output. The parcel inventory pins exact external source bytes without copying third-party program logic.

## Next concrete acceptance work

Acquire and inspect period civilian garment cut/object references for John and clear any named likeness sources. Build a mature skinned/haired canonical master. Replace the coarse jacket study with sewn pattern construction and fit its body/pose deformation before any scene eligibility. A work driver still requires an era-qualified person assignment (existing researched identity first, otherwise explicit fallback), shoes/trousers/shirt, actual seated rein/footboard fit and ordinary canonical export/LOD/render gates. None of those tickets is closed here.

## Independent review correction

period_1812 found that the first adapter relied on documentation for anonymous-only use and checked only skeleton names. The first archive is preserved. The v2 adapter enforces anonymous/unregistered/fallback-only metadata, exact license/axes, exact body skeleton plus contract parents, and an explicit anonymous nonproduction actor_context before any BPy mutation. Sixteen source/refusal controls pass, including a named Glessner caller rejection before BPy import. Geometry is unchanged. The first eight-control receipt remains historical; SOURCE-CHECKS-v2.json is current.
