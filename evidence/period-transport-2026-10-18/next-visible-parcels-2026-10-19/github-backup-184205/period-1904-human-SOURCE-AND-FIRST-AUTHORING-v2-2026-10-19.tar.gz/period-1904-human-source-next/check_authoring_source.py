# SPDX-License-Identifier: GPL-3.0-or-later
"""No Blender execution: qualify refusal guards and actual prepared mesh arrays."""
from pathlib import Path
import argparse
import copy
import json
import sys
import period1904
import blender_garment_adapter as adapter


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",type=Path,required=True)
    parser.add_argument("--actual",type=Path,required=True)
    args=parser.parse_args()
    folder=Path(__file__).resolve().parent
    profile=json.loads((folder/"glessner1904.profile.json").read_text())
    controls=[]
    def refusal(label,call):
        try:call()
        except ValueError:controls.append({"control":label,"refused":True})
        else:raise RuntimeError(label+" was accepted")
    for label,change in (("backdate",{"scene_date":"1835-07-01"}),
                         ("wrong_resident",{"person_reference_id":"rc_bardwell_otis"}),
                         ("coachman_claim",{"roles":["driver"]}),
                         ("likeness_upgrade",{"appearance_grade":"attested"})):
        refusal(label,lambda change=change:period1904.resolve_named(args.root,{**profile,**change}))
    body_bytes=(args.root/"assets/authored/humans/makehuman_hm08/prepared_adult_35.json").read_bytes()
    garment=json.loads((args.actual/"worker1904.jacket.json").read_text())
    contract=json.loads((args.root/"data/humans/contract.json").read_text())
    adapter.validate(garment,body_bytes,contract)
    for key,value in (("person_reference_id","glessner_john_j"),("identity_kind","named"),
                      ("up_axis","+Z"),("forward_axis","-Z"),("license","unknown"),
                      ("fallback_only",False),("registered",True),("ready_for_scene",True)):
        changed=copy.deepcopy(garment);changed[key]=value
        refusal("adapter_"+key,lambda changed=changed:adapter.validate(changed,body_bytes,contract))
    changed=copy.deepcopy(garment);changed["skeleton"][1]["parent"]="wrong"
    refusal("changed_skeleton_parent",lambda:adapter.validate(changed,body_bytes,contract))
    changed=copy.deepcopy(garment);changed["skeleton"][1]["head_m"][0]+=.01
    refusal("changed_skeleton_geometry",lambda:adapter.validate(changed,body_bytes,contract))
    refusal("changed_body_bytes",lambda:adapter.validate(garment,body_bytes+b" ",contract))
    # A named caller must be refused before rig access/importing BPy.
    refusal("named_caller_before_bpy",lambda:adapter.attach(garment,body_bytes,contract,None,None,{},
        actor_context={"identity_kind":"named","person_reference_id":"glessner_john_j","scene_date":"1904-07-01","fallback_only":False,"production_eligible":False}))
    sys.path.insert(0,str(args.root/"tools"))
    from human_teamster_blend import validate_input
    mature=json.loads((folder/"glessner_age61.body.json").read_text())
    validate_input(mature,contract)
    def area2(mesh,face):
        a,b,c=[mesh["positions_m"][i] for i in face]
        u=[b[i]-a[i] for i in range(3)];v=[c[i]-a[i] for i in range(3)]
        return sum(q*q for q in (u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]))
    smallest=min(area2(m,t) for m in garment["meshes"] for t in m["triangles"])
    if smallest<=1e-18:raise ValueError("Degenerate original jacket face")
    print(json.dumps({"status":"PASS_SOURCE_ARRAY_AND_REFUSAL_GUARDS_ONLY", "controls":controls,
        "mature_body_portable_array_contract":"PASS", "garment_triangles":sum(len(m["triangles"]) for m in garment["meshes"]),
        "minimum_squared_double_area_m4":smallest, "blender_adapter_executed":False,"collision_or_visual_acceptance":False},indent=2))


if __name__=="__main__":main()
