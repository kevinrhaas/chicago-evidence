# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only existing witnesses. No new collision predicate/candidate."""
from pathlib import Path
import json,hashlib
import numpy as np
P=Path('/workspace/shared/horse-ear-root-first-idle-binary64-trial/results/baseline-head_vs_all_rest.json')
WANT='f331022085d44163bb5d98c0afc868f18a784d65b5fa8f48d61a6f305f77eee1'
def edge_locations(tri,point,vertices):
 t=np.array(tri);p=np.array(point);out=[]
 for k in range(3):
  a=t[k];d=t[(k+1)%3]-a;fraction=float((p-a)@d/(d@d));residual=float(np.linalg.norm(p-(a+fraction*d)))
  if -1e-12<=fraction<=1+1e-12 and residual<1e-12:out.append({'vertex_pair':[vertices[k],vertices[(k+1)%3]],'fraction':fraction,'residual_m':residual})
 return out
raw=P.read_bytes()
if hashlib.sha256(raw).hexdigest()!=WANT:raise ValueError('Frozen existing receipt SHA mismatch')
d=json.loads(raw);rows=[]
for w in d['unexpected_witnesses']:
 v=w['b_owner']['primitive_vertices'];lo=min(v);quad=(lo//24,(lo%24))
 # exactsource triangular connectivity determines quad, not global ID/proximity.
 found=[]
 for j in range(9):
  for k in range(24):
   a=j*24+k;b=j*24+(k+1)%24
   for parity,f in enumerate([(a,b,b+24),(a,b+24,a+24)]):
    if list(v)in[list(f),list(f[1:]+f[:1]),list(f[2:]+f[:2])]:found.append((j,k,parity))
 if len(found)!=1:raise ValueError('Source lofttriangle ownership ambiguous')
 j,k,parity=found[0];row={'head_source_face':w['a_source_face_owner']['source_head_face'],'old_active_pair':[w['a_global'],w['b_global']],'neck_source_face':j*48+k*2+parity,'neck_strip':j,'neck_quad_sample':k,'neck_vertices':v,'kind':w['kind']}
 if w.get('proper_witness'):
  point=w['proper_witness']['point_m'];he=edge_locations(w['actual_triangles_world'][0],point,w['a_source_vertices']);ne=edge_locations(w['actual_triangles_world'][1],point,v)
  row.update(witness_point=point,head_edge_locations=he,neck_edge_locations=ne)
  row['neck_contact_location']='interior'if not ne else 'quad_diagonal'if all(abs(x['vertex_pair'][0]-x['vertex_pair'][1])==25 for x in ne)else 'fixed_quad_boundary_edge'
 else:row['neck_contact_location']='UNCLASSIFIED rawSAT; no proper witness'
 rows.append(row)
report={'status':'Read-only savedwitness inventory, not exhaustive intersection set','input_sha256':hashlib.sha256(raw).hexdigest(),'diagnostic_edge_reconstruction_residual_m':1e-12,'not_SAT_or_acceptance_tolerance':True,'rows':rows}
Path(__file__).with_name('saved-intersection-inventory.json').write_text(json.dumps(report,indent=2)+'\n')
for r in rows:print(r['head_source_face'],r['neck_source_face'],r['neck_quad_sample'],r['neck_contact_location'],r.get('neck_edge_locations'))
