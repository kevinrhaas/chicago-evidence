# Bounded local neck topology implementation proposal — SOURCE ONLY

Saved baseline full head-vs-rest receipt contains20unexpected pair findings:18strict proper witnesses and2unclassified rawSAT. These are the entire EXISTING saved cohort, not a newly computed exhaustive intersection curve. All map uniquely by original source triangle connectivity to strip8/samples15..20 (sourcefaces414..425). No new SAT/capture ran.

| head sourceface | neck sourceface | quad sample | saved witness on neck |
|---:|---:|---:|:---|
| 33 | 414 | 15 | interior |
| 38 | 425 | 20 | interior |
| 39 | 425 | 20 | interior |
| 80 | 414 | 15 | interior |
| 80 | 416 | 16 | interior |
| 80 | 417 | 16 | quad_diagonal |
| 82 | 418 | 17 | quad_diagonal |
| 82 | 419 | 17 | interior |
| 82 | 421 | 18 | UNCLASSIFIED rawSAT; no proper witness |
| 83 | 416 | 16 | interior |
| 83 | 419 | 17 | interior |
| 84 | 420 | 18 | fixed_quad_boundary_edge |
| 84 | 421 | 18 | interior |
| 84 | 423 | 19 | interior |
| 85 | 418 | 17 | UNCLASSIFIED rawSAT; no proper witness |
| 85 | 421 | 18 | interior |
| 86 | 422 | 19 | fixed_quad_boundary_edge |
| 86 | 423 | 19 | interior |
| 86 | 425 | 20 | interior |
| 87 | 423 | 19 | interior |

## Why the scope is six quads, not one flipped triangle

The first witness is inside source414 while lying on fixed headband edgeH17–H16. Two other strict witnesses lie on neck internal longitudinal edges211–235(sample19) and212–236(sample20). Those edges would survive any independent samequad diagonal flip, so that smaller plan cannot repair the full known cohort. The two rawSAT pairs have no proper point and remain unresolved FAIL—not classified as harmless.

The proposed patch is exactly six consecutive finalneck quads samples15..20,14existing boundaryvertices O15..O21 (207..213) and Q21..Q15 (237..231). Existing offending columns19/20 become INTERIOR patchedges and are retired. The existing saved point witnesses include no demonstrated contact on the OUTER boundary of this larger patch; this absence is not proof that the full uncomputed crossing curve avoids it. No feasibility claim is made.

## Implemented explicit topology proposal

Retire exact sourcefaces414..425 only. Replace them with12explicit ordered source-chart triangles:6fan triangles(O_i,O_(i+1),Q15), i15..20, plus6fan triangles(O21,Q_(i+1),Q_i), i15..20. These partition the6x1 sourcechartrectangle along O21→Q15 with identical14edge outerboundary, positiveareas, no added/movedvertices and no missing samples. Code failcloses on missing/duplicate exact oriented oldface, changedboundary/winding, differentrecipe, sourcechartdegeneracy and knownobstructingedge retention. It emits exactold→new retainedindexmap and12retired/appendedface ownership when invoked; tests invoke only syntheticindexarrays, not actualhorse indices.

EVERY attribute vector stays exact: allPOSITION/NORMAL/JOINTS_0/WEIGHTS_0, protectedhead48, head/ear/portal, allbody vertices, rig/rest/IBMs/sockets/clips/materials and gear. Only12neck indices change. This bypasses neither movementguard nor contactguard: no position movement is proposed, and earlierfaileddeformation remains unchanged. The two orderedfans can introduce long/sliver/nonplanar/folding surfaces in actual3D and altered skinnedface interpolation even with exactvertices. Existingnormals may no longer represent newfacegeometry; visualnormal/anatomy acceptance remainsopen and no implicitnormal change is authorized.

## Separate future review/release required

Oldthreewaychecker allindicesexact MUST be explicitly amended to only these12sourceowned triangle replacements, preserving explicitnewactivehead/neck owners and everyotherindex exactly. Newproducer/manifest/authority and exactprovenance required; do not reuse old26027authority as new. After ONE actualtrial is separately authorized, first reject3Ddegeneracy/winding/foldover/skin changes, then unchangedbinary64 fullheadinternal/headvsALLhorse AND changed12patchinternal/vsALLactivehorse with originalrawSAT/proper/exactsourcecontact rules. Preserve existingnegativecontrols, firstfailure STOP. Only later63poses/gear/visualrelease. No actualGLB/export/capture/SAT/proposed3Dtriangle evaluation ran here.

Six synthetic topology/indexpreservation controls pass normal and -O. Source recipe proof is not anatomical/photographic acceptance. All previousfailurearchives untouched.
