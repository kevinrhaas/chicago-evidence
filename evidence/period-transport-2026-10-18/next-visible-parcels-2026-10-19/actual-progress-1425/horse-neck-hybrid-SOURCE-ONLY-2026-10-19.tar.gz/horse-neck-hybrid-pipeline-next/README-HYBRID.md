# Hybrid throatlatch seam proposal — UNACCEPTED, source only

This is original reconstructed geometry, not a measured anatomical master. Cuyer 1905 Fig.92 informs the qualitative neck/jaw transition; no dimensions or breed are derived from the illustration.

The previous e680 neck-only surface failed actual idle self-embedding against retained head source face30. Earlier source-owned failures also involve lower head faces80..87. This proposal explicitly changes active head/neck connectivity, rather than exempting those crossings.

## Exact ownership amendment

Parent is pinned 26027c225b0c2f3c6ed72543cb2e80238196a86815b7bb910744cbc65cb23ed3, descended from090be8fdc2516ee5b5c8f886026f441850cc208f17b6ede71fed9007ab80f12f. Retire exactly body-neck source336..431 (96 faces) and head source24..47 plus72..95 (48 faces). The latter actual active IDs2046..2069 and2094..2117 are proved in hybrid-seam-contract.json, not selected by proximity.

The retained head/ears form one2912-face disk, Euler1, with directed28-edge boundary:
H0 → Q0..Q12 → H12 → R12..R23 → R0 → H0.
Source vertex order is [24,0..12,36,60..71,48]. Upper poll and all six ear-root skull exceptions remain. Old head lowerQ/H vertices remain byte-exact but inactive. This deliberately replaces the previous active48-portal/band contract; it does not relabel the old failed seam accepted.

The neck starts at fixed body ringB168..191. Its24 phases and28 head-seam phases have48 unique common phases. Fifteen interior rings append720 vertices. Explicit angular zipper triangulation appends1492 triangles (72 +14×96 +76). Patch has772 active vertices, Euler0, two boundary loops24/28,2212 internal and52 external source-edge pairs. Whole horse becomes12800 triangles. All old POSITION/NORMAL/JOINTS/WEIGHTS, other indices, materials, rig, IBMs, sockets and clips remain byte-exact. Old neck vertices192..239 become inactive. Only appended vertices receive new normals/skin attributes.

## Geometry and readback

hybrid_geometry.py implements exact-rational Hermite positions from fixed A/B and actual retained seam/inward source-chart targets; hybrid_reference.py independently evaluates Bernstein controls. No tuning/search or global scaling. hybrid_contract.py resolves the actual root/head palette, records raw anchor weights, and verifies retained directed boundary/Euler. Root/head weight components are interpolated independently to preserve actual float32 endpoint semantics. No posed-C1 claim is made, particularly at B's upstream forelimb weights.

hybrid_rest.py decodes actual emitted arrays, verifies exact intended rational positions/weights, all old attribute bytes, source retirement maps, and appended storage/document protection. hybrid_scope.py authoritatively verifies all1492 actual patch faces and their entire annulus ownership; scans ALL patch-internal pairs and ALL remaining active horse triangles. Head2912 internal and vsALL rest execute first. Unchanged SAT1e-8/proper predicates and exact dyadic source-point/actual-edge certificates apply; unexplained rawSAT remains failure. Old090 known12 negatives and26027 source33/neck negative remain mandatory. No original-nearby-cohort restriction exists.

## Finite operator and current status

run_local_trial.py requires ROOT_RELEASE_ONE_HYBRID_NECK;90 seconds total from entry and30/phase. Export, metadata, independentREST and localKhronos are separate processes; first nonzero stops. Output is exclusively created. All source files and external loader/validator bytes are pinned in operator-source-pins.json. The captured world coordinates remain explicit IEEE binary64/little-endian,72 bytes per triangle, with existing exclusive output ownership.

At source freeze, only synthetic math/topology and syntax controls have run. NO hybrid candidate GLB, actual mesh deformation, collision, gear or browser acceptance exists. Parent/failure archives remain unchanged. After independent source review, only the root-authorized ONE90-second local trial may execute; actual independent REST/ownership review precedes ONE120-second idle capture/check. First actual failure stops. No63-pose, gear, browser, photographic or production acceptance is implied.
