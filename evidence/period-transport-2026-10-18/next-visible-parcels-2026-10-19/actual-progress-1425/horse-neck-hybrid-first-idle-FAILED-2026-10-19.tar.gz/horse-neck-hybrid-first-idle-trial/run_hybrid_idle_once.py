from pathlib import Path
import json,hashlib,time,subprocess,signal,os,sys
start=time.monotonic();src=Path('/workspace/shared/horse-neck-hybrid-pipeline-next');out=Path('/workspace/shared/horse-neck-hybrid-first-idle-trial');out.mkdir(parents=True,exist_ok=False)
for path,want in json.loads((src/'operator-source-pins.json').read_text()).items():
 if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=want:raise ValueError('SOURCEPIN MISMATCH '+path)
packet='/workspace/shared/horse-neck-hybrid-first-local-trial/payload/packet.json';packet_sha='cb6987a5403bf4b83f9c644203936bf181d1b4a38c24e0e76246d2d51f3d41aa'
commands=[['node','--loader','/workspace/shared/horse-ear-root-idle-checker-f64-unique-next/three-loader.mjs',str(src/'capture_threeway.mjs'),'--output-dir',str(out/'capture'),'--baseline','/workspace/shared/horse-head-groove-coat-next/trial1/equine_light_harness_skinned_prototype_01.glb','--ear-parent','/workspace/shared/horse-ear-root-exporter-source-reviewed-next/export-trial1/equine_ear_root_candidate.glb','--chain',packet,'--chain-sha256',packet_sha],['/workspace/shared/chicago-venv/bin/python','-c',"import sys;from pathlib import Path;sys.path.insert(0,"+repr(str(src))+");from check_threeway import run_prepared_once;ok=run_prepared_once(chain_file="+repr(packet)+",chain_sha="+repr(packet_sha)+",base090=Path('/workspace/shared/horse-head-groove-coat-next/trial1'),ear_dir=Path('/workspace/shared/horse-ear-root-exporter-source-reviewed-next/export-trial1'),ear_source=Path('/workspace/shared/horse-ear-root-exporter-source-reviewed-next/source-trial1/candidate-source-edit.json'),capture_dir=Path("+repr(str(out/'capture'))+"),output_dir=Path("+repr(str(out/'results'))+"),negative_provenance=Path('/workspace/shared/horse-ear-root-idle-checker-f64-unique-next/provenance'),parent_receipt=Path('/workspace/shared/horse-ear-root-first-idle-binary64-trial/results/candidate-head_vs_all_rest.json'));sys.exit(0 if ok else 1)"]]
r={'status':'STARTED','packet_sha256':packet_sha,'candidate_sha256':'192204d95776c5cf675f1269f937d0b9bed89eca9df04e9db9f181384e0a4ec8','source_archive_sha256':'a18cac37f8585494f6b868135d925dd585996b4e6f957abb91e34d271a2fda96','deadline_s':120,'stages':[]}
def save():(out/'run-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
save()
for i,cmd in enumerate(commands,1):
 budget=120-(time.monotonic()-start)
 if budget<=0:r.update(status='FIRSTFAIL deadlineSTOP');save();sys.exit(124)
 with(out/f'stage{i}.stdout.log').open('wb')as stdout,(out/f'stage{i}.stderr.log').open('wb')as stderr:
  p=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,start_new_session=True)
  try:code=p.wait(timeout=budget)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();code=124
 r['stages'].append({'command':cmd,'returncode':code,'elapsed_s':time.monotonic()-start});save()
 if code:r.update(status='FIRSTFAIL STOP; no retry/repair');save();sys.exit(code)
r.update(status='DISCRETEidle0ONLY; UNACCEPTEDoverall',elapsed_s=time.monotonic()-start);save()
