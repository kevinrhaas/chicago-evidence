# SPDX-License-Identifier: GPL-3.0-or-later
import json,struct,hashlib
from pathlib import Path
import numpy as np
O=Path(__file__).parent
def load(p):
 b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];return json.loads(b[20:20+n]),b[28+n:]
def read(d,b,i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];k=int(a['type'][-1]);return np.frombuffer(b,dtype='<f4',count=a['count']*k,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,k)
def tris(d,b):
 return sorted(tuple(row)for m in d['meshes']for p in m['primitives']for row in np.concatenate([read(d,b,p['attributes'][k])for k in ['POSITION','NORMAL']],axis=1).reshape(-1,18))
def require(x,s):
 if not x:raise ValueError(s)
d,b=load(O/'candidate/wagon-w01.glb');old,ob=load(Path('/workspace/shared/w01-supported-driver-next/export/wagon-w01.glb'));require(tris(d,b)==tris(old,ob),'actual orientedgeometry/normals changed');require(all(d.get(k)==old.get(k)for k in ['nodes','scenes','skins','animations']),'hierarchychanged');require(b[:len(ob)]==ob,'oldbinaryprefix');count=0;maxortho=0;maxaniso=1;minarea=1e9
for mesh in d['meshes']:
 for p in mesh['primitives']:
  if 'TANGENT'not in p['attributes']:continue
  pos=read(d,b,p['attributes']['POSITION']).astype(float);n=read(d,b,p['attributes']['NORMAL']).astype(float);uv=read(d,b,p['attributes']['TEXCOORD_0']).astype(float);t=read(d,b,p['attributes']['TANGENT']).astype(float);require(np.isfinite(pos).all()and np.isfinite(uv).all()and np.isfinite(t).all(),'nonfinite');ortho=np.max(abs(np.sum(n*t[:,:3],axis=1)));maxortho=max(maxortho,float(ortho));require(ortho<2e-7 and np.max(abs(np.linalg.norm(t[:,:3],axis=1)-1))<2e-7,'TBNnonorthonormal')
  for i in range(0,len(pos),3):
   e=np.stack([pos[i+1]-pos[i],pos[i+2]-pos[i]]);u=np.stack([uv[i+1]-uv[i],uv[i+2]-uv[i]]);det=float(np.linalg.det(u));require(abs(det)>1e-16,'zeroUV');area=float(np.linalg.norm(np.cross(*e))/2);require(area>0,'zeroworldarea');der=np.linalg.solve(u,e);sing=np.linalg.svd(der,compute_uv=False);maxaniso=max(maxaniso,float(sing[0]/sing[-1]));minarea=min(minarea,area)
   for k in range(i,i+3):
    require(t[k,3]in[-1,1]and np.dot(t[k,:3],der[0])>0 and np.dot(np.cross(n[k],t[k,:3])*t[k,3],der[1])>0,'wrongUVorientation')
   count+=1
r={'passed_mechanical_readback':True,'all_oriented_POSITION_NORMAL_triangles_exact':True,'nodes_scenes_rig_exact':True,'oldBINprefix_exact':True,'textured_triangles':count,'max_T_N_dot':maxortho,'min_triangle_area_m2':minarea,'maximum_actualUV_anisotropy':maxaniso,'limitation':'Polar hubs and bevel projections have anisotropy; this is measured NOT claimed stretch-free. Visualacceptance pending, originalproceduralmap notphotographicscan.'};(O/'candidate/independent-readback.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
