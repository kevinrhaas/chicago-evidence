# SPDX-License-Identifier: GPL-3.0-or-later
"""Original data-driven material study using cleared project procedural maps."""
import argparse,json,struct,hashlib,copy,io,math
from pathlib import Path
import numpy as np
from PIL import Image
ap=argparse.ArgumentParser();ap.add_argument('--vehicle',type=Path,required=True);ap.add_argument('--parts',type=Path,required=True);ap.add_argument('--library',type=Path,required=True);ap.add_argument('--parameters',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();recipe=json.loads(a.parameters.read_text())
def require(c,s):
 if not c:raise ValueError(s)
raw=a.vehicle.read_bytes();require(hashlib.sha256(raw).hexdigest()==recipe['input_sha256'],'baseline hash');a.output.mkdir(exist_ok=False);jl=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+jl]);binary=bytearray(raw[28+jl:]);original=copy.deepcopy(g);oldbin=bytes(binary);parts=json.loads(a.parts.read_text());receipts=[];sourcepins={};images={};textures={}
def encodepng(arr):
 f=io.BytesIO();Image.fromarray(arr).save(f,format='PNG',compress_level=9);return f.getvalue()
def linear(x):return np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4)
def srgb(x):return np.where(x<=.0031308,x*12.92,1.055*x**(1/2.4)-.055)
def addview(data,target=None):
 binary.extend(b'\0'*((-len(binary))%4));v={'buffer':0,'byteOffset':len(binary),'byteLength':len(data)}
 if target:v['target']=target
 i=len(g['bufferViews']);g['bufferViews'].append(v);binary.extend(data);return i
def attr(values):
 arr=np.asarray(values,dtype='<f4');require(arr.ndim==2 and np.isfinite(arr).all(),'finite attributes');vi=addview(arr.tobytes(),34962);i=len(g['accessors']);g['accessors'].append({'bufferView':vi,'componentType':5126,'count':len(arr),'type':'VEC'+str(arr.shape[1]),'min':arr.min(0).tolist(),'max':arr.max(0).tolist()});return i
g['images']=[];g['textures']=[];g['samplers']=[{'magFilter':9729,'minFilter':9987,'wrapS':10497,'wrapT':10497}]
def texture(data):
 h=hashlib.sha256(data).hexdigest()
 if h in textures:return textures[h]
 im=len(g['images']);g['images'].append({'bufferView':addview(data),'mimeType':'image/png'});ti=len(g['textures']);g['textures'].append({'source':im,'sampler':0});textures[h]=ti;return ti
newmaterials={};colorreports=[]
for mi in range(5):
 family='paint' if mi==0 else 'iron'if mi==4 else 'wood';cfg=recipe[family];folder=a.library/cfg['source'];sid=cfg['id'];maps={}
 for suffix in ['basecolor','normal_gl','orm']:
  p=folder/(sid+'_'+suffix+'.png');data=p.read_bytes();sourcepins[str(p.relative_to(a.library))]=hashlib.sha256(data).hexdigest();maps[suffix]=data
 rgb=np.asarray(Image.open(io.BytesIO(maps['basecolor'])).convert('RGB'),dtype=np.float64)/255;lin=linear(rgb);mean=lin.mean((0,1));target=np.array(g['materials'][mi]['pbrMetallicRoughness']['baseColorFactor'][:3]);relative=lin/mean;normalized=target*(1+cfg['color_contrast']*(relative-1));require(normalized.min()>=0 and normalized.max()<1,'albedo would clip');data=encodepng(np.round(srgb(normalized)*255).astype('uint8'));ci=texture(data);ni=texture(maps['normal_gl']);oi=texture(maps['orm']);mat=copy.deepcopy(g['materials'][mi]);mat['name']+='_cleared_material_study';pbr=mat['pbrMetallicRoughness'];pbr['baseColorFactor']=[1,1,1,1];pbr['baseColorTexture']={'index':ci};pbr['metallicRoughnessTexture']={'index':oi};pbr['roughnessFactor']=1;pbr['metallicFactor']=1 if family=='iron'else 0;mat['normalTexture']={'index':ni,'scale':cfg['normal_scale']};mat['extras']={'confidence':'original reconstructed application; source confidence retained in SOURCE-MATERIAL records','source_id':sid,'metric_span_m':cfg['span_m'],'no_historical_finish_calibration':True};newmaterials[mi]=len(g['materials']);g['materials'].append(mat);colorreports.append({'material':mi,'family':family,'source_linear_mean':mean.tolist(),'target_original_linear_mean':target.tolist(),'relative_contrast':cfg['color_contrast'],'clipped_pixels':0,'normal_strength_unmeasured':cfg['normal_scale']})
# Reconstruct each batch's exact source primitive stream before making UVs.
for mesh in g['meshes']:
 oldp=mesh['primitives'][0];mat=oldp['material'];frame=mesh['name'].rsplit('_',1)[0] # use exact batch name below, since plank names containunderscore.
 matches=[r for r in parts if r['frame']+'_'+original['materials'][r['material']]['name']==mesh['name']];require(bool(matches),'source batch absent')
 olda=original['accessors'][oldp['attributes']['POSITION']];oldv=original['bufferViews'][olda['bufferView']];actual=np.frombuffer(oldbin,dtype='<f4',count=olda['count']*3,offset=oldv['byteOffset']).reshape(-1,3);joined=np.array([p for r in matches for p in r['positions']],dtype='<f4');require(np.array_equal(actual,joined),'authored source-to-actual batch mismatch')
 batches={}
 for r in matches:
  local=np.array(r['local_positions']);normlocal=np.array(r['local_normals']);positions=np.array(r['positions']);normals=np.array(r['normals']);center=(local.min(0)+local.max(0))/2;cov=np.cov((local-center).T);vals,axes=np.linalg.eigh(cov);axes=axes[:,np.argsort(vals)[::-1]]
  for col in range(3):
   if axes[np.argmax(abs(axes[:,col])),col]<0:axes[:,col]*=-1
  grain=axes[:,0];ring=r['name'].startswith(('iron_tyre','wood_felloe','hub_'))or r['name']=='band';cfg=recipe['paint'if mat==0 else'iron'if mat==4 else'wood'];span=cfg['span_m'];offset=int(hashlib.sha256(r['name'].encode()).hexdigest()[:8],16)/2**32;flat=0;max_aniso=1
  for start in range(0,len(local),3):
   lp=local[start:start+3];nn=normlocal[start];use=mat<5 and abs(float(nn@grain))<.8
   if ring:use=mat<5
   if ring:
    radius=np.sqrt(local[:,1]**2+local[:,2]**2).mean();angles=np.unwrap(np.arctan2(lp[:,2],lp[:,1]));u=angles*radius/span;v=(lp[:,0] if abs(nn[0])<.8 else np.sqrt(lp[:,1]**2+lp[:,2]**2))/span;uv=np.stack([u+offset,v+.213],1)
   else:
    transverse=min([axes[:,1],axes[:,2]],key=lambda q:abs(float(q@nn)));uv=np.stack([lp@grain/span+offset,lp@transverse/span+.213],1)
   dest=newmaterials[mat]if use else mat
   record=batches.setdefault(dest,{'POSITION':[],'NORMAL':[],'TEXCOORD_0':[],'TANGENT':[]})
   record['POSITION'].extend(positions[start:start+3]);record['NORMAL'].extend(normals[start:start+3])
   if use:
    pp=positions[start:start+3];e=np.stack([pp[1]-pp[0],pp[2]-pp[0]]);du=np.stack([uv[1]-uv[0],uv[2]-uv[0]]);require(abs(np.linalg.det(du))>1e-15,'zero UV triangle '+r['name']);der=np.linalg.solve(du,e);ts=[]
    for n in normals[start:start+3]:
     t=der[0]-n*np.dot(n,der[0]);require(np.linalg.norm(t)>1e-12,'tangent collapse');t/=np.linalg.norm(t);w=1 if np.dot(np.cross(n,t),der[1])>0 else-1;ts.append([*t,w])
    record['TEXCOORD_0'].extend(uv);record['TANGENT'].extend(ts);sv=np.linalg.svd(der,compute_uv=False);max_aniso=max(max_aniso,float(sv.max()/sv.min()))
   else:flat+=1
  receipts.append({'part':r['name'],'batch':mesh['name'],'triangles':len(local)//3,'untextured_cut_end_or_small_bevel_triangles':flat,'mapping':'circumferential ring metric'if ring else'local authored PCAgrain / faceplane metric','max_uv_axis_anisotropy':max_aniso,'source_span_m':span})
 mesh['primitives']=[]
 for material,data in batches.items():
  keys=['POSITION','NORMAL']if material<6 else['POSITION','NORMAL','TEXCOORD_0','TANGENT'];mesh['primitives'].append({'attributes':{k:attr(data[k])for k in keys},'material':material})
binary.extend(b'\0'*((-len(binary))%4));g['buffers'][0]['byteLength']=len(binary);g['extras']['material_study']={'grade':recipe['grade'],'endgrain':recipe['endgrain'],'source':'cleared existing projectprocedural maps, not scans','geometry_unchanged':True};j=json.dumps(g,separators=(',',':')).encode();j+=b' '*((-len(j))%4);out=struct.pack('<III',0x46546c67,2,28+len(j)+len(binary))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(binary),0x004e4942)+binary;(a.output/'wagon-w01.glb').write_bytes(out);(a.output/'material-receipt.json').write_text(json.dumps({'status':'UNACCEPTED wholewagon optical study','sha256':hashlib.sha256(out).hexdigest(),'source_parts':receipts,'albedo_normalization':colorreports,'texture_source_sha256':sourcepins,'draws':sum(len(m['primitives'])for m in g['meshes']),'geometry_source_batch_exact':True,'endgrain':'original flat cutends retained, no invented growthrings'},indent=2)+'\n');print(hashlib.sha256(out).hexdigest())
