# Fixed neutral lip reconstruction — executable source, UNEXECUTED actual variant

Baseline actual57d63, with old ab70/fe76 motion model and e578 eye trial immutable. See d962918e proposal archive and actual-source inventory. This source replaces exactly132 dark oral_rim_connector faces; all202 cavity faces remain active and attribute-exact. Original66outer/66inner P/JW remain exact, as do every old position, rig/IBMs/clips/sole/socket and outside indices. New coat tissue462faces and wet lining198faces append264vertices; net+528faces, head3650/total13754. No jaw squash, black overlay, bit change or parameter search.

The fixed aperture has rounded source-bounded rear corners and a2mm front slit. Dimensions are original reconstructed engineering choices, not derived measurements from Cuyer1905Fig92 or Muybridge1878. Those exact cached PD pixels were actually opened; no retained cleared close bit photograph establishes this pose/finish. Photographic/historical identity/pressure/tongue/teeth/motion acceptance stays open.

## Explicit chart-authority revision and preserved failure

The first executable WIP10cb1fb3 is frozen. Its synthetic upper wet lining failed a physical YZ-graph hypothesis: this nonplanar lining narrowsX while descendingY toward the lips and need not be a graph inYZ. No actual horse was generated in that WIP. Independent reviewer accepted that source-intrinsic(edge-phase, radial-layer) charts establish ownership/topology, NOT physical embedding. This new revision uses exact dyadic intrinsic charts and constrained ear triangulation. It proves complete sheet rectangles, consistent winding and pairwise nonoverlap in SOURCE UV, with explicit66↔132 directed alias interfaces. None of those UV facts exempts an actual3D contact or establishes anatomical placement.

Actual binary64 full XYZ self/vsALL checks remain REQUIRED: new660-face annulus, whole head/neck/mane, newlip↔retained202cavity and all36fe76gear; exact source-edge/point contacts pass only existing geometric certificates. Strict SAT1e-8/proper predicates are unchanged. The source array additionally refuses finite/area failures and stale source phase/ownership.

Fourteen actual outer source labels have two raw mesh1 aliases after the original oral graft. The authority selects the unique row used by the RETIRED connector cohort, checks all aliases have exact rawP/JW, and never picks by proximity or array-first convenience. Exterior fullness directions come solely from retained external head face areas, excluding all334 oral surfaces. Cavity normals, source-record eyes/nostrils and actual ear cohorts are protected. A bounded outside lip-skin normal halo is recorded by semantic source labels; genuine protected aliases remain byte-exact.

`lip_variant.py` appends8 accessor/view records and preserves the full old BIN/accessor/view prefix. Only declared bodyN and mesh1 P/N/JW/index references change. Complete reloaded bytes must equal the exact intended serializer; all other actual attributes/indices/materials/document fields remain exact. The full active source-owner remap includes all13754triangles, not merely new geometry.

Twelve synthetic controls pass normal/-O: annulus topology/exact boundaries, owner counts, finite values, missing anchor/normal/count, UV overlap/gap/winding/bowtie and reversed sourcephase refusal. Read-only parent context resolves132retired/202cavity and actual66+66sourcealiases/exterior directions without invoking the proposed surface. The actual variant is NOT generated, exported, captured or SAT-tested yet.

ONE150second operator after independent executable source review: export→readback→Khronos→actualbinary64idle→full8structural scopes→all36gear→bit-volume. First nonzero STOP, preserve bytes/logs, no repair/retry/search. Old078 negative control remains mandatory. Virtual bit caps/head closure are analysis-only; no emitted fake caps. No browser, Blender,63poses, app or ticket edits are authorized by this operator. A real visual comparison is separately needed after technical result.

## Source-phase guard correction

Frozen ce779 source is preserved and not executed. Its source anchor code mistakenly required exactz=.39 from already-quantized globalfloat32 positions after subtracting the headorigin. This revision uses explicit original source IDs385/389/407/403 and the original11db source chart to select/parameterize phases; actual boundaryP remains57d encoded geometry. No proximity search or numeric tolerance increase. The original chart/ID list is serialized in proof. Fixed dimensions and actualcollision guards do not change.

The encoded-boundary regression proves original source phases remain usable when boundary positions are globalfloat32→localbinary64; a stale original source phase is refused. Twelve synthetic controls PASS normal and-O, syntax PASS. The interrupted tool request failed before process creation; later single diagnostic confirmed exec connectivity and no model work occurred.
