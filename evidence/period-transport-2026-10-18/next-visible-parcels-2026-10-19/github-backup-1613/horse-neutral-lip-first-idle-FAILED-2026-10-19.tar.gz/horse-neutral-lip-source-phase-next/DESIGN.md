# Neutral bit-carrying lip reconstruction — fixed source proposal

Status: actual57d ownership/reference inventory only. No proposed geometry evaluated, no GLB/export/capture/SAT/browser. The ab70/fe76 motion baseline and failed/unaccepted e578 eye variant stay immutable. This first new mouth uses57d, not e578.

## Actually seen references and limits

Cuyer, Artistic Anatomy of Animals,1905, Fig92 p239 (`illo262.png`) was opened again for this parcel. Its exposed-muscle head drawing shows a narrow front lip meeting line, rounded muzzle/lower lip and localized rear commissure; it does not show a horse carrying this bit. It is a later comparative anatomy drawing, US public domain by publication age, not a photograph or evidence for Chicago1835/1904 identity/tack. Muybridge1878 Sallie Gardner12-panel photograph was opened again. The small silhouettes do not show a broad yawning front mouth, but lack close lip/bit resolution. They establish neither contact dimensions nor this proposed pose. Original bytes/hashes are in source-inventory.json. No already-cleared close bit-carrying photograph was found in the retained research set; photographic/bit-pressure acceptance remains open. All numerical choices below are bounded original reconstruction.

## Actual cause and source ownership

Every one of the334 newly authored oral-channel faces is currently material1 dark mane/tail:132 external rim connectors,68 roof,58 floor and76 back. Thus the exterior transition is painted like an interior as well as having a genuine wide aperture. The source-owned66 outer loop has a left rear upper boundary y=-.148705 at z=.34 and lower boundary near-.198920; the engineering inner box is roof-.185/floor-.218. This produces the obvious black rear rectangle/smile. A mere recolor would not close its real gap.

Actual ownership must be used: the current graft owner table marks334 new mouth faces plus137 retained-source halo faces as oral_channel. The broader historical584-added-triangle diff is NOT a334+250 permission bucket; do not retire it blindly. `source-inventory.json` lists the exact334 actual faces/materials/vertices. Only the132 owner.kind=oral_rim_connector faces are proposed for retirement. The202 cavity roof/floor/back faces and their source positions/JW remain active and exact. No jaw, chin, muzzle or whole head is squashed/scaled. The original66 outer and66 inner boundary attributes remain exact; new surfaces occupy the connector region between them.

## Fixed new visible aperture

Create a single continuous U-shaped opening: locally rounded rear corners around the actual unchanged bar, tapering to a2mm front slit. The front lips are largely apposed, not a sealed surface hiding the tube. This keeps one mouth opening/cavity and the existing head-disk topology; two disconnected side ports joined by one cavity would instead create a handle and are deliberately not the proposed topology.

Use the existing eight source arc breaks [0,4,9,23,28,32,38,60,66], with original ordered source knots. The new aperture has132points: two samples for each old outer edge, including its exact source-phase midpoint. This is a fixed recipe, not a search.

- Left/right rear commissures: head-local center y=-.20175,z=.395, upper/lower limits-.188/-.2155; rear half-ellipse z=.395-.018*cos(theta), y=-.20175+.01375*sin(theta), theta from+pi/2 to-pi/2 on left and reverse on right. These are modeled clearances, not source measurements. The signed lateral center comes from .95 times the mean absolute upper/lower original side-rim X at original z=.39; it is source-bounded rather than a guessed global width. Actual bar remains unchanged.
- Side upper/lower arcs map the original ordered z phases monotonically from the rear endpoint .395 to front .530. Maintain the corner Y bounds through z=.415, then quintic-blend to front upper-.207/lower-.209 by z=.490. The bar's frontmost surface lies posterior to this closure region; actual tube/SAT/volume checks still decide acceptance.
- Lateral X tapers smoothly from the source-bounded rear center to20mm front half-width. Front upper/lower arcs retain their distinct original source-X knot phases rescaled to[-.020,.020]. Set z=.530+.002*(1-(x/.020)^2). Their Y limits receive the same small +.001*(1-(x/.020)^2) curvature. The2mm separation remains; a gentle curved lip line replaces a rectangular box opening.

The aperture must lie inside the source-owned cut charts; actual interval/orientation/embedding guards must reject a bad fixed recipe. No nearest-face ownership or favorable tolerance change is allowed. These coordinates do not themselves prove anatomical shape or clearance.

## New surfaces and material semantics

Retire exactly132 old connectors, append264 vertices (132 intermediate skin +132 aperture), preserving all oldP/JW. Outer66→intermediate132 is a source-owned three-triangle-per-edge transition (198faces); intermediate→aperture132 adds264faces. The intermediate row follows a .65 blend from the source outer edge to its new aperture phase plus1.5mm outward lip fullness derived from retained exterior incident normals, not cavity-wall normals. These462 faces are coat-colored actual lip tissue, not a black overlay. The aperture132→existing inner66 wet lining uses the reverse three-triangle transition (198faces), dark interior material. All202 existing cavity faces remain unchanged. Net+528faces; resulting head3650/total13754 are derived consequences, not hardcoded exemptions.

The intermediate skin is a true replacement annulus; it does not cover the old faces. Every132↔66 interface has explicit indexed source-edge correspondence, no T-junction. Existing inner cavity geometry keeps the actual bit volume. The new narrowing occurs anterior to the bar; no bit shrinking, hiding or collision exemption. Mouth/lining cap owners are named explicitly. Source-charts, winding, nondegeneracy and actual all-head embedding decide whether this proposal works.

New weights interpolate the actual semantic source endpoint/inner-boundary weights with exact palette names; the raw retained outer/innerJW remain unchanged. New seam aliases must match actual P/JW. Preserve all rig/IBMs/actions/soles/socket frames and every other old index/position. A bounded original outer-skin NORMAL halo may be recomputed; actual nostril/eye/ear protected neighbors are excluded and preserved exactly, with source-label evidence. Retained cavityN may remain exact, with an intentional wet-lining crease. No silently broadened protected halo.

## Required bounded proof and visible acceptance

Executable source must pin57d, current oral source/map and exact fe76 bytes, retired132/retained202 ownership, full source remap and new material/cohort coverage. Original66 boundaries, all protected features, oldBIN prefix and old storage metadata require explicit reloaded equality. Source controls must refuse reversed arcs, missing/duplicate source knots, foreign retirement, degenerate/overlapping projected charts and stale indices. Complete topology must remain one connected head disk with the actual hybrid28-edge boundary, not just pass a local annulus check.

After independent source review, ONE fixed finite trial exports/readbacks/Khronos and captures actual binary64 idle0. Reuse unchanged strict SAT/proper and exact registered edge/point certificates: full new mouth internally/vsALL, full head/neck/mane scopes, all36 fe76gear and actual full bit sides+analysis-only cap/volume classification. Preserve first failure before repair; previous successful ab70/57d motion or bit receipts do not certify these new surfaces. No search or threshold adjustment.

Only after a real mechanical result should matched57d/new profile, front-quarter, front and whole images be assessed. The intended success is a substantially quieter largely apposed front lip silhouette with localized bit-carrying corners, not simply fewer collisions. Photo-quality, pressure, tongue/teeth, blink and63pose acceptance remain open. No app installation is authorized by this source proposal.
