# Root task authorization, 2026-10-19

The following is the parent/root task message supplied to harness_fit. This file records that already-given conditional authorization; it is not a new signed root release or a substitute for independent review.

> For the girth-only next parcel, after an independent full frozen source/caller/math review passes, you may run ONE actual bounded 300s trial on CPU2/one math thread, fresh exclusive output/first failure stop. Freeze/report all source/input hashes first. Preserve qualified rear3 parts plus every other35 primitive stream and unchanged horse; require real closed indexed strap-shell ownership, dimensions/decoded source ownership/Khronos/self/all changed-vs-other35 pairs/all36 against wholehorse and preserved negative controls. Any unbound buckle/billet gap explicit; no blanket contact exemption. No motion/app/photo acceptance. If reviewer capacity is unavailable continue source and send parcel to root; no need another permission round once a complete independent frozen review passes. Root sole tracked writer.

Operator requires the independent reviewer to bind the actual full frozen inventory and report a full executable SOURCE/caller/math PASS. It does not accept a geometry fit or historical/photo acceptance claim from that source review.

## Continuation after preserved v1 and v2 build failures

The original single trial and corrected v2 single trial have both been consumed, each refusing before a candidate. The following new root task message is the currently applicable limited continuation, recorded verbatim; this is a record of the message, not a signed release:

> Proceed v3 domain-only guard correction with full independent peer review and those required/unused tiny-edge controls. After exact peer PASS, one fresh <=300sCPU2 actual trial is authorized, all computed/material-dependency edge/miter/finite and physical guards unchanged. If a further pre-candidate source-domain blocker appears, preserve and diagnose it autonomously; you may perform one additional reviewed domain-only correction trial within a total two-next-trial/600s bound, no guard relaxation on any actual material dependency. Do not wait for root permission each time for that exact limited scope; any physical failure stops for concrete redesign. No app/photo/motion acceptance.

At v3 source freeze, neither of these two next-trial slots has been used. v3 is intended for fresh actual-three. No authorization in this record bypasses exact independent frozen source/caller/math PASS.
