# Close photographic anatomy references, actually viewed

2026-10-19. Two bounded Commons searches,16metadata results; three original
photographs downloaded and actually opened. No model/evaluator/geometry/texture,
app, ticket or source-registry write. These MODERN photographs supply comparative
anatomy only: no attested1812/1835/1871/1904Chicago horse, breed prevalence,
period bridle, millimeter measurement or pressure claim follows.

## Qualified reference1: Henry,2008 — CC BY2.0

Neil McIntosh (Flickr Harlequeen), *Close up of Henry nose n bridle*,2008-05-03.
Commons file: https://commons.wikimedia.org/wiki/File:Close_up_of_Henry_nose_n_bridle_(2471910476).jpg
Primary source: https://www.flickr.com/photos/harlequeen/2471910476/
License: https://creativecommons.org/licenses/by/2.0/

The exact Commons file-page wikitext explicitly declares cc-by-2.0, named author,
source and date. Its FlickreviewR record says passed2018-03-07, reviewlicense
cc-by-2.0, and retains a2019 archived source URL. Both that wikitext and API
metadata are saved. Retain attribution/source/license and change indication when
redistributing/adapting. This audit preserves the unmodified downloaded original;
no pixels have been derived into assets. Credit: Neil McIntosh / CC BY2.0.

Actual3024x1998 pixels: soft rounded lower-lip/chin mass, upper muzzle volume,
fine short coat, coarse long vibrissae, uneven pigmentation, small skin creases,
and an open mouth with some teeth visible. The bit guard obscures the actual
commissure entry, and the flash is annotated left open while resting. Thus this
is NOT a neutral apposed-lip or unobscured bit-portal photograph. The blue nylon
halter, particular flash/bit guard and modern tack must NOT be imported into a
period scene from this comparative reference. Horse identity Henry is attested
only in this modern source, never assigned to a Chicago-era model.

## Qualified reference2: Breton horse with Liverpool bit,2017 — CC BY-SA4.0

Tsaag Valren, *Liverpool bit - Breton horse*,2017-08-06.
Commons file: https://commons.wikimedia.org/wiki/File:Liverpool_bit_-_Breton_horse.jpg
License: https://creativecommons.org/licenses/by-sa/4.0/

The exact file page explicitly declares own work, named author/date and
self|cc-by-sa-4.0. API metadata agrees. Preserve attribution/source/license and
share-alike requirements on adapted image material. This unmodified photograph
remains separately licensed; no GPL/CC0 license is asserted for the photograph,
and no photo texture/model derivative has been generated. Credit: Tsaag Valren /
CC BY-SA4.0.

Actual4000x3000 pixels: a broad fleshy muzzle, rounded chin pad, a narrow curved
lip seam and tissue folding around the mouthpiece. Hair direction, several long
vibrissae and small surface irregularities are visible. The metal cheek/shank
partly hides the corner and the far side is unseen. It gives NO absolute tissue
thickness/clearance, internal cavity section, bit-contact force or historical
Chicago equipment attribution. The source labels the modern animal Breton; do
not relabel it an attested Chicago horse or use2017gear as period evidence.

## Provisional, excluded from redistribution capsule

Violeta Pencheva, *Gray horse wearing a bridle (Unsplash)*,2014-10-18,
https://commons.wikimedia.org/wiki/File:Gray_horse_wearing_a_bridle_(Unsplash).jpg
was downloaded and actually viewed at3132x2661. API labels CC0 and the page links
an archived2017-05-04 Unsplash source, but exact wikitext also lists review needed
and only invokes the Unsplash template. This bounded audit has NOT read the
archived licensing page. Therefore no independent CC0 clearance or asset use is
claimed. The downloaded image stays local research-only and is excluded from
this redistribution capsule; metadata/source locator/hash remain recoverable.
It mostly depicts eye/jaw/neck and a cropped muzzle, so it does not close the
unobscured neutral-mouth reference gap.

## What this changes in assessment

The actual419a mouth is a worthwhile engineering/visible cleanup, but its
perfect circular empty portal and flat faceted brown muzzle remain photographic
UNACCEPTED. These photos support fleshy continuous lip/chin volumes, a thin
curved labial seam, hair/vibrissae and irregular skin, consistent with Cuyer Fig92;
they do NOT supply a measured replacement portal. Both useful bitted close-ups
have some corner occlusion. A healthy unbitted, unobscured neutral-lip profile
and paired frontal/quarter photo remain missing in this bounded search.

Next review should include the existing419a with its physically checked actual
fe76 gear, and keep the horse-only view visible. A gear object may naturally
occupy its mouth opening; it must not serve as an invented occluder to disguise
bad tissue. Further geometry must remain a fixed source-owned anatomical plan
with independent review and all original physical guards; no blind gap/radius
sweep or metric claim from these perspective photos. No new geometry or trial is
released by this research audit.
