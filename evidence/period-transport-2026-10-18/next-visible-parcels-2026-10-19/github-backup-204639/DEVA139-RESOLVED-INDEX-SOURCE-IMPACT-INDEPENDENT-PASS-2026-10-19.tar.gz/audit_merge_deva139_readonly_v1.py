#!/usr/bin/env python3
"""Read-only independent index/parent/source-union/canonical-derived audit. Writes outside evidence only."""
import pathlib,subprocess,json,hashlib,tempfile,re,importlib.util,datetime,sys
ROOT=pathlib.Path('/workspace/chicago');APP=ROOT/'chicago/4d';OUT=pathlib.Path('/workspace/shared/merge-dev-a139-independent-resolved-audit-v1');OUT.mkdir(exist_ok=False)
def git(*a):return subprocess.check_output(['git','-C',str(ROOT),*a])
def h(b):return hashlib.sha256(b).hexdigest()
def need(c,m):
 if not c:raise ValueError(m)
def tree(ref):
 b=git('ls-tree','-rz',ref);r={}
 for row in b.split(b'\0'):
  if not row:continue
  meta,p=row.split(b'\t',1);mode,kind,sha=meta.decode().split();r[p.decode()]=(mode,sha)
 return r
def blob(ref,p):return git('show',ref+':'+p)
def loadmodule(name,path):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
sys.path.insert(0,str(APP/'tools'))
ours=git('rev-parse','HEAD').decode().strip();theirs=git('rev-parse','MERGE_HEAD').decode().strip();base=git('merge-base',ours,theirs).decode().strip();need(ours=='f2f607b0b6a82e9973c260d55c57fc4b661fb0b4'and theirs=='a139f5cf41b5710a4c950caa3fc88f380af58c10','parent identity changed')
B,A,T=map(tree,[base,ours,theirs]);index={};stages=[]
start_index=git('ls-files','--stage','-z')
for row in start_index.split(b'\0'):
 if not row:continue
 meta,p=row.split(b'\t',1);mode,sha,stage=meta.decode().split();stages.append(stage);index[p.decode()]=(mode,sha)
need(all(x=='0'for x in stages),'unmerged index stages remain')
manual={'chicago/4d/docs/LIBERTIES.md','chicago/4d/data/liberties.json','chicago/4d/data/sidecars/1835/sources/index.json','chicago/4d/docs/measurements/source_use_coverage.md'}
rows=[];errors=[];both=[]
with tempfile.TemporaryDirectory(prefix='merge-parent-audit-',dir=OUT)as td:
 td=pathlib.Path(td)
 for p in sorted(set(B)|set(A)|set(T)|set(index)):
  b,a,t,i=B.get(p),A.get(p),T.get(p),index.get(p)
  expected=None;kind=''
  if a==t:expected=a;kind='identical parents'
  elif a==b:expected=t;kind='theirs-only change'
  elif t==b:expected=a;kind='ours-only change'
  else:
   both.append(p)
   if p in manual:rows.append({'path':p,'class':'manual source/canonical derived (audited separately)','index':i});continue
   need(a is not None and b is not None and t is not None,'unsupported dual add/delete '+p)
   bs=[blob(ref,p)for ref in [ours,base,theirs]]
   for name,bb in zip(['ours','base','theirs'],bs):(td/name).write_bytes(bb)
   r=subprocess.run(['git','merge-file','-p',str(td/'ours'),str(td/'base'),str(td/'theirs')],capture_output=True)
   need(r.returncode==0,'unexpected nonclean dual-change merge '+p)
   actual=git('show',':'+p);ok=actual==r.stdout and i[0]==a[0];rows.append({'path':p,'class':'independent clean merge-file reproduction','PASS':ok,'index_sha256':h(actual),'expected_sha256':h(r.stdout)})
   if not ok:errors.append(p)
   continue
  ok=i==expected;rows.append({'path':p,'class':kind,'PASS':ok})
  if not ok:errors.append(p)
# Independently extract insertion-only source deltas from Git zero-context byte patches.
p='chicago/4d/docs/LIBERTIES.md';basebytes=blob(base,p);lines=basebytes.splitlines(keepends=True);edits=[]
for side,ref in [('ours',ours),('theirs',theirs)]:
 patch=git('diff','--no-ext-diff','--text','--unified=0',base,ref,'--',p);(OUT/(side+'-source-insertions.patch')).write_bytes(patch);pos=None;blocks=[]
 for line in patch.splitlines(keepends=True):
  if line.startswith(b'@@ '):
   if pos is not None:blocks.append((pos,b''.join(block)))
   mm=re.match(rb'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',line);need(mm is not None,'unparsed source hunk');need(int(mm[2]or b'1')==0,'source has deletion/replacement '+side);pos=int(mm[1]);block=[]
  elif pos is not None:
   if line.startswith(b'+'):block.append(line[1:])
   elif line.startswith(b'\\ No newline'):need(False,'unexpected no-newline source hunk')
   elif line.startswith(b'-'):need(False,'source deleted line '+side)
 if pos is not None:blocks.append((pos,b''.join(block)))
 restored=list(lines)
 for pos,bb in reversed(blocks):restored[pos:pos]=bb.splitlines(keepends=True)
 need(b''.join(restored)==blob(ref,p),'independent insertion reconstruction does not reproduce '+side)
 edits += [{'side':side,'base_line':pos,'bytes':bb,'sha256':h(bb)}for pos,bb in blocks]
actual=git('show',':'+p);need(actual==(APP/'docs/LIBERTIES.md').read_bytes(),'source working tree/index differ')
merged=[];cursor=0;ambiguity=[]
for pos in sorted({x['base_line']for x in edits}):
 merged+=lines[cursor:pos];same=[x for x in edits if x['base_line']==pos]
 if len(same)>1:
  chunks=[x['bytes']for x in same];need(len(same)==2,'unexpected multi-insertion tie')
  if chunks[0]+chunks[1]in actual:chosen=chunks
  elif chunks[1]+chunks[0]in actual:chosen=chunks[::-1]
  else:need(False,'same-anchor insertions not adjacent/preserved')
  ambiguity.append({'base_line':pos,'ordering':'one of both valid byte-preserving concatenations; independently matched actual'})
 else:chosen=[same[0]['bytes']]
 for bb in chosen:merged+=bb.splitlines(keepends=True)
 cursor=pos
merged+=lines[cursor:];expected=b''.join(merged);need(actual==expected,'source merge is not exact insertion union')
source={'PASS':True,'base_sha256':h(basebytes),'ours_sha256':h(blob(ours,p)),'theirs_sha256':h(blob(theirs,p)),'merged_sha256':h(actual),'preserved_all_parent_insertions':True,'base_bytes_preserved':True,'insertion_blocks':[{k:v for k,v in e.items()if k!='bytes'}for e in edits],'same_anchor_order':ambiguity}
# Rebuild canonical values entirely in memory, comparing both serialized bytes and staged bytes.
cl=loadmodule('merge_audit_compile_liberties',APP/'tools/compile_liberties.py');doc,problems=cl.build();need(not problems,'canonical liberties source problems '+repr(problems));libbody=(json.dumps(doc,indent=2,ensure_ascii=False)+'\n').encode();derived=[]
cs=loadmodule('merge_audit_compile_source_use',APP/'tools/compile_source_use.py');outputs,report=cs.compile_outputs(APP)
for p,expected in [('chicago/4d/data/liberties.json',libbody),('chicago/4d/data/sidecars/1835/sources/index.json',outputs['index.json'].encode()),('chicago/4d/docs/measurements/source_use_coverage.md',report.encode())]:
 staged=git('show',':'+p);working=(ROOT/p).read_bytes();ok=staged==working==expected;derived.append({'path':p,'PASS':ok,'canonical_sha256':h(expected),'index_sha256':h(staged),'working_sha256':h(working),'canonical_bytes':len(expected)})
 if not ok:errors.append(p)
# Detect any unexpected post-audit index mutation during this read.
need(git('rev-parse','HEAD').decode().strip()==ours and git('rev-parse','MERGE_HEAD').decode().strip()==theirs,'parents changed during audit')
end_index=git('ls-files','--stage','-z');need(end_index==start_index,'Index changed during audit')
summary={'scope':'Read-only independent complete index vs three parents; source byte union and in-memory canonical derivation. No app write/test/browser/API/CI mutation','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parents':{'base':base,'ours':ours,'theirs':theirs},'index_unchanged_during_audit':True,'index_listing_sha256':h(start_index),'index_paths':len(index),'dual_changed_paths':both,'classification_counts':{k:sum(r['class']==k for r in rows)for k in sorted({r['class']for r in rows})},'source_union':source,'canonical_three':derived,'errors':errors,'PASS':not errors}
(OUT/'all-index-paths.json').write_text(json.dumps(rows,indent=2)+'\n');(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2));sys.exit(0 if not errors else 1)
