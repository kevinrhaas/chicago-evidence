from pathlib import Path
import subprocess,json,hashlib,difflib
P=Path(__file__).parent;repo=Path('/workspace/chicago');sha='2726042ad9ea217687fab5525529bdee21656011';orig={}
for name in ['human_era_study_blend.py','human_era_study_common.py']:
 raw=subprocess.check_output(['git','-C',str(repo),'show',sha+':chicago/4d/tools/'+name]);orig[name]=raw
(P/'preimages').mkdir(exist_ok=True)
for name,raw in orig.items():(P/'preimages'/name).write_bytes(raw)
s=orig['human_era_study_blend.py'].decode()
helper='''\n\ndef record_failure(args, error):
    """Diagnostic only: persist actual traceback and expose it as a CI annotation.

    The caller always re-raises the original exception. No retry, normal repair,
    numerical normalization, acceptance downgrade or success receipt is supplied.
    """
    import os
    import traceback
    details = {"PASS": False, "scene": args.era_study,
               "scope": "Actual canonical authoring failure; no master/export acceptance",
               "error_type": type(error).__name__, "error": str(error),
               "traceback": "".join(traceback.format_exception(type(error), error, error.__traceback__))}
    # Emit before receipt I/O, so a secondary filesystem error cannot conceal
    # the primary failure. Workflow command newlines/% are escaped explicitly.
    if os.environ.get("GITHUB_ACTIONS") == "true":
        message = details["traceback"][-6000:]
        message = message.replace("%", "%25").replace("\\r", "%0D").replace("\\n", "%0A")
        print("::error title=Era study " + args.era_study + " authoring failed::" + message, flush=True)
    if args.receipt:
        path = args.receipt.with_name("authoring-failure.json")
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("x") as file:
            json.dump(details, file, indent=2)
            file.write("\\n")
    return details
'''
s=s.replace('\n\nif __name__ == "__main__":',helper+'\n\nif __name__ == "__main__":')
s=s.replace('    main(parse(argv))','''    args = parse(argv)
    try:
        main(args)
    except Exception as error:
        try:
            record_failure(args, error)
        except Exception as diagnostic_error:
            print("Could not save authoring failure receipt: " + repr(diagnostic_error), file=sys.stderr)
        raise''')
(P/'proposed/tools/human_era_study_blend.py').write_text(s)
s=orig['human_era_study_common.py'].decode();needle='"Unchanged RAW1e-3 source-body normal readback failed")';replacement='f"Unchanged RAW1e-3 source-body normal readback failed: mesh={obj.name} maximum_raw_vector_delta={delta:.17g} bound=0.001")';assert s.count(needle)==1;s=s.replace(needle,replacement);(P/'proposed/tools/human_era_study_common.py').write_text(s)
patch=''
for name,raw in orig.items():patch+=''.join(difflib.unified_diff(raw.decode().splitlines(True),(P/'proposed/tools'/name).read_text().splitlines(True),fromfile='a/chicago/4d/tools/'+name,tofile='b/chicago/4d/tools/'+name))
(P/'DIAGNOSTICS-ONLY.patch').write_text(patch);(P/'PREIMAGES.json').write_text(json.dumps({'commit':sha,'sha256':{name:hashlib.sha256(raw).hexdigest()for name,raw in orig.items()}},indent=2)+'\n')
