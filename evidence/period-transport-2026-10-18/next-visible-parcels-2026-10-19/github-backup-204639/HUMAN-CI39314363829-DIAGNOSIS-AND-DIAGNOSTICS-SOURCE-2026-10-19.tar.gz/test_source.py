"""Exact proposed handler AST controls only; no BPy or canonical model."""
from pathlib import Path
from types import SimpleNamespace
import ast,json,io,contextlib,os,tempfile,sys,hashlib
P=Path(__file__).parent;tree=ast.parse((P/'proposed/tools/human_era_study_blend.py').read_text());base=ast.parse((P/'preimages/human_era_study_blend.py').read_text());controls=[]
for name in ['parse','checked_inputs','main']:
 a=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name==name);b=next(n for n in base.body if isinstance(n,ast.FunctionDef)and n.name==name);assert ast.dump(a)==ast.dump(b);controls.append('Original '+name+' AST unchanged')
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='record_failure');ns={'json':json};exec(compile(ast.Module(body=[node],type_ignores=[]),'<exact proposed diagnostic handler>','exec'),ns)
with tempfile.TemporaryDirectory()as tmp:
 args=SimpleNamespace(era_study='1812',receipt=Path(tmp)/'master-receipt.json');before=os.environ.get('GITHUB_ACTIONS');os.environ['GITHUB_ACTIONS']='true'
 try:
  try:raise ValueError('Measured guard failure 100%\r\n::notice::not a new command')
  except ValueError as error:
   out=io.StringIO()
   with contextlib.redirect_stdout(out):result=ns['record_failure'](args,error)
   text=out.getvalue();assert text.count('\n')==1 and '%25'in text and '%0D%0A'in text and text.startswith('::error title=Era study 1812 authoring failed::');assert not args.receipt.exists()and result['PASS']is False and result['error_type']=='ValueError';saved=json.loads((Path(tmp)/'authoring-failure.json').read_text());assert saved==result and 'ValueError'in saved['traceback'];controls.append('Actual traceback, explicit failed receipt, escaped one-line annotation, no success receipt')
   old=(Path(tmp)/'authoring-failure.json').read_bytes()
   with contextlib.redirect_stdout(io.StringIO()):
    try:ns['record_failure'](args,error)
    except FileExistsError:pass
    else:raise AssertionError('Overwrite accepted')
   assert(Path(tmp)/'authoring-failure.json').read_bytes()==old;controls.append('Previous failure evidence cannot be overwritten')
 finally:
  if before is None:os.environ.pop('GITHUB_ACTIONS',None)
  else:os.environ['GITHUB_ACTIONS']=before
# Exact entrypoint retains original failure even if saving diagnostics itself fails.
entry=tree.body[-1];assert isinstance(entry,ast.If)
original=RuntimeError('original actual build failure');diagnostic=OSError('secondary receipt error');calls=[]
def main(_):raise original
def record(*_):calls.append('diagnostic');raise diagnostic
g={'sys':SimpleNamespace(argv=['script.py'],stderr=io.StringIO()), 'parse':lambda _:SimpleNamespace(), 'main':main,'record_failure':record}
with contextlib.redirect_stderr(io.StringIO()):
 try:exec(compile(ast.Module(body=entry.body,type_ignores=[]),'<exact proposed entrypoint>','exec'),g)
 except RuntimeError as e:assert e is original
 else:raise AssertionError('Original failure was swallowed')
assert calls==['diagnostic'];controls.append('Exact entrypoint reraises original failure after secondary diagnostic I/O error')
g.update(main=lambda _:calls.append('success'),record_failure=lambda *_:(_ for _ in ()).throw(AssertionError('diagnostic after success')));exec(compile(ast.Module(body=entry.body,type_ignores=[]),'<exact proposed entrypoint>','exec'),g);assert calls[-1]=='success';controls.append('Successful entrypoint never emits failure')
old=ast.parse((P/'preimages/human_era_study_common.py').read_text());new=ast.parse((P/'proposed/tools/human_era_study_common.py').read_text());oldcall=next(n for n in ast.walk(old)if isinstance(n,ast.Call)and n.args and isinstance(n.args[-1],ast.Constant)and n.args[-1].value=='Unchanged RAW1e-3 source-body normal readback failed');newcall=next(n for n in ast.walk(new)if isinstance(n,ast.Call)and any(isinstance(a,ast.JoinedStr)and any(isinstance(v,ast.Constant)and str(v.value).startswith('Unchanged RAW1e-3 source-body normal readback failed')for v in a.values)for a in n.args));assert ast.dump(oldcall.args[0])==ast.dump(newcall.args[0]);oldcall.args[1]=newcall.args[1];assert ast.dump(old)==ast.dump(new);controls.append('Entire common helper AST exact except diagnostic message; RAW1e-3 predicate unchanged')
r={'PASS':True,'scope':'Exact proposed handler/entrypoint and AST-preservation controls only; no BPy/model/export/browser/network.','controls':controls};(P/'SOURCE-CONTROLS.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
