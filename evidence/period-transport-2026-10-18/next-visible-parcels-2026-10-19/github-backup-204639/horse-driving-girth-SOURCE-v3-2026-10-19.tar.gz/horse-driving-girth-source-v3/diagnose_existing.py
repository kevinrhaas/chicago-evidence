# SPDX-License-Identifier: GPL-3.0-or-later
"""READ ONLY actual stored/source geometry diagnosis. No new mesh/evaluator/SAT."""
from pathlib import Path
import json,struct,hashlib,math
P=Path(__file__).parent
G=Path('/workspace/shared/horse-rear-harness-current-support-actual-idle-v5-one/candidate/candidate.glb')
C=Path('/workspace/shared/horse-rear-harness-current-support-actual-idle-v5-one/candidate/capture')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def glb(path):
 b=path.read_bytes();n=struct.unpack_from('<I',b,12)[0];return json.loads(b[20:20+n]),b[28+n:]
def accessor(d,b,i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];size={'SCALAR':1,'VEC3':3}[a['type']];fmt={5123:'H',5125:'I',5126:'f'}[a['componentType']];step=struct.calcsize(fmt)*size;assert v.get('byteStride',step)==step and'sparse'not in a
 off=v.get('byteOffset',0)+a.get('byteOffset',0);raw=b[off:off+a['count']*step];values=struct.unpack('<'+fmt*(a['count']*size),raw);return [list(values[j:j+size])for j in range(0,len(values),size)],raw
D,B=glb(G);meta=json.loads((C/'candidate.json').read_text());rows={r['name']:r for r in meta['meshes']}
report={'status':'READ_ONLY_EXISTING_GEOMETRY_AND_SOURCE_AUTHORITY_DIAGNOSIS; NO_NEW_MESH_OR_FIT','modelSHA256':sha(G),'captureMetadataSHA256':sha(C/'candidate.json'),'parts':{}}
selected=['girth','harness_saddle_pad','girth_billet_l','girth_billet_r','girth_buckle_l','girth_buckle_r','shaft_tug_support_l','shaft_tug_support_r','longitudinal_support_l','longitudinal_support_r']
for name in selected:
 mi=[i for i,m in enumerate(D['meshes'])if m['name']==name];assert len(mi)==1;p=D['meshes'][mi[0]]['primitives'][0];v,raw=accessor(D,B,p['attributes']['POSITION']);r=rows[name];assert r['sourceMesh']==mi[0]
 report['parts'][name]={'sourceMesh':mi[0],'sourcePrimitive':0,'positionSHA256':hashlib.sha256(raw).hexdigest(),'positions':len(v),'triangles':r['count'],'indexed':'indices'in p,'boundsRootM':[[min(q[k]for q in v)for k in range(3)],[max(q[k]for q in v)for k in range(3)]],'actualCaptureStart':r['start']}
# Source-only saddle/billet/buckle extrema identify incompatible nominal attachments;
# no inferred contact or shared seam is assigned by nearest coordinate.
report['existingSourceRouting']={'girth':{'widthM':.046,'thicknessM':.006,'centerY':1.16,'centerZ':-.08,'radiiXY':[.31,.395],'openCappedSections':37,'inclusiveFullTurn':True},'billets':{'widthM':.025,'thicknessM':.005,'leftCenterlineRootM':[[.32,1.30,-.08],[.32,1.10,-.08],[.27,.91,-.08]],'right':'X reflected'},'buckles':{'leftNominalCenterRootM':[.325,1.21,-.08],'right':'X reflected','metalSectionRadiusM':.003,'centerlineHalfExtentsYZM':[.022,.018]},'realHardwareContactAuthority':False}
report['closureNegative']={'diagnosticPath':'/workspace/shared/horse-girth-existing-CLOSURE-DIAGNOSTIC-2026-10-19.json','sha256':sha(Path('/workspace/shared/horse-girth-existing-CLOSURE-DIAGNOSTIC-2026-10-19.json')),'summary':'Nominal duplicate endpoint center, actual corresponding cap corners differ0.4110336mm. No indexed periodic seam or surface-contact authority.'}
(P/'EXISTING-SOURCE-DIAGNOSIS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'PASS':True,'scope':report['status'],'parts':len(selected),'girth':report['parts']['girth'],'saddle':report['parts']['harness_saddle_pad'],'buckle':report['parts']['girth_buckle_l']}))
