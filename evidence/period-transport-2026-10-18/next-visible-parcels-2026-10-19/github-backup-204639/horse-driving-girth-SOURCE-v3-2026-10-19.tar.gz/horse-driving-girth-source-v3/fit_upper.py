# SPDX-License-Identifier: GPL-3.0-or-later
"""Conservative full-inner-triangle distance upper bound using exact dyadic witnesses.
No nearest-face sign/inside, no vertex-only fit acceptance, no IO at import.
Every stored leaf covers its whole dyadic subtriangle by the distance function's
1-Lipschitz bound. Witness is an exact convex combination on one actual horse face.
"""
from fractions import Fraction as F
import math
D=1<<20

def need(q,m):
 if not q:raise ValueError(m)
def sqrt_upper(value):
 need(value>=0,'Nonnegative exact squared distance')
 r=math.sqrt(float(value))
 while F(r)*F(r)<value:r=math.nextafter(r,math.inf)
 return r

def norm_upper(a,b):return sqrt_upper(sum((F(x)-F(y))**2 for x,y in zip(a,b)))
def dyadic_witness(p,tri):
 # Numerical feature selection cannot invalidate ownership: integer nonnegative
 # barycentrics summing to D always represent a point on the exact actual face.
 sub=lambda a,b:[x-y for x,y in zip(a,b)];dot=lambda a,b:sum(x*y for x,y in zip(a,b))
 a,b,c=tri;u,v,w=sub(b,a),sub(c,a),sub(p,a);uu,uv,vv=dot(u,u),dot(u,v),dot(v,v);den=uu*vv-uv*uv
 choices=[]
 if den>0:
  y=(vv*dot(w,u)-uv*dot(w,v))/den;z=(uu*dot(w,v)-uv*dot(w,u))/den
  if y>=0 and z>=0 and y+z<=1:
   iy,iz=math.floor(y*D),math.floor(z*D);choices.append([D-iy-iz,iy,iz])
 for i,j in [(0,1),(1,2),(2,0)]:
  edge=sub(tri[j],tri[i]);s=dot(edge,edge);t=max(0.,min(1.,dot(sub(p,tri[i]),edge)/s))if s else 0.;n=math.floor(t*D);q=[0,0,0];q[i]=D-n;q[j]=n;choices.append(q)
 def point(weights):return [sum(F(tri[j][k])*weights[j]for j in range(3))/D for k in range(3)]
 weights=min(choices,key=lambda q:sum((F(p[k])-point(q)[k])**2 for k in range(3)))
 need(all(isinstance(x,int)and x>=0 for x in weights)and sum(weights)==D,'Exact actual face witness ownership')
 q=point(weights);return weights,sqrt_upper(sum((F(p[k])-q[k])**2 for k in range(3)))

def certificate(triangle,horse_faces,face_ids,bound,maximum_depth=12,maximum_leaves=32768):
 need(len(horse_faces)==len(face_ids)>0 and bound>0,'Owned nonempty horse support faces and fixed bound')
 # Choosing any real face produces a sound upper bound; AABB lower distances
 # only select a potentially useful face, never waive physical scans.
 from official_fit_predicates import point_triangle
 leaves=[];stack=[([[F(x)for x in p]for p in triangle],[],0)]
 while stack:
  t,path,depth=stack.pop();center=[float(sum(p[k]for p in t)/3)for k in range(3)]
  nearest=min(range(len(horse_faces)),key=lambda i:point_triangle(center,horse_faces[i]));weights,distance=dyadic_witness(center,horse_faces[nearest]);radius=max(norm_upper(p,center)for p in t);upper=math.nextafter(distance+radius,math.inf)
  if upper<=bound:
   need(len(leaves)<maximum_leaves,'Bounded full-face certificate leaves')
   leaves.append({'path':path,'query':center,'horseFace':int(face_ids[nearest]),'dyadicWeights':weights,'denominator':D,'witnessDistanceUpperM':distance,'radiusUpperM':radius,'wholeSubtriangleUpperM':upper});continue
  need(depth<maximum_depth,'Fixed maximum full-inner-surface gap cannot be certified; no tolerance/radius search')
  a,b,c=t;ab=[(a[k]+b[k])/2 for k in range(3)];bc=[(b[k]+c[k])/2 for k in range(3)];ca=[(c[k]+a[k])/2 for k in range(3)]
  children=[[a,ab,ca],[ab,b,bc],[ca,bc,c],[ab,bc,ca]]
  for i in reversed(range(4)):stack.append((children[i],path+[i],depth+1))
 return {'complete':True,'boundM':bound,'wholeFaceLipschitzUpper':True,'exactRationalHorseWitness':True,'leaves':leaves}
