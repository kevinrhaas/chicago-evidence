// SPDX-License-Identifier: GPL-3.0-or-later
// Synthetic only; v1 immutable reference and v2 source-domain equivalence.
import assert from 'node:assert/strict';
import {fromSupport as before} from '/workspace/shared/horse-driving-girth-source-proposal/evaluate.mjs';
import {fromSupport as after} from './evaluate.mjs';
let checks=0;
for(const n of[24,36,48,60])for(const scale of[.85,1,1.15])for(const angle of[0,.071]){
 const p=Array.from({length:n},(_,i)=>{const t=2*Math.PI*i/n+angle;return [.31*scale*Math.cos(t),1.16+.395*scale*Math.sin(t)];});const a=before(p),b=after(p);assert.deepEqual([...a.positions],[...b.positions]);assert.deepEqual([...a.normals],[...b.normals]);assert.deepEqual([...a.indices],[...b.indices]);assert.deepEqual(a.pairs,b.pairs);assert.deepEqual(a.stationOwners,b.stationOwners);assert.equal(a.centerlineLengthM,b.centerlineLengthM);checks++;
}
console.log(JSON.stringify({PASS:true,syntheticCompleteArrayComparisons:checks,scope:'Bit-identical material geometry/source station ownership vs immutable v1 wherever v1 domain is valid; no actual horse/mesh/evaluator/candidate'}));
