# SPDX-License-Identifier: GPL-3.0-or-later
"""Independent actual indexed seam, fixed dimensions, preservation and full self guard."""
from pathlib import Path
import importlib.util,json,hashlib,copy,sys,signal,time,numpy as np
R=Path('/workspace/shared/horse-rear-harness-current-support-source/check_serialized.py')
spec=importlib.util.spec_from_file_location('reviewed_rear_serialized',R);base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
P=Path(__file__).parent;PARENT=Path('/workspace/shared/horse-rear-harness-current-support-actual-idle-v5-one/candidate/candidate.glb');PARENT_SHA='1fb25fbe561e8d2607431f7f569caaf594217263437151df98fa8c91c66da948'
need=base.need;sha=lambda b:hashlib.sha256(b).hexdigest()
def index_values(d,b,i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];need(a['componentType']==5125 and a['type']=='SCALAR'and not a.get('normalized')and'sparse'not in a and'byteStride'not in v,'Actual complete Uint32 index accessor');start=v.get('byteOffset',0)+a.get('byteOffset',0);need(a['count']>0 and a['count']%3==0 and a.get('byteOffset',0)+a['count']*4<=v['byteLength']and start+a['count']*4<=d['buffers'][0]['byteLength']<=len(b),'Complete actual index extent');return np.frombuffer(b,dtype='<u4',count=a['count'],offset=start).reshape(-1,3)
def ownership(source):
 n=source['rings'];need(isinstance(n,int)and n>=3,'Actual source station count');expected_v=[{'station':j,'section':k}for j in range(n)for k in ['inner_back','inner_front','outer_front','outer_back']];need(source['vertexOwners']==expected_v,'Every actual vertex has exactly one station/section owner')
 f=[];o=[]
 for j in range(n-1):
  for k in range(4):
   a=j*4+k;b=j*4+(k+1)%4;f.extend([[a,b,b+4],[a,b+4,a+4]]);o.extend([{'kind':'strip_segment','station':j,'sectionEdge':k,'half':0},{'kind':'strip_segment','station':j,'sectionEdge':k,'half':1}])
 last=4*n-4;f.extend([[0,2,1],[0,3,2],[last,last+1,last+2],[last,last+2,last+3]]);o.extend([{'kind':'upper_end_cap','side':s,'half':h}for s in ['l','r']for h in range(2)])
 if source['reversedWinding']:f=[[a,c,b]for a,b,c in f]
 need(source['faces']==f and source['faceOwners']==o,'Exact complete actual indexed shell/caps, no coordinate welding or coincident extra caps');need(source['innerFaceIds']==[i for i,x in enumerate(o)if x['kind']=='strip_segment'and x['sectionEdge']==0],'Complete actual inner material face set');return {'ownedStations':n,'actualIndexSeam':True,'uniqueUpperCaps':2,'circumferentialLoop':False,'sharedHardwareContact':False}
def dimensions(source):
 p=np.array(source['verticesRootM'],float);rings=p.reshape(-1,4,3);bound=256*np.finfo(float).eps*max(1,float(np.max(np.abs(p))));we=[];te=[]
 need(len(p)==source['rings']*4 and np.isfinite(p).all(),'All source material rings');need(np.array_equal(p.astype('<f4').astype(float),source['verticesFloat32']),'Exact independently decoded Float32 rounding')
 for ring in rings:
  for a,b in [(ring[0],ring[1]),(ring[3],ring[2])]:we.append(abs(float(np.linalg.norm(b-a))-.046))
  need(max(abs(ring[0,2]+.103),abs(ring[1,2]+.057),abs(ring[2,2]+.057),abs(ring[3,2]+.103))<=bound,'Exact fixed full-width Z slab')
 for a,b in zip(rings,rings[1:]):
  inner=(a[0]+a[1])/2;other=(b[0]+b[1])/2;n=np.cross(other-inner,[0,0,1]);ln=np.linalg.norm(n);need(ln>1e-12,'Nondegenerate source girth segment');n/=ln
  for ring in [a,b]:te.append(abs(abs(float(((ring[2]+ring[3]-ring[0]-ring[1])/2)@n))-.006))
 need(max(we)<=bound and max(te)<=bound,'Unchanged46mm width and6mm support-plane thickness construction bound');need(rings[0,0,1]==rings[-1,0,1]==1.21,'Fixed upper inner termination Y1.21, not inferred hardware match');return {'widthM':.046,'supportPlaneThicknessM':.006,'constructionBoundM':bound,'maximumWidthErrorM':max(we),'maximumThicknessErrorM':max(te),'miterDiagonalIsNotThickness':True}
def main():
 need(len(sys.argv)==2,'One candidate dir');d=Path(sys.argv[1]);out=d/'SERIALIZED-CHECK.json';need(not out.exists(),'Exclusive serialized receipt');start=time.monotonic();r={'PASS':False,'scope':'Actual indexed girth shell, all35protected streams, dimensions and complete self only'}
 def timeout(*_):raise TimeoutError('90s oneCPU serialized bound')
 signal.signal(signal.SIGALRM,timeout);signal.alarm(90)
 try:
  parent=PARENT.read_bytes();need(sha(parent)==PARENT_SHA,'Qualified parent1fb25 exact');raw=(d/'candidate.glb').read_bytes();side=json.loads((d/'SIDECAR.json').read_text());build=json.loads((d/'BUILD-RESULT.json').read_text());logicalRaw=(d/'LOGICAL-SOURCE.json').read_bytes();s=json.loads(logicalRaw);need(build['PASS']is True and build['candidateSHA256']==side['candidateSHA256']==s['candidateSHA256']==sha(raw),'One actual candidate binding');need(build['sidecarSHA256']==sha((d/'SIDECAR.json').read_bytes())and build['logicalSourceSHA256']==sha(logicalRaw),'Actual source stream ownership');need(build['sourceInventorySHA256']==sha((P/'SOURCE-INVENTORY.json').read_bytes()),'Reviewed executable identity');a,ab=base.read_glb(parent);b,bb=base.read_glb(raw);need(bb.startswith(ab),'All original binary bytes including qualified rear3 exact');need(len(a['meshes'])==len(b['meshes'])==36 and [m['name']for m in a['meshes']]==[m['name']for m in b['meshes']]and len({m['name']for m in b['meshes']})==36,'All36 names/source associations preserved');restored=copy.deepcopy(b)
  for i,(am,bm)in enumerate(zip(a['meshes'],b['meshes'])):
   if am['name']=='girth':
    pr=copy.deepcopy(bm['primitives'][0]);old=am['primitives'][0];need(len(bm['primitives'])==len(am['primitives'])==1 and am!=bm,'Only one original girth changed');pr['attributes']=copy.deepcopy(old['attributes']);pr.pop('indices',None);need(pr==old,'Every original girth non-stream field preserved');restored['meshes'][i]=copy.deepcopy(am)
   else:need(am==bm,'Protected primitive descriptor byte-equivalent '+am['name'])
  need(len(b['accessors'])==len(a['accessors'])+3 and len(b['bufferViews'])==len(a['bufferViews'])+3,'Exactly3 appended position/normal/index streams');restored['accessors']=restored['accessors'][:len(a['accessors'])];restored['bufferViews']=restored['bufferViews'][:len(a['bufferViews'])];restored['buffers']=copy.deepcopy(a['buffers']);need(restored==a,'All other source/node/rig/material/provenance fields exact');mesh=next(m for m in b['meshes']if m['name']=='girth');pr=mesh['primitives'][0];need(pr.get('mode',4)==4 and set(pr['attributes'])=={'POSITION','NORMAL'}and'indices'in pr,'Actual indexed triangle girth');pos=base.values(b,bb,pr['attributes']['POSITION']);normal=base.values(b,bb,pr['attributes']['NORMAL']);faces=index_values(b,bb,pr['indices']);need(np.array_equal(pos,s['verticesFloat32'])and np.array_equal(faces,s['faces'])and len(normal)==len(pos),'Every actual position/index decoded against exact source aliases');own=ownership(s);top,edges=base.topology(faces.tolist(),pos.tolist());tri=pos[faces];cross=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);need(np.min(np.linalg.norm(cross,axis=1)/2)>1e-12,'All actual indexed facets nondegenerate');need(np.max(abs(np.linalg.norm(normal,axis=1)-1))<1e-6 and np.all((normal[faces]*cross[:,None,:]).sum(2)>0),'Actual unit outward indexed normals');need(float(np.einsum('ij,ij->i',tri[:,0],np.cross(tri[:,1],tri[:,2])).sum()/6)>1e-12,'Positive actual outward material volume');base.predicates.predicate_controls();r.update({'ownership':own,'topology':top,'dimensions':dimensions(s),'self':base.self_check('girth',tri,faces.tolist(),edges,r),'candidateSHA256':sha(raw),'protectedParts':35,'PASS':True})
 except BaseException as e:r['error']=repr(e);raise
 finally:signal.alarm(0);r['elapsedS']=time.monotonic()-start;out.write_text(json.dumps(r,indent=2)+'\n')
if __name__=='__main__':main()
