// SPDX-License-Identifier: GPL-3.0-or-later
// Source-owned OPEN lower-support domain. Original reviewed corner arithmetic
// and ALL original corner refusals retained wherever a value is computed.
const need=(q,m)=>{if(!q)throw Error(m);};
const sub=(a,b)=>a.map((v,i)=>v-b[i]),dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0),unit=a=>{const d=Math.hypot(...a);need(d>1e-12&&Number.isFinite(d),'Degenerate unit frame');const inverse=1/d;return a.map(v=>v*inverse);};
export function offsetCorner(poly,i,r){
 need(r>0&&Number.isFinite(r),'Positive construction allowance');const q=poly[i],prev=poly[(i+poly.length-1)%poly.length],next=poly[(i+1)%poly.length];need(q&&prev&&next&&[...q,...prev,...next].every(Number.isFinite),'All computed corner dependencies present');const a=unit(sub(q,prev)),b=unit(sub(next,q)),na=[a[1],-a[0]],nb=[b[1],-b[0]],d=na[0]*nb[1]-na[1]*nb[0];need(Math.abs(d)>1e-14,'Degenerate offset support corner');const denominator=1+dot(na,nb);need(denominator>1e-14,'Nondegenerate finite outward normal bisector');const scale=r/denominator,out=q.map((v,k)=>v+(na[k]+nb[k])*scale);need(out.every(Number.isFinite),'Finite offset support');return out;
}
export function lowerDependencies(poly,cut){
 need(poly.length>=3&&poly.every(q=>q.length===2&&q.every(Number.isFinite)),'Complete finite source hull');const n=poly.length,seed=[];
 // Raw selector uses identity/order only; normalization minimum applies unchanged
 // inside offsetCorner on EVERY actual computed material dependency.
 for(let i=0;i<n;i++){const prev=poly[(i+n-1)%n],q=poly[i],next=poly[(i+1)%n];need(q.some((v,k)=>v!==prev[k])&&next.some((v,k)=>v!==q[k]),'Distinct source hull vertices');const upwardOnly=q[1]>cut&&prev[0]>=q[0]&&q[0]>=next[0];if(!upwardOnly)seed.push(i);}
 const closure=k=>[...new Set(seed.flatMap(i=>Array.from({length:2*k+1},(_,j)=>(i+j-k+n)%n)))].sort((a,b)=>a-b),innerRequired=closure(2),outerRequired=closure(1),have=new Set(innerRequired);
 const uncomputedUpper=Array.from({length:n},(_,i)=>i).filter(i=>!have.has(i)).map(i=>({corner:i,previous:(i+n-1)%n,next:(i+1)%n,point:poly[i],previousPoint:poly[(i+n-1)%n],nextPoint:poly[(i+1)%n],sourceAboveCut:true,monotoneUpperX:true}));
 return {cutY:cut,seed,innerRequired,outerRequired,uncomputedUpper,proof:'Only omit rawY>cut and previousX>=pointX>=nextX: each adjoining CCW outward normal has nonnegativeY. Positive offset cannot move that corner belowcut. Two inner-neighbor layers cover outer corner/cut-endpoint dependencies; one outer layer covers cut endpoints. No omitted corner is evaluated.'};
}
export function offsetLower(poly,innerRadius,thickness,cut,miterBound){
 const deps=lowerDependencies(poly,cut),inner=poly.map(()=>null),outer=poly.map(()=>null);for(const i of deps.innerRequired){inner[i]=offsetCorner(poly,i,innerRadius);need(Math.hypot(...sub(inner[i],poly[i]))<=miterBound,'Fixed computed-inner miter bound');}for(const i of deps.outerRequired){outer[i]=offsetCorner(inner,i,thickness);need(Math.hypot(...sub(outer[i],inner[i]))<=miterBound,'Fixed computed-outer miter bound');}return {inner,outer,offsetDependency:deps};
}
