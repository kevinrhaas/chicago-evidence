from pathlib import Path
import json,hashlib
P=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
R=Path('/workspace/shared/horse-rear-harness-current-support-source');old=json.loads((R/'SOURCE-INVENTORY.json').read_text());external=dict(old['external'])
for n in ['evaluate.mjs','controller.mjs','check_serialized.py','SOURCE-INVENTORY.json']:
 p=R/n;external[str(p)]=sha(p)
for n in ['/workspace/shared/horse-rear-harness-current-support-actual-idle-v5-one/candidate/candidate.glb','/workspace/shared/horse-rear-harness-current-support-actual-idle-v5-one/candidate/capture/candidate.json','/workspace/shared/horse-rear-harness-current-support-actual-idle-v5-one/candidate/capture/horse.json','/workspace/shared/horse-girth-existing-CLOSURE-DIAGNOSTIC-2026-10-19.json','/workspace/shared/horse-rear-harness-idle-ab-visual-actual-two/1280-side-fitted.png','/workspace/shared/horse-rear-harness-idle-ab-visual-actual-two/1280-rear-fitted.png','/workspace/chicago-tickets/evidence/period-transport-2026-10-18/equine-source-acquisition.md','/workspace/shared/horse-headgear-contour-candidate/source/generate_harness.original.py']:
 external[n]=sha(Path(n))
for n in ['/workspace/shared/horse-driving-girth-source-proposal/evaluate.mjs','/workspace/shared/horse-driving-girth-source-proposal/SOURCE-INVENTORY.json','/workspace/shared/horse-driving-girth-period1904-full-source-review.json','/workspace/shared/horse-driving-girth-FIRST-SUPPORT-CORNER-FAILURE-2026-10-19.tar.gz']:
 external[n]=sha(Path(n))
for n in ['/workspace/shared/horse-driving-girth-source-v2/SOURCE-INVENTORY.json','/workspace/shared/horse-driving-girth-v2-period1904-full-source-review.json','/workspace/shared/horse-driving-girth-v2-period1904-independent-domain-proof.json','/workspace/shared/horse-driving-girth-SECOND-UNUSED-EDGE-FAILURE-2026-10-19.tar.gz']:
 external[n]=sha(Path(n))
files={p.name:sha(p)for p in sorted(P.iterdir())if p.is_file()and p.name!='SOURCE-INVENTORY.json'}
d={'status':'Frozen v3 SOURCE ONLY. v1 and v2 build refusals remain immutable. Exact full independent v3 source/caller/math PASS is required before root-authorized domain-only actual-three; two next windows total <=600s, each <=300s CPU2 one math thread. No next slot consumed at freeze.','files':files,'external':external,'changed':['girth'],'protected35Includes':['breeching','hip_support_l','hip_support_r'],'parentGearSHA256':'1fb25fbe561e8d2607431f7f569caaf594217263437151df98fa8c91c66da948','horseSHA256':'ab70aff958bc8a2780458d37212be1866c730817f485fbebbf53bd3c0e3931c3'}
(P/'SOURCE-INVENTORY.json').write_text(json.dumps(d,indent=2,sort_keys=True)+'\n');print(json.dumps({'sourceInventorySHA256':sha(P/'SOURCE-INVENTORY.json'),'owned':len(files),'external':len(external)}))
