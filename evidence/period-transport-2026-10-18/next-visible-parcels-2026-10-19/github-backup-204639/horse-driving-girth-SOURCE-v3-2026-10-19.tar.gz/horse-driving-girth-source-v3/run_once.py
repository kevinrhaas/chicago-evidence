# SPDX-License-Identifier: GPL-3.0-or-later
"""Root-preauthorized ONE <=300s CPU2 idle girth trial AFTER full independent review.
First failure stops. No browser/motion/app writes. All operator logs are exclusive.
"""
from pathlib import Path
import json,hashlib,subprocess,sys,time,os,signal,argparse
P=Path(__file__).resolve().parent
need=lambda q,m:None if q else (_ for _ in ()).throw(ValueError(m))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--independent-review',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();review=a.independent_review.resolve();out=a.output.resolve();raw=(P/'SOURCE-INVENTORY.json').read_bytes();inventory=json.loads(raw);review_doc=json.loads(review.read_bytes());source_sha=hashlib.sha256(raw).hexdigest();need(review_doc.get('PASS')is True and review_doc.get('reviewer')=='period_1904'and review_doc.get('reviewScope')=='FULL_FROZEN_SOURCE_CALLER_MATH'and review_doc.get('sourceInventorySHA256')==source_sha,'Full independent executable/math review bound to current frozen source before actual trial');need(os.sched_getaffinity(0)=={2},'Root authorized exclusiveCPU2 taskset only')
 def pins():
  for n,h in inventory['files'].items():need(not Path(n).is_absolute()and'..'not in Path(n).parts and sha(P/n)==h,'Frozen owned source '+n)
  for n,h in inventory['external'].items():need(sha(Path(n))==h,'Frozen external source/input '+n)
 pins();need(not out.exists(),'Fresh exclusive actual output');out.mkdir();candidate=out/'candidate';start=time.monotonic();r={'PASS':False,'scope':'ONE girth-only actual idle0 trial; no motion/app/forces/completehitch/photo acceptance','boundS':300,'cpuAffinity':[2],'mathThreads':1,'sourceInventorySHA256':source_sha,'independentReviewSHA256':sha(review),'rootPreauthorizationSHA256':sha(P/'ROOT-AUTHORIZATION.md'),'stages':[]};save=lambda:(out/'OPERATOR.json').write_text(json.dumps({**r,'elapsedS':time.monotonic()-start},indent=2)+'\n');save();node=['node','--loader',str(P/'three-loader.mjs')]
 commands=[('build_idle',node+[str(P/'build_idle_once.mjs'),str(review),str(candidate)],30,'BUILD-RESULT.json'),('serialized_scope_indexownership_dimensions_self',[sys.executable,str(P/'check_serialized.py'),str(candidate)],90,'SERIALIZED-CHECK.json'),('khronos',node+[str(P/'validate_candidate.mjs'),str(candidate)],30,'KHRONOS.json'),('fresh_reparsed_idle_capture',node+[str(P/'capture_idle_once.mjs'),str(candidate)],30,'capture/RECEIPT.json'),('girth35pairs_all36wholehorse_negative_fullinnerfit',[sys.executable,str(P/'check_actual_fit.py'),str(candidate)],150,'ACTUAL-IDLE-FIT.json')]
 try:
  for name,cmd,bound,receipt_name in commands:
   before=time.monotonic();budget=min(bound,300-(before-start));need(budget>0,'300s total actual bound');pins()
   with(out/(name+'.stdout')).open('xb')as stdout,(out/(name+'.stderr')).open('xb')as stderr:
    child=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,start_new_session=True,env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','NUMEXPR_NUM_THREADS':'1'})
    try:code=child.wait(timeout=budget)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait();code=124
    except BaseException:os.killpg(child.pid,signal.SIGKILL);child.wait();raise
   row={'name':name,'exit':code,'elapsedS':time.monotonic()-before};r['stages'].append(row);save();need(code==0,'FIRST actual failure '+name+'; all later stages UNRUN');receipt=candidate/receipt_name;doc=json.loads(receipt.read_bytes());need(doc['issues']['numErrors']==doc['issues']['numWarnings']==0 if name=='khronos'else doc.get('PASS')is True,'Required complete stage receipt '+name);row['receiptSHA256']=sha(receipt);save()
  pins();r['candidateSHA256']=sha(candidate/'candidate.glb');r['PASS']=True
 except BaseException as e:r['error']=repr(e)
 finally:save()
 print(json.dumps({**r,'elapsedS':time.monotonic()-start}));return 0 if r['PASS']else 2
if __name__=='__main__':sys.exit(main())
