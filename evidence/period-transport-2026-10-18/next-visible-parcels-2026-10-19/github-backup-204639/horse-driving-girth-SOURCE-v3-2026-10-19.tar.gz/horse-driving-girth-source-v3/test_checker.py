# SPDX-License-Identifier: GPL-3.0-or-later
"""Synthetic source/checker controls only. No model input/evaluator/browser."""
from pathlib import Path
import sys,json,subprocess,copy,math
import numpy as np
sys.path.insert(0,'/workspace/shared/horse-combined-oral-neck-mane-prefix-next/idle-fit')
from check_serialized import ownership,dimensions,base
from check_actual_fit import verify_support
from fit_upper import certificate,dyadic_witness,sqrt_upper,F,D
P=Path(__file__).parent;s=json.loads(subprocess.check_output(['node',str(P/'make_synthetic_fixture.mjs')]))
count=0
def passed(q=True):
 global count
 assert q;count+=1
def refuses(f):
 try:f()
 except (ValueError,AssertionError):passed();return
 raise AssertionError('Required refusal did not happen')
# Complete synthetic planar source fan lies inside the full46mm slab. It is a
# source ownership control, not an anatomical horse proxy or candidate trial.
h=s['hull'];fan=np.array([[[h[0][0],h[0][1],-.08],[h[i][0],h[i][1],-.08],[h[i+1][0],h[i+1][1],-.08]]for i in range(1,len(h)-1)]);s['sourceFaces']=list(range(len(fan)));passed(verify_support(s,fan)['allBelowCutCornersComplete'])
for mutate in [lambda x:x['sourceFaces'].pop(),lambda x:x['hull'][0].__setitem__(0,x['hull'][0][0]+.001),lambda x:x['stationOwners'].__setitem__(1,x['stationOwners'][2]),lambda x:x['stationOwners'][0].__setitem__('t',.5)]:
 b=copy.deepcopy(s);mutate(b);refuses(lambda:verify_support(b,fan))
for mutate in [lambda x:x['offsetDependency']['innerRequired'].pop(),lambda x:x['offsetDependency']['uncomputedUpper'][0]['previousPoint'].__setitem__(0,-100.),lambda x:x['inner'].__setitem__(x['offsetDependency']['innerRequired'][0],None),lambda x:x['inner'].__setitem__(x['offsetDependency']['uncomputedUpper'][0]['corner'],[0.,0.])]:
 b=copy.deepcopy(s);mutate(b);refuses(lambda:verify_support(b,fan))
passed(ownership(s)['actualIndexSeam']);passed(dimensions(s)['widthM']==.046);top,edges=base.topology(s['faces'],s['verticesFloat32']);passed(top['euler']==2);r={};passed(base.self_check('synthetic_girth',np.array(s['verticesFloat32'])[np.array(s['faces'])],s['faces'],edges,r)['complete'])
for mutate in [lambda x:x['faces'].append(x['faces'][-1]),lambda x:x['faceOwners'].pop(),lambda x:x['vertexOwners'].append(x['vertexOwners'][-1]),lambda x:x['innerFaceIds'].pop()]:
 b=copy.deepcopy(s);mutate(b);refuses(lambda:ownership(b))
b=copy.deepcopy(s);b['verticesRootM'][0][2]-=.001;refuses(lambda:dimensions(b));b=copy.deepcopy(s);b['faces'].pop();refuses(lambda:base.topology(b['faces'],b['verticesFloat32']));b=copy.deepcopy(s);b['verticesFloat32'][1]=b['verticesFloat32'][0];refuses(lambda:base.topology(b['faces'],b['verticesFloat32']))
plane=[[[-1.,-1.,0.],[1.,-1.,0.],[0.,1.,0.]]];near=[[-.05,-.05,.008],[.05,-.05,.008],[0.,.05,.008]];cert=certificate(near,plane,[7],.030);passed(cert['complete']and len(cert['leaves'])>1);passed(all(a['horseFace']==7 and sum(a['dyadicWeights'])==D and a['wholeSubtriangleUpperM']<=.030 for a in cert['leaves']));refuses(lambda:certificate([[x,y,.05]for x,y,z in near],plane,[7],.030,maximum_depth=1));refuses(lambda:certificate(near,[],[],.030));refuses(lambda:certificate(near,plane,[7],.030,maximum_depth=0));
weights,dist=dyadic_witness([.1,.1,.008],plane[0]);passed(sum(weights)==D and min(weights)>=0 and dist>=.008);passed(F(sqrt_upper(F(2)))**2>=2);passed(F(sqrt_upper(F(1,3)))**2>=F(1,3));passed(sqrt_upper(F(0))==0)
# Every leaf path partitions its actual whole triangle: prefix-free and total
# exact dyadic area equals the original, not an unchecked point sample.
paths=[tuple(a['path'])for a in cert['leaves']];passed(all(not(a!=b and b[:len(a)]==a)for a in paths for b in paths));passed(sum(F(1,4**len(p))for p in paths)==1)
print(json.dumps({'PASS':True,'checks':count,'scope':'Synthetic indexed/self/dimension/full-face gap certificate controls only; no actual horse/model trial'}))
