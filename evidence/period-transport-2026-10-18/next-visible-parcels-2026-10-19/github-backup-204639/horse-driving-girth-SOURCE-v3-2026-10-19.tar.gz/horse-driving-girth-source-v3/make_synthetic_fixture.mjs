// SPDX-License-Identifier: GPL-3.0-or-later
// Synthetic math fixture only, never a horse/model loader or candidate writer.
import {fromSupport} from './evaluate.mjs';import {convexHull} from '/workspace/shared/horse-rear-harness-current-support-source/evaluate.mjs';
const h=convexHull(Array.from({length:36},(_,i)=>{const t=2*Math.PI*i/36;return [.31*Math.cos(t),1.16+.395*Math.sin(t)];})),p=fromSupport(h);
console.log(JSON.stringify({name:p.name,verticesRootM:p.logicalVertices,verticesFloat32:p.verticesFloat32,faces:p.faces,vertexOwners:p.vertexOwners,faceOwners:p.faceOwners,rings:p.rings,reversedWinding:p.reversedWinding,pairs:p.pairs,stationOwners:p.stationOwners,hull:p.hull,inner:p.inner,outer:p.outer,offsetDependency:p.offsetDependency,innerFaceIds:p.innerFaceIds}));
