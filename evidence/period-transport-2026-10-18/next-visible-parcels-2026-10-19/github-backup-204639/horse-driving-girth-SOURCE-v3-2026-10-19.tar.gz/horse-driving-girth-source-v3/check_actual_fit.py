# SPDX-License-Identifier: GPL-3.0-or-later
"""Actual idle0 girth vs35, ALL36vsALLhorse, unchanged078negative, full inner fit upper bounds.
Every raw interpart/horse contact refuses, no intended-contact exception.
"""
from pathlib import Path
import json,hashlib,sys,signal,time,math,numpy as np
sys.path.insert(0,'/workspace/shared/horse-combined-oral-neck-mane-prefix-next/idle-fit')
import official_fit_predicates as pred
from fit_upper import certificate
P=Path(__file__).parent;ZLOW=-.08-.046/2;ZHIGH=-.08+.046/2;sha=lambda b:hashlib.sha256(b).hexdigest()
def need(q,m):
 if not q:raise ValueError(m)
def clip(poly,axis,value,sign):
 out=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  u,v=sign*(a[axis]-value),sign*(b[axis]-value)
  if u>=0:out.append(a)
  if u*v<0:
   t=u/(u-v);out.append([a[k]*(1-t)+b[k]*t for k in range(3)])
 return out
def hull(points):
 p=sorted(set(tuple(q)for q in points))
 def half(ps):
  out=[]
  for q in ps:
   while len(out)>1 and (out[-1][0]-out[-2][0])*(q[1]-out[-1][1])-(out[-1][1]-out[-2][1])*(q[0]-out[-1][0])<=0:out.pop()
   out.append(q)
  return out
 return [list(p)for p in half(p)[:-1]+half(p[::-1])[:-1]]
def verify_support(source,coat):
 points=[];ids=[]
 for i,t in enumerate(coat):
  p=clip(t.tolist(),2,ZLOW,1);p=clip(p,2,ZHIGH,-1)
  if p:ids.append(i);points.extend([q[:2]for q in p])
 need(ids==source['sourceFaces']and hull(points)==source['hull'],'Independent complete fresh actual full-width coat clipping/hull source identity')
 hh=source['hull'];inner=source['inner'];outer=source['outer'];n=len(hh);need(n>=3 and len(inner)==len(outer)==n,'Owned partial support arrays');seed=[i for i,q in enumerate(hh)if not(q[1]>1.21 and hh[(i-1)%n][0]>=q[0]>=hh[(i+1)%n][0])];closure=lambda k:sorted({(i+j)%n for i in seed for j in range(-k,k+1)});innerRequired=closure(2);outerRequired=closure(1);dep=source['offsetDependency'];need(set(dep)=={'cutY','seed','innerRequired','outerRequired','uncomputedUpper','proof'}and dep['cutY']==1.21 and dep['seed']==seed and dep['innerRequired']==innerRequired and dep['outerRequired']==outerRequired,'Independent exact lower support dependency closure')
 omitted=[{'corner':i,'previous':(i-1)%n,'next':(i+1)%n,'point':hh[i],'previousPoint':hh[(i-1)%n],'nextPoint':hh[(i+1)%n],'sourceAboveCut':True,'monotoneUpperX':True}for i in range(n)if i not in innerRequired];need(dep['uncomputedUpper']==omitted,'Every uncomputed upper corner has exact source-owned monotonic proof')
 for v in omitted:need(v['point'][1]>1.21 and v['previousPoint'][0]>=v['point'][0]>=v['nextPoint'][0],'Both adjoining outward normal Ycomponents nonnegative, no excluded belowcut contributor')
 need(all((v is not None)==(i in innerRequired)for i,v in enumerate(inner))and all((v is not None)==(i in outerRequired)for i,v in enumerate(outer)),'No computed missing/unowned corner value; unused upper corners neveroffset')
 scale=max(1,max(abs(x)for q in outer if q is not None for x in q));bound=256*np.finfo(float).eps*scale
 for aa,bb,r,required in [(hh,inner,.008,innerRequired),(inner,outer,.006,outerRequired)]:
  for i in required:
   need(aa[i]is not None and aa[(i-1)%n]is not None and aa[(i+1)%n]is not None,'All computed offset source neighbor dependencies');q=np.array(aa[i]);u=q-np.array(aa[(i-1)%n]);v=np.array(aa[(i+1)%n])-q;lu=np.linalg.norm(u);lv=np.linalg.norm(v);need(lu>1e-12 and lv>1e-12,'Original nonzero edge refusal retained');u/=lu;v/=lv;na=np.array([u[1],-u[0]]);nb=np.array([v[1],-v[0]]);out=np.array(bb[i]);need(abs(float((out-q)@na)-r)<=bound and abs(float((out-q)@nb)-r)<=bound,'Each computed fixed support-line distance');need(abs(float(na[0]*nb[1]-na[1]*nb[0]))>1e-14 and 1+float(na@nb)>1e-14,'Original determinant/denominator refusals retained on EVERY computed support corner');need(np.linalg.norm(out-q)<=.020,'Fixed computed source miter allowance')
 pairs=[]
 for owner in source['stationOwners']:
  if owner['kind']=='support_corner':
   i=owner['vertex'];need(0<=i<len(inner)and inner[i]is not None and outer[i]is not None and inner[i][1]<1.21,'Owned below-cut corner');pairs.append([inner[i],outer[i]])
  else:
   need(owner['kind']=='source_edge_upper_plane_intersection'and owner['axis']==1 and owner['value']==1.21,'Owned source upper-plane cut');i=owner['edge'];j=(i+1)%len(inner);need(inner[i]is not None and inner[j]is not None and outer[i]is not None and outer[j]is not None,'Complete actual cut-edge support dependencies');u=inner[i][1]-1.21;v=inner[j][1]-1.21;need(u*v<0,'Actual strict source edge/cut');t=float(u/(u-v));need(t==owner['t'],'Exact recorded cut fraction');q=[float(inner[i][k]*(1-t)+inner[j][k]*t)for k in range(2)];q[1]=1.21;p=[float(outer[i][k]*(1-t)+outer[j][k]*t)for k in range(2)];pairs.append([q,p])
 need(pairs==source['pairs']and len(pairs)==source['rings'],'Every actual source station independently replayed')
 # Reconstruct full lower chain order, including cap edge adjacency. Membership
 # alone would permit an invented cross-corner endpoint connection.
 stations=[]
 for i,a in enumerate(inner):
  if a is None:continue
  j=(i+1)%len(inner);u=a[1]-1.21;need(u!=0,'Unambiguous cut source corner')
  if inner[j]is None:need(u>0,'No missing source neighbor beside actual material');v=1.
  else:v=inner[j][1]-1.21
  if u<0:need(outer[i]is not None,'Actual station outer support');stations.append({'kind':'support_corner','vertex':i})
  if u*v<0:need(inner[j]is not None and outer[i]is not None and outer[j]is not None,'Actual cut outer support');stations.append({'kind':'source_edge_upper_plane_intersection','edge':i,'t':float(u/(u-v)),'axis':1,'value':1.21})
 endIds=[i for i,o in enumerate(stations)if o['kind']=='source_edge_upper_plane_intersection'];need(len(endIds)==2,'Exactly2real cut edges')
 def cut_x(o):
  i=o['edge'];j=(i+1)%len(inner);t=o['t'];return float(inner[i][0]*(1-t)+inner[j][0]*t)
 endIds.sort(key=lambda i:-cut_x(stations[i]));paths=[]
 for step in [1,-1]:
  route=[stations[endIds[0]]];i=endIds[0]
  for _ in range(len(stations)):
   i=(i+step)%len(stations);route.append(stations[i])
   if i==endIds[1]:break
  if len(route)>=3 and route[-1]==stations[endIds[1]]and all(o['kind']=='support_corner'for o in route[1:-1]):paths.append(route)
 need(len(paths)==1 and source['stationOwners']==paths[0],'Full lower chain and both source cut/cap edge adjacency replay exactly')

 # Full lower chain/cap boundary ownership: exactly all below-cut source corners,
 # each once in adjacent hull order, with the two transverse cut edges.
 corners=[o['vertex']for o in source['stationOwners'][1:-1]];expected={i for i,q in enumerate(inner)if q is not None and q[1]<1.21};need(len(corners)==len(set(corners))and set(corners)==expected and all(o['kind']=='support_corner'for o in source['stationOwners'][1:-1]),'Every lower hull corner exactly once, none hidden')
 need(source['stationOwners'][0]['kind']==source['stationOwners'][-1]['kind']=='source_edge_upper_plane_intersection'and pairs[0][0][0]>pairs[-1][0][0],'Exact two left/right upper caps')
 steps=[(b-a)%len(inner)for a,b in zip(corners,corners[1:])];need(not steps or all(s==1 for s in steps)or all(s==len(inner)-1 for s in steps),'Continuous source lower chain')
 need(all(np.array_equal(np.array([[a[0],a[1],ZLOW],[a[0],a[1],ZHIGH],[b[0],b[1],ZHIGH],[b[0],b[1],ZLOW]]),np.array(source['verticesRootM'][j*4:j*4+4]))for j,(a,b)in enumerate(pairs)),'Every full-width vertex reconstructed from actual owned pair')
 return {'sourceFaces':ids,'offsetDependency':dep,'boundM':bound,'fixedInnerAllowanceM':.008,'maximumMiterAllowanceM':.020,'allBelowCutCornersComplete':True}
def main():
 need(len(sys.argv)==2,'Candidate dir');d=Path(sys.argv[1]);out=d/'ACTUAL-IDLE-FIT.json';need(not out.exists(),'Fresh fit receipt');start=time.monotonic();r={'PASS':False,'scope':'Actual idle0 only;35changed/fixed pairs, ALL36againstALLhorse,078negative, complete inner-surface gap upper certificates; no containment/forces/motion/hitch/photo','interpart':[],'horse':[]}
 save=lambda:out.write_text(json.dumps(r,indent=2)+'\n')
 def timeout(*_):raise TimeoutError('150s oneCPU actual physical/gap bound')
 signal.signal(signal.SIGALRM,timeout);signal.alarm(150)
 try:
  side=json.loads((d/'SIDECAR.json').read_text());s=json.loads((d/'LOGICAL-SOURCE.json').read_text());serial=json.loads((d/'SERIALIZED-CHECK.json').read_text());receipt=json.loads((d/'capture/RECEIPT.json').read_text());inventory=sha((P/'SOURCE-INVENTORY.json').read_bytes());need(serial['PASS']is True and receipt['PASS']is True and serial['candidateSHA256']==receipt['candidateSHA256']==side['candidateSHA256']==s['candidateSHA256']==sha((d/'candidate.glb').read_bytes()),'Actual same-candidate prerequisites');need(side['sourceInventorySHA256']==receipt['sourceInventorySHA256']==inventory,'Exact frozen source identity');records={a['name']:a for a in receipt['files']};need(set(records)=={'horse','candidate','baseline'}and len(records)==len(receipt['files']),'All3fresh captures')
  def load(name,want):
   mr=(d/'capture'/f'{name}.json').read_bytes();raw=(d/'capture'/f'{name}.f64').read_bytes();m=json.loads(mr);need(sha(mr)==records[name]['metadataSHA256']and sha(raw)==m['bufferSHA256']==records[name]['bufferSHA256']and m['input'][1]==want,'Full actual capture hash '+name);need(m['sourceInventorySHA256']==inventory and m['precision']=='float64_world'and m['post_world_rounding']is False,'Actual capture precision/source');need(m['pose']['clip']=='idle'and m['pose']['timeS']==m['pose']['phase']==m['pose']['actualActionTime']==0,'Actual idle0');need(len(raw)==72*m['triangleCount']and m['triangleCount']==records[name]['triangleCount'],'Exact triangle bytes');a=np.frombuffer(raw,dtype='<f8').reshape(-1,3,3);need(np.isfinite(a).all(),'Finite actual triangle array');pos=0;seen=set()
   for g in m['meshes']:
    key=g['sourceMesh'],g['sourcePrimitive'];need(key not in seen and g['start']==pos and g['count']>0,'Complete actual ordered unique coverage');seen.add(key);pos+=g['count']
   need(pos==len(a),'Actual complete capture end');return m,a
  hm,h=load('horse','ab70aff958bc8a2780458d37212be1866c730817f485fbebbf53bd3c0e3931c3');gm,g=load('candidate',side['candidateSHA256']);bm,negative=load('baseline','078ed2cebc01dba52d28f2ae737f170f0fe28fd20523aed9bb8869f4cd7b35bd');need(hm['pose']==gm['pose']==bm['pose']and hm['rootWorld']==gm['rootWorld']==bm['rootWorld']==[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]and hm['headWorld']==gm['headWorld']==bm['headWorld'],'Exact shared actual idle binding');need(len(h)==13226 and len(gm['meshes'])==36 and len({x['name']for x in gm['meshes']})==36,'Wholehorse/all36coverage');groups={a['name']:a for a in gm['meshes']};new=groups['girth'];tri=g[new['start']:new['start']+new['count']];need(new['indexed']is True and np.array_equal(tri,np.array(s['verticesFloat32'])[np.array(s['faces'])]),'Actual fresh triangle/index-source ownership');pred.predicate_controls()
  for name,part in groups.items():
   if name=='girth':continue
   target=g[part['start']:part['start']+part['count']];lo,hi=target.min(1),target.max(1);row={'parts':['girth',name],'complete':False,'rawSAT':0,'strictProper':0};r['interpart'].append(row)
   for i,a in enumerate(tri):
    for j in np.flatnonzero(np.all(hi>=a.min(0)-1e-8,axis=1)&np.all(lo<=a.max(0)+1e-8,axis=1)):
     j=int(j)
     if pred.sat(a,target[j]):
      row['rawSAT']+=1;proper=pred.proper(a,target[j]);row['strictProper']+=int(proper is not None);r['firstFailure']={'parts':['girth',name],'faces':[i,j],'actualTriangles':[a.tolist(),target[j].tolist()],'proper':proper};raise ValueError('First actual girth/part raw contact; no blanket exception')
   row['complete']=True;save()
  need(len(r['interpart'])==35,'Every girth vsother35pair');hlo,hhi=h.min(1),h.max(1)
  def against(label,values,parts):
   need(isinstance(values,np.ndarray)and values.ndim==3 and values.shape[1:]==(3,3)and len(values)>0,'Actual triangle consumer boundary');row={'label':label,'complete':False,'rawSAT':0,'strictProper':0,'parts':{}};r['horse'].append(row)
   for part in parts:
    raw=proper_count=0
    for i,a in enumerate(values[part['start']:part['start']+part['count']]):
     for j in np.flatnonzero(np.all(hhi>=a.min(0)-1e-8,axis=1)&np.all(hlo<=a.max(0)+1e-8,axis=1)):
      j=int(j)
      if pred.sat(a,h[j]):
       raw+=1;proper=pred.proper(a,h[j]);proper_count+=int(proper is not None)
       if label=='candidate':row['parts'][part['name']]={'rawSAT':raw,'strictProper':proper_count,'complete':False};r['firstFailure']={'part':part['name'],'faces':[i,j],'actualTriangles':[a.tolist(),h[j].tolist()],'proper':proper};raise ValueError('First actual ALL36/ALLhorse contact')
    row['parts'][part['name']]={'rawSAT':raw,'strictProper':proper_count};row['rawSAT']+=raw;row['strictProper']+=proper_count
   row['complete']=True;save();return row
  control=against('original078_negative',negative,[a for a in bm['meshes']if a['name']in{'cheekpiece_l','cheekpiece_r','crownpiece','browband','noseband'}]);need(control['rawSAT']==268 and control['strictProper']==264,'Preserved unchanged078 exact negative counts');against('candidate',g,gm['meshes']);coat_group=[x for x in hm['meshes']if x['name']=='skinned_equine_coat'];need(len(coat_group)==1 and coat_group[0]['count']==10724 and coat_group[0]['indexed']is True,'Actual complete indexed coat');cg=coat_group[0];coat=h[cg['start']:cg['start']+cg['count']];r['support']=verify_support(s,coat);save();ids=s['sourceFaces'];support=coat[ids].tolist();actualIds=[cg['start']+i for i in ids];r['innerSurfaceFit']={'complete':False,'boundM':.030,'faces':[]}
  for fi in s['innerFaceIds']:
   cert=certificate(tri[fi].tolist(),support,actualIds,.030);r['innerSurfaceFit']['faces'].append({'actualGirthFace':fi,**cert})
  need(len(r['innerSurfaceFit']['faces'])==2*(s['rings']-1),'Every actual inner girth surface face covered');r['innerSurfaceFit']['complete']=True;save();r['upperEnds']={}
  for side_name,capIds in [('l',[len(tri)-4,len(tri)-3]),('r',[len(tri)-2,len(tri)-1])]:
   row={'unbound':True,'materialContactClaim':False,'nearestCompleteExistingHardware':{}}
   for role in ['girth_billet_'+side_name,'girth_buckle_'+side_name]:
    group=groups[role];target=g[group['start']:group['start']+group['count']];best=min((pred.triangle_distance(tri[i],t),i,j)for i in capIds for j,t in enumerate(target));row['nearestCompleteExistingHardware'][role]={'distanceM':best[0],'actualGirthCapFace':best[1],'actualHardwareFace':int(best[2]),'completeBothSurfaces':True}
   r['upperEnds'][side_name]=row
  r['candidateSHA256']=side['candidateSHA256'];r['PASS']=True
 except BaseException as e:r['error']=repr(e);raise
 finally:signal.alarm(0);r['elapsedS']=time.monotonic()-start;save()
if __name__=='__main__':main()
