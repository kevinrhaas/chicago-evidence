# Driving girth: historical routing and reconstruction limits

The old girth is a circumferential ellipse implemented as an open capped strip with repeated endpoint centers. Its distinct cap corners differ0.411mm, so closure is not indexed ownership. The new proposal is an under-barrel U strap: a closed solid/material shell with indexed side/end-cap triangles, Euler2. It is not an endless circumferential loop (which would require Euler0 and a different source route). Neither material closure nor proximity assigns the upper ends to existing buckle/billet surfaces.

## Primary text and images actually read/viewed in this pass

Paul N.Hasluck(ed), *Harness Making*, Cassell andCompany, London/Paris/NewYork/Melbourne, MCMIV; preface May1904. Discovered public mirror `https://github.com/GITenberg/Harness-making_70169` via actual public GitHub repository search. Read complete downloaded HTML and relevant primary text; metadata identifies original1904GB publication and `Public domain in the USA.` with PDM link.2023Gutenberg issue date is not original publication. This is a separate Cassell edition from the earlier Philadelphia1904 IA citation. Source mirrors/images are research only; Gutenberg packaging is not incorporated in a generated model. Copyright conclusion is age/public-domain metadata, not a newly obtained institutional grant.

Printedp137, *Van and Cab Harness*, explicitly says:

> “A strap and a girth are needed to fasten to the bottom of the flaps.”

It describes a buckle hole in the lay, buckle edge level with the girth end, stitching on the flat, loops beyond the buckle, and finishes:

> “stitch them, the strap on the near side and the girth on the off side at the base of the flaps”.

This establishes side attachment and separate buckled girth/strap components for that driving-saddle recipe; it does not instruct an independent leather ring over the saddle. The text's2ft/2in cut stock and18in strap are not adopted as this model's fit dimensions or assembled arc length.

Actually viewed original diagram pixels:

- `hasluck1904-131-4.jpg`: printedp131 Figs182–184, van saddle, flap and panel. Shows separate driving saddle structures, not a riding seat; no metric tracing.
- `hasluck1904-147-3.jpg`: printedp147 Fig190, back-band: buckle/loops at one end, spaced holes and long point, visibly an adjustable strip rather than an unbroken material torus. Textpp150–151 describes a back-band passing through a saddle, with buckle/strap and girth/belly-band portions. That van/cab back-band is a separate configuration; it is not silently substituted for the MooreNo1 girth.
- `hasluck1904-155.jpg`: printedp155 Fig197, Hansom Cab Harness. Shows the saddle/side adjustment hardware, lower barrel contour, traces and breeching as distinct paths. The hidden far-side joint and metric clearance cannot be recovered from this engraving. No exact Chicago ownership or MooreNo1 match is inferred.

URLs are `https://raw.githubusercontent.com/GITenberg/Harness-making_70169/master/70169-h/images/<131-4,147-3,155>.jpg`; exact source paths/hashes and viewed dimensions are in PRIMARY-EVIDENCE.json. This was a permitted GitHub-mirror acquisition through inherited proxy/TLS, no archive.org storage-host retry, proxy bypass, CA disable, browser or model evaluation.

Earlier cached Moore1891No1 OCR report at `/workspace/chicago-tickets/evidence/period-transport-2026-10-18/equine-source-acquisition.md` independently supports folded/stitched girth as a distinct part of light buggy breastcollar harness. Its actual plate remains unseen. Hasluck's van/cab recipes and engraving are construction/routing comparators, not evidence that the exact Moore light-buggy strap had these cuts/buckles. Neither1891nor1904supports backdating the exact variant into1812/1835.

## Fixed reconstructed construction

Preserve every byte/descriptor of all35other parts in qualified1fb25parent, including rear3, old billets/buckles and driving saddle. Replace only girth at originalZ=-.08; full width46mm and support-plane thickness6mm remain fixed reconstructed dimensions. Use complete actual current rendered indexedcoat triangles, clip triangle interiors to the entire width slab, projectXY and take current convex support. Inner offset8mm and maximum computed corner-miter allowance20mm are fixed refusal policies, not source/veterinary clearances or tuned radii. Lower support chain terminates at fixed innerY1.21, taken from existing nominal buckle-center source, with explicit edge/plane owners. No upper connector crosses the unchanged saddle.

The full inner material surface must have a conservative point-to-actual-horse upper bound30mm before fit PASS; every whole inner triangle is covered by adaptive exact-dyadic subtriangles and actual-horse-face rational witness points plus Lipschitz-radius bounds. This bounds visual standoff only; all complete self/part/horse intersection guards remain. Refuse unproved bounds or partial scans. The convex envelope can bridge anatomical concavities; the30mm full-face certificate explicitly limits that reconstruction liberty.

Upper ends remain unbound to existing side hardware even if close. Record complete cap-to-billet/buckle distance witnesses after actual physical tests; no nearest-point measurement becomes a shared seam, load path, continuous leather, pressure or animal-health claim. A later hardware-attachment amendment must own real interfaces, preserve strict proper-crossing refusal, and be separately reviewed.

The v2 open lower-support domain and its source-owned null upper entries are specified in SOURCE-CORNER-DOMAIN-REPAIR.md. No original offset refusal is waived on any computed/material dependency.
