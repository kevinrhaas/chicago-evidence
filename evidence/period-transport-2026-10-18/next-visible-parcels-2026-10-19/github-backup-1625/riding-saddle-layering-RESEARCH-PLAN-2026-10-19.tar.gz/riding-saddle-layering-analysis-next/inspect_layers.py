# SPDX-License-Identifier: CC0-1.0
"""Read-only exact stored saddle-layer witnesses; no model export or SAT sweep."""
from pathlib import Path
import json,struct,hashlib,math,statistics
P=Path('/workspace/shared/riding-saddle-front-return-v2-source-next/candidate-one/candidate.glb');raw=P.read_bytes();sha=hashlib.sha256(raw).hexdigest()
if sha!='b870ebe91fd59ef9214845119b3d3bee46461a8a22f12d788c318f3941dd12fe':raise ValueError('Actual b870 pin')
n=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+n]);b=raw[28+n:]
def read(i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];c={'VEC3':3,'SCALAR':1}[a['type']];fmt={5126:'f',5125:'I',5123:'H'}[a['componentType']];x=struct.unpack_from('<'+fmt*a['count']*c,b,v.get('byteOffset',0)+a.get('byteOffset',0));return list(zip(*[iter(x)]*c))
parents={j:i for i,node in enumerate(d['nodes'])for j in node.get('children',[])}
def part(name):
 meshes=[(i,m)for i,m in enumerate(d['meshes'])if m['name']==name]
 if len(meshes)!=1:raise ValueError('Unique named actual part')
 mi,m=meshes[0];nodes=[i for i,x in enumerate(d['nodes'])if x.get('mesh')==mi]
 if len(nodes)!=1:raise ValueError('Unique actual instance')
 i=nodes[0];path=[]
 while True:
  node=d['nodes'][i];path.append(i)
  if node.get('translation',[0,0,0])!=[0,0,0]or node.get('rotation',[0,0,0,1])!=[0,0,0,1]or node.get('scale',[1,1,1])!=[1,1,1]or'matrix'in node or'skin'in node:raise ValueError('Expected actual rigid root identity frame')
  if i not in parents:break
  i=parents[i]
 if path[-1]not in d['scenes'][d.get('scene',0)]['nodes']:raise ValueError('Inactive source part')
 p=m['primitives'][0];V=read(p['attributes']['POSITION']);F=[q[0]for q in read(p['indices'])]if'indices'in p else list(range(len(V)));return {'name':name,'mesh':mi,'node_path':path,'vertices':V,'faces':[tuple(F[i:i+3])for i in range(0,len(F),3)],'material':d['materials'][p['material']]['name']}
def vertical_hits(p,x,z):
 hits=[]
 for fi,f in enumerate(p['faces']):
  A,B,C=[p['vertices'][i]for i in f];den=(B[2]-C[2])*(A[0]-C[0])+(C[0]-B[0])*(A[2]-C[2])
  if abs(den)<1e-14:continue
  u=((B[2]-C[2])*(x-C[0])+(C[0]-B[0])*(z-C[2]))/den;v=((C[2]-A[2])*(x-C[0])+(A[0]-C[0])*(z-C[2]))/den;w=1-u-v
  if min(u,v,w)>=-1e-10:hits.append({'y':u*A[1]+v*B[1]+w*C[1],'face':fi,'vertex_ids':f,'barycentric':[u,v,w],'triangle':[A,B,C]})
 out=[]
 for h in sorted(hits,key=lambda h:h['y']):
  if not out or abs(h['y']-out[-1]['y'])>1e-7:out.append(h)
 return out
result={'candidate_sha256':sha,'scope':'Stored actual rigid root-space surfaces; strict interior-column witnesses and wall slopes only. No new mesh/SAT/pose/pressure/period evaluation','samples':[],'interior_witnesses':[],'jockey_slopes':{}}
for side,s in [('l',1),('r',-1)]:
 panel=part('panel_'+side);quarter=part('quarter_'+side);jockey=part('jockey_'+side);angles=[];drops=[];spans=[]
 for k in range(17):
  a=jockey['vertices'][k*9];c=jockey['vertices'][k*9+8];drop=abs(a[1]-c[1]);span=abs(a[0]-c[0]);angles.append(math.degrees(math.atan2(drop,span)));drops.append(drop);spans.append(span)
 result['jockey_slopes'][side]={'row_count':17,'drop_m':{'min':min(drops),'median':statistics.median(drops),'max':max(drops)},'lateral_span_m':{'min':min(spans),'median':statistics.median(spans),'max':max(spans)},'angle_from_horizontal_degrees':{'min':min(angles),'median':statistics.median(angles),'max':max(angles)},'actual_node_path':jockey['node_path']}
 for z in [-.40,-.30,-.20,-.15,-.10,0.]:
  for x in [.10,.125,.15,.175,.19,.20,.204]:
   ph=vertical_hits(panel,s*x,z);qh=vertical_hits(quarter,s*x,z)
   if len(ph)!=2:continue
   for h in qh:
    depth=min(h['y']-ph[0]['y'],ph[1]['y']-h['y'])
    if depth>1e-6:result['interior_witnesses'].append({'side':side,'point_m':[s*x,h['y'],z],'quarter':{'mesh':quarter['mesh'],'face':h['face'],'vertex_ids':h['vertex_ids'],'barycentric':h['barycentric'],'triangle':h['triangle']},'panel':{'mesh':panel['mesh'],'material':panel['material'],'lower':ph[0],'upper':ph[1]},'vertical_depth_inside_panel_m':depth})
 result['samples'].append({'side':side,'panel_bounds':{'min':[min(q[i]for q in panel['vertices'])for i in range(3)],'max':[max(q[i]for q in panel['vertices'])for i in range(3)]},'panel_face_count':len(panel['faces']),'panel_material':panel['material']})
result['interior_witness_count']=len(result['interior_witnesses']);result['interpretation']='Quarter surface points are strictly between both actual closed panel surfaces on interior columns; panel/leather interpenetration, not a missing texture. Bounded column evidence, not wholepair SAT count.'
Path(__file__).with_name('actual-layer-witnesses.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'strict_panel_interior_points':result['interior_witness_count'],'jockey_slopes':result['jockey_slopes']},indent=2))
