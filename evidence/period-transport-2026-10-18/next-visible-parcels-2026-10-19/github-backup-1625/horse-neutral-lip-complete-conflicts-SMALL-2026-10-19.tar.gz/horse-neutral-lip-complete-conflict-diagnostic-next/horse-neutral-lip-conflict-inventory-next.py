# SPDX-License-Identifier: GPL-3.0-or-later
"""DIAGNOSTIC only: complete FAILED head-internal scan on existing actualf64.
No capture/export/parameter evaluation, no acceptance retry.
"""
from pathlib import Path
import time,signal,json,hashlib,sys,importlib.util,collections
import numpy as np
START=time.monotonic();signal.signal(signal.SIGALRM,lambda *_:(_ for _ in()).throw(TimeoutError('90s diagnostic bound')));signal.alarm(90)
P=Path(__file__).parent;FAILED=Path('/workspace/shared/horse-neutral-lip-source-phase-next');H=Path('/workspace/shared/horse-neck-hybrid-pipeline-next');sys.path.insert(0,str(H))
from ownership import Model,triangle_labels
from source_edges import owned_adjacency
from hybrid_geometry import SEAM
from check_idle import scan,world_aliases
import official_fit_predicates as predicates

def main():
 out=P/'results';out.mkdir(exist_ok=False);report={'status':'FAILED candidate diagnostic; NEVER acceptance retry','complete':False,'input_pins':{},'original_first_failure_preserved':True}
 def save():report['elapsed_s']=time.monotonic()-START;(out/'REPORT.json').write_text(json.dumps(report,indent=2)+'\n')
 try:
  pins=json.loads((P/'input-pins.json').read_text());report['input_pins']=pins;save()
  for name,want in pins.items():
   if hashlib.sha256(Path(name).read_bytes()).hexdigest()!=want:raise ValueError('Frozenpin:'+name)
  raw=(FAILED/'candidate-one/candidate.glb').read_bytes();m=Model(raw);read=json.loads((FAILED/'candidate-one/readback.json').read_text());require=lambda ok,msg:None if ok else(_ for _ in()).throw(ValueError(msg));require(read['PASS']is True and hashlib.sha256(raw).hexdigest()==read['candidate_sha256']=='4c3cb1b9c0e68b73821165f5cf10985327d84e3347c65a90fe99142bc2525853','Exactfailedrestbytes');owners={int(g):o for g,o in read['source_face_owners'].items()};require(set(owners)==set(range(m.total))and m.total==13754,'ALLactiveownerledger');head={g for g,o in owners.items()if o['kind']not in['retained_body','hybrid_neck','fitted_mane']};require(len(head)==3650,'Actualfullheadcohort');m.source_face_owners=owners;labels={(r['mesh'],r['vertex']):r['label']for r in read['source_labels']};records=triangle_labels(m,labels);ha,hb,topology=owned_adjacency(records,head,m.total,1,1,boundary_loop=['h:'+str(x)for x in SEAM]);report['head_topology']=topology
  spec=importlib.util.spec_from_file_location('failed_capture_validation',FAILED/'idle-fit/validate_capture.py');validation=importlib.util.module_from_spec(spec);spec.loader.exec_module(validation);meta=json.loads((FAILED/'idle-fit/capture/horse.json').read_text());buf=(FAILED/'idle-fit/capture/horse.f64').read_bytes();validation.validate('horse',meta,buf);captured=np.frombuffer(buf,dtype='<f8').reshape(-1,3,3);data=np.empty_like(captured);seen=set()
  for row in meta['meshes']:
   key=row['sourceMesh'],row['sourcePrimitive'];require(key in m.views and key not in seen and row['count']==len(m.views[key]['indices']),'Exactcaptureprimitive');seen.add(key);start=m.start[key];data[start:start+row['count']]=captured[row['start']:row['start']+row['count']]
  require(seen==set(m.views),'Allactualtriangles');report['source_aliases']=world_aliases(records,data);save();predicates.predicate_controls();r=scan('failed_neutral_head3650','head_internal',m,records,head,data,ha,out,False,declared_scope='DIAGNOSTIC completion on frozenFAIL arrays only; allheadinternal, no acceptance')
  report['complete']=r['complete'];report['counts']=r['counts'];summary=collections.Counter()
  for w in r['unexpected_witnesses']:
   def kind(g):
    o=owners[g]
    return o['kind']+':'+(o.get('surface','')if o['kind']=='neutral_lip'else o.get('source_owner',{}).get('kind',o.get('tag','')))
   summary[' | '.join(sorted([kind(w['a_global']),kind(w['b_global'])]))]+=1
  report['unexpected_owner_pairs']=dict(summary);report['unexpected_witnesses']=r['unexpected_witnesses'];save()
 except BaseException as e:report['error']=repr(e);save();raise
 finally:signal.alarm(0)
if __name__=='__main__':main()
