# Actual isolated GPU palette result — one authorized run

2026-10-19. Exit0. receipt.json is complete raw evidence; summary.json reduces actual measurements.72PNGs retained. No retry, app writes, production mount, or scene admission.

18 exact canvas screenshot comparisons: desktop1280x800/mobile390x780 × plain/tint/ghost × idle/nonzero/one-stride-loop. ZERO changed pixels and ZERO maximum channel difference in every comparison. Actual resolved camera and route states match exactly. This qualifies those sampled distant fixture outputs only, not arbitrary views/poses, photographic appearance or future source versions.

Six actual off/on/restored draw cases: +1call/+24,964triangles, restore0calls/0triangles. Actual submitted rows identify the single FrontSide opaque or confidence ghost pass and no shadow submissions. No compiler/page/network errors. GL capabilities:4096vertex uniform vectors,16vertex attributes,31varying vectors,WebGL2. These are this execution environment, not minimum mobile hardware qualification.

120samples per viewport: scripted GPU-finished frame p95desktop0.9ms/mobile0.8ms; animation-section p95desktop0.3ms/mobile0.2ms. Max frame3.7ms/2.7ms. These are isolated scripted adapter+render+GPU-finish timings and viewport sizes, not complete RAF presentation, physical mobile hardware or Chicago main-scene p95. Prior CPU-source probe measured19.4ms/17.1ms in its separate historical run; not a same-run controlled hardware benchmark.

Independent wagon and horse remain reconstruction engineering studies without driver, harness or accepted hitch; no people invented. Far-only no-shadow policy, real road/terrain/collision/date/provenance and named-driver integration remain unqualified. StrictLight main scene has only one draw-call headroom in existing diagnostic; this isolated pass does not reserve it or change any cap.

Useful image pair: desktop-plain-nonzero-reference.png / desktop-plain-nonzero-gpu.png, with desktop-plain-nonzero-diff.png. All18corresponding comparison triplets are retained. Source selector/reference SHA and changed source hashes recorded in receipt; frozen source archivea9183e9567f778e9ab1a91ef6e8cd7f69f55ff78aee9edbc14078c7122b54e49 remains unchanged.
