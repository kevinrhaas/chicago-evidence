// SPDX-License-Identifier: GPL-3.0-or-later
// This revision's actual-source tests include frozen CPU comparison.
import './test-palette.mjs';
