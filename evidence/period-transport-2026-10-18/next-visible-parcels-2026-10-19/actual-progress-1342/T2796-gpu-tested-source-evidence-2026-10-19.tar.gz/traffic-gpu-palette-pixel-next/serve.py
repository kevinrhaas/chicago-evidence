# SPDX-License-Identifier: GPL-3.0-or-later
# Root-run only after browser release. Narrow read-only fixture mounts.
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import argparse
ROOT=Path(__file__).resolve().parent
APP=Path('/workspace/chicago/chicago/4d/renderers/web')
class Handler(SimpleHTTPRequestHandler):
 def translate_path(self,path):
  from urllib.parse import unquote,urlsplit
  p=unquote(urlsplit(path).path)
  mounts={'/vendor/':APP/'vendor/three-0.185.1','/assets/':APP/'transport'}
  if p=='/confidence.js':return str(APP/'js/confidence.js')
  for prefix,base in mounts.items():
   if p.startswith(prefix):
    f=(base/p[len(prefix):]).resolve()
    return str(f)if f.is_relative_to(base.resolve())else'/dev/null'
  f=(ROOT/p.lstrip('/')).resolve()
  return str(f)if f.is_relative_to(ROOT)else'/dev/null'
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--port',type=int,default=8796);a=ap.parse_args();ThreadingHTTPServer(('127.0.0.1',a.port),Handler).serve_forever()
