// SPDX-License-Identifier: GPL-3.0-or-later
// Prepare only; requires explicit root browser-lane release. Never mounts town.
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process');
const {chromium}=require('playwright');const crypto=require('node:crypto');const PNG=require('./png.cjs');
if(!process.argv.includes('--root-browser-release'))throw Error('Root browser-lane release required');
const ROOT=__dirname,OUT=process.argv[process.argv.indexOf('--out')+1];if(!process.argv.includes('--out')||!OUT||fs.existsSync(OUT))throw Error('fresh --out required');fs.mkdirSync(OUT,{recursive:true});
const sourceHashes=Object.fromEntries(['batch.mjs','reference-cpu-batch.mjs','index.html','probe-pixels.cjs','png.cjs'].map(n=>[n,crypto.createHash('sha256').update(fs.readFileSync(path.join(ROOT,n))).digest('hex')]));if(sourceHashes['reference-cpu-batch.mjs']!=='4d3d321fd7992b12d5013b022c81d44b81c0177f46a8de2bde07d48d6f3d3435')throw Error('frozen CPU reference SHA mismatch');
const receipt={sourceHashes,pixel_comparisons:[],scope:'isolated actual WebGL only; not town/published/all-stand traffic admission',rows:[],errors:[],status:'STARTED'},save=()=>fs.writeFileSync(path.join(OUT,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
let browser,server;async function cleanup(){if(browser)await browser.close().catch(()=>{});if(server){try{process.kill(-server.pid,'SIGTERM');}catch{}}}const deadline=setTimeout(()=>{receipt.status='TIMEOUT90s';save();cleanup().finally(()=>process.exit(124));},90000);
(async()=>{save();server=cp.spawn('python',[path.join(ROOT,'serve.py'),'--port','8796'],{detached:true,stdio:['ignore',fs.openSync(path.join(OUT,'server.log'),'a'),fs.openSync(path.join(OUT,'server.log'),'a')]});
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});const page=await browser.newPage(),reference=await browser.newPage();for(const [name,p]of [['gpu',page],['reference',reference]]){p.on('pageerror',e=>{receipt.errors.push(name+':'+String(e));save();});p.on('console',m=>{if(m.type()==='error'){receipt.errors.push(name+':'+m.text());save();}});}
 // Server startup bound, no browser/navigation retry after a model or shader failure.
 await new Promise((resolve,reject)=>{const limit=setTimeout(()=>reject(Error('server startup5s')),5000);const poll=setInterval(async()=>{try{const r=await fetch('http://127.0.0.1:8796/index.html');if(r.ok){clearTimeout(limit);clearInterval(poll);resolve();}}catch{}},100);});
 await page.goto('http://127.0.0.1:8796/index.html',{waitUntil:'networkidle',timeout:30000});await page.waitForFunction(()=>window.trafficStudy?.ready,{timeout:30000});
 await reference.goto('http://127.0.0.1:8796/index.html?implementation=reference',{waitUntil:'networkidle',timeout:30000});await reference.waitForFunction(()=>window.trafficStudy?.ready,{timeout:30000});
 receipt.limits={gpu:await page.evaluate(()=>trafficStudy.limits),reference:await reference.evaluate(()=>trafficStudy.limits)};save();
 for(const [viewport,width,height]of[['desktop',1280,800],['mobile',390,780]]){await page.setViewportSize({width,height});await reference.setViewportSize({width,height});
  for(const mode of ['plain','tint','ghost']){
   await page.evaluate(o=>{for(let i=0;i<3;i++){trafficStudy.frame({...o,visible:true});trafficStudy.renderer.getContext().finish();}},{t:0,width,height,mode});
   const frames=[];
   for(const [label,visible]of[['off',false],['on',true],['restored',false]]){const row=await page.evaluate(o=>{const r=trafficStudy.frame(o);trafficStudy.renderer.getContext().finish();return r;},{t:0,width,height,mode,visible});frames.push({label,...row});await page.screenshot({path:path.join(OUT,`${viewport}-${mode}-${label}.png`)});}
   const [off,on,restored]=frames;const row={viewport,mode,frames,delta_calls:on.draws-off.draws,delta_triangles:on.triangles-off.triangles,restore_calls:restored.draws-off.draws,restore_triangles:restored.triangles-off.triangles};receipt.rows.push(row);save();
   for(const frame of frames){if(frame.submitted.reduce((s,r)=>s+r.calls,0)!==frame.draws||frame.submitted.reduce((s,r)=>s+r.triangles,0)!==frame.triangles)throw Error('direct totals do not match renderer');}
   if(row.delta_calls!==1||row.delta_triangles!==24964||row.restore_calls||row.restore_triangles||receipt.errors.length)throw Error('strict isolated draw/triangle/restore/compiler guard');
  }
  const stride=1.161290322580645,ramp=.8/.35,loopTime=ramp+(stride-.5*.35*ramp*ramp)/.8;
  for(const mode of ['plain','tint','ghost'])for(const [label,t]of [['idle',0],['nonzero',.400001],['walk-loop',loopTime]]){
   const options={t,width,height,mode,visible:true},rows=[];
   for(const [name,p]of [['reference',reference],['gpu',page]]){const stats=await p.evaluate(o=>{for(let i=0;i<3;i++){trafficStudy.frame(o);trafficStudy.renderer.getContext().finish();}return trafficStudy.frame(o);},options);const png=await p.locator('canvas').screenshot();fs.writeFileSync(path.join(OUT,`${viewport}-${mode}-${label}-${name}.png`),png);rows.push({name,stats,png});}
   const comparison=PNG.compare(PNG.decode(rows[0].png),PNG.decode(rows[1].png));fs.writeFileSync(path.join(OUT,`${viewport}-${mode}-${label}-diff.png`),PNG.encode(comparison.diff));delete comparison.diff;
   const pixel={viewport,mode,label,t,...comparison,reference:rows[0].stats,gpu:rows[1].stats};receipt.pixel_comparisons.push(pixel);save();
   if(JSON.stringify(pixel.reference.camera)!==JSON.stringify(pixel.gpu.camera)||JSON.stringify(pixel.reference.route_state)!==JSON.stringify(pixel.gpu.route_state))throw Error('reference/GPU camera or route state differs');
   if(pixel.reference.draws!==1||pixel.gpu.draws!==1||pixel.reference.triangles!==24964||pixel.gpu.triangles!==24964)throw Error('reference/GPU actual submission differs');
   if(pixel.changed_pixels!==0||receipt.errors.length)throw Error('EXACT reference/GPU pixel/compiler guard; differences preserved, no tolerance waiver');
  }
  const timing=await page.evaluate(async({width,height})=>{const samples=[];for(let i=0;i<120;i++){await new Promise(requestAnimationFrame);const a=performance.now();const r=trafficStudy.frame({t:i/60,width,height,mode:'plain',visible:true});trafficStudy.renderer.getContext().finish();samples.push({scripted_frame_ms:performance.now()-a,animation_ms:r.animation_ms,draws:r.draws,triangles:r.triangles,textures:r.textures,geometries:r.geometries});}return samples;},{width,height});receipt[viewport+'_timing']=timing;save();
 }
 if(receipt.errors.length)throw Error('page/compiler errors');receipt.status='ISOLATED GPU/COST/EXACT PIXEL PASS only; production admission remains BLOCKED';save();
})().catch(e=>{receipt.status='FIRST FAILURE STOP';receipt.error=String(e.stack);save();process.exitCode=1;}).finally(async()=>{clearTimeout(deadline);await cleanup();});
