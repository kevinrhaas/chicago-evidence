// SPDX-License-Identifier: GPL-3.0-or-later
// Original far-only render study. Does not mount traffic in Chicago.
import * as T from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
const need=(ok,m)=>{if(!ok)throw Error(m);};
export async function createTrafficBatch({wagonURL,horseURL,horseManifestURL,loadGLTF,loadManifest}){
 const loader=new GLTFLoader();
 const pins={wagon:'7749a0199b93bd196ecf6c3482af8ec537f1420a38f6fac88ab79fd8f34d44aa',horse:'89b048b7cda748e6f3a7111aa8e4f3198b01fabf6015cae644c78ed02d385bc6',manifest:'6d5cccb73dbae3dae52a5db6ef0a8cf1be0e79095467c0348cdb0dd315bf2e6a'};
 async function pinnedBytes(url,key){const r=await fetch(url);need(r.ok,'source HTTP');const raw=await r.arrayBuffer();const sha=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',raw)),v=>v.toString(16).padStart(2,'0')).join('');need(sha===pins[key],'source SHA mismatch '+key);return raw;}
 const readGLTF=loadGLTF??(async(url,key)=>loader.parseAsync(await pinnedBytes(url,key),''));
 const readManifest=loadManifest??(async url=>JSON.parse(new TextDecoder().decode(await pinnedBytes(url,'manifest'))));
 const [wagon,horse,metadata]=await Promise.all([readGLTF(wagonURL,'wagon'),readGLTF(horseURL,'horse'),readManifest(horseManifestURL)]);
 need(wagon.parser.json.extras?.asset_id==='wagon_w01_prototype'&&wagon.parser.json.extras.license==='GPL-3.0-or-later'&&metadata.asset_id==='equine_light_harness_skinned_prototype_01'&&metadata.license==='CC0-1.0','actual source identity/license');
 const walk=horse.animations.find(a=>a.name==='walk');need(walk&&metadata.locomotion?.walk?.stride_m>0,'actual walk/stride required');
 const gait=metadata.locomotion.walk,mixer=new T.AnimationMixer(horse.scene);mixer.clipAction(walk).play();
 const vehicle=wagon.scene.getObjectByName('vehicle_root');need(vehicle,'vehicle root');
 const wheels=['rear_left','rear_right','front_left','front_right'].map(n=>vehicle.getObjectByName('vehicle_wheel_'+n));need(wheels.every(Boolean),'four actual wheel pivots');
 const params=wagon.parser.json.extras.parameters;
 const frames=[new T.Matrix4(),new T.Matrix4()],uniform={value:frames};
 const records=[],positions=[],normals=[],colors=[],coeffs=[],actors=[],indices=[];
 for(const [actor,gl] of [[0,wagon],[1,horse]]){
  gl.scene.updateMatrixWorld(true);
  gl.scene.traverse(o=>{
   if(!o.isMesh)return;
   const g=o.geometry,mat=o.material;need(!Array.isArray(mat),'one primitive material required');
   need(!mat.flatShading&&!mat.envMap&&!mat.vertexColors,'flat-shading/envMap/source-vertex-color extension unsupported');
   need(mat.isMeshStandardMaterial&&!mat.transparent&&mat.opacity===1&&mat.side===T.FrontSide,'opaque scalar PBR material required');
   need(!mat.map&&!mat.normalMap&&!mat.roughnessMap&&!mat.metalnessMap&&!mat.alphaMap&&!mat.emissiveMap&&!mat.aoMap&&!mat.lightMap,'textures require separately qualified atlas');
   need(mat.emissive.r===0&&mat.emissive.g===0&&mat.emissive.b===0&&!g.morphAttributes.position?.length,'emissive/morph extension not supported');
   const a=g.attributes.position;need(g.attributes.normal?.count===a.count,'source normals required');
   const start=positions.length/3,active=g.index?Array.from(g.index.array):Array.from({length:a.count},(_,i)=>i);
   need(g.drawRange.start===0&&(!Number.isFinite(g.drawRange.count)||g.drawRange.count>=active.length),'partial drawRange requires explicit handling');
   need(active.length%3===0,'triangles only');
   for(let i=0;i<a.count;i++){positions.push(0,0,0);normals.push(0,1,0);colors.push(mat.color.r,mat.color.g,mat.color.b);coeffs.push(mat.roughness,mat.metalness);actors.push(actor);}
   indices.push(...active.map(i=>i+start));records.push({o,start,count:a.count,actor});
  });
 }
 const geometry=new T.BufferGeometry();
 for(const [name,values,size] of [['position',positions,3],['normal',normals,3],['color',colors,3],['trafficPBR',coeffs,2],['trafficActor',actors,1]])geometry.setAttribute(name,new T.Float32BufferAttribute(values,size));
 geometry.setAttribute('_confidence',new T.Float32BufferAttribute(new Float32Array(actors.length).fill(1),1));
 geometry.attributes.position.setUsage(T.DynamicDrawUsage);geometry.attributes.normal.setUsage(T.DynamicDrawUsage);geometry.setIndex(indices);
 const material=new T.MeshStandardMaterial({vertexColors:true,roughness:1,metalness:1});
 material.onBeforeCompile=shader=>{
  shader.uniforms.trafficFrames=uniform;
  shader.vertexShader='attribute float trafficActor;attribute vec2 trafficPBR;uniform mat4 trafficFrames[2];varying vec2 vTrafficPBR;\n'+shader.vertexShader;
  shader.vertexShader=shader.vertexShader.replace('#include <beginnormal_vertex>','#include <beginnormal_vertex>\nmat4 trafficFrame=trafficActor<0.5?trafficFrames[0]:trafficFrames[1];objectNormal=mat3(trafficFrame)*objectNormal;');
  shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\ntransformed=(trafficFrame*vec4(transformed,1.0)).xyz;vTrafficPBR=trafficPBR;');
  shader.fragmentShader='varying vec2 vTrafficPBR;\n'+shader.fragmentShader;
  shader.fragmentShader=shader.fragmentShader.replace('#include <roughnessmap_fragment>','#include <roughnessmap_fragment>\nroughnessFactor=vTrafficPBR.x;');
  shader.fragmentShader=shader.fragmentShader.replace('#include <metalnessmap_fragment>','#include <metalnessmap_fragment>\nmetalnessFactor=vTrafficPBR.y;');
 };
 material.customProgramCacheKey=()=> 'T2796-scalar-PBR-two-actor-v1';
 const mesh=new T.Mesh(geometry,material);mesh.name='T2796_far_shared_surface_study';mesh.frustumCulled=false;mesh.castShadow=false;mesh.receiveShadow=false;
 const p=new T.Vector3(),n=new T.Vector3(),normalMatrix=new T.Matrix3(),skin=new T.Matrix4(),bm=new T.Matrix4(),bound=new T.Matrix4(),v4=new T.Vector4();
 function bakePose(s,horseDistance){
  for(let i=0;i<4;i++)wheels[i].rotation.x=s/(i<2?params.wheel_diameter_rear_m/2:params.wheel_diameter_front_m/2);
  mixer.setTime((horseDistance/gait.stride_m%1)*walk.duration);
  wagon.scene.updateMatrixWorld(true);horse.scene.updateMatrixWorld(true);
  for(const {o,start,count} of records){
   if(o.isSkinnedMesh)o.skeleton.update();normalMatrix.getNormalMatrix(o.matrixWorld);
   for(let i=0;i<count;i++){
    o.getVertexPosition(i,p).applyMatrix4(o.matrixWorld);n.fromBufferAttribute(o.geometry.attributes.normal,i);
    if(o.isSkinnedMesh){
     const si=o.geometry.attributes.skinIndex,sw=o.geometry.attributes.skinWeight;skin.elements.fill(0);
     for(let k=0;k<4;k++){const weight=sw.getComponent(i,k);bm.fromArray(o.skeleton.boneMatrices,si.getComponent(i,k)*16);for(let j=0;j<16;j++)skin.elements[j]+=bm.elements[j]*weight;}
     bound.multiplyMatrices(o.bindMatrixInverse,skin).multiply(o.bindMatrix);v4.set(n.x,n.y,n.z,0).applyMatrix4(bound);n.set(v4.x,v4.y,v4.z);
    }
    n.applyMatrix3(normalMatrix).normalize();need([...p,...n].every(Number.isFinite),'nonfinite evaluated source vertex');
    geometry.attributes.position.setXYZ(start+i,p.x,p.y,p.z);geometry.attributes.normal.setXYZ(start+i,n.x,n.y,n.z);
   }
  }
  geometry.attributes.position.needsUpdate=true;geometry.attributes.normal.needsUpdate=true;
 }
 let lastPose=-Infinity,hasFrame=false;
 function update({wagon:ws,horse:hs,simulationS,cameraDistance,paused=false,reducedMotion=false}){
  need([simulationS,cameraDistance,ws.e,ws.n,ws.yaw_enu_rad,ws.distance_m,hs.e,hs.n,hs.yaw_enu_rad,hs.distance_m].every(Number.isFinite),'finite state');
  need(ws.scene==='1835'&&hs.scene==='1835'&&ws.grade==='reconstructed'&&hs.grade==='reconstructed','1835 reconstructed study only');
  // No near fallback: detailed rig renderer requires separate admission.
  mesh.visible=cameraDistance>=80&&cameraDistance<=240;
  if((paused||reducedMotion)&&hasFrame)return;
  for(const [i,s] of [[0,ws],[1,hs]])frames[i].makeRotationY(s.yaw_enu_rad).setPosition(s.e,0,s.n);
  hasFrame=true;
  if(!paused&&!reducedMotion&&(lastPose===-Infinity||simulationS<lastPose||simulationS-lastPose>=.2)){bakePose(ws.distance_m,hs.distance_m);lastPose=simulationS;}
 }
 bakePose(0,0);
 return {mesh,update,receipt:{source_sha256:pins,triangles:indices.length/3,vertices:positions.length/3,draw_batches:1,new_texture_bytes:0,shadow_policy:'far study does not cast/receive shadows; production policy unqualified',grade:'reconstructed',source_triangle_topology:'retained exactly; no decimation',horse_motion:gait.status,driver_person_id:null,hitch_status:'NOT CONNECTED: independent wagon/horse actors, not a qualified pulled wagon'},dispose(){geometry.dispose();material.dispose();mixer.stopAllAction();for(const r of records){r.o.geometry.dispose();r.o.material.dispose();}}};
}
