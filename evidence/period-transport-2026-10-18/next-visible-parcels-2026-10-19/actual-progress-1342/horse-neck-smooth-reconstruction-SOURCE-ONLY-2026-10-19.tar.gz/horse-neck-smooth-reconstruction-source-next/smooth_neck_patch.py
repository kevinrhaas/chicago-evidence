# SPDX-License-Identifier: CC0-1.0
"""Original UNEXECUTED horse proposal. Actual calls require separate review.
Tests use synthetic anchors only. No IO, rig changes, optimization or search.
"""
import math
TIMES=tuple(i/16 for i in range(1,16))
def require(ok,msg):
 if not ok:raise ValueError(msg)
def vector(a):
 require(len(a)==3 and all(math.isfinite(x)for x in a),'Finite3D anchor required');return tuple(map(float,a))
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def mul(a,s):return tuple(x*s for x in a)
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def controls(A,B,Q,H):
 A,B,Q,H=map(vector,[A,B,Q,H]);t0=sub(B,A);t1=sub(H,Q)
 require(dot(t0,t0)>0 and dot(t1,t1)>0,'Noncollapsed endpoint derivatives')
 return B,add(B,mul(t0,1/3)),sub(Q,mul(t1,1/3)),Q

def bezier(c,t):
 require(0<=t<=1,'Closed patchparameter only')
 w=((1-t)**3,3*(1-t)**2*t,3*(1-t)*t*t,t**3)
 return tuple(sum(c[i][k]*w[i]for i in range(4))for k in range(3))
def derivative(c,t):
 return tuple(3*((1-t)**2*(c[1][k]-c[0][k])+2*(1-t)*t*(c[2][k]-c[1][k])+t*t*(c[3][k]-c[2][k]))for k in range(3))
def head_weight(t):
 # w(0)=0,w'(0)=0,w(1)=.5,w'(1)=.8-.5=.3.
 require(0<=t<=1,'Weightparameter range');return 1.2*t*t-.7*t*t*t

def recipe():
 return{'status':'UNACCEPTED original smoothupperneck reconstruction proposal','base_parent_sha256':'26027c225b0c2f3c6ed72543cb2e80238196a86815b7bb910744cbc65cb23ed3','upstream_anchor':list(range(144,168)),'fixed_start_boundary':list(range(168,192)),'retired_interior_vertices':list(range(192,216)),'fixed_end_boundary':list(range(216,240)),'protected_head_derivative_anchor':list(range(1049,1073)),'retired_source_faces':list(range(336,432)),'new_interior_t':list(TIMES),'new_vertex_count':360,'new_triangle_count':768,'old_removed_triangle_count':96,'old_position_changes':[],'new_vertex_weights':'root=1-w(t), head=w(t); w=1.2t²-.7t³','old_weight_changes':[],'allowed_old_normal_halo':list(range(168,192)),'protected_portal_and_all_head48_normals':'EXACT','movement_guard':'OLD opposite-continuation movementguard remains unchanged andFAILED; this is a NEW geometryauthority request, not its accepted continuation','endpoint_derivatives':['B-A','H-Q'],'not_proven':['actual3Dembedding','discreteposedcontact','gearfit','silhouette/anatomy/photoacceptance']}

def build_proposal(A,B,Q,H):
 require(all(len(x)==24 for x in[A,B,Q,H]),'Exact declared24column correspondence')
 columns=[controls(*anchors)for anchors in zip(A,B,Q,H)]
 vertices={};weights={};rows=[]
 rows.append(['B:'+str(168+i)for i in range(24)])
 for row,t in enumerate(TIMES):
  ids=[]
  for k,c in enumerate(columns):
   key=f'new:{row}:{k}';vertices[key]=bezier(c,t);w=head_weight(t);weights[key]={'root':1-w,'head':w};ids.append(key)
  rows.append(ids)
 rows.append(['Q:h'+str(i)for i in range(24)])
 faces=[]
 for a,b in zip(rows,rows[1:]):
  for k in range(24):
   j=(k+1)%24;faces.extend([(a[k],a[j],b[j]),(a[k],b[j],b[k])])
 # Caller must resolve ONLY these exact source labels to oldB/Q; newvertices
 # append to the coatmesh. Actual active remapping/normal export not run here.
 require(len(vertices)==360 and len(faces)==768,'Declared patch count')
 return{'new_positions':vertices,'new_weights':weights,'faces':faces,'source_recipe':recipe(),'status':'UNACCEPTED; actualgeometry/poseguards required'}
