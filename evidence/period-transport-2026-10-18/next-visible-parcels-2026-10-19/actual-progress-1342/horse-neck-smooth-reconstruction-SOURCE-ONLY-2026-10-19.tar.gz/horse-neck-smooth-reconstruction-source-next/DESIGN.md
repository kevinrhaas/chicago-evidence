# Smooth upper-neck reconstruction — source proposal, actual curve UNEXECUTED

## Concrete obstruction and required freedom

Parent26027 and c243 have EXACTsame position/skin arrays. Savedparent fullcohort has18proper+2raw findings across the lower finalneck strip. Failedc243 shifts the first crossing to headsource37 (h18,H19,H18) versus newfantriangle(O21,Q18,Q17). It sharesQ18 yet penetrates awayfromQ18; preserving portalownership does not avoid collision. No claim every fixedboundary itself crosses head is supported by these saved pointwitnesses. The obstruction is the fixedheadband occupying the straightspanning neckpatch interior.

Read-only sourceanchor analysis: incoming fixedring7→portal direction Q−B opposes protectedhead exit direction H−Q in11side/lowercolumns13..23. Earlier movementball proves no positive oppositecontinuation at14..22. Therefore anotherdiagonal or smallerpositiveλ cannot supply the necessary turned/throatlatch contour. The OLDmovementguard remainsunchanged, FAILED. This proposal explicitly requests a NEW reconstructed necksurface authority, not permission to call thatguardpassed.

## One original geometric construction

Fixedupstream ring6 A144..167 and fixedstart ring7 B168..191; fixedportal Q216..239 and protectedheadband H1049..1072. For each corresponding angularcolumn, use ONE cubicBezier with controls B, B+(B−A)/3, Q−(H−Q)/3, Q. This enforces underlyingcurve endpointderivatives B−A and H−Q, so the upperneck approaches the retainedhead direction instead of cutting directly through it. No parameteroptimization/search or extra breed/metric inference. It follows the general neck/throatlatch separation visible in cleared CuyerFig92 qualitatively; these are ORIGINAL reconstructed surface dimensions, not a traced/measured anatomical model.

Retire96originalsourcefaces336..431 (strips7/8) and make oldring8 vertices192..215 inactive. Keep everyoldPOSITION/JOINT/WEIGHT byte exact, including oldinactivevertices. Append15interior24vertex rings at explicit dyadic t=1/16..15/16 (360newvertices), with16strips/768newtriangles. This deliberately resolves the turn nearportal; three coarseinteriorrings would not faithfully approximate a reversing endpointtangent. Theoretical net+672triangles; if applied to11452parent,12124triangles, batchedcoat still noextra material draw. This is a sourcecount estimate, not measured actorcapacity/performance. No actualcurvepositions or horseGLB generated.

Continuousheadweight w(t)=1.2t²−.7t³ is monotonic0→.5, derivative0 atB and .3 atQ matching protectedfirstheadband weight difference .8−.5. Newvertices bind only existingnamed root/head; alloldweight/joint vectors, rig/rest/IBMs/socket/clip/sole remainexact. AnalyticcontinuousC1 does NOT prove discreteglTFposedC1 or selfembedding; allactualposes remainmandatory. Materialcoat existing, no newtextures/COLOR0.

## Explicit envelope and normals

The cubic lies in each fourcontrol convexhull; angulartriangle interpolation stays in adjacentcolumn hulls. Read-only analyticalcontrolhull (NOT actualsamplepositions) has localAABB x±.13m,y[1.45000005,1.99000001],z[.52999997,.86000003]. Originalupperneckpatch samex/y bounds,zmax.85000002. Thus requested localcontrol-envelope extension is10.00001mm forwardZ, with no wider/taller bound. This provides a bounded silhouette argument, NOT collisionclearance, anatomicalattestation or a guarantee that allnewvertices avoid head. The newcurve can still selfintersect or produce an ugly throat if fixedheadanchors impose an unsuitable shape.

Newvertexnormals derive from actualneworientedfaces after generation. Only oldnormalhalo B168..191 may change; protectedportalQ/allhead48/ears and allotheroldnormals stayexact. Fixedportal normals may not equal the newareaweighted normal, so normal continuity/shading remains an explicit visualgate. Any need to modify protectedhead48 must be reported as a NEWconflict, not silently relaxed.

## Required fresh qualification and visual comparison

Beforeactualgeneration, root must approve exactly this new96sourceface/360vertex/24oldnormal scope and revisedproducer/remaps/authority. Generator must pin26027 and original090/earproducer chain, source-owned allanchorindices/skinfields and current96activefaces; appendonlybuffers, retain allunaffectedtriangles exactly. Emit exactretirement/newfaceowners and allprotectedfield hashes; no proximitymapping. Onebuild only afterrelease, failclosed on finiteness, degeneracy, normal orientation, manifold and boundaryalias ownership.

Freshbinary64 fullheadinternal+headvsALLactivehorse AND entirechangedneckpatch internal+vsALLhorse, unchangedSAT1e-8/proper/exactcontact rules, allbaselineknownnegatives retained; firstFAILSTOP. Then separately63actualidle/walk/trotposes, rig/soles unchangedproof, actualwholegearfit including headstrap failures, beforeany integration. No oldCPUresults cover thissurface.

Only afterCPUproof/rootrelease: matched parent26027/failedc243/new barehorse profile,frontquarter,front andwholehorse atidle+walk/trot whereuseful, desktop/mobile, identicalcamera/light/exposure; inspect throatmass/tangent/shading, necksilhouette and sourcecomparison. Gear views require freshgearqualification, not cosmeticpassing screenshots. Anatomy/photographic acceptance remainsopen.

Five synthetic controls normal/-O PASS (endpointderivatives,convexcontrolhull,weights,topology counts408boundary+interiorvertices/768annulusfaces, no mutation/badsourceinputs); exactpatch annulusEuler0 and48boundaryedges. Allcurveexecutions in tests use artificialcylinder anchors only. Actualhorse source POSITION arrays were READ ONLY for tangent/envelope mathematics, no curveevaluation/candidate/export/capture/SAT. Allfailedarchives unchanged.
