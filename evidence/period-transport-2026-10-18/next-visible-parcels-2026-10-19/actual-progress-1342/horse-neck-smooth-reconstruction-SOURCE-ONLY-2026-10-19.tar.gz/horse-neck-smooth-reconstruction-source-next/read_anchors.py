# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only anchor/tangent/envelope mathematics, NO patch evaluation."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
sys.path.insert(0,'/workspace/shared/horse-neck-topology-pipeline-source-next')
from glb_data import parse,read
p=Path('/workspace/shared/horse-ear-root-exporter-source-reviewed-next/export-trial1/equine_ear_root_candidate.glb');raw=p.read_bytes();want='26027c225b0c2f3c6ed72543cb2e80238196a86815b7bb910744cbc65cb23ed3'
if hashlib.sha256(raw).hexdigest()!=want:raise ValueError('Parent pin')
d,b=parse(raw);a=read(d,b,d['meshes'][0]['primitives'][0]['attributes']['POSITION']).astype(float);A=a[144:168];B=a[168:192];O=a[192:216];Q=a[216:240];H=a[1049:1073];rows=[]
for i in range(24):
 incoming=Q[i]-B[i];outgoing=H[i]-Q[i];dot=float(incoming@outgoing);cos=dot/float(np.linalg.norm(incoming)*np.linalg.norm(outgoing));rows.append({'sample':i,'body_ring6':144+i,'fixed_neck_ring7':168+i,'retired_neck_ring8':192+i,'protected_portal':216+i,'protected_head_band':1049+i,'incoming_dot_head_direction_m2':dot,'angle_degrees':float(np.degrees(np.arccos(np.clip(cos,-1,1)))),'direction_reversal':dot<0})
# Convex-hull control envelope only; NO actual candidate/sample positions.
controls=np.vstack([B,B+(B-A)/3,Q-(H-Q)/3,Q]);oldpatch=np.vstack([B,O,Q]);report={'status':'READONLY source-anchor/tangent/control-envelope math; no curve generated','input_sha256':want,'rows':rows,'reversal_samples':[r['sample']for r in rows if r['direction_reversal']],'original_patch_AABB_m':{'min':oldpatch.min(0).tolist(),'max':oldpatch.max(0).tolist()},'symbolic_Bezier_control_hull_AABB_m':{'min':controls.min(0).tolist(),'max':controls.max(0).tolist()},'control_formulas':['B','B+(B-A)/3','Q-(H-Q)/3','Q'],'actual_curve_positions_evaluated':False}
Path(__file__).with_name('anchor-envelope-diagnosis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='rows'},indent=2))
