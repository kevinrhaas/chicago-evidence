// SPDX-License-Identifier: GPL-3.0-or-later
// Future actual-geometry measurement helper; not invoked on an asset here.
import * as T from 'three';
export function measureShaftTips({vehicleRoot,assetId,glbSHA256,shaftNodeNames,tipBandM=.025}){
 if(['wagon_w01_prototype','wagon_w01_driver_bench_study'].includes(assetId))throw Error('W01 central team tongue has no physical paired shafts');
 if(!/^[a-f0-9]{64}$/.test(glbSHA256)||shaftNodeNames?.length!==2||!(tipBandM>0&&tipBandM<=.025))throw Error('actual source identity/two explicit shaft owners required');
 vehicleRoot.updateWorldMatrix(true,true);const points=[],section=[];
 for(let side=0;side<2;side++){
  const node=vehicleRoot.getObjectByName(shaftNodeNames[side]);if(!node||node.userData.transport_role!==(side?'shaft_right':'shaft_left'))throw Error('physical shaft semantic owner missing');
  const verts=[];node.traverse(o=>{if(!o.isMesh)return;if(o.isSkinnedMesh||o.isInstancedMesh)throw Error('rigid physical shaft mesh required');const g=o.geometry,a=g.attributes.position,idx=g.index;const start=g.drawRange.start,end=Math.min(idx?.count??a.count,start+g.drawRange.count);for(let i=start;i<end;i++){const v=new T.Vector3();o.getVertexPosition(idx?idx.getX(i):i,v).applyMatrix4(o.matrixWorld);vehicleRoot.worldToLocal(v);verts.push(v);}});
  if(!verts.length)throw Error('empty shaft geometry');const maxZ=Math.max(...verts.map(v=>v.z)),tip=verts.filter(v=>maxZ-v.z<=tipBandM),box=new T.Box3().setFromPoints(tip),center=box.getCenter(new T.Vector3());
  if(!(side?center.x<0:center.x>0)||box.max.z-box.min.z>tipBandM+1e-8)throw Error('shaft side/tip extent mismatch');points.push(center.toArray());section.push({minimum_local_m:box.min.toArray(),maximum_local_m:box.max.toArray(),actual_active_samples:tip.length});
 }
 return{actual_geometry:true,kind:'paired_shafts',asset_id:assetId,glb_sha256:glbSHA256,points_local_m:points,tip_sections:section,scope:'actual active shaft tip AABBs in vehicle frame, not body clearance, tug bore, pressure, load, pose sweep or period acceptance'};
}
