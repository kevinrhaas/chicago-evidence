// SPDX-License-Identifier: GPL-3.0-or-later
// Outside-app proposal only: no placement, mesh generation, mounting or asset load.
export const CORRIDOR_LINE='drawn';
export const CORRIDOR_LINE_WHY='A transport study follows the currently rendered travelled track, never changes the plat or survey-control line; explicit drawn_track wins, platted path is declared fallback.';
const need=(x,m)=>{if(!x)throw Error(m);},finite=Number.isFinite,sha=x=>typeof x==='string'&&/^[a-f0-9]{64}$/.test(x);
export function straightRouteStudy(streets,{streetId,segmentIndex,endMarginM,sourceRegistry}){
 need(streets.scene==='1835'&&streets.target_date==='1835-07-01','exact scene/date required');
 const street=streets.streets.find(s=>s.id===streetId);need(street,'existing street ID');
 const drawn=street.drawn_track_local_enu_m,path=drawn??street.path_local_enu_m;
 need(Array.isArray(path)&&Number.isInteger(segmentIndex)&&segmentIndex>=0&&segmentIndex+1<path.length,'explicit existing segment only');
 const ids=[...new Set([...(streets.sources??[]),...(street.sources??[])])];need(ids.length>0&&ids.every(id=>sourceRegistry[id]),'all existing street source IDs must resolve');
 const a=path[segmentIndex],b=path[segmentIndex+1];need([a,b].every(p=>p.length===2&&p.every(finite)),'finite ENU segment');
 const length=Math.hypot(b[0]-a[0],b[1]-a[1]);need(finite(endMarginM)&&endMarginM>0&&length>2*endMarginM,'both ends reserve complete rig clearance');
 const unit=[(b[0]-a[0])/length,(b[1]-a[1])/length];
 return {format:'transport_scene_route_proposal_v1',production_enabled:false,scene:'1835',target_date:'1835-07-01',street_id:streetId,segment_index:segmentIndex,track_basis:drawn?'drawn_track_local_enu_m':'path_local_enu_m explicit fallback',source_ids:ids,grade:'reconstructed',ownership_claim:null,points:[[a[0]+unit[0]*endMarginM,a[1]+unit[1]*endMarginM],[b[0]-unit[0]*endMarginM,b[1]-unit[1]*endMarginM]],bearing_rad:Math.atan2(unit[0],unit[1]),corridor_width_m:street.corridor_width_m??streets.corridor_width_m,travelled_track_width_m:street.track_width_m??null,blocked:['No route selected/deployed by this function','Actual terrain/water/static swept corridor certificate missing','Physical horse/gear/vehicle hitch qualification missing','Named driver/body/rein acceptance missing','Published all-stand cost and frame qualification missing']};
}
// Dataset compass bearing != project actor yaw: this actor is +Z forward.
export function enuFrame(e,n,y,bearingRad){need([e,n,y,bearingRad].every(finite),'finite frame');return{position:[e,y,-n],yaw_y_rad:Math.PI-bearingRad};}
export function localToEnu([x,y,z],e,n,bearingRad){return[e-x*Math.cos(bearingRad)+z*Math.sin(bearingRad),n+x*Math.sin(bearingRad)+z*Math.cos(bearingRad),y];}
export function flatTerrainSupport({e,n,bearingRad,contactLocal,terrain,receipt,toleranceM=.005}){
 need(receipt?.scene==='1835'&&receipt.target_date==='1835-07-01'&&sha(receipt.heightfield_sha256),'dated actual terrain receipt required');
 need(typeof terrain.inBounds==='function'&&typeof terrain.isWater==='function'&&typeof terrain.surfaceHeight==='function','actual terrain interface required, not walkHeight water barrier');
 need(contactLocal.length>=4&&contactLocal.every(p=>p.length===3&&p.every(finite)&&p[1]===0),'explicit ground contact offsets required');
 need(finite(toleranceM)&&toleranceM>=0&&toleranceM<=.005,'do not widen flat parcel tolerance');
 const samples=contactLocal.map(p=>{const [pe,pn]=localToEnu(p,e,n,bearingRad);need(terrain.inBounds(pe,pn)&&!terrain.isWater(pe,pn),'water/out-of-grid support forbidden');const h=terrain.surfaceHeight(pe,pn);need(finite(h),'terrain height');return{e:pe,n:pn,height_m:h};});
 const y=samples.reduce((sum,s)=>sum+s.height_m,0)/samples.length,maxError=Math.max(...samples.map(s=>Math.abs(s.height_m-y)));
 need(maxError<=toleranceM,'flat-only parcel: slope/contact residual requires dedicated rig support solver');
 return {frame:enuFrame(e,n,y,bearingRad),sampled_ground:samples,maximum_support_residual_m:maxError,grade:'reconstructed',acceptance:'HEIGHT STUDY ONLY; no continuous wheel/hoof/bridge/collision acceptance'};
}
export function solveSingleHorseShaftFrame({vehicleAssetId,vehicleENU,bearingRad,shaftGeometry,tugGeometry,horseGroundY,toleranceM=.005}){
 need(!['wagon_w01_prototype','wagon_w01_driver_bench_study'].includes(vehicleAssetId),'W01 central team tongue is NOT paired shafts; empty single socket cannot qualify');
 for(const [label,g]of [['shafts',shaftGeometry],['tugs',tugGeometry]])need(g?.actual_geometry===true&&sha(g.glb_sha256)&&Array.isArray(g.points_local_m)&&g.points_local_m.length===2&&g.points_local_m.every(p=>p.length===3&&p.every(finite)),label+' actual measured geometry required');
 need(shaftGeometry.kind==='paired_shafts'&&tugGeometry.kind==='physical_shaft_tugs','physical installed parts required, not empty socket labels');
 need(shaftGeometry.points_local_m[0][0]>0&&shaftGeometry.points_local_m[1][0]<0&&tugGeometry.points_local_m[0][0]>0&&tugGeometry.points_local_m[1][0]<0,'left/right correspondence must be explicit');
 need(finite(toleranceM)&&toleranceM>=0&&toleranceM<=.005&&finite(horseGroundY)&&vehicleENU.length===3&&vehicleENU.every(finite),'bounded fit input');
 const mid=points=>points[0].map((v,i)=>(v+points[1][i])/2),tip=mid(shaftGeometry.points_local_m),tug=mid(tugGeometry.points_local_m);
 const [de,dn]=localToEnu([tip[0]-tug[0],0,tip[2]-tug[2]],0,0,bearingRad),horseE=vehicleENU[0]+de,horseN=vehicleENU[1]+dn;
 const errors=shaftGeometry.points_local_m.map((p,i)=>{const a=localToEnu(p,vehicleENU[0],vehicleENU[1],bearingRad),b=localToEnu(tugGeometry.points_local_m[i],horseE,horseN,bearingRad);return Math.hypot(a[0]-b[0],a[1]-b[1],vehicleENU[2]+p[1]-horseGroundY-tugGeometry.points_local_m[i][1]);});
 need(Math.max(...errors)<=toleranceM,'actual shaft/tug fit mismatch; do not float/scale horse to fit');
 return{horse_enu:[horseE,horseN,horseGroundY],horse_world:enuFrame(horseE,horseN,horseGroundY,bearingRad),attachment_errors_m:errors,status:'RIGID STRAIGHT FRAME SOLVE ONLY; body/shaft swept collision, tugs section fit, traces, brakes and loads NOT QUALIFIED'};
}
export function budgetParcel({wagonTriangles,horseTriangles,horseCount,harnessTriangles,driverTriangles,hardwareTriangles,submittedCalls,baseline={triangles:1154091,calls:89}}){
 const values=[wagonTriangles,horseTriangles,horseCount,harnessTriangles,driverTriangles,hardwareTriangles,submittedCalls,baseline.triangles,baseline.calls];need(values.every(x=>Number.isInteger(x)&&x>=0)&&horseCount>0,'all actual component costs explicit; absent parts cannot disappear');
 const triangles=wagonTriangles+horseTriangles*horseCount+harnessTriangles+driverTriangles+hardwareTriangles,calls=baseline.calls+submittedCalls;
 return{parcel_triangles:triangles,total_triangles:baseline.triangles+triangles,total_calls:calls,within_arithmetic_caps:baseline.triangles+triangles<=1190000&&calls<=90,remaining_triangles:1190000-baseline.triangles-triangles,remaining_calls:90-calls,scope:'Arithmetic ONLY, not admission, actual all-pass published delta or physical/historical approval'};
}
