# Exact078 source recovery and fourpart rebase — root review pending

Found original source at /workspace/shared/horse-v2-cap-registered-next. Verified actual generator,parameters and TWO retained buildGLBs against its SHA256.json; both GLBs078ed2cebc01dba52d28f2ae737f170f0fe28fd20523aed9bb8869f4cd7b35bd. These are existing historical exactbuilds, NOT a newly executed baseline. Source binding receipt records exact bytehashes.

Concrete failedbaseline cause: currentapp generator lacked section_offsets support in strap(), whereas exact078source adds bounded <=2mm persection offsets and passes them for breastcollar/support. Its parameters also retain breastcollar_section_offsets_m and breastcollar_support_section_offsets_m. Those omitted original corrections explain actualunexpected breastcollar/leftsupport changes; no need for binarytransplant or assumption generatedGLBs equivalent. Full source recovery diff retained.

Prepared generate_harness.contour.py from EXACT078source, replacing ONLY cheekL/R,brow,nose strap callsites with existing candidate's explicit sourceconforming routes/normals. No function definition changed: actual AST equality verified for every function, including sectionoffset implementation. parameters.contour.json preserves EVERY078field/value exactly and adds only headstrap_contour_study. generator.patch shows actual limited sourcechanges. Route widths18mm/thickness3mm, original bitendpoints/provenance/license remain. Existingcandidate's raw sourceplane routes are reused as data; no secondgeometrycandidate generated.

The failed firstcandidate and PASSfalse receipt/source are archived at /workspace/shared/horse-headgear-contour-failure-2026-10-19.tar.gz SHA3964f62aca5aa7a694677448c1b6ef11aa9a4e376a6c4726cb794fdfcd3db498. They remain unchanged and unqualified.

## Root-reviewed next command (NOT run)

python build_reviewed.py --root-reviewed-source --output-dir <NEW outside directory>

Runner checks exact preparedsource hashes and refuses overwrite. After the separately authorized secondcandidate, actual decodedPOSITION/NORMAL arrays for32protectednonheadmeshes, metadata/anchors/materials and sourceprovenance must match078; no inheritedsuccess before this. Then firstidle actualallhorse strictSAT/proper/signeddistance test should run before anyfull63poses; no browser/render claim. Contour rays/centerlinejoins do not prove rectangularribbon/featureedge clearance. Source route offset12mm is engineering reconstruction, not period measurement/pressureapproval.

Source-only check passes: allfunctionsASTexact, all078parametersretained, onlyroutefieldadded. NoGLBproduction,horsechange,app/ticketwrite,CI/browser or newfitclaim in this rebase step. Root source review remains pending.
