# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json,struct,tarfile
P=Path(__file__).parent;old=Path('/workspace/shared/horse-v2-cap-registered-next/build1');new=P/'candidate-one';changed={'cheekpiece_l','cheekpiece_r','browband','noseband'};name='light_breastcollar_harness_reconstructed_01.glb'
def load(p):
 b=p.read_bytes();n,t=struct.unpack_from('<II',b,12);j=json.loads(b[20:20+n]);off=20+n;size,typ=struct.unpack_from('<II',b,off);return j,b[off+8:off+8+size]
def meshdata(j,b,m):
 result=[]
 for pr in m['primitives']:
  attrs={}
  for key,aid in pr['attributes'].items():
   a=j['accessors'][aid];bv=j['bufferViews'][a['bufferView']];offset=bv.get('byteOffset',0)+a.get('byteOffset',0);size=a['count']*{'VEC3':3,'VEC2':2,'SCALAR':1}[a['type']]*4
   attrs[key]={'type':a['type'],'componentType':a['componentType'],'count':a['count'],'sha256':hashlib.sha256(b[offset:offset+size]).hexdigest()}
  result.append({'attributes':attrs,'material':pr.get('material'),'mode':pr.get('mode',4)})
 return result
j,b=load(old/name);k,c=load(new/name);a={m['name']:meshdata(j,b,m)for m in j['meshes']};z={m['name']:meshdata(k,c,m)for m in k['meshes']};fail=[];rows=[]
if set(a)!=set(z):fail.append('mesh names differ')
for n in sorted(set(a)&set(z)):
 equal=a[n]==z[n];rows.append({'mesh':n,'protected':n not in changed,'decoded_attributes_and_primitive_metadata_exact':equal})
 if n not in changed and not equal:fail.append('protected mesh '+n)
 if n in changed and equal:fail.append('expected changed geometry '+n)
def nodes(j):
 result=[]
 for n in j['nodes']:
  n=dict(n)
  if n['name']in changed:n.pop('extras',None)
  result.append(n)
 return result
checks={'materials_exact':j['materials']==k['materials'],'node_hierarchy_transforms_anchors_and_protected_extras_exact':nodes(j)==nodes(k),'root_source_license_provenance_exact':j['nodes'][0]==k['nodes'][0]}
x=json.loads((old/'manifest.json').read_text());y=json.loads((new/'manifest.json').read_text())
for field in ['source','license','grade','frame','bindings','anchors','head_relative_components','dynamic_components_unbound','missing','shaft_tugs']:
 checks['manifest_'+field+'_exact']=x.get(field)==y.get(field)
fail.extend(n for n,v in checks.items()if not v)
receipt={'PASS':not fail,'failures':fail,'baseline_sha256':hashlib.sha256((old/name).read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256((new/name).read_bytes()).hexdigest(),'protected_parts':32,'changed_parts':sorted(changed),'meshes':rows,'checks':checks,'scope':'actual decoded rest geometry+metadata comparison only; no SAT/clearance/pose/browser/visual/period acceptance'}
(P/'candidate-rest-contract.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items()if k!='meshes'}))
if fail:raise SystemExit(1)
