# SPDX-License-Identifier: CC0-1.0
"""One-shot generator runner; intentionally not executed before root source review."""
import argparse,hashlib,json,pathlib,subprocess,sys
P=pathlib.Path(__file__).parent
ap=argparse.ArgumentParser();ap.add_argument('--root-reviewed-source',action='store_true',required=True);ap.add_argument('--output-dir',type=pathlib.Path,required=True);a=ap.parse_args()
manifest=json.loads((P/'reviewed-source-hashes.json').read_text())
for name,sha in manifest.items():
 if hashlib.sha256((P/name).read_bytes()).hexdigest()!=sha:raise SystemExit('REFUSE source hash mismatch '+name)
if a.output_dir.exists():raise SystemExit('REFUSE overwrite existing candidate directory')
subprocess.run([sys.executable,str(P/'generate_harness.contour.py'),'--parameters',str(P/'parameters.contour.json'),'--output-dir',str(a.output_dir)],check=True)
