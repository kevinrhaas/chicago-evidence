# Released one-candidate generation: rest contract PASS

Root-authorized sourcehashguarded candidate generated once into exclusive candidate-one in about0.02s. ActualGLB SHA f89df20ba159114492bf6c2d8e24c894c5b617204fc78ba25c99d06be0890137;8988triangles/36meshes. Check_candidate.py independently decodes actual candidate and retained078 reference: ALL32 protectedpart POSITION/NORMAL arrays and primitive metadata exact, materials exact, hierarchy/transforms/anchors/protectedextras exact; source/license/provenance/bindings/manifest fields exact. Four intended headparts differ. ReceiptPASStrue,failuresempty.

This is a RESTCONTRACT result only. No SAT,fit,capture,browser,animation or densepose work executed. Old262raw/258strict failure and firstfailedcandidate remain unchanged. Root must separately authorize any fit next; no auto retry or repair. No app/horse/ticket/CI mutation.
