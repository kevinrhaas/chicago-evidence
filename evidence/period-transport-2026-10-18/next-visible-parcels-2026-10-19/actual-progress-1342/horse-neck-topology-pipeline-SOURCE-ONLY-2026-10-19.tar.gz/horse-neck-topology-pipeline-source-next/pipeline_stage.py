# SPDX-License-Identifier: GPL-3.0-or-later
"""UNEXECUTED finite phase CLI. Only execute after separate root release."""
from pathlib import Path
import sys,json,hashlib
from topology_export import export_once,parent_chain,PARENT_AUTHORITY
from topology_rest import audit_rest
from source_inventory import helper_inventory,inventory_sha
from ownership import PINS
BASE=Path('/workspace/shared/horse-head-groove-coat-next/trial1');EAR=Path('/workspace/shared/horse-ear-root-exporter-source-reviewed-next/export-trial1');SOURCE=Path('/workspace/shared/horse-ear-root-exporter-source-reviewed-next/source-trial1/candidate-source-edit.json')
def encoded(d):return(json.dumps(d,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def execute_stage(stage,outer):
 out=Path(outer)
 if stage=='export':
  folder=out/'export';folder.mkdir();raw,proof=export_once(BASE,EAR,SOURCE,checkpoint=lambda b:(folder/'UNVALIDATED-candidate.glb').write_bytes(b));(folder/'UNACCEPTED-candidate.glb').write_bytes(raw);(folder/'topology-export-proof.json').write_bytes(encoded(proof))
 elif stage=='metadata':
  folder=out/'payload';folder.mkdir();raw=(out/'export/UNACCEPTED-candidate.glb').read_bytes();proofraw=(out/'export/topology-export-proof.json').read_bytes();proof=json.loads(proofraw)
  parent_raw,*_=parent_chain(BASE,EAR,SOURCE);audit_rest(parent_raw,raw,proof['index_proof']);require=lambda x:None if x else(_ for _ in()).throw(ValueError('Actualprooflink'))
  require(proof['output_sha256']==sha(raw)and proof['input_pins']==PINS and proof['parent_authority_sha256']==PARENT_AUTHORITY)
  inv=helper_inventory(Path(__file__).parent);ih=inventory_sha(inv)
  manifest={'status':'UNACCEPTED','glb_sha256':sha(raw),'parent_sha256':PINS['candidate'],'original090_sha256':PINS['baseline'],'proof_sha256':sha(proofraw),'retired_source_faces':list(range(414,426)),'all_attributes_byte_exact':True,'source_recipe':proof['topology_recipe'],'helper_inventory':inv,'helper_inventory_sha256':ih,'not_run':['collision','63poses','gear','render_anatomy_photo']};mr=encoded(manifest)
  authority={'status':'UNACCEPTED','glb_sha256':sha(raw),'manifest_sha256':sha(mr),'parent_authority_sha256':PARENT_AUTHORITY,'original_parent_producer_pins':PINS,'helper_inventory':inv,'helper_inventory_sha256':ih};ar=encoded(authority)
  contents={'candidate.glb':raw,'topology-export-proof.json':proofraw,'manifest.json':mr,'authority.json':ar}
  for name,b in contents.items():
   with(folder/name).open('xb')as f:f.write(b)
   require((folder/name).read_bytes()==b)
  packet={'status':'UNACCEPTED','parent090_sha256':PINS['baseline'],'parent26027_sha256':PINS['candidate'],'helper_inventory':inv,'helper_inventory_sha256':ih,'files':{k:{'path':n,'sha256':sha(contents[n])}for k,n in[('glb','candidate.glb'),('proof','topology-export-proof.json'),('manifest','manifest.json'),('authority','authority.json')]}}
  (folder/'packet.json').write_bytes(encoded(packet))
 elif stage=='rest':
  parent_raw,*_=parent_chain(BASE,EAR,SOURCE);candidate=(out/'payload/candidate.glb').read_bytes();proof=json.loads((out/'payload/topology-export-proof.json').read_text());report=audit_rest(parent_raw,candidate,proof['index_proof']);(out/'independent-rest-readback.json').write_bytes(encoded(report))
 else:raise ValueError('Unsupported stage')
if __name__=='__main__':execute_stage(sys.argv[1],sys.argv[2])
