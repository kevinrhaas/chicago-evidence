# SPDX-License-Identifier: GPL-3.0-or-later
"""UNEXECUTED original smooth producer; root-approved efd1 scope only."""
from pathlib import Path
import copy,hashlib
import numpy as np
from topology_export import parent_chain,PARENT_AUTHORITY
from ownership import ATTRS,PINS,Model
from sparse_rules import require
from glb_data import append,encode
from smooth_rules import source_retirement,verify_parent_contract
from smooth_neck_patch import build_proposal,recipe

def export_once(base,ear,source,checkpoint=None):
 raw,m,labels,head,owners,_=parent_chain(Path(base),Path(ear),Path(source));root,headjoint,names=verify_parent_contract(m,labels);v=m.views[0,0];a=v['attributes'];p=a['POSITION'].astype(float)
 shape=build_proposal(p[144:168],p[168:192],p[216:240],p[1049:1073]);count=len(p);keys=list(shape['new_positions']);require(len(keys)==360,'Exact360new vertices');mapping={key:count+i for i,key in enumerate(keys)}
 def actual(label):
  if label.startswith('B:'):return int(label.split(':')[1])
  if label.startswith('Q:h'):return 216+int(label[3:])
  return mapping[label]
 newfaces=np.array([[actual(k)for k in f]for f in shape['faces']],dtype='<u4');require(newfaces.shape==(768,3),'Exact768new triangles')
 retired=source_retirement(v['indices']);keep=[i for i in range(len(v['indices']))if i not in set(retired)];indices=np.vstack([v['indices'][keep],newfaces]).astype('<u4')
 require(not np.isin(indices,np.arange(192,216)).any(),'Oldring8 must inactive inALLcoatfaces')
 # Othermeshes use distinct accessor domains; no sourcecoat index aliases there.
 newp=np.vstack([a['POSITION'],np.array([shape['new_positions'][k]for k in keys],dtype='<f4')]);newj=np.vstack([a['JOINTS_0'],np.tile([root,headjoint,root,root],(360,1))]).astype(a['JOINTS_0'].dtype);neww=np.vstack([a['WEIGHTS_0'],np.array([[shape['new_weights'][k]['root'],shape['new_weights'][k]['head'],0,0]for k in keys],dtype='<f4')])
 nn=np.vstack([a['NORMAL'],np.zeros((360,3),dtype='<f4')]);tri=newp[indices].astype(float);face=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);require(np.isfinite(face).all()and np.all(np.linalg.norm(face,axis=1)>2e-12),'Generated finite/nondegenerate triangles')
 accum=np.zeros_like(newp,dtype=float)
 for k in range(3):np.add.at(accum,indices[:,k],face)
 halo=list(range(168,192))+list(range(count,count+360));norm=np.linalg.norm(accum[halo],axis=1);require(np.all(norm>1e-12),'Valid new/allowedhalo normal sums');nn[halo]=(accum[halo]/norm[:,None]).astype('<f4')
 arrays={'POSITION':newp,'NORMAL':nn,'JOINTS_0':newj,'WEIGHTS_0':neww};d=copy.deepcopy(m.d);blob=bytearray(m.b);prim=d['meshes'][0]['primitives'][0]
 for k in ATTRS:prim['attributes'][k]=append(d,blob,arrays[k],'VEC3'if k in['POSITION','NORMAL']else'VEC4',5123 if k=='JOINTS_0'else 5126)
 prim['indices']=append(d,blob,indices.reshape(-1,1),'SCALAR',5125,target=34963);candidate=encode(d,blob)
 if checkpoint:checkpoint(candidate)
 decoded=Model(candidate)
 for k in ATTRS:require(np.array_equal(decoded.views[0,0]['attributes'][k],arrays[k]),'Serializedactual differs intended:'+k)
 proof={'status':'UNACCEPTED localexport ONLY','input_pins':PINS,'parent_authority_sha256':PARENT_AUTHORITY,'output_sha256':hashlib.sha256(candidate).hexdigest(),'source_recipe':recipe(),'parent_coat_vertex_count':count,'actual_skin_palette':{'root':root,'head':headjoint,'names':names},'index_proof':{'retired_old_active_faces':retired,'retired_source_faces':list(range(336,432)),'unchanged_old_to_new':[{'old':i,'new':j}for j,i in enumerate(keep)],'new_face_count':768,'new_vertex_keys':keys},'newpatch_indices':newfaces.tolist(),'not_run':['collision','63poses','gear','render']}
 from smooth_rest import audit_rest
 proof['rest_readback']=audit_rest(raw,candidate,proof)
 return candidate,proof
