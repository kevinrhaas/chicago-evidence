# SPDX-License-Identifier: GPL-3.0-or-later
"""Independent decodedreadback: rational Hermite, no producer/generator call."""
from fractions import Fraction as F
import hashlib
import numpy as np
from ownership import Model,ATTRS
from sparse_rules import require
from smooth_rules import storage_audit,source_faces,resolve_palette
from smooth_neck_patch import recipe

def audit_rest(parent_bytes,new_bytes,proof):
 require(proof['source_recipe']==recipe(),'Exactnewgeometryauthorityrecipe')
 old=Model(parent_bytes);new=Model(new_bytes);require(old.total==11452 and new.total==12124,'Exactold/newtrianglecounts');require(set(old.views)==set(new.views),'Primitives exact')
 oa=old.views[0,0]['attributes'];na=new.views[0,0]['attributes'];n=len(oa['POSITION']);require(proof['parent_coat_vertex_count']==n,'Oldcountproof');root,head,names=resolve_palette(old)
 require(proof['actual_skin_palette']=={'root':root,'head':head,'names':names},'Actualrigpaletteproof')
 for key,v in old.views.items():
  w=new.views[key];require(v['material']==w['material']and v['mesh_name']==w['mesh_name'],'Primitiveowner')
  if key!=(0,0):
   require(v['attributes_accessors']==w['attributes_accessors']and np.array_equal(v['indices'],w['indices']),'Othermeshindex/accessorrefs')
   for k in ATTRS:require(v['attributes'][k].tobytes()==w['attributes'][k].tobytes(),'Othermeshattribute changed')
 for k in ATTRS:
  require(na[k].dtype==oa[k].dtype and na[k].shape==(n+360,oa[k].shape[1]),'Exactnewattribute shape')
  if k!='NORMAL':require(na[k][:n].tobytes()==oa[k].tobytes(),'OLDattribute prefix byte mutation:'+k)
  else:
   mask=np.ones(n,dtype=bool);mask[168:192]=False;require(na[k][:n][mask].tobytes()==oa[k][mask].tobytes(),'ProtectedoldN changed')
 require(not np.isin(new.views[0,0]['indices'],np.arange(192,216)).any(),'ALLoldring8indicesinactive')
 ip=proof['index_proof'];require(ip['new_face_count']==768 and ip['new_vertex_keys']==[f'new:{j}:{k}'for j in range(15)for k in range(24)],'Exact newsourcevertex keys/count');retired=ip['retired_old_active_faces'];require(len(retired)==len(set(retired))==96 and ip['retired_source_faces']==list(range(336,432)),'Exact96sourceauthority')
 oldidx=old.views[0,0]['indices'];newidx=new.views[0,0]['indices'];canonical=lambda f:min(tuple(f),tuple(f[1:]+f[:1]),tuple(f[2:]+f[:2]))
 require({canonical(list(map(int,oldidx[i])))for i in retired}=={canonical(list(f))for f in source_faces()},'Actual96sourceface ownership')
 keep=[i for i in range(len(oldidx))if i not in set(retired)];require(np.array_equal(newidx[:len(keep)],oldidx[keep]),'Allretained indices exact');require(ip['unchanged_old_to_new']==[{'old':i,'new':j}for j,i in enumerate(keep)],'Actualold→newmap')
 rows=[list(range(168,192))]+[list(range(n+j*24,n+(j+1)*24))for j in range(15)]+[list(range(216,240))];expected=[]
 for a,b in zip(rows,rows[1:]):
  for k in range(24):j=(k+1)%24;expected.extend([(a[k],a[j],b[j]),(a[k],b[j],b[k])])
 require(np.array_equal(newidx[len(keep):],np.array(expected,dtype=newidx.dtype))and proof['newpatch_indices']==[list(f)for f in expected],'Exactly768sourceowned triangles')
 # Exact rational sourcefloat32 anchors and dyadict. Independent of Bezier code.
 expectedp=[];expectedw=[]
 for j in range(1,16):
  t=F(j,16);h00=2*t**3-3*t*t+1;h10=t**3-2*t*t+t;h01=-2*t**3+3*t*t;h11=t**3-t*t;w=(12*t*t-7*t**3)/10
  for k in range(24):
   A,B,Q,H=[oa['POSITION'][i+k]for i in[144,168,216,1049]]
   coords=[]
   for c in range(3):
    av,bv,qv,hv=[F(float(x[c]))for x in[A,B,Q,H]]
    coords.append(float(h00*bv+h10*(bv-av)+h01*qv+h11*(hv-qv)))
   expectedp.append(coords)
   expectedw.append([float(1-w),float(w),0,0])
 require(np.array_equal(na['POSITION'][n:],np.array(expectedp,dtype='<f4')),'NewP exactcanonicalrationalHermite')
 require(np.array_equal(na['WEIGHTS_0'][n:],np.array(expectedw,dtype='<f4'))and np.array_equal(na['JOINTS_0'][n:],np.tile([root,head,root,root],(360,1))),'NewW/J canonical')
 positions=na['POSITION'].astype(float);tri=positions[newidx];area=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);require(np.all(np.linalg.norm(area,axis=1)>2e-12),'Finite/nondegenerate wholecoat')
 accum=np.zeros_like(positions)
 for k in range(3):np.add.at(accum,newidx[:,k],area)
 halo=list(range(168,192))+list(range(n,n+360));norm=np.linalg.norm(accum[halo],axis=1);require(np.all(norm>1e-12),'Normalarea valid');expectedn=accum[halo]/norm[:,None]
 delta=np.linalg.norm(na['NORMAL'][halo].astype(float)-expectedn,axis=1);require(np.all(delta<=1e-6),'New/haloN orientedarea alignment')
 storage=storage_audit(old,new)
 return{'status':'REST ONLY; NOTself/gear/anatomyacceptance','all_old_POS_J_W_byte_exact':True,'protected_old_N_byte_exact':True,'old_normal_halo':list(range(168,192)),'new_vertices':360,'new_faces':768,'retired_source_faces':list(range(336,432)),'newP_rational_Hermite_exact':True,'normal_alignment_max_delta':float(delta.max()),'normal_alignment_tolerance':1e-6,'normal_tolerance_scope':'float32normalengineeringcheck ONLY; collisionepsilon unchanged','storage':storage,'output_sha256':hashlib.sha256(new_bytes).hexdigest()}
