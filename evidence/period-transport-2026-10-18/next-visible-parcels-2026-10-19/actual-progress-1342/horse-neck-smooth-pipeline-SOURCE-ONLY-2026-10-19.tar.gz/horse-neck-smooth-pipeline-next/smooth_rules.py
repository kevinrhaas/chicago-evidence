# SPDX-License-Identifier: GPL-3.0-or-later
import numpy as np
from sparse_rules import require
from local_patch import cycle
from ownership import ATTRS
from smooth_neck_patch import recipe

def source_faces():
 out=[]
 for j in[7,8]:
  for k in range(24):
   a=j*24+k;b=j*24+(k+1)%24
   out.extend([(a,b,b+24),(a,b+24,a+24)])
 return out

def source_retirement(indices):
 lookup={}
 for i,t in enumerate(indices):lookup.setdefault(cycle(list(map(int,t))),[]).append(i)
 retired=[]
 for f in source_faces():
  hits=lookup.get(cycle(f),[]);require(len(hits)==1,'Actual96sourceface ownership missing/duplicate');retired.append(hits[0])
 require(len(set(retired))==96,'Unique96retirement');return retired

def resolve_palette(model):
 owners=[n for n in model.d['nodes']if n.get('mesh')==0];require(len(owners)==1 and owners[0].get('skin')==0,'Coat reviewed skin0 association')
 joints=model.d['skins'][0]['joints'];names=[model.d['nodes'][i]['name']for i in joints];require(names.count('root')==names.count('head')==1,'Unique actual semantic joints');return names.index('root'),names.index('head'),names

def verify_parent_contract(model,labels):
 v=model.views[0,0];a=v['attributes'];require(v['material']==0 and v['mesh_name']=='skinned_equine_coat','Actual neck materialowner')
 require(len(model.d['meshes'][0]['primitives'])==1,'Coat attribute sharing contract')
 root,head,names=resolve_palette(model)
 for i in range(24):
  require(labels[0,216+i]=='h:'+str(i),'Actual declared neckportalalias')
  require(labels[0,1049+i]=='h:'+str(24+i),'Actual protected headband sourcealias')
 require(all(w['attributes_accessors']['POSITION']!=v['attributes_accessors']['POSITION']for key,w in model.views.items()if key!=(0,0)),'No unrelatedmesh sharing retiredcoatdomain')
 for ids,expected in[(range(144,192),{'root':1.}),(range(216,240),{'root':.5,'head':.5}),(range(1049,1073),{'root':float(np.float32(.2)),'head':float(np.float32(.8))})]:
  for i in ids:
   actual={names[int(j)]:float(w)for j,w in zip(a['JOINTS_0'][i],a['WEIGHTS_0'][i])if w>0};require(actual==expected,'Actual old anchor skinfields')
 require(all(np.isfinite(a[k]).all()for k in ATTRS),'Finite original attrs')
 return root,head,names

def storage_audit(old,new):
 a,b=old.d,new.d;na,nv=len(a['accessors']),len(a['bufferViews']);require(len(b['accessors'])==na+5 and len(b['bufferViews'])==nv+5,'Exactly5appendedstorage records')
 require(b['accessors'][:na]==a['accessors']and b['bufferViews'][:nv]==a['bufferViews'],'Oldaccessor/view metadata changed')
 require(bytes(new.b[:len(old.b)])==bytes(old.b),'OldBINprefix changed')
 prim=b['meshes'][0]['primitives'][0];spec=[('POSITION','VEC3',5126,34962),('NORMAL','VEC3',5126,34962),('JOINTS_0','VEC4',5123,34962),('WEIGHTS_0','VEC4',5126,34962),('indices','SCALAR',5125,34963)];offset=len(old.b)
 for i,(name,typ,comp,target)in enumerate(spec):
  ref=prim['indices']if name=='indices'else prim['attributes'][name];require(ref==na+i,'Orderednewactualaccessor ref');ac=b['accessors'][ref];view=b['bufferViews'][nv+i]
  require(ac['bufferView']==nv+i and ac['componentType']==comp and ac['type']==typ,'Newaccessor type/owner')
  fields={'bufferView','componentType','count','type'}|({'min','max'}if typ in['VEC3','SCALAR']else set());require(set(ac)==fields,'Exact appendedaccessor metadata')
  count=new.views[0,0]['indices'].size if name=='indices'else len(new.views[0,0]['attributes'][name]);width=1 if name=='indices'else(3 if typ=='VEC3'else 4);size=2 if comp==5123 else 4
  require(ac['count']==count and view=={'buffer':0,'byteOffset':offset,'byteLength':count*width*size,'target':target},'Exact appendextent/view')
  arr=new.views[0,0]['indices'].reshape(-1,1)if name=='indices'else new.views[0,0]['attributes'][name]
  if 'min'in ac:require(ac['min']==arr.min(0).tolist()and ac['max']==arr.max(0).tolist(),'Actual minmax')
  offset+=count*width*size;require(offset%4==0,'Appendalignment')
 require(offset==len(new.b)==b['buffers'][0]['byteLength'],'Exact newBINextent')
 import copy
 x,y=copy.deepcopy(a),copy.deepcopy(b)
 for d in[x,y]:
  p=d['meshes'][0]['primitives'][0];p.pop('indices');p.pop('attributes')
  for k in['accessors','bufferViews']:d.pop(k)
  d['buffers'][0].pop('byteLength')
 require(x==y,'Protected rig/clips/materials/otherdocument changed')
 return{'oldBINprefix_exact':True,'original_storage_metadata_exact':True,'protected_document_exact':True}
