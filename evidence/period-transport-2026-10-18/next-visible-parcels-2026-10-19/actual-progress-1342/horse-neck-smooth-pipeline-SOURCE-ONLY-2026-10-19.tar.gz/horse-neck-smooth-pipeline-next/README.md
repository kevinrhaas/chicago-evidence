# Approved smooth neck implementation — source only awaiting independentreview

Scope authorized by root efd1: retire96sourcefaces336..431; oldring8(192..215) inactive inALLcoatfaces; append360positions/joints/weights/normals and768triangles; oldnormalhalo ONLY168..191. ALLoldP/J/W and allotheroldN/head48/ears/portal/rig/clips/indices unchanged. Actualsourcealias/skinpalette resolved and checked, not guessed. Newnormal alignment tolerance1e-6 is a float32engineeringreadback bound only; SAT1e-8/proper/exactcontact rules remainunchanged. Alloldfailurearchives remainfailed anduntouched.

Sourceproducer `smooth_export` uses existingpinned090→26027 parentchain, verifiesactual96sourcefaces andbody/head anchorweights/aliases, then evaluates ONEfixedcubic construction with16segments percolumn. Dyadic canonicalHermitebasis evaluates the mathematically identical approvedBezier without1/3control floatingrounding; w=(12t²−7t³)/10 is equivalent approvedweightformula. No shapeparameter/sweep/search. OldcoatPOSITIONS arebyteexactprefix; oldinactivevertices retained inBIN. Normalarea sums affectonlynew360+old24Bhalo. Allothergeometry/attributes/rig protected.

`smooth_rest` independentlydecodes and checks newP against EXACTRATIONAL Hermite fromoriginalfloat32anchors (no call toproducer/build_proposal), newweights rational/actualpalette, exactretainedindexmaps/new768explicittriangles/360sourcekeys, oldring8inactive, protectedattribute bytes, normalarea alignment andstrict5appendedstorage/document/BINprefix exceptions. SeparateRESTprocess pluslater independentagent review precedesanycapture.

`smooth_chain` pinsactualGLB/proof/manifest/authority/packet+fullhelperinventory, preservesold090/earproducer chain, mapsretainedhead2960 byexactold→newactiveindices, labelsnewvertices byexplicitrow/column. `smooth_scope` sourceownsall768actualnewtriangles, provesoneconnectedannulusEuler0/two24boundaryloops anduniqueoppositesourceedgeowners, thenfullnewpatchinternal+vsALLremaininghorse. Headinternal→headvsALLrest remainfirst; exactedgecertificate stillneeded beforeadjacencyskip, properfirst pointcertificate, no unexpectedrawSAT waived. Existing090all12negatives and26027necknegative retained.

Finiteoperator `run_local_trial` uses90TOTALwall fromfirstentry and30maxperphase, exclusiveouterdir/sourcepins/explicitrecipe beforeworkers. Isolatedexport→metadata→REST→Khronos; checkpointUNVALIDATEDbytes; firstnonzeroSTOP/no retry/repair. Capture/SAT not automatic. Root explicitly authorizes ONEpipeline only after independent source reviewer finds no definiteblockers, then independentactualoutputreview, then separately boundedONE120sidlefullhead+patch check. No63poses/gear/browser/Blender/appinstallation authorized. Packet/capturebuffers binary64 unchanged withexclusiveleaf ownership andcanonicalfilenames.

Ten synthetic tests pass normal and-O: originalcurveconstraints, artificialcylinder derivative/topology, in-memorysyntheticGLB rationalREST, protectedP/N/newPcorruptions, actual768annulus ownership1128internal/48externalregisterededges. No actualhorseanchors were evaluated byproducer, no actualhorsecandidateGLB/export/metadata/capture/SAT hasrun. ArtificialtestGLBs neverreadhorsefiles and remaininmemory. Python/Node syntaxPASS. Copiedlegacyhelpers remainunmodified as provenance; onlysmoothentrypoints apply tothisexplicitnewscope.

Source-only prospectivecommand afterreview/no-blockers authorization:
```
/workspace/shared/chicago-venv/bin/python /workspace/shared/horse-neck-smooth-pipeline-next/run_local_trial.py --release-token ROOT_RELEASE_ONE_SMOOTH_NECK --output-dir /workspace/shared/horse-neck-smooth-first-local-trial
```
Actual3Dembedding/discreteposedcontinuity/gear/anatomy/photographicacceptance remainopen regardlessoflocalpipelinepass.
