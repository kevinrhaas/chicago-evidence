# SPDX-License-Identifier: GPL-3.0-or-later
import unittest,copy,hashlib,tempfile,subprocess,sys,json,shutil
from pathlib import Path
from validate_capture import source_expected,validate,INPUTS
class Validation(unittest.TestCase):
 @classmethod
 def setUpClass(c):
  j,rows=source_expected('candidate');h,_=source_expected('horse');idle=next(a for a in h['animations']if a['name']=='idle');duration=max(h['accessors'][s['input']]['max'][0]for s in idle['samplers']);groups=[];start=0
  for r in rows:g=dict(r,start=start,count=r['indexCount']//3);groups.append(g);start+=g['count']
  c.payload=bytes(start*9*8);c.m={'input':list(INPUTS['candidate']),'precision':'float64_world','pose':{'clip':'idle','phase':0,'time_s':0,'duration_s':duration,'head_binding':'actual_parent_inverse_head_world'},'rows':[{'clip':'idle','phase':0}],'meshes':groups,'triangleCount':start,'buffer_sha256':hashlib.sha256(c.payload).hexdigest()}
 def test_valid_synthetic_metadata(self):validate('candidate',self.m,self.payload)
 def reject(self,mutate):
  m=copy.deepcopy(self.m);mutate(m)
  with self.assertRaises(ValueError):validate('candidate',m,self.payload)
 def test_missing_horse_persists_failure(self):
  with tempfile.TemporaryDirectory()as td:
   d=Path(td);source=Path(__file__).parent
   for n in ['check_idle.py','validate_capture.py','official_fit_predicates.py']:shutil.copyfile(source/n,d/n)
   r=subprocess.run([sys.executable,str(d/'check_idle.py')],capture_output=True,text=True)
   self.assertNotEqual(r.returncode,0);receipt=json.loads((d/'results/actual-idle-results.json').read_text());self.assertFalse(receipt['measurement_complete']);self.assertFalse(receipt['fit_passed']);self.assertEqual(receipt['rows'],[]);self.assertIn('FileNotFoundError',receipt['error'])
 def test_hash(self):self.reject(lambda m:m.update(buffer_sha256='0'*64))
 def test_input(self):self.reject(lambda m:m.update(input=['wrong','0'*64]))
 def test_pose(self):self.reject(lambda m:m['pose'].update(phase=.5))
 def test_precision(self):self.reject(lambda m:m.update(precision='float32_world'))
 def test_missingpart(self):self.reject(lambda m:m['meshes'].pop())
 def test_duplicatepart(self):self.reject(lambda m:m['meshes'][1].update(name=m['meshes'][0]['name']))
 def test_name_primitive_swap(self):
  def change(m):m['meshes'][0]['name'],m['meshes'][1]['name']=m['meshes'][1]['name'],m['meshes'][0]['name']
  self.reject(change)
 def test_emptycount(self):self.reject(lambda m:m['meshes'][0].update(count=0))
 def test_gap(self):self.reject(lambda m:m['meshes'][1].update(start=999))
 def test_indexstream(self):self.reject(lambda m:m['meshes'][0].update(indexStreamSHA256='0'*64))
 def test_duration(self):self.reject(lambda m:m['pose'].update(duration_s=999))
 def test_booleanphase(self):self.reject(lambda m:m['pose'].update(phase=False))
if __name__=='__main__':unittest.main()
