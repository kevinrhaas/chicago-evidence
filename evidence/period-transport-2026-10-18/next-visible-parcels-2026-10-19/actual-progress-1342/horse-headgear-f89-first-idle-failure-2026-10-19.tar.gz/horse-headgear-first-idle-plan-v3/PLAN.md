# v3 final source correction — actual trial NOT RUN

Preserves v2 and f89candidate. Coverage Counter now binds(sourceassetname,*primitive/indexFIELDS); capture gets canonical assetname from actualGLTFLoader parser association, preserving runtimeName separately. This avoids guessing runtime suffixes for090two-materialmane/tail. Swappedvalidpartnames now rejected even if36names/counts individuallyvalid. Source expectednames from actualpinnedGLBmesh metadata, not capturedeclaration.

Horseload/validation andlo/hi creation moved intoownedtry after rowsinitialized; failure writes measurement_completefalse,fit_passedfalse,error,emptyrows rather than leavingemptyresults. Actualisolatedmissingcapture regression verifies persistedfailure withoutloadinggeometry/runningfit.14tests PASSnormal andpython-O, plusJSsyntax check.

Float64worldvalues, actualinputGLBhashes/idle0/duration/bufferhash/count/indexstream validation, exclusivefreshcapture/results, unchangedSAT/proper guards andcandidate EXIT2 oncontacts remain. Historicalfloat32262/258 labeleddiagnostic, noforcedfloat64counts. No independentframematrixhash claimed: capture declares actualbindingmethod/pose and actualThree calculation; storedworldarrays andsourcehashes are not independentframeproof.

Await rootreview/release before commands:
node --experimental-loader ./three-loader.mjs ./capture_idle.mjs
python ./check_idle.py

Noactualcapture/fit/browser/app/CI/modelgeneration. Oldv2 untouched. v2-to-v3.patch andSOURCE-HASHES bind finalsource.14tests include onlysyntheticmetadata andmissingfilefailure path, not geometricacceptance.
