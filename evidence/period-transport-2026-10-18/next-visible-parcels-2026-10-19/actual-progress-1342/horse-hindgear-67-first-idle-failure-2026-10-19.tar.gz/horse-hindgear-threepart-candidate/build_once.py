# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import json,hashlib,subprocess,sys
P=Path(__file__).parent
PINS={'/workspace/shared/horse-headgear-first-idle-plan-v3/capture/horse.json': '0ce987c24d4d71dd874feda8ff5cd1cbcf6d0717a7cb6473b15dbc79527ac3b0', '/workspace/shared/horse-headgear-first-idle-plan-v3/capture/horse.f64': 'c853a0dacebab450db4267a458c3493aff224920396c1db48ac4e7215a805be8', '/workspace/shared/horse-headgear-exact078-rebase/generate_harness.contour.py': '8b1e6c22e99d6fc57d08f012d6abf9bdf2a239d775353ec63f2e4e17aacf6c9b', '/workspace/shared/horse-headgear-exact078-rebase/parameters.contour.json': '75ae6ef221aaadb5342122d43abf41c3ed3a2d0568241b76a06725a9988801c9'}
for pin,sha in PINS.items():
 if hashlib.sha256(Path(pin).read_bytes()).hexdigest()!=sha:raise SystemExit('REFUSE pinned source/capture changed '+pin)
if (P/'candidate-one').exists():raise SystemExit('REFUSE existing candidate')
for name,sha in json.loads((P/'SOURCE-HASHES.json').read_text()).items():
 if hashlib.sha256((P/name).read_bytes()).hexdigest()!=sha:raise SystemExit('REFUSE changed source '+name)
subprocess.run([sys.executable,str(P/'source/generate_harness.py'),'--parameters',str(P/'source/parameters.json'),'--output-dir',str(P/'candidate-one')],check=True)
subprocess.run([sys.executable,str(P/'check_candidate.py')],check=True)
