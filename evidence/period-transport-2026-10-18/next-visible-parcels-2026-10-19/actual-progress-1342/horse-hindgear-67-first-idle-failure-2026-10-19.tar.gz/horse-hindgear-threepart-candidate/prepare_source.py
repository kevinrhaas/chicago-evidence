# SPDX-License-Identifier: CC0-1.0
"""Original source-only threepart contour preparation against pinned actual idle world skin."""
from pathlib import Path
import json,hashlib,math,difflib
import numpy as np
PINS={'/workspace/shared/horse-headgear-first-idle-plan-v3/capture/horse.json': '0ce987c24d4d71dd874feda8ff5cd1cbcf6d0717a7cb6473b15dbc79527ac3b0', '/workspace/shared/horse-headgear-first-idle-plan-v3/capture/horse.f64': 'c853a0dacebab450db4267a458c3493aff224920396c1db48ac4e7215a805be8', '/workspace/shared/horse-headgear-exact078-rebase/generate_harness.contour.py': '8b1e6c22e99d6fc57d08f012d6abf9bdf2a239d775353ec63f2e4e17aacf6c9b', '/workspace/shared/horse-headgear-exact078-rebase/parameters.contour.json': '75ae6ef221aaadb5342122d43abf41c3ed3a2d0568241b76a06725a9988801c9'}
for pin,sha in PINS.items():
 if hashlib.sha256(Path(pin).read_bytes()).hexdigest()!=sha:raise ValueError('Independent pinned source/capture mismatch '+pin)
P=Path(__file__).parent;R=Path('/workspace/shared/horse-headgear-exact078-rebase');C=Path('/workspace/shared/horse-headgear-first-idle-plan-v3/capture');m=json.loads((C/'horse.json').read_text());payload=(C/'horse.f64').read_bytes()
if hashlib.sha256(payload).hexdigest()!=m['buffer_sha256']:raise ValueError('horse actual buffer hash')
if m['input'][1]!='090be8fdc2516ee5b5c8f886026f441850cc208f17b6ede71fed9007ab80f12f':raise ValueError('wrong horse')
a=np.frombuffer(payload,dtype='<f8').reshape(m['triangleCount'],3,3);g=next(g for g in m['meshes']if g['name']=='skinned_equine_coat');tri=a[g['start']:g['start']+g['count']];e1=tri[:,1]-tri[:,0];e2=tri[:,2]-tri[:,0]
def ray(o,d):
 o=np.asarray(o,float);d=np.asarray(d,float);d/=np.linalg.norm(d);pv=np.cross(d,e2);det=(e1*pv).sum(1);inv=np.divide(1,det,out=np.zeros_like(det),where=np.abs(det)>1e-12);tv=o-tri[:,0];u=(tv*pv).sum(1)*inv;q=np.cross(tv,e1);v=q@d*inv;t=(e2*q).sum(1)*inv;ids=np.flatnonzero((abs(det)>1e-12)&(u>=-1e-10)&(v>=-1e-10)&(u+v<=1+1e-10)&(t>0))
 if not len(ids):raise ValueError('ray misses actual coat '+str((o.tolist(),d.tolist())))
 i=int(ids[np.argmax(t[ids])]);return float(t[i]),int(g['start']+i)
def dense(points,n):
 out=[]
 for a,b in zip(points,points[1:]):
  for j in range(n):out.append((np.array(a)*(1-j/n)+np.array(b)*(j/n)).tolist())
 return out+[points[-1]]
# Ordered full rear route; preserve the two forward ends as specified.
guide=[[.30,1.10,-.34],[.32,1.09,-.61],[.28,1.075,-.81],[.15,1.06,-.89],[0,1.06,-.91],[-.15,1.06,-.89],[-.28,1.075,-.81],[-.32,1.09,-.61],[-.30,1.10,-.34]]
pts=[];witness=[]
for i,p in enumerate(dense(guide,12)):
 d=np.array([p[0],0,p[2]+.4]);d/=np.linalg.norm(d);radius=[]
 for dy in [-.026,0,.026]:
  t,face=ray([0,p[1]+dy,-.4],d);radius.append(t);witness.append({'part':'breeching','sample':i,'width_y_m':dy,'source_horse_triangle':face})
 offset=.018 if abs(p[0])>.1 else .03;c=np.array([0,p[1],-.4])+d*(max(radius)+offset)
 if i in [0,96]:c=np.array(guide[0 if i==0 else -1])
 pts.append(c.tolist())
if len(pts)!=97:raise ValueError('unexpected route count')
# Pick actual band samples near Z-.66 as explicit lower support junctions.
junctions={};routes={}
for sign,label in [(1,'l'),(-1,'r')]:
 index=min([i for i,x in enumerate(pts)if sign*x[0]>.1],key=lambda i:abs(pts[i][2]+.66));lower=pts[index];junctions[label]={'breeching_sample':index,'position_m':lower}
 guide=[lower,[sign*.34,1.25,-.64],[sign*.27,1.39,-.60],[sign*.13,1.50,-.54],[0,1.525,-.48]];route=[]
 for i,q in enumerate(dense(guide[:3],10)):
  values=[]
  for dz in [-.0115,0,.0115]:
   t,face=ray([0,q[1],q[2]+dz],[sign,0,0]);values.append(t);witness.append({'part':'hip_support_'+label,'sample':i,'width_z_m':dz,'source_horse_triangle':face})
  route.append([sign*(max(values)+.014),q[1],q[2]])
 route[0]=lower;route.extend(dense(guide[2:],10)[1:]);routes[label]=route
old=json.loads((R/'parameters.contour.json').read_text());old['hindgear_contour_study']={'grade':'reconstructed_engineering','horse_sha256':m['input'][1],'breeching_route_m':pts,'hip_support_routes_m':routes,'lower_junctions':junctions,'widths_m':{'breeching':.052,'hip_support':.023},'thickness_m':{'breeching':.007,'hip_support':.004},'source':'Actual binary64 idle0 coat triangle ray-envelope; tail not excluded from subsequent fit'}
(P/'source/parameters.json').write_text(json.dumps(old,indent=2)+'\n');s=(R/'generate_harness.contour.py').read_text();lines=[]
for line in s.splitlines():
 if line.startswith("strap('breeching',"):line="strap('breeching',p['hindgear_contour_study']['breeching_route_m'],.052,.007,width_axis=(0,1,0))"
 elif line.startswith(" strap('hip_support_'+side,"):line=" strap('hip_support_'+side,p['hindgear_contour_study']['hip_support_routes_m'][side],.023,.004,width_axis=(0,0,1))"
 lines.append(line)
s='\n'.join(lines)+'\n';oldline="nm='socket_harness_'+role+'_'+side;node(nm,translation=v,extras={'role':role,'fit':'unpassed'});anchors[nm]={'translation_m':v,'rotation_xyzw':[0,0,0,1],'horse_socket':('socket_equine_'+role+'_'+side) if role in ['trace','breeching','shaft'] else None}"
newline="if role=='breeching':v=p['hindgear_contour_study']['lower_junctions'][side]['position_m']\n  "+oldline
if oldline not in s:raise ValueError('socket source mismatch')
s=s.replace(oldline,newline);(P/'source/generate_harness.py').write_text(s);compile(s,'generator','exec')
(P/'source/generator.patch').write_text(''.join(difflib.unified_diff((R/'generate_harness.contour.py').read_text().splitlines(True),s.splitlines(True),fromfile='f89/generate_harness.py',tofile='hindgear/generate_harness.py')));(P/'route-witnesses.json').write_text(json.dumps(witness,indent=2)+'\n');(P/'source-inputs.json').write_text(json.dumps({'horse_capture_metadata_sha256':hashlib.sha256((C/'horse.json').read_bytes()).hexdigest(),'horse_capture_buffer_sha256':m['buffer_sha256'],'f89_generator_sha256':hashlib.sha256((R/'generate_harness.contour.py').read_bytes()).hexdigest(),'f89_parameters_sha256':hashlib.sha256((R/'parameters.contour.json').read_bytes()).hexdigest()},indent=2)+'\n');print('Source prepared only; no candidate generation',junctions)
