# ONE hindgearcandidate — restcontractPASS, actualidlefitFAIL

Independent carriage_model source review completed beforegeneration; requestedbaselinehash/unique36/indexedprimitive/capturepin guards added and rereviewed. AuthorizedONE30secondcandidate build+restvalidator completedabout0.07seconds. Candidate67e86c3adb738b2f42872ff7068a8645f1042cb1174f0a4fa0d3087746551ea2.

RestcontractPASS: ALL33protectedpartattributes+primitive metadata, materials,hierarchy,bindings,provenance exactf89. Onlybreeching+hip_support_l/rgeometry changed. Twoauthorizedbreechinglowerjunctionsockets changed explicitly from±(.28,1.10,-.70)toapproximately±(.329738731,1.0875,-.656073696); old/new/reason inreceipt. Allotheranchors exact. Actualwidth/thickness readback52/23mm and7/4mm maxerrors<.000104mm; upper2hipanchors andnewlowerjoins exact inparameter/sourcecontract. No horsechange.

Then authorizedONE100secondtotal binary64idle0 actualThree capture→strictall36/allhorsetest executed, checker8.328seconds, EXIT2. measurement_complete=true,fit_passed=false,error=null. Pinnedhorse090,originalbaseline078,newcandidate67. Originalbaseline fiveheadstraps262raw/258proper still genuine negative.

Newcandidate104rawSAT/104propercrossings:

| Part | f89firstidleproper | new67proper |
|---|---:|---:|
|bit_bar|44|44|
|breeching|88|12|
|hip_support_l|10|24|
|hip_support_r|10|24|

Breeching improved butstillfails; bothhipsupports WORSENED. Threepartsubtotal108→60 is not a fitpass. Bit44 remainsunwaived sealedmouthinterfacefailure. Fiveheadstraps andfourpreviouslyqualifiedbodyparts stillzeroSAT/properONLYthisidle0. Otherpartzero results do not establishpositiveclearance,volumecontainment,pressure,continuousmotion or63posequalification.

The source-ray envelope hypothesis did not predict fullstripembedding; source/restcontract cannot substitute for actualfit. No automaticadjustment/retry wasrun. Actualallpartwitnesses,Float64captures,inputs/sourcehashes,stdoutstderr retained inidle-fit androot logs. Allpriorfailedcandidates/results/archives unchanged. No browser,63poses,app/ticket/CIwrite,sourceintegration orproductionacceptance. STOP pendingrootreviewofactualremainingwitnesses.
