# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json,struct,tarfile
P=Path(__file__).parent;old=Path('/workspace/shared/horse-headgear-exact078-rebase/candidate-one');new=P/'candidate-one';changed={'breeching','hip_support_l','hip_support_r'};name='light_breastcollar_harness_reconstructed_01.glb'
def load(p):
 b=p.read_bytes();n,t=struct.unpack_from('<II',b,12);j=json.loads(b[20:20+n]);off=20+n;size,typ=struct.unpack_from('<II',b,off);return j,b[off+8:off+8+size]
def meshdata(j,b,m):
 result=[]
 for pr in m['primitives']:
  attrs={}
  for key,aid in pr['attributes'].items():
   a=j['accessors'][aid];bv=j['bufferViews'][a['bufferView']];offset=bv.get('byteOffset',0)+a.get('byteOffset',0);size=a['count']*{'VEC3':3,'VEC2':2,'SCALAR':1}[a['type']]*4
   attrs[key]={'type':a['type'],'componentType':a['componentType'],'count':a['count'],'sha256':hashlib.sha256(b[offset:offset+size]).hexdigest()}
  result.append({'attributes':attrs,'material':pr.get('material'),'mode':pr.get('mode',4)})
 return result
if hashlib.sha256((old/name).read_bytes()).hexdigest()!='f89df20ba159114492bf6c2d8e24c894c5b617204fc78ba25c99d06be0890137':raise ValueError('wrong pinned f89baseline')
j,b=load(old/name);k,c=load(new/name);
for doc in [j,k]:
 names=[m['name']for m in doc['meshes']]
 if len(names)!=36 or len(set(names))!=36:raise ValueError('Expected36unique meshes')
 for mesh in doc['meshes']:
  for primitive in mesh['primitives']:
   if 'indices'in primitive:raise ValueError('Unexpected indexed primitive; expanded baseline/candidate required')
a={m['name']:meshdata(j,b,m)for m in j['meshes']};z={m['name']:meshdata(k,c,m)for m in k['meshes']};fail=[];rows=[]
if set(a)!=set(z):fail.append('mesh names differ')
for n in sorted(set(a)&set(z)):
 equal=a[n]==z[n];rows.append({'mesh':n,'protected':n not in changed,'decoded_attributes_and_primitive_metadata_exact':equal})
 if n not in changed and not equal:fail.append('protected mesh '+n)
 if n in changed and equal:fail.append('expected changed geometry '+n)
def nodes(j):
 result=[]
 for n in j['nodes']:
  n=dict(n)
  if n['name']in changed:n.pop('extras',None)
  result.append(n)
 return result
params=json.loads((P/'source/parameters.json').read_text());junctions=params['hindgear_contour_study']['lower_junctions'];anchor_changes=[]
def require(ok,msg):
 if not ok:raise ValueError(msg)
for side in ['l','r']:
 n='socket_harness_breeching_'+side;oldnode=next(x for x in j['nodes']if x['name']==n);newnode=next(x for x in k['nodes']if x['name']==n);target=junctions[side]['position_m'];anchor_changes.append({'name':n,'old':oldnode['translation'],'new':newnode['translation'],'reason':'Reconstructed lower support joins source-conforming breeching sample'});require(newnode['translation']==target,'new socket not source junction');oldnode['translation']=target
checks={'materials_exact':j['materials']==k['materials'],'node_hierarchy_transforms_anchors_and_protected_extras_exact':nodes(j)==nodes(k),'root_source_license_provenance_exact':j['nodes'][0]==k['nodes'][0]}
x=json.loads((old/'manifest.json').read_text());y=json.loads((new/'manifest.json').read_text())
for side in ['l','r']:x['anchors']['socket_harness_breeching_'+side]['translation_m']=junctions[side]['position_m']
for field in ['source','license','grade','frame','bindings','anchors','head_relative_components','dynamic_components_unbound','missing','shaft_tugs']:
 checks['manifest_'+field+'_exact']=x.get(field)==y.get(field)
fail.extend(n for n,v in checks.items()if not v)
receipt={'PASS':not fail,'failures':fail,'baseline_sha256':hashlib.sha256((old/name).read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256((new/name).read_bytes()).hexdigest(),'protected_parts':33,'disclosed_anchor_changes':anchor_changes,'changed_parts':sorted(changed),'meshes':rows,'checks':checks,'scope':'actual decoded rest geometry+metadata comparison only; no SAT/clearance/pose/browser/visual/period acceptance'}

import math
widths=[]
for part,w,t,route in [('breeching',.052,.007,params['hindgear_contour_study']['breeching_route_m'])]+[('hip_support_'+side,.023,.004,params['hindgear_contour_study']['hip_support_routes_m'][side])for side in ['l','r']]:
 mesh=next(m for m in k['meshes']if m['name']==part);a=k['accessors'][mesh['primitives'][0]['attributes']['POSITION']];bv=k['bufferViews'][a['bufferView']];off=bv.get('byteOffset',0)+a.get('byteOffset',0);vs=[struct.unpack_from('<fff',c,off+12*i)for i in range(a['count'])];wm=tm=cm=0
 for i,center in enumerate(route[:-1]):
  q=vs[i*24:];corners=[q[n]for n in [0,1,7,13]];wm=max(wm,abs(math.dist(corners[0],corners[1])-w));tm=max(tm,abs(math.dist(corners[1],corners[2])-t));cm=max(cm,math.dist([sum(v[d]for v in corners)/4 for d in range(3)],center))
 require(wm<3e-7 and tm<3e-7 and cm<3e-7,'actual rectangle dimensions/center mismatch '+part);widths.append({'part':part,'max_width_error_m':wm,'max_thickness_error_m':tm,'max_section_center_error_m':cm})
for side in ['l','r']:
 route=params['hindgear_contour_study']['hip_support_routes_m'][side];require(route[0]==junctions[side]['position_m'],'lower join');require(route[-1]==[0,1.525,-.48]and route[-11]==[.13 if side=='l'else-.13,1.50,-.54],'upper anchors')
receipt['actual_width_thickness_section_readback']=widths;receipt['lower_join_and_upper_anchors_exact']=True
(P/'candidate-rest-contract.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items()if k!='meshes'}))
if fail:raise SystemExit(1)
