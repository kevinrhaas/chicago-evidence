# SPDX-License-Identifier: CC0-1.0
"""Stored evidence/hash audit only. No fit imports, geometry evaluation or SAT."""
from pathlib import Path
import json,hashlib,struct,collections,time
P=Path('/workspace/shared/horse-ab70-3bb45-motion-next');S=P/'runs/full63';A=Path('/workspace/shared/horse-ab70-3bb45-full63-completed-chunks');OUT=Path(__file__).parent;started=time.monotonic()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def js(p):return json.loads(Path(p).read_text())
def need(v,msg):
 if not v:raise ValueError(msg)
r={'passed':False,'scope':'Independent stored63pose source/input/artifact/child-result/archive hash audit only; no model, capture, SAT or fit rerun','mismatches':[],'poses':[],'artifact_hashes_checked':0}
try:
 d=js(S/'RESULT.json');need(d['PASS']is True,'terminalPASS');r['authoritative_terminal_elapsed_s']=d['elapsed_s'];r['terminal_RESULT_sha256']=sha(S/'RESULT.json');r['source_inventory_sha256']=sha(P/'SOURCE-HASHES.json');need(r['source_inventory_sha256']==d['source_inventory_sha256']=='a3ace1a9ec8cd02b889d6811ff4406d02f995bb6480e0d70b6e41fac129cb823','sourceinventory')
 for name in ['SOURCE-HASHES.json','EXTERNAL-HASHES.json']:
  pins=js(P/name);r[name+'_count']=len(pins)
  for f,h in pins.items():need(sha(P/f if name=='SOURCE-HASHES.json'else f)==h,'pin:'+f)
 inputpaths={k:(f,h)for k,(f,h)in js(P/'runs/quarter8/RESULT.json')['completed_poses'][0]['pose']['input_sha256'].items()}if False else {'horse':('/workspace/shared/horse-combined-oral-neck-mane-prefix-next/candidate-one/candidate.glb','ab70aff958bc8a2780458d37212be1866c730817f485fbebbf53bd3c0e3931c3'),'baseline':('/workspace/shared/horse-v2-cap-registered-next/build1/light_breastcollar_harness_reconstructed_01.glb','078ed2cebc01dba52d28f2ae737f170f0fe28fd20523aed9bb8869f4cd7b35bd'),'candidate':('/workspace/shared/horse-breeching-swept-route-next/candidate-one/light_breastcollar_harness_reconstructed_01.glb','3bb45abfad635bda74fd2aa999dcf869269e5efad1c888dfb4d615f7b0667825')}
 for k,(f,h)in inputpaths.items():need(sha(f)==h and d['input_sha256'][k]==h,'input:'+k)
 raw=Path(inputpaths['horse'][0]).read_bytes();n=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+n]);binary=raw[28+n:];clips={}
 for a in doc['animations']:
  times=[]
  for sampler in a['samplers']:
   ac=doc['accessors'][sampler['input']];v=doc['bufferViews'][ac['bufferView']];need(ac['componentType']==5126 and ac['type']=='SCALAR'and'sparse'not in ac and'byteStride'not in v,'plaincliptimes');off=v.get('byteOffset',0)+ac.get('byteOffset',0);times.extend(struct.unpack_from('<'+'f'*ac['count'],binary,off))
  clips[a['name']]={'duration_s':max(times),'source_time_sha256':hashlib.sha256(struct.pack('<'+'d'*len(times),*times)).hexdigest()};need(min(times)==0,'zeroorigin')
 expected=[(c,k/20)for c in ['idle','walk','trot']for k in range(21)];need(len(d['completed_poses'])==63 and [(x['pose']['clip'],x['pose']['phase'])for x in d['completed_poses']]==expected,'exact63orderedgrid');need(all(x['PASS']is True for x in d['completed_poses']),'allrowsPASS')
 raw=Path(inputpaths['candidate'][0]).read_bytes();n=struct.unpack_from('<I',raw,12)[0];gd=json.loads(raw[20:20+n]);names={m['name']for m in gd['meshes']};need(len(names)==36,'36actualnames')
 ctl=js(S/'controls/RESULT.json');base=ctl['controls']['baseline'];ear=ctl['controls']['ear_parent']['matched_actual_source_owned_necknegative'];need(ctl['PASS']is True and base['complete']is True and base['expected_count']==base['detected_strict_known_count']==12 and base['missing_signatures']==base['duplicate_known_signatures']==base['duplicate_actual_pairs']==[] and {tuple(x)for x in base['expected_signatures']}=={tuple(x)for x in base['detected_signatures']}and len({tuple(x)for x in base['detected_signatures']})==12,'original09012negative');need(ear['kind']=='unexpected_strict_proper'and min(ear['proper_witness']['face_barycentric'])>0 and min(ear['proper_witness']['edge_signed_distances_m'])<0<max(ear['proper_witness']['edge_signed_distances_m']),'original260negative');r['original_negative_controls']={'090_detected_distinct':12,'260_strict_source_pair':[ear['a_global'],ear['b_global']]}
 for row in d['completed_poses']:
  p=row['pose'];idx=p['index'];need(type(idx)is int and idx==len(r['poses']),'index');need(p['stage']=='full63'and p['loop']=='LoopOnce_clamp'and p['input_sha256']==d['input_sha256']and p['duration_s']==clips[p['clip']]['duration_s']and p['time_s']==p['phase']*p['duration_s']and p['source_time_sha256']==clips[p['clip']]['source_time_sha256'],'actualdecodedclipplan')
  pd=S/f"pose-{idx:02d}-{p['clip']}"
  for f,h in row['artifact_hashes'].items():need(not Path(f).is_absolute()and'..'not in Path(f).parts and sha(pd/f)==h,'artifact:'+str(pd/f));r['artifact_hashes_checked']+=1
  st=js(pd/'idle-fit/structural-results/RESULT.json');g=js(pd/'idle-fit/results/actual-idle-results.json');b=js(pd/'idle-fit/actual-bit-volume-result.json');need(st['PASS']is True and st['pose']==g['pose']==b['pose']==p and st['candidate_sha256']==inputpaths['horse'][1]and g['measurement_complete']is True and g['fit_passed']is True and b['PASS']is True,'childlinks')
  scopes=[]
  for f in sorted((pd/'idle-fit/structural-results').glob('*-head_*.json')):
   v=js(f);count={'fullhead3122':3122,'head3122':3122,'hybrid1492':1492,'fittedmane456':456}.get(v['label']);need(count is not None and v['complete']is True and v['completed_head_triangle_prefix']==count and v['counts']['unexpected_SAT']==v['counts']['strict_proper']==0 and v['SAT_epsilon_unchanged']==1e-8 and not v['unexpected_witnesses'],'fullscope');scopes.append((v['label'],v['scope']))
  need(len(scopes)==6 and len(set(scopes))==6,'sixscopecoverage');cg=[v for v in g['rows']if v['label']=='candidate'];ng=[v for v in g['rows']if v['label']=='baseline'];need(len(cg)==len(ng)==1 and set(cg[0]['parts'])==names and all(type(v['raw_SAT_pairs'])is int and v['raw_SAT_pairs']==0 and type(v['proper_crossings'])is int and v['proper_crossings']==0 for v in cg[0]['parts'].values())and ng[0]['proper_crossings']>0 and ng[0]['raw_SAT_pairs']>0,'36zero+078negative');need(b['actual_bit_full_side_minimum_unsigned_m']>0 and b['virtual_bit_endcaps']['triangles']==16 and b['virtual_bit_endcaps']['minimum_to_head_m']>0,'bitbound')
  r['poses'].append({'index':idx,'clip':p['clip'],'phase':p['phase'],'time_s':p['time_s'],'all6_structural_scopes_complete_zero':True,'all36gear_parts_zero':True,'078_negative_proper':ng[0]['proper_crossings'],'bit_side_minimum_m':b['actual_bit_full_side_minimum_unsigned_m'],'bit_analysis_cap_minimum_m':b['virtual_bit_endcaps']['minimum_to_head_m'],'artifact_count':len(row['artifact_hashes'])})
 index=js(A/'INDEX.json');need(index['full63_PASS']is True and index['completed_poses']==63 and index['error']is None and index['terminal_stage_result_sha256']==r['terminal_RESULT_sha256'],'terminalarchiveindex');need(len(index['chunks'])==9 and [i for c in index['chunks']for i in c['completed_indices']]==list(range(63))and all(c['pose_count']==7 and c['first_failure']is None for c in index['chunks']),'nonoverlap9x7chunks');r['archive_INDEX_sha256']=sha(A/'INDEX.json');r['archives']=[]
 for rec in [index['source_archive'],*index['chunks'],index['terminal_archive']]:
  f=Path(rec['file']);need(f.parent==A and f.stat().st_size==rec['bytes']<=40*1024**2 and sha(f)==rec['sha256'],'archive:'+str(f));r['archives'].append({k:rec[k]for k in ['file','sha256','bytes']})
 r['clip_counts']=dict(collections.Counter(p['clip']for p in r['poses']));r['distinct_clip_times']=len({(p['clip'],p['time_s'])for p in r['poses']});need(r['distinct_clip_times']==63,'63cliptimes');r['passed']=True;r['qualification_boundary']='Exact ab70/3bb45 pair at63discreteidle/walk/trot samples only. Endpoint geometry duplicates legitimate. Not continuousmotion, hoofgrounding, pressure, pulling/hitch/rider/boarding/photo/production acceptance. INDEXobserved_elapsed_s may retain priorinflight reading; authoritativefinalelapsed is hashedterminalRESULT.'
except BaseException as e:r['error']=repr(e);raise
finally:
 r['audit_elapsed_s']=time.monotonic()-started;(OUT/'review.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r[k]for k in ['passed','artifact_hashes_checked','clip_counts','distinct_clip_times','authoritative_terminal_elapsed_s','audit_elapsed_s']}))
