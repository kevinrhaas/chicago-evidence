# Source review changes BEFORE any build

1. Reviewer caught `all_faces_interpart_checked:true` emitted before an actual check. It now says `all_faces_interpart_check_required:true`, never a factual pass.
2. Author caught an overly conservative max-flank radial crown that could lift the seat. Crown now uses central actual body ray plus shared support stack; bow/canopy independently upper-bound local support radius. Hanging quarter offset tapers only AFTER every panel/bar/bow angular owner ends. This is one geometric-authority correction before evaluation, not an actual candidate parameter search.
3. Complete stationary scope is55 changed/changed plus198 changed/fixed unordered pairs, with every triangle/cap and zero exemptions, followed by changed/ALL horse. Closed connected shells also require disjoint-solid winding classification; SAT alone cannot certify nesting.

Original b870 actual intersection receipt stays unchanged. Source was never evaluated or built before or after this source review. Final source hashes supersede the initial draft pins, not its actual-model proof (none exists).

4. Reviewer correctly rejected Euler2 alone as embedded-solid evidence. Added `check_self.py`: every pair within each actual new closed shell; only exact source-owned edge/vertex intersection certificates accepted, no adjacency skip. `check_layers.mjs` now requires the complete actual eleven-shell self-proof bound to the SAME candidate and capture before any nesting inference. This is prepared source, not a performed self scan.
