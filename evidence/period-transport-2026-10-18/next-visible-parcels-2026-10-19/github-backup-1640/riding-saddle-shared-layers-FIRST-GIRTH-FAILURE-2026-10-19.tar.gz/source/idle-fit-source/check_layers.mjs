// SPDX-License-Identifier: GPL-3.0-or-later
// SOURCE ONLY: all eleven changed parts vs each other and every fixed part.
// No bearing/seam/panel/jamb exclusions. Touch is failure under original SAT.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
import * as T from 'three';import {makeSAT} from './sat.js';
const [capture,out,expectedSHA,selfReceiptPath]=process.argv.slice(2);
if(!out||!selfReceiptPath||! /^[a-f0-9]{64}$/.test(expectedSHA||''))throw Error('Explicit input/fresh output/reviewed SHA required');
fs.mkdirSync(out);const receipt={passed:false,scope:'Actual idle0; eleven changed parts vs all eleven and eighteen fixed, and all eleven vs ALL retained horse. No exemptions. Surface SAT/touch plus closed-component nesting; no pressure or motion acceptance',pairs:[]};
const save=()=>fs.writeFileSync(path.join(out,'fit.json'),JSON.stringify(receipt,null,2));const need=(q,s)=>{if(!q)throw Error(s);};const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
try {
 need(sha(fs.readFileSync(new URL('./sat.js',import.meta.url)))==='ed193ed09a9f4177171eab7552a68cd0b1f211fce9a43c3438b830ce0d287a67','Unchanged predicate');
 const raw=fs.readFileSync(path.join(capture,'capture.json')),m=JSON.parse(raw);receipt.capture_metadata_sha256=sha(raw);
 need(m.passed&&m.actualPose.clip==='idle'&&m.actualPose.action_time_s===0&&m.actualPose.mixer_time_s===0,'Actual idle0');
 const pins={horse:'6e9b37b755ae3eda7b5cf2f492d1781b0e507664a99c88a2e6dee086f77c2296',baseline:'a457874a81b624f5e9642d3296b1350eb49b17d21d38099fbe66080711c17021',candidate:expectedSHA};
 for(const k of Object.keys(pins))need(m.inputs[k].sha256===pins[k]&&sha(fs.readFileSync(m.inputs[k].path))===pins[k],'Actual SHA '+k);
 need(m.baseline_head_bind_matrix_error<=1e-10&&m.candidate_head_bind_matrix_error<=1e-10,'Parent inverse binding');receipt.input_sha256=pins;
 const changed=new Set(['panel_l','panel_r','tree_sidebar_l','tree_sidebar_r','front_bow','rear_bow','seat_jockey','jockey_l','jockey_r','quarter_l','quarter_r']);
 const selfRaw=fs.readFileSync(selfReceiptPath),self=JSON.parse(selfRaw);need(self.passed===true&&self.candidate_sha256===expectedSHA&&self.capture_metadata_sha256===sha(raw)&&Object.keys(self.parts).length===29,'Bound actual all29 self-classification receipt');receipt.self_intersection_receipt_sha256=sha(selfRaw);
 const actualParts=m.parts.candidate_all.parts;need(actualParts.length===29&&new Set(actualParts.map(p=>p.name)).size===29&&actualParts.every(p=>Object.hasOwn(self.parts,p.name)&&self.parts[p.name].complete===true&&self.parts[p.name].faces===p.face_count&&self.parts[p.name].unexpected.length===0),'Exact actual part names/counts and strict completed bools');need([...changed].every(n=>self.parts[n]?.closed===true&&self.parts[n]?.embedded_closed_solid===true),'All exact11 changed shells embedded proof');
 function load(k){
  const meta=m.parts[k],b=fs.readFileSync(path.join(capture,k+'.f64'));need(sha(b)===meta.sha256&&b.length===meta.bytes&&b.length===meta.triangles*72,'Bound actual Float64 '+k);
  const parts=[];let cursor=0;for(const p of meta.parts){need(p.face_start===cursor&&p.face_count>0,'Contiguous nonempty actual part');cursor+=p.face_count;const triangles=[];
   for(let j=p.face_start;j<cursor;j++){const points=[0,1,2].map(v=>new T.Vector3(...[0,1,2].map(q=>b.readDoubleLE(j*72+v*24+q*8))));need(points.every(x=>x.toArray().every(Number.isFinite)),'Finite actual positions');const tri=new T.Triangle(...points);need(tri.getArea()>1e-12,'Nondegenerate actual face');triangles.push({tri,box:new T.Box3().setFromPoints(points),face:j-p.face_start});}
   parts.push({name:p.name,triangles,box:new T.Box3().setFromPoints(triangles.flatMap(x=>[x.tri.a,x.tri.b,x.tri.c]))});
  }need(cursor===meta.triangles,'No missing active faces');return parts;
 }
 const gear=load('candidate_all'),horse=load('horse');need(gear.length===29&&new Set(gear.map(x=>x.name)).size===29&&[...changed].every(n=>gear.some(x=>x.name===n)),'Actual full29 cohort');need(m.parts.horse.triangles===14172,'All retained active horse');
 function closure(part){
  const ids=new Map(),points=[],edges=new Map(),adj=[];const id=v=>{const key=JSON.stringify(v.toArray());if(!ids.has(key)){ids.set(key,points.length);points.push(v);adj.push(new Set());}return ids.get(key);};
  for(const row of part.triangles){const f=[row.tri.a,row.tri.b,row.tri.c].map(id);for(let i=0;i<3;i++){const a=f[i],b=f[(i+1)%3],key=[Math.min(a,b),Math.max(a,b)].join('/');if(!edges.has(key))edges.set(key,[]);edges.get(key).push([a,b]);adj[a].add(b);adj[b].add(a);}}
  const closed=[...edges.values()].every(e=>e.length===2&&e[0][0]===e[1][1]&&e[0][1]===e[1][0]);const seen=new Set(),representatives=[];
  for(let i=0;i<points.length;i++)if(!seen.has(i)){representatives.push(points[i]);const todo=[i];while(todo.length){const j=todo.pop();if(seen.has(j))continue;seen.add(j);for(const k of adj[j])if(!seen.has(k))todo.push(k);}}
  return {closed,representatives,components:representatives.length};
 }
 for(const a of gear){a.closure=closure(a);need(a.closure.closed===self.parts[a.name].closed,'Independent actual closure agrees with self scan '+a.name);if(a.closure.closed)need(self.parts[a.name].embedded_closed_solid===true,'Actual embedded closed target proof '+a.name);if(changed.has(a.name))need(a.closure.closed&&a.closure.components===1,'Closed connected changed shell required before containment '+a.name);}
 // Connected closed disjoint surfaces have constant inside/outside relation on
 // each component. After SAT has rejected EVERY surface crossing/touch, one
 // representative per connected component therefore suffices for nesting.
 function nesting(a,b){
  if(!b.closure?.closed)return {solid:b.name,status:'not_a_closed_solid_no_containment_claim'};
  let maximum=0;
  for(const point of a.closure.representatives){if(!b.box.containsPoint(point))continue;let omega=0;
   for(const row of b.triangles){const u=row.tri.a.clone().sub(point),v=row.tri.b.clone().sub(point),w=row.tri.c.clone().sub(point),lu=u.length(),lv=v.length(),lw=w.length();need(Math.min(lu,lv,lw)>1e-10,'Unresolved coincident vertex after SAT');const numerator=u.dot(v.clone().cross(w)),denominator=lu*lv*lw+u.dot(v)*lw+v.dot(w)*lu+w.dot(u)*lv;omega+=2*Math.atan2(numerator,denominator);}
   const winding=Math.abs(omega/(4*Math.PI));maximum=Math.max(maximum,winding);need(winding<1e-5||Math.abs(winding-1)<1e-5,'Ambiguous actual closed-solid winding '+a.name+'/'+b.name);if(winding>.5)return {solid:b.name,status:'STRICT_INTERIOR',winding,point:point.toArray()};
  }return {solid:b.name,status:'outside',maximum_absolute_winding:maximum};
 }
 const sat=makeSAT(T);
 function check(a,b,kind){const r={kind,a:a.name,b:b.name,triangles_a:a.triangles.length,triangles_b:b.triangles.length,AABB_candidates:0,SAT_hits:0,first_actual_pairs:[]};
  if(a.box.intersectsBox(b.box))for(const x of a.triangles)for(const y of b.triangles){if(!x.box.intersectsBox(y.box))continue;r.AABB_candidates++;if(sat(x.tri,y.tri)){r.SAT_hits++;if(r.first_actual_pairs.length<10)r.first_actual_pairs.push({face_a:x.face,face_b:y.face,a:[x.tri.a,x.tri.b,x.tri.c].map(v=>v.toArray()),b:[y.tri.a,y.tri.b,y.tri.c].map(v=>v.toArray())});}}
  receipt.pairs.push(r);save();need(r.SAT_hits===0,'FIRST actual interpart/horse surface touch/crossing '+a.name+'/'+b.name);if(kind==='interpart'){r.containment=[nesting(a,b),nesting(b,a)];save();need(r.containment.every(x=>x.status!=='STRICT_INTERIOR'),'FIRST actual closed-solid nesting '+a.name+'/'+b.name);}}
 // Complete 55 unordered within-cohort and 198 changed/fixed pairs; zero skipped.
 for(let i=0;i<gear.length;i++)for(let j=i+1;j<gear.length;j++)if(changed.has(gear[i].name)||changed.has(gear[j].name))check(gear[i],gear[j],'interpart');
 need(receipt.pairs.length===253,'All55+198 interpart pairs');
 for(const a of gear.filter(x=>changed.has(x.name)))for(const b of horse)check(a,b,'horse');
 receipt.passed=true;save();
}catch(e){receipt.error=String(e.stack||e);save();process.exitCode=2;}
