# SPDX-License-Identifier: CC0-1.0
"""Actual decoded storage, active authored frame and eleven closed section shells."""
from pathlib import Path
import argparse,hashlib,json,struct,collections,math
import numpy as np
from layer_authority import CHANGED,validate

def need(ok,msg):
 if not ok:raise ValueError(msg)
def load(p):
 raw=p.read_bytes();need(struct.unpack_from('<III',raw)==(0x46546c67,2,len(raw)),'GLB header');n,t=struct.unpack_from('<II',raw,12);need(t==0x4e4f534a,'JSON type');size,t=struct.unpack_from('<II',raw,20+n);need(t==0x004e4942 and 28+n+size==len(raw),'BIN type/length');return json.loads(raw[20:20+n]),raw[28+n:],raw
def array(d,b,i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];need('byteStride'not in v and'sparse'not in a,'Plain accessor');dtype={5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']];c={'SCALAR':1,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];return np.frombuffer(b,dtype=dtype,count=a['count']*c,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,c)
def topology(P,F):
 need(len(P)>0 and len(F)>0 and int(F.min())>=0 and int(F.max())<len(P),'Component bounds');edges=collections.defaultdict(list);adj=collections.defaultdict(set)
 for f in F:
  need(len(set(f))==3,'Repeated triangle ID')
  for u,v in zip(f,np.roll(f,-1)):u=int(u);v=int(v);edges[tuple(sorted((u,v)))].append((u,v));adj[u].add(v);adj[v].add(u)
 need(all(len(e)==2 and e[0]==e[1][::-1]for e in edges.values()),'Closed opposite edges');seen=set();todo=[0]
 while todo:
  i=todo.pop()
  if i in seen:continue
  seen.add(i);todo.extend(adj[i]-seen)
 need(len(seen)==len(P) and len(P)-len(edges)+len(F)==2,'Connected Euler2');A=P[F];cross=np.cross(A[:,1]-A[:,0],A[:,2]-A[:,0]);area=np.linalg.norm(cross,axis=1)/2;need(float(area.min())>1e-11,'Actual nondegenerate triangle');volume=float(np.einsum('ij,ij->i',A[:,0],np.cross(A[:,1],A[:,2])).sum()/6);need(volume>0,'Actual outward volume');return {'vertices':len(P),'triangles':len(F),'minimum_area_m2':float(area.min()),'volume_m3':volume,'Euler':2}
def check(oldpath,newpath,params,out):
 out.mkdir();r={'passed':False,'scope':'Actual storage/component/bow envelope/shared-seam only; no horsefit/pressure/rider/period/photo acceptance'}
 try:
  old,ob,raw=load(oldpath);d,b,nraw=load(newpath);p=json.loads(params.read_text());need(hashlib.sha256(raw).hexdigest()=='a457874a81b624f5e9642d3296b1350eb49b17d21d38099fbe66080711c17021','A457 pin');r['candidate_sha256']=hashlib.sha256(nraw).hexdigest();r['parameters_sha256']=hashlib.sha256(params.read_bytes()).hexdigest();need(b[:len(ob)]==ob,'Old BIN prefix');need(d['accessors'][:len(old['accessors'])]==old['accessors']and d['bufferViews'][:len(old['bufferViews'])]==old['bufferViews'],'Old storage refs');need(len(d['meshes'])==len(old['meshes'])==29,'Exact29mesh cohort')
  for k in ['nodes','skins','animations','materials','scenes','scene']:need(old.get(k)==d.get(k),'Protected '+k)
  parts={};total=0;protected=[];rows={}
  for om,nm in zip(old['meshes'],d['meshes']):
   name=om['name'];need(nm['name']==name,'Name/order')
   for pr in nm['primitives']:total+=(len(array(d,b,pr['indices']))if'indices'in pr else len(array(d,b,pr['attributes']['POSITION'])))//3
   if name not in CHANGED:need(om==nm,'Protected mesh '+name);protected.append(name);continue
   need(len(nm['primitives'])==1,'Single changed primitive');pr=nm['primitives'][0];need(set(pr['attributes'])=={'POSITION','NORMAL'}and pr['material']==om['primitives'][0]['material'],'Rigid material/attributes');P=array(d,b,pr['attributes']['POSITION']).astype(float);N=array(d,b,pr['attributes']['NORMAL']).astype(float);F=array(d,b,pr['indices']).reshape(-1,3);need(np.isfinite(P).all()and np.isfinite(N).all(),'Finite geometry');need(np.max(abs(np.linalg.norm(N,axis=1)-1))<1e-6,'Unit normals');parts[name]=(P,F)
   rows[name]=topology(P,F)
   M=p['angular_segments']+1;Z=2 if name in ('front_bow','rear_bow') else len(p['z_stations_m'])
   expected_faces=4*(Z-1)*(M-1)+4*(Z+M-2)
   need(P.shape==(2*Z*M,3) and len(F)==expected_faces,'Exact authored section lattice '+name)
  validate(p);need(len(protected)==18 and set(parts)==CHANGED,'Exactly eleven retired/rebuilt and eighteen protected')
  # Unchanged node arrays alone do not establish that changed primitive bindings
  # are active/rigid: verify selected scene ancestry explicitly.
  parents={}
  for i,node in enumerate(d['nodes']):
   for child in node.get('children',[]):need(child not in parents,'Unique node parent');parents[child]=i
  active=set();todo=list(d['scenes'][d.get('scene',0)]['nodes'])
  while todo:
   i=todo.pop();need(i not in active,'Acyclic selected scene');active.add(i);todo.extend(d['nodes'][i].get('children',[]))
  for name in CHANGED:
   mi=next(i for i,m in enumerate(d['meshes']) if m['name']==name)
   nodes=[i for i in active if d['nodes'][i].get('mesh')==mi];need(len(nodes)==1,'Unique active changed primitive '+name)
   i=nodes[0]
   while True:
    n=d['nodes'][i];need('skin' not in n and n.get('translation',[0,0,0])==[0,0,0] and n.get('rotation',[0,0,0,1])==[0,0,0,1] and n.get('scale',[1,1,1])==[1,1,1] and n.get('matrix',[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1])==[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],'Authored root-frame rigid placement '+name)
    if i not in parents:break
    i=parents[i]
  r.update(active_triangles=total,primitive_batches=29,protected_meshes=protected,components=rows,scope='Actual decoded storage/closed topology/active rigid frame only; interpart and horse tests separate; no pressure/rider/motion/photo acceptance')
  r['passed']=True
 except BaseException as e:r['error']=repr(e);raise
 finally:(out/'readback.json').write_text(json.dumps(r,indent=2)+'\n')
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('old',type=Path);a.add_argument('new',type=Path);a.add_argument('parameters',type=Path);a.add_argument('out',type=Path);o=a.parse_args();check(o.old,o.new,o.parameters,o.out)
