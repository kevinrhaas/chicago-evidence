"""Read existing source/witnesses only; never evaluate a replacement surface."""
import json,hashlib
from pathlib import Path
BASE=Path('/workspace/shared')
INPUTS={'head':BASE/'horse-oral-channel-diagonal-candidate/source/frozen-head.json','patch':BASE/'horse-oral-channel-diagonal-candidate/source/oral-patch.json','conflicts':BASE/'horse-neutral-lip-complete-conflict-diagnostic-next/CONFLICTS.json'}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inventory():
 h,p,c=[json.loads(INPUTS[k].read_text()) for k in ('head','patch','conflicts')]
 ids=p['proposed_retired_source_face_ids']; assert len(ids)==124 and len(set(ids))==124
 faces=[h['faces'][i] for i in ids]; edges={}
 for f in faces:
  for a,b in zip(f,f[1:]+f[:1]):edges.setdefault(tuple(sorted((a,b))),[]).append((a,b))
 boundary=[e for e,v in edges.items() if len(v)==1]; assert len(boundary)==66
 assert all(len(v) in (1,2) for v in edges.values())
 retained=set(); floors=set(); charts=set()
 for row in c:
  for key in ('a_source_face_owner','b_source_face_owner'):
   o=row[key]
   if o['kind']=='oral_channel':
    s=o['source_owner']
    if s['kind']=='retained_source':retained.add(s.get('source_face',s.get('source_face_id')))
    if s['kind']=='oral_floor':floors.add(o['oral_generated_face'])
   elif o['kind']=='neutral_lip':charts.add((o['surface'],o['chart']))
 return {'status':'READONLY source inventory; replacement geometry UNIMPLEMENTED/UNEXECUTED','inputs':{k:{'path':str(v),'sha256':digest(v)} for k,v in INPUTS.items()},'original_patch_source_faces':ids,'original_patch_source_triangles':faces,'original_boundary_loop':p['rim_source_vertex_loop'],'boundary_edges':boundary,'original_source_chart_cells':p['source_chart_cells'],'actual_conflicts':len(c),'retained_exterior_conflict_source_faces':sorted(retained,key=str),'retained_floor_conflict_source_faces':sorted(floors),'failed_new_chart_cohorts':[list(v) for v in sorted(charts)],'required_authority_amendment':'Replace failed independently located aperture/lining with conforming source cut; cavity anterior changes require explicit new source-owned authority. No existing guard changed.'}
if __name__=='__main__': print(json.dumps(inventory(),indent=2))
