# SPDX-License-Identifier: GPL-3.0-or-later
"""Read actual baseline bytes/ancestry only, no new geometry."""
import json,hashlib,sys
from pathlib import Path
from fractions import Fraction as Q
sys.path.insert(0,'/workspace/shared/horse-neck-hybrid-source-next')
sys.path.insert(0,'/workspace/shared/horse-neutral-lip-source-phase-next')
from lip_variant import Model
B=Path('/workspace/shared')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run():
 parent=B/'horse-cheek-throat-quality-next/candidate-one/candidate.glb';assert sha(parent)=='57d63e2d7234380adeb727f5efeeed74d50629b2a8367ccea48961d6ecc5bec2'
 graft=B/'horse-combined-oral-neck-mane-prefix-next/candidate-one/graft-proof.json';g=json.loads(graft.read_text());m=Model(parent.read_bytes());labels={(r['mesh'],r['vertex']):r['label']for r in g['source_labels']};owners=g['source_face_owners']
 src=B/'horse-oral-channel-diagonal-candidate/candidate-one/head-source-surface.json';s=json.loads(src.read_text());r=next(r for r in s['records']if r['name']=='mouth_oral');outer=set(r['outer']);aliases={};live={}
 for key,v in m.views.items():
  active=set(map(int,v['indices'].ravel()))
  for i in active:
   tag=labels.get((key[0],i));
   if tag is not None:live.setdefault(tag,[]).append({'mesh':key[0],'primitive':key[1],'vertex':i})
 for i in sorted(outer):
  tag='h:'+str(i);rows=live.get(tag,[]);assert rows,('Missing active outer alias',tag)
  first=rows[0];base=m.views[first['mesh'],first['primitive']]['attributes'];aliases[tag]=[]
  for row in rows:
   a=m.views[row['mesh'],row['primitive']]['attributes']
   for k in ['POSITION','JOINTS_0','WEIGHTS_0']:assert a[k][row['vertex']].tobytes()==base[k][first['vertex']].tobytes()
   aliases[tag].append({**row,'raw_PJW_sha256':{k:hashlib.sha256(a[k][row['vertex']].tobytes()).hexdigest()for k in ['POSITION','JOINTS_0','WEIGHTS_0']}})
 cavity=[];plane=Q('.420');edgeknots={}
 for idx,o in enumerate(s['source_owners']):
  if o['kind']not in ['oral_roof','oral_floor','oral_back']:continue
  f=s['faces'][idx];z=[Q(str(s['positions'][i][2]))for i in f];state='posterior_exact'if max(z)<=plane else'anterior_retire'if min(z)>=plane else'split_at_plane'
  actual=[int(gid)for gid,owner in owners.items()if owner.get('kind')=='oral_channel'and owner.get('oral_generated_face')==idx];assert len(actual)==1,('Exact actual cavity owner',idx,actual)
  row={'oral_source_face':idx,'source_owner':o,'vertices':f,'actual57d_global':actual[0],'classification':state,'plane_edge_knots':[]}
  for k in range(3):
   a,b=f[k],f[(k+1)%3];za,zb=z[k],z[(k+1)%3]
   if(za<plane<zb)or(zb<plane<za):
    lo,hi=sorted((a,b));t=(plane-Q(str(s['positions'][lo][2])))/(Q(str(s['positions'][hi][2]))-Q(str(s['positions'][lo][2])))
    key=str(lo)+':'+str(hi);edgeknots[key]={'source_edge':[lo,hi],'fraction':str(t),'source_face_owners':[]};row['plane_edge_knots'].append(key)
  cavity.append(row)
 for key,row in edgeknots.items():row['source_face_owners']=[r['oral_source_face']for r in cavity if key in r['plane_edge_knots']]
 assert len(cavity)==202
 return{'status':'READONLY actual57d alias/current cavity ownership; no new model','pins':{'baseline':sha(parent),'graft':sha(graft),'oral_source':sha(src)},'outer66_active_rawaliases':aliases,'cavity202_source_owned_plane_partition':cavity,'shared_cut_edge_knots':edgeknots,'partition_counts':{k:sum(r['classification']==k for r in cavity)for k in ['posterior_exact','anterior_retire','split_at_plane']},'no_permission_claim':'Inactive ancestor124faces are a reconstruction template only; active authority is current132connector plus explicitly enumerated cavity split/anterior owners.'}
if __name__=='__main__':print(json.dumps(run(),indent=2))
