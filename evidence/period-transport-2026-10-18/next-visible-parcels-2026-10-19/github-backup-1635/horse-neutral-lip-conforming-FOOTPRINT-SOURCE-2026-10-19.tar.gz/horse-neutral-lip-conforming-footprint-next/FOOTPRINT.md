# Concrete source-chart footprint revision — not a horse build

This revision replaces the earlier proposed independent physicalY/Z aperture targets with ONE fixed source-z/theta polygon inside the original124-face chart. This is a declared design-authority change. It does not claim a measured lip shape or physical embedding. Existing failed4c3/95-conflict evidence is untouched.

`cut-map.json` gives all108 ordered boundary knots, exact rational barycentric coordinates against their actual ancestor triangles, all source-face aliases on shared edges, and every interval's containing face. The fourteen fixed chart corners are explicit. Rounded rear corners are a deliberately polygonal source-footprint approximation pending actual anatomy viewing, not a finished rounded lip. Every cut interval is proven contained in an original permission triangle;82 source triangles are split. No missing target is extrapolated. No replacement tissue, lining or horse GLB has been generated.

Source patch proof now verifies opposite-directed internal edges, face connectivity, Euler1 and the exact ordered66-edge boundary. This supersedes the earlier count-only124/66 assertion. A separate global simple-cut/nonoverlap and conforming complement-tessellation check is still required in executable source before any trial. Intrinsic containment does not imply XYZ embedding.

`current-map.json` binds actual57d SHA57d63e… and graft ledger to all66 current active outer labels with actual mesh/primitive/raw vertex aliases and exactP/JW byte hashes. It partitions the202 original cavity owners at the exactZ=.420 plane:112 wholly posterior,30 wholly anterior,60 straddling. All202 are mapped to unique current global IDs. The62 shared plane-crossing source edges carry exact rational fractions and all incident cavity face IDs. These are source ownership records, not output triangles.

`template-current-binding.json` enumerates every ancestor patch vertex's actual raw57d aliases, active/inactive status and template-versus-current position difference. All124 original patch faces are confirmed inactive in the actual graft ledger; they are a reconstruction TEMPLATE, never a current face-retirement bucket. Current retirement permission still starts at132 active connectors plus the explicitly listed30 anterior/60 split cavity owners. No sourceID is inferred from proximity.

## Directed posterior commissure loops

The actual box backwall isZ=.370,halfwidth45mm,roofY=-.185,floorY=-.218. For each side create a new planar crescent atX=±.045, replacing NO backwall and retaining its shared boundary. Ordered left crescent boundary:
1. old left backwall top corner (X=-.045,Y=-.185,Z=.370),
2. roof side source-edge knots up to the new rear aperture's top inner endpointZ=.395,
3. ordered inner rear-cut arc, same exact chartZ sequence .395→.382→.377→.382→.395, with innerY derived linearly from lefttheta26→28 across roof→floor,
4. floor side source-edge knots back to the old left backwall bottom corner,
5. old backwall left vertical edge knots in reverse to close.
Right uses the mirrored source-ownedtheta44→46 arc (floor→roof), with reversed order for opposite outward orientation. Neither crescent bridges across the bit or seals the mouth. Every new shared roof/floor edge knot must be split in both incident owners; no duplicate aliases/T-junctions. The .395 corner split is inside the original .390→.430 side interval, whose owners already intersect the .420 split plane. Exact source-edge membership and final knot sequence still need executable verification before generation; the loop is not a clearance claim.

## Longitudinal station correspondence

Use union of actual cut knot chartZ, original roof/floor side source-edgeZ, and .395/.420. All exterior→wet lining interfaces carry the SAME named chart segment and longitudinal station. Posterior inner root lies onX±.045/roof orfloor as appropriate; it cannot silently map a front station to oldZ=.370/.500. Source-owned outer tissue uses conforming original triangles rather than a linearXYZ blend.

The earlier plan's universal final cavityZ=.525 is incompatible with distinct source-owned front cuts atZ=.530 and.532. Do not retain that contradictory station claim. Proposed explicit final front inner setback is6mm: lowerZ=.524,upperZ=.526. The same setback is smoothly introduced only anterior toZ=.490. End floorY=-.212 androofY=-.206 are reconstruction choices. Lateral inner narrowing needs a source-owned front chart and actual clearance validation. Final transverse chart correspondence/corner winding MUST be supplied and independently reviewed in executable source; this document does not mark it solved. No candidate model evaluation is permitted from this map alone.

## Remaining release blockers

Independent review of current footprint; global simple-cut/conforming complement ownership; exact crescent shared-edge splits; full final transverse station map; fixed producer/storage/normal authority and caller review; then one bounded actual trial under existing strictXYZ head/lining/vsALL/36gear/bit predicates. Existing movement/clearance guards are unchanged. No UVadjacency or inherited baseline receipt may waive actual crossing. All physical/anatomical/photographic and posed acceptance remains open.
