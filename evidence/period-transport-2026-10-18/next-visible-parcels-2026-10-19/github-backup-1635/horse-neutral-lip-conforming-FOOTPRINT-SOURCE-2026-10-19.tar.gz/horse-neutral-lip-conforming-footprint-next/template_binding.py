# SPDX-License-Identifier: GPL-3.0-or-later
"""Readonly ancestor-template/current-attribute binding, never creates new P."""
import sys,json,hashlib
from pathlib import Path
import numpy as np
sys.path.insert(0,'/workspace/shared/horse-neutral-lip-source-phase-next')
from lip_variant import Model
B=Path('/workspace/shared');D=Path(__file__).parent
h=json.load(open(B/'horse-oral-channel-diagonal-candidate/source/frozen-head.json'));p=json.load(open(B/'horse-oral-channel-diagonal-candidate/source/oral-patch.json'));g=json.load(open(B/'horse-combined-oral-neck-mane-prefix-next/candidate-one/graft-proof.json'));raw=(B/'horse-cheek-throat-quality-next/candidate-one/candidate.glb').read_bytes();assert hashlib.sha256(raw).hexdigest()=='57d63e2d7234380adeb727f5efeeed74d50629b2a8367ccea48961d6ecc5bec2';m=Model(raw)
labels={(r['mesh'],r['vertex']):r['label']for r in g['source_labels']};active=set()
for key,v in m.views.items():active.update((key[0],int(i))for i in v['indices'].ravel())
rows=[]
for vertex in sorted({i for f in p['proposed_retired_source_face_ids']for i in h['faces'][f]}):
 aliases=[(mi,i)for(mi,i),tag in labels.items()if tag=='h:'+str(vertex)];assert aliases
 out=[]
 for mi,i in aliases:
  view=next(v for key,v in m.views.items()if key[0]==mi);a=view['attributes'];pos=a['POSITION'][i].astype(float)-np.array([0,1.88,.8]);out.append({'mesh':mi,'vertex':i,'currently_active':(mi,i)in active,'raw_PJW_sha256':{k:hashlib.sha256(a[k][i].tobytes()).hexdigest()for k in['POSITION','JOINTS_0','WEIGHTS_0']},'source_template_position_difference_m':float(np.linalg.norm(pos-np.asarray(h['positions'][vertex])))})
 rows.append({'ancestor_vertex':vertex,'aliases':out})
sourceowners=g['source_face_owners'];faces=[]
for f in p['proposed_retired_source_face_ids']:
 found=[]
 for gid,o in sourceowners.items():
  if o.get('kind')=='baseline_head'and o.get('source_head_face')==f:found.append(int(gid))
  if o.get('kind')=='oral_channel'and o.get('source_owner',{}).get('kind')=='retained_source'and o['source_owner'].get('source_face')==f:found.append(int(gid))
 assert not found,('Ancestor cut face unexpectedly active',f,found)
 faces.append({'ancestor_source_face':f,'current_active_equivalent':None,'reason':'Retired by original oral124 authority; template ONLY, not current retirement permission'})
print(json.dumps({'status':'READONLY template/current alias binding','vertices':rows,'ancestor_faces':faces,'no_new_positions':True},indent=2))
