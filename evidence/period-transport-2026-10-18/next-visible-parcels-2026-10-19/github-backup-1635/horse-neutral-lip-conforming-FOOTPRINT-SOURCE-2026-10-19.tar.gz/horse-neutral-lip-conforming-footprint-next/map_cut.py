# SPDX-License-Identifier: CC0-1.0
"""Read original source chart only. Output cut provenance, NOT replacement triangles."""
from fractions import Fraction as Q
from pathlib import Path
import json,hashlib
B=Path('/workspace/shared/horse-oral-channel-diagonal-candidate/source')
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def sub(a,b):return[a[i]-b[i]for i in range(2)]
def bary(p,t):
 d=cross(sub(t[1],t[0]),sub(t[2],t[0])); assert d
 b=cross(sub(p,t[0]),sub(t[2],t[0]))/d;c=cross(sub(t[1],t[0]),sub(p,t[0]))/d
 return[1-b-c,b,c]
def v(q):return[str(x)for x in q]
def generate():
 raw=(B/'frozen-head.json').read_bytes();h=json.loads(raw);pr=(B/'oral-patch.json').read_bytes();p=json.loads(pr)
 assert hashlib.sha256(raw).hexdigest()=='ac4d96ab6ae8d0ef5956686a3a9c213ebce1dd9e76f5e91c4e376b319429b5b3'
 assert hashlib.sha256(pr).hexdigest()=='4b7fe911945903d43d518e496ea55cb09614233d7bfd7583f56724a7e4ac4182'
 ids=p['proposed_retired_source_face_ids'];uv={i:(Q(str(x[2])),Q((i-72)%48))for i,x in enumerate(h['positions'])if 72<=i<648}
 charts={i:[uv[j]for j in h['faces'][i]]for i in ids}
 # Fixed original reconstruction in exact longitudinal-z / angular-index chart.
 points=[['.395','26'],['.382','26.25'],['.377','27'],['.382','27.75'],['.395','28'],['.530','28'],['.530','44'],['.395','44'],['.382','44.25'],['.377','45'],['.382','45.75'],['.395','46'],['.532','46'],['.532','26']]
 C=[tuple(map(Q,r))for r in points];segments=[];knots=[];cutfaces=set();edges={}
 for i in ids:
  f=h['faces'][i]
  for a,b in zip(f,f[1:]+f[:1]):edges.setdefault(tuple(sorted((a,b))),[]).append(i)
 for si,(a,b)in enumerate(zip(C,C[1:]+C[:1])):
  d=sub(b,a);ts={Q(0),Q(1)}
  for e in edges:
   x,y=[uv[k]for k in e];g=sub(y,x);den=cross(d,g)
   if not den:continue
   t=cross(sub(x,a),g)/den;s=cross(sub(x,a),d)/den
   if 0<=t<=1 and 0<=s<=1:ts.add(t)
  ts=sorted(ts);parts=[]
  for ta,tb in zip(ts,ts[1:]):
   m=[a[k]+(ta+tb)/2*d[k]for k in range(2)];owners=[i for i,t in charts.items()if min(bary(m,t))>=0]
   assert owners,('Cut exits original permission footprint',si,v(m))
   cutfaces.update(owners);parts.append({'t0':str(ta),'t1':str(tb),'source_faces':owners})
  for t in ts[:-1]:
   pt=[a[k]+t*d[k]for k in range(2)];owners=[]
   for i,tri in charts.items():
    w=bary(pt,tri)
    if min(w)>=0:owners.append({'source_face':i,'vertices':h['faces'][i],'barycentric':v(w)})
   assert owners
   knots.append({'segment':si,'t':str(t),'chart':v(pt),'source_face_aliases':owners})
  segments.append({'segment':si,'a':v(a),'b':v(b),'intervals':parts})
 # Ordered source disk proof, not a count-only assertion.
 E={};adj={i:set()for i in ids}
 for i in ids:
  f=h['faces'][i]
  for a,b in zip(f,f[1:]+f[:1]):E.setdefault(tuple(sorted((a,b))),[]).append((i,a,b))
 boundary=[]
 for e,rows in E.items():
  assert len(rows)in[1,2]
  if len(rows)==2:
   assert rows[0][1:]==rows[1][1:][::-1];adj[rows[0][0]].add(rows[1][0]);adj[rows[1][0]].add(rows[0][0])
  else:boundary.append(rows[0][1:])
 seen=set();todo=[ids[0]]
 while todo:
  i=todo.pop()
  if i not in seen:seen.add(i);todo.extend(adj[i]-seen)
 assert len(seen)==124
 verts={i for f in ids for i in h['faces'][f]};assert len(verts)-len(E)+124==1
 successor={a:b for a,b in boundary};assert len(successor)==66
 loop=p['rim_source_vertex_loop'];expected={(a,b)for a,b in zip(loop,loop[1:]+loop[:1])};actual=set(boundary)
 assert actual==expected or actual=={(b,a)for a,b in expected}
 return{'status':'READONLY source cut footprint; no replacement horse geometry/export','source_pins':{'head':hashlib.sha256(raw).hexdigest(),'patch':hashlib.sha256(pr).hexdigest()},'chart_authority':'NEW fixed source z/theta cut, supersedes independent physical aperture target; no photo-derived dimensions','ordered_chart_corners':points,'ordered_cut_knots':knots,'segments':segments,'cut_split_source_faces':sorted(cutfaces),'source_patch_disk':{'faces':124,'vertices':len(verts),'edges':len(E),'Euler':1,'connected':True,'opposite_owned_internal_edges':True,'ordered_boundary66':loop},'unresolved':'Current57d aliases, per-face conforming complement tessellation, cavity station/crescent map and independent review required; no actual model trial permitted'}
if __name__=='__main__':print(json.dumps(generate(),indent=2))
