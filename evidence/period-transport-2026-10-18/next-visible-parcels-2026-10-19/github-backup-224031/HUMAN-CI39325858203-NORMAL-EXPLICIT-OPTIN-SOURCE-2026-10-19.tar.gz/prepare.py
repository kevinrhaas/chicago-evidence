from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/chicago')
HEAD = '5410b708fc177eb794249af0b157a36edb1e34b3'
paths = ['chicago/4d/tools/human_era_study_common.py',
         'chicago/4d/tools/human_era_study_blend.py',
         'chicago/4d/tools/human_era_study.sh',
         '.github/workflows/chicago-4d-era-studies.yml']
for path in paths:
    data = subprocess.check_output(['git','-C',str(REPO),'show',HEAD+':'+path])
    for folder in ['preimages','proposed']:
        target = ROOT/folder/path
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)

def change(path, before, after):
    target=ROOT/'proposed'/path
    text=target.read_text()
    if text.count(before)!=1:
        raise ValueError((path, text.count(before),before))
    target.write_text(text.replace(before,after))

common=paths[0]; cli=paths[1]; shell=paths[2]; workflow=paths[3]
change(common,'def skin_and_hair(root, manifest, study):', '''def apply_body_normal_probe(mesh, normals, source_ids, receipt_directory, context):
    """Explicit existing packed-code experiment; no retry or weaker caller audit.

    Inputs are the actual rendered mesh and the exact retained full-body source
    IDs. The existing transaction guards geometry/UV/weights, raw target normals
    and shared-source seams and restores original codes on an ordinary failure.
    This wrapper does not claim export, pose, rendering or photographic acceptance.
    """
    from human_normal_probe import experiment
    directory = Path(receipt_directory).resolve()
    need(directory.is_relative_to(Path('/tmp')),
         "Normal experiment receipts must remain under /tmp")
    path = directory/(hashlib.sha256(mesh.name.encode()).hexdigest()+"-normal-probe.json")
    need(not path.exists(), "Never overwrite a normal experiment receipt")
    return experiment(mesh, normals, source_ids, path, context=context)


def skin_and_hair(root, manifest, study, normal_probe_receipts=None):''')
change(common,'        obj.data.update()\n        need(obj.data.has_custom_normals', '''        obj.data.update()
        probe = None
        if normal_probe_receipts is not None:
            probe = apply_body_normal_probe(
                obj.data, normals, source["source_vertex_indices"], normal_probe_receipts,
                {"blender_version": bpy.app.version_string,
                 "asset_id": manifest["asset_id"], "scene": manifest["scene"],
                 "explicit_opt_in": True,
                 "normal_authority": "Full immutable body normals remapped by retained graphical source IDs",
                 "scope": "Actual masked canonical source body before LOD/export only"})
        need(obj.data.has_custom_normals''')
change(common,'                                "bound": 1e-3, "scope": "Actual BPy body before LOD/export only"})', '''                                "bound": 1e-3, "scope": "Actual BPy body before LOD/export only"})
        if probe is not None:
            normal_receipts[-1]["experimental_normal_probe"] = probe''')
change(cli,'    parser.add_argument("--receipt", type=Path)', '''    parser.add_argument("--receipt", type=Path)
    parser.add_argument("--experimental-normal-probes", action="store_true",
                        help="Explicit bounded existing packed-normal CI experiment; raw1e-3 stays mandatory")
    parser.add_argument("--normal-probe-receipts", type=Path,
                        help="Required fresh /tmp directory for opted-in actual normal measurements")''')
change(cli,'    return args\n\n\ndef checked_inputs', '''    if args.experimental_normal_probes:
        if args.check_source_only:
            parser.error("Normal experiments require actual canonical authoring, never source-only checks")
        if (args.normal_probe_receipts is None or
                not args.normal_probe_receipts.resolve().is_relative_to(Path('/tmp')) or
                args.normal_probe_receipts.exists()):
            parser.error("--experimental-normal-probes requires a fresh --normal-probe-receipts directory under /tmp")
    elif args.normal_probe_receipts is not None:
        parser.error("--normal-probe-receipts requires explicit --experimental-normal-probes")
    return args


def checked_inputs''')
change(cli,'        hair, normals = skin_and_hair(root, manifest, study)', '''        hair, normals = skin_and_hair(
            root, manifest, study,
            normal_probe_receipts=args.normal_probe_receipts if args.experimental_normal_probes else None)''')
change(shell,'OUTPUT=""\n','OUTPUT=""\nNORMAL_PROBES=false\n')
change(shell,'while [ $# -gt 0 ]; do\n  case "$1" in\n','while [ $# -gt 0 ]; do\n  case "$1" in\n    --experimental-normal-probes) NORMAL_PROBES=true; shift ;;\n')
change(shell,'source generators/blender.pin', '''if "$NORMAL_PROBES"; then
  [[ "$(realpath -m -- "$OUTPUT")" = /tmp/* ]] || { echo "Normal experiment output must resolve under /tmp" >&2; exit 2; }
fi
source generators/blender.pin''')
change(shell,'  export HUMAN_EXPORT_EVIDENCE_DIR="$directory/export-evidence"', '''  export HUMAN_EXPORT_EVIDENCE_DIR="$directory/export-evidence"
  normal_args=()
  if "$NORMAL_PROBES"; then
    normal_args=(--experimental-normal-probes --normal-probe-receipts "$directory/normal-probes")
  fi''')
change(shell,'    --output "$master" --receipt "$directory/master-receipt.json" \\',
             '    --output "$master" --receipt "$directory/master-receipt.json" "${normal_args[@]}" \\')
change(workflow,'      - name: Build canonical masters with failure diagnostics and portable exports',
       '      - name: Build canonical masters with explicit packed-normal experiment and unchanged export gates')
change(workflow,'--output-dir /tmp/era-studies\n','--output-dir /tmp/era-studies --experimental-normal-probes\n')
change(workflow,'          python tools/test_human_era_study_source.py',
       '          python tools/test_human_era_normal_probe_optin.py\n          python tools/test_human_era_study_source.py')
