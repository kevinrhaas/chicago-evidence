from pathlib import Path
import ast
import difflib
import hashlib
import json
import shutil
import subprocess
import tarfile
import tempfile

ROOT=Path(__file__).resolve().parent
APP=Path('/workspace/chicago')
HEAD='5410b708fc177eb794249af0b157a36edb1e34b3'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
checks=[]
def record(label,cmd,cwd=None):
    result=subprocess.run(cmd,cwd=cwd,capture_output=True,text=True)
    checks.append({'label':label,'command':cmd,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
    if result.returncode:raise ValueError(checks[-1])

record('new actual AST/parser/shell-prefix dispatch controls', ['python',str(ROOT/'proposed/chicago/4d/tools/test_human_era_normal_probe_optin.py'),'-v'])
for file in ['test_human_normal_probe_math.py','test_human_normal_probe_adapter.py','test_human_normal_probe_optin.py']:
    record('unchanged existing pure/mock '+file,['python',str(APP/'chicago/4d/tools'/file)])
record('shell syntax',['bash','-n',str(ROOT/'proposed/chicago/4d/tools/human_era_study.sh')])
for path in (ROOT/'proposed').rglob('*.py'): ast.parse(path.read_text())

patch=[]
preimages=[]
for path in sorted((ROOT/'proposed').rglob('*')):
    if not path.is_file():continue
    relative=path.relative_to(ROOT/'proposed')
    pre=ROOT/'preimages'/relative
    if pre.exists():
        exact=subprocess.check_output(['git','-C',str(APP),'show',HEAD+':'+str(relative)])
        if exact!=pre.read_bytes(): raise ValueError('Wrong exact head preimage '+str(relative))
        preimages.append({'path':str(relative),'sha256':sha(pre)})
    patch.extend(difflib.unified_diff(pre.read_text().splitlines(True) if pre.exists() else [],
                                    path.read_text().splitlines(True),
                                    fromfile='a/'+str(relative) if pre.exists() else '/dev/null',
                                    tofile='b/'+str(relative)))
(ROOT/'ERA-NORMAL-EXPLICIT-OPTIN.patch').write_text(''.join(patch))
with tempfile.TemporaryDirectory(prefix='era-normal-applycheck-') as temporary:
    for pre in (ROOT/'preimages').rglob('*'):
        if pre.is_file():
            target=Path(temporary)/pre.relative_to(ROOT/'preimages')
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(pre,target)
    record('isolated exact-head patch application check',['git','apply','--check',str(ROOT/'ERA-NORMAL-EXPLICIT-OPTIN.patch')],temporary)

common=Path('chicago/4d/tools/human_era_study_common.py')
cli=Path('chicago/4d/tools/human_era_study_blend.py')
def functions(folder,path):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse((ROOT/folder/path).read_text()).body if isinstance(n,ast.FunctionDef)}
for path,changed in [(common,{'skin_and_hair','apply_body_normal_probe'}),(cli,{'parse','main'})]:
    before,after=functions('preimages',path),functions('proposed',path)
    for name in set(before)|set(after):
        if name not in changed and before.get(name)!=after.get(name):raise ValueError('Unintended function AST change '+name)
    checks.append({'label':'unrelated function ASTs unchanged '+str(path),'PASS':True,'changed_functions':sorted(changed)})

before_skin=next(n for n in ast.parse((ROOT/'preimages'/common).read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='skin_and_hair')
after_skin=next(n for n in ast.parse((ROOT/'proposed'/common).read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='skin_and_hair')
after_skin.args=before_skin.args
body_loop=next(n for n in after_skin.body if isinstance(n,ast.For))
body_loop.body=[n for n in body_loop.body if not (
    isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='probe' for t in n.targets)
    or isinstance(n,ast.If) and ast.unparse(n.test) in ('normal_probe_receipts is not None','probe is not None'))]
if ast.dump(before_skin,include_attributes=False)!=ast.dump(after_skin,include_attributes=False):
    raise ValueError('Existing skin/full-body normal authority/caller raw audit/hair AST changed')
checks.append({'label':'entire ordinary skin/full-body normal/raw-readback/hair function AST unchanged after removing only opt-in additions','PASS':True})

external={}
for path in ['chicago/4d/tools/human_normal_probe.py','chicago/4d/tools/human_normal_probe_math.py',
             'chicago/4d/tools/human_export.sh','chicago/4d/tools/human_source_normals.py',
             'chicago/4d/tools/human_teamster_blend.py',
             'chicago/4d/data/humans/recipes/era_studies/1812.json',
             'chicago/4d/data/humans/recipes/era_studies/1904.json']:
    data=subprocess.check_output(['git','-C',str(APP),'show',HEAD+':'+path])
    if (APP/path).read_bytes()!=data:raise ValueError('External current bytes changed '+path)
    external[path]=hashlib.sha256(data).hexdigest()
report={'PASS':True,'scope':'Exact-head source/AST/parser/shell-prefix and mocked dispatch controls only; no BPy/normal-code execution, master, export, browser or acceptance',
        'head':HEAD,'preimages':preimages,'checks':checks,'external_unchanged':external,
        'normal_bound':0.001,'actual_failed_delta':0.0019328318828065018,
        'actual_new_recovery_attempted':False,'mature_skin_change_included':False}
(ROOT/'SOURCE-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n')
