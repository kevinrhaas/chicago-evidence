# SPDX-License-Identifier: GPL-3.0-or-later
"""Exact opt-in source and mocked dispatch controls. No BPy or export execution."""
import argparse
import ast
import contextlib
import hashlib
import io
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent


def function(path, name, namespace):
    node = next(n for n in ast.parse(path.read_text()).body
                if isinstance(n, ast.FunctionDef) and n.name == name)
    exec(compile(ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[])),
                 str(path), 'exec'), namespace)
    return namespace[name]


class OptIn(unittest.TestCase):
    def parse(self, extra):
        return function(ROOT/'tools/human_era_study_blend.py', 'parse',
                        {'argparse': argparse, 'Path': Path, 'ROOT': ROOT,
                         '__doc__': 'Source-only exact parser control'})(
                             ['--era-study', '1812', '--liberty', 'L419',
                              '--output', '/tmp/ERA_NORMAL_ARG_ONLY_DO_NOT_CREATE.blend']+extra)

    def test_ordinary_default_and_optin(self):
        self.assertFalse(self.parse([]).experimental_normal_probes)
        with tempfile.TemporaryDirectory() as scratch:
            path = str(Path(scratch)/'fresh')
            args = self.parse(['--experimental-normal-probes', '--normal-probe-receipts', path])
            self.assertTrue(args.experimental_normal_probes)
            self.assertEqual(args.normal_probe_receipts, Path(path))

    def test_invalid_receipts_refused(self):
        with tempfile.TemporaryDirectory() as scratch:
            for extra in [['--experimental-normal-probes'],
                          ['--normal-probe-receipts', scratch],
                          ['--experimental-normal-probes', '--normal-probe-receipts', scratch],
                          ['--experimental-normal-probes', '--normal-probe-receipts', '/workspace/unsafe'],
                          ['--experimental-normal-probes', '--normal-probe-receipts', '/tmp/../workspace/unsafe']]:
                with self.subTest(extra=extra), contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                    self.parse(extra)

    def test_source_only_never_runs_probe(self):
        parser = function(ROOT/'tools/human_era_study_blend.py', 'parse',
                          {'argparse': argparse, 'Path': Path, 'ROOT': ROOT, '__doc__': 'source only'})
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            parser(['--era-study', '1812', '--liberty', 'L419', '--check-source-only',
                    '--experimental-normal-probes', '--normal-probe-receipts', '/tmp/fresh'])

    def test_wrapper_exact_masked_source_dispatch_and_failure(self):
        def need(value, message):
            if not value: raise ValueError(message)
        wrapper = function(ROOT/'tools/human_era_study_common.py', 'apply_body_normal_probe',
                           {'Path': Path, 'hashlib': hashlib, 'need': need})
        calls = []
        def experiment(*args, **kwargs):
            calls.append((args, kwargs))
            return {'status': 'explicit mocked adapter, no BPy'}
        mesh = SimpleNamespace(name='actual-mesh-name')
        normals, ids, context = [(0., 1., 0.)], [99], {'explicit_mock': True}
        with tempfile.TemporaryDirectory() as scratch, patch.dict(sys.modules, {'human_normal_probe': SimpleNamespace(experiment=experiment)}):
            path = Path(scratch)/'fresh'
            result = wrapper(mesh, normals, ids, path, context)
            args, kwargs = calls.pop()
            self.assertIs(args[0], mesh)
            self.assertIs(args[1], normals)
            self.assertIs(args[2], ids)
            self.assertEqual(args[3], path/(hashlib.sha256(mesh.name.encode()).hexdigest()+'-normal-probe.json'))
            self.assertIs(kwargs['context'], context)
            self.assertEqual(result['status'], 'explicit mocked adapter, no BPy')
            path.mkdir()
            args[3].write_text('immutable prior receipt')
            with self.assertRaises(ValueError): wrapper(mesh, normals, ids, path, context)
            self.assertFalse(calls)
            self.assertEqual(args[3].read_text(), 'immutable prior receipt')
            with self.assertRaises(ValueError): wrapper(mesh, normals, ids, Path('/workspace/unsafe'), context)
        error = RuntimeError('exact probe failure')
        def fail(*args, **kwargs): raise error
        with tempfile.TemporaryDirectory() as scratch, patch.dict(sys.modules, {'human_normal_probe': SimpleNamespace(experiment=fail)}):
            with self.assertRaises(RuntimeError) as caught: wrapper(mesh, normals, ids, Path(scratch)/'fresh', context)
            self.assertIs(caught.exception, error)

    def test_shell_prefix_optin_and_default(self):
        shell = ROOT/'tools/human_era_study.sh'
        prefix = shell.read_text().split('source generators/blender.pin', 1)[0]
        prefix += '\nprintf "NORMAL_PROBES=%s\\n" "$NORMAL_PROBES"\n'
        for label, extra, code, expected in [
                ('default', [], 0, 'false'), ('optin', ['--experimental-normal-probes'], 0, 'true')]:
            with self.subTest(label=label), tempfile.TemporaryDirectory() as scratch:
                result = subprocess.run(['bash', '-c', prefix, str(shell), '--era-study', '1812', '--liberty', 'L419',
                                         '--output-dir', str(Path(scratch)/'fresh'), *extra], capture_output=True, text=True)
                self.assertEqual(result.returncode, code, result.stderr)
                self.assertIn('NORMAL_PROBES='+expected, result.stdout)
        result = subprocess.run(['bash', '-c', prefix, str(shell), '--era-study', '1812', '--liberty', 'L419',
                                 '--output-dir', '/workspace/EXPLICIT_SOURCE_ONLY_FRESH', '--experimental-normal-probes'], capture_output=True, text=True)
        self.assertEqual(result.returncode, 2)

    def test_source_contracts_unchanged(self):
        source = (ROOT/'tools/human_era_study_common.py').read_text()
        for exact in ['full_normals = source_shared_normals(full["positions_m"], full["triangles"], full["source_vertex_indices"])',
                      'normals = [by_id[sid] for sid in source["source_vertex_indices"]]',
                      'obj.data.normals_split_custom_set([normals[loop.vertex_index] for loop in obj.data.loops])',
                      'need(delta <= 1e-3,', 'normal_probe_receipts is not None:',
                      'obj.data, normals, source["source_vertex_indices"], normal_probe_receipts']:
            self.assertIn(exact, source)
        self.assertLess(source.index('normals_split_custom_set'), source.index('probe = apply_body_normal_probe'))
        self.assertLess(source.index('probe = apply_body_normal_probe'), source.index('need(delta <= 1e-3,'))
        self.assertNotIn('bpy', sys.modules)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--root', type=Path, default=ROOT)
    args, remaining = parser.parse_known_args()
    ROOT = args.root.resolve()
    unittest.main(argv=[sys.argv[0], *remaining])
