"""One<=30min metadata-only watch; >=60s polling; no logs/download/dispatch."""
from pathlib import Path
import subprocess,json,time,datetime
P=Path(__file__).parent;SHA='5410b708fc177eb794249af0b157a36edb1e34b3';START=datetime.datetime.fromisoformat('2026-10-19T21:18:54.218507+00:00').timestamp();DEADLINE=START+1800;BASE='repos/kevinrhaas/chicago/';last_poll=START;sequence=0

def query(path):
 r=subprocess.run(['gh','api',BASE+path],capture_output=True,text=True,timeout=30)
 if r.returncode:raise RuntimeError(r.stderr[:2000])
 return json.loads(r.stdout)
def signature(run,jobs):
 return {'head_sha':run['head_sha'],'status':run['status'],'conclusion':run['conclusion'],'jobs':[{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'steps':[{k:s.get(k)for k in ['number','name','status','conclusion','started_at','completed_at']}for s in j.get('steps',[])]}for j in jobs['jobs']]}
old=signature(json.loads((P/'initial-run.json').read_text()),json.loads((P/'initial-jobs.json').read_text()));events=[{'at':START,'state':old}];(P/'events.json').write_text(json.dumps(events,indent=2)+'\n')
while time.time()<DEADLINE:
 remaining=max(0,last_poll+60-time.time())
 if remaining:time.sleep(min(60,remaining))
 if time.time()>=DEADLINE:break
 last_poll=time.time();sequence+=1
 try:
  run=query('actions/runs/39325858203');jobs=query('actions/runs/39325858203/jobs');assert run['head_sha']==SHA,'CI head changed';now=signature(run,jobs)
  if now!=old:
   stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');(P/(stamp+'-run.json')).write_text(json.dumps(run,indent=2)+'\n');(P/(stamp+'-jobs.json')).write_text(json.dumps(jobs,indent=2)+'\n');events.append({'at':last_poll,'state':now});(P/'events.json').write_text(json.dumps(events,indent=2)+'\n');print(json.dumps({'changed':True,'sequence':sequence,'state':now}),flush=True);old=now
  if run['status']=='completed':
   annotations=[]
   for job in jobs['jobs']:
    check=query('check-runs/'+str(job['id']));ann=query('check-runs/'+str(job['id'])+'/annotations');(P/('terminal-check-'+str(job['id'])+'.json')).write_text(json.dumps(check,indent=2)+'\n');(P/('terminal-annotations-'+str(job['id'])+'.json')).write_text(json.dumps(ann,indent=2)+'\n');annotations.extend([{'job':job['id'],**a}for a in ann])
   artifacts=query('actions/runs/39325858203/artifacts');(P/'terminal-artifact-metadata.json').write_text(json.dumps(artifacts,indent=2)+'\n');summary={'terminal':True,'run_id':run['id'],'head_sha':SHA,'status':run['status'],'conclusion':run['conclusion'],'polls_after_initial':sequence,'state_changes':len(events),'elapsed_s':time.time()-START,'state':now,'annotations':annotations,'artifact_metadata_only':True,'logs_or_artifact_redirect_requested':False,'Blender_or_redispatch':False};(P/'FINAL-SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True);break
 except Exception as e:
  failure={'terminal':False,'watch_error':repr(e),'polls_after_initial':sequence,'elapsed_s':time.time()-START,'last_state':old,'logs_or_artifact_redirect_requested':False};(P/'WATCH-ERROR.json').write_text(json.dumps(failure,indent=2)+'\n');print(json.dumps(failure),flush=True);break
else:pass
if not(P/'FINAL-SUMMARY.json').exists()and not(P/'WATCH-ERROR.json').exists():
 timeout={'terminal':False,'bounded_watch_expired':True,'run_id':39325858203,'head_sha':SHA,'polls_after_initial':sequence,'elapsed_s':time.time()-START,'last_state':old,'logs_or_artifact_redirect_requested':False};(P/'FINAL-SUMMARY.json').write_text(json.dumps(timeout,indent=2)+'\n');print(json.dumps(timeout),flush=True)
