# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only original support source ownership, not a new producer/model/scan.
Only old pure function definitions are replayed; every original Float32 corner
must equal the independently captured immutable parent. No SAT pair search.
"""
from pathlib import Path
import ast,json,math,struct,hashlib
import numpy as np
P=Path(__file__).parent;C=Path('/workspace/shared/horse-driving-girth-upper-attachments-actual-one/candidate');S=Path('/workspace/shared/horse-headgear-contour-candidate/source/generate_harness.original.py');A=S.with_name('harness.original.json');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((C/'capture/parent.json').read_bytes());raw=(C/'capture/parent.f64').read_bytes();assert hashlib.sha256(raw).hexdigest()==m['bufferSHA256'];actual=np.frombuffer(raw,dtype='<f8').reshape(-1,3,3)
selected={'vector','cross','unit','strap','smooth_route'};tree=ast.parse(S.read_text());functions=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in selected],type_ignores=[]);params=json.loads(A.read_bytes());scope={'math':math,'p':params,'leather':0,'mesh':lambda name,vs,faces,*args,**kwargs:(vs,faces)};exec(compile(functions,str(S)+'#old-pure-functions-only','exec'),scope)
report={'PASS':False,'scope':'READ_ONLY OLD support source corner replay/dimensions/endpoint diagnosis; no next material/evaluator/model/capture/SAT/browser','inputs':{str(p):sha(p)for p in[S,A,C/'capture/parent.json',C/'capture/parent.f64',C/'ACTUAL-IDLE-FIT.json']},'parts':{}}
for side,sign in[('l',1),('r',-1)]:
 name='breastcollar_support_'+side;route=scope['smooth_route']([[sign*v[0],v[1],v[2]]for v in params['breastcollar_support_route_m']]);vertices,faces=scope['strap'](name,route,.023,.004,width_axis=(0,0,1));expected=np.asarray(vertices,dtype='<f4').astype(float)[np.asarray(faces)];g=next(x for x in m['meshes']if x['name']==name);tri=actual[g['start']:g['start']+g['count']];assert np.array_equal(expected,tri),name
 # Dimensions are the old unrounded cross-section source parameters; the
 # installed model is triangle soup, not an actual source-index closure.
 rings=np.asarray(vertices).reshape(-1,4,3);widths=[float(np.linalg.norm(r[1]-r[0]))for r in rings];thickness=[float(np.linalg.norm(r[2]-r[1]))for r in rings];assert max(abs(x-.023)for x in widths)<1e-12 and max(abs(x-.004)for x in thickness)<1e-12
 row={'everyOriginalFloat32CornerExact':True,'capturedParentTriangles':g['count'],'originalSourceStations':len(route),'logicalVertices':len(vertices),'sourceWidthM':.023,'sourceThicknessM':.004,'actualParentIndexed':g['indexed'],'routeSourceKnots':[[sign*v[0],v[1],v[2]]for v in params['breastcollar_support_route_m']],'lastCenterlinePointM':route[-1],'lastRingFloat32':np.asarray(vertices[-4:],dtype='<f4').astype(float).tolist(),'padFrontSourceZM':-.005,'lastRingSignedPadFrontZM':[float(p[2]+.005)for p in np.asarray(vertices[-4:],dtype='<f4').astype(float)],'noOldEndpointCoordinateIsAnAttachmentProof':True}
 if side=='l':
  fi=145;row['failedFaceSource']={'actualFace':fi,'logicalIndices':faces[fi],'segment':fi//8,'sectionEdge':(fi%8)//2,'half':fi%2,'actualTriangle':tri[fi].tolist()}
 report['parts'][name]=row
report['PASS']=True;out=P/'EXISTING-SUPPORT-OWNERSHIP.json';assert not out.exists();out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'PASS':True,'output':str(out),'sha256':sha(out),'parts':{n:{k:r[k]for k in['capturedParentTriangles','originalSourceStations','lastRingSignedPadFrontZM']}for n,r in report['parts'].items()}}))
