# Fresh source-owned front-lip sections successor — SOURCE ONLY, NOT RUN

Original source8da034e1 passed independent full source review86a0a2dc, but its ONE
actual7de8 trial FAILED/incomplete at firstpropercrossing in16.205s. Fullfailed
capsule325efc9d/33950797B240files remainsimmutable. Passing419a remains the unchanged
engineeringreference; neither419a norfailed7de8 has natural/photo/motion acceptance.
No candidate/evaluator/P/N/JW/export/fit/SAT/capture/browser has run in this directory.

Concrete storedfirstwitness/sourceproposal15db0b48 diagnoses frontcap/underside
fold nearh684/h685, original8mmwide/4mmhigh collapsedcap and actual Xorderreversal.
A documentary read-only report initially bound barycentrics to wrongtriangle then
looked forhash in wrongscope; those two report-construction failures are preserved
in15db0b48 and didnot run geometry. CorrectreportbindsSECONDtriangle within2.22e-16m,
minbary0.007445 and signstraddle. They do not undermine the actual physical witness.

This fresh frozen successor keeps1368retirement/THREEroutes687/96/585,1984preserved
head incl128EXACTwetlining,112EXACTouter/portalboundary, all5360triangles/2735stencils,
all7344head/5488mouthsourceownership and normalfans, rig/storage/materials/bit,
allpredicates/full8+36gear+fullbit/078negative/readback/Khronos/capture guards.
Only the source-owned anterior lateral lipsection field is new: startnativez9=.505,
halfwidth.078, matchedposterior slope fromstations8/9, endnativez12=.54 with
fixednativez10halfwidth.048 and0frontslope. Positive monotone cubicHermite W(z),
scale sourceX byW/originalstationwidth before the unchangedLoop/real2.5mmgroove.
No groove-depth/radius/pose/predicate sweep, darkmask/occluder or contactexemption.
Width96mm is ORIGINAL AUTHOR reconstructed dimension, NOT measuredphoto/breeddata.
The existing chin/rim/groove and all modelguards are otherwise unchanged.

17 source-only controlsPASS: inherited13 plus scalarwidthendpoint/positive-global-
monotone Bernstein-hull/domain/foreignspeccontrols. NewP/N/JW remainUNEVALUATED.
ThreeNode executables are byte-identical to the reviewed predecessor, whose
syntax checks passed; no Node/model/browser operation was needed for this change.
Metadata-preserving7append serializer AST identical; caller180s/110sstructural,
exactbeforeafterpins/ownedchildgroupcleanup/CPU0/thread1/freshoutputs unchanged
apart the NEW rootrelease token. Exact executable diff is included.

Root has authorized source correction/full peer review ONLY after firstfailure.
IndependentFULLfrozenreview remains required. NO second actualtrial release
assumed; do not run until parent explicitly releases this fixed successor and
CPU0 lane. A future singletrial uses existing180s/110s structural caps and no
retry/extension, token ROOT_RELEASE_ONE_MUZZLE_FRONT_LIP_SECTIONS. No new app,
photographic/period/motion/unbitted/pressure/jaw-opening acceptance.
