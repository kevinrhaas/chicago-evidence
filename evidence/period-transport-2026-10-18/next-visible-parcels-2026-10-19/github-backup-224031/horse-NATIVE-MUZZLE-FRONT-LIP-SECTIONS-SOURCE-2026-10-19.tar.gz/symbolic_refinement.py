# SPDX-License-Identifier: GPL-3.0-or-later
"""Fixed constrained Loop INDEX/STENCIL proposal, never read/evaluate P/N/J/W."""
from pathlib import Path
import json,collections,math
from topology_guard import manifold
from diagnose_source_indices import rows,mouth,nostril,require
P=Path(__file__).parent
inside={g for g in mouth if rows[g]['owner']['source_owner']['kind']=='inner_labial_vestibule'}
require(len(inside)==128,'Exact old vestibule preservation')
native_source=json.loads(Path('/workspace/shared/horse-oral-channel-diagonal-candidate/source/frozen-head.json').read_text())
front={g for g,r in rows.items()if r['owner']['kind']=='baseline_head'and r['owner'].get('tag')in{'skin','lip_l','lip_r'}and all(264<=i<=696 for i in native_source['faces'][r['owner']['source_head_face']])}
require(len(front)==507,'Exact source front skin and residual lip faces, station4 through native tip')
retire=(mouth-inside)|nostril|front
require(len(retire)==1368,'Exact complete native muzzle exterior/nostril retirement')
faces=[rows[g]['aliases']for g in sorted(retire)]
E=collections.defaultdict(list);N=collections.defaultdict(set)
for gi,t in zip(sorted(retire),faces):
 for i,(a,b)in enumerate(zip(t,t[1:]+t[:1])):E[tuple(sorted((a,b)))].append((gi,a,b,t[(i+2)%3]));N[a].add(b);N[b].add(a)
boundary={e for e,uses in E.items()if len(uses)==1};boundaryV={v for e in boundary for v in e}
oldtp=manifold(faces,boundary,-1)
require(oldtp['boundary']==112,'48 exact station4 edges plus64 protected portal edges')
allV=set(N)
def native(i):
 matches={v for v in allV if v in{'h:'+str(i),'labial-native:'+str(i)}}
 require(len(matches)==1,'One actual native alias for seam '+str(i));return next(iter(matches))
def corner_path(start,target,side):
 allowed={v for v in N if v.startswith('labial:'+side+':')}|{target};q=collections.deque([[start]]);seen={start}
 while q:
  path=q.popleft()
  if path[-1]==target:return path
  for v in sorted(N[path[-1]]&allowed-seen):seen.add(v);q.append(path+[v])
 raise ValueError('No fixed source corner path')
left=corner_path('labial:l:portal:28',native(437),'l')+[native(i)for i in[485,533,581,629,677]]
frontpath=[native(i)for i in range(678,692)]
right=[native(i)for i in[643,595,547,499,451]]+list(reversed(corner_path('labial:r:portal:4',native(452),'r')))
paths=[left+frontpath+right]
require(len(set(paths[0]))==len(paths[0]),'One simple portal-to-portal apposed lip crease')
crease={tuple(sorted((a,b)))for path in paths for a,b in zip(path,path[1:])}
require(crease<=set(E)and not crease&boundary and len(crease)==len(paths[0])-1,'Exact existing source lip-path edges')
sharp=collections.defaultdict(set)
for a,b in crease:sharp[a].add(b);sharp[b].add(a)
def even(v):return v if v in boundaryV else'muzzle:even:'+v
def odd(e):return'muzzle:edge:'+e[0]+'|'+e[1]
stencils={};details={}
for v in sorted(N):
 if v in boundaryV or len(sharp[v])not in(0,2):
  w={v:1.};kind='exact boundary or sharp endpoint'
 elif len(sharp[v])==2:
  w={v:.75,**{q:.125 for q in sorted(sharp[v])}};kind='cubic source lip crease'
 else:
  n=len(N[v]);require(n>=3,'Interior valence');beta=(5/8-(3/8+math.cos(2*math.pi/n)/4)**2)/n
  w={v:1-n*beta,**{q:beta for q in sorted(N[v])}};kind='original Loop even mask'
 stencils[even(v)]=w;details[even(v)]={'kind':kind,'valence':len(N[v])}
for e,uses in sorted(E.items()):
 if e in boundary:continue
 if e in crease:w={e[0]:.5,e[1]:.5};kind='source lip crease midpoint'
 else:
  require(len(uses)==2,'Two actual interior opposites');w={e[0]:3/8,e[1]:3/8}
  for use in uses:w[use[3]]=w.get(use[3],0)+1/8
  kind='original Loop odd mask'
 stencils[odd(e)]=w;details[odd(e)]={'kind':kind,'source_edge':list(e)}
for tag,w in stencils.items():require(w and min(w.values())>0 and abs(sum(w.values())-1)<=4e-16,'Finite convex coefficient partition '+tag)
new=[];owners=[]
for g in sorted(retire):
 t=rows[g]['aliases'];splits=[tuple(sorted((t[i],t[(i+1)%3])))not in boundary for i in range(3)];n=sum(splits)
 if n==0:parts=[[even(v)for v in t]]
 elif n==1:
  k=splits.index(True);a,b,c=t[k:]+t[:k];m=odd(tuple(sorted((a,b))));a,b,c=map(even,[a,b,c]);parts=[[a,m,c],[m,b,c]]
 elif n==2:
  k=(splits.index(False)+1)%3;a,b,c=t[k:]+t[:k];ab=odd(tuple(sorted((a,b))));bc=odd(tuple(sorted((b,c))));a,b,c=map(even,[a,b,c]);parts=[[b,bc,ab],[a,ab,bc],[a,bc,c]]
 else:
  a,b,c=map(even,t);ab,bc,ca=[odd(tuple(sorted((t[i],t[(i+1)%3]))))for i in range(3)];parts=[[a,ab,ca],[ab,b,bc],[ca,bc,c],[ab,bc,ca]]
 for f in parts:new.append(f);owners.append({'kind':'source_constrained_muzzle','parent419a_face':g,'original_source_owner':rows[g]['owner'],'material':1 if rows[g]['primitive']==[1,0]else 0})
newtp=manifold(new,boundary,-1)
require(newtp['F']==4*len(retire)-len(boundary),'Adaptive split count')
head={g for g,r in rows.items()if r['owner']['kind']in{'baseline_head','baseline_ear','natural_labial','radial_bridge','skull_complement'}}
require(len(head)==3352 and retire<=head,'Exact full source head ownership')
kept=sorted(head-retire);neck=[24]+list(range(13))+[36]+list(range(60,72))+[48];neck=['h:'+str(x)for x in neck];neckedges={tuple(sorted(e))for e in zip(neck,neck[1:]+neck[:1])}
headtp=manifold([rows[g]['aliases']for g in kept]+new,neckedges,-1)
require(len(kept)==1984 and headtp['F']==7344 and len(new)+len(inside)==5488 and len(rows)-len(retire)+len(new)==17448,'Derived complete scope counts')
newcrease=set()
for e in crease:
 m=odd(e)
 for v in e:newcrease.add(tuple(sorted((even(v),m))))
result={'status':'SOURCE_INDEX_AND_COEFFICIENT_PROOF_ONLY_NO_XYZ','parent419a_sha256':'419a6194b660bcd9ab1f7da21a2b1fcbd67d9ba620d294fd6299440dc8890c31','retirement':sorted(retire),'preserved_head1984':kept,'preserved_inner_vestibule128':sorted(inside),'source_boundary112':[list(e)for e in sorted(boundary)],'old_patch_topology':oldtp,'proposed_patch_topology':newtp,'proposed_full_head_topology':headtp,'proposed_full_model_faces':17448,'proposed_mouth_including_preserved_vestibule_faces':5488,'neck_boundary':neck,'fixed_existing_lip_paths':paths,'refined_lip_crease_edges':[list(e)for e in sorted(newcrease)],'stencils':stencils,'stencil_authority':details,'proposed_faces':new,'proposed_face_owners':owners,'no_claim':['This file defines topology/stencils only; authored source chin/rim/groove field is separate and unexecuted','No photographically measured surface/neutral bit pressure','No new XYZ/normal/JW evaluation/export/guard/capture','No source caller release from this partial planning package']}
# Source scalar/semantic annotations, never evaluate any proposed coordinate.
rim={}
for record in native_source['records']:
 if record['kind']!='recess':continue
 sign=1 if record['name']=='nostril_1'else-1
 aperture={native(i)for i in record['aperture']}
 for v in aperture:
  require(v not in rim or rim[v]==sign,'Disjoint nostril sides');rim[v]=sign
 for v in {x for a in aperture for x in N[a]}-aperture:
  require(v not in rim or rim[v]==sign/2,'Disjoint rim skirts');rim[v]=sign/2
base=json.loads(Path('/workspace/shared/horse-oral-channel-diagonal-candidate/source/parameters.json').read_text())['head_surface_reconstruction_trial']
require({r['maximum_authored_depth_m']for r in native_source['records']if r['kind']=='continuous_closed_lip_groove'}=={.0025},'One existing authored soft tissue depth')
mouthtp=manifold([rows[g]['aliases']for g in sorted(inside)]+new,{tuple(sorted(e))for e in zip(['h:'+str(i)for i in range(264,312)],['h:'+str(i)for i in list(range(265,312))+[264]])},-1)
require(mouthtp=={'V':2767,'E':8256,'F':5488,'Euler':-1,'boundary':48,'connected':True,'directed_manifold':True},'Exact amended complete mouth+nostril scope')
result['proposed_complete_mouth_scope_topology']=mouthtp
result['source_signed_nostril_rim_weights']=rim
result['source_lip_path_groove_strength']={v:(0 if v.startswith('labial:')else 1)for v in paths[0]}
result['geometry_parameters']={'frame_origin':[0,1.88,.8],'native_stations':base['stations'],'anterior_lobe_start_z':base['stations'][7]['z'],'anterior_lobe_end_z':base['stations'][-1]['z'],'chin_down_scale_from_station8_height':'1/6','chin_forward_scale_of_down':'1/2','soft_tissue_depth_m':.0025,'anatomical_authority':'Original authored source-scaled reconstruction, qualitative comparison only; dimensions/ratios NOT photographic metric evidence; one fixed field, no search'}
result['geometry_parameters']['front_lip_sections']={'start_station':9,'anterior_station':12,'width_anchor_station':10,'posterior_slope_pair':[8,9],'anterior_slope':0.}
(P/'PROPOSED-INDEX-AND-STENCIL-PROOF.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'old':oldtp,'new':newtp,'fullhead':headtp,'oldprotectedvestibule':len(inside),'model_faces':17448,'stencils':len(stencils),'crease_edges':len(newcrease)},indent=2))
