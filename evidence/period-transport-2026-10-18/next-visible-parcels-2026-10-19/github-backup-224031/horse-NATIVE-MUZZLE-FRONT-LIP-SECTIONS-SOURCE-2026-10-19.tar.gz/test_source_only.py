"""Source-index and wholly synthetic AST controls only. No actual P/model import."""
from pathlib import Path
import ast,json,copy,types,collections,math
from topology_guard import manifold
P=Path(__file__).parent
A=json.loads((P/'PROPOSED-INDEX-AND-STENCIL-PROOF.json').read_text());tree=ast.parse((P/'conforming_variant.py').read_text());rows=[]
def require(v,m):
 if not v:raise ValueError(m)
def passed(name,fn):fn();rows.append({'name':name,'PASS':True})
def reject(fn):
 try:fn()
 except(ValueError,AssertionError):return
 raise ValueError('Negative control accepted')
def compile_fn(name,env):
 node=next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name==name);m=ast.Module(body=[node],type_ignores=[]);exec(compile(m,'<exact-source-AST>','exec'),env);return env[name]
bd={tuple(e)for e in A['source_boundary112']}
passed('Complete exact actual-source symbolic patch vertex links/edges',lambda:require(manifold(A['proposed_faces'],bd,-1)==A['proposed_patch_topology'],'topology'))
for name,faces in [('Flipped oriented triangle',[A['proposed_faces'][0][::-1]]+A['proposed_faces'][1:]),('Dropped triangle',A['proposed_faces'][1:]),('Duplicated triangle',A['proposed_faces']+[A['proposed_faces'][0]])]:passed(name+' rejected',lambda f=faces:reject(lambda:manifold(f,bd,-1)))
def coefficient_check(stencils):
 known={x for w in A['stencils'].values()for x in w}
 for tag,w in stencils.items():require(w and set(w)<=known and min(w.values())>0 and all(math.isfinite(x)for x in w.values())and abs(sum(w.values())-1)<=4e-16,'Convex exact source coefficient contract')
passed('All2735 source convex partitions',lambda:coefficient_check(A['stencils']))
for name,change in [('negative',lambda w:w.update({next(iter(w)):-1})),('foreign',lambda w:w.update({'foreign-source':1})),('unnormalized',lambda w:w.update({next(iter(w)):2}))]:
 def one(change=change):
  d=copy.deepcopy(A['stencils']);change(next(iter(d.values())));reject(lambda:coefficient_check(d))
 passed('Corrupt '+name+' stencil rejected',one)
normal_fans=compile_fn('normal_fans',{'collections':collections,'require':require})
def normal_case(crease,expected):
 model={'proposed_faces':[['a','b','c'],['b','a','d']],'refined_lip_crease_edges':crease};g=normal_fans(model);require((g[0,'a']!=g[1,'a'])==expected,'Exact synthetic normal fan partition')
passed('Wholly synthetic shared smooth normal fan joins',lambda:normal_case([],False))
passed('Wholly synthetic true crease normal fan splits',lambda:normal_case([['a','b']],True))
oldtree=ast.parse(Path('/workspace/shared/horse-natural-labial-corner-three-primitives-next/conforming_variant.py').read_text());oldserialize=next(x for x in oldtree.body if isinstance(x,ast.FunctionDef)and x.name=='serialize');newserialize=next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name=='serialize')
passed('Reviewed metadata-preserving7append serializer AST unchanged',lambda:require(ast.dump(oldserialize)==ast.dump(newserialize),'serialize AST equality'))
# Full caller AST excluding token/status/docstring values must preserve the old executable shape.
oldcaller=ast.parse(Path('/workspace/shared/horse-natural-labial-corner-three-primitives-next/run_once.py').read_text());newcaller=ast.parse((P/'run_once.py').read_text())
class Names(ast.NodeTransformer):
 def visit_Constant(self,node):
  if isinstance(node.value,str):
   val=node.value.replace('ROOT_RELEASE_ONE_NATURAL_LABIAL_CORNER','ROOT_RELEASE_ONE_MUZZLE_FRONT_LIP_SECTIONS').replace('neutral bitted natural-labial trial','neutral bitted source-owned lip/chin/nostril trial');return ast.copy_location(ast.Constant(val),node)
  return node
passed('180s caller executable exactly old reviewed caller apart from token/status',lambda:require(ast.dump(Names().visit(oldcaller))==ast.dump(newcaller),'caller exact normalized AST'))
front=compile_fn('front_lip_halfwidth',{'math':math,'require':require})
params=A['geometry_parameters'];stations=params['native_stations'];start=stations[9]['z'];end=stations[12]['z'];width0=stations[9]['half_width'];width1=stations[10]['half_width'];slope=(width0-stations[8]['half_width'])/(start-stations[8]['z']);span=end-start
passed('Fixed source scalar Hermite width endpoints',lambda:require(abs(front(start,params)-width0)<1e-15 and abs(front(end,params)-width1)<1e-15,'Exact source width endpoints'))
passed('Hermite Bernstein controls prove positive globally monotone width',lambda:require(width0>=width0+span*slope/3>=width1>0,'Analytic monotonic convex hull, no sweep'))
passed('Scalar width domain rejects posterior/outside source',lambda:(reject(lambda:front(start-.01,params)),reject(lambda:front(end+.01,params))))
passed('Scalar section rejects foreign anatomical specification',lambda:reject(lambda:front(end,{**params,'front_lip_sections':{**params['front_lip_sections'],'width_anchor_station':11}})))
for fn in P.rglob('*.py'):ast.parse(fn.read_text())
rows.append({'name':'All Python source syntax parses without imports/geometry','PASS':True})
report={'PASS':True,'scope':'Source index topology/convex scalar stencils and two wholly synthetic normalfan fixtures; metadata-preserving serializer and unchanged bounded caller AST. Only endpoint/source-scalar width controls added. NO proposed P/N/JW/model/evaluator/import/collision/capture/browser executed.','controls':rows}
(P/'SOURCE-ONLY-CONTROLS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
