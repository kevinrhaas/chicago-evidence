# SPDX-License-Identifier: GPL-3.0-or-later
"""One fixed source-owned anatomical lip/chin/nostril trial. Import evaluates no model."""
from pathlib import Path
import sys,json,hashlib,copy,collections,math
import numpy as np
HELP=Path('/workspace/shared/horse-neck-hybrid-pipeline-next')
sys.path.insert(1,str(HELP))
from ownership import Model,ATTRS
from glb_data import append,encode
from topology_guard import manifold
P=Path(__file__).parent
OLD=Path('/workspace/shared/horse-natural-labial-corner-three-primitives-next/candidate-one')
PARENT='419a6194b660bcd9ab1f7da21a2b1fcbd67d9ba620d294fd6299440dc8890c31'
def require(value,message):
 if not value:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def load():
 for manifest in['LOCAL-PINS.json','EXTERNAL-HASHES.json']:
  for name,digest in json.loads((P/manifest).read_text()).items():
   path=P/name if manifest=='LOCAL-PINS.json'else Path(name);require(sha(path.read_bytes())==digest,'Exact frozen source/input '+name)
 raw=(OLD/'candidate.glb').read_bytes();require(sha(raw)==PARENT,'Immutable419a parent');m=Model(raw);rb=json.loads((OLD/'readback.json').read_text());require(rb['PASS']is True and rb['candidate_sha256']==PARENT,'Stored parent decoded identity')
 labels={(r['mesh'],r['vertex']):r['label']for r in rb['source_labels']};owners={int(k):v for k,v in rb['source_face_owners'].items()};A=json.loads((P/'PROPOSED-INDEX-AND-STENCIL-PROOF.json').read_text());retired=set(A['retirement']);preserved=set(A['preserved_head1984']);inside=set(A['preserved_inner_vestibule128']);head=retired|preserved
 require(m.total==13456 and len(retired)==1368 and len(preserved)==1984 and len(head)==3352 and inside<=preserved and len(inside)==128 and not retired&preserved,'Exact complete old head/retirement/preservation')
 require(A['parent419a_sha256']==PARENT and len(A['proposed_faces'])==len(A['proposed_face_owners'])==5360 and A['proposed_full_model_faces']==17448,'Exact reviewed source proposal')
 require(A['proposed_patch_topology']=={'V':2735,'E':8096,'F':5360,'Euler':-1,'boundary':112,'connected':True,'directed_manifold':True},'Exact fixed patch topology')
 require(collections.Counter((m.descriptor(g)['mesh'],m.descriptor(g)['primitive'])for g in retired)=={(0,0):687,(1,0):96,(1,1):585},'Three actual source primitive routes')
 require(all(m.views[1,0]['attributes'][a].tobytes()==m.views[1,1]['attributes'][a].tobytes()for a in ATTRS),'Shared original head attributes')
 skin=m.d['skins'][0];palette=[m.d['nodes'][i]['name']for i in skin['joints']];require(palette.count('head')==1,'Actual head joint');scopes={k:{g for g,o in owners.items()if o['kind']==v}for k,v in[('hybrid','hybrid_neck'),('mane','fitted_mane')]};require(len(scopes['hybrid'])==1492 and len(scopes['mane'])==456,'Unchanged hybrid/mane')
 return dict(model=m,raw=raw,labels=labels,owners=owners,A=A,retired=retired,preserved=preserved,inside=inside,head=head,palette=palette,scopes=scopes)
def front_lip_halfwidth(z,params):
 """One original authored Hermite lip width; scalar only, no geometry search."""
 stations=params['native_stations'];spec=params['front_lip_sections'];require(spec=={'start_station':9,'anterior_station':12,'width_anchor_station':10,'posterior_slope_pair':[8,9],'anterior_slope':0.},'Exact fixed source section authority')
 a=stations[spec['start_station']];end=stations[spec['anterior_station']];anchor=stations[spec['width_anchor_station']];before=stations[spec['posterior_slope_pair'][0]];span=end['z']-a['z'];require(span>0 and a['z']<=z<=end['z'],'Only fixed anterior source domain');t=(z-a['z'])/span;m0=(a['half_width']-before['half_width'])/(a['z']-before['z']);h00=2*t**3-3*t**2+1;h10=t**3-2*t**2+t;h01=-2*t**3+3*t**2
 width=h00*a['half_width']+h10*span*m0+h01*anchor['half_width'];require(math.isfinite(width)and width>0,'Finite positive authored lip section');return width
def chin_field(local,params):
 """Fixed artist reconstruction; source-relative dimensions, no photograph metric claim."""
 z=float(local[2]);start=params['anterior_lobe_start_z'];end=params['anterior_lobe_end_z']
 if z<=start:return np.array(local,dtype=float)
 require(z<=end+1e-6,'Native anterior source bound');zq=min(z,end);stations=params['native_stations'];pair=next(((a,b)for a,b in zip(stations,stations[1:])if a['z']<=zq<=b['z']),None);require(pair is not None,'Original station interpolation')
 a,b=pair;f=(zq-a['z'])/(b['z']-a['z']);top=(1-f)*a['top_y']+f*b['top_y'];bottom=(1-f)*a['bottom_y']+f*b['bottom_y'];radius=(top-bottom)/2;cy=(top+bottom)/2;require(radius>0,'Positive native section');lower=max(0.,-(float(local[1])-cy)/radius)**2;t=(zq-start)/(end-start);s=t*t*(3-2*t);amplitude=(stations[8]['top_y']-stations[8]['bottom_y'])/6
 require(math.isfinite(lower)and lower<=1.0001 and 0<=t<=1,'Unaltered source section ownership');out=np.array(local,dtype=float);out[1]-=amplitude*s*s*lower;out[2]+=amplitude/2*math.sin(math.pi*t)**2*lower
 if zq>stations[9]['z']:
  native_width=(1-f)*a['half_width']+f*b['half_width'];require(native_width>0,'Original source section width');out[0]*=front_lip_halfwidth(zq,params)/native_width
 return out

def fields(ctx):
 """Actual evaluation only after root release: source basis, fixed tissue field, crease."""
 m=ctx['model'];A=ctx['A'];source=collections.defaultdict(list);boundary={x for e in A['source_boundary112']for x in e};boundary_rows={};source_rows={};proof={}
 for key,v in m.views.items():
  for i in set(map(int,v['indices'].ravel())):source[ctx['labels'][key[0],i]].append((key,i))
 for g in sorted(ctx['retired']):
  d=m.descriptor(g);key=d['mesh'],d['primitive']
  for i in d['primitive_vertices']:
   tag=ctx['labels'][key[0],i]
   if tag in boundary:boundary_rows.setdefault(tag,(key,i,g))
 basis={v for w in A['stencils'].values()for v in w};params=A['geometry_parameters'];origin=np.array(params['frame_origin'],float);depth=params['soft_tissue_depth_m'];require(depth==.0025,'Exact existing authored soft-tissue depth')
 for tag in sorted(basis):
  require(source[tag],'Active actual source alias '+tag);key,i=source[tag][0];a=m.views[key]['attributes'];rec={k:a[k][i].copy()for k in ATTRS}
  for kk,ii in source[tag]:
   for k in['POSITION','JOINTS_0','WEIGHTS_0']:require(m.views[kk]['attributes'][k][ii].tobytes()==rec[k].tobytes(),'All old source aliases actual PJW exact '+tag)
  source_rows[tag]=rec;proof[tag]={'source_mesh':key[0],'source_primitive':key[1],'source_vertex':i,'actual_PJW_sha256':{k:sha(rec[k].tobytes())for k in['POSITION','JOINTS_0','WEIGHTS_0']}}
 warped={tag:chin_field(rec['POSITION'].astype(float)-origin,params)+origin+np.array([depth*A['source_signed_nostril_rim_weights'].get(tag,0),0,0])for tag,rec in source_rows.items()}
 points={tag:(source_rows[tag]['POSITION'].astype(float)if tag in boundary else sum((weight*warped[v]for v,weight in w.items()),np.zeros(3)))for tag,w in A['stencils'].items()}
 # One geometric groove in the continuous tissue, not dark paint or a hidden cap.
 crease={x for e in A['refined_lip_crease_edges']for x in e};normals={tag:np.zeros(3)for tag in points}
 for t in A['proposed_faces']:
  aa,bb,cc=[points[x]for x in t];n=np.cross(bb-aa,cc-aa)
  for x in t:normals[x]+=n
 groove={}
 for tag in sorted(crease):
  strength=sum(w*A['source_lip_path_groove_strength'].get(v,0)for v,w in A['stencils'][tag].items());groove[tag]=strength
  if tag in boundary:require(strength==0,'Fixed actual portal and station boundary');continue
  n=normals[tag];require(np.isfinite(n).all()and np.linalg.norm(n)>1e-12,'Unambiguous source crease outward normal');points[tag]=points[tag]-depth*strength*n/np.linalg.norm(n)
 head=ctx['palette'].index('head');JW=([head,0,0,0],[1.,0.,0.,0.]);records={}
 for tag,p in points.items():
  require(np.isfinite(p).all(),'Finite fixed proposed tissue field')
  if tag in boundary:
   key,i,g=boundary_rows[tag];a=m.views[key]['attributes'];require(np.array_equal(p,a['POSITION'][i].astype(float)),'All112 boundary actual P exact');records[tag]=(p,a['JOINTS_0'][i].tolist(),a['WEIGHTS_0'][i].tolist(),a['NORMAL'][i].astype(float));proof[tag]['boundary_normal_source']={'mesh':key[0],'primitive':key[1],'vertex':i,'retired_boundary_face':g}
  else:records[tag]=(p,JW[0],JW[1],None)
 return records,{'source_basis':proof,'geometry_parameters':params,'crease_depth_strength':groove,'source_recipe':'One convex source stencil refinement of fixed source-width anterior lip section, chin lobe and rounded nostril rim, then one continuous2.5mm maximum closed lip groove; neutral bitted reconstruction'}

def normal_fans(A):
 """True crease normals are split by actual topological fans, never by a color mask."""
 incident=collections.defaultdict(list);edges=collections.defaultdict(list);crease={tuple(e)for e in A['refined_lip_crease_edges']}
 for fi,t in enumerate(A['proposed_faces']):
  for v in t:incident[v].append(fi)
  for a,b in zip(t,t[1:]+t[:1]):edges[tuple(sorted((a,b)))].append(fi)
 groups={}
 for v,ids in incident.items():
  ids=set(ids);neighbors=collections.defaultdict(set)
  for fi in ids:
   for u in A['proposed_faces'][fi]:
    e=tuple(sorted((v,u)))
    if u==v or e in crease:continue
    for other in edges[e]:neighbors[fi].add(other)
  todo=set(ids);fan=0
  while todo:
   pending=[min(todo)];seen=set()
   while pending:
    fi=pending.pop()
    if fi in seen:continue
    seen.add(fi);pending.extend(neighbors[fi]-seen)
   require(seen<=ids,'Normal fan incidence');todo-=seen
   for fi in seen:groups[fi,v]=fan
   fan+=1
 return groups

def evaluate(ctx):
 m=ctx['model'];A=ctx['A'];old=m.views[1,0]['attributes'];records,sourceproof=fields(ctx);fans=normal_fans(A);boundary={x for e in A['source_boundary112']for x in e};arrays={k:old[k].copy().tolist()for k in ATTRS};copies={};newlabels={};newfaces=[];sums={};keeps={key:[i for i in range(len(v['indices']))if m.start[key]+i not in ctx['retired']]for key,v in m.views.items()}
 for ai,(t,owner)in enumerate(zip(A['proposed_faces'],A['proposed_face_owners'])):
  material=owner['material'];ids=[]
  for tag in t:
   key=material,tag,fans[ai,tag]
   if key not in copies:
    rec=records[tag];i=len(arrays['POSITION']);copies[key]=i;newlabels[str(i)]=tag;arrays['POSITION'].append(rec[0].tolist());arrays['JOINTS_0'].append(rec[1]);arrays['WEIGHTS_0'].append(rec[2]);arrays['NORMAL'].append([1.,0.,0.])
   ids.append(copies[key])
  pos=np.asarray([arrays['POSITION'][i]for i in ids],dtype='<f4').astype(float);n=np.cross(pos[1]-pos[0],pos[2]-pos[0]);require(np.isfinite(n).all()and np.linalg.norm(n)>2e-12,'Actual serialized finite nondegenerate triangle')
  for tag in t:sums.setdefault((tag,fans[ai,tag]),np.zeros(3));sums[tag,fans[ai,tag]]+=n
  newfaces.append({'assembly_face':ai,'material':material,'indices':ids,'source_labels':t,'source_owner':owner})
 for(mat,tag,fan),i in copies.items():
  n=records[tag][3]if tag in boundary else sums[tag,fan];require(n is not None and np.isfinite(n).all()and np.linalg.norm(n)>1e-12,'Valid real geometry normal');arrays['NORMAL'][i]=(n if tag in boundary else n/np.linalg.norm(n)).tolist()
 arrays={k:np.asarray(v,dtype=old[k].dtype)for k,v in arrays.items()};require(all(np.isfinite(v).all()for v in arrays.values())and np.all(abs(np.linalg.norm(arrays['NORMAL'].astype(float),axis=1)-1)<2e-5),'All finite attributes/unit normals');idx={}
 for key in[(1,0),(1,1)]:
  mat=1 if key==(1,0)else 0;addition=np.asarray([r['indices']for r in newfaces if r['material']==mat],dtype='<u4');idx[key]=np.vstack((m.views[key]['indices'][keeps[key]],addition))
 idx[0,0]=m.views[0,0]['indices'][keeps[0,0]].copy()
 detail={'retired_current_faces':sorted(ctx['retired']),'preserved_head1984':sorted(ctx['preserved']),'old_keep':{str(k[0])+':'+str(k[1]):v for k,v in keeps.items()},'new_labels':newlabels,'new_faces':newfaces,'new_source_proof':sourceproof,'normal_authority':'All112 boundary copies retain parent actual source normal; every interior fan derived from actual binary32 faces, shared across material copies','status':'UNACCEPTED original reconstructed lip/chin/nostril geometry; all actual guards/appearance pending'}
 return arrays,idx,detail

def serialize(ctx,arrays,idx):
 old=ctx['model'];d=copy.deepcopy(old.d);b=bytearray(old.b);refs={}
 for k in ATTRS:refs[k]=append(d,b,arrays[k],'VEC4'if k in['JOINTS_0','WEIGHTS_0']else'VEC3',comp=5123 if k=='JOINTS_0'else 5126)
 for key in[(1,0),(1,1)]:
  primitive=d['meshes'][key[0]]['primitives'][key[1]];primitive['attributes']=dict(refs);primitive['indices']=append(d,b,idx[key].reshape(-1),'SCALAR',comp=5125,target=34963)
 d['meshes'][0]['primitives'][0]['indices']=append(d,b,idx[0,0].reshape(-1),'SCALAR',comp=5125,target=34963)
 return encode(d,b)
def authority(ctx):return{'parent_sha256':PARENT,'retirement1368':sorted(ctx['retired']),'preserved1984':sorted(ctx['preserved']),'protected_vestibule128':sorted(ctx['inside']),'boundary112':ctx['A']['source_boundary112'],'topology':ctx['A']['proposed_patch_topology'],'geometry':'One source-owned lip/chin/nostril reconstruction; fixed existing physical bit/portals and continuous anatomical skin, no hidden mask or plane','guard':'All original8 complete scopes/all36gear/fullbit/oldnegative unchanged predicates; expanded complete5488 mouth+nostril cohort and7344 head','status':'No natural/photo/motion/pressure/period/unbitted/jaw-opening acceptance'}

def audit(raw,ctx,proof):
 old=ctx['model'];require(proof.get('candidate_sha256')==sha(raw),'Actual candidate identity');a,idx,detail=evaluate(ctx);require(proof['detail']==detail and proof['authority']==authority(ctx),'Exact fixed source/owner proof');require(raw==serialize(ctx,a,idx),'Exact actual serialized intended recipe');new=Model(raw);require(set(new.views)==set(old.views)and new.total==17448,'Same complete primitive/material roles and exact total')
 for key,v in old.views.items():
  w=new.views[key];require(w['material']==v['material'],'All material roles exact')
  if key not in[(1,0),(1,1),(0,0)]:require(w['indices'].tobytes()==v['indices'].tobytes(),'All unaffected primitive indices exact')
  for k in ATTRS:require(w['attributes'][k][:len(v['attributes'][k])].tobytes()==v['attributes'][k].tobytes(),'EVERY original stored attribute row exact')
 require(new.b[:len(old.b)]==old.b,'Old BIN prefix exact');require(new.d['accessors'][:len(old.d['accessors'])]==old.d['accessors']and new.d['bufferViews'][:len(old.d['bufferViews'])]==old.d['bufferViews'],'All old accessor/view metadata prefix exact');require(len(new.d['accessors'])==len(old.d['accessors'])+7 and len(new.d['bufferViews'])==len(old.d['bufferViews'])+7,'Exactly4 attributes+3 indices append')
 docs=[copy.deepcopy(x.d)for x in[old,new]]
 for d in docs:
  d.pop('accessors');d.pop('bufferViews');d['buffers'][0].pop('byteLength')
  for mi,pi in[(1,0),(1,1)]:d['meshes'][mi]['primitives'][pi].pop('attributes');d['meshes'][mi]['primitives'][pi].pop('indices')
  d['meshes'][0]['primitives'][0].pop('indices')
 require(docs[0]==docs[1],'Every other doc/unknown extras/rig/nodes/actions/material property exact');remap={};owners={};head=set();scopes={k:set()for k in ctx['scopes']};scopes['lips']=set();labels={}
 for key,v in old.views.items():
  for ni,oi in enumerate(detail['old_keep'][str(key[0])+':'+str(key[1])]):
   og=old.start[key]+oi;ng=new.start[key]+ni;require(og not in ctx['retired'],'Retirement exact');require(v['indices'][oi].tobytes()==new.views[key]['indices'][ni].tobytes(),'Every preserved oriented triangle exact');remap[og]=ng;owners[ng]=ctx['owners'][og]
   if og in ctx['preserved']:head.add(ng)
   if og in ctx['inside']:scopes['lips'].add(ng)
   for name,cohort in ctx['scopes'].items():
    if og in cohort:scopes[name].add(ng)
 require(set(remap)==set(range(old.total))-ctx['retired'],'Complete old retirement/preservation ledger')
 for key,v in new.views.items():
  for i in set(map(int,v['indices'].ravel())):labels[key[0],i]=detail['new_labels'].get(str(i),ctx['labels'].get((key[0],i),'body:'+str(key[0])+':'+str(i)))if key[0]==1 else ctx['labels'][key[0],i]
 cursors={1:len(detail['old_keep']['1:0']),0:len(detail['old_keep']['1:1'])}
 for row in detail['new_faces']:
  mat=row['material'];key=(1,0)if mat==1 else(1,1);ng=new.start[key]+cursors[mat];cursors[mat]+=1;require(new.views[key]['indices'][ng-new.start[key]].tolist()==row['indices'],'New actual source owner exact');owners[ng]={'kind':'natural_muzzle','assembly_face':row['assembly_face'],'source_owner':row['source_owner']};head.add(ng);scopes['lips'].add(ng)
 require(set(owners)==set(range(new.total))and len(head)==7344 and len(scopes['lips'])==5488 and len(scopes['hybrid'])==1492 and len(scopes['mane'])==456,'Complete active model and eight source cohorts');new.source_face_owners=owners
 def tags(g):
  desc=new.descriptor(g);return[labels[desc['mesh'],i]for i in desc['primitive_vertices']]
 bd={tuple(e)for e in ctx['A']['source_boundary112']};appended=set(head)-set(remap[g]for g in ctx['preserved']);require(manifold([tags(g)for g in sorted(appended)],bd,-1)==ctx['A']['proposed_patch_topology'],'Full decoded new patch vertex links/topology')
 neck=ctx['A']['neck_boundary'];nb={tuple(sorted(e))for e in zip(neck,neck[1:]+neck[:1])};require(manifold([tags(g)for g in sorted(head)],nb,-1)==ctx['A']['proposed_full_head_topology'],'Complete decoded head vertex links/topology');loop=['h:'+str(i)for i in range(264,312)];mb={tuple(sorted(e))for e in zip(loop,loop[1:]+loop[:1])};require(manifold([tags(g)for g in sorted(scopes['lips'])],mb,-1)==ctx['A']['proposed_complete_mouth_scope_topology'],'Complete decoded mouth/nostril scope topology')
 report={'PASS':True,'candidate_sha256':sha(raw),'old_to_new':{str(k):v for k,v in sorted(remap.items())},'source_face_owners':{str(k):v for k,v in sorted(owners.items())},'source_labels':[{'mesh':mi,'vertex':i,'label':v}for(mi,i),v in sorted(labels.items())],'head_faces':len(head),'newlip_faces':len(scopes['lips']),'source_scope':'Decoded full intended P/N/J/W/indices, exact old storage/rig and explicit ownership; actual engineering/visual guards pending'}
 return new,labels,head,owners,scopes,report

def produce(path):
 out=Path(path);out.mkdir(parents=True,exist_ok=False);stage='load';receipt={'PASS':False,'stage':stage,'status':'ONE unaccepted source-owned lip/chin/nostril trial'}
 try:
  ctx=load();stage='evaluate';a,idx,detail=evaluate(ctx);stage='serialize';raw=serialize(ctx,a,idx);(out/'UNVALIDATED-candidate.glb').write_bytes(raw);proof={'candidate_sha256':sha(raw),'authority':authority(ctx),'detail':detail};stage='source_readback';*_,rb=audit(raw,ctx,proof);(out/'candidate.glb').write_bytes(raw);(out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');(out/'readback.json').write_text(json.dumps(rb,indent=2)+'\n');receipt.update(PASS=True,stage='source_readback_complete',candidate_sha256=sha(raw))
 except BaseException as exc:receipt.update(stage=stage,error=repr(exc));raise
 finally:(out/'FIRST-TRIAL-SOURCE.json').write_text(json.dumps(receipt,indent=2)+'\n')
 return receipt
if __name__=='__main__':print(json.dumps(produce(sys.argv[1])))
