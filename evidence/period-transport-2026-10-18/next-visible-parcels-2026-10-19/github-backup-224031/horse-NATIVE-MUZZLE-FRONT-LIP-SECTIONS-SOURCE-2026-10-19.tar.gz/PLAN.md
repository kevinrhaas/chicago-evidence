# One original anatomical lip, chin and nostril correction

419a is a complete bounded idle engineering PASS. Its horse-only and actually
fitted-bit photographs both remain UNACCEPTED as natural/photographic anatomy.
The mouth rectangle/bands are gone. The native muzzle is still flat/blunt, its
lip is a broad weak dimple, and its nostril is polygonal. Those actual images,
prior failures and immutable419a GLB remain unchanged.

## Actually viewed photographic authority

Reopened Henry2008/NeilMcIntosh(CC BY2.0) and Breton2017/TsaagValren(CC BY-SA4.0)
from the frozen cleared audit7d83. They show fleshy lips/chin and a narrow curved
seam; bit hardware partly occludes both corners. Two newly retrieved Commons
close photographs have also actually been opened: Arabian muzzle833x853, Flickr
account7221539@N06/IMG_4083,2010-03-01,CC BY-SA2.0 with Commons Flickr review;
and Fjord horse muzzle4000x3000,TsaagValren,2017-06-02,ownworkCC BY-SA4.0.
The Arabian author-name field is malformed in Commons; retain the explicit
Flickr account/source attribution instead of inventing a repaired name. The
Commons category identifies JimmyBaikovicius, but that is qualified evidence.
Both new frontal photos show the closed upper/lower lips and rounded raised
nostril margins without tack hiding the nose. They are modern comparative
anatomy, not Chicago animal identity/breed prevalence/period tack/metric scans.
Neither supplies an unobscured calibrated neutral bitted profile or pressure.

No photograph is used as a texture, traced mesh or measured coordinate source.
All dimensions below are ORIGINAL AUTHORED RECONSTRUCTION and must be rejected
if actual images look wrong. Photographs retain their explicit separate CC
license/credit; executable source is GPL-3.0-or-later. No blanket CC0/GPL claim
is made on the photos. API metadata and complete file-page provenance are stored.

## Exact anatomical ownership

A simple subdivision would shrink the convex chin and preserve the bad weak
lip dimple. It is not the whole correction. Own the complete existing native
front muzzle, including its front cap, before changing its anatomy.

Retire EXACT1368 current419a faces:573 current exterior labial faces,288 native
nostril skin/recess faces, and507 original anterior skin/residual lip faces.
The507 derive from stored baseline_head owners with native skin/lip tags and
native original grid/tip indices264..696, the complete front of native station4
z=.28. This includes12 residual lip faces that a skin-only selection would leave
as holes. It is a source/index cohort, never a bounding-box exemption. The
retirement spans THREE actual primitives:687 in(0,0),96 in(1,0),585 in(1,1).
Preserve all1984 other head faces and every non-head oriented triangle exactly.
In particular all128 existing real inner vestibule faces are preserved EXACT,
including their attributes, indices and source owners; the actual bit is fixed.

The retired connected patch is V739/E2108/F1368/Euler-1 and has112 exact boundary
edges:48 native station4 outer edges and64 existing actual portal edges. Keep
all112 boundary P/J/W/N copies exact. This explicit amendment replaces the prior
71-alias anatomical boundary; the full head retains its original28-edge neck
boundary/genus. No eyes/ears/neck/mane/body anatomy is changed. Old BIN/accessor/
view/attribute prefixes, rig/actions, extras and all materials remain exact.

## One fixed field, no fitting or parameter sweep

Begin with actual immutable419a source positions. All portal/boundary rows remain
exact. Nothing is regenerated from the earlier failed producers. The original
station table and existing2.5mm authored lip-depth scalar are pinned provenance;
neither was measured from the new photographs.

1. Anterior lower lip/chin lobe. In head-local coordinates, let t=(z-.435)/.105
clamped only for binary32 representability at the last source station. For
z<=.435 there is NO change, preserving the entire fixed bit/corner neighborhood.
Obtain cy and radius by the original station interpolation. Let b=max(0,-(y-cy)/r)^2,
s=t^2(3-2t), and A=(station8 top_y-bottom_y)/6=.115/6 metres. Set
Y'=Y-A*s^2*b and Z'=Z+(A/2)*sin(pi*t)^2*b. X is unchanged by this chin component; the additional front-lip-section amendment
below owns the anterior lateral coordinate. This original authored
lobe rounds/deepens the lower lip/chin, with at most19.167mm downward and9.584mm
forward source amplitudes, no posterior/boundary displacement and no new jaw
rotation. The1/6 and1/2 ratios are explicit fixed artist choices, NOT inferred
photo metrics. Source admissibility requires the original section ownership;
no extrapolation or candidate-driven adjustment is permitted.

2. Continuous raised nostril rim. The existing native aperture loops are semantic
source authority. Give each aperture alias signed side weight+/-1, its immediate
source neighbors+/-1/2, all others0. Add2.5mm times that signed weight along the
existing head-local lateral X direction, before refinement. This is one real
continuous raised skin/recess margin, not a separate torus, plane, dark dot,
overlay or shader. Both material copies share the exact same physical field.
This adds a fixed authored tissue ridge; it does not assert measured cartilage,
normal breathing/dilation or an unbounded sinus interior.

3. One constrained Loop refinement pass. Split every INTERNAL source edge once;
keep all112 boundary edges UNSPLIT and exactly fixed, so no T junction is hidden.
Use the original Loop even mask beta=(5/8-(3/8+cos(2pi/n)/4)^2)/n and odd mask
3/8 endpoints+1/8 each opposite. Use standard cubic3/4+1/8+1/8 masks along the
explicit simple source lip path, midpoint crease edges, fixed sharp endpoints.
Every mask is a finite positive source coefficient partition; all2735 are
stored. Two-split faces use the explicit fixed oriented green diagonal, not a
runtime triangulation search. Refinement alone is NOT claimed volume preserving;
the separate authored lobe above is the explicit anatomy change.

4. One real continuous closed apposed-lip crease. The fixed existing front-lower
source path runs from left portal28 through the existing blend rings to native437,
along the original longitudinal k29 source chain, around native front ring677..691,
back along the k43 chain to native451/452 and right portal4. Corner connections
are the lexicographically deterministic minimum-edge paths through each EXISTING
corner's source graph to the stated boundary target; all resulting aliases/edges
are frozen in the index proof. It is one simple portal-to-portal path. Refine its
32 edges into64. After the lobe/rim/refinement, accumulate actual oriented-area
normals from the proposed patch. Displace the crease inward by the existing
2.5mm nominal depth; source labial blend/portal aliases have strength0, native
path aliases1, refined edge strengths use their frozen convex coefficients.
Boundary remains exact. This is a genuine shallow fold in continuous tissue,
not an aperture, cap, contact exemption, hidden dark paint or rendering trick.

Interior P is computed in binary64 then stored ONCE as binary32. Interior new
vertices use the existing actual head joint at weight1. Original stored rows are
never edited. Recompute appended normals from actual serialized triangles;
crease normals use topologically disconnected local incident fans across the
explicit crease edges. Material copies share their physical alias/fan normal.
All112 boundary copies keep their exact parent retiring-boundary-face normal.
A crease with inadequate flesh or an unnatural anterior curve must still fail
visual review; this reconstruction cannot imply jaw-opening or pressure physics.

## Derived index/topology amendment

The original1368 faces become5360: F'=4F-B, with1996 interior edge splits and no
boundary split. New patch V2735/E8096/F5360/Euler-1/b112, full head
V3685/E11030/F7344/Euler-1/b28. Full model17448 triangles. The COMPLETE mouth
scope includes the128 preserved real vestibule faces plus all5360 new muzzle/
nostril faces:V2767/E8256/F5488/Euler-1/b48,8208 internal adjacency pairs.
All directed edges, vertex links, face connectivity and unchanged boundary
incidence are derived from source indices without reading proposed positions.
Every new face retains its exact parent419a face and material role. Source
cohort widening is explicit, never a reduction of an existing physical check.

## Execution and acceptance

The original8da0 one180s trial was used and FAILED7de8 at firstpropercrossing.
For this fresh successor, root authorized SOURCE correction and full review;
NO second actual candidate is authorized yet. A later explicit root release
must authorize exactly ONE<=180s CPU0/all4maththreads1 actual candidate AFTER full
independent frozen source/caller/index-ownership review PASS. Fresh exclusive
outputs, exact before/after manifest bytes AND entries, owned child-group kill/
reap on EVERY BaseException, no retry and first-failure STOP. Keep prior419a and
all failed/partial evidence immutable. Actual frozen source release token is
ROOT_RELEASE_ONE_MUZZLE_FRONT_LIP_SECTIONS. No actual operation is implied by this
planning document before the full peer PASS and a free CPU0 lane.

Require decoded exact intended P/N/J/W/indices and all original stored data/doc/
rig preservation, Khronos zero errors/warnings, fresh actual binary64 capture,
all8 COMPLETE structural scopes(head7344/hybrid1492/mane456/mouth5488 each
internal/vsALL), all36 unchanged fe76 parts, the actual old078 negative, all32
actual bit-side triangles/>1mm distance and complete virtual-cap/outside57sample
volume guards. Predicates/SAT1e-8/owned-point and edge certificate rules remain
EXACT. The original110s full-structural phase cap/180s total remains; a timeout is
FAILED and incomplete, not permission to extend/rerun a candidate.

After a full actual technical PASS, root has authorized one bounded readonly
matched appearance capture after peer source check. Inspect horse-only AND actual
bitted views, profile/quarter and desktop/mobile. No automatic natural/photo,
period identity, motion, unbitted, jaw-opening or app promotion acceptance follows.


## Required lateral front-lip-section amendment after actual7de8 failure

# Source correction proposal after the stored7de8 anterior crease crossing

The7de8 actual trial is FAILED/incomplete. It is archived as325efc9d; do not rerun
it, extend it or promote its earlier source/Khronos successes. All later physical
scopes/gear/bit remain UNRUN. Passing419a remains immutable engineering baseline.

The stored first proper witness crosses frontcap native1236/parent2841 against
underside native1176/parent11750. Both are exterior coat descendants near the
front-lower lip crease h684/h685, not an intended mucosal interface or shared
actual source point. Barycentrics reconstruct the SECOND stored triangle within
2.22e-16m and have minimum0.007445; signed distances−0.060975/+2.286106mm straddle.
The emitted even h684->h685 X delta is−0.006681mm, while the original native
same-ordered source X delta was+0.522105mm. This is direct stored local fold
corroboration; no producer, alternativeXYZ, SAT or distance query was rerun.

The underlying anatomical defect is an authored snout that collapses to a point:
last station halfwidth4mm/totalheight4mm. The new chin field added vertical tissue,
but preserved that tiny transverse front cap. A real nominal2.5mm closed-lip
crease around that cap can fold sideways into the neighboring underside. The
clear modern unbitted front photographs show a broad fleshy apposed lip, not a
point requiring a submillimeter seam. A smaller scalar groove is not the proposed
repair. No SAT/proper/alias/contact guard may be relaxed.

## One fixed anatomically owned front section amendment, SOURCE ONLY

Keep immutable419a as input and the exact8da0 source retirement/topology/stencils,
chin/rim/nominal2.5mmrealgroove, all112 boundary/128wetlining, rig/storage/materials
and all physical guards. Add ONE explicit transverse lip section reconstruction
before the fixed Loop pass. All source z<=station9z=.505 are EXACTLY unchanged by
this additional field, including every real bit/portal and nostril aperture.

At the anterior source stations, replace the collapsing halfwidth with a fixed
cubic Hermite width W(z) over z9=.505 through z12=.54:

* W(z9)=original station9 halfwidth=.078m.
* W'(z9)=(station9width−station8width)/(z9−z8)=−.366666... .
* W(z12)=original station10 halfwidth=.048m.
* W'(z12)=0, rounding the broad anterior lip section.

For each existing source point, obtain its ORIGINAL station-interpolated halfwidth
w(z), then X'=X*W(z)/w(z). Preserve its source Y/Z chart; the already fixed chin
field still owns Y/Z. At the original native centerpoint X=0 this remains0.
The48 outer station4 vertices and64 actual portal vertices receive no movement.
New front transverse width is therefore96mm instead of8mm, an explicit ORIGINAL
ARTIST reconstruction anchored to the existing native pre-tip station10. It is
not a claimed measurement from either photo, animal identity or breed standard.
No authoring ratios are selected by a collision search or repeated candidates.

This keeps the full narrow lip groove as actual tissue, with existing normalfan
ownership and retained real interior, while supplying a non-collapsed anterior
soft-tissue cross-section. The target width/proportion is still subject to actual
visual rejection. A field that eliminates this one witness is NOT thereby proven
embedded, gear-safe, natural or photographic. Full unchanged actual guards decide.

Symbolic topology is unchanged:5360newfaces/fullhead7344/fullmouth5488/model17448.
Freeze a fresh successor source/caller/pins and obtain independent FULL review of
the exact additional scalar field/source ownership and all guards/import/caller.
Root has authorized source correction/review, not a second actual candidate yet.
Any later root release must remain ONE<=180s/110sstructural CPU0/thread1 with
exclusive outputs/firstfailure and no retry. No new actualXYZ is generated here.
