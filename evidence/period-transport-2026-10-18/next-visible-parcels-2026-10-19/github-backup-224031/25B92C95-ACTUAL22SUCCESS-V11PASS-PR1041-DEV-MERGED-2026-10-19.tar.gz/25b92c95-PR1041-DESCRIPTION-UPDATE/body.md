Adds a transport study gallery with an articulated W01 wagon, open C01 and enclosed C02 carriage, skinned horse, harness and coupling previews. The separate W01 driver bench has a timber seat supported on both rails, retaining hardware and a floor-supported footboard. C02 includes a movable door with collision checks.

Reconstructed 1835 residents Otis Bardwell, Joseph Dufresne and Martin Flynn supply the named workwear references. The opt-in portable `sit_drive` authoring/export path binds the pose to the supported W01 bytes and preserves identity/date checks and ordinary idle/walk authoring. Source and published browser probes check bench framing, controls, GLB binding, supported/baseline substitution and cleanup.

These remain reconstructed engineering studies. Photographic masters, complete tack/bit fit, occupied drivers/riders, main-scene traffic and boarding/riding remain open. No production promotion is included.

Validation at `25b92c95095b7f1ea2b7dee9487ee0f018a773f3` (tree `e921a90b5527eeaf18d51c3a044b525b882d9145`):

- Complete local preflight passed: **1,020 steps**, including **377 refusal self-tests**, exit 0. Post-commit changelog, ID and published-mirror checks passed.
- The fresh **18-cell smoke grid is running** on this exact head. Complete qualification is **pending**: all 18 manual smoke workflows and the four triggered automatic workflows must finish with coherent mandatory steps and current checks before the final V11 audit, ready status or merge. The PR remains a draft.
- Smoke coverage uses the existing nine ranges `1-2`, `3-4`, `5`, `6-7`, `8`, `9-12`, `13`, `14`, `15`, each requested once for desktop and mobile. An earlier unfiltered run exceeded its actual 150-minute job limit; the complete split preserves all 15 parts and both viewports without changing timeouts, assertions or budgets.
- The human producer inputs and 25 qualification source pins remain unchanged. The merged smoke source adds the incoming Short Why assertions inside PART13 while preserving every f2f smoke byte outside that part. The [earlier successful manual workwear+seated export qualification](https://github.com/kevinrhaas/chicago/actions/runs/39289017835) remains historical; it is not represented as a new-head artifact inspection.

CI stdout equivalence remains unproven and artifact contents uninspected. Workflow metadata is not photographic acceptance, and run/input pairing is not inferred from creation order. Earlier failures, setup-only failure, timeouts and stopped zero-POST recovery plans remain preserved. [Recovery records](https://github.com/kevinrhaas/chicago-tickets/tree/main/evidence/period-transport-2026-10-18).
