# SPDX-License-Identifier: GPL-3.0-or-later
"""Independent decoded readback and complete source-owner ledger checks."""
from pathlib import Path
import json,copy,collections
import numpy as np
from analyze_graft import context,tri_key,counter,sha
from graft import source_lookup
from ownership import Model,ATTRS,triangle_labels,verify_source_seams
from sparse_rules import require
P=Path(__file__).parent

def checked():
 base,oral,old,c,hits,adds=context();raw=(P/'candidate-one/candidate.glb').read_bytes();new=Model(raw);proof=json.loads((P/'candidate-one/graft-proof.json').read_text());require(proof['candidate_sha256']==sha(raw),'actualcandidatepin');require(bytes(new.b[:len(old.b)])==bytes(old.b),'oldBINprefixexact');na,nv=len(old.d['accessors']),len(old.d['bufferViews']);require(new.d['accessors'][:na]==old.d['accessors']and new.d['bufferViews'][:nv]==old.d['bufferViews'],'alloldstoragemetadataexact')
 a,b=copy.deepcopy(old.d),copy.deepcopy(new.d)
 for d in[a,b]:
  d.pop('accessors');d.pop('bufferViews');d['buffers'][0].pop('byteLength')
  for mesh in d['meshes']:
   for pr in mesh['primitives']:pr.pop('attributes');pr.pop('indices')
 require(a==b,'nongeometrydocumentrigactionsmaterialsexact')
 expected=counter(old)-(counter(base)-counter(oral))+(counter(oral)-counter(base));require(counter(new)==expected,'ALLactualorientedP/N/J/W/materialinventoryexact')
 for key,v in old.views.items():
  for name in ATTRS:require(np.array_equal(new.views[key]['attributes'][name][:len(v['attributes'][name])],v['attributes'][name]),'everyoldattributerowexact')
 retired={(r['mesh'],r['primitive'],r['triangle'])for r in hits};expectedold={old.global_face(k,i)for k,v in old.views.items()for i in range(len(v['indices']))if(*k,i)not in retired};ledger=proof['retained_old_to_new'];require(len(ledger)==len(expectedold)and {r['old_global']for r in ledger}==expectedold,'fulluniqueoldledger');require(len({r['new_global']for r in ledger})==len(ledger),'unique newretainedledger');remap={r['old_global']:r['new_global']for r in ledger}
 for r in ledger:
  k=r['mesh'],r['primitive'];require(new.global_face(k,r['new_local'])==r['new_global'],'retainedactualglobalbinding');og=r['old_global'];desc=old.descriptor(og);require(k==(desc['mesh'],desc['primitive'])and np.array_equal(old.views[k]['indices'][desc['primitive_triangle']],new.views[k]['indices'][r['new_local']]),'everyretainedexactindextriple')
 s,lookup=source_lookup(oral);labels=dict(c['neck_candidate'][1]);newlabels={(r['mesh'],r['vertex']):r['label']for r in proof['source_labels']};require(len(newlabels)==len(proof['source_labels'])and all(newlabels.get(k)==v for k,v in labels.items()),'oldsemanticlabelsexact')
 for mi in {k[0]for k in new.views}:
  oldlen=len(old.views[mi,0]['attributes']['POSITION']);attrs=new.views[mi,0]['attributes']
  for vi in range(oldlen,len(attrs['POSITION'])):
   sig=b''.join(attrs[a][vi].tobytes()for a in ATTRS);matches=lookup[sig];require(len(matches)==1,'newvertexexactsourceidentity');sid=matches[0];label=('h:'if sid<s['oral_authority']['old_vertices_exact']else'oral:')+str(sid);require(newlabels.get((mi,vi))==label,'newvertexsemanticlabelbinding')
 oldhead=c['neck_candidate'][2];owners=c['neck_candidate'][3];head={remap[g]for g in oldhead if g in remap};actualowners={remap[g]:o for g,o in owners.items()if g in remap};addition=proof['added_faces'];require(len(addition)==len(adds)==471 and len({r['new_global']for r in addition})==471,'all471uniquenewfaces');require({r['oral_global']for r in addition}=={r['global']for r in adds},'completeoralsourcefaces')
 def cycle(q):return min(tuple(q[k:]+q[:k])for k in range(3))
 for r in addition:
  k=r['mesh'],r['primitive'];ng=new.global_face(k,r['new_local']);require(ng==r['new_global']and ng not in remap.values(),'newfaceactualunique');od=oral.descriptor(r['oral_global']);require(k==(od['mesh'],od['primitive'])and tri_key(new,k,r['new_local'])==tri_key(oral,k,od['primitive_triangle']),'exactaddedoralface');sourceids=[int(newlabels[k[0],int(v)].split(':')[1])for v in new.views[k]['indices'][r['new_local']]];sf=r['source_face'];require(cycle(sourceids)==cycle(s['faces'][sf]),'newfaceactualsourcevertexorder');owner={'kind':'oral_channel','oral_generated_face':sf,'source_owner':s['source_owners'][sf]};require(owner==r['owner'],'newowneractualsource');actualowners[ng]=owner;head.add(ng)
 require(set(remap.values())|{r['new_global']for r in addition}==set(range(new.total)),'ALLactualfacesaccounted');require(head==set(proof['head_faces'])and {int(k):v for k,v in proof['source_face_owners'].items()}==actualowners,'headownersrederived');new.source_face_owners=actualowners;verify_source_seams(new,newlabels)
 scopes={name:{remap[g]for g,o in owners.items()if o['kind']==kind}for name,kind in[('hybrid','hybrid_neck'),('mane','fitted_mane')]};require(len(head)==3122 and len(scopes['hybrid'])==1492 and len(scopes['mane'])==456,'completesourcecohorts');require(not(head&scopes['hybrid'])and not(head&scopes['mane'])and not(scopes['hybrid']&scopes['mane']),'disjointfunctionalcohorts')
 return new,newlabels,head,actualowners,scopes,raw
if __name__=='__main__':
 new,labels,head,owners,scopes,raw=checked();r={'PASS':True,'candidate_sha256':sha(raw),'triangles':new.total,'head_faces':len(head),'hybrid_faces':len(scopes['hybrid']),'mane_faces':len(scopes['mane']),'protected':'all old attribute rows/BINprefix/retainedindices/rig/actions/materials exact; whole orientedinventory parent-minus261-plus471 exact','status':'decodedsourcebinding only; rest/pose/gearacceptancepending'};(P/'graft-readback-result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
