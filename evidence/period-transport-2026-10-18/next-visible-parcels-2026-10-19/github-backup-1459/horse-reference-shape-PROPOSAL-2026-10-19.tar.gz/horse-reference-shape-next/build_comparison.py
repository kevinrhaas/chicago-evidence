# SPDX-License-Identifier: CC0-1.0
"""A report figure referencing original pixels; no source image edits."""
from pathlib import Path
import math,json,hashlib,shutil,html
p=Path(__file__).parent
source=Path('/workspace/shared/horse-base-reference-audit/illo262.png');model=Path('/workspace/shared/horse-coat-normal-visual-next/desktop-after-neck-profile.png')
for src,name in[(source,'cuyer1905-fig92-original.png'),(model,'03884-profile-original.png')]:shutil.copy2(src,p/name)
ref={'eye':[174,139],'nostril':[27,254],'ear insertion':[214,90],'ear tip':[211,5],'rear jaw angle':[236,269],'chin':[56,327]}
mod={'eye':[536,367],'nostril':[317,506],'ear insertion':[644,301],'ear tip':[669,184],'rear jaw angle':[587,477],'chin':[320,545]}
z=complex(*mod['nostril'])-complex(*mod['eye']);w=complex(*ref['nostril'])-complex(*ref['eye']);a=z/w;t=complex(*mod['eye'])-a*complex(*ref['eye']);rows=[]
for key,r in ref.items():
 q=a*complex(*r)+t;target=mod[key];rows.append({'landmark':key,'reference_pixel':r,'model_pixel':target,'aligned_reference_pixel':[q.real,q.imag],'model_minus_aligned_reference_pixel':[target[0]-q.real,target[1]-q.imag]})
receipt={'status':'QUALITATIVE manual screen-landmark comparison ONLY; not anatomical metric calibration','reference':'Cuyer1905 Fig92 p239; exposed muscles; comparative anatomy, not period Chicago identity','model':'03884 normal-only variant; same1eee geometry; idle0 lateral perspective camera','anchors':['eye','nostril'],'alignment':'one2Dsimilarity only, no independent axis scaling/warping','scale':abs(a),'rotation_degrees':math.degrees(math.atan2(a.imag,a.real)),'matrix':[a.real,a.imag,-a.imag,a.real,t.real,t.imag],'manual_pixel_uncertainty':'approximately4–10pixels; feature definitions and drawing projection are additionally uncertain','landmarks':rows,'source_files':{str(src):hashlib.sha256(src.read_bytes()).hexdigest()for src in[source,model]},'actually_viewed':True,'no_source_pixel_edit':True}
(p/'landmarks.json').write_text(json.dumps(receipt,indent=2)+'\n')
# The left and right image viewports use identical target-pixel coordinates.
matrix=' '.join(str(x)for x in receipt['matrix']);marks=''
for row in rows:
 x,y=row['aligned_reference_pixel'];mx,my=row['model_pixel'];label=html.escape(row['landmark']);marks+=f'<circle cx="{x}" cy="{y}" r="5" fill="#b52b2b"/><text x="{x+8}" y="{y-8}">{label}</text><circle cx="{1280+mx}" cy="{my}" r="5" fill="#b52b2b"/><text x="{1288+mx}" y="{my-8}">{label}</text>'
svg=f'''<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 2560 900"><style>text{{font:20px sans-serif;fill:#8b1515;paint-order:stroke;stroke:white;stroke-width:3px}}</style><rect width="2560" height="900" fill="#e5e8e3"/><image href="cuyer1905-fig92-original.png" width="350" height="376" transform="matrix({matrix})"/><image href="03884-profile-original.png" x="1280" width="1280" height="900"/>{marks}<text x="30" y="70">Cuyer1905 Fig92: original exposed-anatomy drawing, similarity-aligned</text><text x="1310" y="100">03884 existing model: same1eee geometry, lateral perspective</text></svg>'''
(p/'comparison.svg').write_text(svg)
(p/'comparison.html').write_text('''<!doctype html><meta charset="utf-8"><title>Qualitative horse-head reference comparison</title><style>body{font:16px system-ui;background:#eee;margin:20px}object{width:100%;border:1px solid #777}p{max-width:1100px}</style><h1>Head anatomy comparison — not a likeness or metric reconstruction</h1><p>The original Cuyer1905 Fig92 and actual03884 screenshot are shown without editing their bytes. One similarity transform aligns manually marked eye and nostril centers; the remaining landmarks are diagnostic observations, not measurements of an1835/1904 horse. The drawing shows exposed muscle, and the model uses a perspective camera.</p><object type="image/svg+xml" data="comparison.svg"></object><p>See REPORT.md and landmarks.json for uncertainty, original hashes and the proposed bounded first sculpt. Existing mechanical baselines remain immutable.</p>''')
print(json.dumps({'scale':abs(a),'rotation':receipt['rotation_degrees'],'residuals':[(r['landmark'],r['model_minus_aligned_reference_pixel'])for r in rows]},indent=2))
