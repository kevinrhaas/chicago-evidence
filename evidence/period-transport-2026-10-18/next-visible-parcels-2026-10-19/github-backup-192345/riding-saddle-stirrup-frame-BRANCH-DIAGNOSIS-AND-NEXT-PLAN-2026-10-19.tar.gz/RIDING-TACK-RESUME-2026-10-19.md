# Riding tack worker resume point

The corrected frame trial has run exactly once and FAILED global self embedding. Root confirmed preflight 44592 exited before launch. Session 58814 is terminal, exit 1, after 30.057 seconds on CPU 1. Do NOT repeat this caller. The command below records the completed invocation:

```
PYTHONDONTWRITEBYTECODE=1 taskset -c 1 /workspace/shared/chicago-venv/bin/python /workspace/shared/riding-saddle-stirrup-frame-caller.py
```

Caller SHA256: c91fc6a8290e81cd7d90de910b6226ee3e40ce432af2ec99a7a6b816a4c48d6d.
Source directory: `/workspace/shared/riding-saddle-stirrup-frame-source-next`.
Source inventory SHA256: c1531b28c7fa096b0314845658b67242cfe8379adc496c6ffb69068976aae32b, 44 files.
Root executable review: `riding-saddle-stirrup-frame-root-source-review.json`, SHA256 864ac8ce12513b56c632eaa73ec92829db525e136afd2d67d9bbe05320fbdfe4.
Independent exact frame math review: `riding-saddle-stirrup-frame-period1904-math-review.json`, SHA256 3c37b54d25b2e650e18b4c64db7318876f1af5fee1f331e11e4fc44a68f7f718.

Fresh exclusive output is `/workspace/shared/riding-saddle-stirrup-frame-actual-one`. If it already exists, do not reuse it or repeat the trial. Preserve its current result and consult root. The caller enforces 7 input pins, 44 source pins and unchanged external validator 584230a2. It runs four original negative stages, one fixed build, decoded readback, Khronos, actual idle 0 capture, all 29 self scopes, all 328 interpart pairs, and 16 changed parts versus ALL 14,172 horse faces. Use one CPU and one math thread, with an 1,800 second overall limit, 30 second build limit and 900 second self/assembly limits. Stop at the first failure. Every interrupted owned subprocess group is killed and reaped. No browser, motion, app, central ticket or Git mutation is authorized by this worker release.

Actual candidate f644710ddd19a1be3deee594278bde550b744ea2d2c013e4388c2586145bb8b6 passed all four negative stages, build, readback, Khronos and capture. All 18 interfaces, both exact 119-cell frame proofs and both material-side/underside proofs passed. Left stirrup leather faces 88/865 strictly properly cross between outgoing and return branches at the under-jockey exit. Twenty self scopes completed before the failing 21st. Remaining self, interpart, wholehorse and browser stages did not run. Complete failure archive: `riding-saddle-stirrup-frame-FIRST-SELF-FAILURE-2026-10-19.tar.gz`, SHA 92ec2ea3d14b8191919e88a57a8b4e46b2bfd21ac3c19e8e71a997892bfeda95, 2,337,850 bytes, 92 entries.

Read-only saved-output ring diagnosis is `riding-saddle-stirrup-frame-FAILED-BRANCH-STATIONS.json`. Different root angles created two differently spaced angular grids; the crossing cells straddle the support-transition knot at different phases. A proposed next source revision would share canonical angular stations and transition knots while retaining existing gaps/thickness and full global guards. Root has NOT approved or released that revision yet. No source correction or repeated model trial has followed this failure.

Scope: 16 changed and 13 protected meshes, 22 closed changed components, 18 exact source-owned interfaces. Nine original saddle layer primitive references and the complete 50463 storage prefix stay exact. Two jockeys have actual closed edge notches; the two doubled stirrup leathers wrap an unmeasured approximately 51 mm inherited iron facet strip. All retained jockey positions and all original irons, treads, rig, reins, materials and sockets stay exact. Photographic, period visual, load, rider and motion acceptance is OPEN.

Prior failures are immutable. The first bisector 83f7 trial passed all 29 self scopes but failed a quarter/stirrup-leather proper intersection at pair 185. Its archive is `riding-saddle-underbelly-bisector-FIRST-ASSEMBLY-FAILURE-2026-10-19.tar.gz`, SHA afe90d47744394987a206a98f79afed2a471ab9eb8e61b4915d6dc7f29d51b18. Complete read-only diagnostics retained 184 raw and 168 proper old stirrup crossings across six pairs.

The first notch ae0b trial failed decoded opposing contact orientation after 4.811 seconds; no Khronos, capture, SAT or browser followed. Its archive is `riding-saddle-stirrup-notch-FIRST-INTERFACE-FAILURE-2026-10-19.tar.gz`, SHA a5b1d7257a709f926fb8ee5ea4f3715afb72bc0ded944b69a74c8544f71a0184. All 18 saved contacts were checked: only the left iron contact had 10 same-facing triangles. Both folds extruded away from metal; left inner-face normals pointed into leather, demonstrating a left frame inversion. The corrected source swaps BOTH inner and outer width ownership for that entire left fold and regenerates connectors, without flipping individual faces. Exact spatial trilinear-cell Jacobian Bernstein sign proofs and independently decoded material-direction proofs guard both sides. These do not replace full planar triangle self/interpart checks.

Current source/diagnostics archive: `riding-saddle-stirrup-frame-SOURCE-REVIEW-PENDING-2026-10-19.tar.gz`, SHA 4e9f5c9fde02f9d4a220dbd726877e14955b658232bb61e06f1d2e20a15e574f, 259,431 bytes. Review closure capsule: `riding-saddle-stirrup-frame-REVIEW-CLOSURE-2026-10-19.tar.gz`, SHA c558f97cdb8c70942f940d909086d55c9e2dabaa88cc46cb4910a8ff16718e84, 2,212 bytes. Root owns central preservation and pushes; this worker has made no app, Git or central changes.
