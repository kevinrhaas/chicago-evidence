# SPDX-License-Identifier: GPL-3.0-or-later
"""Freeze executable source only. Never evaluates horse or emits a model."""
from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files={p.name:sha(p)for p in sorted(P.iterdir())if p.is_file()and p.name!='SOURCE-INVENTORY.json'and p.suffix in {'.py','.mjs','.md','.json'}}
external_files=[
    Path('/workspace/shared/horse-combined-oral-neck-mane-prefix-next/candidate-one/candidate.glb'),
    Path('/workspace/shared/horse-breeching-swept-route-next/candidate-one/light_breastcollar_harness_reconstructed_01.glb'),
    Path('/workspace/shared/horse-v2-cap-registered-next/build1/light_breastcollar_harness_reconstructed_01.glb'),
    Path('/workspace/shared/horse-combined-oral-neck-mane-prefix-next/idle-fit/official_fit_predicates.py'),
    Path('/workspace/shared/horse-neck-hybrid-pipeline-next/exact_contact.py'),
    Path('/workspace/shared/horse-neck-hybrid-pipeline-next/classify_contact.py')]
for root in [Path('/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1'),Path('/workspace/shared/transport-tools/node_modules/gltf-validator')]:
    external_files.extend(p for p in root.rglob('*')if p.is_file())
result={'status':'Frozen executable SOURCE ONLY; no actual horse evaluation/candidate run; independent review and root release required',
        'files':files,'external':{str(p):sha(p)for p in sorted(set(external_files))},
        'firstActualTarget':'idle0; one candidate, first-failure stop, outside app',
        'actualModelOrFitClaims':False,'browserOrPhotographicClaims':False}
(P/'SOURCE-INVENTORY.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'sourceInventorySHA256':sha(P/'SOURCE-INVENTORY.json'),'owned':len(files),'external':len(result['external'])}))
