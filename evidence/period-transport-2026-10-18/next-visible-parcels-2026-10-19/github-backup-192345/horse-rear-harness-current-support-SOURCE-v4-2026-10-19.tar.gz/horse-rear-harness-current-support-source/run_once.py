# SPDX-License-Identifier: GPL-3.0-or-later
"""One reviewed idle0 candidate; fresh exclusive logs, first failure STOP."""
from pathlib import Path
import json,hashlib,subprocess,sys,time,os,signal
P=Path(__file__).resolve().parent
def need(v,m):
    if not v:raise ValueError(m)
def main():
    need(len(sys.argv)==3,'explicit release receipt and fresh output root');release=Path(sys.argv[1]).resolve();output=Path(sys.argv[2]).resolve()
    raw=(P/'SOURCE-INVENTORY.json').read_bytes();inventory=json.loads(raw);authority=json.loads(release.read_text())
    need(authority.get('authority')=='root' and authority.get('allow')=='ONE_IDLE_CURRENT_SUPPORT_CANDIDATE' and authority.get('sourceInventorySHA256')==hashlib.sha256(raw).hexdigest(),'actual source-bound one-candidate root release')
    for n,w in inventory['files'].items():need(not Path(n).is_absolute()and'..'not in Path(n).parts and hashlib.sha256((P/n).read_bytes()).hexdigest()==w,'frozen owned source '+n)
    for n,w in inventory['external'].items():need(hashlib.sha256(Path(n).read_bytes()).hexdigest()==w,'frozen external source '+n)
    need(not output.exists(),'exclusive new actual output root');output.mkdir();candidate=output/'candidate'
    started=time.monotonic();r={'PASS':False,'scope':'ONE actual idle0 current-support rear study; no motion/continuous/forces/hitch/photo acceptance','sourceInventorySHA256':hashlib.sha256(raw).hexdigest(),'stages':[]}
    def save():r['elapsedS']=time.monotonic()-started;(output/'OPERATOR.json').write_text(json.dumps(r,indent=2)+'\n')
    save();node=['node','--loader',str(P/'three-loader.mjs')]
    commands=[('build_idle',node+[str(P/'build_idle_once.mjs'),str(release),str(candidate)],30),('serialized_scope_topology_self',[sys.executable,str(P/'check_serialized.py'),str(candidate)],90),('khronos',node+[str(P/'validate_candidate.mjs'),str(candidate)],30),('fresh_reparsed_idle_capture',node+[str(P/'capture_idle_once.mjs'),str(candidate)],30),('all36_horse_and_new3_interpart',[sys.executable,str(P/'check_actual_fit.py'),str(candidate)],90)]
    try:
        for name,cmd,bound in commands:
            before=time.monotonic();budget=min(bound,270-(before-started));need(budget>0,'270second total oneCPU trial bound')
            with(output/(name+'.stdout')).open('xb')as out,(output/(name+'.stderr')).open('xb')as err:
                child=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True,env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'})
                try:code=child.wait(timeout=budget)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait();code=124
                except BaseException:os.killpg(child.pid,signal.SIGKILL);child.wait();raise
            r['stages'].append({'name':name,'exit':code,'elapsedS':time.monotonic()-before});save()
            if code:raise RuntimeError('FIRST failure: '+name+'; all later stages UNRUN')
        r['PASS']=True
    except BaseException as error:r['error']=repr(error)
    finally:save()
    print(json.dumps(r));return 0 if r['PASS']else 2
if __name__=='__main__':sys.exit(main())
