// SPDX-License-Identifier: GPL-3.0-or-later
// Analytic source controls only. No actual horse evaluation or candidate.
import assert from 'node:assert/strict';
import {convexHull,offsetPolygon,clipPolygon,pairedArc,emitStrip,clipClosedAtY} from './evaluate.mjs';
const square=[[-1,-1],[1,-1],[1,1],[-1,1]],near=(a,b)=>assert.ok(Math.abs(a-b)<1e-12);
assert.deepEqual(convexHull([...square,[0,0],[0,-1],[1,1]]),square);
const expanded=offsetPolygon(square,.25);assert.deepEqual(expanded,[[-1.25,-1.25],[1.25,-1.25],[1.25,1.25],[-1.25,1.25]]);
const clipped=clipPolygon([[0,0,0],[2,0,0],[0,2,0]],0,1,-1);
assert.deepEqual(clipped,[[0,0,0],[1,0,0],[1,1,0],[0,2,0]]);
const rear=pairedArc(square,.1,1,0,0,true,p=>p[1]<=0),top=pairedArc(square,.1,1,0,0,true,p=>p[1]>=0);
assert.deepEqual(rear.map(p=>p[0]),[[1,0],[1,-1],[-1,-1],[-1,0]]);
assert.deepEqual(top.map(p=>p[0]),[[1,0],[1,1],[-1,1],[-1,0]]);
assert.deepEqual(rear.map(p=>p[1]),[[1.1,0],[1.1,-1.1],[-1.1,-1.1],[-1.1,0]]);
const frame={origin:[0,0,0],a:[1,0,0],b:[0,0,1],width:[0,1,0]},strip=emitStrip(rear,frame,.2,'analytic');
assert.equal(strip.positions.length/9,28);assert.ok(strip.positions.every(Number.isFinite));
for(const v of strip.logicalVertices)near(Math.abs(v[1]),.1);
const edges=new Map();for(const f of strip.logicalFaces)for(let j=0;j<3;j++){const a=f[j],b=f[(j+1)%3],key=[Math.min(a,b),Math.max(a,b)].join(':');if(!edges.has(key))edges.set(key,[]);edges.get(key).push([a,b]);}
for(const uses of edges.values()){assert.equal(uses.length,2);assert.deepEqual(uses[0],uses[1].toReversed());}
assert.equal(strip.logicalVertices.length-edges.size+strip.logicalFaces.length,2);
assert.throws(()=>convexHull([[0,0],[1,0],[2,0]]),/Nondegenerate/);
assert.throws(()=>offsetPolygon(square,0),/Positive/);
assert.throws(()=>pairedArc(square,.1,1,2,0,true,()=>true),/Two transverse/);
const upright={origin:[0,0,0],a:[1,0,0],b:[0,1,0],width:[0,0,1]},vertical=emitStrip([[[1,-1],[1.1,-1]],[[1,1],[1.1,1]]],upright,.2,'analytic-cut');
const cut=clipClosedAtY(vertical,0);assert.ok(cut.logicalVertices.every(v=>v[1]>=0));assert.equal(cut.clipOwnership.boundary.length,8);assert.equal(cut.clipOwnership.outputVertexOwners.length,cut.logicalVertices.length);near(cut.centerlineLengthM,1);
const cutEdges=new Map();for(const f of cut.logicalFaces)for(let j=0;j<3;j++){const a=f[j],b=f[(j+1)%3],key=[Math.min(a,b),Math.max(a,b)].join(':');if(!cutEdges.has(key))cutEdges.set(key,[]);cutEdges.get(key).push([a,b]);}
for(const uses of cutEdges.values()){assert.equal(uses.length,2);assert.deepEqual(uses[0],uses[1].toReversed());}
assert.equal(cut.logicalVertices.length-cutEdges.size+cut.logicalFaces.length,2);
const trap=[[-1,-2],[1,-2],[5,2],[-5,2]],slab=clipPolygon(clipPolygon(trap,1,-.1,1),1,.1,-1),local=Math.max(...slab.map(p=>p[0]));near(local,3.1);
const rightAtZero=p=>{const hits=[];for(let i=0;i<p.length;i++){const a=p[i],b=p[(i+1)%p.length];if(a[1]===0)hits.push(a[0]);if(a[1]*b[1]<0)hits.push(a[0]+(b[0]-a[0])*(-a[1])/(b[1]-a[1]));}return Math.max(...hits);};
const oldBad=convexHull([...trap,[local,-.1],[local,.1],[-local,-.1],[-local,.1]]);assert.ok(rightAtZero(oldBad)>local);
const globalMax=Math.max(...trap.map(p=>p[0])),fixed=convexHull([...trap,[globalMax,-.1],[globalMax,.1],[-globalMax,-.1],[-globalMax,.1]]);near(rightAtZero(fixed),globalMax);
// Use an oblique frame: an axis-aligned line has a structurally exact zero
// normal component and cannot expose cancellation of two global constants.
const shallow=[[-.3,-.85],[.299,-.85],[.3,-.84999999999],[.3,.1],[-.3,.1]].map(([x,y])=>[Math.cos(.37)*x-Math.sin(.37)*y+.31,Math.sin(.37)*x+Math.cos(.37)*y-.27]),radius=.007;
const outward=(a,b)=>{const dx=b[0]-a[0],dy=b[1]-a[1],n=Math.hypot(dx,dy);return[dy/n,-dx/n];};
const oldGlobal=shallow.map((q,i)=>{const a=outward(shallow[(i+shallow.length-1)%shallow.length],q),b=outward(q,shallow[(i+1)%shallow.length]),d=a[0]*b[1]-a[1]*b[0],u=a[0]*q[0]+a[1]*q[1]+radius,v=b[0]*q[0]+b[1]*q[1]+radius;return[(u*b[1]-a[1]*v)/d,(a[0]*v-u*b[0])/d];});
const planeError=poly=>Math.max(...shallow.flatMap((a,i)=>{const n=outward(a,shallow[(i+1)%shallow.length]);return[poly[i],poly[(i+1)%poly.length]].map(p=>Math.abs(n[0]*(p[0]-a[0])+n[1]*(p[1]-a[1])-radius));}));
const unchangedArithmeticBound=256*Number.EPSILON;
assert.ok(planeError(oldGlobal)>unchangedArithmeticBound,'Old global line solve must reproduce the shallow-corner cancellation failure');
assert.ok(planeError(offsetPolygon(shallow,radius))<=unchangedArithmeticBound,'Vertex-relative equivalent offset preserves unchanged support-plane dimension bound');
console.log(JSON.stringify({PASS:true,scope:'Analytic geometry/global-stem/near-parallel numerical offset controls only; no actual horse or model emitted',controls:16,shallowCornerOldErrorM:planeError(oldGlobal),shallowCornerNewErrorM:planeError(offsetPolygon(shallow,radius)),unchangedArithmeticBoundM:unchangedArithmeticBound}));
