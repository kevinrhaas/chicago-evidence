// SPDX-License-Identifier: GPL-3.0-or-later
// Read original bytes and initialize source ownership only. Every prepare call
// is a refusal BEFORE mixer evaluation/current coat geometry construction.
import fs from 'node:fs';import assert from 'node:assert/strict';import crypto from 'node:crypto';
import * as T from '/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/three.module.js';
import {GLTFLoader} from '/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/addons/loaders/GLTFLoader.js';
import {createCurrentSupportController} from './controller.mjs';import {POLICY} from './evaluate.mjs';
const hb=fs.readFileSync('/workspace/shared/horse-combined-oral-neck-mane-prefix-next/candidate-one/candidate.glb'),gb=fs.readFileSync('/workspace/shared/horse-breeching-swept-route-next/candidate-one/light_breastcollar_harness_reconstructed_01.glb'),loader=new GLTFLoader();
const load=b=>loader.parseAsync(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),'');
const horse=await load(hb),gear=await load(gb),options={horseGLTF:horse,gearGLTF:gear,horseBytes:hb,gearBytes:gb,expectedGearSHA256:POLICY.parentGearSHA256};
const oldGeometry=[];gear.scene.traverse(o=>{if(o.isMesh)oldGeometry.push([o,o.geometry]);});
const controller=await createCurrentSupportController(options);assert.equal(controller.getReferenceLengths(),null);
const clip=horse.animations.find(c=>c.name==='idle'),wrongMixer=new T.AnimationMixer(new T.Group()),wrongAction=wrongMixer.clipAction(clip);
assert.throws(()=>controller.prepareAndUpdate({mixer:wrongMixer,action:wrongAction,clip,timeS:0,phase:0}),/root association/);
const rightMixer=new T.AnimationMixer(horse.scene),rightAction=rightMixer.clipAction(clip);
assert.throws(()=>controller.prepareAndUpdate({mixer:rightMixer,action:rightAction,clip,timeS:1,phase:0}),/Exact actual clip time/);
const fake=Uint8Array.from([1,2,3]),hash=crypto.createHash('sha256').update(fake).digest('hex');
await assert.rejects(createCurrentSupportController({...options,gearBytes:fake,expectedGearSHA256:hash}),/independently checked candidate identity/);
assert.equal(controller.getReferenceLengths(),null);controller.dispose();for(const [o,g]of oldGeometry)assert.equal(o.geometry,g);
console.log(JSON.stringify({PASS:true,scope:'Actual original bytes/index ownership initialization and three caller refusals only; no valid pose update, coat evaluation, emitted strap, GLB/capture/browser/fit',controls:4,threeRevision:T.REVISION}));
