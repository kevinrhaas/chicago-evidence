# Narrow correction after the first actual idle source-dimension failure

The immutable actual failure capsule is horse-rear-harness-current-support-FIRST-ACTUAL-DIMENSION-FAILURE-2026-10-19.tar.gz, SHA de78264434496ff5e16232af5705057743c9a0635c4a3289804f8acecbc6e435. It includes the one actual candidate37b81ee3, v3 source archive, root release, peer source review, terminal logs and read-only stored-array dimension witnesses. No self-embedding, Khronos, capture, physical-fit, browser or motion stage ran after the dimension stop.

Only the support-line intersection arithmetic changes. Let q be the existing convex vertex and na,nb the existing unit outward normals of its incident edges. Both original offset support planes require na·(p-q)=r and nb·(p-q)=r. The same solution is:

    p = q + r(na + nb)/(1 + na·nb)

Dotting the displacement with either unit normal gives r. The original implementation solved the two global line constants na·q+r and nb·q+r by a determinant formula. Near-parallel normals caused subtraction of global values and division by a small sine. The new expression computes the displacement locally; for near-parallel normals its denominator is near2. The old determinant degeneracy refusal remains. The new denominator refusal additionally rejects numerically degenerate opposing normals; it creates no new permitted case.

No allowance, width, thickness, length policy, source slab, route, junction construction, emitted topology, part preservation or collision guard changes. The frozen dimension bound remains256double-epsilon times construction scale. A failed bound now includes its measured width/thickness errors and unchanged bound in the exception text, so the original diagnostic weakness cannot hide the next source witness.

The analytic negative control uses a fixed oblique shallow convex corner: the old formula has1.1293898932382418e-9m support-plane residual; the new equivalent formula has6.938893903907228e-17m, below the unchanged5.684341886080802e-14m bound. An initial axis-aligned control did not reproduce the old cancellation because one normal component was structurally zero; its expected-old-failure assertion failed before correction to an oblique coordinate frame. This was only a synthetic numerical test, not a horse/model trial or a body-fit parameter search.

A new actual candidate remains prohibited until independent review of the exact source delta and a new source-bound root release. The previous root release is consumed by the preserved first failure. No old fit result can qualify the new output bytes.
