# SPDX-License-Identifier: GPL-3.0-or-later
"""Independent actual serialized scope, topology and exact contact checks.

Source preparation only. Run on the one separately released candidate. Does
not grant any all-horse fit, motion, historical or photographic acceptance.
"""
from pathlib import Path
from collections import defaultdict
import copy, hashlib, json, struct, sys, signal, time
import numpy as np
sys.path.insert(0,'/workspace/shared/horse-neck-hybrid-pipeline-next')
from exact_contact import source_edge_only
from classify_contact import classify_raw
sys.path.insert(0,'/workspace/shared/horse-combined-oral-neck-mane-prefix-next/idle-fit')
import official_fit_predicates as predicates

P=Path(__file__).parent
PARENT=Path('/workspace/shared/horse-breeching-swept-route-next/candidate-one/light_breastcollar_harness_reconstructed_01.glb')
PARENT_SHA='3bb45abfad635bda74fd2aa999dcf869269e5efad1c888dfb4d615f7b0667825'
CHANGED={'breeching','hip_support_l','hip_support_r'}
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(v,m):
    if not v:raise ValueError(m)
def read_glb(raw):
    need(struct.unpack_from('<III',raw)==(0x46546c67,2,len(raw)),'actual GLB header')
    n,tag=struct.unpack_from('<II',raw,12);need(tag==0x4e4f534a,'JSON chunk')
    d=json.loads(raw[20:20+n]);bn,tag=struct.unpack_from('<II',raw,20+n)
    need(tag==0x004e4942 and 28+n+bn==len(raw),'BIN extent')
    return d,raw[28+n:]
def values(d,b,i):
    a=d['accessors'][i];v=d['bufferViews'][a['bufferView']]
    need('sparse'not in a and not a.get('normalized') and 'byteStride'not in v,'actual flat accessor')
    need(a['componentType']==5126 and a['type']=='VEC3' and a['count']>0,'actual float3 geometry')
    start=v.get('byteOffset',0)+a.get('byteOffset',0);length=a['count']*12
    need(a.get('byteOffset',0)+length<=v['byteLength'] and start+length<=d['buffers'][0]['byteLength']<=len(b),'actual accessor extents')
    out=np.frombuffer(b,dtype='<f4',count=a['count']*3,offset=start).reshape(-1,3).astype(float)
    need(np.isfinite(out).all(),'actual finite geometry');return out

def topology(faces,vertices):
    need(len(set(map(tuple,vertices)))==len(vertices),'distinct source aliases do not collapse to identical float32 points')
    edges=defaultdict(list);links=defaultdict(list)
    for fi,f in enumerate(faces):
        need(len(set(f))==3 and all(isinstance(x,int)and 0<=x<len(vertices)for x in f),'complete source face indices')
        for j in range(3):
            a,b=f[j],f[(j+1)%3];edges[tuple(sorted((a,b)))].append((a,b,fi))
            links[a].append((f[(j+1)%3],f[(j+2)%3]))
    need(set(links)==set(range(len(vertices))),'all authored logical vertices covered')
    need(len(vertices)-len(edges)+len(faces)==2,'closed source Euler2')
    for uses in edges.values():need(len(uses)==2 and uses[0][:2]==uses[1][:2][::-1],'two opposite complete source edge uses')
    for vertex,segments in links.items():
        graph=defaultdict(set)
        for a,b in segments:graph[a].add(b);graph[b].add(a)
        need(all(len(n)==2 for n in graph.values()),'source vertex link degrees')
        seen=set();todo=[next(iter(graph))]
        while todo:
            a=todo.pop()
            if a in seen:continue
            seen.add(a);todo.extend(graph[a]-seen)
        need(seen==set(graph),'one connected source vertex link cycle')
    return {'vertices':len(vertices),'edges':len(edges),'faces':len(faces),'euler':2},set(tuple(sorted((u[0][2],u[1][2])))for u in edges.values())

def verify_clip(source):
    clip=source['clipOwnership'];need(clip and clip['axis']==1 and clip['value']==1.1135,'exact source hip termination plane')
    inputs=clip['inputVerticesRootM'];input_faces=clip['inputFaces'];owners=clip['outputVertexOwners'];faces=source['faces'];face_owners=clip['outputFaceOwners']
    need(len(owners)==len(source['verticesFloat32']) and len(face_owners)==len(faces),'complete clipping ownership')
    reconstructed=[];old={};cuts={}
    for i,owner in enumerate(owners):
        kind=owner['kind']
        if kind=='original_strip_vertex':
            need(set(owner)=={'kind','vertex'},'exact original vertex owner schema')
            j=owner['vertex'];need(isinstance(j,int) and 0<=j<len(inputs) and j not in old,'unique original source clip alias');old[j]=i;point=inputs[j]
        elif kind=='canonical_source_edge_plane_intersection':
            need(set(owner)=={'kind','edge','t','axis','value'},'exact canonical edge owner schema')
            a,b=owner['edge'];need(0<=a<b<len(inputs) and(a,b)not in cuts,'canonical source edge alias')
            u,v=inputs[a][1]-clip['value'],inputs[b][1]-clip['value'];need(u*v<0,'actual strict edge-plane source crossing');t=u/(u-v)
            need(owner['axis']==1 and owner['value']==clip['value'] and owner['t']==t,'exact recorded source clipping fraction')
            point=[inputs[a][k]*(1-t)+inputs[b][k]*t for k in range(3)];point[1]=clip['value'];cuts[a,b]=i
        elif kind=='owned_plane_cap_center':
            need(set(owner)=={'kind','boundary'},'exact owned cap center schema')
            boundary=owner['boundary'];need(boundary==clip['boundary'] and i==clip['capCenter'] and len(set(boundary))==len(boundary) and all(0<=j<i for j in boundary),'one source-owned cap center')
            point=[]
            for k in range(3):
                total=0.
                for j in boundary:total+=reconstructed[j][k]
                point.append(total/len(boundary))
            point[1]=clip['value']
        else:raise ValueError('unrecognized clipping alias owner')
        need(np.array_equal(np.asarray(point,dtype='<f4').astype(float),source['verticesFloat32'][i]),'every actual clipped serialized vertex independently replayed from owned source edge')
        reconstructed.append(point)
    expected=[];expected_owners=[]
    for fi,f in enumerate(input_faces):
        poly=[]
        for j in range(3):
            a,b=f[j],f[(j+1)%3];u,v=inputs[a][1]-clip['value'],inputs[b][1]-clip['value']
            if u>=0:need(a in old,'complete retained source vertex');poly.append(old[a])
            if u*v<0:need(tuple(sorted((a,b)))in cuts,'complete source crossed edge');poly.append(cuts[tuple(sorted((a,b)))])
        for j in range(1,len(poly)-1):expected.append([poly[0],poly[j],poly[j+1]]);expected_owners.append({'kind':'clipped_original_strip_face','face':fi})
    edges=defaultdict(list)
    for f in expected:
        for j in range(3):a,b=f[j],f[(j+1)%3];edges[tuple(sorted((a,b)))].append((a,b))
    boundary=[v[0]for v in edges.values()if len(v)==1]
    need(set(boundary)=={(a,b)for a,b in zip(clip['boundary'],clip['boundary'][1:]+clip['boundary'][:1])},'one complete registered clipping boundary')
    for a,b in boundary:
        expected.append([clip['capCenter'],b,a]);expected_owners.append({'kind':'owned_plane_cap_face','boundaryEdge':[a,b],'center':clip['capCenter']})
    need(faces==expected and face_owners==expected_owners,'every original clipped face and owned cap face exactly covered; no hidden geometry')
    need(all(p[1]>=clip['value']for p in reconstructed),'all actual hip source points above contact plane')
    return {'sourceVerticesReplayed':len(owners),'sourceFacesCovered':len(faces),'ownedBoundaryEdges':len(boundary),'strictProperExemption':False}

def dimensions(source):
    # Oblique end caps are cuts through this same constant-width strip. Their
    # longer cut edge is not incorrectly measured as the material width.
    points=np.array(source['clipOwnership']['inputVerticesRootM']if source['clipOwnership']else source['verticesRootM'],float)
    need(len(points)==source['rings']*4 and np.isfinite(points).all(),'every full original rectangular material ring')
    frame=source['constructionFrame'];basis=np.array([frame['a'],frame['b'],frame['width']],float)
    need(np.max(np.abs(basis@basis.T-np.eye(3)))<256*np.finfo(float).eps,'orthonormal full-width source frame')
    width=.052 if source['name']=='breeching'else .023;thickness=.007 if source['name']=='breeching'else .004
    bound=256*np.finfo(float).eps*max(1,float(np.max(np.abs(points))))
    rings=points.reshape(-1,4,3);width_errors=[];thickness_errors=[]
    for r in rings:
        for a,b in [(r[0],r[1]),(r[3],r[2])]:width_errors.append(abs(float(np.linalg.norm(b-a))-width))
        need(np.linalg.norm((r[1]-r[0])-(r[2]-r[3]))<=bound,'full parallel ring width edges')
    for a,b in zip(rings,rings[1:]):
        inner_a=(a[0]+a[1])/2;inner_b=(b[0]+b[1])/2;normal=np.cross(inner_b-inner_a,basis[2]);length=np.linalg.norm(normal);need(length>1e-12,'nondegenerate material segment')
        normal/=length
        for r in [a,b]:thickness_errors.append(abs(abs(float(((r[2]+r[3]-r[0]-r[1])/2)@normal))-thickness))
    need(max(width_errors)<=bound and max(thickness_errors)<=bound,'frozen exact strip width/support-plane thickness within construction floating arithmetic bound: widthErrorM='+str(max(width_errors))+' thicknessErrorM='+str(max(thickness_errors))+' unchangedBoundM='+str(bound))
    need(np.array_equal(np.asarray(source['verticesRootM'],dtype='<f4').astype(float),np.asarray(source['verticesFloat32'],float)),'every actual source vertex is exact Float32 rounding of declared unrounded construction')
    return {'widthM':width,'supportPlaneThicknessM':thickness,'maximumSourceWidthErrorM':max(width_errors),'maximumSourceThicknessErrorM':max(thickness_errors),'constructionRoundingBoundM':bound,'actualFloat32RoundingExact':True,'miterDiagonalIsNotThickness':True}

def self_check(name,tri,faces,owned_edges,output):
    lo,hi=tri.min(1),tri.max(1);records=[[name+':'+str(v)for v in f]for f in faces]
    counts={'complete':False,'pairs_in_aabb':0,'exact_source_edges':0,'raw_SAT':0,'strict_proper':0,'exact_source_vertex_only':0,'unexpected_SAT':0}
    for i,a in enumerate(tri):
        possible=np.flatnonzero(np.all(hi>=a.min(0)-1e-8,axis=1)&np.all(lo<=a.max(0)+1e-8,axis=1))
        for j in possible:
            j=int(j)
            if j<=i:continue
            b=tri[j];counts['pairs_in_aabb']+=1
            if(i,j)in owned_edges and source_edge_only(a,b,records[i],records[j])is not None:
                counts['exact_source_edges']+=1;continue
            if not predicates.sat(a,b):continue
            counts['raw_SAT']+=1;proper=predicates.proper(a,b);counts['strict_proper']+=int(proper is not None)
            detail=classify_raw(a,b,records[i],records[j],proper)
            if detail['kind']=='proven_source_vertex_only':counts['exact_source_vertex_only']+=1;continue
            counts['unexpected_SAT']+=1
            output['first_failure']={'part':name,'source_faces':[i,j],'actual_triangles':[a.tolist(),b.tolist()],'classification':detail,'counts':counts}
            raise ValueError('first complete-surface source self-embedding failure')
    counts['complete']=True;return counts

def main():
    need(len(sys.argv)==2,'explicit candidate output dir');directory=Path(sys.argv[1]);out=directory/'SERIALIZED-CHECK.json'
    need(not out.exists(),'exclusive fresh serialized-check receipt')
    started=time.monotonic();result={'PASS':False,'scope':'Actual GLB33protected +3changed source serialization/topology/self-embedding only; no horse fit or motion','parts':{}}
    def deadline(*_):raise TimeoutError('90second oneCPU serialized source check bound')
    signal.signal(signal.SIGALRM,deadline);signal.alarm(90)
    try:
        old=PARENT.read_bytes();need(sha(old)==PARENT_SHA,'exact immutable parent')
        raw=(directory/'candidate.glb').read_bytes();build=json.loads((directory/'BUILD-RESULT.json').read_text());side=json.loads((directory/'SIDECAR.json').read_text());logical_raw=(directory/'LOGICAL-SOURCE.json').read_bytes();logical=json.loads(logical_raw)
        need(build['PASS']is True and build['candidateSHA256']==side['candidateSHA256']==logical['candidateSHA256']==sha(raw),'actual emitted same-candidate receipt binding')
        need(build['sidecarSHA256']==sha((directory/'SIDECAR.json').read_bytes()) and build['logicalSourceSHA256']==sha(logical_raw),'actual source sidecar binding')
        need(build['sourceInventorySHA256']==sha((P/'SOURCE-INVENTORY.json').read_bytes()),'actual reviewed executable inventory')
        a,ab=read_glb(old);b,bb=read_glb(raw);need(bb.startswith(ab),'every original binary byte preserved')
        need(len(a['meshes'])==len(b['meshes'])==36 and [m['name']for m in a['meshes']]==[m['name']for m in b['meshes']],'all36 unique named parts preserved')
        need(len({m['name']for m in b['meshes']})==36,'no duplicate source names')
        restored=copy.deepcopy(b)
        for i,(am,bm)in enumerate(zip(a['meshes'],b['meshes'])):
            if am['name']in CHANGED:
                need(am!=bm,'every declared changed primitive changed')
                restored['meshes'][i]=copy.deepcopy(am)
            else:need(am==bm,'every protected primitive descriptor exact')
        need(len(b['accessors'])==len(a['accessors'])+6 and len(b['bufferViews'])==len(a['bufferViews'])+6,'exact six appended P/N arrays')
        restored['accessors']=restored['accessors'][:len(a['accessors'])];restored['bufferViews']=restored['bufferViews'][:len(a['bufferViews'])];restored['buffers']=copy.deepcopy(a['buffers'])
        need(restored==a,'all nodes/rig/socket-rest/material/provenance/source descriptors exact')
        need({x['name']for x in logical['parts']}==CHANGED and len(logical['parts'])==3,'complete three source-owned surfaces')
        predicates.predicate_controls()
        for source in logical['parts']:
            name=source['name'];mesh=next(m for m in b['meshes']if m['name']==name)
            need(len(mesh['primitives'])==1,'one changed actual primitive');pr=mesh['primitives'][0]
            need('indices'not in pr and pr.get('mode',4)==4 and set(pr['attributes'])=={'POSITION','NORMAL'},'complete actual flat triangles')
            pos=values(b,bb,pr['attributes']['POSITION']);normal=values(b,bb,pr['attributes']['NORMAL']);vertices=np.array(source['verticesFloat32'],float);faces=source['faces']
            need(len(pos)==len(faces)*3 and len(normal)==len(pos),'complete actual source stream')
            need(np.array_equal(pos.reshape(-1,3,3),vertices[np.array(faces)]),'every actual triangle/cap and source alias exactly serialized')
            top,owned_edges=topology(faces,vertices.tolist());tri=pos.reshape(-1,3,3)
            cross=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);areas=np.linalg.norm(cross,axis=1)/2
            need(float(areas.min())>1e-12,'actual emitted positive face areas')
            need(np.max(np.abs(np.linalg.norm(normal,axis=1)-1))<1e-6,'actual normals unit')
            need(np.all((normal.reshape(-1,3,3)[:,0]*cross).sum(1)>0),'actual outward face normals')
            clip_check=verify_clip(source)if name.startswith('hip_support')else None
            result['parts'][name]={'topology':top,'dimensions':dimensions(source),'clipSource':clip_check,'self':self_check(name,tri,faces,owned_edges,result),'actualTriangles':len(tri)}
        result['PASS']=True;result['candidateSHA256']=sha(raw);result['protectedParts']=33
    except BaseException as error:
        result['error']=repr(error);raise
    finally:
        signal.alarm(0);result['elapsedS']=time.monotonic()-started;out.write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':main()
