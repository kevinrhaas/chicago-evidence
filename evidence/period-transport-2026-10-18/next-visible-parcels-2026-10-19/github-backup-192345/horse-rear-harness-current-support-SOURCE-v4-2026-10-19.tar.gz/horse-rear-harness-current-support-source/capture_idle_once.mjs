// SPDX-License-Identifier: GPL-3.0-or-later
// One freshly reparsed actual candidate, after serialized source checks pass.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
import * as T from '/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/three.module.js';
import {GLTFLoader} from '/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/addons/loaders/GLTFLoader.js';
import {createCurrentSupportController,bindWorld} from './controller.mjs';import {POLICY} from './evaluate.mjs';
const need=(v,m)=>{if(!v)throw Error(m);},sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const directory=process.argv[2];need(directory&&process.argv.length===3,'One explicit candidate directory');
const P=path.dirname(new URL(import.meta.url).pathname),side=JSON.parse(fs.readFileSync(path.join(directory,'SIDECAR.json'))),serialized=JSON.parse(fs.readFileSync(path.join(directory,'SERIALIZED-CHECK.json')));
need(serialized.PASS===true&&serialized.candidateSHA256===side.candidateSHA256,'Actual serialized complete self check first');
const out=path.join(directory,'capture');need(!fs.existsSync(out),'Exclusive actual idle capture');fs.mkdirSync(out);
const receipt={PASS:false,scope:'Fresh actual idle0 CPU world geometry only; no physical fit acceptance',sourceInventorySHA256:sha(fs.readFileSync(path.join(P,'SOURCE-INVENTORY.json'))),files:[]};
const inputs={horse:['/workspace/shared/horse-combined-oral-neck-mane-prefix-next/candidate-one/candidate.glb',POLICY.horseSHA256],candidate:[path.resolve(directory,'candidate.glb'),side.candidateSHA256],baseline:['/workspace/shared/horse-v2-cap-registered-next/build1/light_breastcollar_harness_reconstructed_01.glb','078ed2cebc01dba52d28f2ae737f170f0fe28fd20523aed9bb8869f4cd7b35bd']};
const loader=new GLTFLoader();async function load(name){let [f,h]=inputs[name],b=fs.readFileSync(f);need(sha(b)===h,'Actual loaded input '+name);return {bytes:b,gltf:await loader.parseAsync(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),'')};}
let controller,mixer;
try{
 const horse=await load('horse'),gear=await load('candidate');
 const restTargets=new Map();gear.gltf.scene.traverse(o=>{if(o.isMesh){let a=gear.gltf.parser.associations.get(o);let name=gear.gltf.parser.json.meshes[a.meshes].name;if(['breeching','hip_support_l','hip_support_r'].includes(name))restTargets.set(name,{position:Array.from(o.geometry.attributes.position.array),normal:Array.from(o.geometry.attributes.normal.array)});}});
 need(side.sourceInventorySHA256===receipt.sourceInventorySHA256,'Candidate executable source is current reviewed source');
 controller=await createCurrentSupportController({horseGLTF:horse.gltf,gearGLTF:gear.gltf,horseBytes:horse.bytes,gearBytes:gear.bytes,expectedGearSHA256:side.candidateSHA256,releasedCandidateIdentity:{candidateSHA256:side.candidateSHA256,parentGearSHA256:side.parentGearSHA256,sourceInventorySHA256:side.sourceInventorySHA256,serializedReadbackPASS:serialized.PASS},reviewedSourceInventorySHA256:receipt.sourceInventorySHA256});
 const clips=horse.gltf.animations.filter(c=>c.name==='idle');need(clips.length===1,'Unique actual idle clip');const clip=clips[0];mixer=new T.AnimationMixer(horse.gltf.scene);const action=mixer.clipAction(clip);
 const state=controller.prepareAndUpdate({mixer,action,clip,timeS:0,phase:0,scope:'idle-study'});
 need(JSON.stringify(state.referenceLengths)===JSON.stringify(side.referenceLengths),'Actual reparsed same-policy idle reference lengths');
 for(const [name,rest]of restTargets){const actual=state.actualGeometry[name];need(rest.position.length===actual.positions.length&&rest.position.every((v,i)=>v===actual.positions[i])&&rest.normal.length===actual.normals.length&&rest.normal.every((v,i)=>v===actual.normals[i]),'Actual evaluated geometry matches serialized idle GLB exactly '+name);}
 const pose={clip:clip.name,durationS:clip.duration,timeS:0,phase:0,loop:'LoopOnce_clamp',actualActionTime:action.time},root=horse.gltf.scene.getObjectByName('root'),head=horse.gltf.scene.getObjectByName('head');
 function save(name,gltf){
  const groups=[],values=[];let start=0;
  gltf.scene.traverse(o=>{if(!o.isMesh)return;need(o.visible,'All actual model parts visible');if(o.isSkinnedMesh)o.skeleton.update();let a=gltf.parser.associations.get(o);need(a&&Number.isInteger(a.meshes)&&Number.isInteger(a.primitives),'Actual captured GLTF source association');let source=gltf.parser.json.meshes[a.meshes].primitives[a.primitives],g=o.geometry,index=g.index,count=index?index.count:g.attributes.position.count;need((source.mode===undefined||source.mode===4)&&(('indices'in source)===!!index)&&count>0&&count%3===0,'Complete actual captured primitive');need(g.drawRange.start===0&&(g.drawRange.count===Infinity||g.drawRange.count===count),'Complete actual captured draw range');
   for(let i=0;i<count;i++){let id=index?index.getX(i):i;need(Number.isInteger(id)&&id>=0&&id<g.attributes.position.count,'Actual capture index bounds');let v=o.isSkinnedMesh?o.getVertexPosition(id,new T.Vector3()):new T.Vector3().fromBufferAttribute(g.attributes.position,id);v.applyMatrix4(o.matrixWorld);need(v.toArray().every(Number.isFinite),'Actual finite world coordinate');values.push(...v.toArray());}
   groups.push({name:gltf.parser.json.meshes[a.meshes].name,sourceMesh:a.meshes,sourcePrimitive:a.primitives,start,count:count/3,positionCount:g.attributes.position.count,indexed:!!index});start+=count/3;
  });
  const bytes=Buffer.alloc(values.length*8);for(let i=0;i<values.length;i++)bytes.writeDoubleLE(values[i],i*8);
  const meta={input:inputs[name],pose,precision:'float64_world',post_world_rounding:false,rootWorld:root.matrixWorld.toArray(),headWorld:head.matrixWorld.toArray(),triangleCount:start,meshes:groups,bufferSHA256:sha(bytes),sourceInventorySHA256:receipt.sourceInventorySHA256};let json=Buffer.from(JSON.stringify(meta,null,2)+'\n');fs.writeFileSync(path.join(out,name+'.f64'),bytes,{flag:'wx'});fs.writeFileSync(path.join(out,name+'.json'),json,{flag:'wx'});receipt.files.push({name,metadataSHA256:sha(json),bufferSHA256:sha(bytes),triangleCount:start});
 }
 save('horse',horse.gltf);save('candidate',gear.gltf);
 const baseline=await load('baseline');baseline.gltf.scene.updateMatrixWorld(true);bindWorld(baseline.gltf.scene.getObjectByName('root'),root.matrixWorld);baseline.gltf.scene.updateMatrixWorld(true);bindWorld(baseline.gltf.scene.getObjectByName('harness_head'),head.matrixWorld);baseline.gltf.scene.updateMatrixWorld(true);save('baseline',baseline.gltf);
 receipt.PASS=true;receipt.candidateSHA256=side.candidateSHA256;receipt.referenceLengths=state.referenceLengths;
}catch(error){receipt.error=String(error.stack||error);process.exitCode=1;}finally{controller?.dispose();mixer?.stopAllAction();fs.writeFileSync(path.join(out,'RECEIPT.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});}
