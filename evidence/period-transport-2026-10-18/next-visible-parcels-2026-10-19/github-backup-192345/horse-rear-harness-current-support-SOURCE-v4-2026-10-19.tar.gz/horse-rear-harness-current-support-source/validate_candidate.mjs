// SPDX-License-Identifier: GPL-3.0-or-later
import fs from 'node:fs';import path from 'node:path';import validator from '/workspace/shared/transport-tools/node_modules/gltf-validator/index.js';
const d=process.argv[2];if(!d||process.argv.length!==3)throw Error('Explicit candidate dir');const out=path.join(d,'KHRONOS.json');if(fs.existsSync(out))throw Error('Exclusive validator receipt');
const result=await validator.validateBytes(new Uint8Array(fs.readFileSync(path.join(d,'candidate.glb'))),{uri:'candidate.glb',maxIssues:10000});
fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});if(result.issues.numErrors||result.issues.numWarnings)process.exitCode=2;
