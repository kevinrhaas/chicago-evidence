// SPDX-License-Identifier: GPL-3.0-or-later
export function resolve(specifier,context,nextResolve){if(specifier==='three')return{url:'file:///workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/three.module.js',shortCircuit:true};return nextResolve(specifier,context);}
