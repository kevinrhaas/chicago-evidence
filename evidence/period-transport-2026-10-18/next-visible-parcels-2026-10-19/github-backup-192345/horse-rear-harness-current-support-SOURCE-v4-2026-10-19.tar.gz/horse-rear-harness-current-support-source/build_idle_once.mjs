// SPDX-License-Identifier: GPL-3.0-or-later
// SOURCE ONLY. Requires an explicit root release receipt binding this source inventory.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import * as T from '/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/three.module.js';
import {GLTFLoader} from '/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/addons/loaders/GLTFLoader.js';
import {createCurrentSupportController} from './controller.mjs';
import {POLICY} from './evaluate.mjs';
const need=(v,m)=>{if(!v)throw Error(m);},sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const P=path.dirname(new URL(import.meta.url).pathname);
const HORSE='/workspace/shared/horse-combined-oral-neck-mane-prefix-next/candidate-one/candidate.glb';
const GEAR='/workspace/shared/horse-breeching-swept-route-next/candidate-one/light_breastcollar_harness_reconstructed_01.glb';
const GEAR_SHA='3bb45abfad635bda74fd2aa999dcf869269e5efad1c888dfb4d615f7b0667825';
const [releasePath,output]=process.argv.slice(2);need(releasePath&&output&&process.argv.length===4,'Explicit reviewed release receipt and fresh output dir');
const inventoryRaw=fs.readFileSync(path.join(P,'SOURCE-INVENTORY.json')),inventory=JSON.parse(inventoryRaw),release=JSON.parse(fs.readFileSync(releasePath));
need(release.authority==='root'&&release.allow==='ONE_IDLE_CURRENT_SUPPORT_CANDIDATE'&&release.sourceInventorySHA256===sha(inventoryRaw),'Actual root one-candidate source release');
for(const [file,want] of Object.entries(inventory.files)){need(!path.isAbsolute(file)&&!file.split('/').includes('..')&&sha(fs.readFileSync(path.join(P,file)))===want,'Frozen executable source '+file);}
need(!fs.existsSync(output),'Exclusive new actual candidate directory');fs.mkdirSync(output,{recursive:false});
const result={PASS:false,scope:'One idle current-support rear visual study candidate; no physical/photo acceptance',sourceInventorySHA256:sha(inventoryRaw),policy:POLICY,stages:[]};
let controller,mixer;
const save=()=>fs.writeFileSync(path.join(output,'BUILD-RESULT.json'),JSON.stringify(result,null,2)+'\n');
function parseGLB(raw){need(raw.readUInt32LE(0)===0x46546c67&&raw.readUInt32LE(4)===2&&raw.readUInt32LE(8)===raw.length,'GLB header');let n=raw.readUInt32LE(12);need(raw.readUInt32LE(16)===0x4e4f534a,'JSON chunk');const doc=JSON.parse(raw.subarray(20,20+n));let bn=raw.readUInt32LE(20+n);need(raw.readUInt32LE(24+n)===0x004e4942&&28+n+bn===raw.length,'BIN chunk');return {doc,bin:Buffer.from(raw.subarray(28+n))};}
function append(doc,chunks,values){let length=chunks.reduce((n,b)=>n+b.length,0);if(length%4){chunks.push(Buffer.alloc(4-length%4));length=chunks.reduce((n,b)=>n+b.length,0);}const bytes=Buffer.alloc(values.length*4);for(let i=0;i<values.length;i++)bytes.writeFloatLE(values[i],i*4);let vi=doc.bufferViews.length;doc.bufferViews.push({buffer:0,byteOffset:length,byteLength:bytes.length});chunks.push(bytes);let a=doc.accessors.length;const rows=values.length/3;doc.accessors.push({bufferView:vi,componentType:5126,count:rows,type:'VEC3',min:[0,1,2].map(k=>{let v=Infinity;for(let i=k;i<values.length;i+=3)v=Math.min(v,values[i]);return v;}),max:[0,1,2].map(k=>{let v=-Infinity;for(let i=k;i<values.length;i+=3)v=Math.max(v,values[i]);return v;})});return a;}
try{
  const hb=fs.readFileSync(HORSE),gb=fs.readFileSync(GEAR);need(sha(hb)===POLICY.horseSHA256&&sha(gb)===GEAR_SHA,'Immutable actual parent inputs');
  const loader=new GLTFLoader(),horse=await loader.parseAsync(hb.buffer.slice(hb.byteOffset,hb.byteOffset+hb.byteLength),''),gear=await loader.parseAsync(gb.buffer.slice(gb.byteOffset,gb.byteOffset+gb.byteLength),'');
  controller=await createCurrentSupportController({horseGLTF:horse,gearGLTF:gear,horseBytes:hb,gearBytes:gb,expectedGearSHA256:GEAR_SHA});
  const clips=horse.animations.filter(c=>c.name==='idle');need(clips.length===1,'Unique actual idle clip');mixer=new T.AnimationMixer(horse.scene);let action=mixer.clipAction(clips[0]);
  const measured=controller.prepareAndUpdate({mixer,action,clip:clips[0],timeS:0,phase:0,scope:'idle-study'});
  for(const part of measured.parts){const actual=measured.actualGeometry[part.name];need(actual.matrixWorld.every((v,i)=>v===measured.actualRootWorld[i]),'First idle serialized mesh frame is exactly horse-root frame');need(actual.positions.length===part.positions.length&&actual.positions.every((v,i)=>v===part.positions[i])&&actual.normals.every((v,i)=>v===part.normals[i]),'Actual installed Float32 arrays equal serialized root-frame arrays');}
  result.stages.push({stage:'Actual single current idle evaluation',parts:measured.parts.map(p=>({name:p.name,triangles:p.positions.length/9,lengthM:p.centerlineLengthM,rings:p.rings}))});save();
  // Append only the three changed P/N accessors. Every protected primitive,
  // node, material and original BIN byte is retained exactly as parent.
  const {doc,bin}=parseGLB(gb),chunks=[bin];
  need(doc.buffers.length===1&&!doc.buffers[0].uri,'Internal parent buffer');
  for(const part of measured.parts){const meshes=doc.meshes.filter(m=>m.name===part.name);need(meshes.length===1&&meshes[0].primitives.length===1,'Unique changed source primitive');const pr=meshes[0].primitives[0];need(!('indices'in pr)&&Object.keys(pr.attributes).sort().join(',')==='NORMAL,POSITION','Exact flat source primitive');pr.attributes.POSITION=append(doc,chunks,part.positions);pr.attributes.NORMAL=append(doc,chunks,part.normals);}
  const binary=Buffer.concat(chunks);doc.buffers[0].byteLength=binary.length;
  let jb=Buffer.from(JSON.stringify(doc));jb=Buffer.concat([jb,Buffer.alloc((4-jb.length%4)%4,32)]);const bb=Buffer.concat([binary,Buffer.alloc((4-binary.length%4)%4)]),header=Buffer.alloc(20),bh=Buffer.alloc(8);header.writeUInt32LE(0x46546c67,0);header.writeUInt32LE(2,4);header.writeUInt32LE(28+jb.length+bb.length,8);header.writeUInt32LE(jb.length,12);header.writeUInt32LE(0x4e4f534a,16);bh.writeUInt32LE(bb.length,0);bh.writeUInt32LE(0x004e4942,4);const raw=Buffer.concat([header,jb,bh,bb]);
  fs.writeFileSync(path.join(output,'candidate.glb'),raw,{flag:'wx'});
  const logical={scope:'Authored logical strip vertex and face ownership for independent actual serialized readback; no coordinate welding',candidateSHA256:sha(raw),parts:measured.parts.map(p=>({name:p.name,verticesRootM:p.logicalVertices,verticesFloat32:p.logicalVertices.map(v=>v.map(Math.fround)),faces:p.logicalFaces,widthM:p.widthM,constructionFrame:p.constructionFrame,rings:p.rings,clipOwnership:p.clipOwnership}))};
  fs.writeFileSync(path.join(output,'LOGICAL-SOURCE.json'),JSON.stringify(logical,null,2)+'\n',{flag:'wx'});
  const sidecar={version:POLICY.version,sourceInventorySHA256:sha(inventoryRaw),horseSHA256:POLICY.horseSHA256,parentGearSHA256:GEAR_SHA,candidateSHA256:sha(raw),policy:POLICY,referenceLengths:measured.referenceLengths,identity:measured.identity,protected33:measured.protectedParts,changed3:measured.parts.map(p=>p.name),junctions:measured.junctions,sourceCoverage:measured.sourceCoverage,limits:measured.limits,
    socketSemantics:'Two original GLB rear socket coordinates retained for byte preservation; controller updates them from the current shared sidecar record before capture/render. They are not static fit authority.',
    runtime:'Import identical controller.mjs; call prepareAndUpdate after actual horse clip action, before capture/render. Pure geometry emitted from current source triangles, not a sampled animation table.',
    completePhysicalFit:false,photographicAcceptance:false};
  fs.writeFileSync(path.join(output,'SIDECAR.json'),JSON.stringify(sidecar,null,2)+'\n',{flag:'wx'});
  result.PASS=true;result.candidateSHA256=sha(raw);result.sidecarSHA256=sha(fs.readFileSync(path.join(output,'SIDECAR.json')));result.logicalSourceSHA256=sha(fs.readFileSync(path.join(output,'LOGICAL-SOURCE.json')));save();
}catch(error){result.error=String(error.stack||error);save();process.exitCode=1;}finally{controller?.dispose();mixer?.stopAllAction();}
