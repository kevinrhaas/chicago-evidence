// SPDX-License-Identifier: GPL-3.0-or-later
// The capture caller and browser must import this same file, without a fork.
import * as T from '/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/three.module.js';
import {POLICY,evaluateCurrentSupport} from './evaluate.mjs';
const need=(v,m)=>{if(!v)throw Error(m);};
const sha=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');
const sourceName=(gltf,o)=>{const a=gltf.parser.associations.get(o);need(a&&Number.isInteger(a.meshes)&&Number.isInteger(a.primitives),'Actual GLTF primitive association');return {name:gltf.parser.json.meshes[a.meshes].name,association:a,primitive:gltf.parser.json.meshes[a.meshes].primitives[a.primitives]};};
export function bindWorld(object,target){const local=object.parent?object.parent.matrixWorld.clone().invert().multiply(target):target.clone();local.decompose(object.position,object.quaternion,object.scale);object.updateMatrixWorld(true);const err=Math.max(...object.matrixWorld.elements.map((v,i)=>Math.abs(v-target.elements[i])));need(err<=128*Number.EPSILON*Math.max(1,...target.elements.map(Math.abs)),'Actual parent-inverse world binding');}

export async function createCurrentSupportController({horseGLTF,gearGLTF,horseBytes,gearBytes,expectedGearSHA256,releasedCandidateIdentity=null,reviewedSourceInventorySHA256=null}) {
  need(await sha(horseBytes)===POLICY.horseSHA256,'Actual loaded immutable horse bytes');
  need(/^[a-f0-9]{64}$/.test(expectedGearSHA256)&&await sha(gearBytes)===expectedGearSHA256,'Actual loaded gear bytes');
  if(expectedGearSHA256!==POLICY.parentGearSHA256) {
    need(releasedCandidateIdentity?.candidateSHA256===expectedGearSHA256&&releasedCandidateIdentity?.parentGearSHA256===POLICY.parentGearSHA256&&releasedCandidateIdentity?.serializedReadbackPASS===true,'Explicit independently checked candidate identity descended from immutable parent');
    need(/^[a-f0-9]{64}$/.test(reviewedSourceInventorySHA256)&&releasedCandidateIdentity?.sourceInventorySHA256===reviewedSourceInventorySHA256,'Released candidate uses this reviewed executable source inventory');
  }
  const horseRoot=horseGLTF.scene.getObjectByName('root'),horseHead=horseGLTF.scene.getObjectByName('head');
  const gearRoot=gearGLTF.scene.getObjectByName('root'),gearHead=gearGLTF.scene.getObjectByName('harness_head');
  need(horseRoot&&horseHead&&gearRoot&&gearHead,'Actual source rig nodes');
  const coats=[],targets=new Map(),protectedParts=[];
  horseGLTF.scene.traverse(o=>{if(o.isMesh){const s=sourceName(horseGLTF,o);if(s.name==='skinned_equine_coat'){need(s.association.meshes===0&&s.association.primitives===0,'Exact coat source association');coats.push(o);}}});
  need(coats.length===1&&coats[0].isSkinnedMesh,'One complete actual skinned coat');const coat=coats[0];
  const source=sourceName(horseGLTF,coat).primitive,index=coat.geometry.index;
  need(source.mode===undefined||source.mode===4,'Actual coat triangle mode');
  need(Number.isInteger(source.indices)&&index&&index.count===POLICY.coatFaces*3&&coat.geometry.attributes.position.count===5867,'Complete actual indexed coat');
  need(coat.geometry.drawRange.start===0&&(coat.geometry.drawRange.count===Infinity||coat.geometry.drawRange.count===index.count),'No partial coat draw range');
  const indexBytes=new ArrayBuffer(index.count*4),view=new DataView(indexBytes);
  for(let i=0;i<index.count;i++){const v=index.getX(i);need(Number.isInteger(v)&&v>=0&&v<5867,'Actual coat index bounds');view.setUint32(i*4,v,true);}
  need(await sha(indexBytes)===POLICY.coatIndexSHA256,'Actual complete coat source index stream');
  gearGLTF.scene.traverse(o=>{if(o.isMesh){const s=sourceName(gearGLTF,o);if(['breeching','hip_support_l','hip_support_r'].includes(s.name)){need(!targets.has(s.name)&&!o.isSkinnedMesh&&!o.geometry.index,'Unique original flat rear target');targets.set(s.name,{object:o,original:o.geometry,current:null});}else protectedParts.push({name:s.name,object:o,geometry:o.geometry,material:o.material});}});
  need(targets.size===3&&protectedParts.length===33&&new Set(protectedParts.map(p=>p.name)).size===33,'All36 actual visible original parts');
  const sockets=Object.fromEntries(['l','r'].map(s=>{const o=gearGLTF.scene.getObjectByName('socket_harness_breeching_'+s);need(o,'Existing rear socket');return[s,o];}));
  let reference=null,disposed=false;
  return {
    prepareAndUpdate({mixer,action,clip,timeS,phase,scope='idle-study'}) {
      need(!disposed&&mixer&&action&&clip,'Owned live pose caller');
      need(horseGLTF.animations.filter(c=>c===clip).length===1&&action.getClip()===clip&&action.getMixer()===mixer&&mixer.getRoot()===horseGLTF.scene&&action.getRoot()===horseGLTF.scene,'Actual horse clip/action/mixer root association');
      need(Number.isFinite(timeS)&&Number.isFinite(phase)&&phase>=0&&phase<=1&&timeS===phase*clip.duration,'Exact actual clip time');
      mixer.stopAllAction();mixer.timeScale=1;action.reset();action.enabled=true;action.paused=false;action.setEffectiveWeight(1);action.setEffectiveTimeScale(1);action.setLoop(T.LoopOnce,1);action.clampWhenFinished=true;action.play();mixer.setTime(timeS);
      need(Math.abs(action.time-timeS)<=64*Number.EPSILON*Math.max(1,timeS),'Actual evaluated action time');
      need(action.getEffectiveWeight()===1&&action.getEffectiveTimeScale()===1&&mixer.timeScale===1,'Selected action is unblended at unit time scale');
      horseGLTF.scene.updateMatrixWorld(true);coat.skeleton.update();
      const root=horseRoot.matrixWorld.clone(),det=root.determinant();
      need(Math.abs(det-1)<1e-10&&root.elements.every(Number.isFinite),'Actual rigid unit root');
      need([3,7,11].every(i=>root.elements[i]===0)&&root.elements[15]===1,'Actual affine root row');
      for(let i=0;i<3;i++)for(let j=0;j<3;j++){
        const a=new T.Vector3().setFromMatrixColumn(root,i),b=new T.Vector3().setFromMatrixColumn(root,j);
        need(Math.abs(a.dot(b)-(i===j?1:0))<1e-10,'Actual orthonormal root columns');
      }
      const inverse=root.clone().invert(),tri=new Float64Array(POLICY.coatFaces*9),v=new T.Vector3();
      for(let i=0;i<index.count;i++){coat.getVertexPosition(index.getX(i),v);v.applyMatrix4(coat.matrixWorld).applyMatrix4(inverse);tri.set(v.toArray(),i*3);}
      const identity={horseSHA256:POLICY.horseSHA256,coatIndexSHA256:POLICY.coatIndexSHA256,clip:clip.name,timeS,phase};
      const result=evaluateCurrentSupport({coatRootTriangles:tri,identity,referenceLengths:reference,scope});
      if(!reference){need(scope==='idle-study'&&clip.name==='idle'&&timeS===0,'Freeze actual idle reference before motion');reference=Object.freeze({...result.lengths});}
      gearGLTF.scene.updateMatrixWorld(true);bindWorld(gearRoot,root);gearGLTF.scene.updateMatrixWorld(true);bindWorld(gearHead,horseHead.matrixWorld);gearGLTF.scene.updateMatrixWorld(true);
      for(const part of result.parts){
        const target=targets.get(part.name),o=target.object,geometry=new T.BufferGeometry();
        const meshFromRoot=o.matrixWorld.clone().invert().multiply(root),p=new T.Vector3(),n=new T.Vector3(),normalMatrix=new T.Matrix3().getNormalMatrix(meshFromRoot);
        const positions=new Float32Array(part.positions.length),normals=new Float32Array(part.normals.length);
        const identityMatrix=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
        if(meshFromRoot.elements.every((v,i)=>v===identityMatrix[i])){positions.set(part.positions);normals.set(part.normals);}
        else for(let i=0;i<positions.length;i+=3){p.fromArray(part.positions,i).applyMatrix4(meshFromRoot);n.fromArray(part.normals,i).applyMatrix3(normalMatrix).normalize();positions.set(p.toArray(),i);normals.set(n.toArray(),i);}
        geometry.setAttribute('position',new T.BufferAttribute(positions,3));geometry.setAttribute('normal',new T.BufferAttribute(normals,3));geometry.computeBoundingBox();geometry.computeBoundingSphere();
        o.geometry=geometry;o.visible=true;if(target.current)target.current.dispose();target.current=geometry;
      }
      // Current articulated sidecar semantics supersede the two old static
      // socket coordinates. No vehicle/force endpoint is manufactured.
      for(const side of ['l','r']){
        const o=sockets[side],world=new T.Vector3().fromArray(result.junctions[side].innerPointRootM).applyMatrix4(root);
        o.position.copy(o.parent?o.parent.worldToLocal(world):world);o.updateMatrixWorld(true);
      }
      for(const p of protectedParts)need(p.object.geometry===p.geometry&&p.object.material===p.material&&p.object.visible,'Protected33 parts unchanged and visible');
      gearGLTF.scene.updateMatrixWorld(true);
      return {...result,referenceLengths:reference,actualCoatRootTriangles:tri,
        actualGeometry:Object.fromEntries([...targets].map(([name,t])=>[name,{positions:t.object.geometry.attributes.position.array,normals:t.object.geometry.attributes.normal.array,matrixWorld:t.object.matrixWorld.toArray()}])),
        actualRootWorld:root.toArray(),actualHeadWorld:horseHead.matrixWorld.toArray(),protectedParts:protectedParts.map(p=>p.name)};
    },
    dispose(){if(disposed)return;disposed=true;for(const t of targets.values()){t.object.geometry=t.original;t.current?.dispose();}},
    getReferenceLengths(){return reference;}
  };
}
