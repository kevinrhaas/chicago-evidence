// SPDX-License-Identifier: GPL-3.0-or-later
// Independent checker fixture only: rectangular prism, no horse or GLB.
import fs from 'node:fs';import {emitStrip,clipClosedAtY} from './evaluate.mjs';
const out=process.argv[2];if(!out||process.argv.length!==3)throw Error('Explicit fresh analytic fixture path');
const frame={origin:[0,1.1135,0],a:[1,0,0],b:[0,1,0],width:[0,0,1]},p=clipClosedAtY(emitStrip([[[1,-.1],[1.004,-.1]],[[1,.1],[1.004,.1]]],frame,.023,'hip_support_l'),1.1135);
fs.writeFileSync(out,JSON.stringify({scope:'ANALYTIC rectangular prism only; no actual horse or model',name:p.name,verticesRootM:p.logicalVertices,verticesFloat32:p.logicalVertices.map(v=>v.map(Math.fround)),faces:p.logicalFaces,widthM:p.widthM,constructionFrame:p.constructionFrame,rings:p.rings,clipOwnership:p.clipOwnership})+'\n',{flag:'wx'});
