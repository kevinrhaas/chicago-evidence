# Corrected frame trial: global self embedding FAILED

Root released exactly one trial after preflight44592 exited. Reviewed source c1531b28 and caller c91fc6a8 ran on CPU1 in the supported profile, terminating exit1 after30.056792 seconds. Candidate f644710ddd19a1be3deee594278bde550b744ea2d2c013e4388c2586145bb8b6 is UNACCEPTED.

All four actual original negative stages passed. Build,decoded readback,Khronos and actual idle0 capture passed. Both exact full-strip spatial trilinear-cell Jacobian proofs passed; all18 source-owned contact registrations opposed correctly. Both selected iron underside normals,actual centerline relations,and inner-to-outer material directions passed independent decoded checks. These local source/frame results did not claim global planar-mesh embedding.

The actual closed-shell self scan stopped at left stirrup leather faces88/865. The outgoing and return branches strictly properly cross near(0.23112964,1.41141453,-0.04818672)m. Complete actual Float64 triangle coordinates,source indices,strict plane distances and face barycentrics are in self/self.json. Twenty scopes completed before the failing21st scope; all29 scopes did NOT pass.

No interpart,wholehorse or browser check ran. No source correction,repeated trial,parameter search or exemption followed. The frame correction resolved the prior interface orientation defect,while the global embedding guard exposed a separate branch routing failure. Photographic,period visual,rider,load,pressure and motion acceptance remain open. Further saved-output diagnosis and independently reviewed source correction are required before another actual trial can be released.
