"""Exact handler mock and metadata serializer AST controls; no producer import."""
from pathlib import Path
import ast,copy,json,hashlib,subprocess,signal,types
P=Path('/workspace/shared/horse-neutral-rail-closed-producer-next')
tree=ast.parse((P/'run_once.py').read_text());handler=next(n for n in ast.walk(tree)if isinstance(n,ast.Try) and any(isinstance(h.type,ast.Name)and h.type.id=='BaseException'for h in n.handlers) and len(n.body)==1 and isinstance(n.body[0],ast.Assign) and isinstance(n.body[0].value,ast.Call) and isinstance(n.body[0].value.func,ast.Attribute) and n.body[0].value.func.attr=='wait')
module=ast.fix_missing_locations(ast.Module(body=[handler],type_ignores=[]));cases=[]
class Stop(BaseException):pass
for name,exc,gone in [('normal',None,False),('timeout',subprocess.TimeoutExpired('mock',7),False),('keyboard',KeyboardInterrupt(),False),('baseexception',Stop(),False),('ordinary',ValueError('mock'),False),('already_gone',KeyboardInterrupt(),True)]:
 calls=[]
 class Child:
  pid=987654321
  def wait(self,**kw):
   calls.append(['wait',kw])
   if len(calls)==1 and exc is not None:raise exc
   return 0
 def killpg(pid,sig):
  calls.append(['killpg',pid,sig])
  if gone:raise ProcessLookupError()
 ns={'child':Child(),'remain':7,'os':types.SimpleNamespace(killpg=killpg),'signal':signal,'subprocess':subprocess};raised=None
 try:exec(compile(module,'<exact-wait-handler>','exec'),ns)
 except BaseException as e:raised=type(e).__name__
 expected_raised=None if name in ['normal','timeout'] else type(exc).__name__
 if raised!=expected_raised:raise ValueError('Wrong rethrow '+name)
 if name=='normal':
  if len(calls)!=1 or ns['code']!=0:raise ValueError('Normal handler')
 else:
  if calls[1:]!=[['killpg',987654321,signal.SIGKILL],['wait',{}]]:raise ValueError('Wrong ownership/reap '+name)
  if name=='timeout'and ns['code']!=124:raise ValueError('Timeout status lost')
 cases.append({'case':name,'PASS':True,'calls':calls,'raised':raised})
source=ast.parse((P/'conforming_variant.py').read_text());serializer=next(n for n in source.body if isinstance(n,ast.FunctionDef)and n.name=='serialize')
oldtree=ast.parse(Path('/workspace/shared/horse-neutral-closed-anterior-producer-next/conforming_variant.py').read_text());old=next(n for n in oldtree.body if isinstance(n,ast.FunctionDef)and n.name=='serialize')
if ast.dump(serializer)!=ast.dump(old):raise ValueError('Serializer changed unexpectedly')
doc={'meshes':[{'primitives':[{'untouched':1}]},{'primitives':[{'attributes':{'old':1},'indices':4,'material':1,'extras':{'provenance':'dark'},'extensions':{'TEST':1}},{'attributes':{'old':1},'indices':7,'material':0,'extras':{'provenance':'coat'}}]}],'nodes':[{'unchanged':1}],'materials':[{'same':1}]};snap=copy.deepcopy(doc);b=b'prefix';calls=[]
def append(d,buf,array,kind,**kw):calls.append((kind,kw));buf.extend(b'x');return len(calls)+99
def encode(d,buf):return d,bytes(buf)
class Array:
 def reshape(self,*a):return self
ns={'copy':copy,'ATTRS':['POSITION','NORMAL','JOINTS_0','WEIGHTS_0'],'append':append,'encode':encode};exec(compile(ast.Module(body=[serializer],type_ignores=[]),'<exact-serializer>','exec'),ns)
ctx={'c':{'model':types.SimpleNamespace(d=doc,b=b)}};new,buf=ns['serialize'](ctx,{k:Array()for k in ns['ATTRS']},{(1,0):Array(),(1,1):Array()})
if doc!=snap or buf[:len(b)]!=b or len(calls)!=6:raise ValueError('Source mutation/prefix/record count')
for pi in range(2):
 for k,v in snap['meshes'][1]['primitives'][pi].items():
  if k not in ['attributes','indices'] and new['meshes'][1]['primitives'][pi][k]!=v:raise ValueError('Metadata loss '+k)
if new['nodes']!=snap['nodes']or new['materials']!=snap['materials']or new['meshes'][0]!=snap['meshes'][0]:raise ValueError('Other document changed')
r={'PASS':True,'scope':'Exact caller wait-handler mocks and serializer AST on synthetic metadata only. No producer/model/new XYZ/GLB/capture/SAT/browser.','handler_cases':cases,'serializer_unchanged_from_previous_review':True,'serializer_synthetic_metadata_extras_extensions_materials_PREFIX':True,'run_once_sha256':hashlib.sha256((P/'run_once.py').read_bytes()).hexdigest()}
Path('/workspace/shared/horse-neutral-rail-closed-INDEPENDENT-CALLER-SERIALIZER-CONTROLS.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'PASS':True,'handler_cases':len(cases),'serializer_metadata_preserved':True}))
