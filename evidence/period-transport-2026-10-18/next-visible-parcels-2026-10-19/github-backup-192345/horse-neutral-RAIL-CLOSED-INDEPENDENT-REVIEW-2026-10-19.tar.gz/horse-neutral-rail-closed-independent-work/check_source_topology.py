"""Independent labels/indices/topology/scalar audit; no POSITION/field access."""
from pathlib import Path
from fractions import Fraction as Q
from collections import defaultdict,Counter
import json,struct,hashlib,bisect
P=Path('/workspace/shared/horse-neutral-rail-closed-producer-next')
A=json.loads((P/'complete-symbolic.json').read_text())
O=json.loads(Path('/workspace/shared/horse-neutral-lip-conforming-metadata-preserving-next/complete-symbolic.json').read_text())
def need(v,m):
 if not v:raise ValueError(m)
def edge_map(T):
 d=defaultdict(list)
 for fi,t in enumerate(T):
  need(len(t)==3 and len(set(t))==3,'triangle')
  for a,b in zip(t,t[1:]+t[:1]):d[tuple(sorted([a,b]))].append((fi,a,b))
 return d
def proof(T,expected=None):
 need(len(set(tuple(sorted(t))for t in T))==len(T),'unique faces');E=edge_map(T);V={v for t in T for v in t};B={e for e,u in E.items()if len(u)==1}
 need(all(len(u)==1 or len(u)==2 and u[0][1:]==u[1][1:][::-1] for u in E.values()),'directed incidence')
 if expected is not None:need(B==expected,'exact boundary')
 boundaryV={v for e in B for v in e};links=defaultdict(list)
 for t in T:
  for i,v in enumerate(t):links[v].append((t[(i+1)%3],t[(i+2)%3]))
 for v,L in links.items():
  adj=defaultdict(set)
  for a,b in L:adj[a].add(b);adj[b].add(a)
  seen=set();todo=[next(iter(adj))]
  while todo:
   x=todo.pop()
   if x not in seen:seen.add(x);todo.extend(adj[x]-seen)
  need(len(seen)==len(adj),'vertex link connected');degrees=Counter(map(len,adj.values()));need(degrees==(Counter({1:2,2:len(adj)-2})if v in boundaryV else Counter({2:len(adj)})),'disk/half-disk link')
 adj=defaultdict(set)
 for u in E.values():
  if len(u)==2:adj[u[0][0]].add(u[1][0]);adj[u[1][0]].add(u[0][0])
 seen=set();todo=[0]
 while todo:
  x=todo.pop()
  if x not in seen:seen.add(x);todo.extend(adj[x]-seen)
 need(len(seen)==len(T),'one face component')
 return {'V':len(V),'E':len(E),'F':len(T),'Euler':len(V)-len(E)+len(T),'boundary':len(B),'all_vertex_links':len(V),'connected':True,'directed_manifold':True},B
inverse={v:k for k,v in O['seam_equivalences'].items()}
def chart(tag):return (tag if tag.startswith(('cut:','inner:'))else inverse[tag]).split(':')
removed={'upper':[],'lower':[]}
for i,(t,o)in enumerate(zip(O['triangles'],O['owners'])):
 if o['kind']!='wet_lining':continue
 c=[(k,Q(z),Q(th))for k,z,th in map(chart,t)]
 if min(z for _,z,_ in c)<Q('0.420'):continue
 if all(th in [26,46]or z==Q('.532')for _,z,th in c):removed['upper'].append(i)
 elif all(th in [28,44]or z==Q('.530')for _,z,th in c):removed['lower'].append(i)
need(removed==A['removed_lining_faces'],'independent source disk selection')
retired=set(sum(removed.values(),[]));keep=[i for i in range(len(O['triangles']))if i not in retired]
need(keep==A['old_face_retained_indices'],'exact original retained ledger')
need(A['triangles'][:len(keep)]==[O['triangles'][i]for i in keep] and A['owners'][:len(keep)]==[O['owners'][i]for i in keep],'kept original source/orientation/owner')
disks={s:proof([O['triangles'][i]for i in ids])[0]for s,ids in removed.items()}
oldmouth,oldB=proof(O['triangles']);mouth,B=proof(A['triangles'],oldB)
need(mouth['Euler']==-1 and mouth['boundary']==66,'mouth genus one with one boundary')
rings=[{Q(k):v for k,v in r.items()}for r in A['rings']];union=set(rings[0])|set(rings[-1]);need(len(union)==182,'union phases')
for r in range(1,4):need(set(rings[r])==union and all(v==f'seal:{r}:{q}'for q,v in rings[r].items()),'three exact interior rings')
rail_checks=0
for q in union:
 need(0<=q<=1 or Q('1.1')<=q<=Q('2.1'),'no novel corner interior phase')
 queries=[q,Q('2.1')-q] if q<=1 else[q]
 for query in queries:
  for row in [rings[0],rings[-1]]:
   keys=sorted(row)
   if query not in row:
    n=bisect.bisect_left(keys,query);need(0<n<len(keys),'bracket');lo,hi=keys[n-1:n+1];need((lo<=hi<=1)or(Q('1.1')<=lo<=hi),'no interpolation across return gap');f=(query-lo)/(hi-lo);need(0<f<1,'positive interpolation')
   rail_checks+=1
# Decode old GLB JSON/index accessors only, never positions/normals/weights.
f=Path('/workspace/shared/horse-cheek-throat-quality-next/candidate-one/candidate.glb');raw=f.read_bytes();need(hashlib.sha256(raw).hexdigest()=='57d63e2d7234380adeb727f5efeeed74d50629b2a8367ccea48961d6ecc5bec2','old source')
n=struct.unpack_from('<I',raw,12)[0];D=json.loads(raw[20:20+n]);buf=raw[28+n:];g=json.loads(Path('/workspace/shared/horse-combined-oral-neck-mane-prefix-next/candidate-one/graft-proof.json').read_text());labels={(r['mesh'],r['vertex']):r['label']for r in g['source_labels']};heads=set(g['head_faces']);gid=0;oldhead=[];headkept=[];retired334=[];oral={}
for mi,m in enumerate(D['meshes']):
 for pi,p in enumerate(m['primitives']):
  a=D['accessors'][p['indices']];v=D['bufferViews'][a['bufferView']];fmt={5121:'B',5123:'H',5125:'I'}[a['componentType']];size=struct.calcsize('<'+fmt);off=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',size);ids=[struct.unpack_from('<'+fmt,buf,off+i*stride)[0]for i in range(a['count'])]
  for j in range(0,len(ids),3):
   if gid in heads:
    t=[labels[mi,x]for x in ids[j:j+3]];oldhead.append(t);o=g['source_face_owners'][str(gid)]
    if o.get('kind')=='oral_channel':oral[o['oral_generated_face']]=(gid,t)
    if o.get('kind')=='oral_channel'and o['source_owner']['kind']in ['oral_rim_connector','oral_roof','oral_floor','oral_back']:retired334.append(gid)
    else:headkept.append(t)
   gid+=1
parent,headB=proof(oldhead);head,_=proof(headkept+A['triangles'],headB)
posterior=[]
for i,(t,o)in enumerate(zip(A['triangles'],A['owners'])):
 if o['kind']=='retained_cavity_clip' and o['oral_source_face']in oral:
  gid,ot=oral[o['oral_source_face']]
  if any(t==ot[k:]+ot[:k]for k in range(3)):posterior.append(gid)
need(len(set(posterior))==110 and len(posterior)==110,'110 exact cyclic source posterior faces')
need(len(retired334)==334 and head['Euler']==-1 and head['F']==4964 and head['boundary']==28,'full head')
report={'PASS':True,'scope':'Independent source label surgery, all edges/links/components, old GLB JSON/index buffers ONLY and scalar rail-domain checks. No P/JW fields/new XYZ/model/SAT/export/capture.','removed_disks':disks,'kept_old_faces':len(keep),'new_annulus_faces':len(A['triangles'])-len(keep),'rings':[len(r)for r in rings],'mouth':mouth,'old_head':parent,'assembled_head':head,'posterior_oriented_exact':len(posterior),'rail_scalar_domain_checks':rail_checks,'local_convexity_is_global_embedding_proof':False}
Path('/workspace/shared/horse-neutral-rail-closed-INDEPENDENT-TOPOLOGY.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
