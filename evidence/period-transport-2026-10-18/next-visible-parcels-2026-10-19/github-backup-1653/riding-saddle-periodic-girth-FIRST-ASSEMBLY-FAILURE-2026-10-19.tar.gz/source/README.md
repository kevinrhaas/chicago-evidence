# SOURCE ONLY — periodic girth closure, eleven layer hypothesis fixed

Prior50463 firstactualfailure and b481 archive remain immutable. Root authorized this explicit12changed/17protected revision, not a contact exemption. No new candidate, model input evaluation, capture, SAT or browser has run for this revision. Actual qualification MUST WAIT for root's post-preflight CPU lane release and full independent source PASS.

## One fixed correction

`periodic_girth.py` reconstructs388 source ring-corner identities from the exact pinned A457 expanded772triangle stream. Full POSITION hash ab5527... and every repeated source alias are checked. The97 old ring centers include duplicate endpoint. Preserve the first96 centers; require duplicate endpoint agreement within2e-7m, +Z55mm width and4mm thickness. Use periodic centered tangents (previous/next modulo96), same width axis, continuous outward section frame. Emit384vertices/768triangles, connected closed genus1/Euler0, no endcaps. No radius inflation, offset search or body refit. This is a reconstructed engineering band, not a claim about1835buckles/force distribution.

All eleven existing layer functions AND saddle_sections.json remain byte-identical to source468a5/Authority517795. Caller enforces both source/recipe hashes. Independent actual readback also requires firstcandidate50463 as a hard-pinned control: full priorBIN prefix/accessor/view arrays and all eleven primitive definitions must match exactly. This prevents an incidental layer change from hiding behind the girth correction. Original A457 baseline binary, seventeen nonsaddle mesh definitions, original nodes/rig/reins/skins/sockets/materials/animations remain exact.

## Gates — prepared, NOT RUN

Python stdlib producer; NumPy decoded/self check; Node+existing Three0.185.1 actual capture; original retained SAT/proper/source-simplex helpers. No Blender/network/new runtime dependency. Outside Three loader still has the declared local app-vendor binding; not an installed portable app parcel.

1. Full independent source/recipe/caller/guards review; root CPU lane release.
2. Actual `check_girth_negative.py A457 FRESH_NEGATIVE`: reconstruct original canonicalfaces0/760 from exact actualGLB and require unchangedSAT+strictproper witness. Existing priorbufferwitness remains provenance, not a cachedgreen.
3. ONE<=30s `build_candidate.py --gear-input A457 --horse-input 6e9b --horse-manifest MANIFEST --parameters saddle_sections.json --output-dir FRESH_CANDIDATE`.
4. `check_actual.py A457 NEW saddle_sections.json PREVIOUS_50463 FRESH_READBACK`: eleven actual layer arrays/indices unchanged; girth384v768f/Euler0; all twelve actual closed topology/active rigid frames/finite/unit normals; seventeen protected. Independent girth section/ring centers/width/thickness/periodic frame/complete moduloindices checked.
5. Khronos actual bytes, external fetch refused; preserve inherited two skin warnings and all infos; no0warnings claim.
6. Existing capture arguments HORSE A457 NEW FRESH_CAPTURE REVIEWED_NEW_SHA: actualidle0, actual head parent-inverse, full29gear/all14172horse triangles.
7. `check_self.py CAPTURE NEW FRESH_SELF REVIEWED_NEW_SHA`: all actual closed gear parts, all trianglepairs; twelve changed shells mandatory (elevenEuler2+girthEuler0). Exact owned-simplex certificates, no adjacency exemption; new vertex uniqueness and vertex-link manifold checks. Fixed open/nonmanifold targets reported non-solid and retain all interpartSAT.
8. `check_layers.mjs CAPTURE FRESH_FIT REVIEWED_NEW_SHA SELF/self.json`: all66changed/changed+204changed/fixed=270unordered pairs, all triangles/caps, no exemptions; then all12 vsALLhorse. Complete hash-bound selfscan required for every closed winding target. Report true contacts/fail first; do not erase pressure or accept force/cloth/animal fit.

Stop and preserve the FIRST actual failure at any stage. No automatic retry, geometry/threshold parameter search or browser before full technical PASS. The new source is not permission to run during root's full gate.

## Evidence and rights

Existing original geometry CC0-1.0; new periodic helper/caller/recipe originalCC0. Inherited exact self/contact/capture/predicate tools remain GPL-3.0-or-later (fullnotice included). Existing1833actualOCR supports paired linen/hair panels, woodtree, smooth restrainedpadding and quarters; sourcepages/pixels notcollated, no measured cut. No1902backdating/Chicagoowner/sourceID invention. Period/photo/master/rider/pressure/load/motion remain UNACCEPTED. No app or central ticket edits.
