# SPDX-License-Identifier: CC0-1.0
"""SOURCE ONLY periodic closure repair; no import-time model IO or evaluation.
Exact old expanded authored ring identities are reconstructed, never nearest-fit.
The eleven layer geometry functions remain byte-identical to their first trial.
"""
import math,hashlib,struct
from collections import defaultdict
from topology import cross3
N=96;WIDTH=.055;THICK=.004
SOURCE_POSITION_SHA='ab552780b1379c9ba467dcb0a7cdf5e5b8cdf4a4a15f82cfcf2e26e5c49f0e45'
def need(q,m):
 if not q:raise ValueError(m)
def unit(v):
 length=math.sqrt(math.fsum(x*x for x in v));need(length>1e-10,'Nonzero periodic tangent');return [x/length for x in v]
def authored_faces():
 faces=[]
 for j in range(N):
  for k in range(4):
   a=j*4+k;b=j*4+(k+1)%4;c=b+4;e=a+4;faces.extend([(a,b,c),(a,c,e)])
 faces.extend([(0,2,1),(0,3,2),(N*4,N*4+1,N*4+2),(N*4,N*4+2,N*4+3)])
 return faces

def source_centers(expanded):
 need(len(expanded)==2316 and all(len(v)==3 and all(math.isfinite(x)for x in v)for v in expanded),'Exact original772 expanded triangles')
 raw=struct.pack('<'+'f'*(len(expanded)*3),*(x for row in expanded for x in row));need(hashlib.sha256(raw).hexdigest()==SOURCE_POSITION_SHA,'Pinned actual A457 girth POSITION bytes')
 aliases={}
 for i,p in zip([i for f in authored_faces()for i in f],expanded):
  p=tuple(p)
  if i in aliases:need(aliases[i]==p,'Actual source ring alias identity')
  aliases[i]=p
 need(len(aliases)==388,'Complete original97ring ownership')
 centers=[]
 for j in range(N+1):
  q=[aliases[j*4+k]for k in range(4)];centers.append([math.fsum(v[a]for v in q)/4 for a in range(3)])
  width=[q[1][a]-q[0][a]for a in range(3)];thick=[q[3][a]-q[0][a]for a in range(3)]
  need(max(abs(width[a]-(WIDTH if a==2 else 0))for a in range(3))<=2e-7,'Original55mm +Z width vector')
  need(abs(math.sqrt(math.fsum(x*x for x in thick))-THICK)<=2e-7,'Original4mm thickness')
  need(abs(math.fsum(width[a]*thick[a]for a in range(3)))<=2e-8,'Original orthogonal source section')
  need(max(abs((q[0][a]+q[2][a])-(q[1][a]+q[3][a]))for a in range(3))<=2e-7,'Original rectangular source section')
 need(max(abs(centers[0][a]-centers[-1][a])for a in range(3))<=2e-7,'Actual duplicate endpoint center before periodic repair')
 need(all(abs(c[2]+.15)<=2e-7 for c in centers),'Preserve original girth Z plane')
 return centers[:N]

def finish_periodic(v,f):
 edges=defaultdict(list);adj=defaultdict(set)
 for a,b,c in f:
  need(len({a,b,c})==3 and min(a,b,c)>=0 and max(a,b,c)<len(v),'Periodic actual indices')
  for u,w in ((a,b),(b,c),(c,a)):edges[tuple(sorted((u,w)))].append((u,w));adj[u].add(w);adj[w].add(u)
 need(all(len(e)==2 and e[0]==e[1][::-1]for e in edges.values()),'Closed opposite periodic edges')
 seen=set();todo=[0]
 while todo:
  i=todo.pop()
  if i in seen:continue
  seen.add(i);todo.extend(adj[i]-seen)
 need(len(seen)==len(v)and len(v)-len(edges)+len(f)==0,'Connected genus1 band Euler0')
 volume=math.fsum(math.fsum(v[a][i]*cross3(v[b],v[c])[i]for i in range(3))for a,b,c in f)/6
 need(abs(volume)>1e-10,'Nonzero band material volume')
 if volume<0:f=[(a,c,b)for a,b,c in f]
 normals=[[0.,0.,0.]for _ in v]
 for a,b,c in f:
  q=cross3([v[b][i]-v[a][i]for i in range(3)],[v[c][i]-v[a][i]for i in range(3)]);need(math.sqrt(math.fsum(x*x for x in q))>1e-11,'Nondegenerate periodic face')
  for j in (a,b,c):
   for i in range(3):normals[j][i]+=q[i]
 normals=[unit(q)for q in normals];need(all(math.isfinite(x)for row in v+normals for x in row),'Finite band geometry')
 return v,normals,f

def periodic_girth(expanded):
 centers=source_centers(expanded);v=[];faces=[]
 for j,c in enumerate(centers):
  tangent=unit([centers[(j+1)%N][a]-centers[(j-1)%N][a]for a in range(3)])
  need(abs(tangent[2])<1e-5,'Actual planar periodic tangent')
  side=[0.,0.,1.];normal=unit(cross3(tangent,side))
  for sw,st in ((-1,-1),(1,-1),(1,1),(-1,1)):
   v.append([c[a]+side[a]*sw*WIDTH/2+normal[a]*st*THICK/2 for a in range(3)])
 for j in range(N):
  for k in range(4):
   a=j*4+k;b=j*4+(k+1)%4;c=((j+1)%N)*4+(k+1)%4;e=((j+1)%N)*4+k;faces.extend([(a,b,c),(a,c,e)])
 need(len(v)==384 and len(faces)==768,'Exactly96 unique periodic stations, no endcaps')
 return finish_periodic(v,faces),{'source_position_sha256':SOURCE_POSITION_SHA,'source_stations':97,'new_unique_stations':96,'width_m':WIDTH,'thickness_m':THICK,'new_vertices':384,'new_faces':768,'expected_Euler':0,'centerline_authority':'Actual original ring centers; duplicate endpoint removed within2e-7m; no radius/body refit','fit_accepted':False}
