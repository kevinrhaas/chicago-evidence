# SPDX-License-Identifier: CC0-1.0
"""Actual decoded storage, active authored frame and twelve closed section shells."""
from pathlib import Path
import argparse,hashlib,json,struct,collections,math
import numpy as np
from layer_authority import CHANGED as LAYER_CHANGED,validate
CHANGED=LAYER_CHANGED|{'riding_girth'}

def need(ok,msg):
 if not ok:raise ValueError(msg)
def load(p):
 raw=p.read_bytes();need(struct.unpack_from('<III',raw)==(0x46546c67,2,len(raw)),'GLB header');n,t=struct.unpack_from('<II',raw,12);need(t==0x4e4f534a,'JSON type');size,t=struct.unpack_from('<II',raw,20+n);need(t==0x004e4942 and 28+n+size==len(raw),'BIN type/length');return json.loads(raw[20:20+n]),raw[28+n:],raw
def array(d,b,i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];need('byteStride'not in v and'sparse'not in a,'Plain accessor');dtype={5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']];c={'SCALAR':1,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];return np.frombuffer(b,dtype=dtype,count=a['count']*c,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,c)
def topology(P,F,expected_euler=2):
 need(len(P)>0 and len(F)>0 and int(F.min())>=0 and int(F.max())<len(P),'Component bounds');edges=collections.defaultdict(list);adj=collections.defaultdict(set)
 for f in F:
  need(len(set(f))==3,'Repeated triangle ID')
  for u,v in zip(f,np.roll(f,-1)):u=int(u);v=int(v);edges[tuple(sorted((u,v)))].append((u,v));adj[u].add(v);adj[v].add(u)
 need(all(len(e)==2 and e[0]==e[1][::-1]for e in edges.values()),'Closed opposite edges');seen=set();todo=[0]
 while todo:
  i=todo.pop()
  if i in seen:continue
  seen.add(i);todo.extend(adj[i]-seen)
 need(len(seen)==len(P) and len(P)-len(edges)+len(F)==expected_euler,'Connected declared Euler');A=P[F];cross=np.cross(A[:,1]-A[:,0],A[:,2]-A[:,0]);area=np.linalg.norm(cross,axis=1)/2;need(float(area.min())>1e-11,'Actual nondegenerate triangle');volume=float(np.einsum('ij,ij->i',A[:,0],np.cross(A[:,1],A[:,2])).sum()/6);need(volume>0,'Actual outward volume');return {'vertices':len(P),'triangles':len(F),'minimum_area_m2':float(area.min()),'volume_m3':volume,'Euler':expected_euler}
def check(oldpath,newpath,params,layer_control,out):
 out.mkdir();r={'passed':False,'scope':'Actual storage/component/bow envelope/shared-seam only; no horsefit/pressure/rider/period/photo acceptance'}
 try:
  old,ob,raw=load(oldpath);d,b,nraw=load(newpath);p=json.loads(params.read_text());need(hashlib.sha256(raw).hexdigest()=='a457874a81b624f5e9642d3296b1350eb49b17d21d38099fbe66080711c17021','A457 pin');r['candidate_sha256']=hashlib.sha256(nraw).hexdigest();r['parameters_sha256']=hashlib.sha256(params.read_bytes()).hexdigest();need(b[:len(ob)]==ob,'Old BIN prefix');need(d['accessors'][:len(old['accessors'])]==old['accessors']and d['bufferViews'][:len(old['bufferViews'])]==old['bufferViews'],'Old storage refs');need(len(d['meshes'])==len(old['meshes'])==29,'Exact29mesh cohort')
  previous,pb,praw=load(layer_control);need(hashlib.sha256(praw).hexdigest()=='50463c358935677ce0413ae58006dba9df1cfadf21b477df18492042bd1683b5','Exact first eleven-layer candidate control')
  need(b[:len(pb)]==pb and d['accessors'][:len(previous['accessors'])]==previous['accessors'] and d['bufferViews'][:len(previous['bufferViews'])]==previous['bufferViews'],'Full actual eleven-layer binary/accessor prefix exact')
  for name in LAYER_CHANGED:need(next(m for m in d['meshes']if m['name']==name)==next(m for m in previous['meshes']if m['name']==name),'Eleven actual layer primitive refs exact '+name)
  r['eleven_layer_control_sha256']=hashlib.sha256(praw).hexdigest();r['eleven_layer_control_BIN_prefix_bytes']=len(pb)
  for k in ['nodes','skins','animations','materials','scenes','scene']:need(old.get(k)==d.get(k),'Protected '+k)
  parts={};total=0;protected=[];rows={}
  for om,nm in zip(old['meshes'],d['meshes']):
   name=om['name'];need(nm['name']==name,'Name/order')
   for pr in nm['primitives']:total+=(len(array(d,b,pr['indices']))if'indices'in pr else len(array(d,b,pr['attributes']['POSITION'])))//3
   if name not in CHANGED:need(om==nm,'Protected mesh '+name);protected.append(name);continue
   need(len(nm['primitives'])==1,'Single changed primitive');pr=nm['primitives'][0];need(set(pr['attributes'])=={'POSITION','NORMAL'}and pr['material']==om['primitives'][0]['material'],'Rigid material/attributes');P=array(d,b,pr['attributes']['POSITION']).astype(float);N=array(d,b,pr['attributes']['NORMAL']).astype(float);F=array(d,b,pr['indices']).reshape(-1,3);need(np.isfinite(P).all()and np.isfinite(N).all(),'Finite geometry');need(np.max(abs(np.linalg.norm(N,axis=1)-1))<1e-6,'Unit normals');parts[name]=(P,F)
   rows[name]=topology(P,F,0 if name=='riding_girth'else 2)
   if name=='riding_girth':
    need(P.shape==(384,3) and F.shape==(768,3),'Exact periodic96ring band');continue
   M=p['angular_segments']+1;Z=2 if name in ('front_bow','rear_bow') else len(p['z_stations_m'])
   expected_faces=4*(Z-1)*(M-1)+4*(Z+M-2)
   need(P.shape==(2*Z*M,3) and len(F)==expected_faces,'Exact authored section lattice '+name)
  validate(p);need(len(protected)==17 and set(parts)==CHANGED,'Exactly twelve retired/rebuilt and seventeen protected')
  # Independent actual girth section readback: source authored expanded order
  # establishes centers; no generator helper or nearest-point fit is invoked.
  oldg=next(m for m in old['meshes']if m['name']=='riding_girth')['primitives'][0]
  need('indices'not in oldg,'Pinned original expanded girth')
  expanded=array(old,ob,oldg['attributes']['POSITION']).astype(float)
  need(hashlib.sha256(expanded.astype('<f4').tobytes()).hexdigest()=='ab552780b1379c9ba467dcb0a7cdf5e5b8cdf4a4a15f82cfcf2e26e5c49f0e45','Original girth POSITION pin')
  source_faces=[]
  for j in range(96):
   for k in range(4):
    a=j*4+k;bb=j*4+(k+1)%4;c=bb+4;e=a+4;source_faces.extend([(a,bb,c),(a,c,e)])
  source_faces.extend([(0,2,1),(0,3,2),(384,385,386),(384,386,387)])
  aliases={}
  for label,point in zip([i for face in source_faces for i in face],expanded):
   if label in aliases:need(np.array_equal(aliases[label],point),'Original actual girth aliases')
   aliases[label]=point
  need(len(aliases)==388,'Complete original ring identities')
  original_centers=np.array([[aliases[4*j+k]for k in range(4)]for j in range(97)]).mean(axis=1)
  GP,GF=parts['riding_girth'];rings=GP.reshape(96,4,3);centers=rings.mean(axis=1);error=float(np.max(abs(centers-original_centers[:96])))
  need(error<=2e-7 and float(np.max(abs(original_centers[0]-original_centers[-1])))<=2e-7,'Actual periodic centerline preserved')
  widths=rings[:,1]-rings[:,0];thickness=rings[:,3]-rings[:,0]
  need(float(np.max(abs(widths-np.array([0,0,.055]))))<=2e-7,'Actual55mm +Z width')
  need(float(np.max(abs(np.linalg.norm(thickness,axis=1)-.004)))<=2e-7,'Actual4mm thickness')
  tangent=np.roll(centers,-1,axis=0)-np.roll(centers,1,axis=0);tangent/=np.linalg.norm(tangent,axis=1)[:,None];outward=np.cross(tangent,np.array([0,0,1]));outward/=np.linalg.norm(outward,axis=1)[:,None]
  need(float(np.max(abs(thickness/.004-outward)))<=1e-4,'Actual periodic centered frame, no one-sided closure')
  expected=[]
  for j in range(96):
   for k in range(4):
    a=j*4+k;bb=j*4+(k+1)%4;c=((j+1)%96)*4+(k+1)%4;e=((j+1)%96)*4+k;expected.extend([(a,bb,c),(a,c,e)])
  expected=np.array(expected);need(np.array_equal(GF,expected)or np.array_equal(GF,expected[:,[0,2,1]]),'Actual complete96periodic segment indices; no endcaps')
  r['girth_contract']={'unique_stations':96,'vertices':384,'triangles':768,'Euler':0,'maximum_centerline_error_m':error,'width_m':.055,'thickness_m':.004,'all_periodic_faces_exact':True,'no_animal_pressure_or_motion_acceptance':True}
  # Unchanged node arrays alone do not establish that changed primitive bindings
  # are active/rigid: verify selected scene ancestry explicitly.
  parents={}
  for i,node in enumerate(d['nodes']):
   for child in node.get('children',[]):need(child not in parents,'Unique node parent');parents[child]=i
  active=set();todo=list(d['scenes'][d.get('scene',0)]['nodes'])
  while todo:
   i=todo.pop();need(i not in active,'Acyclic selected scene');active.add(i);todo.extend(d['nodes'][i].get('children',[]))
  for name in CHANGED:
   mi=next(i for i,m in enumerate(d['meshes']) if m['name']==name)
   nodes=[i for i in active if d['nodes'][i].get('mesh')==mi];need(len(nodes)==1,'Unique active changed primitive '+name)
   i=nodes[0]
   while True:
    n=d['nodes'][i];need('skin' not in n and n.get('translation',[0,0,0])==[0,0,0] and n.get('rotation',[0,0,0,1])==[0,0,0,1] and n.get('scale',[1,1,1])==[1,1,1] and n.get('matrix',[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1])==[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],'Authored root-frame rigid placement '+name)
    if i not in parents:break
    i=parents[i]
  r.update(active_triangles=total,primitive_batches=29,protected_meshes=protected,components=rows,scope='Actual decoded storage/closed topology/active rigid frame only; interpart and horse tests separate; no pressure/rider/motion/photo acceptance')
  r['passed']=True
 except BaseException as e:r['error']=repr(e);raise
 finally:(out/'readback.json').write_text(json.dumps(r,indent=2)+'\n')
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('old',type=Path);a.add_argument('new',type=Path);a.add_argument('parameters',type=Path);a.add_argument('layer_control',type=Path);a.add_argument('out',type=Path);o=a.parse_args();check(o.old,o.new,o.parameters,o.layer_control,o.out)
