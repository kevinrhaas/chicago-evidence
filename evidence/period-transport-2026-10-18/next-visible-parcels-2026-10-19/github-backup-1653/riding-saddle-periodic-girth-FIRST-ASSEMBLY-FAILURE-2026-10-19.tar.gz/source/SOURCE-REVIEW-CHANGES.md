# Delta from first50463/b481 trial — no geometry evaluated yet

- NEW periodic_girth.py: exactA457 ring alias recovery;96unique centerline samples; periodic frame; no caps; declaredEuler0.
- Caller CHANGED11→12 only by adding girth. Authority517795 and recipeec719b remain exact; caller hardchecks both hashes.
- Actual readback requires hardpinned first50463 control and exact entire priorBIN+storage prefix/eleven primitive refs, then separately checks girth dimensions/centerline/fullperiodic indices/Euler0.
- Exact12-name mandatory selfproof cohort,17protected; all270interpart pairs then12vsallhorse. No predicate/contact exemptions changed. Existing exactsource certificate source files remain identical.
- NEW actualoriginalgirth negativecontrol; oldb870 panel56negative source retained. Both are prepared gates, not new results.

Firsttrial selfproof showed eleven new shells independently embedded but protectedgirth selfcrossed at0/760. Independent existingcapture mapping confirmed same oldA457/b870 geometry. This fixedsource revision addresses that closure cause only; no assembly/horse/photographic acceptance inferred.
