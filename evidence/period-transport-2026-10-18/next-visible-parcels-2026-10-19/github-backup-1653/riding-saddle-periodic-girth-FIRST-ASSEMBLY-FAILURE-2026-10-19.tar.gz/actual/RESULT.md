# FIRST actual failure — periodic closure repaired, assembly still fails

One reviewed fixed candidate generated:8ce7793bf776df7a1632202b849a41b06ef34ddeacfcae76c92891432d3ca7bc. Prior firstfailure50463/b481 and source47d18 remain immutable. No app/ticket/browser writes.

PASS actual oldA457faces0/760 strictpropernegative; actual decoded14736triangles/29primitivebatches/17protected, full oldA457rig/rein/material/node/binary storage, and entire50463BIN/accessor/view prefix plus all eleven priorlayerprimitive refs EXACT. Newgirth384v768f/Euler0 with96unique periodicstations,55mmwidth/4mmthickness; actualmaximum centerlineerror3.725290298461914e-9m. Noendcaps, completeperiodicindices. Khronos0errors/2inheritedskinwarnings/25infos. Actual6e9bidle0capture PASS.

ALL29gear selfclassifications completedPASS: every closedtarget scanned, all twelve changedparts embedded (elevenEuler2+girthEuler0). Open/nonmanifold fixedobjects explicitly remain non-solids, no hiddenwindingacceptance. This does NOT qualify the assembled saddle.

FIRST assemblyfailure: panel_l/riding_girth,846AABBcandidatepairs,154rawSAT/touch pairs. First10actualcoordinates/faceIDs saved. This is pair95 of270planned; remainingpairs and ALLhorsequalification UNTESTED. No inference that all earliernew/new combinations passed; traversal order includesheadgear-vsnew before saddlepairordering. No furtherfit or browser after failure, no threshold/exemption/offset search.

The periodicclosure correction preserves the oldfullwrapcenterline. Its upperarc runs through the same back/side region where paired cushions reside. Thus fixing the original seam defect does not fix the physical girthing route. A different underbelly-to-billet construction needs an explicit new source hypothesis, actual existinganchor/endinterface measurements and source review. Merely lifting the wholeband outsidecushions would preserve an unsupported over-backbelt rather than establish a plausible girth. No newroute/candidate is authored in this checkpoint.

Perioddimensions/buckledetails/pressure/load/animalfit/rider/motion/master/photographic acceptance remain OPEN. Current installedapp unaffected. Existing primarytext supports components, not this exact route or force distribution.
