# SPDX-License-Identifier: CC0-1.0
"""Source-only conventional-notch and folded-leather engineering hypothesis.

No model IO or geometry evaluation at import. All cuts and dimensions are
original reconstruction. Existing1833 text does not describe a measured pattern.
"""
import math,struct
from topology import finish
from underbelly_construction import slab_hull,radius
from frame_orientation import strip_guard
from station_ownership import schedule,require_shared,verify_upper_branches,verify_strip_faces

EXTRA=frozenset(('stirrup_leather_l','stirrup_leather_r'))
AMENDED=frozenset(('jockey_l','jockey_r'))
ZCELL=10
WIDTH=.025
THICK=.004

def need(q,m):
 if not q:raise ValueError(m)
def f32(v):return struct.unpack('<f',struct.pack('<f',v))[0]
def quantize(points):return [[f32(x)for x in p]for p in points]
def add(a,b):return [x+y for x,y in zip(a,b)]
def sub(a,b):return [x-y for x,y in zip(a,b)]
def scale(a,t):return [x*t for x in a]
def unit(a):
 n=math.sqrt(math.fsum(x*x for x in a));need(math.isfinite(n)and n>1e-12,'Nonzero finite route vector');return scale(a,1/n)
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def mix(a,b,t):return [x*(1-t)+y*t for x,y in zip(a,b)]
def center(points):return [math.fsum(p[k]for p in points)/len(points)for k in range(3)]
def tri_key(points):return frozenset(tuple(p)for p in points)

def notch(surface,side,p):
 """Remove one outer-edge grid block, retaining all surviving source positions."""
 P,_,oldfaces=surface;P=quantize(P);N=len(p['z_stations_m']);M=p['angular_segments']+1;o=N*M
 need(len(P)==2*o and N==13 and M==25,'Exact original jockey grid')
 removed={(ZCELL,k)for k in(range(18,24)if side=='l'else range(0,6))}
 active={(j,k)for j in range(N-1)for k in range(M-1)}-removed
 faces=[];owners=[];edges={}
 for j,k in sorted(active):
  a=j*M+k;b=a+1;c=b+M;e=a+M
  for face in [(a,b,c),(a,c,e),(a+o,c+o,b+o),(a+o,e+o,c+o)]:faces.append(face);owners.append('retained_cell')
  for u,v in [(a,b),(b,c),(c,e),(e,a)]:
   key=tuple(sorted((u,v)))
   if key in edges:del edges[key]
   else:edges[key]=(u,v)
 oldkeys={tri_key([P[i]for i in face]):j for j,face in enumerate(oldfaces)}
 for u,v in edges.values():
  for face in [(u,v+o,v),(u,u+o,v+o)]:
   faces.append(face);owners.append('retained_boundary'if tri_key([P[i]for i in face])in oldkeys else 'new_notch_cap')
 used=sorted({i for f in faces for i in f});remap={old:new for new,old in enumerate(used)}
 result=finish([P[i]for i in used],[tuple(remap[i]for i in f)for f in faces])
 ledger=[]
 for f,owner in zip(result[2],owners):
  key=tri_key([result[0][i]for i in f]);ledger.append({'owner':owner,'source_face':oldkeys.get(key),'source_vertices':[used[i]for i in f]})
 need(sum(q['owner']=='new_notch_cap'for q in ledger)==26,'Three notch sides:6+6+1 quads')
 return result,{'removed_cells':[list(q)for q in sorted(removed)],'retained_vertex_source_indices':used,'face_ledger':ledger,'source_z_cell':ZCELL,'Euler':2,'not_a_through_hole':True}

def source_patch(P,F,triangles):
 table={tri_key([P[i]for i in f]):j for j,f in enumerate(F)}
 ids=[]
 for tri in triangles:
  key=tri_key(tri);need(key in table,'Contact must reuse a complete actual source triangle');ids.append(table[key])
 need(len(set(ids))==len(ids),'Unique source patch faces');return ids

def foot(bar,side,which):
 P,_,F=bar;P=quantize(P);M=25;o=13*M
 cols=([14,15,16]if which==0 else[18,19,20])if side=='l'else([10,9,8]if which==0 else[6,5,4])
 rings=[]
 for k in cols:
  a=P[ZCELL*M+k];b=P[(ZCELL+1)*M+k]
  def outer(q):
   n=unit([q[0],q[1]-1.16,0]);return add(q,scale(n,THICK))
  rings.append([a,b,outer(b),outer(a)])
 desired=[]
 for j in range(2):
  quad=[rings[j][0],rings[j][1],rings[j+1][1],rings[j+1][0]]
  keys={tri_key([P[i]for i in f])for f in F}
  options=[[(quad[0],quad[1],quad[2]),(quad[0],quad[2],quad[3])],[(quad[0],quad[1],quad[3]),(quad[1],quad[2],quad[3])]]
  matches=[q for q in options if all(tri_key(t)in keys for t in q)];need(len(matches)==1,'Exact sidebar patch diagonal')
  desired.extend(matches[0])
 return rings,{'mesh':'tree_sidebar_'+side,'source_faces':source_patch(P,F,desired),'actual_triangles':desired}

def iron_fold(P,F,side):
 """Reuse five complete underside facets of one unchanged top-bar segment."""
 P=quantize(P);need(len(F)==140,'Exact inherited seven-segment10-sided iron')
 segment=0 if side=='l'else 6;start=segment*20;quads=[]
 for k in range(10):
  t=[P[i]for i in F[start+2*k]];u=[P[i]for i in F[start+2*k+1]]
  need(t[0]==u[0]and t[2]==u[1],'Actual inherited tube quad triangulation')
  quads.append((t[0],t[1],t[2],u[2]))
 centers=[center([quads[k][q]for k in range(10)])for q in(0,3)]
 rings=[]
 for k in range(6):
  a,b=(quads[k][0],quads[k][3])if k<5 else(quads[4][1],quads[4][2])
  oa=add(a,scale(unit(sub(a,centers[0])),THICK));ob=add(b,scale(unit(sub(b,centers[1])),THICK))
  rings.append([a,b,ob,oa])
 actual=[[P[i]for i in F[start+j]]for j in range(10)]
 # The selected material is physically below the bar, not an index label.
 for tri in actual:
  normal=cross(sub(tri[1],tri[0]),sub(tri[2],tri[0]));need(normal[1]<0,'Selected source facets must face the underside')
  for point in tri:
   ca,cb=centers;edge=sub(cb,ca);den=math.fsum(x*x for x in edge);need(den>0,'Distinct iron bar centers')
   t=math.fsum(x*y for x,y in zip(sub(point,ca),edge))/den;datum=add(ca,scale(edge,t));need(math.fsum(x*y for x,y in zip(normal,sub(point,datum)))>0,'Selected iron normals must point away from actual bar centerline')
 # Left root traversal has opposite handedness from the right root. Reverse
 # width ownership of BOTH inner and outer rows, then regenerate connectors.
 # No individual face winding is reversed and the physical contact stays exact.
 if side=='l':rings=[[q[i]for i in(1,0,3,2)]for q in rings]
 return rings,{'mesh':'stirrup_'+side,'source_faces':list(range(start,start+10)),'actual_triangles':actual,'copied_underside_half':True,'unmeasured_fold_width_m':math.dist(rings[0][0],rings[0][1]),'open_iron_no_solid_or_load_claim':True}

def regular_ring(c,w,n,width=WIDTH):
 w=unit(w);n=unit(n);need(abs(math.fsum(x*y for x,y in zip(w,n)))<1e-8,'Orthogonal route section')
 a=add(c,scale(w,-width/2));b=add(c,scale(w,width/2));return [a,b,add(b,scale(n,THICK)),add(a,scale(n,THICK))]

def route(roots,loop_end,base,outside,side,branch,angles,shared_radii):
 """One fixed support-slab hypothesis; actual self/pair/horse guards decide fit."""
 sign=1 if side=='l'else-1;last=roots[-1];c0=center(last[:2]);a0=math.atan2(sign*c0[0],c0[1]-1.16)
 zc=-.06;gap=.012 if branch==0 else.006
 # Include the full40mm root width initially; taper to25mm before the notch.
 rows=[]
 for a in angles:
  aa=sign*a
  if a in shared_radii:common=shared_radii[a]
  else:
   br=radius(base,aa);er=radius(outside,aa);need(br is not None and er is not None,'Full-width support contour coverage')
   u=max(0.,min(1.,(a-.738)/.070));u=u*u*(3-2*u);common=br*(1-u)+er*u
  wanted=common+gap
  root_radius=math.hypot(c0[0],c0[1]-1.16)
  blend=0. if a in shared_radii else max(0.,1-(a-a0)/.055);r=wanted*(1-blend)+root_radius*blend
  c=[sign*r*math.sin(a),1.16+r*math.cos(a),zc]
  width=WIDTH if a in shared_radii else .04+(.025-.04)*min(1.,(a-a0)/.055)
  rows.append(regular_ring(c,[0,0,1 if branch==0 else-1],[sign*math.sin(a),math.cos(a),0],width))
 # A fixed lower transition twists the width to the existing iron bar.
 # No clipping/offset retry is permitted if actual geometry later rejects it.
 start=rows[-1];ca=center(start[:2]);cb=center(loop_end[:2]);wa=unit(sub(start[1],start[0]));wb=unit(sub(loop_end[1],loop_end[0]));na=unit(sub(start[3],start[0]));nb=unit(sub(loop_end[3],loop_end[0]))
 for j in range(1,13):
  t=j/13;c=mix(ca,add(cb,[0,.035,0]),t);w=unit(mix(wa,wb,t));n=mix(na,nb,t);n=unit(sub(n,scale(w,math.fsum(x*y for x,y in zip(w,n)))))
  rows.append(regular_ring(c,w,n,WIDTH*(1-t)+math.dist(loop_end[0],loop_end[1])*t))
 rows.append([[x for x in q]for q in loop_end]);return rows

def loft(rings,contact_triangles):
 """Closed strip with exact source-owned diagonal choices on contact quads."""
 V=[list(q)for ring in rings for q in ring];F=[];contactkeys={tri_key(t)for t in contact_triangles}
 for j in range(len(rings)-1):
  for k in range(4):
   a=4*j+k;b=4*j+(k+1)%4;c=b+4;d=a+4
   options=[[(a,b,c),(a,c,d)],[(a,b,d),(b,c,d)]]
   wanted=[q for q in options if all(tri_key([V[i]for i in f])in contactkeys for f in q)]
   F.extend(wanted[0]if wanted else options[0])
 F.extend([(0,2,1),(0,3,2)]);a=len(V)-4;F.extend([(a,a+1,a+2),(a,a+2,a+3)])
 result=finish(V,F);table={tri_key([result[0][i]for i in f]):j for j,f in enumerate(result[2])}
 need(contactkeys<=set(table),'Every declared complete source contact triangle reused')
 return result,table

def construct(body_triangles,surfaces,p,iron_meshes):
 """Emit only two jockey amendments and two continuous folded leathers."""
 fixed={name:(quantize(v),n,f)for name,(v,n,f)in surfaces.items()};changed={};notches={};interfaces=[];ledgers={}
 for side in('l','r'):
  changed['jockey_'+side],notches[side]=notch(fixed['jockey_'+side],side,p)
 full={**fixed,**changed}
 stock_names=['panel_l','panel_r','tree_sidebar_l','tree_sidebar_r','front_bow','rear_bow','riding_girth','billet_l','billet_r']
 def triangles(names):return [[full[name][0][i]for i in f]for name in names for f in full[name][2]]
 stock=triangles(stock_names);exterior=triangles(stock_names+['seat_jockey','jockey_l','jockey_r','quarter_l','quarter_r'])
 for side in('l','r'):
  roots=[];packets=[]
  for which in(0,1):
   q,packet=foot(full['tree_sidebar_'+side],side,which)
   if which==1:q=[[row[i]for i in(1,0,3,2)]for row in q]
   roots.append(q);packets.append(packet)
  metal=iron_meshes['stirrup_'+side];lower,mpacket=iron_fold(metal[0],metal[1],side)
  sign=1 if side=='l'else-1;root_angles=[]
  for root in roots:
   c=center(root[-1][:2]);root_angles.append(math.atan2(sign*c[0],c[1]-1.16))
  stations=schedule(root_angles);require_shared(stations['branches'][0][len(stations['initial'][0]):],stations['branches'][1][len(stations['initial'][1]):],stations['common'])
  base=slab_hull(body_triangles+stock,-.08,-.04);outside=slab_hull(body_triangles+exterior,-.06-WIDTH/2,-.06+WIDTH/2);shared_radii={}
  for angle in stations['common']:
   br=radius(base,sign*angle);er=radius(outside,sign*angle);need(br is not None and er is not None,'Full-width shared support coverage');u=max(0.,min(1.,(angle-.738)/.070));u=u*u*(3-2*u);shared_radii[angle]=br*(1-u)+er*u
  a=route(roots[0],lower[0],base,outside,side,0,stations['branches'][0],shared_radii)
  b=route(roots[1],lower[-1],base,outside,side,1,stations['branches'][1],shared_radii)
  # The return root is traversed in reverse; its section width reverses too.
  # Ring order is maintained through the actual lower half-circle, then up.
  rings=roots[0]+a[:-1]+lower+list(reversed(b[:-1]))+list(reversed(roots[1]))
  contacts=[t for packet in packets+[mpacket]for t in packet['actual_triangles']]
  serialized=quantize([q for row in rings for q in row]);station_proof=verify_upper_branches(serialized,side,[stations['common'],stations['common']]);frame_proof=strip_guard(serialized,side)
  result,table=loft(rings,contacts);index_proof=verify_strip_faces(result[2],len(result[0]));name='stirrup_leather_'+side;changed[name]=result
  for number,packet in enumerate(packets+[mpacket]):
   interfaces.append({'name':('stirrup_root_'+side+'_'+str(number))if number<2 else'stirrup_iron_'+side,'a_mesh':packet['mesh'],'a_faces':packet['source_faces'],'b_mesh':name,'b_faces':[table[tri_key(t)]for t in packet['actual_triangles']],'strict_proper_allowed':False})
  ledgers[side]={'rings':len(rings),'actual_index_ownership':index_proof,'shared_station_proof':station_proof,'material_frame_proof':frame_proof,'branch_root_patch_columns':[[14,15,16],[18,19,20]]if side=='l'else[[10,9,8],[6,5,4]],'iron_fold':{k:v for k,v in mpacket.items()if k!='actual_triangles'},'width_above_fold_m':WIDTH,'thickness_m':THICK,'Euler':2,'material_holding_capacity_unproved':True}
 return changed,{'notches':notches,'stirrup_leathers':ledgers,'planned_interfaces':interfaces,'new_closed_components':4,'total_expected_components':22,'historical_scope':'Original unmeasured cut/route/fold;1833 identifies straps but does not describe their pattern','production_accepted':False}
