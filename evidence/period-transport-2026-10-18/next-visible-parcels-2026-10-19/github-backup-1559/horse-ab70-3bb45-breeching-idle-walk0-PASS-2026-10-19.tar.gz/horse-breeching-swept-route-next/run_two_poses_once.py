# SPDX-License-Identifier: GPL-3.0-or-later
"""ONE exclusive <=240s idle0+failed walk0, no future8/63 automatic release."""
from pathlib import Path
import sys,json,time,subprocess,os,signal
P=Path(__file__).parent;sys.path.insert(0,str(P/'trial'))
from pair_inputs import verified_receipts
start=time.monotonic();r={'PASS':False,'scope':'Complete discrete idle0+walk0 only; no63fit, continuous/contact-force/photo claim'}
with(P/'two-pose-operator-result.json').open('x')as f:f.write(json.dumps(r)+'\n')
try:
 row=verified_receipts()
 with(P/'trial/pair-inputs.json').open('x')as f:f.write(json.dumps(row,sort_keys=True,indent=2)+'\n')
 r['inputs']=row['inputs'];r['source_inventory_sha256']=row['source_inventory_sha256']
 with(P/'two-pose.stdout').open('xb')as out,(P/'two-pose.stderr').open('xb')as err:
  child=subprocess.Popen([sys.executable,str(P/'trial/run_two_poses.py'),'--stage','repair2'],stdout=out,stderr=err,start_new_session=True)
  try:code=child.wait(timeout=max(.01,240-(time.monotonic()-start)))
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait();code=124
  except BaseException:os.killpg(child.pid,signal.SIGKILL);child.wait();raise
 r['exit']=code
 if code:raise RuntimeError('FIRST actual two-pose failure '+str(code))
 result=json.loads((P/'trial/runs/repair2/RESULT.json').read_text());rows=result.get('completed_poses',[])
 if result.get('PASS')is not True or len(rows)!=2 or [(v['pose']['clip'],v['pose']['phase'])for v in rows]!=[('idle',0),('walk',0)]or any(v.get('PASS')is not True for v in rows):raise ValueError('complete exact two poses required')
 r['PASS']=True
except BaseException as e:r['error']=repr(e)
finally:r['elapsed_s']=time.monotonic()-start;(P/'two-pose-operator-result.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r));sys.exit(0 if r['PASS']else 2)
