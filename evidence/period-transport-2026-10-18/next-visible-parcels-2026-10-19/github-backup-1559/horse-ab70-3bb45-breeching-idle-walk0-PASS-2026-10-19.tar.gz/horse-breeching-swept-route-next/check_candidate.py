# SPDX-License-Identifier: GPL-3.0-or-later
"""Actual source/readback strict35protection, one changedpart, anchor/width contract."""
from pathlib import Path
import json,hashlib,struct,numpy as np
P=Path(__file__).parent;OLD=Path('/workspace/shared/horse-hindgear-support-hull-candidate/candidate-one');NEW=P/'candidate-one';NAME='light_breastcollar_harness_reconstructed_01.glb'
def require(c,msg):
 if not c:raise ValueError(msg)
def load(path):
 raw=path.read_bytes();magic,version,total=struct.unpack_from('<III',raw);require(magic==0x46546c67 and version==2 and total==len(raw),'actualGLBheader');n,kind=struct.unpack_from('<II',raw,12);require(kind==0x4e4f534a,'JSONchunk');bn,bk=struct.unpack_from('<II',raw,20+n);require(bk==0x004e4942 and 28+n+bn==len(raw),'BINchunk');return json.loads(raw[20:20+n]),raw[28+n:],raw
def meshdata(d,b,mesh):
 out=[]
 for pr in mesh['primitives']:
  require('indices'not in pr and pr.get('mode',4)==4 and set(pr['attributes'])=={'POSITION','NORMAL'},'originalexpandedtrianglecontract');attrs={};arrays={}
  for k,ref in pr['attributes'].items():
   a=d['accessors'][ref];v=d['bufferViews'][a['bufferView']];require(a['componentType']==5126 and a['type']=='VEC3'and type(a['count'])is int and a['count']>0 and a['count']%3==0 and'sparse'not in a and'byteStride'not in v,'nonemptyFLOATVEC3');start=v.get('byteOffset',0)+a.get('byteOffset',0);length=a['count']*12;require(start>=0 and start+length<=len(b)and a.get('byteOffset',0)+length<=v['byteLength'],'actualboundextent');raw=b[start:start+length];arr=np.frombuffer(raw,dtype='<f4').reshape(-1,3);require(np.isfinite(arr).all(),'finiteattribute');attrs[k]={'count':a['count'],'type':a['type'],'componentType':a['componentType'],'sha256':hashlib.sha256(raw).hexdigest()};arrays[k]=arr
  require(len(arrays['POSITION'])==len(arrays['NORMAL']),'coherentattributeextent');out.append({'attrs':attrs,'material':pr.get('material'),'mode':pr.get('mode',4)})
 return out

def once():
 r={'PASS':False,'scope':'Actualonechangedbreeching/35protectedparts source readback; NOTfit'}
 try:
  a,ab,oldraw=load(OLD/NAME);b,bb,newraw=load(NEW/NAME);require(hashlib.sha256(oldraw).hexdigest()=='fe76c95b49234da64700a1e20741b4998e8cfbae69571387d49bf5bb23ef04b1','pinnedfe76baseline')
  for d in[a,b]:require(len(d['meshes'])==36 and len({m['name']for m in d['meshes']})==36,'complete36uniqueparts')
  am={m['name']:meshdata(a,ab,m)for m in a['meshes']};bm={m['name']:meshdata(b,bb,m)for m in b['meshes']};require(set(am)==set(bm),'alloriginalpartnames');protected=[n for n in am if n!='breeching'];require(len(protected)==35 and all(am[n]==bm[n]for n in protected),'ALL35P/N/material/modebyteexact');require(am['breeching']!=bm['breeching'],'breechingmustactuallychange');require(a['nodes']==b['nodes']and a['scenes']==b['scenes']and a['materials']==b['materials']and a['asset']==b['asset'],'ALLnodes/frames/anchors/source/license/materialsexact')
  oldmanifest=json.loads((OLD/'manifest.json').read_text());newmanifest=json.loads((NEW/'manifest.json').read_text())
  for k in['source','license','grade','frame','bindings','anchors','head_relative_components','dynamic_components_unbound','missing','shaft_tugs']:require(oldmanifest.get(k)==newmanifest.get(k),'preservedsidecarfield '+k)
  oldparams=json.loads(Path('/workspace/shared/horse-hindgear-support-hull-candidate/source/parameters.json').read_text());newparams=json.loads((P/'source/parameters.json').read_text());x=json.loads(json.dumps(oldparams));y=json.loads(json.dumps(newparams));allowed={'breeching_route_m','lower_junctions','horse_sha256','source','diagnostic_capture_receipt_sha256'}
  for d in[x,y]:
   for k in allowed:d['hindgear_contour_study'].pop(k,None)
  require(x==y,'ALLotherparameterssame');route=newparams['hindgear_contour_study']['breeching_route_m'];junc=newparams['hindgear_contour_study']['lower_junctions']
  for side in['l','r']:
   require(junc[side]['position_m']==oldparams['hindgear_contour_study']['lower_junctions'][side]['position_m']and route[junc[side]['breeching_sample']]==junc[side]['position_m']and newparams['hindgear_contour_study']['hip_support_routes_m'][side][0]==junc[side]['position_m'],'exactprotectedhipjunction')
  count=bm['breeching'][0]['attrs']['POSITION']['count']//3;require(count==8*(len(route)-1)+4,'fullactualbreechingfacecoverage');require(newparams['hindgear_contour_study']['widths_m']['breeching']==.052 and newparams['hindgear_contour_study']['thickness_m']['breeching']==.007,'width/thicknessunchanged');mesh=next(m for m in b['meshes']if m['name']=='breeching');pr=mesh['primitives'][0];ac=b['accessors'][pr['attributes']['POSITION']];view=b['bufferViews'][ac['bufferView']];start=view.get('byteOffset',0)+ac.get('byteOffset',0);actual=np.frombuffer(bb,dtype='<f4',count=ac['count']*3,offset=start).reshape(-1,3,3);rings=[]
  for i in range(len(route)-1):rings.append(np.array([actual[8*i,0],actual[8*i,1],actual[8*i+2,1],actual[8*i+4,1]]))
  j=8*(len(route)-2);rings.append(np.array([actual[j+1,2],actual[j,2],actual[j+2,2],actual[j+4,2]]));rings=np.array(rings);width_errors=[];thickness_errors=[]
  def err(v):return float(np.linalg.norm(np.spacing(np.abs(v).astype('<f4')).astype(float)))/2
  for centre,ring in zip(route,rings):
   require(np.linalg.norm(ring.astype(float).mean(0)-centre)<=sum(err(v)for v in ring)/4+64*2**-52,'actualringcentreF32roundoff')
   for aidx,bidx,target,errors in [(0,1,.052,width_errors),(3,2,.052,width_errors),(1,2,.007,thickness_errors),(0,3,.007,thickness_errors)]:
    error=abs(float(np.linalg.norm(ring[bidx].astype(float)-ring[aidx].astype(float)))-target);require(error<=err(ring[aidx])+err(ring[bidx])+64*2**-52,'actualwidth/thicknessF32roundoff');errors.append(error)
  expected=[]
  for i in range(len(route)-1):
   for k in range(4):a0,b0,c0,e0=rings[i,k],rings[i,(k+1)%4],rings[i+1,(k+1)%4],rings[i+1,k];expected.extend([[a0,b0,c0],[a0,c0,e0]])
  expected.extend([[rings[0,0],rings[0,2],rings[0,1]],[rings[0,0],rings[0,3],rings[0,2]],[rings[-1,0],rings[-1,1],rings[-1,2]],[rings[-1,0],rings[-1,2],rings[-1,3]]]);require(np.asarray(expected,dtype='<f4').tobytes()==actual.tobytes(),'ALLactualstripsides/cap/orientationexactringtopology');r['actual_rectangle_readback']={'rings':len(rings),'maximum_width_error_m':max(width_errors),'maximum_thickness_error_m':max(thickness_errors),'bound':'sumofendpoint F32halfULPnorms+64doubleepsilon; no collision tolerance change'};r.update(PASS=True,candidate_sha256=hashlib.sha256(newraw).hexdigest(),protected_parts=protected,breeching_triangles=count,total_triangles=newmanifest['triangles'],all_anchors_and_bindings_exact=True,width_m=.052,thickness_m=.007)
 except BaseException as e:r['error']=repr(e);raise
 finally:(P/'protected35-readback.json').write_text(json.dumps(r,indent=2)+'\n')
if __name__=='__main__':once()
