# SPDX-License-Identifier: GPL-3.0-or-later
"""All actual emitted breeching triangles vs sampled swept coat corridor.
Numeric projected guard only; no allgear/wholehorse/pose qualification.
"""
from pathlib import Path
import json,hashlib,numpy as np
from check_candidate import load,require,NEW,NAME
P=Path(__file__).parent

def separation(q,poly):
 require(q.shape==(3,2)and poly.ndim==2 and poly.shape[1]==2 and len(poly)>=3 and np.isfinite(q).all()and np.isfinite(poly).all(),'finitecompleteprojectioninputs')
 axes=[]
 for points in[q,poly]:
  for a,b in zip(points,np.roll(points,-1,axis=0)):
   e=b-a;length=float(np.linalg.norm(e))
   if length>1e-14:axes.append(np.array([-e[1],e[0]])/length)
 require(bool(axes),'nonemptysupportaxes')
 return max(max(float((q@n).min()-(poly@n).max()),float((poly@n).min()-(q@n).max()))for n in axes)

def once():
 r={'PASS':False,'scope':'ALLactualbreechingfullwidth/thickness/caps vs complete sampled63frame rootlocal coat corridor convexprojection; nothair/wholehorse/fit/continuousmotion'}
 try:
  read=json.loads((P/'protected35-readback.json').read_text());require(read['PASS']is True,'protected35actualreadbackfirst');d,b,raw=load(NEW/NAME);require(hashlib.sha256(raw).hexdigest()==read['candidate_sha256'],'actualcandidatelink');source=json.loads((P/'SWEPT-HULL-SOURCE-PROPOSAL.json').read_text());poly=np.array(source['hull_rootlocal_XZ']);require(np.isfinite(poly).all()and len(poly)>=3,'finiteactualsourcehull');mesh=next(m for m in d['meshes']if m['name']=='breeching');require(len(mesh['primitives'])==1,'singleactualbreechingprimitive');pr=mesh['primitives'][0];a=d['accessors'][pr['attributes']['POSITION']];v=d['bufferViews'][a['bufferView']];pos=np.frombuffer(b,dtype='<f4',count=a['count']*3,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,3).astype(float);require(np.isfinite(pos).all()and len(pos)>0 and len(pos)%3==0,'ALLnonemptyactualpositions');bounds=np.array([pos.min(0),pos.max(0)]);require(bounds[0,1]>=1.034 and bounds[1,1]<=1.128 and bounds[1,2]<=-.33,'actualentirestripinsideclippedcorridor');areas=np.linalg.norm(np.cross(pos.reshape(-1,3,3)[:,1]-pos.reshape(-1,3,3)[:,0],pos.reshape(-1,3,3)[:,2]-pos.reshape(-1,3,3)[:,0]),axis=1)/2;require(float(areas.min())>1e-12,'actualnondegeneracyexistingguard');bad=[];gaps=[];ranks={0:0,1:0,2:0}
  for i,t in enumerate(pos.reshape(-1,3,3)):
   q=t[:,[0,2]];rank=int(np.linalg.matrix_rank(q[1:]-q[0]));ranks[rank]+=1;gap=separation(q,poly);gaps.append(gap)
   if not np.isfinite(gap)or gap<=1e-7:bad.append({'triangle':i,'projection_rank':rank,'numeric_projection_gap_m':gap})
  require(len(gaps)==read['breeching_triangles'],'everyactualtriangleincludingcaps');r.update(candidate_sha256=read['candidate_sha256'],actual_triangles=len(gaps),projection_ranks=ranks,minimum_projected_gap_m=min(gaps),actual_bounds_rootlocal_m=bounds.tolist(),bad=bad,source_hull_sha256=hashlib.sha256((P/'SWEPT-HULL-SOURCE-PROPOSAL.json').read_bytes()).hexdigest());require(not bad,'actualfullwidth/capintersectionwithsweptprojection');r['PASS']=True
 except BaseException as e:r['error']=repr(e);raise
 finally:(P/'actual-swept-envelope-result.json').write_text(json.dumps(r,indent=2)+'\n')
if __name__=='__main__':once()
