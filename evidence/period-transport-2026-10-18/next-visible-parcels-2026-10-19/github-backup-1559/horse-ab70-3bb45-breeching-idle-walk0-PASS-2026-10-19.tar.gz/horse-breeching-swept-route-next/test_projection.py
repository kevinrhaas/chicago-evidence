# SPDX-License-Identifier: CC0-1.0
import unittest,numpy as np
from check_actual_envelope import separation
class Projection(unittest.TestCase):
 def setUp(self):self.poly=np.array([[-1.,-1.],[1.,-1.],[1.,1.],[-1.,1.]])
 def test_full_triangle_and_degenerate_line_point_separated(self):
  for q in [[[2,0],[3,0],[2,1]],[[2,0],[2,0],[2,1]],[[2,2],[2,2],[2,2]],[[.8,1.5],[1.5,.8],[1.5,1.5]]]:self.assertGreater(separation(np.array(q,float),self.poly),1e-7)
 def test_crossing_contact_inside_refused(self):
  for q in [[[0,0],[2,0],[0,2]],[[1,1],[1,2],[2,1]],[[0,0],[0,0],[0,0]]]:self.assertLessEqual(separation(np.array(q,float),self.poly),1e-7)
 def test_nonfinite_refused(self):
  with self.assertRaises(ValueError):separation(np.array([[2.,0],[3,0],[np.nan,1]]),self.poly)
if __name__=='__main__':unittest.main()
