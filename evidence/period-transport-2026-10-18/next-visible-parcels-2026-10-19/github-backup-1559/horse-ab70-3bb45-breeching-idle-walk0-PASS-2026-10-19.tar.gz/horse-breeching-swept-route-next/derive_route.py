# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only63frame full-triangle swept corridor and source parameter proposal.
No GLB generation, SAT, fit or renderer. Convex numeric envelope, not exact algebra.
"""
from pathlib import Path
import sys,json,hashlib,collections
import numpy as np
M=Path('/workspace/shared/horse-ab70-motion-nonindexed-next');sys.path.insert(0,str(M))
from pose_contract import plans,require,INPUTS
P=Path(__file__).parent;D=Path('/workspace/shared/horse-breeching-motion-diagnosis-next/sweep-captures');SOURCE=Path('/workspace/shared/horse-hindgear-support-hull-candidate/source/parameters.json')
YLO,YHI,ZMAX=1.034,1.128,-.33;OFFSET=.008

def cross(a,b):return float(a[0]*b[1]-a[1]*b[0])
def clip(poly,axis,value,sign):
 out=[]
 for(a,ba),(b,bb)in zip(poly,poly[1:]+poly[:1]):
  u=sign*(a[axis]-value);v=sign*(b[axis]-value)
  if u>=0:out.append((a,ba))
  if u*v<0:t=u/(u-v);out.append((a+(b-a)*t,ba+(bb-ba)*t))
 return out

def convex(points):
 ps=sorted(points);lo=[];hi=[]
 for q in ps:
  while len(lo)>1 and cross(np.array(lo[-1])-lo[-2],np.array(q)-lo[-1])<=0:lo.pop()
  lo.append(q)
 for q in ps[::-1]:
  while len(hi)>1 and cross(np.array(hi[-1])-hi[-2],np.array(q)-hi[-1])<=0:hi.pop()
  hi.append(q)
 require(len(lo)+len(hi)>5,'nondegenerate2Dhull');return np.array(lo[:-1]+hi[:-1])
def offset(poly,r):
 result=[]
 for i,q in enumerate(poly):
  a=q-poly[i-1];b=poly[(i+1)%len(poly)]-q;na=np.array([a[1],-a[0]])/np.linalg.norm(a);nb=np.array([b[1],-b[0]])/np.linalg.norm(b);mat=np.array([na,nb]);require(abs(float(np.linalg.det(mat)))>=1e-14,'nondegenerateoffsetsupport');result.append(np.linalg.solve(mat,np.array([na@q+r,nb@q+r])))
 return np.array(result)
def inside(poly,q,eps=1e-11):return all(cross(b-a,q-a)>eps for a,b in zip(poly,np.roll(poly,-1,axis=0)))
def visible(poly,a,b):
 cuts=[0.,1.];d=b-a
 for u,v in zip(poly,np.roll(poly,-1,axis=0)):
  e=v-u;den=cross(e,d)
  if abs(den)>1e-18:
   t=-cross(e,a-u)/den
   if 0<t<1:cuts.append(float(t))
 cuts=sorted(cuts);return not any(inside(poly,a+d*((u+v)/2))for u,v in zip(cuts,cuts[1:])if v-u>1e-12)
def path(poly,a,b):
 a,b=np.array(a),np.array(b);require(not inside(poly,a)and not inside(poly,b),'protectedanchorINSIDEexpandedhull STOP');points=[a,b]+[q for q in poly if q[1]<=-.329999];dist=[float('inf')]*len(points);dist[0]=0;prev={};todo=set(range(len(points)))
 while todo:
  i=min(todo,key=lambda k:dist[k]);todo.remove(i);require(np.isfinite(dist[i]),'noallowedrearhomotopyroute')
  if i==1:break
  for j in todo:
   if visible(poly,points[i],points[j]):
    z=dist[i]+float(np.linalg.norm(points[j]-points[i]))
    if z<dist[j]:dist[j]=z;prev[j]=i
 result=[1]
 while result[-1]!=0:result.append(prev[result[-1]])
 return [points[i]for i in result[::-1]]
def dense(points,n=3):return[np.asarray(a)*(1-j/n)+np.asarray(b)*j/n for a,b in zip(points,points[1:])for j in range(n)]+[points[-1]]

def derive():
 raw=(D/'DIAGNOSTIC-RESULT.json').read_bytes();require(hashlib.sha256(raw).hexdigest()=='e0e3331fa816576b9d5d3f63e6dc898639a962bd72bffd129943fd939eddf6a6','independentlypinnedactualdiagnosticmanifest');receipt=json.loads(raw);require(receipt['capture_complete']is True and receipt['fit_evaluated']is False and receipt['fit_passed']is False and len(receipt['frames'])==63 and [r['pose']for r in receipt['frames']]==plans('full63'),'completeDIAGNOSTIC_only63grid');points={};perframe=[];idlepoints={};counts=collections.Counter()
 for record in receipt['frames']:
  pose=record['pose'];pd=D/f"frame-{pose['index']:02d}-{pose['clip']}"
  for name,want in record['artifact_hashes'].items():require(not Path(name).is_absolute()and'..'not in Path(name).parts and hashlib.sha256((pd/name).read_bytes()).hexdigest()==want,'frozencaptureartifacthash')
  mp=pd/'idle-fit/capture/horse.json';bp=pd/'idle-fit/capture/horse.f64';meta=json.loads(mp.read_text());data=bp.read_bytes();require(meta['input']==list(INPUTS['horse'])and meta['pose']==pose and hashlib.sha256(data).hexdigest()==meta['buffer_sha256'],'horseposeandbufferpin');alltri=np.frombuffer(data,dtype='<f8').reshape(-1,3,3);root=np.array(meta['root_world']).reshape(4,4,order='F');require(np.isfinite(root).all()and np.array_equal(root[3],[0,0,0,1])and abs(float(np.linalg.det(root[:3,:3]))-1)<1e-12,'actualrigidrootframe');inv=np.linalg.inv(root);groups=[g for g in meta['meshes']if g['name']=='skinned_equine_coat'];require(len(groups)==1,'uniqueactualcoatprimitive');g=groups[0];tri=alltri[g['start']:g['start']+g['count']]@inv[:3,:3].T+inv[:3,3];require(np.isfinite(tri).all(),'finiteactorrootlocal');possible=np.flatnonzero((tri[:,:,1].max(1)>=YLO)&(tri[:,:,1].min(1)<=YHI)&(tri[:,:,2].min(1)<=ZMAX));selected=0
  for i in possible:
   poly=[(tri[i,j].copy(),np.eye(3)[j])for j in range(3)]
   for axis,value,sign in [(1,YLO,1),(1,YHI,-1),(2,ZMAX,-1)]:
    poly=clip(poly,axis,value,sign)
    if not poly:break
   if not poly:continue
   selected+=1
   for v,bary in poly:
    require(np.isfinite(v).all()and np.isfinite(bary).all()and abs(float(bary.sum())-1)<1e-12 and np.linalg.norm(bary@tri[i]-v)<1e-12,'clippedsourcebarycentric');key=tuple(map(float,v[[0,2]]));owner={'frame':pose,'source_mesh':g['sourceMesh'],'source_primitive':g['sourcePrimitive'],'primitive_triangle':int(i),'capture_global_triangle':int(g['start']+i),'barycentric':bary.tolist(),'root_local_position_m':v.tolist(),'root_world':meta['root_world'],'source_capture_metadata_sha256':hashlib.sha256(mp.read_bytes()).hexdigest(),'source_capture_buffer_sha256':meta['buffer_sha256']};points.setdefault(key,owner)
    if pose['clip']=='idle'and pose['phase']==0:idlepoints.setdefault(key,owner)
  require(selected>0,'nonemptyrearcoatcorridor');perframe.append({'pose':pose,'clipped_triangles':selected});counts[pose['clip']]+=selected
 hull=convex(points);expanded=offset(hull,OFFSET);idlehull=convex(idlepoints);params=json.loads(SOURCE.read_text());fixed=params['hindgear_contour_study']['lower_junctions'];back=expanded[np.argmin(expanded[:,1])];landmarks=[np.array([.30,-.34]),np.array(fixed['l']['position_m'])[[0,2]],back,np.array(fixed['r']['position_m'])[[0,2]],np.array([-.30,-.34])];route=[]
 for seg,(a,b)in enumerate(zip(landmarks,landmarks[1:])):
  samples=dense(path(expanded,a,b));lengths=[0.]
  for u,v in zip(samples,samples[1:]):lengths.append(lengths[-1]+float(np.linalg.norm(v-u)))
  require(lengths[-1]>0,'nonzerolandmarkspan')
  for i,q in enumerate(samples):
   t=lengths[i]/lengths[-1];y=1.1*(1-t)+1.0875*t if seg==0 else 1.0875*(1-t)+1.1*t if seg==3 else 1.0875;p=[float(q[0]),float(y),float(q[1])]
   if not route or np.linalg.norm(np.array(p)-route[-1])>1e-12:route.append(p)
 junctions={}
 for side in['l','r']:
  p=fixed[side]['position_m'];i=min(range(len(route)),key=lambda i:np.linalg.norm(np.array(route[i])-p));require(np.linalg.norm(np.array(route[i])-p)<1e-12,'exactprotectedjunction');route[i]=p;junctions[side]={**fixed[side],'breeching_sample':i}
 proposal=json.loads(SOURCE.read_text());proposal['hindgear_contour_study'].update(breeching_route_m=route,lower_junctions=junctions);(P/'proposed-parameters.json').write_text(json.dumps(proposal,indent=2)+'\n');result={'status':'SOURCErouteproposal_only; no GLB/fit generated','diagnostic_receipt_sha256':hashlib.sha256(raw).hexdigest(),'source_parameters_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'slab_rootlocal_m':{'Y':[YLO,YHI],'Zmax':ZMAX},'envelope_target':'FULLtriangleclipping ALLactualcoat triangles inrear corridor, all63sampledposes; nothair/hooves; finalactualfit MUSTincludeALLhorse','offset_m':OFFSET,'offset_rationale':'UNCHANGED prior8mm circumscribedcentreline allowance (7mm strap thickness); notpressure/comfort/historical certification','frames':perframe,'clipped_counts_by_clip':dict(counts),'hull_rootlocal_XZ':hull.tolist(),'hull_vertex_source_owners':[points[tuple(map(float,q))]for q in hull],'expanded_hull_rootlocal_XZ':expanded.tolist(),'idle_hull_rootlocal_XZ':idlehull.tolist(),'route_points':len(route),'fixed_landmarks':{'l':fixed['l']['position_m'],'r':fixed['r']['position_m']},'breeching_width_m':.052,'breeching_thickness_m':.007,'unchanged_otherparts':35,'remaining_gates':['actualemittedfullwidth/thickness envelope certificate','protected35parts/anchors/rigreadback','all36vsALLhorse idle0+failedwalk0','newpair8then63discretefit','appearance/pressure/historicalfit']};(P/'SWEPT-HULL-SOURCE-PROPOSAL.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'hull_vertices':len(hull),'route_points':len(route),'clipped_triangles':dict(counts),'minimum_rear_z_idle':float(idlehull[:,1].min()),'minimum_rear_z_swept':float(hull[:,1].min())}))
if __name__=='__main__':derive()
