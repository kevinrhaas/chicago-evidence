# SPDX-License-Identifier: GPL-3.0-or-later
"""ONE <=30s generation+independent readback; firstfailurestop, no fitting."""
from pathlib import Path
import json,hashlib,subprocess,sys,time,os,signal
P=Path(__file__).parent;started=time.monotonic();r={'PASS':False,'scope':'ONEnewbreechingonly candidate; no fit/period/photo acceptance','stages':[]}
with(P/'operator-result.json').open('x')as f:f.write(json.dumps(r)+'\n')
def save():r['elapsed_s']=time.monotonic()-started;(P/'operator-result.json').write_text(json.dumps(r,indent=2)+'\n')
try:
 for n,w in json.loads((P/'SOURCE-HASHES.json').read_text()).items():
  if hashlib.sha256((P/n).read_bytes()).hexdigest()!=w:raise ValueError('sourcepin '+n)
 for n,w in json.loads((P/'EXTERNAL-HASHES.json').read_text()).items():
  if hashlib.sha256(Path(n).read_bytes()).hexdigest()!=w:raise ValueError('externalpin '+n)
 (P/'candidate-one').mkdir()
 commands=[('generate',[sys.executable,str(P/'source/generate_harness.py'),'--parameters',str(P/'source/parameters.json'),'--output-dir',str(P/'candidate-one')]),('protected35readback',[sys.executable,str(P/'check_candidate.py')]),('actual_swept_envelope',[sys.executable,str(P/'check_actual_envelope.py')])]
 for name,cmd in commands:
  budget=30-(time.monotonic()-started)
  if budget<=0:raise TimeoutError('30s totalcandidatebound')
  before=time.monotonic()
  with(P/(name+'.stdout')).open('xb')as out,(P/(name+'.stderr')).open('xb')as err:
   child=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True)
   try:code=child.wait(timeout=budget)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait();code=124
   except BaseException:os.killpg(child.pid,signal.SIGKILL);child.wait();raise
  r['stages'].append({'name':name,'exit':code,'elapsed_s':time.monotonic()-before});save()
  if code:raise RuntimeError('FIRSTfailure '+name)
 r['PASS']=True
except BaseException as e:r['error']=repr(e)
finally:save()
print(json.dumps(r));sys.exit(0 if r['PASS']else 2)
