# SPDX-License-Identifier: GPL-3.0-or-later
"""Fail-closed new pair receipt, created only after actual generation/readback."""
from pathlib import Path
import json,hashlib
P=Path(__file__).parent;ROOT=P.parent
HORSE=('/workspace/shared/horse-combined-oral-neck-mane-prefix-next/candidate-one/candidate.glb','ab70aff958bc8a2780458d37212be1866c730817f485fbebbf53bd3c0e3931c3')
BASE=('/workspace/shared/horse-v2-cap-registered-next/build1/light_breastcollar_harness_reconstructed_01.glb','078ed2cebc01dba52d28f2ae737f170f0fe28fd20523aed9bb8869f4cd7b35bd')
def require(c,m):
 if not c:raise ValueError(m)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def verified_receipts():
 inventory=ROOT/'SOURCE-HASHES.json';pins=json.loads(inventory.read_text())
 for n,w in pins.items():require(sha(ROOT/n)==w,'frozen new source '+n)
 for n,w in json.loads((ROOT/'EXTERNAL-HASHES.json').read_text()).items():require(sha(n)==w,'frozen external '+n)
 op=json.loads((ROOT/'operator-result.json').read_text());require(op.get('PASS')is True and [(x['name'],x['exit'])for x in op.get('stages',[])]==[('generate',0),('protected35readback',0),('actual_swept_envelope',0)],'complete actual new candidate operator')
 f=ROOT/'candidate-one/light_breastcollar_harness_reconstructed_01.glb';h=sha(f)
 read=json.loads((ROOT/'protected35-readback.json').read_text());env=json.loads((ROOT/'actual-swept-envelope-result.json').read_text());require(read.get('PASS')is True and env.get('PASS')is True and read.get('candidate_sha256')==h and env.get('candidate_sha256')==h and len(read.get('protected_parts',[]))==35 and read.get('breeching_triangles')==844 and env.get('actual_triangles')==844,'same actual candidate protected35+complete envelope')
 for f0,h0 in [HORSE,BASE]:require(sha(f0)==h0,'original pair pin')
 return {'scope':'NEW reconstructed breeching candidate; prior35 parts exact; not fit acceptance','inputs':{'horse':list(HORSE),'baseline':list(BASE),'candidate':[str(f),h]},'source_inventory_sha256':sha(inventory),'evidence_sha256':{n:sha(ROOT/n)for n in ['operator-result.json','protected35-readback.json','actual-swept-envelope-result.json']}}
def checked_inputs():
 row=json.loads((P/'pair-inputs.json').read_text());require(row==verified_receipts(),'new pair independently revalidated');return {k:tuple(v)for k,v in row['inputs'].items()}
