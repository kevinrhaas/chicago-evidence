# SPDX-License-Identifier: GPL-3.0-or-later
import ast,unittest,tempfile,json
from pathlib import Path
P=Path(__file__).parent
class Wiring(unittest.TestCase):
 def test_owned_leaf_refuses_without_touching(self):
  m=ast.parse((P/'trial/run_two_poses.py').read_text());f=next(x for x in m.body if isinstance(x,ast.FunctionDef)and x.name=='claim_stage');ns={'Path':Path,'require':lambda c,m:None if c else (_ for _ in ()).throw(ValueError(m))};exec(compile(ast.Module(body=[f],type_ignores=[]),'actualclaim','exec'),ns)
  with tempfile.TemporaryDirectory()as d:
   out=ns['claim_stage'](d,'repair2');r=out/'RESULT.json';r.write_bytes(b'preserved failure')
   with self.assertRaises(FileExistsError):ns['claim_stage'](d,'repair2')
   self.assertEqual(r.read_bytes(),b'preserved failure')
 def test_pair_drift_rejected(self):
  m=ast.parse((P/'trial/pair_inputs.py').read_text());f=next(x for x in m.body if isinstance(x,ast.FunctionDef)and x.name=='checked_inputs')
  with tempfile.TemporaryDirectory()as d:
   r={'inputs':{'horse':['a','h'],'baseline':['b','b'],'candidate':['c','c']}};Path(d,'pair-inputs.json').write_text(json.dumps(r));ns={'P':Path(d),'json':json,'verified_receipts':lambda:r,'require':lambda c,m:None if c else (_ for _ in ()).throw(ValueError(m))};exec(compile(ast.Module(body=[f],type_ignores=[]),'actualchecked','exec'),ns);self.assertEqual(ns['checked_inputs']()['candidate'],('c','c'));r2=json.loads(json.dumps(r));r2['inputs']['candidate'][1]='wrong';Path(d,'pair-inputs.json').write_text(json.dumps(r2))
   with self.assertRaises(ValueError):ns['checked_inputs']()
 def test_no_legacy_candidate_in_captured_pair(self):
  s=(P/'trial/capture_pose.mjs').read_text();self.assertIn("new URL('./pair-inputs.json',import.meta.url)",s);self.assertNotIn('fe76c95b',s);self.assertIn('pose.input_sha256[name]!==want',s)
 def test_stage_fixed_two(self):
  s=(P/'trial/pose_contract.py').read_text();self.assertIn("[('idle',0),('walk',0)]if stage=='repair2'",s);s=(P/'trial/run_two_poses.py').read_text();self.assertIn("require(stage=='repair2'",s);self.assertIn('explicit_original_badgeometry_controls',s);self.assertIn("len(parts)==36",s);self.assertIn("v['raw_SAT_pairs']==0",s)
if __name__=='__main__':unittest.main()
