from pathlib import Path
import struct,json,math,hashlib
p=Path('/workspace/shared/riding-gear-1835-next/horse-input/equine_light_harness_skinned_prototype_01.glb');b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);bb=b[28+n:]
def read(i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];c={'SCALAR':1,'VEC3':3,'VEC4':4}[a['type']];f={5126:'f',5125:'I',5123:'H'}[a['componentType']];rows=struct.unpack_from('<'+f*(a['count']*c),bb,v.get('byteOffset',0)+a.get('byteOffset',0));return list(zip(*[iter(rows)]*c))
a=next(m for m in d['meshes']if m['name']=='skinned_equine_coat')['primitives'][0];vs=read(a['attributes']['POSITION']);ids=[x[0]for x in read(a['indices'])]
def top(x,z):
 h=[]
 for i in range(0,len(ids),3):
  q=[vs[ids[i+j]]for j in range(3)];(ax,ay,az),(bx,by,bz),(cx,cy,cz)=q;den=(bz-cz)*(ax-cx)+(cx-bx)*(az-cz)
  if abs(den)<1e-14:continue
  u=((bz-cz)*(x-cx)+(cx-bx)*(z-cz))/den;v=((cz-az)*(x-cx)+(ax-cx)*(z-cz))/den;w=1-u-v
  if min(u,v,w)>=-1e-10:h.append(u*ay+v*by+w*cy)
 if not h:raise ValueError('No intersection')
 return max(h)
if __name__=='__main__':
 rows=[{'z':z,'spine_top':top(0,z),'left_bar_under_top':top(.13,z),'right_bar_under_top':top(-.13,z)}for z in [-.48,-.35,-.2,-.05,.015]]
 print(json.dumps({'horse_sha256':hashlib.sha256(b).hexdigest(),'rows':rows},indent=2))
