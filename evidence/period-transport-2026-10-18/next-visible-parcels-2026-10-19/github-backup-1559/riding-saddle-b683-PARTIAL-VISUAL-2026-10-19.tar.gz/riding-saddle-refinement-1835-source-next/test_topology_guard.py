# SPDX-License-Identifier: CC0-1.0
"""Synthetic closed-edge guards only; no actual saddle or horse evaluation."""
from saddle_surfaces import finish
v=[[0,0,0],[1,0,0],[0,1,0],[0,0,1]]
f=[(0,2,1),(0,1,3),(0,3,2),(1,2,3)]
finish(v,f)
for name,points,faces in [('one reversed face',v,[f[0][::-1]]+f[1:]),('missing face',v,f[:-1]),('two disconnected shells',v+[[x+3,y,z]for x,y,z in v],f+[tuple(i+4 for i in q)for q in f]),('repeated index',v,[(0,0,1)]+f[1:])]:
 try:finish(points,faces)
 except ValueError:pass
 else:raise RuntimeError('Guard failed '+name)
print('Synthetic topology controls PASS: valid shell; reversed/missing/disconnected/repeated refused')
