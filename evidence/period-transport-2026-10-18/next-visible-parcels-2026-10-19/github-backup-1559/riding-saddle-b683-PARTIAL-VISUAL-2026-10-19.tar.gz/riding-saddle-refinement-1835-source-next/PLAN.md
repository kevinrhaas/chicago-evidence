# Original1835 civilian saddle surface refinement — source-only checkpoint

No candidate/export, fit sweep or browser has run. Existing V1/V2/V3 and A457 rein-fix remain immutable. No app/ticket/registry changes. Local inspection actually opened the old CPU threequarter image and decoded actual source parts; the CPU painter is not a PBR or historical acceptance render.

## Evidence boundary

The retained riding-tack research dossier records prior actual OCR readings of Lebeaud1833 Philadelphia pp25–30: beech bows/sidebars, paired linen/hair panels, seat/pommel/quarters, girths/stirrup straps. Adams1805 supplies an early simple-snaffle comparator. Source researcher searched retained shared/tmp corpus: no actual primary Lebeaud/Sears page/OCR/image bytes were found, and no cleared saddle illustration can be asserted. Thus this is an ORIGINAL bounded component reconstruction; there is no copied source cut, authenticated primary visual, registered newsource or photographic acceptance. Do not cite an unseen Sears1902 Somerset image, import its dimensions or backdate a later military/horned type. Source URLs in retained dossier remain citations, not pixel derivation or an explicit host license grant.

## Actual deficits and bounded first parcel

Actual V3 uses a .32m constant-width rectangular seat with near-vertical edge, large rectangular jockey strips, exposed beech bow ends and a simplified quarter hem. CPU view visibly reads as a tall slab/scaffold despite prior body SAT pass. Wire-loop stirrups, absent leathers/buckles/throatlatch detail, broad flat colors and anatomical horse deficits also remain; these are not all being fixed in one parcel.

Replace exactly FIVE existing surfaces: seat_jockey, jockey_l/r, quarter_l/r. A457 is the input (SHA a457874a81b624f5e9642d3296b1350eb49b17d21d38099fbe66080711c17021), preserving root/head rein skin and all24 other mesh definitions/old BIN bytes/materials/nodes/skins/animations/sockets. The current2Khronos skin warnings remain inherited limitations, not new proof or ignored warnings. No skinning/shape combination with ab70 is attempted.

- New waisted, rounded-plan leather seat: polar closed shell, raised rear/front margins, six-millimetre rolled perimeter tapering from18mm center body, smooth area-weighted normals. This is original geometry, not an attested early-English pattern.
- Curved side jockey covers run from actual new seat side boundary toward the retained torso-backed outer edge; no separate unsupported rectangular slab. Bow/sidebar/panel geometry stays exact this first trial; whether the new coverage actually conceals scaffold gaps coherently MUST be inspected, not presumed from a mathematical silhouette.
- Lower quarters use retained actual torso ray intersections but rounded lifted hem corners, narrower lower length and consistent6mm leather thickness; sampled interpolation must still pass actual whole-triangle horse fit. No pressure/contact-safety claim follows from surface offset or zero crossings.
- No new trim, studs, tooling, named manufacturer, horn, rider or historical ownership. Current stirrups remain visibly coarse and are explicitly next work, not falsely relabelled as improved.

All cut/dimensions/colors/finish are unmeasured original reconstruction. Exact parameters in parameters.json. New5faces predicted7232 vs source4104 → source7892 total becomes11020 (+3128),29draws/materialslots unchanged; actual counts/geometry remain unverified until build/readback. No texture memory added. Original actual retained6e9b horse unchanged; source field samples show centerback1.510–1.518m and underbar points1.463–1.477m. The support/panel pressure, saddle tree solid contact and human seat fit remain open even if silhouettes improve.

## Review then one build/check design

Independent SOURCE review first (no helper evaluation during review). CLI requires exact A457 gear,6e9b horse and SHA-pinned source ownership manifest, explicitparameters and FRESH outputdir; failure receipt written only after exclusive ownership. Pure stdlib original code, no external asset/network/Blender. Build appends new accessors/indices only, retains old BIN prefix and all unrelated definitions. Output proof records exact input/newfile/parameter/manifest hashes and bounds. No source guard uses assert or optimized-mode-dependent behavior.

After source review, one separately bounded build: `python -B build_candidate.py --gear-input <A457> --horse-input <retained6e9b.glb> --horse-manifest <retainedmanifest> --parameters parameters.json --output-dir <FRESH>` (30s bound, firstfailure STOP/preserve). Then independent actual readback checks finite/unitnormals/nondegenerate faces/manifold+winding, exact24protectedparts/rig/rein attributes and oldBINprefix, and actual Khronos with inherited warnings accounted. Actual retained6e9b idle fit must compare new5surfaces vsALLhorse using unchanged proper/SAT predicates, not only ray centers; actual zero crossings does not certify inside-volume, source match or support pressure. Existing rein endpoint84row proof is NOT automatically reaccepted on a different horse.

Only after actual geometry/idlefit review, coordinate one controlled real-browser close/whole baseline/candidate desktop/mobile A/B. Preserve every failure. Do not accept a smoother slab merely because counts or validators pass. Separate new ab70 anatomy/gear/rider protocol,21walk/trot/continuous/physics, primaryvisual+registry, photograph/leather finish, master/LOD and named resident fit all remain open. Root owns renewed T2802 claim and application integration decisions.
