# Source-only winding failure preserved

Before any candidate generation, independent source review found the initial shell/seat rim ordering `(a,b,b+o),(a,b+o,a+o)` reused the top surface's directed boundary edge rather than opposing it. An overall signed-volume flip cannot correct mixed per-face orientation. The author independently identified the same issue before receiving the reviewer message. No helper geometry was evaluated, no actual model was built and no fit/visual acceptance occurred under this source revision.

Corrected BOTH rim loops to `(a,b+o,b),(a,a+o,b+o)`. Added explicit combinatorial refusal before volume/normals: valid non-repeated indices, exactly two opposite directed edge uses, connected use of all vertices and expected Euler2. This is a source-only repair, not a collision or normal tolerance waiver. Existing old V3 and A457 files remain untouched; inherited source topology is not silently called corrected globally.
