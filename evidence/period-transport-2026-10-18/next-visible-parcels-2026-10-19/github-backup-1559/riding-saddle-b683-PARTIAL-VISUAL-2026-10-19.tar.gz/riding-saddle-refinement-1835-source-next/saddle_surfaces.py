# SPDX-License-Identifier: CC0-1.0
"""Original bounded leather forms, not a traced saddle or measured pattern."""
import math
from collections import defaultdict

def seat_height(z,p):
 t=(z-p['seat_z_range_m'][0])/(p['seat_z_range_m'][1]-p['seat_z_range_m'][0]);return p['seat_center_height_m']+p['rear_rise_m']*(1-t)**4+p['front_rise_m']*t**4

def halfwidth(z,p):
 t=(z-p['seat_z_range_m'][0])/(p['seat_z_range_m'][1]-p['seat_z_range_m'][0]);return p['waist_halfwidth_m']+(p['rear_halfwidth_m']-p['waist_halfwidth_m'])*(1-t)**4+(p['front_halfwidth_m']-p['waist_halfwidth_m'])*t**4

def cross3(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def finish(v,f):
 edges=defaultdict(list);adj=defaultdict(set)
 for a,b,c in f:
  if len({a,b,c})!=3 or min(a,b,c)<0 or max(a,b,c)>=len(v):raise ValueError('Invalid topology indices')
  for u,w in [(a,b),(b,c),(c,a)]:edges[tuple(sorted((u,w)))].append((u,w));adj[u].add(w);adj[w].add(u)
 if any(len(q)!=2 or q[0]!=q[1][::-1] for q in edges.values()):raise ValueError('Closed opposite-edge ownership required')
 seen=set();todo=[0]
 while todo:
  i=todo.pop()
  if i in seen:continue
  seen.add(i);todo.extend(adj[i]-seen)
 if len(seen)!=len(v):raise ValueError('Connected closed surface required')
 if len(v)-len(edges)+len(f)!=2:raise ValueError('Expected single closed shell Euler2')
 volume=math.fsum(math.fsum(v[a][i]*cross3(v[b],v[c])[i]for i in range(3))for a,b,c in f)
 if volume<0:f=[(a,c,b)for a,b,c in f]
 n=[[0.,0.,0.]for _ in v]
 for a,b,c in f:
  q=cross3([v[b][i]-v[a][i]for i in range(3)],[v[c][i]-v[a][i]for i in range(3)]);length=math.sqrt(math.fsum(x*x for x in q))
  if length<1e-11:raise ValueError('Degenerate generated face')
  for j in (a,b,c):
   for i in range(3):n[j][i]+=q[i]
 for j,q in enumerate(n):
  length=math.sqrt(math.fsum(x*x for x in q))
  if length<1e-12:raise ValueError('Unresolved vertex normal')
  n[j]=[x/length for x in q]
 if not all(math.isfinite(x)for row in v+n for x in row):raise ValueError('Nonfinite surface')
 return v,n,f

def shell(top,bottom,N,M):
 v=top+bottom;o=N*M;f=[]
 for j in range(N-1):
  for k in range(M-1):
   a=j*M+k;b=a+1;c=b+M;e=a+M;f.extend([(a,b,c),(a,c,e),(a+o,c+o,b+o),(a+o,e+o,c+o)])
 boundary=list(range(M))+[j*M+M-1 for j in range(1,N)]+list(range((N-1)*M+M-2,(N-1)*M-1,-1))+[j*M for j in range(N-2,0,-1)]
 for i,a in enumerate(boundary):b=boundary[(i+1)%len(boundary)];f.extend([(a,b+o,b),(a,a+o,b+o)])
 return finish(v,f)

def seat(p):
 N=p['seat_angular_segments'];R=p['seat_radial_rings'];z0,z1=p['seat_z_range_m'];zc=(z0+z1)/2;zh=(z1-z0)/2;v=[];f=[]
 for lower in (False,True):
  v.append([0,seat_height(zc,p)-(p['seat_thickness_m']if lower else 0),zc])
  for r in range(1,R+1):
   t=r/R
   for k in range(N):
    a=2*math.pi*k/N;z=zc+t*zh*math.cos(a);s=math.sin(a);x=t*halfwidth(z,p)*math.copysign(abs(s)**p['plan_exponent'],s);y=seat_height(z,p)+p['cross_rise_m']*(abs(x)/p['waist_halfwidth_m'])**2
    y-=p['edge_roll_m']*t**10
    if lower:y-=p['edge_thickness_m']+(p['seat_thickness_m']-p['edge_thickness_m'])*(1-t*t)
    v.append([x,y,z])
 o=1+N*R
 for k in range(N):f.append((0,1+k,1+(k+1)%N));f.append((o,o+1+(k+1)%N,o+1+k))
 for r in range(R-1):
  for k in range(N):
   a=1+r*N+k;b=1+r*N+(k+1)%N;c=b+N;d=a+N;f.extend([(a,d,c),(a,c,b),(a+o,c+o,d+o),(a+o,b+o,c+o)])
 for k in range(N):a=1+(R-1)*N+k;b=1+(R-1)*N+(k+1)%N;f.extend([(a,b+o,b),(a,a+o,b+o)])
 return finish(v,f)

def jockey(sign,p,top):
 a=[];b=[];N=p['jockey_length_segments']+1;M=p['jockey_width_segments']+1;z0,z1=p['seat_z_range_m'];zc=(z0+z1)/2;zh=(z1-z0)/2
 for j in range(N):
  t=j/(N-1);z=z0+.030+(z1-z0-.065)*t;u=(z-zc)/zh;inner=halfwidth(z,p)*(max(0.,1-u*u)**(p['plan_exponent']/2));outer=p['jockey_outer_x_m']-.020*abs(2*t-1)**4
  if inner>=outer-.008:raise ValueError('Jockey seam has no width')
  for k in range(M):
   q=k/(M-1);x=sign*(inner+(outer-inner)*q);start=seat_height(z,p)+p['cross_rise_m']*(inner/p['waist_halfwidth_m'])**2-p['edge_roll_m']-.004;y=max((1-q)*start+q*(top(x,z)+p['jockey_outer_offset_m']),top(x,z)+p['jockey_outer_offset_m'])
   a.append([x,y,z]);b.append([x,y-p['leather_thickness_m'],z])
 return shell(a,b,N,M)

def quarter(sign,p,ray):
 a=[];b=[];N=p['quarter_vertical_segments']+1;M=p['quarter_length_segments']+1
 for j in range(N):
  t=j/(N-1);half=p['quarter_halfwidth_top_m']*(1-t)+p['quarter_halfwidth_bottom_m']*t
  for k in range(M):
   u=2*k/(M-1)-1;z=p['quarter_center_z_m']+half*u;angle=p['quarter_top_angle_rad']*(1-t)+p['quarter_bottom_angle_rad']*t+p['quarter_corner_lift_rad']*t**3*u*u;direction=[sign*math.cos(angle),math.sin(angle),0];r=ray([0,p['quarter_ray_height_m'],z],direction)
   def point(extra):return [(r+extra)*direction[0],p['quarter_ray_height_m']+(r+extra)*direction[1],z]
   a.append(point(p['quarter_offset_m']));b.append(point(p['quarter_offset_m']-p['leather_thickness_m']))
 return shell(a,b,N,M)
