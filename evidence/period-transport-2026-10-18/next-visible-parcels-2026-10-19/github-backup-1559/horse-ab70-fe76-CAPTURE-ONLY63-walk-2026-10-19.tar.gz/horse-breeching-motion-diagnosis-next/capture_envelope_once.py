# SPDX-License-Identifier: GPL-3.0-or-later
"""ONE <=120s capture-only63frame diagnostic. NEVER runs SAT or fit checks."""
from pathlib import Path
import sys,json,hashlib,subprocess,os,signal,time
M=Path('/workspace/shared/horse-ab70-motion-nonindexed-next');sys.path.insert(0,str(M))
from pose_contract import plans,validate,INPUTS,require
P=Path(__file__).parent;OUT=P/'sweep-captures';OUT.mkdir() # exclusive refusal before handler
started=time.monotonic();r={'capture_complete':False,'fit_evaluated':False,'fit_passed':False,'purpose':'DIAGNOSTIC_ONLY_ACTUAL_SWEPT_GEOMETRY; not qualification','total_bound_s':120,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'motion_source_inventory_sha256':hashlib.sha256((M/'SOURCE-HASHES.json').read_bytes()).hexdigest(),'input_sha256':{k:v[1]for k,v in INPUTS.items()},'planned_frames':63,'frames':[]}
def save():r['elapsed_s']=time.monotonic()-started;(OUT/'DIAGNOSTIC-RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
try:
 save()
 for name,want in json.loads((M/'SOURCE-HASHES.json').read_text()).items():require(hashlib.sha256((M/name).read_bytes()).hexdigest()==want,'frozenmotion_sourcepin')
 for name,want in json.loads((M/'EXTERNAL-HASHES.json').read_text()).items():require(hashlib.sha256(Path(name).read_bytes()).hexdigest()==want,'frozenexternalpin')
 for pose in plans('full63'):
  before=time.monotonic();budget=min(10,120-(before-started));require(budget>0,'120s capture-onlytotalbound');pd=OUT/f"frame-{pose['index']:02d}-{pose['clip']}";pd.mkdir();(pd/'pose.json').write_text(json.dumps(pose,sort_keys=True,indent=2)+'\n');(pd/'DIAGNOSTIC-ONLY.json').write_text(json.dumps({'purpose':r['purpose'],'fit_evaluated':False,'fit_passed':False},indent=2)+'\n');env={**os.environ,'CHICAGO_POSE_DIR':str(pd)}
  with(pd/'capture.stdout').open('xb')as stdout,(pd/'capture.stderr').open('xb')as stderr:
   child=subprocess.Popen(['node','--loader',str(M/'three-loader.mjs'),str(M/'capture_pose.mjs')],env=env,stdout=stdout,stderr=stderr,start_new_session=True)
   try:code=child.wait(timeout=budget)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait();code=124
   except BaseException:os.killpg(child.pid,signal.SIGKILL);child.wait();raise
  require(code==0,'firstcapturefailure index'+str(pose['index']));os.environ['CHICAGO_POSE_DIR']=str(pd)
  for name in INPUTS:
   meta=json.loads((pd/'idle-fit/capture'/f'{name}.json').read_text());buf=(pd/'idle-fit/capture'/f'{name}.f64').read_bytes();validate(name,meta,buf)
  hashes={str(f.relative_to(pd)):hashlib.sha256(f.read_bytes()).hexdigest()for f in pd.rglob('*')if f.is_file()};r['frames'].append({'pose':pose,'artifact_hashes':hashes,'capture_only':True});save();require(time.monotonic()-started<=120,'120s totalbound includingvalidation')
 require(len(r['frames'])==63,'completecapturegrid');r['capture_complete']=True;save();print(json.dumps({k:v for k,v in r.items()if k!='frames'}))
except BaseException as e:r['error']=repr(e);save();raise
