# SPDX-License-Identifier: GPL-3.0-or-later
"""Original fixed neutral-lip variant. No evaluation/IO at import."""
from pathlib import Path
import sys,copy,json,hashlib,collections
import numpy as np
BASE=Path('/workspace/shared/horse-cheek-throat-quality-next');sys.path.insert(0,str(BASE))
from checked_quality import checked as parent_checked
from input_contract import context as parent_context
from ownership import Model,ATTRS
from glb_data import append,encode
from sparse_rules import require
from lip_surface import surface
PARENT_SHA='57d63e2d7234380adeb727f5efeeed74d50629b2a8367ccea48961d6ecc5bec2'

def context():
 m,l,h,o,s,raw=parent_checked();require(hashlib.sha256(raw).hexdigest()==PARENT_SHA,'Exact57dparent');source=parent_context()['source'];record=next(r for r in source['records']if r['name']=='mouth_oral');retired=set();cavity=set();mouth=set()
 for g,row in o.items():
  if row.get('kind')!='oral_channel':continue
  kind=row['source_owner']['kind']
  if kind=='oral_rim_connector':retired.add(g);mouth.add(g)
  elif kind in['oral_roof','oral_floor','oral_back']:cavity.add(g);mouth.add(g)
 require(len(retired)==132 and len(cavity)==202,'Exact132connector/202cavityauthority');require(all((m.descriptor(g)['mesh'],m.descriptor(g)['primitive'])==(1,0)for g in mouth),'Actualmouthdarkprimitiveownership');outer=[];inner=[]
 def actual(label):
  ids=[i for(mi,i),t in l.items()if mi==1 and t==label];require(len(ids)==1,'Unambiguoussourcesemanticalias:'+label);return ids[0]
 for v in record['outer']:outer.append(actual('h:'+str(v)))
 for v in record['inner']:inner.append(actual('oral:'+str(v)))
 require(len(set(outer))==len(set(inner))==66 and not(set(outer)&set(inner)),'Exactdistinct66loops')
 # The actual exterior normal direction comes only from retained exterior head,
 # never the dark cavity/wall bucket.
 sums=collections.defaultdict(lambda:np.zeros(3));outside=set(h)-mouth
 for g in outside:
  d=m.descriptor(g);a=m.views[d['mesh'],d['primitive']]['attributes'];p=a['POSITION'][d['primitive_vertices']].astype(float);n=np.cross(p[1]-p[0],p[2]-p[0])
  for i in d['primitive_vertices']:sums[l.get((d['mesh'],i),'body:'+str(d['mesh'])+':'+str(i))]+=n
 normals=[]
 for i in outer:
  n=sums[l[1,i]];require(np.linalg.norm(n)>1e-12,'Actualretainedexteriornormalexists');normals.append(n/np.linalg.norm(n))
 protected=set();protected_faces=set()
 for g,row in o.items():
  feature=row.get('kind')in['baseline_ear','skull_complement','radial_bridge']or(row.get('kind')=='baseline_head'and ('eye' in row.get('tag','')or'nostril'in row.get('tag','')))
  if feature:
   protected_faces.add(g);d=m.descriptor(g);protected.update(l.get((d['mesh'],i),'body:'+str(d['mesh'])+':'+str(i))for i in d['primitive_vertices'])
 # All cavity normals/attributes remain exact, including inner-interface aliases.
 for g in cavity:
  d=m.descriptor(g);protected.update(l[d['mesh'],i]for i in d['primitive_vertices'])
 return dict(model=m,labels=l,head=h,owners=o,scopes=s,raw=raw,record=record,retired=retired,cavity=cavity,mouth=mouth,outer=outer,inner=inner,normals=normals,protected_labels=protected,protected_faces=protected_faces)

def weights(parts):
 D=collections.defaultdict(float)
 for alpha,J,W in parts:
  for j,w in zip(J,W):
   if w>0:D[int(j)]+=float(alpha*w)
 vals=sorted(((j,w)for j,w in D.items()if w>1e-12),key=lambda x:(-x[1],x[0]));require(0<len(vals)<=4,'Boundedactualsemanticinfluences');total=sum(w for _,w in vals);return[j for j,_ in vals]+[0]*(4-len(vals)),[w/total for _,w in vals]+[0.]*(4-len(vals))

def evaluate(c):
 m=c['model'];old=m.views[1,0]['attributes'];origin=np.array([0.,1.88,.8]);O=old['POSITION'][c['outer']].astype(float)-origin;I=old['POSITION'][c['inner']].astype(float)-origin;s=surface(O,I,c['normals']);arrays={k:old[k].copy().tolist()for k in ATTRS};mapping=c['outer']+c['inner'];labels={};source_new=[]
 for local,p in enumerate(s['positions'][132:],132):
  layer=0 if local<264 else 1;k=local-132 if layer==0 else local-264;phase=s['phases'][k];i=phase['old_edge'];j=(i+1)%66;f=phase['fraction'];oi,oj=c['outer'][i],c['outer'][j];ii,ij=c['inner'][i],c['inner'][j];wparts=[(1-f,old['JOINTS_0'][ii],old['WEIGHTS_0'][ii]),(f,old['JOINTS_0'][ij],old['WEIGHTS_0'][ij])]
  if layer==0:wparts=[(.35*(1-f),old['JOINTS_0'][oi],old['WEIGHTS_0'][oi]),(.35*f,old['JOINTS_0'][oj],old['WEIGHTS_0'][oj])]+[(a*.65,J,W)for a,J,W in wparts]
  J,W=weights(wparts);actual=len(arrays['POSITION']);mapping.append(actual);arrays['POSITION'].append((np.asarray(p)+origin).tolist());arrays['NORMAL'].append([1.,0.,0.]);arrays['JOINTS_0'].append(J);arrays['WEIGHTS_0'].append(W);labels[str(actual)]='neutral_lip:'+('mid'if layer==0 else'aperture')+':'+str(k);source_new.append({'local':local,'actual_vertex':actual,'phase':phase,'layer':layer})
 arrays={k:np.asarray(v,dtype=old[k].dtype)for k,v in arrays.items()};skin=[];lining=[];newowners=[]
 for f,o in zip(s['faces'],s['owners']):
  row=[mapping[i]for i in f];(skin if o['kind']=='lip_skin'else lining).append(row);newowners.append({**o,'actual_vertices':row})
 keep=[i for i in range(len(m.views[1,0]['indices']))if m.start[1,0]+i not in c['retired']];idx={(1,0):np.vstack((m.views[1,0]['indices'][keep],np.asarray(lining,dtype='<u4'))),(1,1):np.vstack((m.views[1,1]['indices'],np.asarray(skin,dtype='<u4')))}
 newlabels={i:labels.get(str(i),c['labels'].get((1,i),'body:1:'+str(i)))for i in range(len(arrays['POSITION']))};field=collections.defaultdict(lambda:np.zeros(3));graph=collections.defaultdict(set)
 def add(P,F,lookup):
  tri=P[F].astype(float);A=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);require(np.isfinite(A).all()and np.all(np.linalg.norm(A,axis=1)>2e-12),'Activefinite/nondegeneratesurface')
  for face,n in zip(F,A):
   tags=[lookup[int(i)]for i in face]
   for t in tags:field[t]+=n
   for a,b in zip(tags,tags[1:]+tags[:1]):graph[a].add(b);graph[b].add(a)
 for key,v in m.views.items():
  rows=[i for i in range(len(v['indices']))if m.start[key]+i in c['head']-c['mouth']]
  if rows:add(v['attributes']['POSITION'],v['indices'][rows],{i:c['labels'].get((key[0],i),'body:'+str(key[0])+':'+str(i))for i in set(map(int,v['indices'].ravel()))})
 add(arrays['POSITION'],np.asarray(skin),newlabels);boundary={c['labels'][1,i]for i in c['outer']};halo=set(boundary)
 for tag in boundary:halo.update(graph[tag])
 halo-=c['protected_labels'];skinN=arrays['NORMAL'].copy();darkN=arrays['NORMAL'].copy();bodyN=m.views[0,0]['attributes']['NORMAL'].copy()
 def unit(n):
  require(np.isfinite(n).all()and np.linalg.norm(n)>1e-12,'Validnewnormalfield');return n/np.linalg.norm(n)
 for i in range(len(arrays['POSITION'])):
  tag=newlabels[i]
  if tag in halo or i>=len(old['POSITION']):skinN[i]=unit(field[tag])if np.linalg.norm(field[tag])>1e-12 else[1.,0.,0.]
  if tag in halo:darkN[i]=skinN[i]
 for i in range(len(bodyN)):
  tag=c['labels'].get((0,i),'body:0:'+str(i))
  if tag in halo:bodyN[i]=unit(field[tag])
 L=np.asarray(lining);T=arrays['POSITION'][L].astype(float);A=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);sums=np.zeros_like(arrays['POSITION'],dtype=float)
 for k in range(3):np.add.at(sums,L[:,k],A)
 for i in range(len(old['POSITION']),len(arrays['POSITION'])):darkN[i]=unit(sums[i])if np.linalg.norm(sums[i])>1e-12 else skinN[i]
 require(np.isfinite(skinN).all()and np.isfinite(darkN).all(),'Finitenewnormals');return arrays,skinN,darkN,bodyN,idx,{'surface':s,'local_to_actual':mapping,'old_dark_keep_indices':keep,'new_source_labels':labels,'new_owners':newowners,'source_new_vertices':source_new,'normal_halo_labels':sorted(halo),'protected_normal_labels':sorted(c['protected_labels']),'protected_boundary_normal_exclusions':sorted(boundary&c['protected_labels'])}
