# SPDX-License-Identifier: CC0-1.0
"""Original fixed U-slit lip tissue; pure arrays, no horse IO or export.
Dimensions are explicit reconstruction; this function is not a fit acceptance.
"""
import math
import numpy as np
from chart_topology import triangulate,validate_sheets
BREAKS=[0,4,9,23,28,32,38,60,66]
def require(x,msg):
 if not x:raise ValueError(msg)
def smooth(t):
 t=max(0.,min(1.,float(t)));return t*t*t*(10+t*(-15+6*t))
def surface(outer,inner,normals):
 O,I,N=[np.asarray(a,dtype=float)for a in[outer,inner,normals]];require(O.shape==I.shape==N.shape==(66,3),'Exact66sourceboundaries');require(np.isfinite(O).all()and np.isfinite(I).all()and np.isfinite(N).all(),'Finiteboundary');require(np.all(np.linalg.norm(N,axis=1)>.5),'Exteriornormalfield')
 # Source-defined source arcs contain actual original z=.39 samples.
 corners={}
 for side,top,bottom in [(-1,range(60,66),range(4,9)),(1,range(32,38),range(23,28))]:
  def at39(ids):
   found=[i for i in ids if abs(O[i,2]-.39)<1e-12];require(len(found)==1,'Exactsourcez39anchor');return abs(O[found[0],0])
  corners[side]=.95*(at39(top)+at39(bottom))/2
 def aperture(arc,k):
  start,end=BREAKS[arc:arc+2];span=end-start;u=(k-start)/span
  if arc in[0,4]:
   theta=(math.pi/2-math.pi*u)if arc==0 else(-math.pi/2+math.pi*u);side=-1 if arc==0 else 1
   return[side*corners[side],-.20175+.01375*math.sin(theta),.395-.018*math.cos(theta)]
  # Interpolate the actual original source-edge coordinate, not proximity.
  j=int(math.floor(k))%66;f=k-math.floor(k);p=(1-f)*O[j]+f*O[(j+1)%66]
  if arc in[1,3,5,7]:
   za,zb=O[start,2],O[end%66,2];require(abs(zb-za)>.1,'Sourceorderedlongitudinalarc');u=(p[2]-za)/(zb-za);back_to_front=u if arc in[1,5]else 1-u;z=.395+(.530-.395)*back_to_front;t=smooth((z-.415)/(.490-.415));upper=arc in[5,7];y=(1-t)*(-.188 if upper else-.2155)+t*(-.207 if upper else-.209);side=-1 if arc in[1,7]else 1;x=side*((1-smooth(back_to_front))*corners[side]+smooth(back_to_front)*.020);return[x,y,z]
  require(arc in[2,6],'Exacteightarcs');xa,xb=O[start,0],O[end%66,0];require(abs(xb-xa)>.04,'Sourceorderedfrontarc');u=(p[0]-xa)/(xb-xa);x=.020*((2*u-1)if arc==2 else(1-2*u));curve=1-(x/.020)**2;return[x,(-.209 if arc==2 else-.207)+.001*curve,.530+.002*curve]
 A=[];M=[];phases=[]
 for i in range(66):
  arc=next(a for a in range(8)if BREAKS[a]<=i<BREAKS[a+1])
  for f in[0.,.5]:
   p=np.asarray(aperture(arc,i+f));base=(1-f)*O[i]+f*O[(i+1)%66];n=(1-f)*N[i]+f*N[(i+1)%66];n=n/np.linalg.norm(n);mid=.35*base+.65*p+.0015*math.sin(math.pi*.65)*n;M.append(mid.tolist());A.append(p.tolist());phases.append({'old_edge':i,'fraction':f,'chart':arc})
 # Canonical local indices: exact outer66, exact inner66, mid132, aperture132.
 V=O.tolist()+I.tolist()+M+A;mid=list(range(132,264));ap=list(range(264,396));F=[];owners=[]
 def tri(a,b,c,kind,edge):
  require(len({a,b,c})==3,'Distincttriangleindices');q=np.asarray([V[a],V[b],V[c]]);require(np.linalg.norm(np.cross(q[1]-q[0],q[2]-q[0]))>2e-12,'Nondegenerateliptriangle');F.append([a,b,c]);owners.append({'kind':kind,'source_edge':edge})
 def polygon(ids,kind,edge):
  chart=next(a for a in range(8)if BREAKS[a]<=edge<BREAKS[a+1])
  for f in triangulate(V,ids,chart):
   tri(*f,kind,edge);owners[-1]['chart']=chart
 for i in range(66):
  j=(i+1)%66;polygon([i,j,mid[(2*i+2)%132],mid[2*i+1],mid[2*i]],'lip_skin',i)
 for i in range(132):
  j=(i+1)%132;polygon([mid[i],mid[j],ap[j],ap[i]],'lip_skin',i//2)
 for i in range(66):
  j=(i+1)%66;polygon([ap[2*i],ap[2*i+1],ap[(2*i+2)%132],66+j,66+i],'oral_lining',i)
 chart_proof=validate_sheets(V,F,owners)
 return{'positions':V,'faces':F,'owners':owners,'outer':list(range(66)),'inner':list(range(66,132)),'mid':mid,'aperture':ap,'phases':phases,'source_corner_halfwidth_m':corners,'local_chart_proof':chart_proof,'status':'UNACCEPTED fixed neutral lip reconstruction; actual embedding/bit/gear/visual untested'}
