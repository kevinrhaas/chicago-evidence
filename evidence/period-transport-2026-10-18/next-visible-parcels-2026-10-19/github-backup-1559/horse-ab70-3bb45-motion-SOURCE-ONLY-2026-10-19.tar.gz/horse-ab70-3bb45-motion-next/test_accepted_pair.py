# SPDX-License-Identifier: GPL-3.0-or-later
import unittest,tempfile,json,hashlib
from pathlib import Path
from unittest.mock import patch
import accepted_pair as a
class Prerequisite(unittest.TestCase):
 def fixture(self,p):
  inputs={'horse':('h','1'),'candidate':('g','2'),'baseline':('b','3')};op={'PASS':True,'inputs':{k:list(v)for k,v in inputs.items()}};rows=[]
  for i,c in enumerate(['idle','walk']):
   d=p/'trial/runs/repair2'/f'pose-{i:02d}-{c}';d.mkdir(parents=True);(d/'actual').write_bytes(b'fixture');rows.append({'PASS':True,'pose':{'clip':c,'phase':0,'index':i},'artifact_hashes':{'actual':hashlib.sha256(b'fixture').hexdigest()}})
  r={'PASS':True,'input_sha256':{k:v[1]for k,v in inputs.items()},'completed_poses':rows};(p/'two-pose-operator-result.json').write_text(json.dumps(op));(p/'trial/runs/repair2/RESULT.json').write_text(json.dumps(r));return inputs,r
 def test_exact_positive_then_artifact_mutation_refuses(self):
  with tempfile.TemporaryDirectory()as td,patch.object(a,'P',Path(td)):
   inputs,r=self.fixture(Path(td));a.require_two_pose(inputs);(Path(td)/'trial/runs/repair2/pose-01-walk/actual').write_bytes(b'changed')
   with self.assertRaises(ValueError):a.require_two_pose(inputs)
 def test_capture_only_partial_wrong_pair_and_reordered_refuse(self):
  for kind in ['capture_only','partial','wrong_pair','reordered']:
   with self.subTest(kind=kind),tempfile.TemporaryDirectory()as td,patch.object(a,'P',Path(td)):
    p=Path(td);inputs,r=self.fixture(p)
    if kind=='capture_only':r['PASS']=False;r['capture_complete']=True
    if kind=='partial':r['completed_poses'].pop()
    if kind=='wrong_pair':r['input_sha256']['candidate']='wrong'
    if kind=='reordered':r['completed_poses'].reverse()
    (p/'trial/runs/repair2/RESULT.json').write_text(json.dumps(r))
    with self.assertRaises(ValueError):a.require_two_pose(inputs)
if __name__=='__main__':unittest.main()
