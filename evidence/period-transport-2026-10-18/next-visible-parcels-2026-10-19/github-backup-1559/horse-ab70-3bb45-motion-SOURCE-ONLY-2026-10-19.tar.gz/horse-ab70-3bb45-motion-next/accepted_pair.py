# SPDX-License-Identifier: GPL-3.0-or-later
"""Revalidate actual prerequisite, never substitute capture-only data for fit."""
from pathlib import Path
import json,hashlib
P=Path('/workspace/shared/horse-breeching-swept-route-next')
def require(c,m):
 if not c:raise ValueError(m)
def require_two_pose(inputs):
 op=json.loads((P/'two-pose-operator-result.json').read_text());r=json.loads((P/'trial/runs/repair2/RESULT.json').read_text());want={k:list(v)for k,v in inputs.items()};require(op.get('PASS')is True and op.get('inputs')==want and r.get('PASS')is True and r.get('input_sha256')=={k:v[1]for k,v in inputs.items()},'actual samepair two-pose prerequisite')
 rows=r.get('completed_poses',[]);require(len(rows)==2 and [(x['pose']['clip'],x['pose']['phase'])for x in rows]==[('idle',0),('walk',0)]and all(x.get('PASS')is True for x in rows),'complete actual prerequisite coverage')
 for x in rows:
  d=P/'trial/runs/repair2'/f"pose-{x['pose']['index']:02d}-{x['pose']['clip']}";hashes=x.get('artifact_hashes');require(isinstance(hashes,dict)and bool(hashes),'actual prerequisite artifact inventory')
  for n,w in hashes.items():require(not Path(n).is_absolute()and'..'not in Path(n).parts and hashlib.sha256((d/n).read_bytes()).hexdigest()==w,'actual two-pose artifact hash '+n)
 return r
