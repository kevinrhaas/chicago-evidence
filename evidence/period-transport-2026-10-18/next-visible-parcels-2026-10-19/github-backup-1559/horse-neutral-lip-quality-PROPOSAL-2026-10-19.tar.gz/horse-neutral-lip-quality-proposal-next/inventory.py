# SPDX-License-Identifier: GPL-3.0-or-later
"""Read actual57d source-owned oral geometry; no proposed geometry evaluation."""
from pathlib import Path
import sys,json,hashlib,collections
import numpy as np
sys.path.insert(0,'/workspace/shared/horse-cheek-throat-quality-next')
from checked_quality import checked
P=Path(__file__).parent;SRC=Path('/workspace/shared/horse-oral-channel-diagonal-candidate/candidate-one/head-source-surface.json')
def inventory():
 m,labels,head,owners,scopes,raw=checked();require=lambda ok,msg:None if ok else(_ for _ in()).throw(ValueError(msg));require(hashlib.sha256(raw).hexdigest()=='57d63e2d7234380adeb727f5efeeed74d50629b2a8367ccea48961d6ecc5bec2','Actual57d');s=json.loads(SRC.read_text());r=next(x for x in s['records']if x['name']=='mouth_oral');mouth=[];halo=[]
 for g,o in owners.items():
  if o.get('kind')!='oral_channel':continue
  inner=o['source_owner'];row={'global_face':g,'material':m.views[(m.descriptor(g)['mesh'],m.descriptor(g)['primitive'])]['material'],'owner':o,'actual_mesh':m.descriptor(g)['mesh'],'actual_primitive':m.descriptor(g)['primitive'],'vertices':m.descriptor(g)['primitive_vertices']}
  (halo if inner['kind']=='retained_source'else mouth).append(row)
 require(len(mouth)==334 and len(halo)==137,'Actualsourceownednewmouthvsretainedhalo');B=[0,4,9,23,28,32,38,60,66];v=np.asarray(s['positions']);arcs=[]
 for i,(a,b)in enumerate(zip(B,B[1:])):
  ids=r['outer'][a:b];q=v[ids];arcs.append({'arc':i,'source_ids':ids,'local_bounds_m':[q.min(0).tolist(),q.max(0).tolist()],'positions_local_m':q.tolist()})
 result={'status':'SOURCE INVENTORY ONLY; proposedneutral mouth unexecuted','parent_sha256':hashlib.sha256(raw).hexdigest(),'source_head_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'oral_record':r,'mouth_faces':mouth,'retained_normal_halo_faces':halo,'mouth_material_counts':dict(collections.Counter(x['material']for x in mouth)),'source_owner_counts':dict(collections.Counter(x['owner']['source_owner']['kind']for x in mouth)),'outer_arcs':arcs,'actual_reference_pixels':[{'path':str(x),'sha256':hashlib.sha256(x.read_bytes()).hexdigest(),'actually_viewed':True}for x in[Path('/workspace/shared/horse-base-reference-audit/illo262.png'),Path('/workspace/shared/horse-base-reference-audit/muybridge-horse-in-motion-1878.jpg')]]}
 return result
if __name__=='__main__':
 r=inventory();(P/'source-inventory.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k]for k in['mouth_material_counts','source_owner_counts']}))
