# Root path correction — source only, not installed

Preserves the original6469 unresolved archive. Changes only the proposed page source: use existing resolveBases() with the actual renderer-root URL resolved from import.meta.url, preserving the supported data/assets query overrides. Directory/recipe/contract and resident-card requests use dataBase; actual GLB requests use assetBase. Fixes a second preexisting draft error: the installed Three module is at vendor/three-0.185.1/three.module.js, with no build/ directory. No fallback host, model, person or hashed-delivery bypass.

Original MANIFEST/sourcepins/status docs are preserved as PREDECESSOR evidence and are stale for the TWO updated files. New PATHFIX-HASHES.json is the current file authority for this draft. Actual approved fourLOD bytes/hashes and model/browser fit remain unavailable, so this is still unaccepted and not install-ready. Root did not create a human GLB or change the app. Independent source review is next.
