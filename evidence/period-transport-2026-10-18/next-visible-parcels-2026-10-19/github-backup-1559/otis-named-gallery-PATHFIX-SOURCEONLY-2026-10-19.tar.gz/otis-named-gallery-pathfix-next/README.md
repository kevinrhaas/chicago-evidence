# Named Otis study — path-corrected source only, unaccepted

This preserves original6469 as predecessor and fixes two draft path bugs. The page now resolves renderer-root via import.meta.url and uses existing scene-loader resolveBases: JSON and cards use dataBase; named GLBs use assetBase. Source, published and prefixed dev-preview URL cases plus supported query overrides were checked against the actual current project resolver. Three import points to the installed version-root module, not nonexistent build/.

Actual qualified delivery is still null: no approved fourLOD hashes/bytes are present. The page refuses before loading a surrogate. This is NOT install-ready or browser/model/photographic accepted. Actual loaded bounds, camera/phone framing, textures, animation/contact, resident-card behavior, cleanup and source/published probes remain necessary once approved assets arrive. Existing named reconstructed1835 resident, no archival likeness claim.

PATHFIX-HASHES is the fourfile source authority; independent source review is separate. predecessor-records preserve old stale docs/pins and do not override current files. No app edits or asset delivery occurred. Existing GPL3 code license remains. The active environment is stillspec1; draft16 needs user application before blocked artifact hosts may be retried.
