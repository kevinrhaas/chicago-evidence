# SPDX-License-Identifier: GPL-3.0-or-later
"""Archive only immutable completed pose artifacts; no capture or fit execution."""
from pathlib import Path
import hashlib,json,tarfile,io,time,os
P=Path('/workspace/shared/horse-ab70-3bb45-motion-next');S=P/'runs/full63';OUT=Path('/workspace/shared/horse-ab70-3bb45-full63-completed-chunks');
# The existing fit is never signalled, restarted or imported by this archiver.
REC=Path(__file__).parent
EXPECTED_INDEX_SHA='07bd6c882e24fa125612bb53fb3b42389f31e6777fdb76ff7712a0d9c77263a8'
EXPECTED_SOURCE='a3ace1a9ec8cd02b889d6811ff4406d02f995bb6480e0d70b6e41fac129cb823'
sha=lambda b:hashlib.sha256(b).hexdigest()
oldstat=Path('/proc/1385209/stat')
if oldstat.exists() and oldstat.read_text().split(') ',1)[1].split()[0]!='Z':raise ValueError('old archiver is not proved stopped; refuse second writer')
raw=(OUT/'INDEX.json').read_bytes()
if sha(raw)!=EXPECTED_INDEX_SHA or raw!=(REC/'prior-index.json').read_bytes():raise ValueError('prior index changed; no takeover')
INDEX=json.loads(raw)
if sha((P/'SOURCE-HASHES.json').read_bytes())!=EXPECTED_SOURCE:raise ValueError('fit source inventory changed')
for n,w in json.loads((P/'SOURCE-HASHES.json').read_text()).items():
 if sha((P/n).read_bytes())!=w:raise ValueError('fit source changed '+n)
prior=INDEX['chunks'];indices=[i for r in prior for i in r['completed_indices']]
if indices!=list(range(21)) or len(prior)!=3 or INDEX.get('full63_PASS')is not False:raise ValueError('exact3chunks/21completed prerequisite')
for row in [INDEX['source_archive'],*prior]:
 f=Path(row['file'])
 if f.parent!=OUT or f.stat().st_size!=row['bytes'] or sha(f.read_bytes())!=row['sha256']:raise ValueError('prior immutable archive mismatch')
lock=OUT/'RECOVERY-WRITER.lock'
with lock.open('x')as f:f.write(json.dumps({'pid':os.getpid(),'source_sha256':sha(Path(__file__).read_bytes()),'prior_index_sha256':EXPECTED_INDEX_SHA})+'\n')
nextpose=21
INDEX['recovery_v2']={'source_sha256':sha(Path(__file__).read_bytes()),'prior_index_sha256':EXPECTED_INDEX_SHA,'old_pid':1385209,'old_stopped':True,'writer_pid':os.getpid(),'scope':'Persistence ONLY; original fit/model/source unchanged'}
def emit(row):
 with(REC/'progress.log').open('a')as f:f.write(json.dumps(row)+'\n')
def publish(tmp,dest):
 # Same-directory hardlink publishes an entirely closed file atomically and REFUSES replacement.
 os.link(tmp,dest);tmp.unlink()
def save():
 tmp=OUT/('.INDEX.v2.'+str(os.getpid())+'.tmp')
 with tmp.open('x')as f:json.dump(INDEX,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(tmp,OUT/'INDEX.json')
def archive(rows,stage,extra_failure=None):
 global nextpose
 first=rows[0]['pose']['index']if rows else nextpose;last=rows[-1]['pose']['index']if rows else first-1
 name=f'poses-{first:02d}-{last:02d}'+('-FIRSTFAILURE'if extra_failure else '')+'.tar.gz';a=OUT/name;receipt={'scope':'Selected completed actual poses only; NOTfull63acceptance','source_inventory_sha256':stage['source_inventory_sha256'],'input_sha256':stage['input_sha256'],'indices':[x['pose']['index']for x in rows],'poses':[x['pose']for x in rows],'first_failure':extra_failure,'files':{}}
 tmp=OUT/('.'+name+'.partial-'+str(os.getpid()))
 with tarfile.open(tmp,'x:gz',compresslevel=6)as t:
  def add(n,b):
   i=tarfile.TarInfo(n);i.size=len(b);t.addfile(i,io.BytesIO(b));receipt['files'][n]=sha(b)
  for row in rows:
   d=S/f"pose-{row['pose']['index']:02d}-{row['pose']['clip']}"
   for n,w in row['artifact_hashes'].items():
    f=d/n;b=f.read_bytes()
    if sha(b)!=w:raise ValueError('completed artifact changed '+str(f))
    add(d.name+'/'+n,b)
  if extra_failure:
   for f in sorted((S/extra_failure['directory']).rglob('*')):
    if f.is_file()and'__pycache__'not in f.parts:add('FIRSTFAILURE/'+str(f.relative_to(S)),f.read_bytes())
  b=(json.dumps(receipt,indent=2)+'\n').encode();i=tarfile.TarInfo('CHUNK-RECEIPT.json');i.size=len(b);t.addfile(i,io.BytesIO(b))
 size=tmp.stat().st_size
 if size>40*1024**2:raise ValueError('unexpected >40MiB archive; preserved, no retry')
 publish(tmp,a)
 meta={'file':str(a),'sha256':sha(a.read_bytes()),'bytes':size,'completed_indices':receipt['indices'],'pose_count':len(rows),'first_failure':extra_failure};INDEX['chunks'].append(meta);nextpose=last+1;save();emit(meta)
save();emit({'recovery':'started','first_unarchived_pose':21,'all3prior_archives_rehashed':True})
while True:
 raw=(S/'RESULT.json').read_bytes()
 try:r=json.loads(raw)
 except json.JSONDecodeError:time.sleep(1);continue
 rows=r['completed_poses'];n=len(rows)
 while n-nextpose>=7:archive(rows[nextpose:nextpose+7],r)
 if r.get('error')or r.get('PASS')is True:
  if r.get('error'):
   names=[p.name for p in S.glob('pose-*')if p.is_dir()];done={f"pose-{x['pose']['index']:02d}-{x['pose']['clip']}"for x in rows};partial=sorted(set(names)-done);extra={'error':r['error'],'directory':partial[0]}if partial else {'error':r['error'],'directory':'controls'};archive(rows[nextpose:],r,extra)
  elif nextpose<n:archive(rows[nextpose:],r)
  # Terminal source result and controls, no duplicated pose payloads.
  a=OUT/'terminal-result-and-controls.tar.gz'
  tmp=OUT/('.terminal.partial-'+str(os.getpid()))
  with tarfile.open(tmp,'x:gz',compresslevel=6)as t:
   for f in [S/'RESULT.json',*sorted((S/'controls').rglob('*'))]:
    if f.is_file()and'__pycache__'not in f.parts:t.add(f,arcname=str(f.relative_to(S)),recursive=False)
  if tmp.stat().st_size>40*1024**2:raise ValueError('terminal archive >40MiB')
  publish(tmp,a)
  INDEX.update(full63_PASS=r.get('PASS')is True,completed_poses=n,error=r.get('error'),terminal_stage_result_sha256=sha(raw),terminal_archive={'file':str(a),'sha256':sha(a.read_bytes()),'bytes':a.stat().st_size});save();emit({'TERMINAL':INDEX});break
 INDEX.update(completed_poses=n,observed_elapsed_s=r['elapsed_s'],full63_PASS=False);save();time.sleep(20)
