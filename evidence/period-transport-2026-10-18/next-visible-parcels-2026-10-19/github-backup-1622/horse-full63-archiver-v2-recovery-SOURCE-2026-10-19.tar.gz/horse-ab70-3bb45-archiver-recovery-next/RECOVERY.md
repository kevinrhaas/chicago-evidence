{
  "scope": "Persistence recovery ONLY, no fit restart/model/source changes",
  "old_pid": 1385209,
  "old_state": "Z",
  "old_script_sha256": "6096e61327a12a1215b47ec8d1aca3bb6d63f85de97d164d1695cd8a9ab85bb5",
  "old_index_sha256": "07bd6c882e24fa125612bb53fb3b42389f31e6777fdb76ff7712a0d9c77263a8",
  "reason": "Old archiver defunct and INDEX stale after21. Exact exception unavailable; broken stdout pipe is hypothesis only. Existingfit continued."
}
