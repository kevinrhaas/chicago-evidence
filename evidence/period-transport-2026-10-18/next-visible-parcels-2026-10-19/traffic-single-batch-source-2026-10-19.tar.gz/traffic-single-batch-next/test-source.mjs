// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';import fs from 'node:fs';import crypto from 'node:crypto';
import{GLTFLoader}from'three/addons/loaders/GLTFLoader.js';import{createTrafficBatch}from'./batch.mjs';
const base='/workspace/chicago/chicago/4d/renderers/web/transport/',sources={wagon:base+'wagon/wagon-w01.glb',horse:base+'horse/equine_light_harness_skinned_prototype_01.glb',manifest:base+'horse/manifest.json'};
const assets={};for(const k of ['wagon','horse']){const b=fs.readFileSync(sources[k]);assets[k]=await new GLTFLoader().parseAsync(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),'');}
const b=await createTrafficBatch({wagonURL:'wagon',horseURL:'horse',horseManifestURL:'manifest',loadGLTF:async id=>assets[id],loadManifest:async()=>JSON.parse(fs.readFileSync(sources.manifest))});
assert.equal(b.receipt.triangles,24964);assert.equal(b.mesh.geometry.index.count,24964*3);assert.equal(b.mesh.geometry.groups.length,0);assert.equal(b.mesh.castShadow,false);assert.equal(b.mesh.receiveShadow,false);assert.equal(b.mesh.material.transparent,false);assert.equal(b.mesh.material.side,0);
const sample={e:0,n:0,distance_m:0,yaw_enu_rad:0,scene:'1835',grade:'reconstructed'};
const state={wagon:sample,horse:{...sample,e:5},simulationS:0,cameraDistance:100};b.update(state);
const initial=b.mesh.geometry.attributes.position.array.slice();b.update({...state,wagon:{...sample,distance_m:2},horse:{...sample,distance_m:2,e:5},simulationS:1});
assert.ok(initial.some((v,i)=>v!==b.mesh.geometry.attributes.position.array[i]),'actual wheel/horse pose changes');
assert.ok(Array.from(b.mesh.geometry.attributes.position.array).every(Number.isFinite));assert.ok(Array.from(b.mesh.geometry.attributes.normal.array).every(Number.isFinite));
const frozen=b.mesh.geometry.attributes.position.array.slice();b.update({...state,simulationS:2,paused:true});assert.deepEqual(b.mesh.geometry.attributes.position.array,frozen);
b.update({...state,cameraDistance:79});assert.equal(b.mesh.visible,false);b.update({...state,cameraDistance:241});assert.equal(b.mesh.visible,false);assert.throws(()=>b.update({...state,horse:{...sample,scene:'1904'}}),/1835/);
const shader={uniforms:{},vertexShader:'#include <beginnormal_vertex>\n#include <begin_vertex>',fragmentShader:'#include <roughnessmap_fragment>\n#include <metalnessmap_fragment>'};b.mesh.material.onBeforeCompile(shader);assert.ok(shader.vertexShader.includes('trafficFrames[1]'));assert.ok(shader.fragmentShader.includes('roughnessFactor=vTrafficPBR.x'));assert.ok(shader.fragmentShader.includes('metalnessFactor=vTrafficPBR.y'));
const receipt={scope:'actual GLTFLoader/CPU source geometry and shader-string tests ONLY; no renderer/browser cost or shader compilation acceptance',source_sha256:Object.fromEntries(Object.entries(sources).map(([k,p])=>[k,crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')])),...b.receipt,tests:'PASS'};
fs.writeFileSync(new URL('./cpu-source-receipt.json',import.meta.url),JSON.stringify(receipt,null,2)+'\n');b.dispose();console.log(JSON.stringify(receipt));
