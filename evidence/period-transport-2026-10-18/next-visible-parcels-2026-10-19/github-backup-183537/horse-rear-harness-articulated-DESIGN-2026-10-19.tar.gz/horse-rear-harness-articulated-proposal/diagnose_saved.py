# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only sparse standoff diagnostics on previously qualified idle capture. No fit acceptance."""
from pathlib import Path
import json,hashlib,sys,numpy as np
P=Path(__file__).parent; C=Path('/workspace/shared/horse-ab70-3bb45-motion-next/runs/full63/pose-00-idle/idle-fit/capture')
sys.path.insert(0,'/workspace/shared/horse-ab70-3bb45-motion-next')
from unsigned_distance import pts_tri
sha=lambda b:hashlib.sha256(b).hexdigest()
inputs={}
def load(n):
 raw=(C/(n+'.json')).read_bytes();m=json.loads(raw);b=(C/(n+'.f64')).read_bytes()
 if sha(b)!=m['buffer_sha256'] or m['precision']!='float64_world':raise ValueError('capture binding')
 inputs[n]={'metadata_sha256':sha(raw),'buffer_sha256':sha(b),'input':m['input']}
 return m,np.frombuffer(b,dtype='<f8').reshape(-1,3,3)
h,ht=load('horse');g,gt=load('candidate');out={'scope':'Sparse actual previously captured idle vertices only; NOT fit or whole-surface max gap','inputs':inputs,'parts':{}}
for name in ['breeching','hip_support_l','hip_support_r','girth','shaft_tug_l','shaft_tug_support_l']:
 rows=[r for r in g['meshes']if r['name']==name]
 if len(rows)!=1:raise ValueError('unique named part')
 r=rows[0];v=np.unique(gt[r['start']:r['start']+r['count']].reshape(-1,3),axis=0);ix=set(np.linspace(0,len(v)-1,min(17,len(v)),dtype=int).tolist())
 for k in range(3):ix.add(int(v[:,k].argmin()));ix.add(int(v[:,k].argmax()))
 samples=[]
 for i in sorted(ix):
  d=pts_tri(v[i],ht);j=int(d.argmin());owner=next(a for a in h['meshes']if a['start']<=j<a['start']+a['count']);samples.append({'gear_point_world_m':v[i].tolist(),'nearest_distance_m':float(np.sqrt(d[j])),'horse_global_face':j,'horse_mesh':owner['name'],'horse_mesh_local_face':j-owner['start'],'horse_triangle_world_m':ht[j].tolist()})
 out['parts'][name]={'unique_vertices':len(v),'world_bbox_m':[v.min(0).tolist(),v.max(0).tolist()],'samples':samples,'sampled_min_m':min(s['nearest_distance_m']for s in samples),'sampled_max_m':max(s['nearest_distance_m']for s in samples)}
(P/'ACTUAL-IDLE-LANDMARKS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({n:{k:v[k]for k in ['sampled_min_m','sampled_max_m']}for n,v in out['parts'].items()}))
