# FIRST actual trial failure: construction refused before GLB

Sourcea2cb3056/234122 and independentexecutable reviewb9ea2d64 remain immutable. Both actualoldnegative gates PASS: A457girthclosure0/760 and alltenold8cepanel/girth strictproper witnesses. ONE actualbuild was attempted with pinned6e9b/A457/50463inputs.

The original determinant-based convexsupportoffset rejected near-parallel adjacent supportplanes at the firstband: ValueError('No unresolved parallel support planes'). Exacttraceback and candidate/failure.json preserved. NO newcandidate.glb was emitted. No decoded/Khronos/capture/self/interpart/wholehorse/browser trial followed; no automaticretry, changedguard, droppedhullface or scalaroffsetsearch.

The actualconstruction result is FAILED/INCOMPLETE, not a fit or visualresult. The firstfailure does not affect frozenapp/CI or earliermodelarchives. Elevenlayer/rig/shapeprotection remains the sourcecontract, but cannot be claimed as validated newoutput when nooutput exists.

Proposed source-only mathematical followup: for incident outwardunitnormals n0,n1 at originalvertexP, offsetvertex=P+d*(n0+n1)/(1+dot(n0,n1)). This algebraically solves both incident shiftedplanes and is stable for alignednear-parallel normals; a nonpositive/nearlyzero denominator (opposing normals) must still refuse. It must be independently reviewed and tested onanalytic controls, and actualfailedhull diagnosis requires separate bounded readonlyrelease. No correction is implemented or newbuildauthorized by this receipt.
