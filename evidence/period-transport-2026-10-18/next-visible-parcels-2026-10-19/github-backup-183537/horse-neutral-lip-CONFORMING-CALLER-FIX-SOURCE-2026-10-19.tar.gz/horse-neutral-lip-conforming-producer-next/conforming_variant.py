# SPDX-License-Identifier: GPL-3.0-or-later
"""Fixed conforming lip reconstruction. Import does NOT evaluate a horse surface.
Production/appearance is unaccepted. Actual execution requires reviewed caller.
"""
from pathlib import Path
from fractions import Fraction as Q
import sys,json,hashlib,copy,collections
import numpy as np
BASE=Path('/workspace/shared/horse-neutral-lip-source-phase-next')
sys.path.insert(0,str(BASE))
from lip_variant import context as old_context,Model,ATTRS,weights
from glb_data import append,encode
P=Path(__file__).parent
PARENT='57d63e2d7234380adeb727f5efeeed74d50629b2a8367ccea48961d6ecc5bec2'
ORIGIN=np.array([0.,1.88,.8])
def require(v,msg):
 if not v:raise ValueError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def load():
 pins=json.loads((P/'INPUTS.json').read_text())
 for path,digest in pins.items():require(sha(Path(path).read_bytes())==digest,'Input pin:'+path)
 for name,digest in json.loads((P/'LOCAL-PINS.json').read_text()).items():require(sha((P/name).read_bytes())==digest,'Local pin:'+name)
 c=old_context();require(sha(c['raw'])==PARENT,'Exact actual57d')
 a=json.loads((P/'complete-symbolic.json').read_text());t=json.loads((P/'head-topology.json').read_text());require(t['parent']['F']==3122 and t['assembled_head']['F']==3868 and len(a['triangles'])==1080,'Reviewed source shape')
 require(set(t['retired_current_mouth334'])==c['mouth']and len(c['mouth'])==334,'Exact full334 mouth retirement authority')
 source=json.loads(Path('/workspace/shared/horse-oral-channel-diagonal-candidate/source/frozen-head.json').read_text());patch=json.loads(Path('/workspace/shared/horse-oral-channel-diagonal-candidate/source/oral-patch.json').read_text())
 require(source is not None and len(patch['proposed_retired_source_face_ids'])==124,'Pinned original source template')
 skin=c['model'].d['skins'][0];palette=[c['model'].d['nodes'][i]['name']for i in skin['joints']];require('head'in palette and'root'in palette,'Actual joint palette identities')
 for node in c['model'].d['nodes']:
  if node.get('mesh')in[0,1]:require(node.get('skin')==0,'Reviewed body/head skin association')
 return dict(c=c,assembly=a,topology=t,source=source,patch=patch,palette=palette)
def bary(point,tri):
 def sub(a,b):return[a[k]-b[k]for k in range(2)]
 def cross(a,b):return a[0]*b[1]-a[1]*b[0]
 den=cross(sub(tri[1],tri[0]),sub(tri[2],tri[0]));require(den!=0,'Original sourcechart nondegenerate');b=cross(sub(point,tri[0]),sub(tri[2],tri[0]))/den;d=cross(sub(tri[1],tri[0]),sub(point,tri[0]))/den;return[1-b-d,b,d]
def smooth(q):q=max(0.,min(1.,q));return q*q*q*(10+q*(-15+6*q))
def fields(ctx):
 """Future ONLY: evaluate one declared recipe, no parameters/search."""
 c=ctx['c'];old=c['model'].views[1,0]['attributes'];A=ctx['assembly'];source=ctx['source'];lookup={};actualbindings={};cache={};sourceproof={}
 # All raw semantic aliases must agree in actual P/JW, never choose by proximity.
 for(mi,i),tag in c['labels'].items():lookup.setdefault(tag,[]).append((mi,i))
 def raw(tag):
  require(tag in lookup,'Actual source alias:'+tag);rows=[]
  for mi,i in lookup[tag]:
   view=next(v for key,v in c['model'].views.items()if key[0]==mi);rows.append((mi,i,view['attributes']))
  mi,i,a=rows[0]
  for _,j,b in rows:
   for k in['POSITION','JOINTS_0','WEIGHTS_0']:require(b[k][j].tobytes()==a[k][i].tobytes(),'Raw alias exact:'+tag+':'+k)
  actualbindings[tag]=[{'mesh':mi,'vertex':j,'raw_PJW':{k:sha(b[k][j].tobytes())for k in['POSITION','JOINTS_0','WEIGHTS_0']}}for mi,j,b in rows]
  return a['POSITION'][i].astype(float),a['JOINTS_0'][i].tolist(),a['WEIGHTS_0'][i].tolist(),a['NORMAL'][i].astype(float)
 def blend(parts):
  pos=sum((alpha*rec[0]for alpha,rec in parts),np.zeros(3));J,W=weights([(alpha,rec[1],rec[2])for alpha,rec in parts]);return pos,J,W,None
 uv={i:(Q(str(p[2])),Q((i-72)%48))for i,p in enumerate(source['positions'])if 72<=i<648}
 def cut(tag):
  z,theta=map(Q,tag.split(':')[1:]);aliases=[]
  for f in ctx['patch']['proposed_retired_source_face_ids']:
   ids=source['faces'][f];w=bary((z,theta),[uv[i]for i in ids])
   if min(w)>=0:aliases.append((f,ids,w))
  require(aliases,'Cut point contained in original triangle footprint');values=[]
  for face,ids,w in aliases:
   parts=[(alpha,raw('h:'+str(i)))for alpha,i in zip(w,ids)if alpha];value=blend([(float(alpha),rec)for alpha,rec in parts]);exactP=np.asarray([float(sum((alpha*Q.from_float(float(rec[0][axis]))for alpha,rec in parts),Q(0)))for axis in range(3)]);values.append((exactP,value[1],value[2],None))
  # Dyadic source-edge ties can differ by arithmetic roundoff before the one
  # mandatory binary32 store; require exact STORED values/JW across aliases.
  ref=values[0]
  for row in values:
   require(np.asarray(row[0],dtype='<f4').tobytes()==np.asarray(ref[0],dtype='<f4').tobytes(),'Stored cut alias P exact')
   require(np.asarray(row[1],dtype='<u2').tobytes()==np.asarray(ref[1],dtype='<u2').tobytes()and np.asarray(row[2],dtype='<f4').tobytes()==np.asarray(ref[2],dtype='<f4').tobytes(),'Stored cut alias JW exact')
  sourceproof[tag]=[{'source_face':f,'vertices':ids,'barycentric':[str(x)for x in w]}for f,ids,w in aliases];return ref
 extra={e['alias']:e for r in json.loads((P/'interface-map.json').read_text())['posterior_crescents']for e in r['station395_splits']};plane=json.loads((P/'current-map.json').read_text())['shared_cut_edge_knots']
 def resolve(tag):
  if tag in cache:return cache[tag]
  if tag.startswith(('h:','oral:')):value=raw(tag)
  elif tag.startswith(('station395:','plane420:')):
   e=extra[tag]if tag.startswith('station395:')else plane[':'.join(tag.split(':')[1:])];a,b=e.get('edge',e.get('source_edge'));t=Q(e['fraction']);value=blend([(float(1-t),raw('oral:'+str(a))),(float(t),raw('oral:'+str(b)))])
  elif tag.startswith('cut:'):value=cut(tag)
  elif tag.startswith('inner:'):
   # Canonical retained-source aliases must already have been resolved by the
   # complete symbolic table; no duplicate formula at a retained interface.
   require(tag not in A['seam_equivalences'],'Unresolved retained seam alias')
   z,th=map(Q,tag.split(':')[1:]);zz=float(z);theta=float(th);base=cut('cut:'+str(z)+':'+str(th));root=base[0]-ORIGIN
   if z==Q('.532'):
    require(26<=th<=46,'Frontupper chart');u=float((th-26)/20);local=[-.018+.036*u,-.206,.526];region='front_roof'
   elif z==Q('.530')and 28<=th<=44:
    u=float((th-28)/16);local=[-.018+.036*u,-.212,.524];region='front_floor'
   elif z<=Q('.395'):
    require(26<=th<=28 or 44<=th<=46,'Rear commissure chart');left=th<30;u=float((th-26)/2 if left else(46-th)/2);local=[-.045 if left else.045,-.185-.033*u,zz];region='rear_commissure'
   else:
    require(th in[26,28,44,46],'Side sourcechart owner');upper=th in[26,46];left=th in[26,28];end=.532 if upper else.530;q=smooth((zz-.420)/(end-.420));width=.045+(.018-.045)*q;y=(-.185+(-.206+.185)*q)if upper else(-.218+(-.212+.218)*q);depth=.006*smooth((zz-.490)/(end-.490));local=[-width if left else width,y,zz-depth];region='upper_side'if upper else'lower_side'
   value=(np.asarray(local)+ORIGIN,base[1],base[2],None);sourceproof[tag]={'recipe_region':region,'source_cut_alias':'cut:'+str(z)+':'+str(th),'fixed_recipe':'conforming U and longitudinal vault; no parameters'}
  else:raise ValueError('Foreign symbolic source label:'+tag)
  require(np.isfinite(value[0]).all(),'Finite authored point');require(abs(sum(value[2])-1)<2e-6 and all(w>=0 for w in value[2]),'Normalized source weights');require(all(0<=j<len(ctx['palette'])for j in value[1]),'Actual skin palette bounds')
  cache[tag]=value;return value
 return resolve,actualbindings,sourceproof
def evaluate(ctx):
 c=ctx['c'];m=c['model'];A=ctx['assembly'];old=m.views[1,0]['attributes'];resolve,bindings,sourceproof=fields(ctx)
 # Exactly unchanged original posterior triangles retain original indices/attrs.
 old_by_source={o['oral_generated_face']:g for g,o in c['owners'].items()if o.get('kind')=='oral_channel'and g in c['cavity']};preserved={};pending=[]
 def original_tags(g):
  d=m.descriptor(g);return[c['labels'][d['mesh'],i]for i in d['primitive_vertices']]
 for i,(t,o)in enumerate(zip(A['triangles'],A['owners'])):
  g=old_by_source.get(o.get('oral_source_face'))if o['kind']=='retained_cavity_clip'else None
  # Cyclic orientation equality, never sorted triangle equality.
  if g is not None and any(t==original_tags(g)[k:]+original_tags(g)[:k]for k in range(3)):
   require(g not in preserved,'No duplicate retained posterior face');preserved[g]=i
  else:pending.append((i,t,o))
 retired=c['mouth']-set(preserved);require(len(preserved)==110,'Explicit original110 posterior faces remain exact;two posterior boundaryfaces split at395');require(len(retired)==224,'Exact224 active retired/split faces')
 arrays={k:old[k].copy().tolist()for k in ATTRS};newlabels={};copies={};newfaces=[];sums={}
 def material(owner):return 0 if owner['kind']=='conforming_exterior'else 1
 # Preserve material-specific normal creases. Semantic P/JW aliases stay shared.
 for i,t,o in pending:
  mat=material(o);idx=[]
  for tag in t:
   k=(mat,tag)
   if k not in copies:
    rec=resolve(tag);j=len(arrays['POSITION']);copies[k]=j;newlabels[str(j)]=tag;arrays['POSITION'].append(rec[0].tolist());arrays['JOINTS_0'].append(rec[1]);arrays['WEIGHTS_0'].append(rec[2]);arrays['NORMAL'].append([1.,0.,0.]);sums[j]=np.zeros(3)
   idx.append(copies[k])
  P32=np.asarray([arrays['POSITION'][j]for j in idx],dtype='<f4').astype(float);n=np.cross(P32[1]-P32[0],P32[2]-P32[0]);require(np.isfinite(n).all()and np.linalg.norm(n)>2e-12,'Actual serialized triangle finite/nondegenerate')
  for j in idx:sums[j]+=n
  newfaces.append({'assembly_face':i,'material':mat,'indices':idx,'source_owner':o,'source_labels':t})
 outer={'h:'+str(v)for v in c['record']['outer']}
 for(mat,tag),j in copies.items():
  rec=resolve(tag)
  # Original outer skin and retained cavity source vertices get the ACTUAL
  # retained seam normal, not a regenerated old field. Other new points use
  # incident faces of the same explicit material cohort.
  n=rec[3]if tag in outer or tag.startswith('oral:')else sums[j];require(n is not None and np.isfinite(n).all()and np.linalg.norm(n)>1e-12,'Valid source-bounded new normal');n=n if tag in outer or tag.startswith('oral:')else n/np.linalg.norm(n);arrays['NORMAL'][j]=n.tolist()
 arrays={k:np.asarray(v,dtype=old[k].dtype)for k,v in arrays.items()};require(all(np.isfinite(v).all()for v in arrays.values()),'All finite actual attribute arrays');require(np.all(abs(np.linalg.norm(arrays['NORMAL'].astype(float),axis=1)-1)<2e-5),'Actual normals unit')
 keep=[i for i in range(len(m.views[1,0]['indices']))if m.start[1,0]+i not in retired];idx={(1,0):np.vstack((m.views[1,0]['indices'][keep],np.asarray([r['indices']for r in newfaces if r['material']==1],dtype='<u4'))),(1,1):np.vstack((m.views[1,1]['indices'],np.asarray([r['indices']for r in newfaces if r['material']==0],dtype='<u4')))}
 detail={'retired_current_faces':sorted(retired),'preserved110_posterior':{str(k):v for k,v in sorted(preserved.items())},'old_dark_keep':keep,'source_bindings':bindings,'new_source_proof':sourceproof,'new_labels':newlabels,'new_faces':newfaces,'all_old_attribute_bytes_exact':True,'normal_authority':'ONLY newly appended copies; all original NORMAL bytes exact; material-specific field with fixed actual old seam normals','material_cohorts':{'coat':'conforming_exterior','dark':'wet lining,existing cavity clip,roof,floor,crescents'},'status':'UNACCEPTED original reconstruction; actualXYZ/gear/bit/appearance/motion pending'}
 return arrays,idx,detail

def serialize(ctx,arrays,idx):
 old=ctx['c']['model'];d=copy.deepcopy(old.d);b=bytearray(old.b);refs={}
 for k in ATTRS:refs[k]=append(d,b,arrays[k],'VEC4'if k in['JOINTS_0','WEIGHTS_0']else'VEC3',comp=5123 if k=='JOINTS_0'else 5126)
 for key in[(1,0),(1,1)]:
  d['meshes'][key[0]]['primitives'][key[1]]={'attributes':dict(refs),'indices':append(d,b,idx[key].reshape(-1),'SCALAR',comp=5125,target=34963),'material':1 if key==(1,0)else 0}
 return encode(d,b)

def authority(ctx):
 return{'parent_sha256':PARENT,'geometry':'NEW conforming original-source skin cut/longitudinal oral vault; no old4c3 geometry acceptance','symbolic_disk':ctx['assembly']['summary'],'original334_mouth_scope':sorted(ctx['c']['mouth']),'preservation':'Every old POSITION/NORMAL/JOINTS_0/WEIGHTS_0 accessor row exact; old BIN+accessor/view prefixes exact; all unaffected triangle indices/materials/nodes/rig/actions exact','guard':'Strict SAT1e-8/proper unchanged; topology is NOT a collision exemption','status':'UNACCEPTED; period dimensions reconstructed; anatomy/photo/gear/bit/motion pending'}

def audit(raw,ctx,proof):
 c=ctx['c'];old=c['model'];require(proof.get('candidate_sha256')==sha(raw),'Actual candidate hash');a,idx,detail=evaluate(ctx);require(proof['detail']==detail and proof['authority']==authority(ctx),'Exact fixed producer/proof authority');require(raw==serialize(ctx,a,idx),'Actual serialized document/attributes/indices equal intended recipe');new=Model(raw)
 require(set(new.views)==set(old.views),'No new mesh/material ownership');require(new.total==old.total-334+1080==13972,'Actual owner count')
 for key,v in old.views.items():
  w=new.views[key];require(w['material']==v['material'],'Material roles exact')
  if key not in[(1,0),(1,1)]:require(w['indices'].tobytes()==v['indices'].tobytes(),'Every unaffected index exact')
  for attr in ATTRS:
   require(w['attributes'][attr][:len(v['attributes'][attr])].tobytes()==v['attributes'][attr].tobytes(),'EVERY old attribute row exact:'+str(key)+attr)
 require(new.b[:len(old.b)]==old.b,'Original BIN prefix exact');require(new.d['accessors'][:len(old.d['accessors'])]==old.d['accessors']and new.d['bufferViews'][:len(old.d['bufferViews'])]==old.d['bufferViews'],'Original accessor/view metadata exact')
 require(len(new.d['accessors'])==len(old.d['accessors'])+6 and len(new.d['bufferViews'])==len(old.d['bufferViews'])+6,'Exactly4 attributes+2indices append')
 protected_old=copy.deepcopy(old.d);protected_new=copy.deepcopy(new.d)
 for doc in[protected_old,protected_new]:
  doc.pop('accessors');doc.pop('bufferViews');doc['buffers'][0].pop('byteLength')
  for key in[(1,0),(1,1)]:doc['meshes'][key[0]]['primitives'][key[1]].pop('attributes');doc['meshes'][key[0]]['primitives'][key[1]].pop('indices')
 require(protected_old==protected_new,'All other doc nodes/rig/materials/animations metadata exact')
 # Full decoded owner ledger across EVERY active triangle.
 remap={};owners={};labels={};head=set();scopes={k:set()for k in c['scopes']};scopes['lips']=set();retired=set(detail['retired_current_faces'])
 for key,v in old.views.items():
  pairs=[(oi,ni)for ni,oi in enumerate(detail['old_dark_keep'])]if key==(1,0)else[(i,i)for i in range(len(v['indices']))]
  for oi,ni in pairs:
   og=old.start[key]+oi;ng=new.start[key]+ni;require(og not in retired,'Retired face absent');remap[og]=ng;owners[ng]=c['owners'].get(og,{'kind':'retained_body','parent_global_face':og})
   require(v['indices'][oi].tobytes()==new.views[key]['indices'][ni].tobytes(),'Actual retained oriented triangle indexexact')
   if og in c['head']:head.add(ng)
   if str(og)in detail['preserved110_posterior']:scopes['lips'].add(ng)
   for name,cohort in c['scopes'].items():
    if og in cohort:scopes[name].add(ng)
 for key,v in new.views.items():
  for i in set(map(int,v['indices'].ravel())):labels[key[0],i]=detail['new_labels'].get(str(i),c['labels'].get((key[0],i),'body:'+str(key[0])+':'+str(i)))if key[0]==1 else c['labels'].get((key[0],i),'body:'+str(key[0])+':'+str(i))
 cursors={1:len(detail['old_dark_keep']),0:len(old.views[1,1]['indices'])}
 for row in detail['new_faces']:
  mat=row['material'];key=(1,0)if mat==1 else(1,1);ng=new.start[key]+cursors[mat];cursors[mat]+=1;require(new.views[key]['indices'][ng-new.start[key]].tolist()==row['indices'],'Actual newface indices match owner');owners[ng]={'kind':'conforming_mouth','assembly_face':row['assembly_face'],'source_owner':row['source_owner']};head.add(ng);scopes['lips'].add(ng)
 require(len(remap)==old.total-len(retired)and len(owners)==new.total and len(head)==3868,'Full active owner+head coverage');require(all(len(x)==len(set(x))for x in[head,*scopes.values()]),'Unique cohort members');new.source_face_owners=owners
 return new,labels,head,owners,scopes,{'PASS':True,'candidate_sha256':sha(raw),'old_to_new':{str(k):v for k,v in sorted(remap.items())},'source_face_owners':{str(k):v for k,v in sorted(owners.items())},'source_labels':[{'mesh':mi,'vertex':i,'label':v}for(mi,i),v in sorted(labels.items())],'actual_source_readback_scope':'All original attribute/storage/rig bytes exact; intended new attributes/index; no XYZ/collision acceptance','head_faces':len(head),'newlip_faces':len(scopes['lips'])}

def produce(path):
 out=Path(path);out.mkdir(parents=True,exist_ok=False);stage='load';receipt={'PASS':False,'status':'UNACCEPTED conforming mouth trial','stage':stage,'declared_input_pins':json.loads((P/'INPUTS.json').read_text()),'declared_source_pins':json.loads((P/'LOCAL-PINS.json').read_text())}
 try:
  ctx=load();receipt['parent_sha256']=sha(ctx['c']['raw']);stage='evaluate';a,idx,detail=evaluate(ctx);stage='encode';raw=serialize(ctx,a,idx);(out/'UNVALIDATED-candidate.glb').write_bytes(raw);proof={'candidate_sha256':sha(raw),'authority':authority(ctx),'detail':detail};stage='readback';*_,report=audit(raw,ctx,proof);(out/'candidate.glb').write_bytes(raw);(out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');(out/'readback.json').write_text(json.dumps(report,indent=2)+'\n');receipt.update(PASS=True,stage='source_readback_complete',candidate_sha256=sha(raw))
 except BaseException as e:receipt.update(stage=stage,error=repr(e));raise
 finally:(out/'FIRST-TRIAL-SOURCE.json').write_text(json.dumps(receipt,indent=2)+'\n')
 return receipt
if __name__=='__main__':print(json.dumps(produce(sys.argv[1])))
