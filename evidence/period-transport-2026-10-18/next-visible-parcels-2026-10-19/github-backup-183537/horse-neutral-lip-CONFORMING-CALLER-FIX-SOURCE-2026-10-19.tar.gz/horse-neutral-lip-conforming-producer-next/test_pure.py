"""Extract only numerical pure helpers; never import/evaluate horse producer."""
import ast,unittest
from fractions import Fraction as Q
from pathlib import Path
p=Path(__file__).parent/'conforming_variant.py';tree=ast.parse(p.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in['require','bary','smooth']];env={'Q':Q};exec(compile(ast.Module(body=nodes,type_ignores=[]),'purehelpers','exec'),env);bary=env['bary'];smooth=env['smooth']
class Pure(unittest.TestCase):
 def test_inside_exact(self):self.assertEqual(bary((Q(1,4),Q(1,4)),[(0,0),(1,0),(0,1)]),[Q(1,2),Q(1,4),Q(1,4)])
 def test_edge_exact(self):self.assertEqual(bary((Q(1,2),Q(1,2)),[(0,0),(1,0),(0,1)]),[0,Q(1,2),Q(1,2)])
 def test_reversed(self):self.assertEqual(bary((Q(1,4),Q(1,4)),[(0,0),(0,1),(1,0)]),[Q(1,2),Q(1,4),Q(1,4)])
 def test_outside_sign(self):self.assertLess(min(bary((2,2),[(0,0),(1,0),(0,1)])),0)
 def test_degenerate_refusal(self):
  with self.assertRaises(ValueError):bary((0,0),[(0,0),(1,0),(2,0)])
 def test_quintic_bounds(self):self.assertEqual([smooth(-1),smooth(0),smooth(1),smooth(2)],[0,0,1,1]);self.assertEqual(smooth(.5),.5)
 def test_no_horse_entry(self):self.assertEqual(set(env)-{'__builtins__','Q'},{'require','bary','smooth'})
if __name__=='__main__':unittest.main()
