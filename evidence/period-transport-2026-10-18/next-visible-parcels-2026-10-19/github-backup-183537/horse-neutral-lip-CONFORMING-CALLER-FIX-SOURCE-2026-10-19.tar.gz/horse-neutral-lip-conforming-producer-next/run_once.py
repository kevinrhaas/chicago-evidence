# SPDX-License-Identifier: CC0-1.0
"""One explicitly released fixed reconstruction; no retry/search/browser."""
import time
START=time.monotonic()
from pathlib import Path
import json,hashlib,subprocess,sys,os,signal
P=Path(__file__).parent

def main():
 if sys.argv[1:]!=['ROOT_RELEASE_ONE_CONFORMING_LIP_QUALITY']:raise ValueError('Independent executable review and explicit root release required')
 # Exclusive receipt claim occurs outside failure writer. Existing evidence
 # is never reused or modified, including concurrent/raced callers.
 with(P/'operator-receipt.json').open('x')as f:f.write('{}\n')
 r={'PASS':False,'status':'UNACCEPTED fixed conforming neutralmouth trial','bound_s':150,'stages':[],'phase':'pin_check','no_browser_motion_app':True}
 def save():r['elapsed_s']=time.monotonic()-START;(P/'operator-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
 try:
  for file in['LOCAL-PINS.json','EXTERNAL-HASHES.json']:
   pins=json.loads((P/file).read_text());r[file]=pins;save()
   for name,digest in pins.items():
    path=P/name if file=='LOCAL-PINS.json'else Path(name)
    if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:raise ValueError('Frozen source mismatch:'+name)
    if time.monotonic()-START>=150:raise TimeoutError('Total deadline during pins')
  stages=[('generate',[sys.executable,str(P/'conforming_variant.py'),str(P/'candidate-one')],30),('source_readback',[sys.executable,str(P/'checked_conforming.py')],30),('Khronos',['node',str(P/'khronos.cjs')],15),('actual_binary64_idle_capture',['node','--loader',str(P/'idle-fit/three-loader.mjs'),str(P/'idle-fit/capture_idle.mjs')],20),('full_structural',[sys.executable,str(P/'check_lip_idle.py')],75),('all36gear',[sys.executable,str(P/'idle-fit/check_idle.py')],90),('actual_bit_volume',[sys.executable,str(P/'check_actual_bit_volume.py')],30)]
  for name,cmd,cap in stages:
   remain=min(cap,150-(time.monotonic()-START))
   if remain<=0:raise TimeoutError('150s total deadline')
   r['phase']=name;save()
   with(P/(name+'.stdout')).open('xb')as out,(P/(name+'.stderr')).open('xb')as err:
    child=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True)
    try:code=child.wait(timeout=remain)
    except BaseException as exc:
     # The child owns a new session/process group. Reap it on every escape,
     # including operator interruption, before recording a failed trial.
     try:os.killpg(child.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     child.wait()
     if isinstance(exc,subprocess.TimeoutExpired):code=124
     else:raise
   r['stages'].append({'name':name,'exit':code,'elapsed_s':time.monotonic()-START});save()
   if code:raise RuntimeError('FIRSTFAIL '+name+' exit'+str(code))
  r.update(PASS=True,status='Fixed bounded idle engineering trial ONLY; visual/anatomy/photo/motion OPEN')
 except BaseException as e:r['error']=repr(e)
 finally:save()
 return 0 if r['PASS']else 2
if __name__=='__main__':raise SystemExit(main())
