"""Independent stored JSON/INDEX-only ownership/stencil/topology reconstruction.
Never decode P/N/J/W, import producer/Model/evaluator or evaluate proposed fields.
"""
from pathlib import Path
import json,hashlib,struct,collections,math
B=Path('/workspace/shared');P=B/'horse-native-muzzle-anatomy-correction-next';C=B/'horse-natural-labial-corner-three-primitives-next/candidate-one'
def need(v,m):
 if not v:raise ValueError(m)
def load(p):return json.loads(p.read_text())
A=load(P/'PROPOSED-INDEX-AND-STENCIL-PROOF.json');rb=load(C/'readback.json');raw=(C/'candidate.glb').read_bytes();need(hashlib.sha256(raw).hexdigest()==A['parent419a_sha256']==rb['candidate_sha256'],'source identity');n=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+n]);buf=raw[28+n:];labels={(x['mesh'],x['vertex']):x['label']for x in rb['source_labels']};records=[];primitives=[];owners={int(k):v for k,v in rb['source_face_owners'].items()}
for mi,m in enumerate(doc['meshes']):
 for pi,p in enumerate(m['primitives']):
  a=doc['accessors'][p['indices']];v=doc['bufferViews'][a['bufferView']];fmt={5123:'H',5125:'I'}[a['componentType']];off=v.get('byteOffset',0)+a.get('byteOffset',0);ids=struct.unpack_from('<'+fmt*a['count'],buf,off)
  for j in range(0,len(ids),3):records.append([labels[mi,i]for i in ids[j:j+3]]);primitives.append((mi,pi))
need(len(records)==13456,'all parent indexed faces')
# Independent full simplicial checks: unique triangles/opposite edges, all connected
# vertex links are cycles(interior)/paths(boundary), full face component.
def prove(faces,expectedB=None):
 E=collections.defaultdict(list);links=collections.defaultdict(list);V=set();need(len({tuple(sorted(t))for t in faces})==len(faces),'unique triangles')
 for fi,t in enumerate(faces):
  need(len(set(t))==3,'triangle distinct');V.update(t)
  for j in range(3):
   x,y,z=t[j],t[(j+1)%3],t[(j+2)%3];E[tuple(sorted((x,y)))].append((fi,x,y));links[x].append((y,z))
 for uses in E.values():need(len(uses)==1 or(len(uses)==2 and uses[0][1:]==uses[1][1:][::-1]),'opposite incidence')
 bd={e for e,u in E.items()if len(u)==1};bv={x for e in bd for x in e};faceAdj=collections.defaultdict(set)
 for uses in E.values():
  if len(uses)==2:a,b=[u[0]for u in uses];faceAdj[a].add(b);faceAdj[b].add(a)
 def connected(adj,seed):
  seen=set();todo=[seed]
  while todo:
   x=todo.pop()
   if x in seen:continue
   seen.add(x);todo.extend(adj[x]-seen)
  return seen
 need(len(connected(faceAdj,0))==len(faces),'one face component')
 for v,pairs in links.items():
  adj=collections.defaultdict(set)
  for a,b in pairs:adj[a].add(b);adj[b].add(a)
  need(connected(adj,next(iter(adj)))==set(adj),'connected vertex link');degrees=sorted(map(len,adj.values()));need(degrees==([1,1]+[2]*(len(adj)-2)if v in bv else[2]*len(adj)),'disk vertex link')
 if expectedB is not None:need(bd==expectedB,'same exact source boundary')
 return {'V':len(V),'E':len(E),'F':len(faces),'Euler':len(V)-len(E)+len(faces),'boundary':len(bd),'all_vertex_links':len(V),'connected':True,'directed_manifold':True},E,bd
native=load(B/'horse-oral-channel-diagonal-candidate/source/frozen-head.json');mouth={g for g,o in owners.items()if o['kind']=='natural_labial'};inside={g for g in mouth if owners[g]['source_owner']['kind']=='inner_labial_vestibule'};nostrils={g for g,o in owners.items()if o.get('tag')in {'nostril_1','nostril_-1','skin:nostril_1','skin:nostril_-1'}};front={g for g,o in owners.items()if o['kind']=='baseline_head'and o.get('tag')in {'skin','lip_l','lip_r'}and all(264<=i<=696 for i in native['faces'][o['source_head_face']])};ret=(mouth-inside)|nostrils|front;head={g for g,o in owners.items()if o['kind']in {'baseline_head','baseline_ear','natural_labial','radial_bridge','skull_complement'}};kept=head-ret
need((len(mouth-inside),len(nostrils),len(front),len(ret),len(inside),len(kept))==(573,288,507,1368,128,1984),'exact source semantic ownership');need(A['retirement']==sorted(ret)and A['preserved_head1984']==sorted(kept)and A['preserved_inner_vestibule128']==sorted(inside),'immutable ownership lists');routes=collections.Counter(primitives[g]for g in ret);need(routes=={(0,0):687,(1,0):96,(1,1):585},'all3 routes');old,E,bd=prove([records[g]for g in sorted(ret)]);need({tuple(e)for e in A['source_boundary112']}==bd,'112exactboundary');need(old['Euler']==-1 and old['boundary']==112,'oldpatch')
# Boundary loops derived from directed parent indices, not just expected counts.
nextV={}
for uses in E.values():
 if len(uses)==1:_,x,y=uses[0];need(x not in nextV,'simpleboundary');nextV[x]=y
loops=[];todo=set(nextV)
while todo:
 start=min(todo);x=start;loop=[]
 while True:
  need(x in todo,'simple oriented loop');todo.remove(x);loop.append(x);x=nextV[x]
  if x==start:break
 loops.append(loop)
need(sorted(map(len,loops))==[32,32,48],'three fixed loops')
N=collections.defaultdict(set)
for x,y in E:N[x].add(y);N[y].add(x)
allV=set(N);boundaryV={x for e in bd for x in e}
def nv(i):
 c={v for v in allV if v in ['h:'+str(i),'labial-native:'+str(i)]};need(len(c)==1,'unique native alias');return c.pop()
def shortest(start,end,side):
 allowed={v for v in N if v.startswith('labial:'+side+':')}|{end};queue=collections.deque([(start,)]);seen={start}
 while queue:
  q=queue.popleft()
  if q[-1]==end:return list(q)
  for v in sorted(N[q[-1]]&allowed):
   if v not in seen:seen.add(v);queue.append(q+(v,))
 raise ValueError('unreachable source corner')
path=shortest('labial:l:portal:28',nv(437),'l')+[nv(i)for i in [485,533,581,629,677]]+[nv(i)for i in range(678,692)]+[nv(i)for i in [643,595,547,499,451]]+list(reversed(shortest('labial:r:portal:4',nv(452),'r')));need(A['fixed_existing_lip_paths']==[path]and len(set(path))==len(path),'frozen simple source path');crease={tuple(sorted((x,y)))for x,y in zip(path,path[1:])};need(len(crease)==32 and crease<=set(E)and not crease&bd,'all32existingedges')
sharp=collections.defaultdict(set)
for x,y in crease:sharp[x].add(y);sharp[y].add(x)
even=lambda v:v if v in boundaryV else'muzzle:even:'+v
odd=lambda e:'muzzle:edge:'+e[0]+'|'+e[1]
weights={}
for v in sorted(N):
 if v in boundaryV or len(sharp[v])not in [0,2]:w={v:1.}
 elif len(sharp[v])==2:w={v:.75,**{u:.125 for u in sorted(sharp[v])}}
 else:
  n=len(N[v]);beta=(5/8-(3/8+math.cos(2*math.pi/n)/4)**2)/n;w={v:1-n*beta,**{u:beta for u in sorted(N[v])}}
 weights[even(v)]=w
for e,u in sorted(E.items()):
 if e in bd:continue
 if e in crease:w={e[0]:.5,e[1]:.5}
 else:
  w={e[0]:.375,e[1]:.375}
  for fi,_,_ in u:
   op=(set(records[sorted(ret)[fi]])-set(e)).pop();w[op]=w.get(op,0)+.125
 weights[odd(e)]=w
need(weights==A['stencils']and len(weights)==2735,'all reconstructed coefficient masks');need(all(min(w.values())>0 and all(math.isfinite(v)for v in w.values())and abs(math.fsum(w.values())-1)<5e-16 for w in weights.values()),'finite positive partitions');new=[];newowners=[]
for g in sorted(ret):
 tri=records[g];cuts=[tuple(sorted((tri[j],tri[(j+1)%3])))not in bd for j in range(3)];count=sum(cuts)
 if count==3:
  a,b,c=map(even,tri);ab,bc,ca=[odd(tuple(sorted((tri[j],tri[(j+1)%3]))))for j in range(3)];parts=[[a,ab,ca],[ab,b,bc],[ca,bc,c],[ab,bc,ca]]
 elif count==2:
  j=(cuts.index(False)+1)%3;x,y,z=tri[j:]+tri[:j];xy=odd(tuple(sorted((x,y))));yz=odd(tuple(sorted((y,z))));a,b,c=map(even,[x,y,z]);parts=[[b,yz,xy],[a,xy,yz],[a,yz,c]]
 elif count==1:
  j=cuts.index(True);x,y,z=tri[j:]+tri[:j];middle=odd(tuple(sorted((x,y))));a,b,c=map(even,[x,y,z]);parts=[[a,middle,c],[middle,b,c]]
 else:parts=[list(map(even,tri))]
 for f in parts:new.append(f);newowners.append({'kind':'source_constrained_muzzle','parent419a_face':g,'original_source_owner':owners[g],'material':1 if primitives[g]==(1,0)else 0})
need(new==A['proposed_faces']and newowners==A['proposed_face_owners'],'everygreen/red childface and original parent/materialowner');newtp,_,_=prove(new,bd);neck=['h:'+str(i)for i in [24,*range(13),36,*range(60,72),48]];ne={tuple(sorted((a,b)))for a,b in zip(neck,neck[1:]+neck[:1])};headtp,_,_=prove([records[g]for g in sorted(kept)]+new,ne);outer=['h:'+str(i)for i in range(264,312)];outeredges={tuple(sorted((a,b)))for a,b in zip(outer,outer[1:]+outer[:1])};mouthtp,_,_=prove([records[g]for g in sorted(inside)]+new,outeredges)
for actual,name in [(old,'old_patch_topology'),(newtp,'proposed_patch_topology'),(headtp,'proposed_full_head_topology'),(mouthtp,'proposed_complete_mouth_scope_topology')]:need({k:v for k,v in actual.items()if k!='all_vertex_links'}==A[name],'all complete topology '+name)
refined={tuple(sorted((even(v),odd(e))))for e in crease for v in e};need(refined=={tuple(e)for e in A['refined_lip_crease_edges']}and len(refined)==64,'refined64creaseedges');strength={v:0 if v.startswith('labial:')else 1 for v in path};need(strength==A['source_lip_path_groove_strength'],'exact source groove strength');rim={}
for r in native['records']:
 if r['kind']!='recess':continue
 sign=1 if r['name']=='nostril_1'else-1;aperture={nv(i)for i in r['aperture']}
 for x in aperture:need(x not in rim or rim[x]==sign,'rim side');rim[x]=sign
 for x in {v for u in aperture for v in N[u]}-aperture:need(x not in rim or rim[x]==sign/2,'rim skirt side');rim[x]=sign/2
need(rim==A['source_signed_nostril_rim_weights'],'all real semantic nostril rim weights');stations=load(B/'horse-oral-channel-diagonal-candidate/source/parameters.json')['head_surface_reconstruction_trial']['stations'];need(A['geometry_parameters']['native_stations']==stations and A['geometry_parameters']['anterior_lobe_start_z']==stations[7]['z']==.435 and A['geometry_parameters']['anterior_lobe_end_z']==stations[-1]['z']==.54,'original source scalar table');need({r['maximum_authored_depth_m']for r in native['records']if r['kind']=='continuous_closed_lip_groove'}=={A['geometry_parameters']['soft_tissue_depth_m']}=={.0025},'original authored depth')
r={'PASS':True,'scope':'Independent actual parent JSON/INDEX and original source semantic/scalar data only. No P/N/J/W decoded, no producer/Model/evaluator imports or proposed point evaluation.','parent_sha256':A['parent419a_sha256'],'retirement_parts':{'exterior_labial':573,'native_nostrils':288,'anterior_skin_residual_lip':507},'retired_routes':{str(k):v for k,v in routes.items()},'preserved_other_head':1984,'preserved_inner_vestibule':128,'boundary_loop_lengths':sorted(map(len,loops)),'old_patch':old,'new_patch':newtp,'full_head':headtp,'complete_mouth_scope':mouthtp,'all2735_stencils_reconstructed_exact':True,'each5360_child_face_parent_material_exact':True,'original_crease_edges':32,'refined_crease_edges':64,'source_rim_alias_count':len(rim),'source_rim_weight_counts':dict(collections.Counter(map(str,rim.values()))),'fixed_native_chin_down_amplitude_m':(stations[8]['top_y']-stations[8]['bottom_y'])/6,'fixed_forward_scale':.5,'fixed_original_groove_and_rim_depth_m':.0025,'all_seams_and_links_index_manifold':True,'model_faces':len(records)-len(ret)+len(new),'geometric_embedding_proved':False};out=B/'horse-native-muzzle-INDEPENDENT-INDEX-PROOF.json';out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
