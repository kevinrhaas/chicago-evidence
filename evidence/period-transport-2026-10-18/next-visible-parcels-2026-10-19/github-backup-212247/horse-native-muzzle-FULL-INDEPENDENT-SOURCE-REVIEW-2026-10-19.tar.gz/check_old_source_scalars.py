"""Decode ONLY immutable419a old attributes for field admissibility premises.
No proposed field called, no proposed XYZ/N/JW generated, no Model import.
"""
from pathlib import Path
import json,struct,collections,math,hashlib
B=Path('/workspace/shared');P=B/'horse-native-muzzle-anatomy-correction-next';C=B/'horse-natural-labial-corner-three-primitives-next/candidate-one';A=json.loads((P/'PROPOSED-INDEX-AND-STENCIL-PROOF.json').read_text());rb=json.loads((C/'readback.json').read_text());raw=(C/'candidate.glb').read_bytes();n=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+n]);buf=raw[28+n:];labels={(x['mesh'],x['vertex']):x['label']for x in rb['source_labels']};source=collections.defaultdict(list);descriptors=[]
def need(v,m):
 if not v:raise ValueError(m)
def acc(index):
 a=doc['accessors'][index];view=doc['bufferViews'][a['bufferView']];fmt,size={5123:('H',2),5125:('I',4),5126:('f',4)}[a['componentType']];width={'SCALAR':1,'VEC3':3,'VEC4':4}[a['type']];off=view.get('byteOffset',0)+a.get('byteOffset',0);stride=view.get('byteStride',width*size);return[(struct.unpack_from('<'+fmt*width,buf,off+i*stride),bytes(buf[off+i*stride:off+i*stride+width*size]))for i in range(a['count'])]
for mi,m in enumerate(doc['meshes']):
 for pi,p in enumerate(m['primitives']):
  ids=[x[0][0]for x in acc(p['indices'])];attrs={k:acc(p['attributes'][k])for k in ['POSITION','NORMAL','JOINTS_0','WEIGHTS_0']}
  for i in sorted(set(ids)):
   tag=labels[mi,i];source[tag].append({'mesh':mi,'primitive':pi,'vertex':i,'material':p.get('material'),'attrs':{k:v[i]for k,v in attrs.items()}})
  for j in range(0,len(ids),3):descriptors.append([(labels[mi,i],next(r for r in source[labels[mi,i]]if(r['mesh'],r['primitive'],r['vertex'])==(mi,pi,i)))for i in ids[j:j+3]])
basis={v for w in A['stencils'].values()for v in w};boundary={v for e in A['source_boundary112']for v in e};chosen={}
for g in A['retirement']:
 for tag,r in descriptors[g]:
  if tag in boundary:chosen.setdefault(tag,r)
need(set(chosen)==boundary and len(basis)==739,'full oldbasis/boundary');params=A['geometry_parameters'];stations=params['native_stations'];origin=params['frame_origin'];bounds=[]
for tag in sorted(basis):
 rr=source[tag];need(rr,'source alias exists')
 for k in ['POSITION','JOINTS_0','WEIGHTS_0']:need(len({r['attrs'][k][1]for r in rr})==1,'all old source alias P/JW exact '+tag)
 p=rr[0]['attrs']['POSITION'][0];z=p[2]-origin[2]
 if z<=params['anterior_lobe_start_z']:continue
 need(z<=params['anterior_lobe_end_z']+1e-6,'source z admissible');zq=min(z,params['anterior_lobe_end_z']);pair=next((a,b)for a,b in zip(stations,stations[1:])if a['z']<=zq<=b['z']);a,b=pair;f=(zq-a['z'])/(b['z']-a['z']);top=(1-f)*a['top_y']+f*b['top_y'];bottom=(1-f)*a['bottom_y']+f*b['bottom_y'];radius=(top-bottom)/2;lower=max(0,-((p[1]-origin[1])-(top+bottom)/2)/radius)**2;t=(zq-params['anterior_lobe_start_z'])/(params['anterior_lobe_end_z']-params['anterior_lobe_start_z']);need(radius>0 and math.isfinite(lower)and lower<=1.0001 and 0<=t<=1,'old section/parameter premises');bounds.append((z,lower,t,radius))
variants=collections.Counter(len({r['attrs']['NORMAL'][1]for r in source[v]})for v in boundary);materials=collections.Counter(chosen[v]['material']for v in boundary);r={'PASS':True,'scope':'ONLY immutable old419a POSITION/NORMAL/JW and native scalar station data read. Original field admissibility premises checked without calling chin_field/fields/evaluate or emitting proposed positions/normals/JW.','basis_aliases':len(basis),'all_old_PJW_aliases_bit_exact':True,'boundary_aliases':len(boundary),'selected_parent_retiring_boundary_normals_material_counts':dict(materials),'old_boundary_normal_variant_counts':dict(variants),'anterior_existing_source_alias_count':len(bounds),'maximum_original_source_local_z':max(x[0]for x in bounds),'maximum_original_normalized_lower_section_squared':max(x[1]for x in bounds),'minimum_native_section_radius':min(x[3]for x in bounds),'all_old_source_chin_admissibility_conditions_pass':True,'no_proposed_field_or_geometry_evaluated':True};out=B/'horse-native-muzzle-INDEPENDENT-OLD-SOURCE-PREMISES.json';out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
