#!/usr/bin/env python3
"""Fixed once-only qualification; source review required before invocation."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,time

BASE=Path('/workspace/shared')
SRC=BASE/'riding-saddle-stirrup-central-fold-source-next'
OUT=BASE/'riding-saddle-stirrup-central-fold-actual-one'
PY='/workspace/shared/chicago-venv/bin/python'
GEAR=BASE/'riding-rein-skin-next/candidate-v2.glb'
HORSE=BASE/'riding-gear-1835-next/horse-input/equine_light_harness_skinned_prototype_01.glb'
MANIFEST=BASE/'riding-gear-1835-next/horse-input/manifest.json'
CONTROL=BASE/'riding-saddle-shared-layers-actual-one/candidate/candidate.glb'
OLD=BASE/'riding-saddle-periodic-girth-actual-one/candidate/candidate.glb'
OLD_STIRRUP=BASE/'riding-saddle-underbelly-bisector-actual-one/candidate/candidate.glb'
OLD_FRAME=BASE/'riding-saddle-stirrup-notch-actual-one/candidate/candidate.glb'
OLD_BRANCH=BASE/'riding-saddle-stirrup-frame-actual-one/candidate/candidate.glb'
OLD_LOWER=BASE/'riding-saddle-stirrup-stations-owned-actual-one/candidate/candidate.glb'
OLD_ROOT=BASE/'riding-saddle-stirrup-paired-lower-actual-one/candidate/candidate.glb'
OLD_IRON=BASE/'riding-saddle-stirrup-root-peel-negative-fixed-actual-one/candidate/candidate.glb'
SOURCE_SHA='497b89f994130d0bc68d5cd94679f154dc98677cbdf57bec10fc2f3b682870f9'
PINS={GEAR:'a457874a81b624f5e9642d3296b1350eb49b17d21d38099fbe66080711c17021',HORSE:'6e9b37b755ae3eda7b5cf2f492d1781b0e507664a99c88a2e6dee086f77c2296',MANIFEST:'f2b4710e2d65037ad84dd059c21d1bfb3ae6f1f751b9c794931dc73397d6d094',CONTROL:'50463c358935677ce0413ae58006dba9df1cfadf21b477df18492042bd1683b5',OLD:'8ce7793bf776df7a1632202b849a41b06ef34ddeacfcae76c92891432d3ca7bc'}
PINS[OLD_STIRRUP]='83f7b0b927c316ec2efb360178cace360351f1e04a1431d240599ae9cc8682bd'
PINS[OLD_FRAME]='ae0b84fca50d135dbd0d54c002fb054759c4ea9ae2ccb41595197d7feb545858'
PINS[OLD_BRANCH]='f644710ddd19a1be3deee594278bde550b744ea2d2c013e4388c2586145bb8b6'
PINS[OLD_LOWER]='8f32793bf14cd9a379ca699ed8144e6bb14b77873c14c37a2732e75497697786'
PINS[OLD_ROOT]='6cb6addf7cc11ac18a12d7786b082574c70ad5ea988cfaa60a9537a6e299302c'
PINS[OLD_IRON]='ff905feec5c07978b700fa87cd2dd0015fb6b3a0f253d4bbb2b4eb3bf27d1e6d'
VALIDATOR=BASE/'riding-saddle-underbelly-bisector-validator.cjs'
VALIDATOR_SHA='584230a2d1a5dab6367a26e9af91c26399af4677a2a8a90349f43588213c0cec'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(ok,message):
 if not ok:raise ValueError(message)

def wait_owned(p,timeout,stage):
 try:return p.wait(timeout=timeout)
 except BaseException as error:
  # Every interrupted stage must stop/reap its owned group before returning.
  try:os.killpg(p.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:p.wait(timeout=3)
  except subprocess.TimeoutExpired:
   try:os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   p.wait()
  stage['interruption']=repr(error)
  stage['timed_out']=isinstance(error,subprocess.TimeoutExpired)
  stage['exit_code']=p.returncode
  raise

def main():
 OUT.mkdir() # An existing attempt, successful or failed, must never be reused.
 started=time.monotonic();deadline=started+1800
 receipt={'passed':False,'scope':'One fixed actual idle qualification; no browser, motion, pressure, rider or photographic acceptance','source_manifest_sha256':SOURCE_SHA,'expected_scope':{'gear_self':29,'affected_parts':18,'closed_solid_obligations':16,'amended_inherited_open_irons':2,'interpart_pairs':351,'horse_triangles_per_affected_part':14172},'stages':[]}
 def save():
  receipt['elapsed_s']=time.monotonic()-started
  (OUT/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n')
 def run(name,args,limit):
  remaining=deadline-time.monotonic();need(remaining>0,'Overall 1800 second bound')
  stage={'name':name,'argv':list(map(str,args)),'timeout_s':min(limit,remaining),'started_elapsed_s':time.monotonic()-started}
  receipt['stages'].append(stage);save()
  with (OUT/(name+'.stdout')).open('xb')as stdout,(OUT/(name+'.stderr')).open('xb')as stderr:
   p=subprocess.Popen(list(map(str,args)),stdout=stdout,stderr=stderr,stdin=subprocess.DEVNULL,start_new_session=True,env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'})
   stage['pid']=p.pid;save()
   try:stage['exit_code']=wait_owned(p,min(limit,remaining),stage)
   finally:save()
  stage['finished_elapsed_s']=time.monotonic()-started;save();need(stage['exit_code']==0,'FIRST actual stage failure: '+name)
 try:
  cpu=min(os.sched_getaffinity(0));os.sched_setaffinity(0,{cpu});receipt['single_cpu']=cpu
  need(sha(SRC/'SOURCE-HASHES.json')==SOURCE_SHA,'Exact reviewed source inventory')
  for relative,digest in json.loads((SRC/'SOURCE-HASHES.json').read_text()).items():need(sha(SRC/relative)==digest,'Source pin '+relative)
  need(sha(VALIDATOR)==VALIDATOR_SHA,'Exact reviewed external validator caller')
  for path,digest in json.loads((SRC/'external-vendor-pins.json').read_text()).items():need(sha(Path(path))==digest,'External unchanged vendor pin '+path)
  for path,digest in PINS.items():need(sha(path)==digest,'Input pin '+str(path))
  receipt['input_pins']={str(k):v for k,v in PINS.items()};save()
  run('closure-negative',[PY,SRC/'check_girth_negative.py',GEAR,OUT/'original-closure-negative'],30)
  run('panel-negative',[PY,SRC/'check_panel_girth_negative.py',OLD,SRC/'old-panel-girth-negative.json',OUT/'original-panel-negative'],30)
  run('stirrup-negatives',[PY,SRC/'check_stirrup_negatives.py',OLD_STIRRUP,SRC/'old-stirrup-crossing-negative.json',OUT/'original-stirrup-negative'],30)
  run('old-frame-negative',[PY,SRC/'check_old_frame_negative.py',OLD_FRAME,OUT/'original-frame-negative'],30)
  run('old-branch-negative',[PY,SRC/'check_old_branch_negative.py',OLD_BRANCH,SRC/'old-branch-crossing-negative.json',OUT/'original-branch-negative'],30)
  run('old-lower-negative',[PY,SRC/'check_old_lower_negative.py',OLD_LOWER,SRC/'old-lower-crossing-negative.json',OUT/'original-lower-negative'],30)
  run('old-root-negatives',[PY,SRC/'check_old_root_negatives.py',OLD_ROOT,SRC/'old-root-crossing-negatives.json',OUT/'original-root-negatives'],30)
  run('old-iron-negatives',[PY,SRC/'check_old_iron_negatives.py',OLD_IRON,SRC/'old-iron-crossing-negatives.json',OUT/'original-iron-negatives'],30)
  run('build',[PY,SRC/'build_candidate.py','--gear-input',GEAR,'--horse-input',HORSE,'--horse-manifest',MANIFEST,'--parameters',SRC/'saddle_sections.json','--layer-control',CONTROL,'--output-dir',OUT/'candidate'],30)
  candidate=OUT/'candidate/candidate.glb';digest=sha(candidate);receipt['candidate_sha256']=digest;save()
  run('readback',[PY,SRC/'check_actual.py',GEAR,candidate,SRC/'saddle_sections.json',CONTROL,OLD_BRANCH,OLD_IRON,OUT/'readback'],60)
  run('khronos',['node',VALIDATOR,candidate,OUT/'khronos.json'],60)
  run('capture',['node','--experimental-loader',SRC/'idle-fit-source/three-loader.mjs',SRC/'idle-fit-source/capture_idle.mjs',HORSE,GEAR,candidate,OUT/'capture',digest],60)
  run('self',[PY,SRC/'check_self.py',OUT/'capture',candidate,OUT/'self',digest],900)
  run('assembly',[PY,SRC/'check_assembly.py',OUT/'capture',candidate,OUT/'self/self.json',OUT/'readback/validated-interfaces.json',OUT/'fit',digest],900)
  receipt['passed']=True;save()
 except BaseException as error:receipt['error']=repr(error);save();raise
 finally:save()

if __name__=='__main__':main()
