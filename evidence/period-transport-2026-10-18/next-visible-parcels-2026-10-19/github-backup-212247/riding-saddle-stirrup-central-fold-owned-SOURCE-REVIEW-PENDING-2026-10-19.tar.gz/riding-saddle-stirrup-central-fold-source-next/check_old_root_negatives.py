# SPDX-License-Identifier: GPL-3.0-or-later
"""Reproduce all eight captured bilateral6cb6 billet/root proper crossings."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
from check_actual import load,array,need
from official_fit_predicates import sat,proper

def run(old,fixture,out):
 out.mkdir();r={'passed':False,'scope':'All eight exact old6cb6 billet/return-root negative witnesses; no replacement evaluation','pairs':{}}
 try:
  d,binary,raw=load(old);digest=hashlib.sha256(raw).hexdigest();need(digest=='6cb6addf7cc11ac18a12d7786b082574c70ad5ea988cfaa60a9537a6e299302c','Exact immutable previous actual model');packet=json.loads(fixture.read_text());need(packet['candidate_sha256']==digest,'Fixture identity')
  def triangles(name):
   pr=next(m for m in d['meshes']if m['name']==name)['primitives'][0];P=array(d,binary,pr['attributes']['POSITION']).astype(float);F=array(d,binary,pr['indices']).reshape(-1,3);return P[F]
  for side in('l','r'):
   A=triangles('billet_'+side);B=triangles('stirrup_leather_'+side);rows=[];saved=packet['pairs'][side]['witnesses'];need(len(saved)==4 and {(q['a_face'],q['b_face'])for q in saved}=={(252,1600),(252,1603),(369,1600),(369,1603)},'Exact four actual root witnesses per side')
   for q in saved:
    triangle_a=A[q['a_face']];triangle_b=B[q['b_face']];need(np.array_equal(triangle_a,np.asarray(q['actual_coordinates'][0]))and np.array_equal(triangle_b,np.asarray(q['actual_coordinates'][1])),'Exact saved source/capture triangle binding');w=proper(triangle_a,triangle_b);need(sat(triangle_a,triangle_b)and w is not None,'Old root strict proper crossing must reproduce');rows.append({'a_face':q['a_face'],'b_face':q['b_face'],'proper':w})
   r['pairs'][side]=rows
  r.update(passed=True,input_sha256=digest,strict_proper_witnesses=8)
 except BaseException as e:r['error']=repr(e);raise
 finally:(out/'old-root-negatives.json').write_text(json.dumps(r,indent=2)+'\n')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('old',type=Path);p.add_argument('fixture',type=Path);p.add_argument('out',type=Path);a=p.parse_args();run(a.old,a.fixture,a.out)
