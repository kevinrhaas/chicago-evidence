# SPDX-License-Identifier: CC0-1.0
"""Exact dyadic synthetic cells; no actual model input or trial."""
import json
from frame_orientation import strip_guard,need

def ring(center,width,thickness):
 a=[center[k]-width[k]/2 for k in range(3)];b=[center[k]+width[k]/2 for k in range(3)]
 return[a,b,[b[k]+thickness[k]for k in range(3)],[a[k]+thickness[k]for k in range(3)]]
def expect(name,points,side,passed):
 error=None
 try:r=strip_guard(points,side)
 except ValueError as e:error=str(e)
 need((error is None)==passed,'Expected synthetic frame outcome '+name)
 return{'name':name,'expected_PASS':passed,'observed_PASS':error is None,'error':error,'scope':'Pure dyadic synthetic cell'}
def run():
 rows=[]
 # A lower underside fold moves+Z, with outward material toward-Y. The
 # immutable right bar order is-X; the corrected left order must be+X.
 for side,w in[('r',[-.05,0,0]),('l',[.05,0,0])]:
  a=ring([0,0,0],w,[0,-.004,0]);b=ring([0,0,.004],w,[0,-.004,0]);rows.append(expect(side+'_correct_fold',a+b,side,True));rows.append(expect(side+'_inverted_width_refuses',[[*q]for q in[a[i]for i in(1,0,3,2)]]+[[*q]for q in[b[i]for i in(1,0,3,2)]],side,False))
 # A terminal half twist has a zero/negative full-cell determinant and cannot
 # be certified merely because either endpoint frame is separately regular.
 a=ring([0,0,0],[.05,0,0],[0,-.004,0]);b=ring([0,0,.004],[-.05,0,0],[0,.004,0]);rows.append(expect('interior_half_twist_refuses',a+b,'l',False))
 print(json.dumps({'passed':True,'scope':'Synthetic exact frame proof and inversion refusals only; no actual geometry','rows':rows},indent=2))

if __name__=='__main__':run()
