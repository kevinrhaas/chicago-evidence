HISTORICAL PRIOR-SOURCE DESIGN. The current central-fold scope is defined in CENTRAL-FOLD-DESIGN.md; old fullwidth anchor/fold protection claims below do not apply to the amended fold/iron streams.

# Negative-control decoder state fix

The original56816891 single attempt stopped before build: four oldleft6cb6 proper witnesses reproduced, then the right decoder saw a72-byte triangle because its captured BIN variableb had been overwritten by localtriangleb. That complete failed attempt remains immutable at root-peel-actual-one and in ee5413b8 capsule. No newcandidate or support evaluation occurred.

The only executable source change is distinct immutable binary and local triangle_a/triangle_b names inside check_old_root_negatives.py. Geometry/predicates/readback/normal amendment/coverage/fixtures/sourceownedinterfaces remain byteexact to56816891. Real input SHA6cb6 and exact all8 bilateral witness coordinates/face pairs remain enforced, with unchanged SAT/proper. Caller only changes source path/hash and a fresh exclusive output path; all10 input pins/7negatives/bounds/cleanup/fullphysical gates are unchanged.

New source-only regression runs the actual helperrun() and actualarray decoder on packed synthetic mesh buffers for all four left/right source meshes and all8 bilateral witnesses, with original SAT/proper. Only assetloading and identityhash are mocked for synthetic data; production pin enforcement is unchanged. The test was run against the unfixed helper and reproduced the right-side72byte buffer failure after left witnesses. Fixed helper passes normal andpython-O. No actual asset or replacement model was evaluated for the regression. Prior58 geometry/source controls remain backed by unchanged sources and review860ea69c.

Root explicitly authorizes this ordinary helper correction, independent source-delta/negative review, then exactly one fresh <=1800sCPU1/maththreads1 attempt. No extra permission round, no retry of any existing output, and no geometry/threshold/contact waiver is authorized. No browser/motion/app/photo acceptance.
