# SPDX-License-Identifier: CC0-1.0
"""Exact dyadic trilinear-cell Jacobian bounds, not a mesh embedding proof."""
from fractions import Fraction
from itertools import product,permutations
from math import comb

def need(q,m):
 if not q:raise ValueError(m)
def mul(a,b):
 out={}
 for i,x in a.items():
  for j,y in b.items():
   k=tuple(u+v for u,v in zip(i,j));out[k]=out.get(k,Fraction(0))+x*y
 return {k:v for k,v in out.items()if v}
def component_derivative(coeff,axis,component):
 return {tuple(x-int(k==axis)for k,x in enumerate(i)):v[component]for i,v in coeff.items()if i[axis]}
def bernstein_bounds(ring_a,ring_b,expected_sign):
 need(expected_sign in(-1,1),'Explicit source orientation sign')
 # Actual serialized float32 values are supplied by caller/readback. Fraction
 # converts their binary values exactly; no epsilon is used for this proof.
 corners={}
 for u,ring in enumerate((ring_a,ring_b)):
  for v,w,index in[(0,0,0),(1,0,1),(1,1,2),(0,1,3)]:corners[(u,v,w)]=tuple(Fraction(float(x))for x in ring[index])
 coeff={}
 for index in product(range(2),repeat=3):
  q=[Fraction(0)]*3
  for subindex in product(*(range(i+1)for i in index)):
   sign=(-1)**(sum(index)-sum(subindex))
   for k in range(3):q[k]+=sign*corners[subindex][k]
  coeff[index]=tuple(q)
 jac={}
 for perm in permutations(range(3)):
  parity=(-1)**sum(perm[i]>perm[j]for i in range(3)for j in range(i+1,3))
  term={(0,0,0):Fraction(parity)}
  for axis,component in enumerate(perm):term=mul(term,component_derivative(coeff,axis,component))
  for k,v in term.items():jac[k]=jac.get(k,Fraction(0))+v
 need(all(all(i<=2 for i in k)for k in jac),'Jacobian degree at most2 per coordinate')
 bernstein=[]
 for index in product(range(3),repeat=3):
  value=Fraction(0)
  for powers,coefficient in jac.items():
   if any(a>b for a,b in zip(powers,index)):continue
   weight=Fraction(1)
   for i,j in zip(index,powers):weight*=Fraction(comb(i,j),comb(2,j))
   value+=coefficient*weight
  bernstein.append(value*expected_sign)
 need(all(x>0 for x in bernstein),'Every exact full-cell Jacobian Bernstein coefficient must have the declared material-frame sign')
 return {'minimum_exact_signed_Bernstein':str(min(bernstein)),'maximum_exact_signed_Bernstein':str(max(bernstein)),'coefficients':27,'continuous_trilinear_cell_orientation_proved':True,'planar_mesh_embedding_proved':False}

def strip_guard(points,side):
 need(side in('l','r')and len(points)>=8 and len(points)%4==0,'Explicit strip ring ownership')
 sign=-1 if side=='l'else 1;rows=[]
 for j in range(len(points)//4-1):
  try:row=bernstein_bounds(points[4*j:4*j+4],points[4*j+4:4*j+8],sign)
  except ValueError as error:raise ValueError('Material frame inversion or unproved cell '+side+'/'+str(j)+': '+str(error))from error
  rows.append(row)
 return {'passed':True,'scope':'All exact serialized trilinear-cell Jacobians have fixed source material-frame sign; actual full planar-triangle self/interpart guards remain mandatory','side':side,'expected_sign':sign,'cells':len(rows),'rows':rows}
