# SPDX-License-Identifier: GPL-3.0-or-later
"""Actual original A457 closure negative. No cached green result is consumed."""
from pathlib import Path
import argparse,json,hashlib,numpy as np
from check_actual import load,array,need
from official_fit_predicates import sat,proper

def run(old,out):
 out.mkdir();r={'passed':False,'scope':'Pinned original girth faces0/760 strict proper closure negative only'}
 try:
  d,b,raw=load(old);need(hashlib.sha256(raw).hexdigest()=='a457874a81b624f5e9642d3296b1350eb49b17d21d38099fbe66080711c17021','Exact original A457')
  mesh=next(m for m in d['meshes']if m['name']=='riding_girth');pr=mesh['primitives'][0];need('indices'not in pr,'Original expanded girth');P=array(d,b,pr['attributes']['POSITION']).astype(float);need(hashlib.sha256(P.astype('<f4').tobytes()).hexdigest()=='ab552780b1379c9ba467dcb0a7cdf5e5b8cdf4a4a15f82cfcf2e26e5c49f0e45','Actual original girth positions')
  a=P[0:3];bb=P[760*3:761*3];witness=proper(a,bb);need(sat(a,bb)and witness is not None,'Original actual strictproper failure must reproduce')
  r.update(passed=True,source_faces=[0,760],actual_coordinates=[a.tolist(),bb.tolist()],proper=witness,input_sha256=hashlib.sha256(raw).hexdigest())
 except BaseException as e:r['error']=repr(e);raise
 finally:(out/'girth-negative.json').write_text(json.dumps(r,indent=2)+'\n')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('old',type=Path);p.add_argument('out',type=Path);a=p.parse_args();run(a.old,a.out)
