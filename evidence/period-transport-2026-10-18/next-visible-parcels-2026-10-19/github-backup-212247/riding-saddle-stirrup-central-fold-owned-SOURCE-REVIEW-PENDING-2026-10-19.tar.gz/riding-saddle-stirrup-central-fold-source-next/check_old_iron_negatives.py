# SPDX-License-Identifier: GPL-3.0-or-later
"""All sixty actual fullwidth-fold/neighboring-arch strict proper negatives."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
from check_actual import load,array,need
from official_fit_predicates import sat,proper
DIGEST='ff905feec5c07978b700fa87cd2dd0015fb6b3a0f253d4bbb2b4eb3bf27d1e6d'
def run(old,fixture,out):
 out.mkdir();r={'passed':False,'scope':'All60 actual old fullwidth-fold strict proper witnesses only; no new geometry evaluation','pairs':{}}
 try:
  d,binary,raw=load(old);need(hashlib.sha256(raw).hexdigest()==DIGEST,'Exact immutable fullwidth failure model');packet=json.loads(fixture.read_text());need(packet['candidate_sha256']==DIGEST,'Fixture identity')
  def triangles(name):
   pr=next(m for m in d['meshes']if m['name']==name)['primitives'][0];P=array(d,binary,pr['attributes']['POSITION']).astype(float);F=array(d,binary,pr['indices']).reshape(-1,3)if'indices'in pr else np.arange(len(P)).reshape(-1,3);return P[F]
  for side in('l','r'):
   A=triangles('stirrup_leather_'+side);B=triangles('stirrup_'+side);saved=packet['pairs'][side]['witnesses'];need(len(saved)==30 and len({(q['leather_face'],q['iron_face'])for q in saved})==30,'All30 distinct saved proper pairs per side');rows=[]
   for q in saved:
    triangle_a=A[q['leather_face']];triangle_b=B[q['iron_face']];need(np.array_equal(triangle_a,np.asarray(q['actual_coordinates'][0]))and np.array_equal(triangle_b,np.asarray(q['actual_coordinates'][1])),'Actual saved source/capture coordinates');w=proper(triangle_a,triangle_b);need(sat(triangle_a,triangle_b)and w is not None,'Every historical strict proper remains fatal');rows.append({'leather_face':q['leather_face'],'iron_face':q['iron_face'],'proper':w})
   r['pairs'][side]=rows
  r.update(passed=True,input_sha256=DIGEST,strict_proper_witnesses=60)
 except BaseException as e:r['error']=repr(e);raise
 finally:(out/'old-iron-negatives.json').write_text(json.dumps(r,indent=2)+'\n')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('old',type=Path);p.add_argument('fixture',type=Path);p.add_argument('out',type=Path);a=p.parse_args();run(a.old,a.fixture,a.out)
