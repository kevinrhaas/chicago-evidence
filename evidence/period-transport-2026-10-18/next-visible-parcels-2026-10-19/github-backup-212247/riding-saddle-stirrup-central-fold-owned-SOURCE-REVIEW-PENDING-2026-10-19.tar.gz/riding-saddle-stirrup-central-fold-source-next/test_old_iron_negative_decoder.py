# SPDX-License-Identifier: CC0-1.0
"""Source-only bilateral60-witness regression through real array/SAT/proper."""
from pathlib import Path
import json,struct,tempfile,types
import check_old_iron_negatives as helper

def main():
 source=json.loads(Path(__file__).with_name('old-iron-crossing-negatives.json').read_text());d={'accessors':[],'bufferViews':[],'meshes':[]};binary=bytearray();pairs={}
 a=[[0.,0.,0.],[1.,0.,0.],[0.,1.,0.]];b=[[.25,.25,-1.],[.25,.25,1.],[.5,.25,1.]]
 def append(rows,component,kind):
  flat=[v for row in rows for v in row];offset=len(binary);fmt='f'if component==5126 else'I';binary.extend(struct.pack('<'+fmt*len(flat),*flat));view=len(d['bufferViews']);d['bufferViews'].append({'byteOffset':offset,'byteLength':len(binary)-offset});index=len(d['accessors']);d['accessors'].append({'bufferView':view,'componentType':component,'count':len(rows),'type':kind});return index
 for side in('l','r'):
  saved=source['pairs'][side]['witnesses'];pairs[side]={'witnesses':[{'leather_face':q['leather_face'],'iron_face':q['iron_face'],'actual_coordinates':[a,b]}for q in saved]}
  for part,triangle,count in(('stirrup_leather',a,1+max(q['leather_face']for q in saved)),('stirrup',b,1+max(q['iron_face']for q in saved))):
   pos=append(triangle,5126,'VEC3');ix=append([[k]for _ in range(count)for k in(0,1,2)],5125,'SCALAR');d['meshes'].append({'name':part+'_'+side,'primitives':[{'attributes':{'POSITION':pos},'indices':ix}]})
 original_load,original_hash=helper.load,helper.hashlib
 try:
  helper.load=lambda _: (d,bytes(binary),b'synthetic60-witness-identity');helper.hashlib=types.SimpleNamespace(sha256=lambda _:types.SimpleNamespace(hexdigest=lambda:helper.DIGEST))
  with tempfile.TemporaryDirectory(prefix='central-iron-negative-decoder-')as name:
   root=Path(name);fixture=root/'fixture.json';fixture.write_text(json.dumps({'candidate_sha256':helper.DIGEST,'pairs':pairs}));helper.run(root/'unused',fixture,root/'out');r=json.loads((root/'out/old-iron-negatives.json').read_text());
   if not(r['passed']and r['strict_proper_witnesses']==60 and len(r['pairs']['l'])==len(r['pairs']['r'])==30):raise ValueError('All60 bilateral decoder/strict witnesses mandatory')
 finally:helper.load,helper.hashlib=original_load,original_hash
 print(json.dumps({'passed':True,'scope':'Synthetic buffers/source fixtureface ids, real array/run/SAT/proper; no actual asset/model','sides':2,'strict_proper_witnesses':60,'synthetic_loading_hash_only_mocked':True}))
if __name__=='__main__':main()
