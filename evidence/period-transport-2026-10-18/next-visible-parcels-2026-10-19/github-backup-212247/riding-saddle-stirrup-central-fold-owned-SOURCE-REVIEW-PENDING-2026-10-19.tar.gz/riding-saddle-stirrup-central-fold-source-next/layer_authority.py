# SPDX-License-Identifier: CC0-1.0
"""Original common radial section construction. SOURCE ONLY, not evaluated.
Every radius is derived in metre/Y-up/+Z gear root coordinates. Body queries
must come from the pinned retained source; actual triangle guards remain mandatory.
No import-time geometry or IO. No historical pattern/dimension is asserted.
"""
import math
from topology import shell

CHANGED = frozenset(('panel_l','panel_r','tree_sidebar_l','tree_sidebar_r',
                     'front_bow','rear_bow','seat_jockey','jockey_l','jockey_r',
                     'quarter_l','quarter_r'))

def need(ok, message):
    if not ok: raise ValueError(message)

def smooth(t):
    t=max(0.,min(1.,t)); return t*t*(3.-2.*t)

def validate(p):
    need(p['schema']=='original_saddle_layers_v1','Explicit section recipe schema')
    keys=('axis_y_m','body_standoff_m','panel_thickness_m','panel_edge_thickness_m',
          'wood_thickness_m','layer_gap_m','leather_thickness_m','outer_clearance_m',
          'seat_padding_m','bow_width_m','bow_rise_m','seam_arc_gap_m','quarter_end_inset_m','quarter_body_offset_m')
    for k in keys:
        need(type(p[k]) in (int,float) and math.isfinite(p[k]) and 0<p[k]<2,'Finite positive '+k)
    need(.0005<=p['layer_gap_m']<=.003,'Declared visual layer gap bound')
    need(p['outer_clearance_m']>=p['layer_gap_m'],'Outer clearance covers layer gap')
    need(p['panel_thickness_m']>p['panel_edge_thickness_m'],'Rounded taper panel thickness')
    need(len(p['z_stations_m'])>=9 and all(type(x) in (int,float) and math.isfinite(x) for x in p['z_stations_m']),'Finite station list')
    need(all(a<b for a,b in zip(p['z_stations_m'],p['z_stations_m'][1:])),'Increasing station ownership')
    need(len(p['crown_rise_m'])==len(p['z_stations_m']) and all(type(x) in (int,float) and math.isfinite(x) and 0<=x<.08 for x in p['crown_rise_m']),'Bounded section crown choices')
    need(type(p['angular_segments']) is int and 8<=p['angular_segments']<=96,'Bounded angular sampling')
    for k in ('panel_angle_rad','bar_angle_rad'):
        a,b=p[k]; need(0<a<b<1.4,'Bounded angular owner '+k)
    need(p['panel_angle_rad'][0]<p['bar_angle_rad'][0]<p['bar_angle_rad'][1]<p['panel_angle_rad'][1],'Bars inside panel ownership')
    need(0<p['seat_end_angle_rad']<p['jockey_end_angle_rad']<p['quarter_end_angle_rad']<1.55,'Exterior angular partition')
    need(type(p['bow_end_angle_rad']) in (int,float) and math.isfinite(p['bow_end_angle_rad']) and p['bar_angle_rad'][1]<=p['bow_end_angle_rad']<p['panel_angle_rad'][1],'Bow angular ownership')
    need(p['jockey_end_angle_rad']>p['panel_angle_rad'][1],'Quarter begins outside panel angular owner')
    need(p['quarter_end_inset_m']*4 < p['z_stations_m'][-1]-p['z_stations_m'][0],'Bounded curved lower flap ends')
    need(p['bow_width_m']*4 < p['z_stations_m'][-1]-p['z_stations_m'][0],'Distinct front/rear bow bands')
    need(p['grade']=='original_unmeasured_engineering','Do not imply source measured recipe')

class Authority:
    def __init__(self,p,body_ray):
        validate(p); self.p=p; self.ray=body_ray; self.z=p['z_stations_m'];self._body_cache={}
        # Central gullet datum: do not lift the seat to the largest flank
        # radius. Each covered angle still uses its own actual body/support
        # envelope below. All components consume these SAME section datums.
        self.crown=[]
        for j,z in enumerate(self.z):
            self.crown.append(self.body(z,0)+p['body_standoff_m']+p['panel_thickness_m']+
                              p['layer_gap_m']+p['wood_thickness_m']+p['crown_rise_m'][j])

    def body(self,z,a):
        key=(z,a)
        if key in self._body_cache:return self._body_cache[key]
        q=self.ray([0,self.p['axis_y_m'],z],[math.sin(a),math.cos(a),0])
        need(math.isfinite(q) and q>0,'Finite positive actual body ray')
        self._body_cache[key]=q
        return q

    def station(self,values,z):
        need(self.z[0]-1e-12<=z<=self.z[-1]+1e-12,'Section z bounded')
        for j in range(len(self.z)-1):
            if z<=self.z[j+1]:
                t=(z-self.z[j])/(self.z[j+1]-self.z[j]);return values[j]*(1-t)+values[j+1]*t
        return values[-1]

    def taper(self,z,a):
        lo,hi=self.p['panel_angle_rad'];u=(abs(a)-lo)/(hi-lo)
        t=(z-self.z[0])/(self.z[-1]-self.z[0])
        # Smooth both perimeter directions; finite edge thickness avoids a
        # collapsed shell boundary. Choice is original, not a sewing pattern.
        return max(0.,math.sin(math.pi*max(0.,min(1.,u))))**.75 * max(0.,math.sin(math.pi*t))**.5

    def panel(self,z,a):
        p=self.p;b=self.body(z,a)+p['body_standoff_m']
        t=p['panel_edge_thickness_m']+(p['panel_thickness_m']-p['panel_edge_thickness_m'])*self.taper(z,a)
        return b,b+t

    def bar(self,z,a):
        # Wood supported above panel's exact shared upper radius. Engineering
        # clearance is explicit, not hidden bearing-contact exclusions.
        b=self.panel(z,a)[1]+self.p['layer_gap_m'];return b,b+self.p['wood_thickness_m']

    def bow(self,z,a):
        p=self.p;b=max(self.station(self.crown,z),self.body(z,a)+p['body_standoff_m']+p['panel_thickness_m']+p['layer_gap_m']+p['wood_thickness_m'])+p['layer_gap_m']
        return b,b+p['wood_thickness_m']+p['bow_rise_m']

    def exterior(self,z,a):
        p=self.p
        # Full supporting stock bounds panel+bar+bow at every covered angle.
        # Beyond ALL support angular owners, taper the hanging exterior stock
        # smoothly toward the declared flank offset rather than carrying tree
        # thickness to the bottom. No component boundary produces a radial step.
        stock=p['body_standoff_m']+p['panel_thickness_m']+p['layer_gap_m']+p['wood_thickness_m']+p['layer_gap_m']+p['wood_thickness_m']+p['bow_rise_m']+p['outer_clearance_m']
        lower=smooth((abs(a)-p['jockey_end_angle_rad'])/(p['quarter_end_angle_rad']-p['jockey_end_angle_rad']))
        canopy=max(self.station(self.crown,z)+p['layer_gap_m']+p['wood_thickness_m']+p['bow_rise_m']+p['outer_clearance_m'],self.body(z,a)+stock)
        r=canopy*(1-lower)+(self.body(z,a)+p['quarter_body_offset_m'])*lower
        return r,r+p['leather_thickness_m']+p['seat_padding_m']*max(0.,1-(a/p['seat_end_angle_rad'])**2)

    def loft(self,zs,angles,radial,round_quarter=False):
        bottom=[];top=[]
        for z in zs:
            for a in angles:
                z_actual=z
                if round_quarter:
                    fraction=smooth((abs(a)-self.p['jockey_end_angle_rad'])/(self.p['quarter_end_angle_rad']-self.p['jockey_end_angle_rad']))
                    mid=(self.z[0]+self.z[-1])/2;span=self.z[-1]-self.z[0]
                    z_actual=mid+(z-mid)*(1-2*self.p['quarter_end_inset_m']*fraction/span)
                lo,hi=radial(z_actual,a);need(0<lo<hi and all(math.isfinite(x) for x in (lo,hi)),'Ordered radial layers')
                for rows,r in ((bottom,lo),(top,hi)):
                    rows.append([r*math.sin(a),self.p['axis_y_m']+r*math.cos(a),z_actual])
        return shell(top,bottom,len(zs),len(angles))

    def emit(self):
        p=self.p;out={};owners={};N=p['angular_segments']
        def angles(a,b):return [a+(b-a)*k/N for k in range(N+1)]
        def put(name,zs,ab,fn):
            out[name]=self.loft(zs,angles(*ab),fn,round_quarter=name.startswith('quarter_'))
            owners[name]={'z_stations_m':zs,'angle_range_rad':list(ab),'layer':fn.__name__,'all_faces_interpart_check_required':True}
        for suffix,sign in (('l',1),('r',-1)):
            for name,key,fn in (('panel','panel_angle_rad',self.panel),('tree_sidebar','bar_angle_rad',self.bar)):
                a,b=p[key];put(name+'_'+suffix,self.z,sorted((sign*a,sign*b)),fn)
        for name,zs in (('rear_bow',[self.z[0],self.z[0]+p['bow_width_m']]),('front_bow',[self.z[-1]-p['bow_width_m'],self.z[-1]])):
            put(name,zs,(-p['bow_end_angle_rad'],p['bow_end_angle_rad']),self.bow)
        # Exact authored partition, gap measured as angular arc at crown radius.
        gap=p['seam_arc_gap_m']/min(self.crown)
        put('seat_jockey',self.z,(-p['seat_end_angle_rad'],p['seat_end_angle_rad']),self.exterior)
        for suffix,sign in (('l',1),('r',-1)):
            a=p['seat_end_angle_rad']+gap;b=p['jockey_end_angle_rad'];c=p['quarter_end_angle_rad']
            put('jockey_'+suffix,self.z,sorted((sign*a,sign*b)),self.exterior)
            put('quarter_'+suffix,self.z,sorted((sign*(b+gap),sign*c)),self.exterior)
        need(set(out)==CHANGED,'Exact eleven-part construction ownership')
        return out,owners
