# SPDX-License-Identifier: CC0-1.0
"""Synthetic exact source-cut/rounded-shape/complete contact patch controls."""
import math,json,copy
from fractions import Fraction
from iron_subdivision import rebuild,normal,quantize,contact_faces,need,FOLD_ROWS
from stirrup_construction import iron_fold,loft
from frame_orientation import strip_guard

def fixture():
 P=[];N=[];F=[]
 for segment in range(7):
  centers=[[.355,.93+segment*.1,-.055],[.305,.92+segment*.1,-.055]];rings=[]
  for c in centers:
   rings.append([quantize([c[0]+.006*.1961161351*math.sin(2*math.pi*k/10),c[1]-.006*.9805806757*math.sin(2*math.pi*k/10),c[2]-.006*math.cos(2*math.pi*k/10)])for k in range(10)])
  for k in range(10):
   quad=[rings[0][k],rings[0][(k+1)%10],rings[1][(k+1)%10],rings[1][k]]
   for ids in((0,1,2),(0,2,3)):
    tri=[quad[i]for i in ids];n=normal(tri);start=len(P);P.extend(tri);N.extend([quantize(n)]*3);F.append((start,start+1,start+2))
 return P,N,F
def refuse(fn,label):
 try:fn()
 except ValueError:return label
 raise ValueError('Missing synthetic refusal '+label)
def main():
 controls=[];P,N,F=fixture()
 for side in('l','r'):
  (V,VN,Q),packet=rebuild(P,N,F,side);need(V[:420]==P and VN[:420]==N,'Every original source row exact');controls.append(side+' old P/N prefix')
  need(len(Q)==220 and len(packet['contact_faces'])==20 and len(packet['inner_contact_rows'])==FOLD_ROWS,'Explicit new face/complete contact count');controls.append(side+' face/contact/row ownership')
  for row in packet['face_ledger']:
   if row['region']=='unchanged':need(tuple(row['actual_indices'])==F[row['old_face']],'Every unaffected face exact')
  controls.append(side+' all120 unaffected faces')
  for row in packet['source_cuts']:
   t=Fraction(row['axial_t']);a,b=row['source_endpoints'];expected=[quantize([(1-t)*Fraction(x)+t*Fraction(y)for x,y in zip(a,b)])][0];need(expected==row['actual_float32_position'],'Exactly rounded dyadic source cut')
  controls.append(side+' exact dyadic point ownership')
  need(packet['maximum_new_point_rounding_error_m']>=0 and packet['maximum_actual_point_old_facet_plane_residual_m']>=0 and packet['surface_mathematically_exact']is False,'Honest numerical shape provenance');controls.append(side+' numerical residual disclosure')
  need([i for i,row in enumerate(packet['face_ledger'])if row['region']=='central'and row['old_face']<(0 if side=='l'else 120)+10]==contact_faces(side),'Exactly lower half central source facets');controls.append(side+' selected20 actual source faces')
  rings,owned=iron_fold((V,VN,Q),packet,side);surface,_=loft(rings,owned['actual_triangles']);strip_guard([quantize(q)for q in surface[0]],side);controls.append(side+' eleven skewfold rows/complete copied contact/local exact frame')
 bad=copy.deepcopy(F);bad[0]=(0,2,1);controls.append(refuse(lambda:rebuild(P,N,bad,'l'),'altered source topology'))
 controls.append(refuse(lambda:rebuild(P[:-1],N,F,'l'),'missing original row'))
 print(json.dumps({'passed':True,'scope':'Synthetic source only; no actual asset/model evaluation','count':len(controls),'controls':controls}))
if __name__=='__main__':main()
