# SPDX-License-Identifier: GPL-3.0-or-later
"""Analytic synthetic controls ONLY; no model/input/asset IO or export."""
import numpy as np
from interface_contact import certify
from check_assembly import disk,vertex_standoff,absolute_winding
from underbelly_construction import hull,offset,radius,clip_z,earclip,build_band,build_strip

def need(q,m):
 if not q:raise ValueError(m)
def refusal(fn):
 try:fn()
 except ValueError:return
 raise ValueError('Expected refusal absent')
A=np.array([[0.,0,0],[1.,0,0],[0,1.,0]])
record={'name':'synthetic','a_mesh':'wood','b_mesh':'leather','a_faces':[7],'b_faces':[9], 'aliases':[{'alias':i,'a_vertex':i,'b_vertex':10+i}for i in range(3)]}
def check(B,ia,ib,fa=7,fb=9):return certify(A,np.array(B,float),ia,ib,'wood','leather',fa,fb,[record])
need(check(A[[0,2,1]],[0,1,2],[10,12,11])['actual_boundary_contact']['kind']=='EXACT_registered_opposing_same_triangle_boundary','Actual opposing sameface')
need(check(A,[0,1,2],[10,11,12])is None,'Same-material-side coincidence refused')
need(check(A[[0,2,1]],[0,1,2],[10,12,11],fa=8)is None,'Unregistered face coincidence refused')
edge=check([[0,0,0],[1,0,0],[0,0,-1]],[0,1,2],[10,11,13],fb=10)
need(edge is not None and edge['actual_boundary_contact']['kind']=='EXACT_owned_source_edge_only','Edge-only contact with argument orientation')
need(check([[0,0,0],[1,0,0],[.2,.3,0]],[0,1,2],[10,11,13])is None,'Coplanar overlapping interiors refused')
need(check([[0,0,0],[-1,0,-1],[0,0,-1]],[0,1,2],[10,13,14])is not None,'Exact commonpoint-only control')
need(check([[0,0,0],[1,0,0],[0,0,-1]],[0,1,2],[20,21,22])is None,'Unowned coincident edge refused')
disk([[0,1,2],[0,2,3]])
refusal(lambda:disk([[0,1,2],[3,4,5]]))
refusal(lambda:disk([[0,1,5],[0,5,4],[1,2,6],[1,6,5],[2,3,7],[2,7,6],[3,0,4],[3,4,7]]))
poly=hull([[-1,-1],[1,-1],[1,1],[-1,1],[0,0]])
expanded=offset(poly,.25);need(all(abs(abs(v)-1.25)<1e-12 for p in expanded for v in p),'Outward support offset control')
clipped=clip_z([[0,0,-1],[1,0,1],[0,1,1]],0,True);need(len(clipped)==4 and min(p[2]for p in clipped)>=0,'Exact slab retains between-knot intersection')
need(abs(radius([[-1,0],[1,0],[1,2],[-1,2]],0)-.84)<1e-12,'Y-up axis ray control')
concave=[(0,0),(2,0),(2,1),(1,1),(1,2),(0,2)];faces=earclip(concave);need(abs(sum(abs((concave[b][0]-concave[a][0])*(concave[c][1]-concave[a][1])-(concave[b][1]-concave[a][1])*(concave[c][0]-concave[a][0]))/2 for a,b,c in faces)-3)<1e-12,'Concave support-sector triangulation area')
surface,caps,profile=build_band([(-.3,.86),(.3,.86),(.3,1.46),(-.3,1.46)],-.18);need(len(caps)==2 and all(len(c)==4 for c in caps.values()),'Synthetic closed U-band endpoint contracts; no actualhorse geometry')
# Reversed right-hand root traversal must retain the sourcebar diagonal.
source=[[[float(k),0.,float(z)]for k in range(4)]for z in range(2)]
root=[]
for k in range(3,-1,-1):root.append([source[0][k],source[1][k],[float(k),.1,1.],[float(k),.1,0.]])
v,n,f=build_strip(root,reverse_foot=True)
actual={frozenset(tuple(v[i])for i in f[j])for j in(0,1,8,9,16,17)}
expected={frozenset(tuple(p)for p in tri)for k in range(3)for tri in((source[0][k],source[0][k+1],source[1][k+1]),(source[0][k],source[1][k+1],source[1][k]))}
need(actual==expected,'Rightfoot exactsourcebar diagonal preserved despite reversed path')
metric=vertex_standoff(np.array([[.2,.2,1.],[2.,0,0]]),np.array([A]));need(abs(metric['minimum_m']-1)<1e-12 and abs(metric['maximum_m']-1)<1e-12,'Unsignedface/edge diagnostic distance controls')
tetra=np.array([[0.,0,0],[2.,0,0],[0,2.,0],[0,0,2.]]);faces=np.array([[0,2,1],[0,1,3],[0,3,2],[1,2,3]]);outer=tetra[faces];inner=(tetra*.5)[faces][:,[0,2,1]];probe=np.array([.1,.1,.1]);need(absolute_winding(probe,np.concatenate([outer,inner]))<1e-5 and absolute_winding(probe,outer)>.99999 and absolute_winding(probe,inner)>.99999,'Opposite nested components cannot cancel percomponent containment')
print('19 synthetic exactcontact/disk/slab/support controls PASS; no actual model IO/evaluation')
