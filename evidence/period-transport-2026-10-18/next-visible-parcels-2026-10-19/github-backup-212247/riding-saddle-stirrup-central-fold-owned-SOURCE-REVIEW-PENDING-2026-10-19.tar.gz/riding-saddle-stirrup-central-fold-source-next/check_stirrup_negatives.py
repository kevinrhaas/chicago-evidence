# SPDX-License-Identifier: GPL-3.0-or-later
"""Reproduce all184 raw/168 proper saved inherited crossings on actual old GLB."""
from pathlib import Path
import argparse,hashlib,json
import numpy as np
from check_actual import load,array,need
from official_fit_predicates import sat,proper

def run(old,fixture,out):
 out.mkdir();result={'passed':False,'scope':'Actual old83f7 input negative only; no replacement fit','rows':[]}
 try:
  d,b,raw=load(old);need(hashlib.sha256(raw).hexdigest()=='83f7b0b927c316ec2efb360178cace360351f1e04a1431d240599ae9cc8682bd','Immutable previous failed input')
  packet=json.loads(fixture.read_text());need(packet['passed']is True and len(packet['pairs'])==67,'Complete recorded readonly diagnostic')
  def triangles(name):
   pr=next(m for m in d['meshes']if m['name']==name)['primitives'][0];P=array(d,b,pr['attributes']['POSITION']).astype(float);F=array(d,b,pr['indices']).reshape(-1,3)if'indices'in pr else np.arange(len(P)).reshape(-1,3);return P[F]
  raw_count=0;proper_count=0;pairs=0
  for row in packet['pairs']:
   if row['raw_SAT']==0:continue
   need(row['kind']=='gear'and len(row['all_raw_witnesses'])==row['raw_SAT'],'Every actual raw witness retained');pairs+=1;A=triangles(row['a']);B=triangles(row['b']);observed=0
   for saved in row['all_raw_witnesses']:
    a=A[saved['a_face']];bb=B[saved['b_face']];need(np.array_equal(a,np.array(saved['actual_coordinates'][0]))and np.array_equal(bb,np.array(saved['actual_coordinates'][1])),'Actual old serialized source face identity');need(sat(a,bb),'Old raw intersection must reproduce');w=proper(a,bb);need((w is not None)==(saved['proper']is not None),'Old exact proper classification must reproduce');raw_count+=1;proper_count+=int(w is not None);observed+=int(w is not None)
   need(observed==row['strict_proper'],'Each inherited crossing pair count exact');result['rows'].append({'a':row['a'],'b':row['b'],'raw_SAT':row['raw_SAT'],'strict_proper':observed})
  need(pairs==6 and raw_count==184 and proper_count==168,'All six184raw/168proper old crossing controls')
  result.update(passed=True,raw_SAT=raw_count,strict_proper=proper_count,input_sha256=hashlib.sha256(raw).hexdigest(),fixture_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest())
 except BaseException as error:result['error']=repr(error);raise
 finally:(out/'stirrup-negative.json').write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('old',type=Path);p.add_argument('fixture',type=Path);p.add_argument('out',type=Path);a=p.parse_args();run(a.old,a.fixture,a.out)
