# SPDX-License-Identifier: CC0-1.0
"""Synthetic polygons only: no actual model/hull IO or construction."""
import math
from underbelly_construction import offset

def require(q,m):
 if not q:raise RuntimeError(m)
def refused(poly,d):
 try:offset(poly,d)
 except ValueError:return
 raise RuntimeError('Expected explicit refusal')
polygons=[[(0.,0.),(1.,0.),(2.,1e-14),(2.,1.),(0.,1.)],[(0.,0.),(1.,0.),(2.,0.),(2.,1.),(0.,1.)],[(0.,0.),(1.,0.),(1.,1.),(0.,1.)]]
worst=0.
for poly in polygons:
 for d in(.006,.010):
  result=offset(poly,d);require(len(result)==len(poly),'Every vertex retained')
  for i,q in enumerate(result):
   p=poly[i]
   for a,b in((poly[i-1],p),(p,poly[(i+1)%len(poly)])):
    dx=b[0]-a[0];dy=b[1]-a[1];length=math.hypot(dx,dy);n=(dy/length,-dx/length)
    residual=abs(math.fsum(n[k]*(q[k]-p[k])for k in range(2))-d)
    worst=max(worst,residual);require(residual<2e-15,'Independent two-plane residual')
require(offset(polygons[1],.006)[1]==(1.,-.006),'Aligned normals canonical displacement')
refused([(0.,0.),(1.,0.),(0.,1e-7)],.006)
refused(polygons[2][::-1],.006)
refused([(0.,0.),(1.,0.),(1.,float('nan'))],.006)
refused(polygons[2],float('inf'))
refused(polygons[2],-.006)
refused([(0.,0.),(1.,0.),(.5,.2),(1.,1.),(0.,1.)],.006)
print('Synthetic bisector controls PASS; worst incident-plane residual',worst,'m; no actual model IO/evaluation')
