# SPDX-License-Identifier: GPL-3.0-or-later
"""Reproduce the actual old 8f32 outgoing/return strict proper crossing."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
from check_actual import load,array,need
from official_fit_predicates import sat,proper

def run(old,fixture,out):
 out.mkdir();r={'passed':False,'scope':'Actual old 8f32 self-crossing negative only; no replacement qualification'}
 try:
  d,b,raw=load(old);need(hashlib.sha256(raw).hexdigest()=='8f32793bf14cd9a379ca699ed8144e6bb14b77873c14c37a2732e75497697786','Exact previous failed shared-station model');packet=json.loads(fixture.read_text());need(packet['candidate_sha256']==hashlib.sha256(raw).hexdigest()and packet['mesh']=='stirrup_leather_l','Actual old fixture ownership');pr=next(m for m in d['meshes']if m['name']==packet['mesh'])['primitives'][0];P=array(d,b,pr['attributes']['POSITION']).astype(float);F=array(d,b,pr['indices']).reshape(-1,3);saved=packet['actual_witness'];need(saved['a_face']==697 and saved['b_face']==931,'Exact old failed face pair');A=P[F[697]];B=P[F[931]];need(np.array_equal(A,np.array(saved['actual_coordinates'][0]))and np.array_equal(B,np.array(saved['actual_coordinates'][1])),'Actual old source triangles match saved capture');w=proper(A,B);need(sat(A,B)and w is not None,'Old branch strict proper crossing must reproduce');r.update(passed=True,input_sha256=hashlib.sha256(raw).hexdigest(),source_faces=[697,931],actual_coordinates=[A.tolist(),B.tolist()],proper=w)
 except BaseException as e:r['error']=repr(e);raise
 finally:(out/'old-lower-negative.json').write_text(json.dumps(r,indent=2)+'\n')

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('old',type=Path);p.add_argument('fixture',type=Path);p.add_argument('out',type=Path);a=p.parse_args();run(a.old,a.fixture,a.out)
