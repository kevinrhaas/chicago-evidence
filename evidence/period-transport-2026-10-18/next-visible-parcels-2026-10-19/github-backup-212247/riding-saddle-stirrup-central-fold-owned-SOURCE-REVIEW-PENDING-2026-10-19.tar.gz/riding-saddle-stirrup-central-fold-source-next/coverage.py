# SPDX-License-Identifier: CC0-1.0
"""Explicit physical scope: sixteen closed solids plus two amended open irons."""
from layer_authority import CHANGED as LAYER_CHANGED
CLOSED_CHANGED=LAYER_CHANGED|{'riding_girth','billet_l','billet_r','stirrup_leather_l','stirrup_leather_r'}
REVISED_OPEN=frozenset(('stirrup_l','stirrup_r'))
AFFECTED=CLOSED_CHANGED|REVISED_OPEN
INTERPART_PAIRS=351
if len(CLOSED_CHANGED)!=16 or len(AFFECTED)!=18 or CLOSED_CHANGED&REVISED_OPEN:raise ValueError('Exact18affected/16closed/2open scope')
