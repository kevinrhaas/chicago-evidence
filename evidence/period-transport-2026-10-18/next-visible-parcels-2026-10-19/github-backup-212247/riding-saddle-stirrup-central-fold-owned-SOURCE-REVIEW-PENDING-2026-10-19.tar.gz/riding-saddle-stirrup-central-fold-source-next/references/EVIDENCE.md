# Recovered early saddle primary text; page images remain blocked

Actual1833 metadata+full reader OCR and1805 metadata+full reader OCR were retrieved through the inherited proxy with TLS verification. No browser/model/app/ticket writes. First sandbox proxy-socket failure was infrastructural; authorized ordinary proxy request with escalation succeeded. No proxy/path/CA bypass. The exact BookReader host advertised by the1833 page UI returned CONNECT403; it was not retried or remapped. PDF standard download redirected to a storage host; not followed. No primary page image or saddle illustration was recovered/viewed. Do not infer plate shape from OCR.

##1833 Lebeaud — construction directly read

The principles of the art of modern horsemanship for ladies and gentlemen, Philadelphia:E.L.Carey&A.Hart,1833. https://archive.org/metadata/principlesofarto00lebe metadata confirms title/date/publisher, contains no rights/license field. https://archive.org/stream/principlesofarto00lebe/principlesofarto00lebe_djvu.txt is actual full OCR reader (retainedHTML lebeaud1833.ocr, literal<pre> extracted to lebeaud1833-extracted.txt). US public-domain rationale:1833 published work, not a claimed host license declaration. No check_required image used. OCR page divisions are readable but pagination/typography uncollated against pagepixels.

Printed25, Of the Saddle and its different parts:
“A saddle to be good, whatever may be its form, should fit the shape of the horse, so as not to cause rubbing, be a little stuffed but very even, in order that it may bear every where equally, and not cause any bruises.”
Seat: “very smooth and equal; a little hard, not higher on the front than the back,” and “but little thickness between the thighs and the body of the horse.” Whitespace normalized; punctuation follows retainedOCR. This directly supports restrained, coherent padding instead of a thick box or stacked unrelated shells. It supplies no numeric thickness, pressure validation, universal modern fit standard or exact cut.

Printed26: “The saddle-bows, are two pieces of beech wood, turned round to embrace the back of the horse.” They “give form to the saddle, and support all the other parts.” Two little wooden sidebars tie bows, “three or four fingers wide” (no metric conversion asserted). Rear bow wider/rounder than front; French rear border/troussequin is a separately described form, not generic English silhouette evidence.

Printed26–27: “The pannels are two cushions of linen, stuffed with hair, as hair of a cow or of a deer, which line the two sides of the saddle.” Fine rather than coarse linen discussed. This supports two padded bearing pieces below/supporting the seat, not an unbroken block across spine; precise dimensions, color and exposed perimeter not attested.

Printed27: “The seat is the top of the saddle”; excessive stuffing “heats and excoriates” the rider more quickly. “The quarters, are the external sides of the saddle, whatever may be the matter of which it is composed.” They should be “wide and long” because short quarters discomfort rider. Girthing leathers described as little straps nailed to sidebars, three on each side. No specific quarter outline, seam route, leather thickness or linen exposure is specified.

Printed29: smooth/plain saddle has “no sides to the pummel, nor edge or border to the back bow.” Nearby says such English saddles are convenient/agreeable. This is a bounded type distinction, not a drawing of a particular1835Chicago saddle. Do not combine French raised supports and later modern knee rolls merely because both names are familiar.

Printed29 also states: “As the perspiration which the pannels of the saddle imbibe, hardens them” and may wound the horse, “it is good to line this part with calf or buckskin, for horses that perspire much.” This is an explicitly conditional lining option, not evidence that every panel is exposed pale linen or that all saddles had leather lining. It can support a separately declared material/construction choice; it cannot justify recoloring intersecting panels to hide a geometric defect.

##1805 Adams — rider interface only from this volume

An analysis of horsemanship, volume1,1805, London:AlbionPress/JamesCundee. Metadata and actual full OCR retrieved from https://archive.org/metadata/analysisofhorsem01adam and https://archive.org/stream/analysisofhorsem01adam/analysisofhorsem01adam_djvu.txt . Metadata has no explicit rights field; reasoned public-domain basis from1805publication. Retained adams1805-reader.html and literalpre extraction adams1805-extracted.txt.

Printed12–13: thighs turn inward, hollow/muscular portion should lie smooth/flat to saddle; instruction places thighs25–30degrees short of perpendicular. Printed24 recommends a “peak saddle” when beginning each new lesson. These are this riding-master's instruction, not a civilian saddle construction plate or a requirement to add high cantle/pommel to the1833plain pattern. Volume1 search did not locate panel/upholstery construction; no such evidence claimed. Not sufficient to backdate the1833pattern to1812.

##Source registration and eligibility

No existing canonical data/sources ID matching these IA identifiers was found in this read-only search. They are bibliographic sources already cited in the retained T2802 dossier, not newly minted sourceIDs. Root must register verified metadata/rights/excerpts with real IDs before a committed asset record cites them. Do not fabricate an ID to satisfy a validator.1833text is eligible pre1835 construction analogy; neither work attests Chicago ownership, a specific person using the gear, exact colors/dimensions/cut or photographic quality. Later1902/1904 catalog/workshop evidence remains later analogy only; none was used to fill1835geometry in this pass.

The new shared-section construction plan is compatible with restrained padding, paired panels, wood bows/sidebars and exterior quarters. Its actual geometry sections, gullet shape, seam/collar bearing interfaces and outside silhouette remain original reconstruction and must independently pass actual readback/contact/image gates. Text does not excuse interpenetration or count as animal-fit/occupant acceptance.
