# SPDX-License-Identifier: CC0-1.0
"""Shared angular ownership and exact decoded upper-branch separation.

No asset IO or geometry evaluation at import. Float32 rounding enclosures only
bind authored station ownership; they never relax the physical SAT predicates.
"""
import math,struct,operator
from fractions import Fraction
from iron_subdivision import FOLD_ROWS

START_KNOT=.738
END_KNOT=.808
END_ANGLE=1.60
ROOT_BLEND=.055
THICK=.004

def need(ok,message):
 if not ok:raise ValueError(message)
def f32(value):return struct.unpack('<f',struct.pack('<f',value))[0]
def legacy_angles(root):
 return[root+(END_ANGLE-root)*j/42 for j in range(1,42)]+[END_ANGLE]
def schedule(root_angles):
 need(len(root_angles)==2 and all(math.isfinite(a)and 0<a<START_KNOT-ROOT_BLEND for a in root_angles),'Two finite bounded root angles')
 shared_start=max(root_angles)+ROOT_BLEND
 common=sorted({shared_start,START_KNOT,END_KNOT,END_ANGLE}|{a for root in root_angles for a in legacy_angles(root)if a>shared_start})
 need(common[0]==shared_start and common[-1]==END_ANGLE and START_KNOT in common and END_KNOT in common,'Canonical endpoints and both exact support knots')
 initial=[sorted({a for a in legacy_angles(root)if a<shared_start}|({root+ROOT_BLEND}if root+ROOT_BLEND<shared_start else set()))for root in root_angles]
 # Feet end at source columns16/20. Half of the next unused grid interval
 # owns one return-only radial peel before the billet foot begins atcol21.
 peel=root_angles[1]+(root_angles[1]-root_angles[0])/8
 need(root_angles[1]<peel<shared_start,'Bounded return-root peel station')
 initial[1]=sorted(set(initial[1])|{peel})
 branches=[before+common for before in initial]
 need(all(all(x<y for x,y in zip(q,q[1:]))for q in branches),'Strictly increasing retained source stations')
 return{'root_angles':list(root_angles),'shared_start':shared_start,'common':common,'initial':initial,'branches':branches,'return_peel_angle':peel}

def require_shared(first,second,canonical):
 need(list(first)==list(second)==list(canonical),'Independent angular phases are forbidden after the shared start')

def verify_strip_faces(indices,point_count):
 """Bind actual indexed triangles to four-vertex source rings, either diagonal."""
 need(point_count>=8 and point_count%4==0,'Four vertices per owned source ring')
 cells=point_count//4-1;need(len(indices)==8*cells+4,'Eight side faces per cell plus four end-cap faces')
 faces=[]
 for face in indices:
  need(len(face)==3,'Three actual source indices per triangle')
  q=tuple(operator.index(v)for v in face);need(len(set(q))==3 and min(q)>=0 and max(q)<point_count,'Exact distinct in-bounds integer triangle ownership');faces.append(frozenset(q))
 def quad(actual,a,b,c,d):
  need(len(set(actual))==2,'Two distinct triangles per source quad')
  need(set(actual)in({frozenset((a,b,c)),frozenset((a,c,d))},{frozenset((a,b,d)),frozenset((b,c,d))}),'Actual face pair must own exactly one legal source-quad diagonal')
 for j in range(cells):
  for k in range(4):
   a=4*j+k;b=4*j+(k+1)%4;quad(faces[8*j+2*k:8*j+2*k+2],a,b,b+4,a+4)
 quad(faces[8*cells:8*cells+2],0,1,2,3);last=point_count-4;quad(faces[8*cells+2:8*cells+4],last,last+1,last+2,last+3)
 return{'passed':True,'scope':'Exact actual four-vertex ring/side/endcap index ownership, either legal diagonal; orientation and embedding require unchanged topology/frame/self guards','cells':cells,'side_quads':4*cells,'endcap_quads':2}

def root_angles_from_rings(points,side):
 need(len(points)%4==0 and len(points)>=24 and side in('l','r'),'Owned root sections')
 sign=1 if side=='l'else-1;n=len(points)//4;out=[]
 for row in(2,n-3):
  a,b=points[4*row],points[4*row+1];x=(float(a[0])+float(b[0]))/2;y=(float(a[1])+float(b[1]))/2
  out.append(math.atan2(sign*x,y-1.16))
 return out

def cross2(a,b,c):return(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def exact_quad(points):
 q=[tuple(Fraction(float(x))for x in p)for p in points]
 turns=[cross2(q[i],q[(i+1)%4],q[(i+2)%4])for i in range(4)]
 need(all(x>0 for x in turns)or all(x<0 for x in turns),'Strict convex station material quad')
 return q
def strictly_separate(a,b):
 for poly in(a,b):
  for p,q in zip(poly,poly[1:]+poly[:1]):
   axis=(q[1]-p[1],p[0]-q[0]);A=[x[0]*axis[0]+x[1]*axis[1]for x in a];B=[x[0]*axis[0]+x[1]*axis[1]for x in b]
   if max(A)<min(B)or max(B)<min(A):return True
 return False

def rounding_interval(value):
 value=float(value);bits=struct.unpack('<I',struct.pack('<f',value))[0]
 need(math.isfinite(value)and value==f32(value),'Actual finite serialized float32')
 if value==0:lo=-2.**-149;hi=2.**-149
 elif value>0:lo=struct.unpack('<f',struct.pack('<I',bits-1))[0];hi=struct.unpack('<f',struct.pack('<I',bits+1))[0]
 else:lo=struct.unpack('<f',struct.pack('<I',bits+1))[0];hi=struct.unpack('<f',struct.pack('<I',bits-1))[0]
 return((Fraction(lo)+Fraction(value))/2,(Fraction(value)+Fraction(hi))/2)

def radius_enclosure(point,angle,side,offset):
 # Closed float32 rounding bins plus a conservative bound for the fixed short
 # float64 producer arithmetic. This is ~7e-15 metres, NOT collision clearance.
 error=Fraction(8*math.ulp(4.));interval=(Fraction(0),Fraction(2));sign=1 if side=='l'else-1
 for value,coefficient,datum in[(point[0],sign*math.sin(angle),0.),(point[1],math.cos(angle),1.16)]:
  need(abs(value)<4 and math.isfinite(coefficient)and coefficient!=0,'Bounded station coordinate and nonzero direction')
  lo,hi=rounding_interval(value);c=Fraction(coefficient);d=Fraction(datum);bounds=sorted(((lo-error-d)/c-Fraction(offset),(hi+error-d)/c-Fraction(offset)))
  interval=(max(interval[0],bounds[0]),min(interval[1],bounds[1]))
 need(interval[0]<=interval[1],'Actual point must belong to declared angular/radial source enclosure')
 return interval

def verify_upper_branches(points,side,declared=None):
 spec=schedule(root_angles_from_rings(points,side))
 if declared is not None:
  require_shared(declared[0],declared[1],spec['common'])
 nA,nB=map(len,spec['branches']);lower_start=15+nA
 need(len(points)==4*(30+FOLD_ROWS+nA+nB),'Exact source root/upper/connector/fold row ownership')
 common=spec['common'];firstA=3+len(spec['initial'][0]);firstB=lower_start+nB+11+FOLD_ROWS-len(spec['initial'][1]);A=[];B=[];bindings=[]
 zlo,zhi=f32(-.06-.025/2),f32(-.06+.025/2)
 for i,angle in enumerate(common):
  rows=[firstA+i,firstB-i];sections=[];interval=(Fraction(0),Fraction(2))
  for branch,row in enumerate(rows):
   ring=points[4*row:4*row+4];need(len(ring)==4,'Actual station row bounds')
   need(list(ring[0][:2])==list(ring[1][:2])and list(ring[2][:2])==list(ring[3][:2]),'Actual shared width is exactly alongZ')
   expected_z=[zlo,zhi,zhi,zlo]if branch==0 else[zhi,zlo,zlo,zhi]
   need([float(q[2])for q in ring]==expected_z,'Exact per-edge25mm source width/Zorder, with return width reversed')
   inner=list(map(float,ring[0][:2]));outer=list(map(float,ring[3][:2]));gap=.012 if branch==0 else.006
   for xy,offset in((inner,gap),(outer,gap+THICK)):
    bounds=radius_enclosure(xy,angle,side,offset);interval=(max(interval[0],bounds[0]),min(interval[1],bounds[1]))
   sections.append((inner,outer))
  need(interval[0]<=interval[1],'Both branches must bind one common support radius with unchanged6/12mm offsets/4mm thickness')
  A.append(sections[0]);B.append(sections[1]);bindings.append({'angle':angle,'outgoing_row':rows[0],'return_row':rows[1],'common_radius_enclosure_m':[str(x)for x in interval]})
 quadsA=[exact_quad([a[0],b[0],b[1],a[1]])for a,b in zip(A,A[1:])];quadsB=[exact_quad([a[0],b[0],b[1],a[1]])for a,b in zip(B,B[1:])]
 for i,a in enumerate(quadsA):
  for j,b in enumerate(quadsB):need(strictly_separate(a,b),'Actual common upper branch material quads must strictly separate: '+str(i)+'/'+str(j))
 return{'passed':True,'scope':'Decoded shared angular/radius ownership with float32 rounding enclosures and exact dyadic2D material-quad separation; not full3D global embedding/pressure/motion','common_station_count':len(common),'all_upper_quad_pairs':len(quadsA)*len(quadsB),'bindings':bindings,'lower_fold_start_row':lower_start}
