# SPDX-License-Identifier: GPL-3.0-or-later
"""SOURCE ONLY. Exact source-simplex contact certificates, never adjacency waivers.
No model IO/evaluation at import. Must precede closed-solid nesting qualification.
"""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
from check_actual import load,array,topology,need,connected_components
from coverage import CLOSED_CHANGED,REVISED_OPEN,AFFECTED
CHANGED=AFFECTED
from exact_contact import source_edge_only,source_vertex_only
from official_fit_predicates import sat,proper

def run(capture,candidate,out,expected):
 out.mkdir();r={'passed':False,'scope':'All actual closed gear components self-intersection; sixteen closed changed shells plus two amended open irons mandatory; exact owned edge/vertex ONLY, no whole-adjacency exemption','parts':{}}
 def save():(out/'self.json').write_text(json.dumps(r,indent=2)+'\n')
 try:
  raw=(capture/'capture.json').read_bytes();m=json.loads(raw);r['capture_metadata_sha256']=hashlib.sha256(raw).hexdigest();d,b,glb=load(candidate)
  need(len(expected)==64 and hashlib.sha256(glb).hexdigest()==expected==m['inputs']['candidate']['sha256'],'Explicit reviewed actual candidate hash');r['candidate_sha256']=expected
  need(m['passed']and m['actualPose']=={'clip':'idle','action_time_s':0,'mixer_time_s':0},'Actual idle0')
  meta=m['parts']['candidate_all'];datafile=capture/'candidate_all.f64';need(hashlib.sha256(datafile.read_bytes()).hexdigest()==meta['sha256']and datafile.stat().st_size==meta['triangles']*72,'Actual Float64 capture identity');data=np.memmap(datafile,dtype='<f8',mode='r',shape=(meta['triangles'],3,3))
  need(np.isfinite(data).all(),'Finite actual world triangles');seen=set()
  for p in meta['parts']:
   name=p['name'];need(name not in seen,'Unique changed actual part');seen.add(name);mesh=d['meshes'][p['mesh']];need(mesh['name']==name and p['primitive']==0 and len(mesh['primitives'])==1,'Exact canonical primitive binding');pr=mesh['primitives'][0];P=array(d,b,pr['attributes']['POSITION']).astype(float);F=array(d,b,pr['indices']).reshape(-1,3) if 'indices'in pr else np.arange(len(P)).reshape(-1,3);need(len(F)==p['face_count']and p['source_face_start']==0,'Complete actual source index stream');
   if name in CLOSED_CHANGED:
    comps=connected_components(P,F);need(len(comps)==(3 if name in{'riding_girth','billet_l','billet_r'}else 1),'Explicit twentytwocomponent topology')
    for comp in comps:
     vo=comp['vertex_start'];fo=comp['face_start'];topology(P[vo:vo+comp['vertex_count']],F[fo:fo+comp['face_count']]-vo)
   triangles=np.asarray(data[p['face_start']:p['face_start']+p['face_count']]);
   if name in CHANGED:need(np.array_equal(triangles,P[F]),'Exact actual changed world capture equals verified rigid source frame')
   # Fixed expanded hard-edge primitives duplicate source POSITION rows. Exact
   # actual coordinate welding recovers geometric aliases without tolerance.
   alias={};actual_vertices=[];faces=[]
   for tri in triangles:
    f=[]
    for q in tri:
     key=tuple(map(float,q))
     if key not in alias:alias[key]=len(actual_vertices);actual_vertices.append(key)
     f.append(alias[key])
    need(len(set(f))==3,'Actual nondegenerate welded face');faces.append(f)
   
   if name in CLOSED_CHANGED:
    need(len(alias)==len(P),'No unowned coincident NEW vertices before exact contact classification')
   F=np.array(faces,int);edges={}
   for f in faces:
    for a,bb in zip(f,f[1:]+f[:1]):edges.setdefault(tuple(sorted((a,bb))),[]).append((a,bb))
   closed=all(len(e)==2 and e[0]==e[1][::-1] for e in edges.values())
   need(name not in CLOSED_CHANGED or closed,'Changed closed shell must be closed')
   if name in REVISED_OPEN:need(not closed,'Amended inherited iron remains explicitly open/nonmanifold; no solid inference')
   if closed:
    # Edge incidence alone permits a vertex pinch. Every closed-target vertex
    # link must be ONE cycle before inferring an embedded 2-manifold solid.
    links={}
    for face in faces:
     for v in face:
      aa,bb=[q for q in face if q!=v];link=links.setdefault(v,{});link.setdefault(aa,set()).add(bb);link.setdefault(bb,set()).add(aa)
    for link in links.values():
     need(all(len(neighbors)==2 for neighbors in link.values()),'Closed target vertex link degree2')
     todo=[next(iter(link))];visited=set()
     while todo:
      k=todo.pop()
      if k in visited:continue
      visited.add(k);todo.extend(link[k]-visited)
     need(len(visited)==len(link),'Closed target single-cycle vertex link; no pinched solids')
   lo=triangles.min(1);hi=triangles.max(1)
   row={'complete':False,'closed':closed,'embedded_closed_solid':False,'faces':len(F),'AABB_candidates':0,'raw_SAT':0,'exact_edge_only':0,'exact_vertex_only':0,'unexpected':[]};r['parts'][name]=row;save()
   if not closed:
    row.update(complete=True,status='Open/nonmanifold target: no solid or winding inference; full interpart SAT remains mandatory');save();continue
   for i,a in enumerate(triangles):
    possible=np.flatnonzero(np.all(hi>=lo[i]-1e-8,axis=1)&np.all(lo<=hi[i]+1e-8,axis=1))
    for j in possible:
     j=int(j)
     if j<=i:continue
     row['AABB_candidates']+=1;bb=triangles[j];ia=list(map(int,F[i]));ib=list(map(int,F[j]));shared=set(ia)&set(ib)
     if len(shared)==2:
      cert=source_edge_only(a,bb,ia,ib)
      if cert is not None:row['exact_edge_only']+=1;continue
     if not sat(a,bb):continue
     row['raw_SAT']+=1;witness=proper(a,bb)
     cert=None
     if witness is None and len(shared)==1:
      k=next(iter(shared));cert=source_vertex_only(a,bb,ia.index(k),ib.index(k))
     if cert is not None:row['exact_vertex_only']+=1;continue
     row['unexpected'].append({'a_face':i,'b_face':j,'source_indices':[ia,ib],'actual_coordinates':[a.tolist(),bb.tolist()],'proper':witness});save();raise ValueError('FIRST actual shell self intersection/touch '+name)
   row.update(complete=True,embedded_closed_solid=True);save()
  need(len(seen)==29 and CHANGED<=seen,'All29 actual gear classifications;18affected/16closed/2inheritedopen, every closed component self-scanned');r['passed']=True;save()
 except BaseException as e:r['error']=repr(e);save();raise
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('capture',type=Path);ap.add_argument('candidate',type=Path);ap.add_argument('out',type=Path);ap.add_argument('expected_sha');a=ap.parse_args();run(a.capture,a.candidate,a.out,a.expected_sha)
