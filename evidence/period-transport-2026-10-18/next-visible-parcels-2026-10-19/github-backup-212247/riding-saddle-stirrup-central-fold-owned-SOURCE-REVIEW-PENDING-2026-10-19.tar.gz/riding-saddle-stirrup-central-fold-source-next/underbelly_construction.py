# SPDX-License-Identifier: CC0-1.0
"""SOURCE ONLY original three-girth/six-leather engineering hypothesis.
No IO/evaluation at import.1833 supports general component/count family only.
Cuts, offsets and interfaces are unmeasured reconstruction, not animal fit.
"""
import math,struct
from topology import finish
from layer_authority import Authority
CHANGED_EXTRA=frozenset(('riding_girth','billet_l','billet_r'))
CELLS=(4,7,10);AXIS=(0.,1.16);START=1.65;WIDTH=.055;THICK=.004

def need(q,m):
 if not q:raise ValueError(m)
def f32(v):return struct.unpack('<f',struct.pack('<f',v))[0]
def cross2(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def hull(points):
 p=sorted(set(tuple(q)for q in points));need(len(p)>=3,'Nonempty full-width support')
 def half(rows):
  out=[]
  for q in rows:
   while len(out)>1 and cross2(out[-2],out[-1],q)<=0:out.pop()
   out.append(q)
  return out
 out=half(p)[:-1]+half(p[::-1])[:-1];need(len(out)>=3,'Nondegenerate convex support');return out

def clip_z(poly,value,lower):
 out=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  da=(a[2]-value)*(1 if lower else -1);db=(b[2]-value)*(1 if lower else -1)
  if da>=0:out.append(a)
  if (da<0<db)or(db<0<da):
   t=da/(da-db);out.append([a[i]+t*(b[i]-a[i])for i in range(3)])
 return out

def slab_hull(triangles,lo,hi):
 points=[]
 for triangle in triangles:
  poly=clip_z(clip_z([list(p)for p in triangle],lo,True),hi,False)
  points.extend([p[:2]for p in poly])
 return hull(points)

def offset(poly,distance):
 # Same support planes and vertices; stable unit-normal bisector, not edge deletion.
 need(len(poly)>=3 and math.isfinite(distance) and distance>=0,'Finite nonnegative support offset')
 need(all(len(p)==2 and all(math.isfinite(x)for x in p)for p in poly),'Finite XY support vertices')
 need(math.fsum(a[0]*b[1]-b[0]*a[1]for a,b in zip(poly,poly[1:]+poly[:1]))>0,'Counterclockwise support polygon')
 normals=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  dx=b[0]-a[0];dy=b[1]-a[1];length=math.hypot(dx,dy);need(length>1e-10,'Support edge length')
  n=(dy/length,-dx/length)
  need(abs(math.fsum(x*x for x in n)-1)<=8*math.ulp(1.),'Unit outward support normal')
  normals.append(n)
 out=[]
 for i,p in enumerate(poly):
  previous=poly[i-1];following=poly[(i+1)%len(poly)]
  need(cross2(previous,p,following)>=0,'Consistent convex CCW support turns')
  a=normals[i-1];b=normals[i];denominator=1+math.fsum(x*y for x,y in zip(a,b))
  need(math.isfinite(denominator) and denominator>1e-8,'Antiparallel or ill-conditioned support miter refused')
  q=tuple(p[j]+distance*(a[j]+b[j])/denominator for j in range(2))
  need(all(math.isfinite(x)for x in q),'Finite support miter')
  # Float64 rounding bound in metres, not a geometry/contact tolerance change.
  scale=max(1.,distance,*(abs(x)for x in p),*(abs(x)for x in q))
  bound=64*math.ulp(scale)
  for n in(a,b):
   residual=abs(math.fsum(n[j]*(q[j]-p[j])for j in range(2))-distance)
   need(residual<=bound,'Both incident shifted support planes must agree within float64 rounding bound')
  out.append(q)
 return out

def radius(poly,a):
 direction=(math.sin(a),math.cos(a));hits=[]
 for q,w in zip(poly,poly[1:]+poly[:1]):
  v=(w[0]-q[0],w[1]-q[1]);p=(q[0]-AXIS[0],q[1]-AXIS[1]);det=direction[0]*v[1]-direction[1]*v[0]
  if abs(det)<1e-14:continue
  t=(p[0]*v[1]-p[1]*v[0])/det;u=(p[0]*direction[1]-p[1]*direction[0])/det
  if t>=0 and -1e-10<=u<=1+1e-10:hits.append(t)
 return max(hits)if hits else None

def point(r,a,z):return [r*math.sin(a),AXIS[1]+r*math.cos(a),z]
def build_strip(rings,reverse_foot=False):
 need(len(rings)>=2 and all(len(q)==4 for q in rings),'Closed rectangular-section strip')
 v=[list(q)for ring in rings for q in ring];faces=[]
 for j in range(len(rings)-1):
  for k in range(4):
   a=j*4+k;b=j*4+(k+1)%4;c=b+4;e=a+4
   if reverse_foot and j<3 and k==0:faces.extend([(a,b,e),(b,c,e)])
   else:faces.extend([(a,b,c),(a,c,e)])
 faces.extend([(0,2,1),(0,3,2)]);last=len(v)-4;faces.extend([(last,last+1,last+2),(last,last+2,last+3)])
 return finish(v,faces)

def earclip(poly):
 area=math.fsum(a[0]*b[1]-b[0]*a[1]for a,b in zip(poly,poly[1:]+poly[:1]))
 need(abs(area)>1e-12,'Nondegenerate support-sector area')
 sign=1 if area>0 else -1;ids=list(range(len(poly)));triangles=[]
 while len(ids)>3:
  found=False
  for k,b in enumerate(ids):
   a=ids[k-1];c=ids[(k+1)%len(ids)]
   if sign*cross2(poly[a],poly[b],poly[c])<=0:continue
   if any(min(sign*cross2(poly[a],poly[b],poly[j]),sign*cross2(poly[b],poly[c],poly[j]),sign*cross2(poly[c],poly[a],poly[j]))>=0 for j in ids if j not in(a,b,c)):continue
   triangles.append((a,b,c));ids.pop(k);found=True;break
  need(found,'No unresolved support-sector triangulation; refuse fallback')
 triangles.append(tuple(ids));return triangles if sign>0 else[(a,c,b)for a,b,c in triangles]

def build_band(body,zc):
 inner=offset(body,.006);outer=offset(body,.010)
 def arc(poly):
  vertices=[(math.atan2(x,y-AXIS[1])%(2*math.pi),(x,y))for x,y in poly]
  middle=[point for angle,point in sorted(vertices)if START<angle<2*math.pi-START]
  start=radius(poly,START);end=radius(poly,2*math.pi-START);need(start is not None and end is not None,'Actual underbelly endpoints')
  return [tuple(point(start,START,0)[:2])]+middle+[tuple(point(end,2*math.pi-START,0)[:2])]
 ia=arc(inner);oa=arc(outer);poly=ia+oa[::-1];need(math.fsum(a[0]*b[1]-b[0]*a[1]for a,b in zip(poly,poly[1:]+poly[:1]))>1e-12,'Counterclockwise simple support sector');N=len(poly);v=[[x,y,zc-WIDTH/2]for x,y in poly]+[[x,y,zc+WIDTH/2]for x,y in poly];faces=[]
 for a,b,c in earclip(poly):faces.extend([(a+N,b+N,c+N),(a,c,b)])
 left=(N-1,0);right=(len(ia)-1,len(ia))
 for a in range(N):
  b=(a+1)%N
  if(a,b)in(left,right):continue
  faces.extend([(a,b,b+N),(a,b+N,a+N)])
 # Explicit endpoint diagonals agree with the copied four-corner leaf caps.
 a,b=left;faces.extend([(a,b,a+N),(b,b+N,a+N)])
 a,b=right;faces.extend([(a,b,b+N),(a,b+N,a+N)])
 def cap(i,o):return [v[i],v[i+N],v[o+N],v[o]]
 return finish(v,faces),{'l':cap(0,N-1),'r':cap(len(ia)-1,len(ia))},{'inner_contour_XY_m':ia,'outer_contour_XY_m':oa,'surface_tessellation':'Exact separately tessellated contours, not near-duplicate union-angle rings'}

def merge(components):
 v=[];n=[];f=[];ledger=[]
 for name,(cv,cn,cf)in components:
  vo=len(v);fo=len(f);v.extend(cv);n.extend(cn);f.extend(tuple(i+vo for i in face)for face in cf)
  ledger.append({'name':name,'vertex_start':vo,'vertex_count':len(cv),'face_start':fo,'face_count':len(cf),'Euler':2})
 return (v,n,f),ledger

def construct(body_triangles,fixed_surfaces,params):
 # The caller verifies fixed_surfaces against hard-pinned50463 actual inputs.
 # Quantize before reuse so contact interfaces share ACTUAL float32 coordinates.
 fixed={name:([[f32(x)for x in p]for p in v],faces)for name,(v,n,faces)in fixed_surfaces.items()}
 bands=[];leaves={'l':[],'r':[]};interfaces=[];profiles=[]
 cache={}
 def support(lo,hi):
  key=(lo,hi)
  if key not in cache:cache[key]=slab_hull(body_triangles,lo,hi)
  return cache[key]
 for number,cell in enumerate(CELLS):
  zlo=params['z_stations_m'][cell];zhi=params['z_stations_m'][cell+1];zc=(zlo+zhi)/2
  body=support(zc-WIDTH/2,zc+WIDTH/2)
  need(all(cross2(a,b,AXIS)>0 for a,b in zip(body,body[1:]+body[:1])),'Reference axis inside full-width body support')
  band_name='underbelly_band_'+str(number);band_surface,caps,contours=build_band(body,zc);bands.append((band_name,band_surface))
  profiles.append({'component':band_name,'center_z_m':zc,'width_m':WIDTH,'inner_offset_m':.006,'outer_offset_m':.010,'support_polygon_XY_m':body,**contours,'no_over_back_segment':True,'not_pressure_or_motion_accepted':True})
  for side,sign in (('l',1),('r',-1)):
   bar='tree_sidebar_'+side;P,F=fixed[bar];cols=list(range(21,25))if side=='l'else list(range(3,-1,-1));root=[]
   for col in cols:
    a=P[cell*25+col];b=P[(cell+1)*25+col];upper=[]
    for q in (a,b):
     length=math.hypot(q[0],q[1]-AXIS[1]);need(length>0,'Actual bar radial frame')
     upper.append([q[0]*(1+THICK/length),AXIS[1]+(q[1]-AXIS[1])*(1+THICK/length),q[2]])
    root.append([a,b,upper[1],upper[0]])
   # Follow only the under-quarter corridor. Full-width body/panel supports,
   # not three body rays; chosen spacings/transition are original engineering.
   foot_angle=sign*.58;foot_r=[math.hypot(q[0],q[1]-AXIS[1])for q in root[-1][:2]]
   for j in range(1,13):
    t=j/12;a=sign*(.58+(START-.58)*t)
    if j==12:
     cap=caps[side];root.append([list(q)for q in cap]);continue
    width=.04+(.024-.04)*min(1,t/.3)if t<=.7 else .024+(.055-.024)*((t-.7)/.3)
    lo=zc-width/2;hi=zc+width/2;bh=support(lo,hi);br=radius(bh,a);need(br is not None,'Actual strap body support')
    panelP,panelF=fixed['panel_'+side];paneltri=[[panelP[i]for i in face]for face in panelF];ph=slab_hull(paneltri,lo,hi);pr=radius(ph,a)
    lower=br+.006
    if pr is not None:lower=max(lower,pr+.001)
    # Exact attachment datum decays once outboard of wood; no postfailure tuning.
    t0=min(1,t/.3);blend=1-t0*t0*(3-2*t0);lower=max(lower,br+(max(foot_r)-radius(support(zlo,zhi),foot_angle))*blend+.006*(1-blend))
    root.append([point(lower,a,lo),point(lower,a,hi),point(lower+THICK,a,hi),point(lower+THICK,a,lo)])
   leaf_name='girthing_leather_'+side+'_'+str(number);leaves[side].append((leaf_name,build_strip(root,reverse_foot=side=='r')))
   barfaces=[4*(cell*24+k)+q for k in ((21,22,23)if side=='l'else(0,1,2))for q in (0,1)]
   interfaces.append({'name':'wood_foot_'+side+'_'+str(number),'a_mesh':bar,'a_faces':barfaces,'b_mesh':'billet_'+side,'b_component':number,'b_local_faces':[0,1,8,9,16,17],'kind':'copied_actual_bar_top_foot','strict_proper_allowed':False})
   interfaces.append({'name':'band_cap_'+side+'_'+str(number),'a_mesh':'riding_girth','a_component':number,'a_local_faces':[-4,-3]if side=='l'else[-2,-1],'b_mesh':'billet_'+side,'b_component':number,'b_local_faces':[-2,-1],'kind':'copied_actual_band_endcap','strict_proper_allowed':False})
 output={};ledger={}
 output['riding_girth'],ledger['riding_girth']=merge(bands)
 for side in ('l','r'):output['billet_'+side],ledger['billet_'+side]=merge(leaves[side])
 return output,{'component_ranges':ledger,'planned_interfaces':interfaces,'band_profiles':profiles,'source_supported_family':'1833pp27–28: threeleathersperside, girthsgenerallythree; no Chicagoobjectattestation','all_dimensions_and_connections':'original_unmeasured_reconstruction','production_accepted':False}
