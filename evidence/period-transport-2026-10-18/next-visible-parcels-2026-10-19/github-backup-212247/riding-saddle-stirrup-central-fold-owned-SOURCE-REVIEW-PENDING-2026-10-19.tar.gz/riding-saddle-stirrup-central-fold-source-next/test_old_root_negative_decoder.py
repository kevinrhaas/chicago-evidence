# SPDX-License-Identifier: CC0-1.0
"""Source-only bilateral regression using the REAL array decoder/predicates.

Only asset loading and identity hash are mocked. Mesh arrays, all eight witness
bindings, both decoder sides, SAT/proper and the real run() control flow execute.
No actual asset, support evaluator or candidate is opened or generated.
"""
from pathlib import Path
import json,struct,tempfile,types
import check_old_root_negatives as helper

DIGEST='6cb6addf7cc11ac18a12d7786b082574c70ad5ea988cfaa60a9537a6e299302c'
def main():
 d={'accessors':[],'bufferViews':[],'meshes':[]};binary=bytearray()
 def append(rows,kind):
  width=3 if kind=='VEC3'else 1;flat=[v for row in rows for v in row];offset=len(binary);fmt='f'if kind=='VEC3'else'I';binary.extend(struct.pack('<'+fmt*len(flat),*flat));v=len(d['bufferViews']);d['bufferViews'].append({'byteOffset':offset,'byteLength':len(binary)-offset});a=len(d['accessors']);d['accessors'].append({'bufferView':v,'componentType':5126 if kind=='VEC3'else 5125,'count':len(rows),'type':kind});return a
 triangle_a=[[0.,0.,0.],[1.,0.,0.],[0.,1.,0.]];triangle_b=[[.25,.25,-1.],[.25,.25,1.],[.5,.25,1.]]
 for side in('l','r'):
  for part,triangle,count in(('billet',triangle_a,372),('stirrup_leather',triangle_b,1604)):
   pos=append(triangle,'VEC3');indices=append([[v]for _ in range(count)for v in(0,1,2)],'SCALAR');d['meshes'].append({'name':part+'_'+side,'primitives':[{'attributes':{'POSITION':pos},'indices':indices}]})
 pairs={}
 for side in('l','r'):
  pairs[side]={'witnesses':[{'a_face':a,'b_face':b,'actual_coordinates':[triangle_a,triangle_b]}for a,b in((252,1600),(252,1603),(369,1600),(369,1603))]}
 fixture={'candidate_sha256':DIGEST,'pairs':pairs};old_load,old_hash=helper.load,helper.hashlib
 try:
  # Real helper.array reads every accessor from this unchanged shared bytes
  # object. Replacing it with a left triangle breaks the right-side decode.
  helper.load=lambda _: (d,bytes(binary),b'synthetic-input-identity')
  helper.hashlib=types.SimpleNamespace(sha256=lambda _:types.SimpleNamespace(hexdigest=lambda:DIGEST))
  with tempfile.TemporaryDirectory(prefix='tack-negative-decoder-')as name:
   base=Path(name);packet=base/'fixture.json';packet.write_text(json.dumps(fixture));out=base/'out';helper.run(base/'unused-synthetic-input',packet,out);r=json.loads((out/'old-root-negatives.json').read_text())
   if not(r['passed']and r['strict_proper_witnesses']==8 and len(r['pairs']['l'])==len(r['pairs']['r'])==4):raise ValueError('Both real decoder sides and all eight strict witnesses mandatory')
 finally:helper.load,helper.hashlib=old_load,old_hash
 print(json.dumps({'passed':True,'scope':'Synthetic buffers only, real bilateral array decoder and run control flow; no actual asset/model/candidate','sides':2,'strict_proper_witnesses':8,'input_hash_mocked_only_for_synthetic_identity':True}))
if __name__=='__main__':main()
