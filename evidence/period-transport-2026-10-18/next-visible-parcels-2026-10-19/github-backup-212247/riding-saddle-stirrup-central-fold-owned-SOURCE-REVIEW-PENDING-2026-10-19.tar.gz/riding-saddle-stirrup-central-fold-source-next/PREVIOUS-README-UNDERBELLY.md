# SOURCE ONLY — three underbelly girths and six sidebar leathers

Root approved74dad0plan and explicit14changed/15protected authoring scope. No new actualhorse/gear input evaluation, candidate export, capture, SAT qualification or browser has run. Only19synthetic analytic controls ran normally and under-O; those are NOT asset evidence. Prior50463/b481closure and8ce779/ba3eproperpanel failures remain immutable.

## One construction hypothesis

`underbelly_construction.py` uses actual complete torsoZslabs, convexsupportcontours with fixed6/10mm normal offsets, and ONLY the underbelly angular sector1.65..2pi-1.65. Each of three55mm bands is a closedEuler2 U-shaped solid. Inner/outer contour paths are tessellated separately (ears in their simple supportsector), avoiding near-duplicate union-angle strips; all emitted caps/faces remain subject to actual checks. Not scalaroffsetsearch or arbitrary smoothing. Nominaloffsets do not prove actual pressure/continuousmotion clearance.

Six leathers start on six exact existingbar TOP patches (sixtriangles/eightvertices each). Reused serializedfloat32 points define their innerfeet.4mm outward thickness and original width/corridor transitions then lead below the quarter to copied band endcaps. Rightfoot diagonal is explicitly reversed to match the unchanged sourcebar triangulation. Each billet node contains three independent namedclosed components. No invented visible buckle/nail geometry or holdingstrength claim. Cut/thickness/spacing/connection surfaces remain original reconstruction.

Actual1833printed27–28 supports three little girthingleathers per side nailed to sidebars and girths 'generallythree'; a fourthsurcingle passes OVER the saddle. This describes a generalfamily, not a specificChicago object. No primarypagepixels/cut/dimension/optical attestation; no1902backdating/sourceID invention. NewgeometryoriginalCC0; exactsourcepredicate/contact/capture programs GPL3+ (fullnotice present).

## Fixed and changed authority

Authority517795 and recipeec719b remain BYTEEXACT to the eleven-layertrial. Caller hardpins both and compares every generated eleven-layer POSITION/NORMAL/index stream to hardpinned50463 before newconstruction. Actualreadback requires entire50463BIN/storageprefix and all elevenprimitive refs exact. Only riding_girth,billet_l,billet_r differ beyond those eleven baselineauthoredlayers; fifteen unrelatedmeshdefs, originalrig/reins/skins/nodes/materials/sockets/animations exactA457.29activeprimitivebatches;20explicit closedEuler2 components across14authoringmeshes.

Producer is stdlib; actualdecoded/self/assembly checks requireNumPy. Existing actualThree0.185.1capture remains the localapp-vendor researchbinding, not an installedportableapp dependency. No Blender/network/assetdownload/newruntimeframework.

## Exact boundary contacts, not pair exemptions

Independent `check_actual.py` derives twelve contacts FROM ACTUAL GLB: sixwoodfootpatches plus sixband/leathercaps. It checks exact vertices/triangles/opposing orientation, then emits validated-interfaces.json. Producer's proposedpacket is NOT the acceptanceauthority.

`check_assembly.py` independently rebinds those semanticpatches, aliases and sourceindices to actualgeometry/capture. Retains the UNCHANGED originalPythonSAT/proper bytes inherited from the prior selfchecks; no thresholdchange (1e-8SAT/touch, strictproper unchanged). The previous JS-only zero-contact wrapper is retired in this NEW sourceparcel; originaloldpackages stay immutable. Exactfulltriangle/edge/point boundary certificates are small `interface_contact.py`; allstrictproper intersections fail BEFORE certification. Reversing a certificate argument for cross-part edgeorientation alters no physical geometry. RawSAT and each admitted certificate remain stored, never reported as0rawSAT.

All301unorderedpartpairs (91changed/changed+210changed/fixed) and all14vsALL14172horsefaces remain tested, caps included. No broadcontact/excludedmesh cases. Everyclosedtarget first needs full actualselfembedding/vertexlink proof. Each contactpatch must be a disk, patches disjoint and the actualcomponent-minuspatches edgeconnected. Strict noncontactprobes permit winding; ambiguous nesting fails. Finalbandvertexstand-off summaries use ALLhorse triangles but are explicitly unsignedVERTEXsamples, not fulltriangleminimum/pressure acceptance.

## Prepared future actual trial — requires full source PASS first

1. RootCPUlane + independently reviewed executable sources/recipe/caller/certificates/guards.
2. `check_girth_negative.py A457 FRESH_NEGATIVE` and `check_panel_girth_negative.py OLD_8ce old-panel-girth-negative.json FRESH_NEGATIVE2`: actualoldinputbytes MUST reproduce originalclosure and alltenstoredpanel/girth proper witnesses. No cachedgreens.
3. ONE<=30s `build_candidate.py --gear-input A457 --horse-input 6e9b --horse-manifest MANIFEST --parameters saddle_sections.json --layer-control OLD_50463 --output-dir FRESH`.
4. `check_actual.py A457 NEW saddle_sections.json OLD_50463 FRESH_READBACK`; actualKhronos with externalfetchrefused, preserveallwarnings/infos. Inheritedtwo skinwarnings are notclean0warnings.
5. ExistingNodecapture HORSE A457 NEW FRESH_CAPTURE REVIEWED_NEW_SHA at actualidle0/headparentinverse/fullactiveprimitivecoverage.
6. `check_self.py CAPTURE NEW FRESH_SELF REVIEWED_NEW_SHA`: all29closedtargetclassifications/selfchecks,14newparts/20components; unchangedexactowned-simplexcertificates, no adjacencyskip.
7. `check_assembly.py CAPTURE NEW SELF/self.json READBACK/validated-interfaces.json FRESH_FIT REVIEWED_NEW_SHA`: all301thenwholehorse, rawcontacts/proper/certificates/nesting. FIRSTactualfailure STOP/preserve; no automaticretry or shapeparametersearch. Use oneCPUworker.
8. Only fulltechnicalPASS permits root-coordinated matchedbrowser. Currentapp/centralqueue untouched. Master/periodappearance/photographicquality/pressure/load/rider/skinforces/motion/newbody remainUNACCEPTED; root's8ceactualimages remain provisionalbarrel/flatmaterial evidence.
