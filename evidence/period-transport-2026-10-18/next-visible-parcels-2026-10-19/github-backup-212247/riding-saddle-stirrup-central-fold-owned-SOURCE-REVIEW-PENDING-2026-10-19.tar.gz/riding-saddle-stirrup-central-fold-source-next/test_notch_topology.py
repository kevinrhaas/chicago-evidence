# SPDX-License-Identifier: CC0-1.0
"""Synthetic rectangular stocks only; never reads actual model bytes."""
import json
from topology import shell
from stirrup_construction import notch,need
from source_interfaces import notch_face_keys

def run():
 rows=[];p={'z_stations_m':list(range(13)),'angular_segments':24}
 for side in('l','r'):
  top=[[j*.04,k*.01,.013]for j in range(13)for k in range(25)];bottom=[[x,y,0]for x,y,z in top];original=shell(top,bottom,13,25);candidate,ledger=notch(original,side,p)
  expected,deleted=notch_face_keys(original[2],side)
  need({frozenset(f)for f in candidate[2]}==expected,'Independent exact ownership')
  need(candidate[0]==[[__import__('struct').unpack('<f',__import__('struct').pack('<f',x))[0]for x in v]for v in original[0]],'Retained coordinate identity')
  need(len(deleted)==26 and sum(q['owner']=='new_notch_cap'for q in ledger['face_ledger'])==26,'Complete cap and deletion scope')
  rows.append({'side':side,'closed_Euler2':True,'removed_faces':26,'new_caps':26,'all_retained_coordinates_exact':True,'independent_triangle_ownership_exact':True})
 print(json.dumps({'passed':True,'scope':'Pure synthetic rectangular grids, no actual horse/gear/model evaluation','rows':rows},indent=2))

if __name__=='__main__':run()
