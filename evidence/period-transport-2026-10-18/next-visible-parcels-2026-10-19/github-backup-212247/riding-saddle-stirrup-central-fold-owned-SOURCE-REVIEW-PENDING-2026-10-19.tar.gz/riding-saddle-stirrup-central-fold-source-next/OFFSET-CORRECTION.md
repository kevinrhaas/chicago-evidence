# Source-only support-offset correction

Preserves every original support vertex/edge, the fixed 6/10 mm offsets, all eleven layer bytes and all qualification predicates. Replaces unstable two-line determinant division by the unit outward-normal bisector formula. Both incident support-plane residuals are checked independently within 64 float64 ULPs at the coordinate scale. Antiparallel/ill-conditioned miters refuse explicitly. This is floating-point engineering, not an exact-binary theorem.

Prior first build failed before export; archive 1c183a72db420d0a7ebad6c81ed8bcb2c1f32d9742869542df08db7dfc2706ac remains immutable. No actual hull/model evaluation or trial has run for this revision. Synthetic controls alone do not establish actual fit. Root must release any new actual trial after independent review.
