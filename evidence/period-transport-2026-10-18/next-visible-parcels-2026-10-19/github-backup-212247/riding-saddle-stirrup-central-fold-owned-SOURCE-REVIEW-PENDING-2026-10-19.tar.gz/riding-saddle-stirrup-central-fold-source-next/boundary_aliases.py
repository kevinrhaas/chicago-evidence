# SPDX-License-Identifier: GPL-3.0-or-later
"""Complete duplicate source rows at existing owned patch-boundary simplexes.

Original patch row coverage/disks remain unchanged. This supplemental catalog
adds no position, face, pair or tolerance. Exact vertex-only/owned boundary-edge
proofs remain mandatory AFTER the caller rejects every strict proper witness.
"""
import collections
from source_interfaces import alias_ids
from exact_contact import source_vertex_only,source_edge_only

def need(ok,message):
 if not ok:raise ValueError(message)
def decode_catalog(interface,AP,AF,BP,BF):
 """Recompute from complete actual decoded sources, never producer receipts."""
 aliases=interface['aliases'];byid={int(q['alias']):q for q in aliases};need(len(byid)==len(aliases),'Unique original alias ids');boundaries=[]
 for prefix,P,F in(('a',AP,AF),('b',BP,BF)):
  mapping={int(v):int(q['alias'])for q in aliases for v in alias_ids(q,prefix)}
  ids={int(v)for face in interface[prefix+'_faces']for v in F[face]};need(set(mapping)==ids,'Original exact patch-index coverage retained')
  for v,alias in mapping.items():need(tuple(map(float,P[v]))==tuple(byid[alias]['actual_point_m']),'Original source alias coordinates exact')
  counts=collections.Counter()
  for face in interface[prefix+'_faces']:
   tri=[mapping[int(v)]for v in F[face]]
   for u,v in zip(tri,tri[1:]+tri[:1]):counts[tuple(sorted((u,v)))]+=1
  need(all(n in(1,2)for n in counts.values()),'Source patch edge incidence')
  boundaries.append({edge for edge,n in counts.items()if n==1})
 need(boundaries[0]==boundaries[1]and bool(boundaries[0]),'Matching actual owned patch boundary edges')
 edges=sorted(boundaries[0]);vertices={v for edge in edges for v in edge};adj=collections.defaultdict(set)
 for a,b in edges:adj[a].add(b);adj[b].add(a)
 need(all(len(q)==2 for q in adj.values()),'Boundary vertex degree2');seen=set();todo=[next(iter(vertices))]
 while todo:
  v=todo.pop()
  if v in seen:continue
  seen.add(v);todo.extend(adj[v]-seen)
 need(seen==vertices,'Single existing boundary cycle')
 groups=[]
 for alias in sorted(vertices):
  point=tuple(byid[alias]['actual_point_m']);q={'alias':alias,'actual_point_m':list(point)}
  for prefix,P in(('a',AP),('b',BP)):
   rows=[i for i,p in enumerate(P)if tuple(map(float,p))==point];need(rows and set(alias_ids(byid[alias],prefix))<=set(rows),'Full exact duplicate group contains original owner rows');q[prefix+'_rows']=rows
  groups.append(q)
 return{'scope':'Existing registered exact patch-boundary positions and edges only; no new contact domain','boundary_edges':[list(q)for q in edges],'boundary_alias_groups':groups,'tolerance_used':False}

def validate_catalog(interface,AP,AF,BP,BF):
 need(interface['boundary_source_aliases']==decode_catalog(interface,AP,AF,BP,BF),'Independently decoded complete duplicate boundary ownership')

def certify_duplicates(a,b,indices_a,indices_b,part_a,part_b,interface,flipped):
 catalog=interface.get('boundary_source_aliases')
 if catalog is None:return None
 prefixA,prefixB=('b','a')if flipped else('a','b');groups=catalog['boundary_alias_groups']
 amap={v:q['alias']for q in groups for v in q[prefixA+'_rows']};bmap={v:q['alias']for q in groups for v in q[prefixB+'_rows']}
 baseA={v for q in interface['aliases']for v in alias_ids(q,prefixA)};baseB={v for q in interface['aliases']for v in alias_ids(q,prefixB)}
 if not(any(v in amap and v not in baseA for v in indices_a)or any(v in bmap and v not in baseB for v in indices_b)):return None
 la=[('boundary',interface['name'],amap[v])if v in amap else('source',part_a,v)for v in indices_a];lb=[('boundary',interface['name'],bmap[v])if v in bmap else('source',part_b,v)for v in indices_b];shared=set(la)&set(lb);proof=None;simplex=None
 if len(shared)==1:
  vertex=next(iter(shared));proof=source_vertex_only(a,b,la.index(vertex),lb.index(vertex));simplex={'kind':'existing_patch_boundary_vertex','aliases':[vertex[2]]}
 elif len(shared)==2:
  edge=sorted(v[2]for v in shared)
  if edge not in catalog['boundary_edges']:return None
  proof=source_edge_only(a,b,la,lb)
  if proof is None:
   proof=source_edge_only(a,b[[0,2,1]],la,[lb[i]for i in(0,2,1)])
   if proof is not None:proof={**proof,'certificate_argument_b_reversed':True}
  simplex={'kind':'existing_registered_patch_boundary_edge','aliases':edge}
 # Three common aliases never authorize an additional full triangle contact.
 if proof is None:return None
 return{'interface':interface['name'],'actual_boundary_contact':{**proof,'complete_exact_duplicate_source_rows':True,'owned_simplex':simplex}}
