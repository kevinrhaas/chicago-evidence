# SPDX-License-Identifier: CC0-1.0
"""Reproduce the old actual layer failure from pinned GLB, not cached green."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
from check_actual import load,array,need
PIN='b870ebe91fd59ef9214845119b3d3bee46461a8a22f12d788c318f3941dd12fe'
def run(glb,witnesses,out):
 out.mkdir();r={'passed':False,'scope':'Original b870 strict panel-interior negative witnesses, not whole SAT','witnesses':[]}
 try:
  d,b,raw=load(glb);need(hashlib.sha256(raw).hexdigest()==PIN,'Exact original b870 negative GLB');r['actual_input_sha256']=PIN
  wraw=witnesses.read_bytes();w=json.loads(wraw);need(w['candidate_sha256']==PIN,'Witness scope pin');r['witnesses_sha256']=hashlib.sha256(wraw).hexdigest();need(len(w['interior_witnesses'])==56,'Exact original56 witness cohort')
  def point(mesh,record):
   pr=d['meshes'][mesh]['primitives'][0];P=array(d,b,pr['attributes']['POSITION']).astype(float);F=array(d,b,pr['indices']).reshape(-1,3)if'indices'in pr else np.arange(len(P)).reshape(-1,3);ids=F[record['face']];need(list(map(int,ids))==record['vertex_ids'],'Actual canonical source face indices');tri=P[ids];need(np.array_equal(tri,np.array(record['triangle'])),'Actual source triangle coordinates');bary=np.array(record['barycentric']);need(abs(float(bary.sum())-1)<1e-12 and float(bary.min())>0,'Strict triangle interior barycentric');return bary@tri
  for row in w['interior_witnesses']:
   side=row['side'];q=row['quarter'];p=row['panel'];need(d['meshes'][q['mesh']]['name']=='quarter_'+side and d['meshes'][p['mesh']]['name']=='panel_'+side,'Semantic negative ownership');a=point(q['mesh'],q);lo=point(p['mesh'],p['lower']);hi=point(p['mesh'],p['upper']);need(np.max(abs(a[[0,2]]-lo[[0,2]]))<1e-12 and np.max(abs(a[[0,2]]-hi[[0,2]]))<1e-12,'Same actual interior column');depth=min(float(a[1]-lo[1]),float(hi[1]-a[1]));need(depth>1e-5,'Original strict interior failure must remain reproduced');r['witnesses'].append({'side':side,'quarter_face':q['face'],'panel_faces':[p['lower']['face'],p['upper']['face']],'actual_point_m':a.tolist(),'strict_interior_depth_m':depth})
  r['passed']=True
 except BaseException as e:r['error']=repr(e);raise
 finally:(out/'negative.json').write_text(json.dumps(r,indent=2)+'\n')
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('glb',type=Path);ap.add_argument('witnesses',type=Path);ap.add_argument('out',type=Path);a=ap.parse_args();run(a.glb,a.witnesses,a.out)
