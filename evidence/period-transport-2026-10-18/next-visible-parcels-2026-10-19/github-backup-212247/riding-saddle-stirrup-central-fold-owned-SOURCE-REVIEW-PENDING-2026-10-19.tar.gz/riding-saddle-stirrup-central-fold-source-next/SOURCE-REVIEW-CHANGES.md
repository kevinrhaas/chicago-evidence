# Delta from immutable periodicgirth47d18/8ce779/ba3e

Root approved14/15scope after74dad0plan and its independentreview.11layer Authority/recipe/predicategeometry remain byteexact. Replace the fullbackloop with three belowbody bands and sixleathers on existingmesh names. Only threeexistingprimitives change after the elevenlayers, no node/rig/rein/socket/material changes.

Actualwoodfeet use copiedTOPsurfacepatches, not the rejectedthick outerwallcap. Sixband/leatherendcaps share copiedactualpoints. Rightfootbottom triangulation matches the originalbar diagonal despite reversed path. Fullsource/actualserialization check required; no near-pointinterface aliasing.

Separateinner/outeroffsetcontour tessellation avoids adding nearlycoincident angularrows; fixedcontour6/10mm hypotheses unchanged. Noactualbodyconstruction evaluated.19syntheticcontrols (normally/-O) exercise exactcontactrefusals/patchdisks/supportclipping/eararea/closedgenericU/rightfootdiagonal/unsignedsamplemetric; they do not qualifyactualassets.

OldPythonSAT/proper/exact_contact bytes unchanged. Newall301checker uses those same retainedpredicates (as previousactualselfchecker), with explicit rawcontactclassification at twelvevalidatedinterfaces. OriginalJSed193source remains retained forprovenance; no silent claim that the oldzero-contactwrapper ran with newinterfaces. Actual301/wholehorse pending.

Independent source review caught multipart signed-winding cancellation. Narrow fix: evaluate absolute winding separately for every actual closed target component; any inside/ambiguous result fails. Synthetic opposite-nested-tetra control demonstrates aggregate0/percomponent1. No actualgeometry or SAT run.
