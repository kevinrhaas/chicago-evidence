# SPDX-License-Identifier: GPL-3.0-or-later
"""Exact declared boundary-contact certificates, not whole-pair exemptions.
Caller MUST run unchanged proper predicate first and reject every proper witness.
Validated actual serialized alias packets are mandatory; no proximity matching.
"""
from exact_contact import source_edge_only,source_vertex_only,cross,sub,dot
from source_interfaces import alias_ids
from boundary_aliases import certify_duplicates

def certify(a,b,indices_a,indices_b,part_a,part_b,face_a,face_b,interfaces):
 for interface in interfaces:
  flipped=False
  if (part_a,part_b)==(interface['a_mesh'],interface['b_mesh']):pass
  elif(part_b,part_a)==(interface['a_mesh'],interface['b_mesh']):flipped=True
  else:continue
  ak='b_vertex'if flipped else'a_vertex';bk='a_vertex'if flipped else'b_vertex'
  amap={i:q['alias']for q in interface['aliases']for i in alias_ids(q,'b'if flipped else'a')};bmap={i:q['alias']for q in interface['aliases']for i in alias_ids(q,'a'if flipped else'b')}
  la=[('interface',interface['name'],amap[v])if v in amap else('source',part_a,v)for v in indices_a]
  lb=[('interface',interface['name'],bmap[v])if v in bmap else('source',part_b,v)for v in indices_b]
  shared=set(la)&set(lb)
  if not shared:
   supplemental=certify_duplicates(a,b,indices_a,indices_b,part_a,part_b,interface,flipped)
   if supplemental is not None:return supplemental
   continue
  proof=None
  if len(shared)==3:
   af=interface['b_faces']if flipped else interface['a_faces'];bf=interface['a_faces']if flipped else interface['b_faces']
   if face_a not in af or face_b not in bf:continue
   if {tuple(map(float,p))for p in a}!={tuple(map(float,p))for p in b}:continue
   na=cross(sub(a[1],a[0]),sub(a[2],a[0]));nb=cross(sub(b[1],b[0]),sub(b[2],b[0]))
   if dot(na,nb)>=0:continue
   proof={'kind':'EXACT_registered_opposing_same_triangle_boundary','tolerance_used':False}
  elif len(shared)==2:
   proof=source_edge_only(a,b,la,lb)
   if proof is None:
    # Across two separately closed parts the common edge orientation may agree.
    # Reversing ONLY certificate argument order changes no physical geometry.
    proof=source_edge_only(a,b[[0,2,1]],la,[lb[i]for i in (0,2,1)])
    if proof is not None:proof={**proof,'certificate_argument_b_reversed':True}
  elif len(shared)==1:
   v=next(iter(shared));proof=source_vertex_only(a,b,la.index(v),lb.index(v))
  if proof is not None:return {'interface':interface['name'],'actual_boundary_contact':proof}
  supplemental=certify_duplicates(a,b,indices_a,indices_b,part_a,part_b,interface,flipped)
  if supplemental is not None:return supplemental
 return None
