# SPDX-License-Identifier: CC0-1.0
"""Central half-width top-bar contact facets, original source-owned geometry.

Retain every old expanded POSITION/NORMAL row and every unaffected face. Cut
each of the twenty original bar triangles at exact dyadic axial parameters
1/4,3/4, then round new points to Float32. Quantify this rounding explicitly;
the new facets are not claimed mathematically identical to the old surface.
No IO/model evaluation at import. Full physical qualification remains required.
"""
import math,struct
from fractions import Fraction

FOLD_ROWS=11
def need(ok,message):
 if not ok:raise ValueError(message)
def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
def quantize(q):return[f32(float(x))for x in q]
def vector(a,b):return[b[k]-a[k]for k in range(3)]
def cross(a,b):return[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def normal(tri):
 q=cross(vector(tri[0],tri[1]),vector(tri[0],tri[2]));length=math.sqrt(math.fsum(x*x for x in q));need(length>1e-12 and math.isfinite(length),'Nondegenerate source iron facet');return[x/length for x in q]
def cut(a,b,t):
 exact=[(1-t)*Fraction(float(x))+t*Fraction(float(y))for x,y in zip(a,b)];rounded=quantize(exact)
 return rounded,exact
def contact_faces(side):
 start=0 if side=='l'else 120
 return[start+5*j+k for j in range(10)for k in((2,3)if j%2==0 else(1,2))]

def rebuild(P,N,F,side):
 """Return revised indexed iron plus full provenance and exact contact rows."""
 need(side in('l','r')and len(P)==len(N)==420 and len(F)==140,'Exact inherited expanded seven-segment iron')
 need([tuple(map(int,f))for f in F]==[tuple(range(j,j+3))for j in range(0,420,3)],'Original fully expanded index order')
 P=[quantize(q)for q in P];N=[quantize(q)for q in N];V=[q[:]for q in P];VN=[q[:]for q in N];faces=[];ledger=[];start=0 if side=='l'else 120;quads=[];source_cuts=[];positions={}
 for k in range(10):
  t=[P[i]for i in F[start+2*k]];u=[P[i]for i in F[start+2*k+1]]
  need(t[0]==u[0]and t[2]==u[1],'Original source quad diagonal');quads.append((t[0],t[1],t[2],u[2]))
 # Quantized point values are computed from exact source edges in one fixed
 # direction; adjacent source triangles therefore share the SAME actual point.
 for k,(a,b,c,d)in enumerate(quads):
  for label,x,y in(('low',a,d),('diagonal',a,c),('high',b,c)):
   for value,t in(('quarter',Fraction(1,4)),('three_quarter',Fraction(3,4))):
    point,exact=cut(x,y,t);positions[(k,label,value)]=point;delta=[Fraction(v)-e for v,e in zip(point,exact)];source_cuts.append({'quad':k,'edge':label,'axial_t':str(t),'source_endpoints':[x,y],'exact_position':[str(e)for e in exact],'actual_float32_position':point,'exact_rounding_error_m':[str(v)for v in delta]})
 for k in range(9):
  for value in('quarter','three_quarter'):need(positions[(k,'high',value)]==positions[(k+1,'low',value)],'Original adjacent angular rows own exactly identical cut points')
 for oldface,indices in enumerate(F):
  if not start<=oldface<start+20:
   faces.append(tuple(map(int,indices)));ledger.append({'old_face':oldface,'region':'unchanged','actual_indices':list(map(int,indices))});continue
  j=oldface-start;k=j//2;a,b,c,d=quads[k];cq=positions[(k,'low','quarter')];ch=positions[(k,'low','three_quarter')];dq=positions[(k,'diagonal','quarter')];dh=positions[(k,'diagonal','three_quarter')];hq=positions[(k,'high','quarter')];hh=positions[(k,'high','three_quarter')]
  # Same source-triangle boundary order; five triangles replace each original.
  regions=[('outer_end',[a,b,hq,dq]),('central',[dq,hq,hh,dh]),('outer_end',[dh,hh,c])]if j%2==0 else[('outer_end',[a,dq,cq]),('central',[dq,dh,ch,cq]),('outer_end',[dh,c,d,ch])]
  source_normal=normal([P[i]for i in indices]);cache={tuple(P[i]):int(i)for i in indices}
  for region,polygon in regions:
   ids=[]
   for point in polygon:
    key=tuple(point)
    if key not in cache:cache[key]=len(V);V.append(point[:]);VN.append(quantize(source_normal))
    ids.append(cache[key])
   for t in range(1,len(ids)-1):
    tri=(ids[0],ids[t],ids[t+1]);need(math.fsum(x*y for x,y in zip(normal([V[i]for i in tri]),source_normal))>0,'Every new actual triangle preserves source material side');faces.append(tri);ledger.append({'old_face':oldface,'region':region,'actual_indices':list(tri)})
 need(len(faces)==220 and [i for i,q in enumerate(ledger)if q['region']=='central'and q['old_face']<start+10]==contact_faces(side),'Exact220face/20contact subdivision ownership')
 # Ck rows own each original radial station; Dk rows own the original source
 # diagonal between radial stations. Twenty complete actual contact triangles
 # require eleven rows, rather than flattening them to a ten-triangle patch.
 inner=[]
 for k in range(5):
  inner.append([positions[(k,'low','quarter')],positions[(k,'low','three_quarter')]])
  inner.append([positions[(k,'diagonal','quarter')],positions[(k,'diagonal','three_quarter')]])
 inner.append([positions[(4,'high','quarter')],positions[(4,'high','three_quarter')]])
 centers=[[math.fsum(q[index][axis]for q in quads)/10 for axis in range(3)]for index in(0,3)]
 max_error=max(math.sqrt(math.fsum(float(Fraction(x))**2 for x in q['exact_rounding_error_m']))for q in source_cuts)
 plane_residuals=[]
 for index,q in enumerate(ledger):
  if q['region']=='unchanged':continue
  tri=[P[i]for i in F[q['old_face']]];n=normal(tri)
  plane_residuals.extend(abs(math.fsum(n[k]*(V[v][k]-tri[0][k])for k in range(3)))for v in faces[index])
 packet={'side':side,'axial_cut_fractions':['1/4','3/4'],'fold_rows':FOLD_ROWS,'original_vertices_retained':420,'unchanged_source_faces':120,'actual_faces':220,'contact_faces':contact_faces(side),'face_ledger':ledger,'source_cuts':source_cuts,'maximum_new_point_rounding_error_m':max_error,'maximum_actual_point_old_facet_plane_residual_m':max(plane_residuals),'surface_mathematically_exact':False,'iron_bent_or_old_vertices_moved':False,'period_pattern_attested':False,'bar_centers':centers,'inner_contact_rows':inner,'nominal_central_fraction':.5,'actual_first_fold_width_m':math.dist(inner[0][0],inner[0][1])}
 return(V,VN,faces),packet
