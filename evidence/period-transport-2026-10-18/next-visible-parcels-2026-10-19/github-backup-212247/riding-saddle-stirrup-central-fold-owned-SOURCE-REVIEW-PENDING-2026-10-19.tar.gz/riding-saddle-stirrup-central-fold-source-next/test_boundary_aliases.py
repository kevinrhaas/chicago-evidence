# SPDX-License-Identifier: GPL-3.0-or-later
"""Synthetic exact duplicate-boundary owner/vertex/edge refusal controls."""
import copy,json
import numpy as np
from boundary_aliases import decode_catalog,validate_catalog,need
from interface_contact import certify
from official_fit_predicates import proper

def fixture(square=False):
 base=[[0.,0.,0.],[1.,0.,0.],[1.,1.,0.],[0.,1.,0.]]if square else[[0.,0.,0.],[1.,0.,0.],[0.,1.,0.]]
 A=base+copy.deepcopy(base)+[[0.,-1.,0.],[-1.,-1.,0.]];B=base+copy.deepcopy(base)+[[0.,0.,1.],[-1.,0.,1.]];n=len(base)
 FA=[(0,1,2),(0,2,3)]if square else[(0,1,2)];FB=[tuple(reversed(f))for f in FA];count=len(FA)
 FA+=[(n,len(A)-2,len(A)-1),(n,n+1,len(A)-2)];FB+=[(n,len(B)-2,len(B)-1),(n+1,n,len(B)-2)]
 q={'name':'owned','a_mesh':'A','b_mesh':'B','a_faces':list(range(count)),'b_faces':list(range(count)),'aliases':[{'alias':i,'actual_point_m':p,'a_vertex':i,'b_vertex':i}for i,p in enumerate(base)]};q['boundary_source_aliases']=decode_catalog(q,A,FA,B,FB)
 return np.asarray(A),np.asarray(FA),np.asarray(B),np.asarray(FB),q
def refuse(fn,label):
 try:fn()
 except ValueError:return label
 raise ValueError('Missing refusal '+label)
def main():
 controls=[];A,FA,B,FB,q=fixture();validate_catalog(q,A,FA,B,FB);controls.append('original patch coverage plus complete exact boundary groups')
 need(all(len(row['a_rows'])==len(row['b_rows'])==2 for row in q['boundary_source_aliases']['boundary_alias_groups']),'Every duplicate represented');controls.append('all exact duplicate rows')
 proof=certify(A[FA[1]],B[FB[1]],FA[1].tolist(),FB[1].tolist(),'A','B',1,1,[q]);need(proof and proof['actual_boundary_contact']['owned_simplex']['kind']=='existing_patch_boundary_vertex','Exact existing owner point only');controls.append('owned exact vertex fallback')
 proof=certify(A[FA[2]],B[FB[2]],FA[2].tolist(),FB[2].tolist(),'A','B',2,2,[q]);need(proof and proof['actual_boundary_contact']['owned_simplex']['kind']=='existing_registered_patch_boundary_edge','Exact existing boundary edge only');controls.append('owned exact edge fallback')
 need(certify(A[FA[1]],B[FB[1]],FA[1].tolist(),FB[1].tolist(),'wrong','B',1,1,[q])is None,'No new partpair');controls.append('unknown pair refusal')
 bad=copy.deepcopy(q);bad['boundary_source_aliases']['boundary_alias_groups'][0]['a_rows'].append(7);controls.append(refuse(lambda:validate_catalog(bad,A,FA,B,FB),'invented source row refusal'))
 bad=copy.deepcopy(q);bad['aliases'][0]['a_vertex']=7;controls.append(refuse(lambda:decode_catalog(bad,A,FA,B,FB),'original patch coverage preserved'))
 # Matching full triangles through duplicate ids remain unregistered faces.
 duplicate=[3,4,5];need(certify(A[duplicate],B[list(reversed(duplicate))],duplicate,list(reversed(duplicate)),'A','B',99,99,[q])is None,'No added triangle domain');controls.append('supplemental fulltriangle refusal')
 A,FA,B,FB,q=fixture(True);n=4;edgeA=[n,n+2,len(A)-2];edgeB=[n+2,n,len(B)-2]
 need(certify(A[edgeA],B[edgeB],edgeA,edgeB,'A','B',99,99,[q])is None,'Any two boundaryvertices are not automatically an owned boundaryedge');controls.append('unregistered diagonal edge refusal')
 # A shared owner point cannot hide a genuine transverse intersection.
 A,FA,B,FB,q=fixture();a=np.asarray([[0.,0.,0.],[1.,0.,0.],[0.,1.,0.]]);b=np.asarray([[0.,0.,0.],[.25,.25,-1.],[.25,.25,1.]])
 need(proper(a,b)is not None and certify(a,b,[3,6,7],[3,6,7],'A','B',99,99,[q])is None,'Strict proper never a point-only certificate');controls.append('proper crossing refusal')
 print(json.dumps({'passed':True,'scope':'Synthetic only; exact boundary certificates, no actual assets/models','count':len(controls),'controls':controls}))
if __name__=='__main__':main()
