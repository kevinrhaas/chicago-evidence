# SPDX-License-Identifier: GPL-3.0-or-later
"""Reproduce stored firstten original proper negatives from actual8ce bytes."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
from check_actual import load,array,need
from official_fit_predicates import sat,proper

def run(old,fixture,out):
 out.mkdir();r={'passed':False,'scope':'Original actual8ce panel/girth negative only','rows':[]}
 try:
  need(hashlib.sha256(fixture.read_bytes()).hexdigest()=='3bef96e5893d746fc9e10bdbfcba980393085fe72d118eaf92099b3ff8d44d62','Exact original storednegative fixture');d,b,raw=load(old);need(hashlib.sha256(raw).hexdigest()=='8ce7793bf776df7a1632202b849a41b06ef34ddeacfcae76c92891432d3ca7bc','Pinned oldperiodiccandidate');w=json.loads(fixture.read_text());need(w['input_sha256']==hashlib.sha256(raw).hexdigest()and len(w['first10_actual_pairs'])==10,'Originalnegativecohort')
  def triangles(name):
   pr=next(m for m in d['meshes']if m['name']==name)['primitives'][0];P=array(d,b,pr['attributes']['POSITION']).astype(float);F=array(d,b,pr['indices']).reshape(-1,3);return P[F]
  A=triangles(w['a_mesh']);B=triangles(w['b_mesh'])
  for p in w['first10_actual_pairs']:
   a=A[p['face_a']];bb=B[p['face_b']];need(np.array_equal(a,np.array(p['a']))and np.array_equal(bb,np.array(p['b'])),'Actualsourcefacecoordinates');witness=proper(a,bb);need(sat(a,bb)and witness is not None,'OriginalpropernegativeMUSTreproduce');r['rows'].append({'faces':[p['face_a'],p['face_b']],'proper':witness})
  r['passed']=True;r['input_sha256']=hashlib.sha256(raw).hexdigest()
 except BaseException as e:r['error']=repr(e);raise
 finally:(out/'negative.json').write_text(json.dumps(r,indent=2)+'\n')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('old',type=Path);p.add_argument('fixture',type=Path);p.add_argument('out',type=Path);a=p.parse_args();run(a.old,a.fixture,a.out)
