# SPDX-License-Identifier: GPL-3.0-or-later
"""Actual old ae0b material inversion is a negative control, never accepted fit."""
from pathlib import Path
import argparse,hashlib,json
import numpy as np
from check_actual import load,array,need
from frame_orientation import strip_guard

def run(old,out):
 out.mkdir();receipt={'passed':False,'scope':'Old failed ae0b frame/material-direction negative only; no replacement geometry or fit'}
 try:
  d,b,raw=load(old);need(hashlib.sha256(raw).hexdigest()=='ae0b84fca50d135dbd0d54c002fb054759c4ea9ae2ccb41595197d7feb545858','Exact first notch failure')
  def part(name):
   pr=next(m for m in d['meshes']if m['name']==name)['primitives'][0];P=array(d,b,pr['attributes']['POSITION']).astype(float);F=array(d,b,pr['indices']).reshape(-1,3)if'indices'in pr else np.arange(len(P)).reshape(-1,3);return P,F
  P,F=part('stirrup_leather_l');IP,IF=part('stirrup_l');lookup={frozenset(tuple(P[i])for i in f):j for j,f in enumerate(F)};rows=[]
  for face in range(10):
   a=IP[IF[face]];key=frozenset(tuple(q)for q in a);need(key in lookup,'Old copied iron face exists');fb=lookup[key];leaf=P[F[fb]];metal_normal=np.cross(a[1]-a[0],a[2]-a[0]);leaf_normal=np.cross(leaf[1]-leaf[0],leaf[2]-leaf[0]);need(float(np.dot(metal_normal,leaf_normal))>0,'Old material-side defect must reproduce')
   vertex=int(F[fb][0]);need(vertex%4 in(0,1),'Old contact inner ring ownership');outer=(vertex//4)*4+(3 if vertex%4==0 else 2);direction=P[outer]-P[vertex];need(float(np.dot(metal_normal,direction))>0 and float(np.dot(leaf_normal,direction))>0,'Old outward extrusion with inverted leather inner normal must reproduce');rows.append({'iron_face':face,'leather_face':fb,'actual_material_direction_m':direction.tolist()})
  error=None
  try:strip_guard(P.tolist(),'l')
  except ValueError as e:error=str(e)
  need(error is not None and error.startswith('Material frame inversion or unproved cell l/'),'New exact full-strip frame guard must reject old input')
  receipt.update(passed=True,input_sha256=hashlib.sha256(raw).hexdigest(),reproduced_material_defects=rows,exact_frame_refusal=error)
 except BaseException as error:receipt['error']=repr(error);raise
 finally:(out/'old-frame-negative.json').write_text(json.dumps(receipt,indent=2)+'\n')

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('old',type=Path);p.add_argument('out',type=Path);a=p.parse_args();run(a.old,a.out)
