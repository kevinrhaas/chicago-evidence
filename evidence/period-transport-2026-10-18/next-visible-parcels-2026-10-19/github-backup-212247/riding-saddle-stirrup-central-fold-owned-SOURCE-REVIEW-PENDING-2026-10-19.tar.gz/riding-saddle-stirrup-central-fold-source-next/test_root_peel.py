# SPDX-License-Identifier: CC0-1.0
"""Pure synthetic root peel schedule, ordering, normals and hull controls."""
import json,math,copy
from root_peel import need,verify_peel_order,certify_pairs,recompute_root_normals,root_normal_ids,f32
from station_ownership import schedule
from topology import finish

def refuse(fn,label):
 try:fn()
 except(ValueError,ZeroDivisionError):return label
 raise ValueError('Synthetic refusal missing: '+label)
def billet(angle,side):
 points=[[0.,0.,0.]for _ in range(192)];sign=1 if side=='l'else-1
 for i,z in((128,-.08),(129,-.04)):points[i]=[sign*.35*math.sin(angle),1.16+.35*math.cos(angle),z]
 return points
def cube(lo,hi):return[[x,y,z]for x in(lo[0],hi[0])for y in(lo[1],hi[1])for z in(lo[2],hi[2])]
def main():
 controls=[]
 for side in('l','r'):
  roots=[.47,.53];spec,boundary=verify_peel_order(roots,billet(.545,side),side);need(spec['initial'][1][0]==spec['return_peel_angle']==roots[1]+(roots[1]-roots[0])/8,'One explicit first return station')
  need(len(spec['branches'][1])-len(spec['initial'][1])==len(spec['common']),'Common phase unchanged');controls.append(side+' peel/order/common')
  controls.append(refuse(lambda:verify_peel_order(roots,billet(.533,side),side),side+' peel beyond actual billet boundary'))
  controls.append(refuse(lambda:verify_peel_order(roots,billet(.52,side),side),side+' reversed root ordering'))
 a=cube((0,0,0),(1,1,1));b=cube((2,0,0),(3,1,1));need(certify_pairs([a],[b])['cell_pairs']==1,'Exact hull gap');controls.append('strict hull gap')
 controls.append(refuse(lambda:certify_pairs([a],[cube((1,0,0),(2,1,1))]),'hull touch'))
 controls.append(refuse(lambda:certify_pairs([a],[cube((.5,0,0),(1.5,1,1))]),'hull overlap'))
 # Supporting-face fallback with overlapping XYZ intervals: parallel diagonal
 # prisms displaced across their thin perpendicular direction.
 def diagonal(shift):return[[u-v+shift,u+v-shift,z]for u in(0.,1.)for v in(0.,.1)for z in(0.,1.)]
 need(certify_pairs([diagonal(0.)],[diagonal(.5)])['passed'],'Supporting face strict separation');controls.append('rational supporting-face fallback')
 P=[];F=[]
 for j in range(6):P.extend([[0.,j/4,-.125],[0.,j/4,.125],[.125,j/4,.125],[.125,j/4,-.125]])
 for j in range(5):
  for k in range(4):
   a=4*j+k;b=4*j+(k+1)%4;F.extend([(a,b,b+4),(a,b+4,a+4)])
 F.extend([(0,2,1),(0,3,2),(20,21,22),(20,22,23)])
 P,N,F=finish(P,F);ids=root_normal_ids(len(P));observed=recompute_root_normals(P,F);expected=[[f32(x)for x in N[i]]for i in ids];need(observed==expected,'Actual dyadic geometry independently matches original finish normal sums');controls.append('four honest root normals')
 need(ids==[12,13,14,15]and len(observed)==4,'Narrow normal scope');controls.append('exact four-row normal scope')
 damaged=copy.deepcopy(P);damaged[16][0]+=.0625;need(recompute_root_normals(damaged,F)!=observed,'Incident geometry updates normals');controls.append('changed adjacent geometry changes normals')
 controls.append(refuse(lambda:recompute_root_normals([[0.,0.,0.]for _ in P],F),'degenerate actual normal'))
 print(json.dumps({'passed':True,'scope':'Synthetic source only; no actual assets or model evaluation','count':len(controls),'controls':controls}))
if __name__=='__main__':main()
