# SPDX-License-Identifier: CC0-1.0
"""Pure synthetic index/Z ownership controls; no actual model evaluation."""
import json
from station_ownership import verify_strip_faces,verify_upper_branches,need
from test_station_ownership import toy

def faces(mixed=False):
 out=[]
 def quad(a,b,c,d,alternate=False):return[(a,b,d),(b,c,d)]if alternate else[(a,b,c),(a,c,d)]
 for j in range(3):
  for k in range(4):
   a=4*j+k;b=4*j+(k+1)%4;out.extend(quad(a,b,b+4,a+4,mixed and(j+k)%2==0))
 out.extend(quad(0,1,2,3,mixed));out.extend(quad(12,13,14,15,not mixed));return out
def outcome(name,F,passed):
 error=None
 try:verify_strip_faces(F,16)
 except(ValueError,TypeError)as e:error=str(e)
 need((error is None)==passed,'Synthetic exact index outcome '+name);return{'case':name,'expected_PASS':passed,'observed_PASS':error is None,'error':error}
def run():
 rows=[outcome('legal_standard',faces(),True),outcome('legal_mixed_diagonals_and_caps',faces(True),True)]
 bad=faces();bad[0]=(0,1,9);rows.append(outcome('skipped_ring_refuses',bad,False))
 bad=faces();bad[0]=(0,1,7);rows.append(outcome('wrong_side_refuses',bad,False))
 bad=faces();bad[1]=bad[0];rows.append(outcome('duplicate_triangle_refuses',bad,False))
 rows.append(outcome('missing_face_refuses',faces()[:-1],False))
 bad=faces();bad[-1]=(0,4,8);rows.append(outcome('wrong_endcap_refuses',bad,False))
 bad=faces();bad[0]=(0,1,5.5);rows.append(outcome('noninteger_index_refuses',bad,False))
 for side in('l','r'):
  for branch in(0,1):
   points,spec=toy('common',side);nA,nB=map(len,spec['branches']);row=3+len(spec['initial'][0]) if branch==0 else 15+nA+nB+17-len(spec['initial'][1]);ring=points[4*row:4*row+4];zs=sorted(q[2]for q in ring)
   for q,z in zip(ring,zs):q[2]=z
   error=None
   try:verify_upper_branches(points,side)
   except ValueError as e:error=str(e)
   need(error is not None,'Same-multiset wrong per-edge width must refuse');rows.append({'side':side,'branch':branch,'case':'wrong_edge_order_same_multiset_refuses','refused':True,'error':error})
 print(json.dumps({'passed':True,'scope':'Synthetic index templates and altered toy Z ownership only; no actual model','rows':rows},indent=2))

if __name__=='__main__':run()
