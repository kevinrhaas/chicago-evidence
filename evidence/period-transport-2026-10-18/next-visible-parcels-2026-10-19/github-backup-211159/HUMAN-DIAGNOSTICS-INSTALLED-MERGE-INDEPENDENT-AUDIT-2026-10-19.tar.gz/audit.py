"""Read-only staged-tree/parent byte comparison; no tests or Git mutation."""
from pathlib import Path
import subprocess,json,hashlib
R=Path('/workspace/chicago');B=Path('/workspace/shared');A='2726042ad9ea217687fab5525529bdee21656011';T='25b92c95095b7f1ea2b7dee9487ee0f018a773f3'
def git(*args):return subprocess.check_output(['git','-C',str(R),*args])
def need(v,m):
 if not v:raise ValueError(m)
def tree(ref):
 result={}
 for entry in git('ls-tree','-r','-z',ref).split(b'\0'):
  if not entry:continue
  head,name=entry.split(b'\t',1);mode,kind,oid=head.split();result[name.decode('utf8','surrogateescape')]=(mode.decode(),oid.decode())
 return result
def index():
 result={}
 for entry in git('ls-files','--stage','-z').split(b'\0'):
  if not entry:continue
  head,name=entry.split(b'\t',1);mode,oid,stage=head.split();need(stage==b'0','unresolved stage');result[name.decode('utf8','surrogateescape')]=(mode.decode(),oid.decode())
 return result
def raw(ref,name):return git('show',ref+':'+name)
def staged(name):return git('show',':'+name)
def digest(b):return hashlib.sha256(b).hexdigest()
need(git('rev-parse','HEAD').decode().strip()==A and git('rev-parse','MERGE_HEAD').decode().strip()==T,'exact requested parents');base=git('merge-base',A,T).decode().strip();a,t,b=tree(A),tree(T),tree(base);i=index();allowed={'.github/workflows/chicago-4d-era-studies.yml','chicago/4d/tools/human_era_study_blend.py','chicago/4d/tools/human_era_study_common.py','chicago/4d/docs/STATUS.md','chicago/4d/docs/ROADMAP.md','chicago/4d/data/liberties.json','chicago/4d/docs/measurements/source_use_coverage.md','chicago/4d/docs/LIBERTIES.md'};rows=[];unexpected=[];both=[];extra=[]
for p in sorted(set(a)|set(t)|set(b)|set(i)):
 av,tv,bv,iv=a.get(p),t.get(p),b.get(p),i.get(p)
 if av==tv:expected=av;reason='both parents identical'
 elif av==bv:expected=tv;reason='transport-only change preserved'
 elif tv==bv:expected=av;reason='human-only change preserved'
 else:expected=None;reason='both parents changed';both.append(p)
 if expected!=iv:
  if p not in allowed:unexpected.append({'path':p,'reason':reason,'human':av,'transport':tv,'base':bv,'index':iv})
  else:extra.append(p)
 rows.append({'path':p,'reason':reason,'index':iv,'expected':expected,'extra_reviewed':p in allowed})
need(not unexpected,'unexpected non-parent differences '+str(unexpected));need(set(extra)==allowed,'exact eight intentional/derived/parentLIBmerge differences')
# The only new runtime-source edits are exactly the independently reviewed diagnostics.
py=[]
for name in ['human_era_study_blend.py','human_era_study_common.py']:
 p='chicago/4d/tools/'+name;f=B/'human-ci39314363829-diagnostics-next/proposed/tools'/name;need(staged(p)==f.read_bytes(),'diagnostics exact '+name);py.append({'path':p,'sha256':digest(staged(p))})
wf='.github/workflows/chicago-4d-era-studies.yml';old=raw(A,wf);new=staged(wf);find=b'- name: Build canonical masters and existing portable exports';replace=b'- name: Build canonical masters with failure diagnostics and portable exports';need(old.count(find)==1 and old.replace(find,replace)==new,'only workflow step name');need(b'push:\n    paths:\n      - ".github/workflows/chicago-4d-era-studies.yml"'in new,'ownfile-only trigger')
# Preserve ALL prior bytes, including invalidUTF8, not decoded/reencoded prose.
docs=[];append=None
for n in ['STATUS.md','ROADMAP.md']:
 p='chicago/4d/docs/'+n;oldA,oldT,now=raw(A,p),raw(T,p),staged(p);need(now.startswith(oldA)and now.startswith(oldT),'all parent document bytes as prefixes '+n);tail=now[len(oldA):];need(tail.startswith(b'\nActual CI39314363829 passed fixture verification, era identity/source checks and exact body reproduction, then failed during canonical authoring/export.')and b'The exception is not yet known.'in tail and b'threshold and all export gates remain unchanged'in tail,'honest appended note');need(append is None or append==tail,'same concise note in bothdocs');append=tail;docs.append({'path':p,'human_parent_bytes':len(oldA),'transport_parent_bytes':len(oldT),'merged_bytes':len(now),'human_prefix_exact':True,'transport_prefix_exact':True,'sha256':digest(now),'invalid_UTF8_in_prior':False})
 try:oldA.decode('utf8')
 except UnicodeDecodeError:docs[-1]['invalid_UTF8_in_prior']=True
# Source LIBERTIES is exactly the entire transport parent plus the human parent's
# independently appended L419 suffix, with no new source edits or allocations.
lib='chicago/4d/docs/LIBERTIES.md';baseLib=raw(base,lib);aLib=raw(A,lib);tLib=raw(T,lib);need(aLib.startswith(baseLib) and staged(lib)==tLib+aLib[len(baseLib):],'exact parent-only source liberty merge');need(staged(lib).count(b'### L419 ')==1,'L419 unique')
# Compiled liberties preserve every record from both parents, with canonical union count.
p='chicago/4d/data/liberties.json';la,lt,li=[json.loads(x)for x in[raw(A,p),raw(T,p),staged(p)]];ma={x['id']:x for x in la['liberties']};mt={x['id']:x for x in lt['liberties']};mi={x['id']:x for x in li['liberties']};need(len(mi)==len(li['liberties'])==li['count']==644,'644 unique compiled liberties');need(set(mi)==set(ma)|set(mt),'parent liberty union');need(all(mi[k]==v for k,v in ma.items())and all(mi[k]==v for k,v in mt.items()),'every prior compiled liberty record unchanged');need(li['count']==la['count']+2,'two mergedtransport liberties')
p='chicago/4d/docs/measurements/source_use_coverage.md';need(staged(p)==raw(A,p).replace(b'| liberties (structured citations) | 642 | 0 | 0 |',b'| liberties (structured citations) | 644 | 0 | 0 |'),'source use only canonical libertycount')
# Explicit human acceptance boundaries and unvalidated later skin not integrated.
protected=[]
for p,entry in a.items():
 if any(p.startswith(x)for x in ['chicago/4d/assets/authored/humans/era_studies/','chicago/4d/data/humans/recipes/era_studies/','chicago/4d/assets/authored/humans/skin_toigo_bronze/'])or p in ['chicago/4d/data/residents_1812/households/hh_kinzie_john_elder.json','chicago/4d/data/sidecars/1812/people.json','chicago/4d/tools/human_teamster_blend.py','chicago/4d/tools/human_export.sh']:
  need(i.get(p)==entry,'human source/identity/bronze/export changed '+p);protected.append(p)
need(not any('makehuman_age_labeled_skin'in p or p.endswith('human_era_skin_study.py')for p in i),'later mature-skin proposal unexpectedly installed');need(index()==i,'index stable throughout audit');worktree=subprocess.run(['git','-C',str(R),'diff','--quiet']).returncode;need(worktree==0,'unstaged tracked changes');counts={reason:sum(r['reason']==reason for r in rows)for reason in {r['reason']for r in rows}};index_id=digest(json.dumps(i,sort_keys=True,separators=(',',':')).encode())
report={'status':'PASS_READONLY_INSTALLED_MERGE_AUDIT','parents':{'human':A,'transport':T,'merge_base':base},'staged_index_entries':len(i),'staged_index_canonical_sha256':index_id,'index_stable_during_audit':True,'unstaged_tracked_changes':False,'parent_tree_classification_counts':counts,'nontrivial_parent_overlap_paths':both,'new_nonparent_difference_paths':extra,'unexpected_parent_losses_or_extra_changes':[],'reviewed_diagnostics_exact':py,'prior_peer_review_sha256':'5da692981b4f0022f92a2d1decd167b7ca3d46568c71cef62b4b2e9894af1c59','workflow':'Exactly one existing step-name replacement. Existing narrow own-YAML push trigger, all commands/gates/defaults/inputs/bounds unchanged.','docs':docs,'appended_note':append.decode('ascii'),'derived':{'source_liberties_exact_transport_bytes_plus_human_append':True,'L419_unique':True,'compiled_liberties_unique_count':644,'all_parent_liberty_records_exact':True,'source_use_only642_to644':True},'protected_human_paths':protected,'later_mature_skin_not_installed':True,'scope':'Finite Git tree/index/original byte comparison only; no test rerun, Blender/model/capture/browser, source edit, Git mutation or commit. Root preflight73176 remains a separate pending gate.'};out=B/'human-diagnostics-merged-installed-INDEPENDENT-REVIEW.json';out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'report':str(out),'sha256':digest(out.read_bytes()),'entries':len(i),'protected':len(protected),'nontrivial':both,'extra':extra,'classification':counts}))
