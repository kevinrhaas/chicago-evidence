# Immutable idle driving-girth comparison

This outside-app read-only comparison uses exact ab70 horse, baseline1fb25 rear-fitted gear and new43bc48a5 girth-only gear. Technical actual-three PASS must have a complete independent stored audit, and the full frozen visualization delta must independently pass before invoking the existing root-authorized <=150s browser window. No app, Git, motion, force or photographic acceptance.

The scene imports the exact reviewed v3 girth controller/evaluator/offset helper, plus immutable v5 root-binding/clipping dependencies via explicit hashed routes. No copies or patched controller imports. All other35 primitives remain unchanged, including qualified rear3. Before every rendered frame, current idle0 source geometry is evaluated by that same controller, then all36 installed position/normal and index streams must exactly equal the decoded qualified serialized arrays. All36 parts remain individually visible; only the complete inactive comparison version is toggled. Upper girth ends remain explicitly unbound, with all loose ends and existing hardware visible.

One unblended idle0 clip only. Same full actual CPU-deformed referenced union camera for each pair; strict2% complete union bounds. No manual framing/cropping/hidden parts. Cameras/pose/head-root bindings/GL errors/primitive callbacks/source index ownership are checked after rendering. CPU projection is not a proof of GPU skinning precision.

Eight PNGs: profile and rear quarter at1280×800 and390×780 for each baseline/fitted version. Full horse retained, so mobile local fit remains small. Keyboard/touch/reset, single model fetch, all3 fetched-byte corruption refusals, both viewport disposal/RAF and browser/server cleanup required. Source-control and served-file hashes bind actual output. Browser/server failures are fatal and terminal evidence is saved by nested cleanup.

Delta from qualified rear A/B framework: exact component/evidence/policy pins and manifest; full indexed girth controller dependency routes; all36 P/N/index equality; girth length/unbound readback; honest visible labels. Union camera, complete coverage, browser controls and bounded operator are unchanged. No new mesh file is generated or written by this visualization.

Source controls: node test_source.mjs, JavaScript/Python syntax; these do not launch Three/Chromium or an actual horse evaluator. make_manifest.py only decodes immutable file metadata/index bytes. freeze_source.py hashes exact source/inputs and the complete reviewed girth closure.

After independent frozen source PASS and browser-lane handoff:

```sh
taskset -c 0 /workspace/shared/chicago-venv/bin/python run_once.py --released-render-window --output /workspace/shared/horse-driving-girth-idle-ab-visual-actual-one
```

Existing root authorization covers routine bounded read-only A/B after technical PASS and independent source-delta review, without another permission round. Use the supported local-listener/Chromium execution profile. A first failure is preserved and diagnosed before any correction. Actual images require human assessment; no automatic visual/photo promotion.
