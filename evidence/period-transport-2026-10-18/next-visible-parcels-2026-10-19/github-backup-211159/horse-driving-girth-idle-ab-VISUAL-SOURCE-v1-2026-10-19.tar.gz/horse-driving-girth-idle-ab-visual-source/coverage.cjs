// SPDX-License-Identifier: GPL-3.0-or-later
const assert=require('node:assert/strict');
function canonical(rows){assert(Array.isArray(rows)&&rows.length>0,'Nonempty coverage');const seen=new Set();for(const r of rows){assert(Number.isInteger(r.sourceMesh)&&r.sourceMesh>=0&&Number.isInteger(r.sourcePrimitive)&&r.sourcePrimitive>=0,'Source primitive key');const key=r.sourceMesh+':'+r.sourcePrimitive;assert(!seen.has(key),'Duplicate source primitive');seen.add(key);}return [...rows].sort((a,b)=>a.sourceMesh-b.sourceMesh||a.sourcePrimitive-b.sourcePrimitive);}
function checkedCoverage(actual,expected){assert.deepEqual(canonical(actual),canonical(expected),'Complete keyed source primitive coverage');}
module.exports={checkedCoverage};
