// SPDX-License-Identifier: GPL-3.0-or-later
// Wholly synthetic bindings/arrays only. No horse/gear model parsed or rendered.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import * as T from '/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/three.module.js';
import {bindWorld} from './gear_binding.mjs';
const folder=new URL('.',import.meta.url),rows=[];
const original=fs.readFileSync('/workspace/shared/horse-rear-harness-current-support-source/controller.mjs','utf8').split('\n').find(x=>x.startsWith('export function bindWorld('));
assert.equal(fs.readFileSync(new URL('gear_binding.mjs',folder),'utf8').split('\n').find(x=>x.startsWith('export function bindWorld(')),original);
rows.push({case:'Exact previously reviewed bindWorld function bytes',PASS:true});
for(const kind of ['unparented','translated-parent','rotated-scaled-parent']){
 const parent=new T.Group(),child=new T.Group();
 if(kind!=='unparented'){parent.position.set(2,-1,.7);if(kind==='rotated-scaled-parent'){parent.rotation.set(.1,.3,-.2);parent.scale.setScalar(1.25);}parent.add(child);parent.updateMatrixWorld(true);}
 const target=new T.Matrix4().compose(new T.Vector3(-.3,1.8,.9),new T.Quaternion().setFromEuler(new T.Euler(.2,-.1,.3)),new T.Vector3(1,1,1));
 bindWorld(child,target);const error=Math.max(...child.matrixWorld.elements.map((v,i)=>Math.abs(v-target.elements[i])));assert(error<=128*Number.EPSILON*Math.max(1,...target.elements.map(Math.abs)));rows.push({case:kind,PASS:true});
}
const invalid=new T.Matrix4();invalid.elements[0]=NaN;assert.throws(()=>bindWorld(new T.Group(),invalid));rows.push({case:'Nonfinite synthetic target rejected',PASS:true});
const scene=fs.readFileSync(new URL('scene.mjs',folder),'utf8'),functionText=scene.slice(scene.indexOf('function verifyGearArrays(){'),scene.indexOf('\nfunction framing(){'));
assert(functionText.startsWith('function verifyGearArrays(){')&&!functionText.includes('function framing'));
const verify=new Function('gearArrays','surfaces',functionText+';return verifyGearArrays();'),gearArrays=new Map(),surfaces={gear:[]};
for(let i=0;i<36;i++){const object={geometry:{attributes:{position:{array:new Float32Array([i,1,2])},normal:{array:new Float32Array([0,1,0])}}}},row={name:'synthetic-'+i};surfaces.gear.push({object,row});gearArrays.set(object,{position:object.geometry.attributes.position.array.slice(),normal:object.geometry.attributes.normal.array.slice()});}
assert.equal(Object.keys(verify(gearArrays,surfaces)).length,36);rows.push({case:'Exact36 wholly synthetic arrays accepted',PASS:true});
surfaces.gear[0].object.geometry.attributes.position.array[0]=999;assert.throws(()=>verify(gearArrays,surfaces));surfaces.gear[0].object.geometry.attributes.position.array[0]=0;rows.push({case:'Synthetic position mutation rejected',PASS:true});
surfaces.gear[1].object.geometry.attributes.normal.array[0]=1;assert.throws(()=>verify(gearArrays,surfaces));surfaces.gear[1].object.geometry.attributes.normal.array[0]=0;rows.push({case:'Synthetic normal mutation rejected',PASS:true});
gearArrays.delete(surfaces.gear[35].object);assert.throws(()=>verify(gearArrays,surfaces));rows.push({case:'Missing synthetic part rejected',PASS:true});
const study=JSON.parse(fs.readFileSync(new URL('study.json',folder),'utf8')),captured=JSON.parse(fs.readFileSync('/workspace/shared/horse-natural-labial-corner-three-primitives-next/idle-fit/capture/candidate.json','utf8')),keys=['name','sourceMesh','sourcePrimitive','positionCount','indexCount','indexed','indexStreamSHA256'];
assert.equal(captured.input[1],study.components.gear.sha256);const actualRows=captured.meshes.map(r=>Object.fromEntries(keys.map(k=>[k,r[k]])));assert.notDeepEqual(actualRows,study.components.gear.primitives);assert.deepEqual([...actualRows].sort((a,b)=>a.sourceMesh-b.sourceMesh||a.sourcePrimitive-b.sourcePrimitive),study.components.gear.primitives);rows.push({case:'Actual stored36 metadata order differs; canonical source-key comparison matches every field',PASS:true});
fs.writeFileSync(new URL('SOURCE-CONTROLS.json',folder),JSON.stringify({PASS:true,scope:'Wholly synthetic source tests, no actual model/XYZ/render/browser',controls:rows},null,2),{flag:'wx'});
console.log(JSON.stringify({PASS:true,controls:rows.length}));
