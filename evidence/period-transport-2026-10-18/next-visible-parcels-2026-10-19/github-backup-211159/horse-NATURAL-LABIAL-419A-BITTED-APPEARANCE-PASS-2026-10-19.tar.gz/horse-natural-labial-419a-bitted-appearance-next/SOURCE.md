# Bitted798e/419a comparison — SOURCE ONLY, NOT RUN

Root authorizes one<=150s read-only capture AFTER full frozen independent source
PASS and freebrowserlane. This adds exact fe76 all36gear to the actually exercised
union-camera framework9d92/actual8c2b. Source before798e and after419a are unchanged;
both have actual complete idle structural/all36fe76gear/fullbit qualification.
The419a full operator30.172s and independent stored685774a8 remain engineering
ONLY. No new geometry, evaluator, pose sweep, model export or asset promotion.

Load/verify the third fetched exact fe76 GLB buffer, reject external resource
URIs, and parse that SAME buffer using the same canonical /vendor Three module.
All36 gear source/index manifests are derived directly from immutable GLB JSON
and indices. checkedSurfaces validates every actual source association and full
drawRange/indexstream; gear coverage is explicitly canonicalized by source mesh/
primitive, because actual scene traversal differs from mesh-array order. Six
horse callbacks plus36gear callbacks are mandatory on EVERY fresh draw. All
individual meshes have frustumculling disabled; detail view honestly labels
head/body cropped, with full geometries submitted (hardware clipping allowed).

Copied unchanged reviewed bindWorld from rear controller, now a small local
helper without evaluator/alternateThree import. Apply parent-inverse world
attachment to actual gear root and harness_head from actual selected horse root/
head, matching the qualified idle capture matrices EXACTLY. Postdraw readback
checks actual gear matrices against horse and saved qualification, with original
128machineepsilon representability bound. Runner separately queries those matrix
objects and compares receipts and exact A/B frames/bindings. Static gear must
have no animation and exactly36parts. Snapshot all36 position/normal arrays at
load; postdraw require every scalar remains exact. No procedural support solver,
mesh displacement, material or source-field change is permitted. The fixed fe76
variant is used, never the newer rear strap parcel qualified on another horse.

The existing shared camera fits union of BOTH horses and actual selected gear
points with unchanged5%fit/2%postdraw guards. Same targets/orthographic rules,
lighting/material handling, idle0/freshframes and exact A/B camera/projection
checks. allPointCount/bounds include the actual gear. Request each component
once; keep keyboard/tap/reset and header/canvas controls. A new gear-buffer
corruption negative supplements the two horse-buffer corruptions and pending
fetch disposal: FOUR negatives total. Release staticgear on all disposal paths;
check disposal after asynchronous coverage and clear retained array snapshots.
Existing browser/server teardown105s, loop110s, external150s and freshoutput
remain. Failure-state diagnostics retain lastSUCCESSFUL receipt without treating
it as a new draw. No retry or hidden alternate view on failure.

Ten source-only controls passed: exact copied binding function; three wholly
synthetic parent transforms; nonfinite target rejection;36 wholly synthetic array
copies accepted; position/normal/missingpart rejected; actual STORED36capture
metadata permutation reproduces the earlier order trap and matches the canonical
source manifest. No actual model was parsed/rendered in these controls. Source
syntax checks pass. Existing camera/draw/disposal helpers remain byte-identical.

Schedule eight PNG: before/after × profile/quarter ×1280x900/390x844. The previously
saved complete horse-only8c2b images remain visible evidence of the drilled empty
portal/faceted muzzle. Actual metal occupying its physical opening is expected;
it does NOT alone establish natural tissue or photographic quality. Root and
author must actually inspect both horse-only and bitted frames. No additional
occluder, paint, texture, shader or contact-tolerance waiver. Photographic/era/
motion/pressure/jawopening/unbitted acceptance remains OPEN. Newly acquired modern
lip photographs are reference-only and are NOT used as textures in this viewer.
