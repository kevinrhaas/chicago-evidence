// SPDX-License-Identifier: GPL-3.0-or-later
// bindWorld copied unchanged from the independently reviewed rear-harness
// controller.mjs. No dynamic support evaluator or alternate Three import.
const need=(v,m)=>{if(!v)throw Error(m);};
export function bindWorld(object,target){const local=object.parent?object.parent.matrixWorld.clone().invert().multiply(target):target.clone();local.decompose(object.position,object.quaternion,object.scale);object.updateMatrixWorld(true);const err=Math.max(...object.matrixWorld.elements.map((v,i)=>Math.abs(v-target.elements[i])));need(err<=128*Number.EPSILON*Math.max(1,...target.elements.map(Math.abs)),'Actual parent-inverse world binding');}
