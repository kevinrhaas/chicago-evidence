# SPDX-License-Identifier: CC0-1.0
"""Paired lower leather construction from quantized, immutable endpoint rows.

Original engineering reconstruction, not a measured period pattern. Support
placement is not a collision waiver: exact cell enclosure and full 3D physical
checks remain mandatory. No asset IO or model evaluation occurs at import.
"""
import math,struct,itertools,json
from pathlib import Path
from fractions import Fraction
from station_ownership import schedule,root_angles_from_rings

THICK=.004
WIDTH=.025
INTERVALS=13
PAIRED_INTERVALS=12

def need(ok,message):
 if not ok:raise ValueError(message)
def add(a,b):return[x+y for x,y in zip(a,b)]
def sub(a,b):return[x-y for x,y in zip(a,b)]
def scale(a,t):return[x*t for x in a]
def dot(a,b):return math.fsum(x*y for x,y in zip(a,b))
def unit(a):
 n=math.sqrt(dot(a,a));need(math.isfinite(n)and n>1e-12,'Nonzero finite lower frame');return scale(a,1/n)
def mix(a,b,t):return[x*(1-t)+y*t for x,y in zip(a,b)]
def f32(v):return struct.unpack('<f',struct.pack('<f',v))[0]
def quantize(ring):return[[f32(x)for x in point]for point in ring]
def midpoint(ring):return[math.fsum(p[k]for p in ring)/4 for k in range(3)]
def frame(ring):
 w=sub(ring[1],ring[0]);n=sub(ring[3],ring[0]);return unit(w),unit(n),math.sqrt(dot(w,w))
def section(mid,w,n,width):
 # Material midpoint, not inner-face midpoint, owns paired separation.
 c=sub(mid,scale(n,THICK/2));a=sub(c,scale(w,width/2));b=add(c,scale(w,width/2))
 return[a,b,add(b,scale(n,THICK)),add(a,scale(n,THICK))]
def support(w,n,width,axis):return width*abs(dot(axis,w))/2+THICK*abs(dot(axis,n))/2

def paired_rows(starts,ends):
 """Thirteen rows ending at the immutable fold-adjacent source anchor.

 At each common station a separating direction interpolated from the actual
 paired endpoint material-midpoint deltas separates both complete rectangular
 sections. Spacing is their projected support-radius sum plus an endpoint-
 derived gap. Copying a near-fold anchor introduces no arbitrary normal jump.
 """
 need(len(starts)==len(ends)==2,'Two paired lower legs')
 starts=[quantize(q)for q in starts];ends=[quantize(q)for q in ends]
 sf=[frame(q)for q in starts];ef=[frame(q)for q in ends]
 sm=[midpoint(q)for q in starts];em=[midpoint(q)for q in ends]
 centers=[scale(add(*sm),.5),scale(add(*em),.5)]
 endpoint_axes=[unit(sub(pair[0],pair[1]))for pair in(sm,em)]
 gaps=[]
 for frames,mids,axis in((sf,sm,endpoint_axes[0]),(ef,em,endpoint_axes[1])):
  # Actual projected endpoint material intervals own the available gap.
  ext=sum(support(w,n,width,axis)for w,n,width in frames)
  gap=dot(sub(mids[0],mids[1]),axis)-ext
  need(math.isfinite(gap)and gap>0,'Strict positive actual endpoint material gap');gaps.append(gap)
 rows=[[starts[0]],[starts[1]]];axes=[endpoint_axes[0]]
 for j in range(1,PAIRED_INTERVALS):
  t=j/PAIRED_INTERVALS;frames=[]
  for branch in(0,1):
   wa,na,widtha=sf[branch];wb,nb,widthb=ef[branch]
   w=unit(mix(wa,wb,t));n=mix(na,nb,t);n=unit(sub(n,scale(w,dot(w,n))))
   frames.append((w,n,widtha*(1-t)+widthb*t))
  axis=unit(mix(endpoint_axes[0],endpoint_axes[1],t));axes.append(axis);gap=gaps[0]*(1-t)+gaps[1]*t
  distance=sum(support(w,n,width,axis)for w,n,width in frames)+gap
  common=mix(centers[0],centers[1],t)
  for branch,(w,n,width)in enumerate(frames):
   mid=add(common,scale(axis,distance*(.5 if branch==0 else-.5)))
   rows[branch].append(quantize(section(mid,w,n,width)))
 rows[0].append(ends[0]);rows[1].append(ends[1]);axes.append(endpoint_axes[1])
 return rows,axes,{'intervals':INTERVALS,'endpoint_projected_material_gaps_m':gaps,'spacing_rule':'sum of both complete projected material support radii plus actual endpoint-gap interpolation','period_pattern_attested':False}

def anchor_rows(side):
 packet=json.loads(Path(__file__).with_name('fold-adjacent-anchors.json').read_text())
 need(packet['input_sha256']=='f644710ddd19a1be3deee594278bde550b744ea2d2c013e4388c2586145bb8b6','Pinned prior anchor source identity')
 q=packet['sides'][side];return[q['outgoing'],q['return']]
def complete_rows(starts,anchors,ends):
 rows,axes,rule=paired_rows(starts,anchors)
 for branch in(0,1):rows[branch].append(quantize(ends[branch]))
 axes.append(frame(quantize(ends[0]))[1]);rule.update(paired_intervals=PAIRED_INTERVALS,fixed_final_cells=2,fold_adjacent_geometry_preserves_fold_normals=True)
 return rows,axes,rule

def exact_axis(axis):
 need(len(axis)==3 and all(math.isfinite(x)for x in axis)and any(x!=0 for x in axis),'Finite nonzero separating axis')
 return tuple(Fraction(float(x))for x in axis)
def interval(points,axis):
 values=[sum(x*y for x,y in zip(point,axis))for point in points];return min(values),max(values)
def hull_face_axes(points):
 # Every supporting plane through three actual vertices is a sufficient
 # candidate axis. This avoids treating adjoining Y ranges as overlap merely
 # because their end stations share a Y value. No predicate epsilon is used.
 axes=set()
 for i,j,k in itertools.combinations(range(len(points)),3):
  a=sub(points[j],points[i]);b=sub(points[k],points[i]);axis=(a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
  if not any(axis):continue
  values=[sum(x*y for x,y in zip(sub(p,points[i]),axis))for p in points]
  if min(values)<0<max(values):continue
  pivot=next(x for x in axis if x);axes.add(tuple(x/pivot for x in axis))
 return sorted(axes)
def certify_cell_hulls(first,second,axes):
 """Sufficient strict separation of every 8-vertex lower cell enclosure.

 Exact dyadic projections on finite declared axes may refuse separated cells;
 they can never certify overlapping convex hulls. This does not replace full
 triangle self/assembly/horse checks, including all upper/lower comparisons.
 """
 need(len(first)==len(second)==INTERVALS+1,'Fourteen actual lower rows per leg')
 directions=[exact_axis(q)for q in((1.,0.,0.),(0.,1.,0.),(0.,0.,1.),*axes)]
 cells=[]
 for branch in(first,second):
  cells.append([[tuple(Fraction(float(x))for x in p)for row in branch[j:j+2]for p in row]for j in range(INTERVALS)])
 projected=[[[interval(cell,axis)for axis in directions]for cell in branch]for branch in cells]
 faces=[[None]*INTERVALS for _ in range(2)];owned=[]
 for i,a in enumerate(projected[0]):
  for j,b in enumerate(projected[1]):
   separators=[k for k,(x,y)in enumerate(zip(a,b))if x[1]<y[0]or y[1]<x[0]]
   if separators:owned.append({'kind':'declared','axis':separators[0]});continue
   for branch,index in((0,i),(1,j)):
    if faces[branch][index]is None:faces[branch][index]=hull_face_axes(cells[branch][index])
   axis_found=None
   for axis in faces[0][i]+faces[1][j]:
    x=interval(cells[0][i],axis);y=interval(cells[1][j],axis)
    if x[1]<y[0]or y[1]<x[0]:axis_found=axis;break
   need(axis_found is not None,'Strict actual lower cell-hull separation '+str(i)+'/'+str(j));owned.append({'kind':'actual_supporting_face','axis':[str(x)for x in axis_found]})
 return{'passed':True,'scope':'Every paired lower-cell convex enclosure strictly separated on an exact rational declared/supporting-face axis; sufficient only, full physical scans still mandatory','cell_pairs':INTERVALS**2,'declared_axis_count':len(directions),'separators':owned}

def verify_lower(points,side):
 spec=schedule(root_angles_from_rings(points,side));nA,nB=map(len,spec['branches']);lo=15+nA
 need(len(points)==4*(36+nA+nB),'Exact current strip row count')
 def ring(i):return[[float(x)for x in p]for p in points[4*i:4*i+4]]
 first=[ring(i)for i in range(lo-INTERVALS,lo+1)]
 second=[ring(i)for i in range(lo+INTERVALS+5,lo+4,-1)]
 anchors=anchor_rows(side)
 need(first[-2]==anchors[0]and second[-2]==anchors[1],'Actual fold-adjacent fixed source anchor rows')
 expected,axes,rule=complete_rows([first[0],second[0]],anchors,[first[-1],second[-1]])
 need(first==expected[0]and second==expected[1],'Exact quantized paired lower source ownership from actual immutable endpoint rows')
 return{'passed':True,'first_rows':[lo-INTERVALS,lo],'return_rows':[lo+INTERVALS+5,lo+5],**rule,'exact_cell_enclosures':certify_cell_hulls(first,second,axes)}
