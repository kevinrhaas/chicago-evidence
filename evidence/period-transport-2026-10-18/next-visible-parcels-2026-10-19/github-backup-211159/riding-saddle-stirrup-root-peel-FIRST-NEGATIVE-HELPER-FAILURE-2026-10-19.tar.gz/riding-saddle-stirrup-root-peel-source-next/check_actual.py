# SPDX-License-Identifier: CC0-1.0
"""Actual decoded storage, active authored frame and twentytwo closed section shells."""
from pathlib import Path
import argparse,hashlib,json,struct,collections,math
import numpy as np
from layer_authority import CHANGED as LAYER_CHANGED,validate
from source_interfaces import notch_face_keys,expected_interface_source,new_interface_names
from frame_orientation import strip_guard
from root_peel import verify_return_exit,recompute_root_normals,root_normal_ids
from lower_connector import verify_lower,anchor_rows
from station_ownership import verify_upper_branches,verify_strip_faces
CHANGED=LAYER_CHANGED|{'riding_girth','billet_l','billet_r','stirrup_leather_l','stirrup_leather_r'}
AMENDED={'jockey_l','jockey_r'}

def need(ok,msg):
 if not ok:raise ValueError(msg)
def load(p):
 raw=p.read_bytes();need(struct.unpack_from('<III',raw)==(0x46546c67,2,len(raw)),'GLB header');n,t=struct.unpack_from('<II',raw,12);need(t==0x4e4f534a,'JSON type');size,t=struct.unpack_from('<II',raw,20+n);need(t==0x004e4942 and 28+n+size==len(raw),'BIN type/length');return json.loads(raw[20:20+n]),raw[28+n:],raw
def array(d,b,i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];need('byteStride'not in v and'sparse'not in a,'Plain accessor');dtype={5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']];c={'SCALAR':1,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];return np.frombuffer(b,dtype=dtype,count=a['count']*c,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,c)
def topology(P,F,expected_euler=2):
 need(len(P)>0 and len(F)>0 and int(F.min())>=0 and int(F.max())<len(P),'Component bounds');edges=collections.defaultdict(list);adj=collections.defaultdict(set)
 for f in F:
  need(len(set(f))==3,'Repeated triangle ID')
  for u,v in zip(f,np.roll(f,-1)):u=int(u);v=int(v);edges[tuple(sorted((u,v)))].append((u,v));adj[u].add(v);adj[v].add(u)
 need(all(len(e)==2 and e[0]==e[1][::-1]for e in edges.values()),'Closed opposite edges');seen=set();todo=[0]
 while todo:
  i=todo.pop()
  if i in seen:continue
  seen.add(i);todo.extend(adj[i]-seen)
 need(len(seen)==len(P) and len(P)-len(edges)+len(F)==expected_euler,'Connected declared Euler');A=P[F];cross=np.cross(A[:,1]-A[:,0],A[:,2]-A[:,0]);area=np.linalg.norm(cross,axis=1)/2;need(float(area.min())>1e-11,'Actual nondegenerate triangle');volume=float(np.einsum('ij,ij->i',A[:,0],np.cross(A[:,1],A[:,2])).sum()/6);need(volume>0,'Actual outward volume');return {'vertices':len(P),'triangles':len(F),'minimum_area_m2':float(area.min()),'volume_m3':volume,'Euler':expected_euler}

def connected_components(P,F):
 adjacency=collections.defaultdict(set)
 for face in F:
  for a in face:adjacency[int(a)].update(map(int,face))
 seen=set();out=[]
 for i in range(len(P)):
  if i in seen:continue
  todo=[i];vertices=set()
  while todo:
   j=todo.pop()
   if j in vertices:continue
   vertices.add(j);todo.extend(adjacency[j]-vertices)
  seen.update(vertices);ids=sorted(vertices);faces=[j for j,f in enumerate(F)if int(f[0])in vertices];need(all(all(int(v)in vertices for v in F[j])for j in faces),'Whole component faces');need(ids==list(range(ids[0],ids[-1]+1))and faces==list(range(faces[0],faces[-1]+1)),'Contiguous authored component ranges')
  out.append({'vertex_start':ids[0],'vertex_count':len(ids),'face_start':faces[0],'face_count':len(faces),'Euler':2})
 return out

def check(oldpath,newpath,params,layer_control,route_control,peel_control,out):
 out.mkdir();r={'passed':False,'scope':'Actual decoded16/13, nine exact layerrefs/two notches,22components and eighteen registered interfaces; no fit/load/photo acceptance'}
 try:
  old,ob,raw=load(oldpath);d,b,nraw=load(newpath);p=json.loads(params.read_text());validate(p);need(hashlib.sha256(raw).hexdigest()=='a457874a81b624f5e9642d3296b1350eb49b17d21d38099fbe66080711c17021','A457 input');r['candidate_sha256']=hashlib.sha256(nraw).hexdigest()
  previous,pb,praw=load(layer_control);need(hashlib.sha256(praw).hexdigest()=='50463c358935677ce0413ae58006dba9df1cfadf21b477df18492042bd1683b5','Actual prior elevenlayer control');need(b[:len(pb)]==pb and d['accessors'][:len(previous['accessors'])]==previous['accessors']and d['bufferViews'][:len(previous['bufferViews'])]==previous['bufferViews'],'Entire50463 BIN/storage prefix exact')
  prior_route,routebin,routebytes=load(route_control);need(hashlib.sha256(routebytes).hexdigest()=='f644710ddd19a1be3deee594278bde550b744ea2d2c013e4388c2586145bb8b6','Actual preceding frame study')
  prior_peel,peelbin,peelraw=load(peel_control);need(hashlib.sha256(peelraw).hexdigest()=='6cb6addf7cc11ac18a12d7786b082574c70ad5ea988cfaa60a9537a6e299302c','Exact actual preceding paired-lower study')
  for k in ('nodes','skins','animations','materials','scenes','scene'):need(d.get(k)==old.get(k),'Protected '+k)
  need(len(d['meshes'])==len(old['meshes'])==29,'Exact29primitive cohort');parts={};protected=[];total=0;ranges={};reports={}
  for om,nm in zip(old['meshes'],d['meshes']):
   name=om['name'];need(nm['name']==name,'Mesh name/order');need(len(nm['primitives'])==1,'One primitive per part');pr=nm['primitives'][0];P=array(d,b,pr['attributes']['POSITION']).astype(float);F=array(d,b,pr['indices']).reshape(-1,3)if'indices'in pr else np.arange(len(P)).reshape(-1,3);total+=len(F)
   control_mesh=next(m for m in prior_route['meshes']if m['name']==name);cp=control_mesh['primitives'][0]
   if not name.startswith('stirrup_leather_'):
    need(nm==control_mesh,'All27non-stirrup primitives exact preceding study '+name)
    for semantic,accessor in pr['attributes'].items():need(array(d,b,accessor).tobytes()==array(prior_route,routebin,cp['attributes'][semantic]).tobytes(),'All27actual attribute streams exact '+name+'/'+semantic)
    if'indices'in pr:need(array(d,b,pr['indices']).tobytes()==array(prior_route,routebin,cp['indices']).tobytes(),'All27actual index streams exact '+name)
   if name not in CHANGED:need(om==nm,'Protected unrelated mesh '+name);protected.append(name);continue
   need(set(pr['attributes'])=={'POSITION','NORMAL'}and pr['material']==om['primitives'][0]['material'],'Rigid original material/attributes');N=array(d,b,pr['attributes']['NORMAL']).astype(float);need(np.isfinite(P).all()and np.isfinite(N).all()and np.max(abs(np.linalg.norm(N,axis=1)-1))<1e-6,'Finite/unit normals');parts[name]=(P,F)
   if name in LAYER_CHANGED-AMENDED:need(nm==next(m for m in previous['meshes']if m['name']==name),'Exact nine prior layer primitives '+name)
   if name in AMENDED:
    cp=next(m for m in previous['meshes']if m['name']==name)['primitives'][0];oldP=array(previous,pb,cp['attributes']['POSITION']);oldF=array(previous,pb,cp['indices']).reshape(-1,3);need(np.array_equal(P,oldP),'Every retained jockey POSITION exact prior source');keys,deleted=notch_face_keys(oldF.tolist(),name[-1]);need({frozenset(map(int,f))for f in F}==keys and len(F)==len(keys),'Only exact declared notch deletion/caps')
   ranges[name]=connected_components(P,F);expected=3 if name in{'riding_girth','billet_l','billet_r'}else 1;need(len(ranges[name])==expected,'Explicit component ownership '+name);reports[name]=[]
   for comp in ranges[name]:
    vo=comp['vertex_start'];fo=comp['face_start'];reports[name].append(topology(P[vo:vo+comp['vertex_count']],F[fo:fo+comp['face_count']]-vo))
   if name.startswith('stirrup_leather_'):
    r.setdefault('actual_stirrup_index_ownership',{})[name]=verify_strip_faces(F.tolist(),len(P))
    owned=verify_upper_branches(P.tolist(),name[-1]);r.setdefault('actual_shared_station_ownership',{})[name]=owned
    r.setdefault('actual_paired_lower_ownership',{})[name]=verify_lower(P.tolist(),name[-1])
    start=owned['lower_fold_start_row'];oldP=array(prior_route,routebin,cp['attributes']['POSITION']);oldN=array(prior_route,routebin,cp['attributes']['NORMAL']);newP=array(d,b,pr['attributes']['POSITION']);newN=array(d,b,pr['attributes']['NORMAL'])
    anchors=anchor_rows(name[-1]);need(np.array_equal(np.asarray(anchors[0]),oldP[56*4:57*4])and np.array_equal(np.asarray(anchors[1]),oldP[63*4:64*4]),'Source anchor fixture independently matches actual pinned f644 fold-adjacent rows')
    for current,control in[(slice(0,12),slice(0,12)),(slice(len(P)-12,len(P)),slice(len(oldP)-12,len(oldP))),(slice(start*4,(start+6)*4),slice(57*4,63*4))]:
     need(newP[current].tobytes()==oldP[control].tobytes(),'Both root POSITION sets and corrected six-row iron fold remain byteexact')
    for current,control in[(slice(0,12),slice(0,12)),(slice(len(P)-8,len(P)),slice(len(oldP)-8,len(oldP))),(slice(start*4,(start+6)*4),slice(57*4,63*4))]:
     need(newN[current].tobytes()==oldN[control].tobytes(),'All twenty unamended root NORMAL rows and sixfold NORMAL rows exact')
    ids=root_normal_ids(len(P));need(newN[ids].tobytes()==np.asarray(recompute_root_normals(P.tolist(),F.tolist()),dtype='<f4').tobytes(),'Only four amended root normals genuinely recomputed from actual geometry')
    pp=next(m for m in prior_peel['meshes']if m['name']==name)['primitives'][0];oldlowerP=array(prior_peel,peelbin,pp['attributes']['POSITION']);oldlowerN=array(prior_peel,peelbin,pp['attributes']['NORMAL']);owned_lower=slice((start-13)*4,(start+19)*4)
    need(newP[owned_lower].tobytes()==oldlowerP[owned_lower].tobytes()and newN[owned_lower].tobytes()==oldlowerN[owned_lower].tobytes(),'Complete prior paired-lower repair POSITION/NORMAL rows exact')
    bp=next(m for m in d['meshes']if m['name']=='billet_'+name[-1])['primitives'][0];billetP=array(d,b,bp['attributes']['POSITION']).astype(float);billetF=array(d,b,bp['indices']).reshape(-1,3)
    r.setdefault('actual_return_root_peel',{})[name]=verify_return_exit(P.tolist(),name[-1],billetP.tolist(),billetF.tolist())
    r.setdefault('actual_stirrup_material_frames',{})[name]=strip_guard(P.tolist(),name[-1])
  need(len(protected)==13 and set(parts)==CHANGED and sum(len(q)for q in ranges.values())==22,'Sixteenpart/twentytwocomponent scope')
  # Every changed part is active exactlyonce in the root identity frame.
  parents={}
  for i,node in enumerate(d['nodes']):
   for child in node.get('children',[]):need(child not in parents,'Unique parent');parents[child]=i
  active=set();todo=list(d['scenes'][d.get('scene',0)]['nodes'])
  while todo:
   i=todo.pop();need(i not in active,'Acyclic active scene');active.add(i);todo.extend(d['nodes'][i].get('children',[]))
  ident=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]
  for name in CHANGED:
   mi=next(i for i,m in enumerate(d['meshes'])if m['name']==name);nodes=[i for i in active if d['nodes'][i].get('mesh')==mi];need(len(nodes)==1,'Unique active authoredpart');i=nodes[0]
   while True:
    n=d['nodes'][i];need('skin'not in n and n.get('translation',[0,0,0])==[0,0,0]and n.get('rotation',[0,0,0,1])==[0,0,0,1]and n.get('scale',[1,1,1])==[1,1,1]and n.get('matrix',ident)==ident,'Actual root-frame authored geometry')
    if i not in parents:break
    i=parents[i]
  interfaces=[]
  def register(name,an,af,bn,bf):
   def actual_part(part):
    if part in parts:return parts[part]
    pr=next(m for m in d['meshes']if m['name']==part)['primitives'][0];AP=array(d,b,pr['attributes']['POSITION']).astype(float);AF=array(d,b,pr['indices']).reshape(-1,3)if'indices'in pr else np.arange(len(AP)).reshape(-1,3);return AP,AF
   AP,AF=actual_part(an);BP,BF=actual_part(bn);aids=sorted({int(v)for f in af for v in AF[f]});bids=sorted({int(v)for f in bf for v in BF[f]})
   amap=collections.defaultdict(list);bmap=collections.defaultdict(list)
   for i in aids:amap[tuple(AP[i])].append(i)
   for i in bids:bmap[tuple(BP[i])].append(i)
   need(set(amap)==set(bmap),'Actual serialized interface vertexidentity, no tolerance');aliases=[]
   for alias,point in enumerate(sorted(amap)):
    q={'alias':alias,'actual_point_m':list(point)}
    for side,group in(('a',amap[point]),('b',bmap[point])):q[side+'_vertex'if len(group)==1 else side+'_vertices']=group[0]if len(group)==1 else group
    aliases.append(q)
   atris={frozenset(tuple(AP[i])for i in AF[f]):f for f in af};btris={frozenset(tuple(BP[i])for i in BF[f]):f for f in bf};need(set(atris)==set(btris)and len(atris)==len(af)==len(bf),'Exact matching actual interface triangles')
   for key,fa in atris.items():
    aa=AP[AF[fa]];bb=BP[BF[btris[key]]];na=np.cross(aa[1]-aa[0],aa[2]-aa[0]);nb=np.cross(bb[1]-bb[0],bb[2]-bb[0]);need(float(np.dot(na,nb))<0,'Opposing actual material-side interface orientation')
    if name.startswith('stirrup_iron_'):
     segment_start=0 if name[-1]=='l'else 120
     centers=[np.array([AP[AF[segment_start+2*k][0]]for k in range(10)]).mean(0),np.array([AP[AF[segment_start+2*k+1][2]]for k in range(10)]).mean(0)];axis=centers[1]-centers[0];den=float(np.dot(axis,axis));need(den>0 and na[1]<0,'Actual selected facets are the underside of a nonzero bar')
     for vertex in AF[fa]:
      point=AP[vertex];projection=centers[0]+axis*float(np.dot(point-centers[0],axis)/den);need(float(np.dot(na,point-projection))>0,'Actual iron normal points away from decoded bar centerline')
     directions=[]
     for vertex in BF[btris[key]]:
      vertex=int(vertex);offset=vertex%4;need(offset in(0,1),'Actual contact belongs to inner strip boundary');outer=(vertex//4)*4+(3 if offset==0 else 2);material=BP[outer]-BP[vertex];need(float(np.dot(na,material))>0 and float(np.dot(nb,material))<0,'Actual leather lies outside metal and inner normal points out of leather material');directions.append(material.tolist())
     r.setdefault('actual_iron_material_sides',{}).setdefault(name,[]).append({'iron_face':fa,'leather_face':btris[key],'metal_normal_m2':na.tolist(),'leather_inner_normal_m2':nb.tolist(),'actual_inner_to_outer_directions_m':directions,'outward_metal_underside_and_opposed_leather':True})
   interfaces.append({'name':name,'a_mesh':an,'a_faces':af,'b_mesh':bn,'b_faces':bf,'aliases':aliases,'actual_coplanar_matching_boundary_only':True})
  for number,cell in enumerate((4,7,10)):
   comp=ranges['riding_girth'][number];GP,GF=parts['riding_girth'];faceend=comp['face_start']+comp['face_count'];first=comp['face_start'];vertices=GP[comp['vertex_start']:comp['vertex_start']+comp['vertex_count']];angles=np.mod(np.arctan2(vertices[:,0],vertices[:,1]-1.16),2*math.pi);need(float(angles.min())>=1.65-2e-6 and float(angles.max())<=2*math.pi-1.65+2e-6,'No over-back band geometry');center=(-.48+.04*cell+.02);need(float(np.max(abs(abs(vertices[:,2]-center)-.0275)))<=2e-7,'Actual55mm band width/Zcenter')
   for side in ('l','r'):
    bar='tree_sidebar_'+side;leaf='billet_'+side;lc=ranges[leaf][number];start=lc['face_start'];end=start+lc['face_count'];cols=(21,22,23)if side=='l'else(0,1,2);barfaces=[4*(cell*24+k)+i for k in cols for i in (0,1)];leaffaces=[start+i for i in (0,1,8,9,16,17)];register('wood_foot_'+side+'_'+str(number),bar,barfaces,leaf,leaffaces)
    register('band_cap_'+side+'_'+str(number),'riding_girth',[faceend-4,faceend-3]if side=='l'else[faceend-2,faceend-1],leaf,[end-2,end-1])
  need(len(interfaces)==12,'Original twelve exact girthing interfaces')
  for name in sorted(new_interface_names()):
   an,af,bn=expected_interface_source(name,parts)
   apr=next(m for m in d['meshes']if m['name']==an)['primitives'][0];AP=array(d,b,apr['attributes']['POSITION']).astype(float);AF=array(d,b,apr['indices']).reshape(-1,3)if'indices'in apr else np.arange(len(AP)).reshape(-1,3);BP,BF=parts[bn]
   table={frozenset(tuple(BP[i])for i in f):j for j,f in enumerate(BF)};bf=[]
   for f in af:
    key=frozenset(tuple(AP[i])for i in AF[f]);need(key in table,'Actual complete source-owned new contact triangle');bf.append(table[key])
   register(name,an,af,bn,bf)
  need(len(interfaces)==18 and len({q['name']for q in interfaces})==18,'Only eighteen exact planned interfaces')
  packet={'passed':True,'candidate_sha256':r['candidate_sha256'],'component_ranges':ranges,'interfaces':interfaces,'strict_proper_allowed':False,'scope':'Decoded actual source-owned boundary registration, requires self/interpart/horse check'};(out/'validated-interfaces.json').write_text(json.dumps(packet,indent=2)+'\n')
  r.update(passed=True,active_triangles=total,primitive_batches=29,protected_meshes=protected,components=reports,component_ranges=ranges,interfaces_sha256=hashlib.sha256((out/'validated-interfaces.json').read_bytes()).hexdigest(),eleven_layer_control_sha256=hashlib.sha256(praw).hexdigest())
 except BaseException as e:r['error']=repr(e);raise
 finally:(out/'readback.json').write_text(json.dumps(r,indent=2)+'\n')
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('old',type=Path);a.add_argument('new',type=Path);a.add_argument('parameters',type=Path);a.add_argument('layer_control',type=Path);a.add_argument('route_control',type=Path);a.add_argument('peel_control',type=Path);a.add_argument('out',type=Path);o=a.parse_args();check(o.old,o.new,o.parameters,o.layer_control,o.route_control,o.peel_control,o.out)
