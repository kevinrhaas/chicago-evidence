# SPDX-License-Identifier: CC0-1.0
"""Independent decoded ownership definitions; no producer receipt is authority."""
import collections

def alias_ids(record,side):
 return record[side+'_vertices']if side+'_vertices'in record else[record[side+'_vertex']]

def notch_face_keys(source_faces,side):
 """Expected unordered triangle IDs; all source positions must remain exact."""
 M=25;o=325;row=10;cols=range(18,24)if side=='l'else range(0,6)
 deleted=set()
 for k in cols:deleted.update(range(4*(row*24+k),4*(row*24+k)+4))
 outside=24 if side=='l'else 0;vs={row*M+outside,(row+1)*M+outside,row*M+outside+o,(row+1)*M+outside+o}
 deleted.update(i for i,f in enumerate(source_faces)if set(f)<=vs)
 if len(deleted)!=26:raise ValueError('Exactly26 old notch faces removed')
 expected={frozenset(f)for i,f in enumerate(source_faces)if i not in deleted};new=[]
 for k in cols:
  new.extend([(row*M+k+1,row*M+k),((row+1)*M+k,(row+1)*M+k+1)])
 edge=18 if side=='l'else 6
 new.append((row*M+edge,(row+1)*M+edge)if side=='l'else((row+1)*M+edge,row*M+edge))
 for u,v in new:expected.update([frozenset((u,v+o,v)),frozenset((u,u+o,v+o))])
 if len(new)!=13:raise ValueError('Exactly13 new notch wall quads')
 return expected,sorted(deleted)

def expected_interface_source(name,parts):
 """Actual face IDs for one of the six new, narrowly owned patches."""
 words=name.split('_');side=words[2]
 if name.startswith('stirrup_iron_'):
  start=0 if side=='l'else 120
  return 'stirrup_'+side,list(range(start,start+10)),'stirrup_leather_'+side
 if not name.startswith('stirrup_root_'):raise ValueError('Unknown new interface')
 which=int(words[3]);cols=([14,15]if which==0 else[18,19])if side=='l'else([8,9]if which==0 else[4,5])
 return 'tree_sidebar_'+side,[4*(10*24+k)+t for k in cols for t in(0,1)],'stirrup_leather_'+side

def new_interface_names():
 return {'stirrup_root_'+s+'_'+str(i)for s in('l','r')for i in(0,1)}|{'stirrup_iron_'+s for s in('l','r')}
