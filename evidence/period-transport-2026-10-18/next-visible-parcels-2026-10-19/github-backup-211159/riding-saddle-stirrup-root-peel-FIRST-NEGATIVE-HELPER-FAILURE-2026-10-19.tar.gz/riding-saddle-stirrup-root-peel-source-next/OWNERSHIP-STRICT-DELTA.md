# Narrow ownership checks, source only

Root approved two strengthenings before any shared-station actual trial. The geometry-producing notch, root, folded iron, route and loft function bodies remain byteexact to the previously reviewed shared-station source. No offsets, thickness, support stations, physical vertices, indices, material interfaces or original predicates change.

1. Both common upper branches now require exact per-edge Z order: outgoing[lo,hi,hi,lo], return[hi,lo,lo,hi]. A sorted multiset alone no longer passes.
2. The source and independently decoded actual indexed mesh must own exactly four vertices per strip ring, eight side triangles per interval, and four end-cap triangles. Every side or cap quad must use one of its two legal diagonals. Skipped rings, wrong sides, duplicate triangles, missing faces, wrong cap ownership and non-integer indices refuse. This is an ownership check; unchanged closed topology, exact frame orientation, actual material-side tests and global self/SAT still establish physical validity.

All previous twelve synthetic radial controls and twelve new strict index/edge-order controls pass normally and under-O. New controls include mirrored outgoing and return Z permutations that retain the same sorted multiset, ensuring that weakness is explicitly rejected. Existing engineering limits of float32 source rounding enclosures remain unchanged and do not affect exact separation or original physical predicates.

All earlier source/actual failure archives remain immutable. No actual model or evaluator has run for this revision. Independent narrow delta review, root full caller review and explicit release are required before one bounded actual trial.
