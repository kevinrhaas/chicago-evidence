# SPDX-License-Identifier: CC0-1.0
"""Synthetic paired support controls; never open or evaluate actual assets."""
import copy,json,math
from lower_connector import paired_rows,complete_rows,section,quantize,certify_cell_hulls,need,verify_lower
from station_ownership import schedule

def fixture(sign=1):
 starts=[quantize(section([sign*.31,1.20,-.06],[0,0,1],[sign,0,0],.025)),quantize(section([sign*.304,1.20,-.06],[0,0,-1],[sign,0,0],.025))]
 ends=[quantize(section([sign*.33,.925,-.063],[sign,0,0],[0,0,-1],.051)),quantize(section([sign*.33,.925,-.047],[sign,0,0],[0,0,1],.051))]
 return starts,ends
def owned_strip(side,rows):
 sign=1 if side=='left'else-1;spec=schedule([.4,.5]);nA,nB=map(len,spec['branches']);lo=15+nA;n=36+nA+nB
 rings=[[[0.,0.,0.]for _ in range(4)]for _ in range(n)]
 for row,angle in((2,.4),(n-3,.5)):
  rings[row]=quantize(section([sign*.3*math.sin(angle),1.16+.3*math.cos(angle),-.06],[0,0,1],[sign,0,0],.025))
 # Recompute from quantized actual root centers exactly as the reader does.
 from station_ownership import root_angles_from_rings
 spec=schedule(root_angles_from_rings([p for ring in rings for p in ring],side[0]));a,b=map(len,spec['branches']);need((a,b)==(nA,nB),'Toy source row count stable under serialization')
 for k,ring in enumerate(rows[0]):rings[lo-13+k]=ring
 for k,ring in enumerate(rows[1]):rings[lo+18-k]=ring
 return[p for ring in rings for p in ring],lo
def refuse(fn,label):
 try:fn()
 except(ValueError,ZeroDivisionError,OverflowError):return label
 raise ValueError('Missing synthetic refusal: '+label)
def main():
 controls=[]
 for side,sign in(('left',1),('right',-1)):
  starts,ends=fixture(sign);anchors=copy.deepcopy(ends)
  for ring in anchors:
   for point in ring:point[1]+=.05
  anchors=[quantize(q)for q in anchors];rows,axes,rule=complete_rows(starts,anchors,ends)
  need(rows[0][0]==starts[0]and rows[1][0]==starts[1]and rows[0][-1]==ends[0]and rows[1][-1]==ends[1],'Exact endpoint preservation')
  proof=certify_cell_hulls(*rows,axes);need(proof['cell_pairs']==169,'All opposite lower cells')
  controls.extend([side+' exact endpoints',side+' all169 cell enclosures'])
  points,lo=owned_strip(side,rows)
  import lower_connector
  original=lower_connector.anchor_rows;lower_connector.anchor_rows=lambda _:anchors
  try:verify_lower(points,side[0])
  finally:lower_connector.anchor_rows=original
  controls.append(side+' decoded source ownership')
  damaged=copy.deepcopy(points);damaged[4*(lo-7)][0]+=.0001
  lower_connector.anchor_rows=lambda _:anchors
  try:controls.append(refuse(lambda:verify_lower(damaged,side[0]),side+' changed actual lower source row'))
  finally:lower_connector.anchor_rows=original
  controls.append(refuse(lambda:certify_cell_hulls(rows[0],rows[0],axes),side+' coincident cells'))
  swapped=copy.deepcopy(starts);swapped.reverse();controls.append(refuse(lambda:paired_rows(swapped,ends),side+' inverted directed-frame interpolation'))
  overlapping=copy.deepcopy(starts)
  for point in overlapping[1]:point[0]+=.003*sign
  controls.append(refuse(lambda:paired_rows(overlapping,ends),side+' nonpositive endpoint gap'))
  damaged=copy.deepcopy(rows);damaged[1][6]=copy.deepcopy(damaged[0][6]);controls.append(refuse(lambda:certify_cell_hulls(*damaged,axes),side+' interior hull overlap'))
  damaged=copy.deepcopy(rows);damaged[1][0]=copy.deepcopy(damaged[0][0]);controls.append(refuse(lambda:certify_cell_hulls(*damaged,axes),side+' endpoint overlap'))
 controls.append(refuse(lambda:certify_cell_hulls(*rows,[[float('nan'),0,0]]),'nonfinite axis'))
 controls.append(refuse(lambda:certify_cell_hulls(rows[0][:-1],rows[1],axes),'missing cell'))
 print(json.dumps({'passed':True,'scope':'Synthetic source-only, no actual model IO or geometry','controls':controls,'count':len(controls)}))
if __name__=='__main__':main()
