# SPDX-License-Identifier: CC0-1.0
"""Synthetic radial strips only; no actual horse/gear model evaluation."""
import math,json
from station_ownership import schedule,root_angles_from_rings,verify_upper_branches,require_shared,exact_quad,strictly_separate,f32,need

def xy(angle,radius):return[radius*math.sin(angle),1.16+radius*math.cos(angle)]
def radial(angle):return .3+.7*max(0.,min(1.,(angle-.738)/.070))
def ring(angle,base,gap,branch,side='l'):
 inner=xy(angle,base+gap);outer=xy(angle,base+gap+.004);lo,hi=-.0725,-.0475
 rows=[inner+[lo],inner+[hi],outer+[hi],outer+[lo]]
 if branch==1:rows=[rows[i]for i in(1,0,3,2)]
 if side=='r':rows=[[-q[0],q[1],q[2]]for q in rows]
 return[[f32(x)for x in q]for q in rows]
def toy(mode,side):
 # Dummy untouched rows carry no geometry assertion. Only the root markers and
 # owned common upper sections are queried by this narrow ownership control.
 rootA=ring(.47,.3,.012,0,side);rootB=ring(.53,.3,.006,1,side);seed=rootA*3+rootB*3;spec=schedule(root_angles_from_rings(seed,side));nA,nB=map(len,spec['branches']);points=[[0.,0.,0.]for _ in range(4*(36+nA+nB))];points[:12]=rootA*3;points[-12:]=rootB*3
 firstA=3+len(spec['initial'][0]);firstB=15+nA+nB+17-len(spec['initial'][1])
 for i,a in enumerate(spec['common']):
  for branch,row in[(0,firstA+i),(1,firstB-i)]:
   actual_angle=a+(.001 if mode=='independent'and branch==1 else 0.);gap=(.006 if branch==0 else .012)if mode=='inverted'else(.012 if branch==0 else .006)
   points[row*4:row*4+4]=ring(actual_angle,radial(actual_angle),gap,branch,side)
 return points,spec
def run():
 rows=[]
 for side in('l','r'):
  for mode in('common','independent','inverted'):
   points,spec=toy(mode,side);error=None
   try:proof=verify_upper_branches(points,side)
   except ValueError as e:error=str(e)
   need((error is None)==(mode=='common'),'Synthetic ownership outcome '+mode);rows.append({'side':side,'case':mode,'expected_PASS':mode=='common','observed_PASS':error is None,'error':error})
 spec=schedule([.47,.53]);error=None
 try:require_shared(spec['common'],[x+.001 for x in spec['common']],spec['common'])
 except ValueError as e:error=str(e)
 need(error is not None,'Independent source phase refusal');rows.append({'case':'source_phase_mismatch','refused':True})
 # Independently phased chords of the same steep radius curve cross despite
 # fixed ordered offsets. This reproduces the failure mechanism on toy data.
 def material_quad(a,b,gap):return exact_quad([xy(a,radial(a)+gap),xy(b,radial(b)+gap),xy(b,radial(b)+gap+.004),xy(a,radial(a)+gap+.004)])
 A=material_quad(.717,.744,.012);B=material_quad(.732,.758,.006);need(not strictly_separate(A,B),'Toy independent phased chords must overlap');rows.append({'case':'phased_chord_overlap_control','overlap_detected':True})
 square=exact_quad([[0,0],[1,0],[1,1],[0,1]])
 for name,offset,wanted in[('strict_dyadic_gap',1+2**-20,True),('exact_touch_refuses',1.,False),('proper_overlap_refuses',1-2**-20,False)]:
  other=exact_quad([[offset,0],[offset+1,0],[offset+1,1],[offset,1]]);observed=strictly_separate(square,other);need(observed==wanted,'Exact2D boundary control '+name);rows.append({'case':name,'strict_separation':observed})
 error=None
 try:exact_quad([[0,0],[1,1],[0,1],[1,0]])
 except ValueError as e:error=str(e)
 need(error is not None,'Inverted material quad must refuse');rows.append({'case':'inverted_quad_refuses','refused':True})
 print(json.dumps({'passed':True,'scope':'Pure synthetic radial ownership and exact2D separation only; dummy unqueried rows are not a model or fit proof','rows':rows},indent=2))

if __name__=='__main__':run()
