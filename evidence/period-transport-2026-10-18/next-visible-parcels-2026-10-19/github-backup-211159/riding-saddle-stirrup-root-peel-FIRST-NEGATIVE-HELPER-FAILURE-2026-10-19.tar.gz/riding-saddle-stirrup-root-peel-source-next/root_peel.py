# SPDX-License-Identifier: CC0-1.0
"""Bounded return-only root peel: exact ownership, normals and hull proofs.

No asset IO or model evaluation at import. This is an original engineering
cut/route; all unchanged global physical guards remain mandatory.
"""
import math,struct
from fractions import Fraction
from station_ownership import schedule,root_angles_from_rings,verify_strip_faces
from lower_connector import exact_axis,interval,hull_face_axes

def need(ok,message):
 if not ok:raise ValueError(message)
def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
def root_normal_ids(point_count):
 need(point_count>=24 and point_count%4==0,'Root-normal ownership bounds')
 return list(range(point_count-12,point_count-8))
def recompute_root_normals(points,faces):
 """Actual float32 geometry owns exactly four amended return-exit normals."""
 points=[[f32(float(x))for x in p]for p in points];ids=root_normal_ids(len(points));sums={i:[0.,0.,0.]for i in ids}
 for face in faces:
  owned=set(map(int,face))&sums.keys()
  if not owned:continue
  a,b,c=[points[int(i)]for i in face];u=[b[k]-a[k]for k in range(3)];v=[c[k]-a[k]for k in range(3)];cross=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
  for i in owned:
   for k in range(3):sums[i][k]+=cross[k]
 out=[]
 for i in ids:
  q=sums[i];length=math.sqrt(math.fsum(x*x for x in q));need(math.isfinite(length)and length>1e-12,'Genuine finite nonzero actual root normal');out.append([f32(x/length)for x in q])
 return out

def actual_billet_angle(points,side):
 need(len(points)==192,'Three original sixteen-ring billet components')
 a,b=points[128:130];sign=1 if side=='l'else-1
 return math.atan2(sign*(a[0]+b[0])/2,(a[1]+b[1])/2-1.16)
def verify_peel_order(root_angles,billet_points,side):
 spec=schedule(root_angles);peel=spec['return_peel_angle'];boundary=actual_billet_angle(billet_points,side)
 need(root_angles[1]<peel<boundary<spec['shared_start'],'Peel must complete before actual fixed billet foot begins')
 return spec,boundary

def certify_pairs(first,second):
 """Sufficient strict exact rational enclosure proof, never a pair waiver."""
 cells=[[[tuple(Fraction(float(x))for x in p)for p in cell]for cell in group]for group in(first,second)]
 need(all(len(c)==8 for group in cells for c in group),'Eight actual cell vertices')
 axes=[exact_axis(a)for a in((1.,0.,0.),(0.,1.,0.),(0.,0.,1.))];faces=[[None]*len(group)for group in cells];certificates=[]
 for i,a in enumerate(cells[0]):
  for j,b in enumerate(cells[1]):
   found=None
   for axis in axes:
    x=interval(a,axis);y=interval(b,axis)
    if x[1]<y[0]or y[1]<x[0]:found=axis;break
   if found is None:
    for group,index in((0,i),(1,j)):
     if faces[group][index]is None:faces[group][index]=hull_face_axes(cells[group][index])
    for axis in faces[0][i]+faces[1][j]:
     x=interval(a,axis);y=interval(b,axis)
     if x[1]<y[0]or y[1]<x[0]:found=axis;break
   need(found is not None,'Strict return-root/billet cell-hull separation '+str(i)+'/'+str(j));certificates.append([str(x)for x in found])
 return{'passed':True,'scope':'Exact rational sufficient convex-cell enclosure separation only; unchanged global self/interpart/horse checks mandatory','cell_pairs':len(first)*len(second),'separator_axes':certificates}

def verify_return_exit(points,side,billet_points,billet_faces):
 roots=root_angles_from_rings(points,side);spec,boundary=verify_peel_order(roots,billet_points,side);nA,nB=map(len,spec['branches']);n=len(points)//4
 need(n==36+nA+nB,'Current exact row count');start=15+nA+nB+17-len(spec['initial'][1]);end=n-3
 need(len(billet_faces)==372,'Three original124-face billet components')
 verify_strip_faces([[int(v)-128 for v in face]for face in billet_faces[248:]],64)
 # All four exit-to-common cells versus every cell of the fixed third billet.
 first=[points[4*j:4*(j+2)]for j in range(start,end)]
 second=[billet_points[128+4*j:128+4*(j+2)]for j in range(15)]
 need(len(first)==len(spec['initial'][1])+1,'Exact return initial/common cell ownership')
 # The first free source row is exactly the new peel angle and original width
 # rule. Canonical common rows receive their separate existing radius proof.
 row=points[4*(end-1):4*end];angle=spec['return_peel_angle'];sign=1 if side=='l'else-1
 from station_ownership import radius_enclosure
 inner=radius_enclosure(row[0][:2],angle,side,0.);outer=radius_enclosure(row[3][:2],angle,side,.004)
 need(max(inner[0],outer[0])<=min(inner[1],outer[1]),'Exact peel angle/radial4mm material ownership')
 width=.04+(.025-.04)*min(1.,(angle-roots[1])/.055);expected=[f32(-.06+width/2),f32(-.06-width/2),f32(-.06-width/2),f32(-.06+width/2)]
 need([float(p[2])for p in row]==expected,'Original return source width taper at peel')
 return{'passed':True,'peel_angle':angle,'actual_billet_boundary_angle':boundary,'return_exit_cells':[start,end],'root_normal_amendment_vertex_ids':root_normal_ids(len(points)),'enclosures':certify_pairs(first,second)}
