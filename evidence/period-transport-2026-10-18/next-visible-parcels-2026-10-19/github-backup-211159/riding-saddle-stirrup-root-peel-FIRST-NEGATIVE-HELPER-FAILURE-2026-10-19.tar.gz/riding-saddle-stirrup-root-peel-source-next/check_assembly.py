# SPDX-License-Identifier: GPL-3.0-or-later
"""Prepared only: unchanged retained SAT/proper plus exact boundary certificates.
All328 partpairs/all16-vs-ALLhorse; first failure persisted. No whole-pair skips.
"""
from pathlib import Path
import json,hashlib,argparse,math,collections
import numpy as np
from check_actual import load,array,need,CHANGED,LAYER_CHANGED,connected_components
from official_fit_predicates import sat,proper
from interface_contact import certify
from source_interfaces import alias_ids,new_interface_names,expected_interface_source

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def graph_components(faces):
 adjacency=collections.defaultdict(set);owners=collections.defaultdict(list)
 for j,face in enumerate(faces):
  for a,b in zip(face,face[1:]+face[:1]):owners[tuple(sorted((a,b)))].append(j)
 for ids in owners.values():
  for a in ids:adjacency[a].update(ids)
 out=[];seen=set()
 for i in range(len(faces)):
  if i in seen:continue
  todo=[i];group=set()
  while todo:
   j=todo.pop()
   if j in group:continue
   group.add(j);todo.extend(adjacency[j]-group)
  seen.update(group);out.append(sorted(group))
 return out

def disk(faces):
 need(len(graph_components(faces))==1,'Connected registered patch');edges=collections.Counter(tuple(sorted((a,b)))for face in faces for a,b in zip(face,face[1:]+face[:1]));vertices={v for f in faces for v in f};need(len(vertices)-len(edges)+len(faces)==1 and all(n in(1,2)for n in edges.values()),'Actual interface patch disk Euler1');boundary=[e for e,n in edges.items()if n==1];adj=collections.defaultdict(set)
 for a,b in boundary:adj[a].add(b);adj[b].add(a)
 need(bool(adj)and all(len(v)==2 for v in adj.values()),'Single patch boundary degree2');seen=set();todo=[next(iter(adj))]
 while todo:
  j=todo.pop()
  if j in seen:continue
  seen.add(j);todo.extend(adj[j]-seen)
 need(len(seen)==len(adj),'Single interface boundary cycle')

def absolute_winding(point,triangles):
 v=triangles-point;u=v[:,0];vv=v[:,1];w=v[:,2];lu=np.linalg.norm(u,axis=1);lv=np.linalg.norm(vv,axis=1);lw=np.linalg.norm(w,axis=1);need(float(min(lu.min(),lv.min(),lw.min()))>1e-10,'Probe away from actualtargetvertices');numerator=np.einsum('ij,ij->i',u,np.cross(vv,w));denominator=lu*lv*lw+np.einsum('ij,ij->i',u,vv)*lw+np.einsum('ij,ij->i',vv,w)*lu+np.einsum('ij,ij->i',w,u)*lv;return abs(float(np.arctan2(numerator,denominator).sum())/(2*math.pi))

def vertex_standoff(points,triangles):
 # Diagnostic unsigned vertex samples ONLY; never a triangleclearance/pressure
 # acceptance test. All active horse triangles are queried for each sample.
 a=triangles[:,0];ab=triangles[:,1]-a;ac=triangles[:,2]-a;normal=np.cross(ab,ac);nn=np.einsum('ij,ij->i',normal,normal);uu=np.einsum('ij,ij->i',ab,ab);uv=np.einsum('ij,ij->i',ab,ac);vv=np.einsum('ij,ij->i',ac,ac);den=uu*vv-uv*uv;result=[]
 for p in points:
  w=p-a;plane=np.einsum('ij,ij->i',w,normal);proj=w-normal*(plane/nn)[:,None];wu=np.einsum('ij,ij->i',proj,ab);wv=np.einsum('ij,ij->i',proj,ac);u=(wu*vv-wv*uv)/den;v=(wv*uu-wu*uv)/den;d=np.where((u>=0)&(v>=0)&(u+v<=1),plane*plane/nn,np.inf)
  for i,j in((0,1),(1,2),(2,0)):
   edge=triangles[:,j]-triangles[:,i];q=p-triangles[:,i];t=np.clip(np.einsum('ij,ij->i',q,edge)/np.einsum('ij,ij->i',edge,edge),0,1);delta=q-edge*t[:,None];d=np.minimum(d,np.einsum('ij,ij->i',delta,delta))
  result.append(math.sqrt(float(d.min())))
 return {'scope':'Unsigned unique actualvertex samples vsALLhorse triangles, NOT fulltriangleminimum/pressure/continuousmotion','samples':len(result),'minimum_m':min(result),'median_m':float(np.median(result)),'p95_m':float(np.percentile(result,95)),'maximum_m':max(result)}

def run(capture,candidate,selfpath,interfacepath,out,expected):
 out.mkdir();r={'passed':False,'scope':'Actual retained6e9b idle0; all328 interpart/all16vsALLhorse; rawSAT retained, exact registered boundary contacts only. No motion/pressure/load/photo acceptance','pairs':[]}
 def save():(out/'fit.json').write_text(json.dumps(r,indent=2)+'\n')
 try:
  mraw=(capture/'capture.json').read_bytes();m=json.loads(mraw);need(m['passed']is True and m['actualPose']=={'clip':'idle','action_time_s':0,'mixer_time_s':0},'Actual idle0');d,b,raw=load(candidate);need(hashlib.sha256(raw).hexdigest()==expected,'Reviewed actual candidate pin')
  pins={'horse':'6e9b37b755ae3eda7b5cf2f492d1781b0e507664a99c88a2e6dee086f77c2296','baseline':'a457874a81b624f5e9642d3296b1350eb49b17d21d38099fbe66080711c17021','candidate':expected}
  for k,v in pins.items():need(m['inputs'][k]['sha256']==v==sha(Path(m['inputs'][k]['path'])),'Actual input bytes '+k)
  need(m['baseline_head_bind_matrix_error']<=1e-10 and m['candidate_head_bind_matrix_error']<=1e-10,'Actual head parent-inverse binding');r['input_sha256']=pins;r['capture_metadata_sha256']=hashlib.sha256(mraw).hexdigest()
  selfr=json.loads(selfpath.read_text());packet=json.loads(interfacepath.read_text());need(selfr['passed']is True and selfr['candidate_sha256']==expected and selfr['capture_metadata_sha256']==r['capture_metadata_sha256'],'Same actual complete selfproof');need(packet['passed']is True and packet['candidate_sha256']==expected and packet['strict_proper_allowed']is False,'Validated actualinterface packet');interfaces=packet['interfaces'];need(len(interfaces)==18 and {q['name']for q in interfaces}==({kind+'_'+side+'_'+str(i)for kind in('wood_foot','band_cap')for side in('l','r')for i in range(3)}|new_interface_names()),'Exact eighteen interface names')
  need(all(selfr['parts'].get(n,{}).get('closed')is True and selfr['parts'].get(n,{}).get('embedded_closed_solid')is True for n in CHANGED),'All exact sixteen changed targets embedded');r['self_receipt_sha256']=sha(selfpath);r['validated_interfaces_sha256']=sha(interfacepath)
  def read_capture(k):
   meta=m['parts'][k];file=capture/(k+'.f64');need(sha(file)==meta['sha256']and file.stat().st_size==meta['triangles']*72==meta['bytes'],'Actual fullFloat64 '+k);data=np.frombuffer(file.read_bytes(),dtype='<f8').reshape(-1,3,3);need(np.isfinite(data).all(),'Finite actualcaptured');parts=[];cursor=0
   for p in meta['parts']:
    need(p['face_start']==cursor and p['face_count']>0,'Full contiguous actualpart');cursor+=p['face_count'];tri=data[p['face_start']:cursor];need(float(np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1).min())>2e-12,'Nondegenerate actual triangle');obj={'name':p['name'],'tri':tri,'lo':tri.min(1),'hi':tri.max(1),'overall_lo':tri.min((0,1)),'overall_hi':tri.max((0,1))}
    if k=='candidate_all':
     need(p['name']in selfr['parts']and selfr['parts'][p['name']]['complete']is True and selfr['parts'][p['name']]['faces']==p['face_count']and not selfr['parts'][p['name']]['unexpected'],'Exact selfpart/cohort count');mesh=d['meshes'][p['mesh']];need(mesh['name']==p['name']and p['primitive']==0,'Canonical actualmesh association');pr=mesh['primitives'][0];P=array(d,b,pr['attributes']['POSITION']).astype(float);F=array(d,b,pr['indices']).reshape(-1,3)if'indices'in pr else np.arange(len(P)).reshape(-1,3);need(len(F)==len(tri),'Complete actualsource indexstream');obj['indices']=F;obj['source_positions']=P
     if p['name']in CHANGED:obj['source_components']=connected_components(P,F)
     if p['name']in CHANGED:need(np.array_equal(tri,P[F]),'Actual changed rigidworld/source equality')
     aliases={};faces=[];points=[]
     for triangle in tri:
      face=[]
      for point in triangle:
       q=tuple(map(float,point))
       if q not in aliases:aliases[q]=len(points);points.append(q)
       face.append(aliases[q])
      faces.append(face)
     closed=selfr['parts'][p['name']]['closed'];obj.update(closed=closed,welded_faces=faces,points=np.array(points),components=graph_components(faces))
     if closed:need(selfr['parts'][p['name']]['embedded_closed_solid']is True,'Embedded target before solid inference')
    parts.append(obj)
   need(cursor==len(data),'No missing capture faces');return parts
  gear=read_capture('candidate_all');horse=read_capture('horse');need(len(gear)==29 and {p['name']for p in gear}==set(selfr['parts'])and CHANGED<={p['name']for p in gear},'Exact29/16 sourcecohort');need(sum(len(p['tri'])for p in horse)==14172,'All actualhorse14172 faces');byname={p['name']:p for p in gear}
  # Recheck actual aliases/face binding before admitting any certificate. Never
  # accept packet-only positions, missing records, or arbitrary target partpairs.
  patches=collections.defaultdict(list);contact_points=collections.defaultdict(set)
  for q in interfaces:
   name=q['name']
   if name in new_interface_names():
    an,expected_a,bn=expected_interface_source(name,byname);AA=byname[an];BB=byname[bn];lookup={frozenset(tuple(v)for v in triangle):j for j,triangle in enumerate(BB['tri'])};expected_b=[]
    for face in expected_a:
     key=frozenset(tuple(v)for v in AA['tri'][face]);need(key in lookup,'Actual complete new source interface triangle');expected_b.append(lookup[key])
    expected_pair=(an,bn)
   elif name.startswith('wood_foot_'):
    number=int(name.rsplit('_',1)[1]);side=name.rsplit('_',2)[1];leaf='billet_'+side
    cell=(4,7,10)[number];cols=(21,22,23)if side=='l'else(0,1,2);expected_a=[4*(cell*24+k)+v for k in cols for v in(0,1)];lc=byname[leaf]['source_components'][number];expected_b=[lc['face_start']+v for v in(0,1,8,9,16,17)];expected_pair=('tree_sidebar_'+side,leaf)
   else:
    number=int(name.rsplit('_',1)[1]);side=name.rsplit('_',2)[1];leaf='billet_'+side
    gc=byname['riding_girth']['source_components'][number];lc=byname[leaf]['source_components'][number];ge=gc['face_start']+gc['face_count'];le=lc['face_start']+lc['face_count'];expected_a=[ge-4,ge-3]if side=='l'else[ge-2,ge-1];expected_b=[le-2,le-1];expected_pair=('riding_girth',leaf)
   need((q['a_mesh'],q['b_mesh'])==expected_pair and q['a_faces']==expected_a and q['b_faces']==expected_b,'Exact planned actual source interface semantics')
   A=byname[q['a_mesh']];B=byname[q['b_mesh']];need(q['actual_coplanar_matching_boundary_only']is True,'Boundary-only record')
   for side,obj in(('a',A),('b',B)):
    ids=q[side+'_faces'];need(ids and len(set(ids))==len(ids)and min(ids)>=0 and max(ids)<len(obj['tri']),'Actual interface facebounds');faces=[obj['welded_faces'][i]for i in ids];disk(faces);patches[obj['name']].append(set(ids))
   need(len({x['alias']for x in q['aliases']})==len(q['aliases']),'Unique actual canonical aliases')
   need(len({tuple(x['actual_point_m'])for x in q['aliases']})==len(q['aliases'])and all(alias_ids(x,'a')and alias_ids(x,'b')for x in q['aliases']),'Nonempty exact canonical coordinate groups')
   for prefix,obj in(('a',A),('b',B)):
    allids=[v for x in q['aliases']for v in alias_ids(x,prefix)];need(len(allids)==len(set(allids))and set(allids)=={int(v)for f in q[prefix+'_faces']for v in obj['indices'][f]},'Exact source row coverage without alias overlap')
   for alias in q['aliases']:
    point=tuple(alias['actual_point_m'])
    for prefix,obj in(('a',A),('b',B)):
     need(all(tuple(map(float,obj['source_positions'][v]))==point for v in alias_ids(alias,prefix)),'Actual exact duplicate-row serialized identity')
    contact_points[A['name']].add(point);contact_points[B['name']].add(point)
  for obj in gear:
   ps=patches[obj['name']];pv=[{v for f in patch for v in obj['welded_faces'][f]}for patch in ps];need(all(not(a&bb)for i,a in enumerate(pv)for bb in pv[i+1:]),'Disjoint registeredcontact disks/vertices');removed=set().union(*ps)if ps else set();representatives=[]
   for component in obj['components']:
    remain=[i for i in component if i not in removed];need(remain and len(graph_components([obj['welded_faces'][i]for i in remain]))==1,'Actual surface-minus-contactdisks remains connected');valid=[i for i in remain if all(tuple(p)not in contact_points[obj['name']]for p in obj['tri'][i])];need(valid,'Strict noncontact probe exists');tri=obj['tri'][valid[0]];representatives.append(tri[0]*.5+tri[1]*.25+tri[2]*.25)
   obj['representatives']=representatives
  def nesting(A,B):
   if not B.get('closed'):return {'solid':B['name'],'status':'not_a_proved_closed_solid'}
   reports=[]
   # Each actual closed target component is evaluated separately. Never sum
   # orientations across multipart targets: opposite shells could cancel.
   for number,faces in enumerate(B['components']):
    triangles=B['tri'][faces];lo=triangles.min((0,1));hi=triangles.max((0,1));maximum=0.
    for p in A['representatives']:
     if np.any(p<lo)or np.any(p>hi):continue
     value=absolute_winding(p,triangles);maximum=max(maximum,value);need(value<1e-5 or abs(value-1)<1e-5,'Ambiguous actualcomponentwinding');need(value<.5,'FIRST actual closedcomponentnesting '+A['name']+'/'+B['name']+'/'+str(number))
    reports.append({'component':number,'status':'outside','maximum_absolute_winding':maximum})
   return {'solid':B['name'],'actual_closed_components':reports}
  def scan(A,B,kind):
   row={'kind':kind,'a':A['name'],'b':B['name'],'triangles_a':len(A['tri']),'triangles_b':len(B['tri']),'AABB_candidates':0,'raw_SAT':0,'strict_proper':0,'certified_contacts':[],'unexpected':[],'complete':False};r['pairs'].append(row);save()
   if not(np.any(A['overall_hi']<B['overall_lo']-1e-8)or np.any(B['overall_hi']<A['overall_lo']-1e-8)):
    for i,a in enumerate(A['tri']):
     candidates=np.flatnonzero(np.all(B['hi']>=A['lo'][i]-1e-8,axis=1)&np.all(B['lo']<=A['hi'][i]+1e-8,axis=1))
     for j in candidates:
      j=int(j);bb=B['tri'][j];row['AABB_candidates']+=1
      if not sat(a,bb):continue
      row['raw_SAT']+=1;w=proper(a,bb);row['strict_proper']+=int(w is not None);cert=None
      if w is None and kind=='interpart':cert=certify(a,bb,list(map(int,A['indices'][i])),list(map(int,B['indices'][j])),A['name'],B['name'],i,j,interfaces)
      if cert is not None:row['certified_contacts'].append({'a_face':i,'b_face':j,**cert});continue
      row['unexpected'].append({'a_face':i,'b_face':j,'actual_coordinates':[a.tolist(),bb.tolist()],'proper':w});save();raise ValueError('FIRST actual unexpectedcontact/proper '+A['name']+'/'+B['name'])
     if i%250==0:save()
   if kind=='interpart':row['nesting']=[nesting(A,B),nesting(B,A)]
   row['complete']=True;save()
  for i,A in enumerate(gear):
   for B in gear[i+1:]:
    if A['name']in CHANGED or B['name']in CHANGED:scan(A,B,'interpart')
  need(len(r['pairs'])==328,'All120changed/changed+208changed/fixed pairs')
  for A in gear:
   if A['name']in CHANGED:
    for B in horse:scan(A,B,'horse')
  allhorse=np.concatenate([p['tri']for p in horse]);r['girth_vertex_standoff']=vertex_standoff(np.unique(byname['riding_girth']['tri'].reshape(-1,3),axis=0),allhorse)
  r['passed']=True;save()
 except BaseException as e:r['error']=repr(e);save();raise
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('capture',type=Path);p.add_argument('candidate',type=Path);p.add_argument('self_receipt',type=Path);p.add_argument('interfaces',type=Path);p.add_argument('out',type=Path);p.add_argument('expected_sha');a=p.parse_args();run(a.capture,a.candidate,a.self_receipt,a.interfaces,a.out,a.expected_sha)
