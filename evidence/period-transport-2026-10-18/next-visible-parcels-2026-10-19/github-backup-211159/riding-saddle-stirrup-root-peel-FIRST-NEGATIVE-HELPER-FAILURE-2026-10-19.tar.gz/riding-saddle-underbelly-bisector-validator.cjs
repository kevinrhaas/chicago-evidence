// One actual GLB; external resources forbidden; original warning/info report retained.
const fs=require('node:fs');
const validator=require('/workspace/shared/transport-tools/node_modules/gltf-validator');
const [file,out]=process.argv.slice(2);
if(!file||!out)throw Error('Explicit GLB and fresh report path required');
validator.validateBytes(new Uint8Array(fs.readFileSync(file)),{uri:file,externalResourceFunction:async()=>{throw Error('External resource refused');}}).then(report=>{
 fs.writeFileSync(out,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
 if(report.issues.numErrors!==0)throw Error('Khronos errors');
}).catch(error=>{console.error(error);process.exitCode=1;});
