# Additional actually viewed muzzle anatomy references

Two existing cleared modern bit closeups were reopened: Henry2008/NeilMcIntosh
(CC BY2.0) and BretonLiverpool2017/TsaagValren(CC BY-SA4.0), from audit7d83.
They do not supply an unobscured neutral commissure or metric scans.

Three bounded Commons queries were stored: two fulltext searches returned mostly
book PDFs, so no PDF was downloaded; a15-file Category:Horse_muzzle listing then
identified two relevant photographs. Exactly two new original JPEGs and their
complete file-page wikitext JSON were downloaded and ACTUALLY OPENED with the
image-view tool. No browser was held, no photo editing or app asset derivation.

* `arabian-muzzle.jpg`,833x853,514832bytes,
SHA11d79c1bdbeaba4f827cefeff8f818b55c4ebf7dfb9ecb51d59a83750505a333.
https://commons.wikimedia.org/wiki/File:Arabian_muzzle.jpg
Original source https://www.flickr.com/photos/7221539@N06/4429053008 (IMG_4083),
2010-03-01. Filepage explicit{{cc-by-sa-2.0}}, Commons Flickr upload/review byPitke
2012-02-06 confirmed the indicated license. License
https://creativecommons.org/licenses/by-sa/2.0/ . Filepage's author display is
malformed{{{1}}}; retain the explicit attribution to Flickr account7221539@N06
https://www.flickr.com/people/7221539@N06 instead of silently repairing it. The
Commons author-stream category names JimmyBaikovicius, qualified secondary
attribution evidence. The existing photo remains unmodified underCC BY-SA2.0.
Actual view: frontal nose with two raised fleshy nostril margins, a central upper
lip cleft, closed apposed lip seam and distinct lower lip/chin; short hair and
vibrissae. No claim of calibrated dimensions, clinical health, breathing phase,
period Chicago identity, pose pressure or neutral bitted geometry.

* `fjord-muzzle.jpg`,4000x3000,4931584bytes,
SHA8e724fe2476a5817029208ff1710f0f64ded9fd34791f71e9a6d0239be15b50e.
https://commons.wikimedia.org/wiki/File:Fjord_horse_muzzle.jpg
TsaagValren,2017-06-02, explicit ownwork/selfCC BY-SA4.0 in completefilepage;
API metadata agrees. https://creativecommons.org/licenses/by-sa/4.0/ .
Actual view: close frontal/quarter muzzle, large rounded raised nostril entry,
short coat/long vibrissae, closed narrow seam around upper lip and distinct lower
lip/chin. It supplies clear soft-tissue form, not a calibrated 3D surface or
Chicago Fjord horse attestation. Original photograph remainsCC BY-SA4.0.

Photographs provide qualitative anatomical comparison ONLY. The proposed chin
amplitude/ratios and rim/groove2.5mm are explicitly original authored dimensions
from the pre-existing source station/depth scale. They are NOT pixel tracing,
photogrammetry or claims that either photograph measured these values. No photo
texture, pigment copy, derivative mesh or named horse likeness is emitted. No
blanket GPL/CC0 license is applied to the photographs. Unsplash grayhorse from
earlier audit remains provisional/excluded; pathological examples are not used.
