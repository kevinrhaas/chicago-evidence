# Source-only fixed lip/chin/nostril correction — actual operation NOT RUN

The419a parent remains independently stored-audited complete idle engineering
PASS685774a8, with horse-only8c2b and bitted36173b appearance capsules technically
PASS but visually UNACCEPTED. Root/author actually inspected both. App untouched.

Root conditionally authorized exactly ONE<=180s CPU0/allmaththreads1 actual
candidate AFTER full independently frozen source/caller/index-ownership PASS.
No actual candidate/field/model/export/fit/SAT/capture/browser has run here.
Index-only source reconstruction and finite scalar coefficient proofs are not
an actual geometry trial. Proposed2735 vertex positions/normals/JW remain UNEVALUATED.

PLAN.md defines exact original artist reconstruction, including explicit
source-relative chin amplitude/ratios, existing2.5mm rim/groove scalar, and all
limits of modern reference evidence. It is not claimed measured/photo quality.
1368 retired source faces acrossTHREE actual primitives,1984headfaces and128
vestibulefaces preserved, exact112 source boundaryedges, fixedactualfe76bit.
5360newfaces/fullhead7344/model17448; complete5488mouth+nostrilcohort. Every
oriented edge/link/fullscope proof derives from indices with no proposed XYZ.

13 source-only controls PASS: full directed topology and corrupted orientations/
missing/duplicate triangles, all2735convexpartitions plusnegative/foreign/
unnormalized controls, two whollysynthetic exact-AST normalfan fixtures,
unchanged7appendserializer AST and exact original180scaller aparttoken/status,
allPython ASTsyntax. ThreeNode syntax checks pass. All prior160external source
pins were independently rehashed against currentbytes and match EXACTLY; no
silent refresh. Added parent419a/source/clearedref pins are explicit new authority.

Physical checks retain exact original predicates/thresholds: all8fullscopes,
all36gear/fullactualbit/old078negative/readback/Khronos/freshbinary64capture.
Only the explicit head/mouth sourcecohort counts/labels change in structural
routing. The caller keeps its reviewed predecessor's exact180s total and110s fullstructural phase. There is no
extension, retry, search or provisionalPASS on timeout. Every failure immutable.

Future invocation only AFTER fullpeerPASS/freeCPU0:
timeout --signal=TERM --kill-after=5s 180s taskset -c 0 env OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 python /workspace/shared/horse-native-muzzle-anatomy-correction-next/run_once.py ROOT_RELEASE_ONE_MUZZLE_LIP_CHIN_NOSTRIL
Callerowns180s budget andkills/reapswholechildgroup. External180s has a5s kill/reapcleanupbackstop, not added computationtime. Fresh outputs mandatory. Root authorizes one later
bounded readonly matchedcapture after fulltechnicalPASS and peersourcecheck;
coordinate browser lane. No automatic photo/motion/app/unbitted/pressure acceptance.
