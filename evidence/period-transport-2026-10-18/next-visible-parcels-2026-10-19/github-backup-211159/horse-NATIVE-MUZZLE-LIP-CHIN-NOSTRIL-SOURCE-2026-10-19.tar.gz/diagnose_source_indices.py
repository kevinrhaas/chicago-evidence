"""Read immutable source indices/owners only; never decode P/N/J/W or import evaluator."""
from pathlib import Path
import struct,json,hashlib,collections
def require(value,message='Stored index source contract'):
 if not value:raise ValueError(message)
P=Path(__file__).parent
C=Path('/workspace/shared/horse-natural-labial-corner-three-primitives-next/candidate-one')
raw=(C/'candidate.glb').read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest()
require(sha(raw)=='419a6194b660bcd9ab1f7da21a2b1fcbd67d9ba620d294fd6299440dc8890c31')
rbraw=(C/'readback.json').read_bytes();rb=json.loads(rbraw);require(rb['PASS']and rb['candidate_sha256']==sha(raw))
n,typ=struct.unpack_from('<II',raw,12);require(typ==0x4e4f534a)
d=json.loads(raw[20:20+n]);bo=20+n;bn,bt=struct.unpack_from('<II',raw,bo);require(bt==0x004e4942);binary=memoryview(raw)[bo+8:bo+8+bn]
labels={(x['mesh'],x['vertex']):x['label'] for x in rb['source_labels']};rows={};offset=0
for mi,m in enumerate(d['meshes']):
 for pi,p in enumerate(m['primitives']):
  acc=d['accessors'][p['indices']];v=d['bufferViews'][acc['bufferView']];require(acc['type']=='SCALAR'and acc['componentType'] in(5123,5125)and not v.get('byteStride')and not acc.get('sparse'));fmt={5123:'H',5125:'I'}[acc['componentType']];idx=struct.unpack_from('<'+fmt*acc['count'],binary,v.get('byteOffset',0)+acc.get('byteOffset',0));require(len(idx)%3==0)
  for k in range(len(idx)//3):
   g=offset+k;rows[g]={'primitive':[mi,pi],'indices':list(idx[3*k:3*k+3]),'aliases':[labels[mi,j]for j in idx[3*k:3*k+3]],'owner':rb['source_face_owners'][str(g)]}
  offset+=len(idx)//3
require(offset==13456 and len(rows)==offset)
mouth={g for g,r in rows.items()if r['owner']['kind']=='natural_labial'};nostril={g for g,r in rows.items()if r['owner'].get('tag','')in{'nostril_1','nostril_-1','skin:nostril_1','skin:nostril_-1'}}
require(len(mouth)==701 and len(nostril)==288 and not mouth&nostril)
edges=collections.defaultdict(list)
for g,r in rows.items():
 a=r['aliases']
 for u,v in zip(a,a[1:]+a[:1]):edges[tuple(sorted((u,v)))].append((g,u,v))
selected=mouth|nostril
halo={g for uses in edges.values()if any(u[0]in selected for u in uses)for g,_,_ in uses if g not in selected and rows[g]['owner'].get('tag')=='skin'and rows[g]['owner']['kind']=='baseline_head'}
regions={}
for name,cohort in [('mouth',mouth),('nostrils',nostril),('core_union',selected),('one_skin_halo',halo),('union_with_halo',selected|halo)]:
 es=collections.defaultdict(list)
 for g in sorted(cohort):
  a=rows[g]['aliases']
  for u,v in zip(a,a[1:]+a[:1]):es[tuple(sorted((u,v)))].append((u,v,g))
 boundary=[z[0][:2]for z in es.values()if len(z)==1];V={u for g in cohort for u in rows[g]['aliases']};out=collections.Counter(x for x,y in boundary);inn=collections.Counter(y for x,y in boundary)
 regions[name]={'face_count':len(cohort),'faces':sorted(cohort),'V':len(V),'E':len(es),'F':len(cohort),'Euler':len(V)-len(es)+len(cohort),'oriented_boundary':boundary,'boundary_count':len(boundary),'simple_boundary_degrees':all(x==1 for x in out.values())and out==inn,'routes':dict(collections.Counter(str(tuple(rows[g]['primitive']))for g in cohort)),'owner_tags':dict(collections.Counter(rows[g]['owner'].get('tag',rows[g]['owner']['kind'])for g in cohort))}
require(all(len(x)<=2 for x in edges.values()))
report={'status':'STORED_INDEX_DIAGNOSIS_ONLY_NO_PROPOSED_XYZ','candidate_sha256':sha(raw),'readback_sha256':sha(rbraw),'native_source_sha256':sha(Path('/workspace/shared/horse-oral-channel-diagonal-candidate/source/frozen-head.json').read_bytes()),'regions':regions,'retired_face_records':{str(g):rows[g]for g in sorted(selected|halo)},'not_done':['No source-owned boundary amendment frozen','No proposed topology','No proposed positions/normals/rig weights','No candidate/export/collision/capture/browser']}
(P/'STORED-INDEX-DIAGNOSIS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:{x:v[x]for x in['face_count','V','E','F','Euler','boundary_count','simple_boundary_degrees','routes','owner_tags']}for k,v in regions.items()},indent=2))
