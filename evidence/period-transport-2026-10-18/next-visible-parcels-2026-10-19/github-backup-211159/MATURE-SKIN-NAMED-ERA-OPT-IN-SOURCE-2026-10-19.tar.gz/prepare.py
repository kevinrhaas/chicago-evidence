from pathlib import Path
import json,hashlib,shutil,difflib
P=Path(__file__).parent;B=P.parent;A=P/'proposed/chicago/4d';D=A/'assets/authored/humans/makehuman_age_labeled_skin';D.mkdir(parents=True,exist_ok=True);T=A/'tools';T.mkdir(exist_ok=True);original=B/'mature-male-skin-SOURCE-next';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=json.loads((original/'SOURCE.json').read_text());page=original/'evidence/makehuman_system_assets.official-page.md';rows=[line for line in page.read_text().splitlines()if 'middleage_caucasian_male'in line or 'old_caucasian_male'in line];package=json.loads((original/'evidence/PACKAGE-INSPECTION.json').read_text())
for c in source['components']:shutil.copyfile(original/c['image'],D/Path(c['image']).name)
shutil.copyfile(P/'evidence/UV-REGISTRATION.json',D/'UV-REGISTRATION.json')
images=[]
for c in source['components']:
 filename=Path(c['image']).name;entry=next(e for e in package['selected_entries']if e['path'].endswith('/'+filename));images.append({'file':filename,'sha256':c['sha256'],'bytes':c['bytes'],'resolution':[2048,2048],'mode':'RGB','license':'CC0-1.0','source_component_name':c['source_component_name'],'original_package_entry':entry,'maps_supplied':['diffuse_color_only'],'normal_map':None,'roughness_map':None,'upscaled':False})
r={'format':'chicago4d_original_image_component_v1','license':'CC0-1.0','license_scope':'Exact original PNG image bytes only; image PUBLICDOMAIN mark plus current named-component official CC0 evidence accepted for reusable skincomponent. No legacy material/program code included.','license_evidence':{'record':{'license':'CC0','kind':'Image-level PUBLICDOMAIN mark plus pinned current upstream named-component catalog','upstream_catalog_rows':rows},'embedded_mark':'Actual original pixels include PUBLICDOMAIN / MAKEHUMAN.ORG at lower right, inspected without editing.','official_catalog':{**source['upstream_catalog'],'local_copy':None,'original_page_sha256':h(page),'git_blob_sha1':'307b832a3593513fa657feae73309c9a0ea9d7ee'}},'acquisition':source['acquisition'],'images':images,'version_license_distinction':{'image_rights':'Embedded original PUBLICDOMAIN mark and pinned current named-component official CC0 evidence apply to exact original images.','legacy_material_code':'Original2016 AGPLv3 .mhmat files remain in the separate original research parcel only; none copied here or ported into material code.','older_package_wording':source['license_scope']['package_copyright']},'component_identity_scope':'Vendor age/ancestry/color names label reusable source assets; they are not historical person identities, ancestry, complexion, exact age or photographic likeness evidence.','code_copied':False,'legacy_material_files_copied':False,'texture_edits_or_generated_maps':False,'UV_registration':{'basis':'Original1.1.1 packagebase.npz atlas shares exact18,486quad vertex/UV indices with actualHM08 OBJ;21,334UVs equal at nativefloat32 storage. Every14,517 prepared UV/sourcevertex pair in each era matches source face corners.','source_receipt':'UV-REGISTRATION.json','source_receipt_sha256':h(D/'UV-REGISTRATION.json'),'limits':'UV registration is established at source; actual source/published Blender/export/LOD/seams/material/lighting/animation review remains open. Conservative badgebox is outside full prepared body triangles at source; downstream mip/derivative sampling remains untested.'},'quality_limits':[line if not line.startswith('Actual body UV registration') else 'Source UV registration and conservative badge footprint checks passed. Actual Blender/export/LOD seams, mip sampling, mature surface form, lighting and animated fit remain untested.' for line in source['quality_limits']]};(D/'SOURCE.json').write_text(json.dumps(r,indent=2)+'\n');source_sha=h(D/'SOURCE.json')
# The accepted diagnostics source is the later patch's PREIMAGE, not re-proposed here.
(P/'preimages/tools').mkdir(parents=True,exist_ok=True)
for n in ['human_era_study_blend.py','human_era_study_common.py']:
 shutil.copyfile(B/'human-ci39314363829-diagnostics-next/proposed/tools'/n,P/'preimages/tools'/n)
shutil.copyfile(B/'era-canonical-integration-next/app/chicago/4d/tools/human_era_study.sh',P/'preimages/tools/human_era_study.sh')
module='''# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicit original age-labeled diffuse studies, only named1812/1904.

Default bronze bytes remain untouched. This module never imports BPy, edits UVs,
ages geometry, infers historical complexion or authors image/maps. Original
PNG images are native2048 and licensed independently from legacy material code.
"""
from pathlib import Path
import copy
import hashlib
import json

YOUNG_SHA = "5a53213f061bfa97ee0afd6b40650ffbc089a479c144e63f3c39acceca5853c0"
SOURCE_PATH = "assets/authored/humans/makehuman_age_labeled_skin/SOURCE.json"
SOURCE_SHA = "@SOURCE_SHA@"
COMPONENTS = {
    "1812": {"person_id": "kinzie_john_elder", "age": 49, "date": "1812-08-14",
             "component": "middleage_caucasian_male",
             "file": "middleage_lightskinned_male_diffuse.png",
             "sha256": "ee64f23cc77abb53d0a105fb242032b97e97ef9350ada8135f3544bcd517b5fa"},
    "1904": {"person_id": "glessner_john_j", "age": 61, "date": "1904-07-01",
             "component": "old_caucasian_male",
             "file": "old_lightskinned_male_diffuse.png",
             "sha256": "2f7de9bad2be050290cc3fbcf647992dab53a94c657fb0b44b45966de73af76a"}}


def need(value, message):
    if not value:
        raise ValueError(message)


def component(manifest):
    era = manifest.get("scene")
    need(era in COMPONENTS, "Only named1812/1904 skin studies; never1835/default residents")
    c = COMPONENTS[era]
    need(manifest.get("person_id") == c["person_id"] and
         manifest.get("body_age_years") == c["age"] and manifest.get("scene_date") == c["date"],
         "Fixed named identity/date/body age required for this skin comparison")
    return c


def expected_skin(manifest):
    c = component(manifest)
    return {"path": "assets/authored/humans/makehuman_age_labeled_skin/"+c["file"],
            "sha256": c["sha256"], "license": "CC0-1.0", "color_space": "sRGB",
            "base_color_factor": [1, 1, 1, 1], "roughness": .68,
            "roughness_basis": "Unchanged reconstructed engineering scalar; selected source supplies no measured roughness/normal map. Not converted from legacy specular/shininess.",
            "identity_basis": "Explicit reconstructed reusable skin choice. Vendor component ancestry/color/age label identifies only the source asset, never this person's ancestry, complexion, measured skin age or likeness.",
            "uv_status": "Original package compiledbase.npz shares exact HM08 face/UV indices and nativefloat32 UVs; every prepared-body UV/sourcevertex pair matches actual source. No re-UV. Actual canonical/export/LOD/seam/mip/lighting validation remains open.",
            "source_manifest_path": SOURCE_PATH, "source_manifest_sha256": SOURCE_SHA,
            "age_limit": "Source age label is a reconstruction comparison for body age "+str(c["age"])+" only. Exact personal skin aging is unknown; identity grade remains separate from reconstructed appearance. Not calibrated albedo or photographic acceptance.",
            "source_component_name": c["component"], "native_resolution": [2048, 2048],
            "maps_supplied": ["diffuse_color_only"], "normal_map": None, "roughness_map": None,
            "upscaled": False}


def select_skin(manifest, choice="young-bronze"):
    need(choice in ("young-bronze", "age-labeled"), "Explicit supported skin choice required")
    # The immutable base era recipe retains the old fallback. Never silently
    # reinterpret a previously modified recipe as the reviewed bronze baseline.
    need(manifest.get("skin_texture", {}).get("sha256") == YOUNG_SHA and
         "skin_component_study" not in manifest, "Start from unchanged young-bronze era recipe")
    if choice == "young-bronze":
        return manifest
    c = component(manifest)
    result = copy.deepcopy(manifest)
    result["skin_texture"] = expected_skin(manifest)
    result["skin_component_study"] = {"choice": "age-labeled", "source_component_name": c["component"],
                                     "source_is_historical_identity_evidence": False,
                                     "production_or_photographic_accepted": False}
    return result


def validate_skin_choice(root, manifest, source):
    skin = manifest["skin_texture"]
    if skin["sha256"] == YOUNG_SHA:
        need("skin_component_study" not in manifest, "Mature study must not masquerade as fallback")
        return
    c = component(manifest)
    need(skin == expected_skin(manifest), "Exact reviewed named-study image, settings and limits required")
    need(manifest.get("skin_component_study") == {
        "choice": "age-labeled", "source_component_name": c["component"],
        "source_is_historical_identity_evidence": False,
        "production_or_photographic_accepted": False}, "Explicit reconstructed skin study context required")
    path = (Path(root)/SOURCE_PATH).resolve()
    need(path.is_relative_to(Path(root).resolve()) and
         hashlib.sha256(path.read_bytes()).hexdigest() == SOURCE_SHA,
         "Exact image provenance changed")
    images = [i for i in source.get("images", []) if i.get("file") == c["file"]]
    need(len(images) == 1 and images[0]["sha256"] == c["sha256"] and
         images[0]["license"] == "CC0-1.0" and images[0]["resolution"] == [2048, 2048] and
         images[0]["maps_supplied"] == ["diffuse_color_only"] and
         images[0]["normal_map"] is None and images[0]["roughness_map"] is None and
         source["legacy_material_files_copied"] is False and source["texture_edits_or_generated_maps"] is False,
         "Native original diffuse-only image provenance must remain explicit")
'''.replace('@SOURCE_SHA@',source_sha)
(T/'human_era_skin_study.py').write_text(module)
s=(P/'preimages/tools/human_era_study_blend.py').read_text();s=s.replace('    parser.add_argument("--root", type=Path, default=ROOT)','    parser.add_argument("--skin-component", choices=["young-bronze", "age-labeled"], default="young-bronze",\n                        help="Explicit reconstructed skin comparison; default keeps original bronze")\n    parser.add_argument("--root", type=Path, default=ROOT)');s=s.replace('    manifest = json.loads(path.read_text())','    manifest = json.loads(path.read_text())\n    from human_era_skin_study import select_skin\n    manifest = select_skin(manifest, args.skin_component)');s=s.replace('    if not args.check_source_only:\n        import bpy','    if manifest.get("skin_component_study"):\n        receipt.update(skin_component_study=manifest["skin_component_study"], skin_texture=manifest["skin_texture"])\n    if not args.check_source_only:\n        import bpy');(T/'human_era_study_blend.py').write_text(s)
s=(P/'preimages/tools/human_era_study_common.py').read_text();needle='    need(skin["sha256"] == "5a53213f061bfa97ee0afd6b40650ffbc089a479c144e63f3c39acceca5853c0",\n         "No unreviewed skin substitution")';assert s.count(needle)==1;s=s.replace(needle,'    from human_era_skin_study import validate_skin_choice\n    validate_skin_choice(root, manifest, skin_source)');s=s.replace('def provenance(manifest, contract, liberty, master, identity, hair_report, normals):\n    return {','def provenance(manifest, contract, liberty, master, identity, hair_report, normals):\n    result = {');s += '\n    if manifest.get("skin_component_study"):\n        result["basis"] = result["basis"].replace(\n            "Cleared young skin atlas and shared hair are reusable engineering components, not age-matched likeness or recorded complexion.",\n            "Source age-labeled native2048 diffuse and shared hair are reconstructed engineering components, not measured personal skin age, likeness, recorded complexion, calibrated albedo or photographic quality.")\n        result["skin_component_study_json"] = json.dumps(manifest["skin_component_study"], sort_keys=True)\n    return result\n';(T/'human_era_study_common.py').write_text(s)
s=(P/'preimages/tools/human_era_study.sh').read_text().replace('OUTPUT=""','OUTPUT=""\nSKIN_COMPONENT="young-bronze"').replace('--era-study|--liberty|--output-dir)','--era-study|--liberty|--output-dir|--skin-component)').replace('        --output-dir) OUTPUT="$2" ;;','        --output-dir) OUTPUT="$2" ;;\n        --skin-component) SKIN_COMPONENT="$2" ;;');s=s.replace('source generators/blender.pin','[[ "$SKIN_COMPONENT" = young-bronze || "$SKIN_COMPONENT" = age-labeled ]] || { echo "Explicit --skin-component young-bronze|age-labeled required" >&2; exit 2; }\nsource generators/blender.pin');s=s.replace('--liberty "$LIBERTY" --check-source-only','--liberty "$LIBERTY" --skin-component "$SKIN_COMPONENT" --check-source-only').replace('--output "$master" --receipt', '--skin-component "$SKIN_COMPONENT" --output "$master" --receipt');(T/'human_era_study.sh').write_text(s)
patch=''
for f in sorted(T.iterdir()):
 pre=P/'preimages/tools'/f.name;before=pre.read_text()if pre.exists()else'';patch+=''.join(difflib.unified_diff(before.splitlines(True),f.read_text().splitlines(True),fromfile='a/chicago/4d/tools/'+f.name if pre.exists()else'/dev/null',tofile='b/chicago/4d/tools/'+f.name))
(P/'LATER-OPT-IN-SKIN-SOURCE.patch').write_text(patch);(P/'PREIMAGES.json').write_text(json.dumps({'base':'Accepted diagnostics-only c935 source layered on2726042ad; never replace newer mainline code wholesale.','sha256':{f.name:h(f)for f in(P/'preimages/tools').iterdir()}},indent=2)+'\n');print(json.dumps({'source_sha256':source_sha,'images':images,'proposed_tools':[f.name for f in T.iterdir()]},indent=2))
