# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicit original age-labeled diffuse studies, only named1812/1904.

Default bronze bytes remain untouched. This module never imports BPy, edits UVs,
ages geometry, infers historical complexion or authors image/maps. Original
PNG images are native2048 and licensed independently from legacy material code.
"""
from pathlib import Path
import copy
import hashlib
import json

YOUNG_SHA = "5a53213f061bfa97ee0afd6b40650ffbc089a479c144e63f3c39acceca5853c0"
SOURCE_PATH = "assets/authored/humans/makehuman_age_labeled_skin/SOURCE.json"
SOURCE_SHA = "76df53ddc5dda58967dacd0cfad646574d762e4fdf80de02d37b02613430d6b5"
COMPONENTS = {
    "1812": {"person_id": "kinzie_john_elder", "age": 49, "date": "1812-08-14",
             "component": "middleage_caucasian_male",
             "file": "middleage_lightskinned_male_diffuse.png",
             "sha256": "ee64f23cc77abb53d0a105fb242032b97e97ef9350ada8135f3544bcd517b5fa"},
    "1904": {"person_id": "glessner_john_j", "age": 61, "date": "1904-07-01",
             "component": "old_caucasian_male",
             "file": "old_lightskinned_male_diffuse.png",
             "sha256": "2f7de9bad2be050290cc3fbcf647992dab53a94c657fb0b44b45966de73af76a"}}


def need(value, message):
    if not value:
        raise ValueError(message)


def component(manifest):
    era = manifest.get("scene")
    need(era in COMPONENTS, "Only named1812/1904 skin studies; never1835/default residents")
    c = COMPONENTS[era]
    need(manifest.get("person_id") == c["person_id"] and
         manifest.get("body_age_years") == c["age"] and manifest.get("scene_date") == c["date"],
         "Fixed named identity/date/body age required for this skin comparison")
    return c


def expected_skin(manifest):
    c = component(manifest)
    return {"path": "assets/authored/humans/makehuman_age_labeled_skin/"+c["file"],
            "sha256": c["sha256"], "license": "CC0-1.0", "color_space": "sRGB",
            "base_color_factor": [1, 1, 1, 1], "roughness": .68,
            "roughness_basis": "Unchanged reconstructed engineering scalar; selected source supplies no measured roughness/normal map. Not converted from legacy specular/shininess.",
            "identity_basis": "Explicit reconstructed reusable skin choice. Vendor component ancestry/color/age label identifies only the source asset, never this person's ancestry, complexion, measured skin age or likeness.",
            "uv_status": "Original package compiledbase.npz shares exact HM08 face/UV indices and nativefloat32 UVs; every prepared-body UV/sourcevertex pair matches actual source. No re-UV. Actual canonical/export/LOD/seam/mip/lighting validation remains open.",
            "source_manifest_path": SOURCE_PATH, "source_manifest_sha256": SOURCE_SHA,
            "age_limit": "Source age label is a reconstruction comparison for body age "+str(c["age"])+" only. Exact personal skin aging is unknown; identity grade remains separate from reconstructed appearance. Not calibrated albedo or photographic acceptance.",
            "source_component_name": c["component"], "native_resolution": [2048, 2048],
            "maps_supplied": ["diffuse_color_only"], "normal_map": None, "roughness_map": None,
            "upscaled": False}


def select_skin(manifest, choice="young-bronze"):
    need(choice in ("young-bronze", "age-labeled"), "Explicit supported skin choice required")
    # The immutable base era recipe retains the old fallback. Never silently
    # reinterpret a previously modified recipe as the reviewed bronze baseline.
    need(manifest.get("skin_texture", {}).get("sha256") == YOUNG_SHA and
         "skin_component_study" not in manifest, "Start from unchanged young-bronze era recipe")
    if choice == "young-bronze":
        return manifest
    c = component(manifest)
    result = copy.deepcopy(manifest)
    result["skin_texture"] = expected_skin(manifest)
    result["skin_component_study"] = {"choice": "age-labeled", "source_component_name": c["component"],
                                     "source_is_historical_identity_evidence": False,
                                     "production_or_photographic_accepted": False}
    return result


def validate_skin_choice(root, manifest, source):
    skin = manifest["skin_texture"]
    if skin["sha256"] == YOUNG_SHA:
        need("skin_component_study" not in manifest, "Mature study must not masquerade as fallback")
        return
    c = component(manifest)
    need(skin == expected_skin(manifest), "Exact reviewed named-study image, settings and limits required")
    need(manifest.get("skin_component_study") == {
        "choice": "age-labeled", "source_component_name": c["component"],
        "source_is_historical_identity_evidence": False,
        "production_or_photographic_accepted": False}, "Explicit reconstructed skin study context required")
    path = (Path(root)/SOURCE_PATH).resolve()
    need(path.is_relative_to(Path(root).resolve()) and
         hashlib.sha256(path.read_bytes()).hexdigest() == SOURCE_SHA,
         "Exact image provenance changed")
    images = [i for i in source.get("images", []) if i.get("file") == c["file"]]
    need(len(images) == 1 and images[0]["sha256"] == c["sha256"] and
         images[0]["license"] == "CC0-1.0" and images[0]["resolution"] == [2048, 2048] and
         images[0]["maps_supplied"] == ["diffuse_color_only"] and
         images[0]["normal_map"] is None and images[0]["roughness_map"] is None and
         source["legacy_material_files_copied"] is False and source["texture_edits_or_generated_maps"] is False,
         "Native original diffuse-only image provenance must remain explicit")
