# SPDX-License-Identifier: GPL-3.0-or-later
"""Read actual original images and named-study source guards; no BPy/model/export."""
from pathlib import Path
import argparse,copy,hashlib,io,json,contextlib,sys,tempfile,subprocess
from PIL import Image
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'tools'))
from human_era_skin_study import select_skin,validate_skin_choice,COMPONENTS,SOURCE_PATH,SOURCE_SHA
from human_era_study_common import validate_manifest,provenance
from human_era_study_blend import parse

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--liberty',required=True);args=parser.parse_args();controls=[];studies=[]
 def refuse(label,fn):
  try:fn()
  except (ValueError,SystemExit):controls.append(label)
  else:raise RuntimeError('Refusal failed: '+label)
 for era,c in COMPONENTS.items():
  original=json.loads((ROOT/'data/humans/recipes/era_studies'/f'{era}.json').read_text());before=copy.deepcopy(original);fallback=select_skin(original);assert fallback is original and fallback==before;contract=validate_manifest(ROOT,fallback,args.liberty);controls.append(era+'/unchanged default bronze')
  chosen=select_skin(original,'age-labeled');assert original==before and {k:v for k,v in chosen.items()if k not in ['skin_texture','skin_component_study']}=={k:v for k,v in before.items()if k!='skin_texture'};validate_manifest(ROOT,chosen,args.liberty);source=json.loads((ROOT/SOURCE_PATH).read_text());validate_skin_choice(ROOT,chosen,source);image=ROOT/chosen['skin_texture']['path'];assert hashlib.sha256(image.read_bytes()).hexdigest()==c['sha256'];im=Image.open(image);assert im.size==(2048,2048)and im.mode=='RGB';im.verify();controls.append(era+'/native original licensed image and unchanged identity/body/wardrobe')
  identity={'sources_for_identity_only':['source-scope-control']};baseprov=provenance(fallback,contract,args.liberty,Path('not-written.blend'),identity,{},[]);newprov=provenance(chosen,contract,args.liberty,Path('not-written.blend'),identity,{},[]);assert 'Cleared young skin atlas'in baseprov['basis']and 'Source age-labeled native2048'in newprov['basis']and 'skin_component_study_json'in newprov;controls.append(era+'/explicit age-label provenance, unchanged young fallback wording')
  for label,changes in [('wrongPerson',{'person_id':'anonymous'}),('wrongDate',{'scene_date':'1835-07-01'}),('wrongAge',{'body_age_years':35}),('1835',{'scene':'1835'})]:
   refuse(era+'/'+label,lambda changes=changes:select_skin({**original,**changes},'age-labeled'))
  for label,key,value in [('changedImagePin','sha256','0'*64),('changedSourcePin','source_manifest_sha256','0'*64),('inventedNormal','normal_map','imaginary.png'),('inventedRoughness','roughness_map','imaginary.png'),('upscaleClaim','native_resolution',[4096,4096]),('licenceChange','license','check_required'),('componentSwap','source_component_name','old_caucasian_male'if era=='1812'else'middleage_caucasian_male')]:
   bad=copy.deepcopy(chosen);bad['skin_texture'][key]=value;refuse(era+'/'+label,lambda bad=bad:validate_skin_choice(ROOT,bad,source))
  bad=copy.deepcopy(chosen);del bad['skin_component_study'];refuse(era+'/implicitAppearanceSelection',lambda:validate_skin_choice(ROOT,bad,source))
  badsource=copy.deepcopy(source);badsource['legacy_material_files_copied']=True;refuse(era+'/legacyMaterialCode',lambda:validate_skin_choice(ROOT,chosen,badsource))
  refuse(era+'/reselectModifiedRecipe',lambda:select_skin(chosen,'young-bronze'))
  studies.append({'era':era,'person_id':chosen['person_id'],'identity_grade':chosen['identity_grade'],'appearance_grade':chosen['appearance_grade'],'component':c['component'],'image_sha256':c['sha256'],'native_resolution':[2048,2048],'diffuse_only':True,'body_or_wardrobe_changed':False,'BPy_executed':False})
 with contextlib.redirect_stderr(io.StringIO()):refuse('CLIunknownSkin',lambda:parse(['--era-study','1812','--liberty',args.liberty,'--check-source-only','--skin-component','invented']))
 # Only the actual shell argument prefix; stops BEFORE any Blender/cache lookup.
 prefix=(ROOT/'tools/human_era_study.sh').read_text().split('source generators/blender.pin',1)[0]+'\nprintf "SOURCE_SKIN=%s\\n" "$SKIN_COMPONENT"\n'
 with tempfile.TemporaryDirectory()as tmp:
  base=['--era-study','both','--liberty',args.liberty,'--output-dir',str(Path(tmp)/'never-created')]
  for label,argv,code,want in [('default',base,0,'young-bronze'),('explicitAge',base+['--skin-component','age-labeled'],0,'age-labeled'),('unknown',base+['--skin-component','invented'],2,None),('missing',base+['--skin-component'],2,None)]:
   r=subprocess.run(['bash','-c',prefix,str(ROOT/'tools/human_era_study.sh'),*argv],capture_output=True,text=True);assert r.returncode==code and(want is None or 'SOURCE_SKIN='+want in r.stdout);controls.append('shell-prefix/'+label)
 if 'bpy'in sys.modules:raise RuntimeError('BPy imported in source-only test')
 print(json.dumps({'PASS':True,'scope':'Actual image bytes/PIL metadata and named appearance source/refusal/argument-prefix controls; no BPy/model/export/browser','studies':studies,'controls':controls},indent=2))
if __name__=='__main__':main()
