"""Read original package base OBJ and current HM08/prepared UVs; no install/model execution."""
from pathlib import Path
import io,tarfile,json,hashlib,collections
P=Path(__file__).parent;B=P.parent;deb=B/'mature-skin-makehuman-data_1.1.1-1_all.deb';current=Path('/workspace/chicago/chicago/4d/assets/authored/humans/makehuman_hm08/makehuman/data/3dobjs/base.obj')
class Limited(io.RawIOBase):
 def __init__(self,f,n):self.f=f;self.remaining=n
 def readable(self):return True
 def read(self,n=-1):
  b=self.f.read(min(self.remaining,self.remaining if n<0 else n));self.remaining-=len(b);return b
 def readinto(self,b):d=self.read(len(b));b[:len(d)]=d;return len(d)
raw=None;member=None
with deb.open('rb')as f:
 assert f.read(8)==b'!<arch>\n'
 while True:
  h=f.read(60)
  if not h:break
  name=h[:16].decode().strip().rstrip('/');n=int(h[48:58]);part=Limited(f,n)
  if name.startswith('data.tar'):
   with tarfile.open(fileobj=part,mode='r|*')as t:
    for m in t:
     if m.isfile()and m.name.endswith('/data/3dobjs/base.npz'):
      assert raw is None;raw=t.extractfile(m).read();member=m.name
  while part.remaining:
   if not part.read(min(1048576,part.remaining)):raise ValueError('truncated package')
  if n%2:f.read(1)
assert raw is not None
legacy=P/'evidence/legacy-package-base.npz';legacy.write_bytes(raw)
md5s={path:digest for digest,path in (line.split(maxsplit=1)for line in(B/'mature-skin-package-study/package-md5sums').read_text().splitlines())};assert hashlib.md5(raw).hexdigest()==md5s[member.lstrip('./')]
def parse(raw):
 uv=[];faces=[];points=0
 for line in raw.decode().splitlines():
  fields=line.split()
  if not fields:continue
  if fields[0]=='v':points+=1
  if fields[0]=='vt':uv.append(tuple(map(float,fields[1:3])))
  if fields[0]=='f':faces.append([tuple(int(x)-1 if x else None for x in term.split('/'))for term in fields[1:]])
 return uv,faces,points
import numpy as np
uv,faces,points=parse(current.read_bytes());z=np.load(io.BytesIO(raw),allow_pickle=False)
assert np.array_equal(np.array(uv,dtype=np.float32),z['texco'])
assert np.array_equal(np.array([[c[0]for c in f]for f in faces]),z['fvert'])
assert np.array_equal(np.array([[c[1]for c in f]for f in faces]),z['fuvs'])
assert points==len(z['coord'])
uv_storage_delta=float(np.max(abs(np.array(uv)-z['texco'])))
# A visually chosen conservative original-pixel badge rectangle, including2px
# sampling margin; check actual UV triangle interiors, not vertices alone.
rect=(1982/2048,0.,1.,530/2048)
def clipped(poly,axis,value,keep):
 result=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  ia=keep(a[axis],value);ib=keep(b[axis],value)
  if ia:result.append(a)
  if ia!=ib:
   t=(value-a[axis])/(b[axis]-a[axis]);result.append([a[k]+t*(b[k]-a[k])for k in range(2)])
 return result
def intersects(tri):
 q=tri
 for axis,value,keep in [(0,rect[0],lambda a,b:a>=b),(0,rect[2],lambda a,b:a<=b),(1,rect[1],lambda a,b:a>=b),(1,rect[3],lambda a,b:a<=b)]:
  if not q:return False
  q=clipped(q,axis,value,keep)
 return len(q)>=3 and abs(sum(a[0]*b[1]-b[0]*a[1]for a,b in zip(q,q[1:]+q[:1])))>1e-18
# Every authored prepared UV/source vertex pair comes from an actual source face-corner.
allowed={(corner[0],uv[corner[1]])for face in faces for corner in face};results=[]
for era,name in [('1812','body.json'),('1904','glessner_john_j_1904.prepared.json')]:
 path=B/'era-canonical-integration-next/app/chicago/4d/assets/authored/humans/era_studies'/era/name;d=json.loads(path.read_text());count=0;badge_intersections=0
 for mesh in d['meshes']:
  for sid,pair in zip(mesh['source_vertex_indices'],mesh['uvs']):
   assert (sid,tuple(pair))in allowed,(sid,pair);count+=1
  badge_intersections+=sum(intersects([mesh['uvs'][i]for i in tri])for tri in mesh['triangles'])
 results.append({'era':era,'body_path':str(path),'body_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'uv_source_pairs':count,'all_pairs_exact_original_OBJ_face_corners':True,'body_triangles':sum(len(m['triangles'])for m in d['meshes']),'triangles_intersecting_conservative_badge_box_plus2px':badge_intersections})
r={'PASS':True,'scope':'Original1.1.1 skin-package compiledbase.npz UV-coordinate(nativefloat32)+exactface-index correspondence with actual currentHM08 OBJ, plus every current1812/1904 prepared body UV/sourcevertex pair. No Blender/mesh generation/render/export/appearance validation.','package_sha256':hashlib.sha256(deb.read_bytes()).hexdigest(),'package_base_member':member,'package_base_md5_control_verified':True,'legacy_base_sha256':hashlib.sha256(raw).hexdigest(),'current_base_sha256':hashlib.sha256(current.read_bytes()).hexdigest(),'all_UV_coordinates_equal_after_native_float32_storage':True,'maximum_decimal_OBJ_to_original_float32_UV_delta':uv_storage_delta,'all_face_corner_vertex_UV_indices_exact':True,'badge_original_pixel_box_plus_margin':[1982,1518,2048,2048],'graphical_vertex_count':points,'uv_count':len(uv),'faces':len(faces),'prepared_bodies':results,'limits':['UV-atlas registration is established; source-native2048 resolution does not prove skin quality, seam continuity or named likeness.','Conservative badge rectangle has been checked against full prepared-body UVtriangle interiors; downstream mips, texture transform/export/seam rendering remain untested. No original image resizing, re-UV, color transform or age/complexion inference.']};(P/'evidence/UV-REGISTRATION.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
