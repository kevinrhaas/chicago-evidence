#!/usr/bin/env python3
"""Read only coherent saved observer snapshot; no API or release/merge action."""
import pathlib,json,importlib.util,hashlib,datetime
s=pathlib.Path('/workspace/shared');p=s/'verify_25b92c95_normal_dev_gates_v11_FINAL.py';assert hashlib.sha256(p.read_bytes()).hexdigest()=='477f0ad4606cc9a89af8a59bbaab57cfe93371388a8c9fb76be9687ea8c25924';sp=importlib.util.spec_from_file_location('v11',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);v=m.configure();o=m.load(s/'final-25b92c95-metadata/observer.json');saved=o.get('terminal_jobs',{});selected=[];normal=[]
for c in o['latest_snapshot']['check_runs']:
 if c['status']=='completed':m.need(c['conclusion']=='success'or m.optional_skip_check(c),'Actual failed check/unbound skip '+str(c['id'])+' '+str(c['conclusion']))
for key,record in saved.items():
 rid=int(key);spec=o['expected_runs'][key];run=next(r for r in o['latest_snapshot']['runs']if r['id']==rid);m.run_ok(run,rid,spec);jobs=record['jobs']
 if spec['selected_smoke']:v.jobs_ok(jobs,rid,{'smoke':v.SMOKE_STEPS});selected.append(rid)
 elif rid==m.HUMAN_RUN:
  v.jobs_ok(jobs,rid,{'humans':v.HUMAN_STEPS});skip=next(j for j in jobs if j['name']=='teamster-studies');m.need(skip['id']==m.TEAM_SKIP and skip['status']=='completed'and skip['conclusion']=='skipped'and not skip['steps'],'Actual optional PR human skip changed');normal.append(rid)
 else:
  name,steps=next((name,steps)for name,(known,steps)in m.NORMAL.items()if known==rid);v.jobs_ok(jobs,rid,{name:steps});normal.append(rid)
a={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'snapshot':o['latest_snapshot']['at'],'scope':'Saved ACTUAL terminal jobs and mandatory steps only; not full CI gate, stdout or artifact proof','selected_actual_strict_success':selected,'normal_actual_strict_success':normal,'selected_status':o.get('selected_conclusions'),'normal_status':o.get('normal_conclusions'),'observer_error':o.get('error'),'observer_finished':o.get('finished_utc')};(s/'25b92c95-saved-terminal-partial-audit.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(dict(a,selected_actual_strict_success=len(selected),normal_actual_strict_success=len(normal)),indent=2))
