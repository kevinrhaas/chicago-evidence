#!/usr/bin/env python3
"""Offline controls only. Future job/run SUCCESS records are synthetic, never CI evidence."""
import pathlib,importlib.util,json,hashlib,copy
s=pathlib.Path('/workspace/shared');p=s/'verify_25b92c95_normal_dev_gates_v11_FINAL.py';sp=importlib.util.spec_from_file_location('v11',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);v=m.configure();w=m.module('approved_observer',m.OBSERVER,m.OBSERVER_SHA);receipt=s/'25b92c95-exact18-discovery-reconciliation/receipt.json';assert m.digest(receipt.read_bytes())=='544aac2136b17810809752286c44462b789badc656181c2f91c164693ba0e888';manifest,dispatch,expected=w.inputs(receipt);assert m.digest((s/'25b92c95-exact18-dispatch/receipt.json').read_bytes())==dispatch['reconciliation']['original_receipt_sha256'];assert m.digest((s/'reconcile_25b92c95_exact18_DISCOVERY_SOURCE_ONLY.py').read_bytes())==dispatch['reconciliation']['source_sha256']=='7efec2ec2aeb8977c6ea2a6844e3f34fb459025df7c544149b38fa55b6446ab8';v.source_ok({q:m.git('show',m.SHA+':'+q)for q in v.PINS});absence=m.bake_not_triggered(v);m.normal_source_contracts(v,manifest)
o=m.load(s/'final-25b92c95-metadata/observer.json');saved=copy.deepcopy(o['terminal_jobs']);actual=sorted(saved);runs={r['id']:copy.deepcopy(r)for r in o['latest_snapshot']['runs']};actualjobids={j['id']for r in saved.values()for j in r['jobs']};checks=[copy.deepcopy(c)for c in o['latest_snapshot']['check_runs']if c['id']in actualjobids];synthetic=[]
for rid,spec in expected.items():
 if str(rid)in saved:continue
 synthetic.append(rid);runs[rid].update(status='completed',conclusion='success');name='smoke'if spec['selected_smoke']else next(name for name,(known,steps)in m.NORMAL.items()if known==rid);steps=v.SMOKE_STEPS if spec['selected_smoke']else m.NORMAL[name][1];jid=900000000000+rid;j={'id':jid,'run_id':rid,'run_attempt':1,'head_sha':m.SHA,'name':name,'status':'completed','conclusion':'success','check_run_url':f'https://api.github.com/repos/{m.REPO}/check-runs/{jid}','html_url':f'https://github.com/{m.REPO}/actions/runs/{rid}/job/{jid}','steps':[{'name':n,'status':'completed','conclusion':'success'}for n in steps]};saved[str(rid)]={'run_id':rid,'attempt':1,'head_sha':m.SHA,'jobs':[j]};checks.append({k:j[k]for k in ['id','head_sha','name','status','conclusion','html_url']})
results=[]
def validate(ss=saved,cc=checks):
 ids,_=m.records_ok(v,ss,runs,expected);m.checks_ok(v,{'total_count':len(cc),'check_runs':cc},ids);assert len(ids)==23
validate();results.extend(['Actual26 source/normal contracts and bake absence source passed','Actual original/reconciliation/source receipt hashes preserved','Actual terminal normal records plus explicitly synthetic future jobs pass22workflow/23job contract'])
for label in ['unbound skipped check','extra bake saved record','mandatory smoke step failure','wrong optional human skip ID']:
 ss=copy.deepcopy(saved);cc=copy.deepcopy(checks)
 if label=='unbound skipped check':next(c for c in cc if c['conclusion']=='success')['conclusion']='skipped'
 elif label=='extra bake saved record':ss['123']=copy.deepcopy(next(iter(ss.values())))
 elif label=='mandatory smoke step failure':next(j for rec in ss.values()for j in rec['jobs']if j['name']=='smoke')['steps'][-1]['conclusion']='failure'
 else:next(j for j in ss[str(m.HUMAN_RUN)]['jobs']if j['name']=='teamster-studies')['id']+=1
 try:validate(ss,cc)
 except ValueError:results.append('Rejected '+label)
 else:raise AssertionError('Control failed '+label)
a={'scope':'OFFLINE CONTROLS ONLY; no requests or --verify, no CI gate/merge/photographic claim','source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'actual_terminal_normal_ids':actual,'synthetic_future_run_ids':synthetic,'actual_optional_human_skip_id':m.TEAM_SKIP,'passed':len(results),'results':results,'actual_bake_absence_source':absence};(s/'25b92c95-V11-FINAL-OFFLINE-controls.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(a,indent=2))
