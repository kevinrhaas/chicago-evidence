#!/usr/bin/env python3
"""One bounded passive metadata observer for exact25b9 18smokes+4 normal runs. No retries or release actions."""
import argparse,datetime,hashlib,importlib.util,json,pathlib,time,collections,sys
S=pathlib.Path('/workspace/shared');MANIFEST=S/'25b92c95-exact18-qualification-MANIFEST.json';HELPER=S/'watch_transport_metadata_dev28c53.py';HELPER_SHA='e34bd7b051a91db35d17ff0e34613925c74149935089f7cfc38236ed91754ae4'
def need(c,m):
 if not c:raise ValueError(m)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(path,data):
 temp=path.with_name(path.name+'.tmp');temp.write_text(json.dumps(data,indent=2)+'\n');temp.replace(path)
CALLER_SHA256='fb5264df180d351186e5b5fce81d22808767fad7273cd4c6204d487b55bbf295'
def inputs(receipt_path):
 from importlib import util
 caller=S/'dispatch_25b92c95_exact18_BASE_OBSERVATIONAL.py';need(hashlib.sha256(caller.read_bytes()).hexdigest()==CALLER_SHA256,'Reviewed dispatch caller changed');sp=util.spec_from_file_location('grid_source',caller);c=util.module_from_spec(sp);sp.loader.exec_module(c);m=c.load_manifest();requested=c.cells(m);r=json.loads(receipt_path.read_text());need(r['source_sha256']==CALLER_SHA256 and r['manifest_sha256']==c.MANIFEST_SHA256,'Receipt caller/manifest source bindings changed');need(r['repository']==m['repository']and r['branch']==m['branch']and r['sha']==m['sha']and r['tree']==m['tree']and r['remote_head_after']==m['sha'],'Frozen dispatch identity mismatch');need(r.get('dispatch_complete')is True and len(r['dispatches'])==18 and all(x.get('post_attempted')is True and x.get('post_succeeded')is True for x in r['dispatches']),'Exactly18 successful dispatch receipts required');need(collections.Counter((x['viewport'],x['stage'])for x in r['dispatches'])==collections.Counter(requested),'Dispatch cell grid differs')
 expected={}
 for row in r['discovered_runs']:
  need(row['id']not in expected and row['head_sha']==m['sha']and row['run_attempt']==1 and row['event']=='workflow_dispatch'and row['path']=='.github/workflows/'+m['workflow'],'Discovered smoke identity changed');expected[row['id']]={'path':row['path'],'event':'workflow_dispatch','attempt':1,'selected_smoke':True}
 need(len(expected)==18,'Exactly18 smoke run IDs required')
 for row in m['known_normal_runs']:
  need(row['id']not in expected,'Normal run ID overlaps smoke');expected[row['id']]={'path':row['path'],'event':row['event'],'attempt':row['attempt'],'selected_smoke':False}
 need(len(expected)==22,'Exactly18selected+4normal required');return m,r,expected
def validate(run,rid,spec,m):
 need(run['id']==rid and run['head_sha']==m['sha']and run['head_branch']==m['branch']and run['path']==spec['path']and run['event']==spec['event']and run['run_attempt']==spec['attempt'],'Observed run head/branch/path/event/attempt changed')
def meta(run):return{k:run.get(k)for k in ['id','name','path','event','head_sha','head_branch','run_attempt','status','conclusion','created_at','updated_at','html_url']}
def terminal_jobs(api,rid,run,spec,m):
 data=api.get(f"repos/{m['repository']}/actions/runs/{rid}/attempts/{spec['attempt']}/jobs?per_page=100");need(data['total_count']==len(data['jobs']),'Terminal jobs truncated');need(len({j['id']for j in data['jobs']})==len(data['jobs']),'Duplicate terminal job IDs')
 for j in data['jobs']:need(j['run_id']==rid and j['head_sha']==m['sha']and j['run_attempt']==spec['attempt'],'Terminal job binding mismatch')
 return{'run_id':rid,'head_sha':m['sha'],'attempt':spec['attempt'],'collected_utc':now(),'jobs':data['jobs'],'scope':'Actual job/step JSON only; no logs/artifacts inspected'}
def main():
 a=argparse.ArgumentParser();a.add_argument('dispatch',type=pathlib.Path);a.add_argument('--out',required=True,type=pathlib.Path);a.add_argument('--max-seconds',required=True,type=int);x=a.parse_args();m,r,expected=inputs(x.dispatch);need(0<x.max_seconds<=m['observer']['max_seconds'],'At most180min observation required');need(hashlib.sha256(HELPER.read_bytes()).hexdigest()==HELPER_SHA,'Reviewed API helper changed');sp=importlib.util.spec_from_file_location('old_api',HELPER);w=importlib.util.module_from_spec(sp);sp.loader.exec_module(w)
 out=x.out.resolve();need(out.is_relative_to(S),'Outside shared evidence required');out.mkdir(exist_ok=False);save(out/'manifest.json',m);save(out/'dispatch.json',r);start=time.monotonic();deadline=start+x.max_seconds;api=w.MetadataAPI(deadline,out);jobs={};attempted=set();record={'sha':m['sha'],'tree':m['tree'],'started_utc':now(),'max_seconds':x.max_seconds,'poll_seconds':60,'api_timeout_seconds':45,'expected_runs':{str(k):v for k,v in expected.items()},'merge_qualified':False,'stdout_union':'UNPROVEN','artifacts':'UNINSPECTED','photographic_acceptance':'OPEN'};save(out/'observer.json',record);exitcode=1
 try:
  while time.monotonic()<deadline:
   cycle=time.monotonic();listing=api.get(f"repos/{m['repository']}/actions/workflows/{m['workflow']}/runs?head_sha={m['sha']}&event=workflow_dispatch&per_page=100");smokeids={k for k,v in expected.items()if v['selected_smoke']};need(listing['total_count']==len(listing['workflow_runs'])==18 and {z['id']for z in listing['workflow_runs']}==smokeids,'Remote smoke run set differs');runs={z['id']:z for z in listing['workflow_runs']}
   for rid,spec in expected.items():
    if not spec['selected_smoke']:runs[rid]=api.get(f"repos/{m['repository']}/actions/runs/{rid}")
   for rid,run in runs.items():validate(run,rid,expected[rid],m)
   checks=api.get(f"repos/{m['repository']}/commits/{m['sha']}/check-runs?per_page=100");pr=api.get(f"repos/{m['repository']}/pulls/1041");need(pr['state']=='open'and pr['head']['sha']==m['sha']and pr['head']['ref']==m['branch']and pr['base']['ref']=='dev','PR exacthead/state/target changed')
   snapshot={'at':now(),'sha':m['sha'],'runs':[meta(z)for _,z in sorted(runs.items())],'check_runs':checks['check_runs'],'checks_total_count':checks['total_count'],'checks_complete':checks['total_count']==len(checks['check_runs']),'pr':{k:pr.get(k)for k in ['state','draft','mergeable','mergeable_state']},'pr_base_sha':pr['base']['sha']};save(out/'latest.json',snapshot)
   with(out/'snapshots.jsonl').open('a')as f:f.write(json.dumps(snapshot)+'\n')
   for rid,run in sorted(runs.items()):
    if run['status']=='completed'and rid not in attempted:
     attempted.add(rid);save(out/'terminal-job-attempts.json',sorted(attempted));jobs[str(rid)]=terminal_jobs(api,rid,run,expected[rid],m);save(out/'terminal-jobs.json',jobs)
   selected=[v for k,v in runs.items()if k in smokeids];terminal=all(z['status']=='completed'for z in runs.values());counts=collections.Counter(z['conclusion']or'pending'for z in selected);normal=collections.Counter(z['conclusion']or'pending'for k,z in runs.items()if k not in smokeids);record.update(latest_snapshot=snapshot,terminal_jobs=jobs,metadata_requests=api.count,selected_conclusions=dict(counts),normal_conclusions=dict(normal),all22runs_terminal=terminal,all18selected_workflows_success=all(z['status']=='completed'and z['conclusion']=='success'for z in selected),merge_qualified=False);save(out/'observer.json',record);print(json.dumps({'at':snapshot['at'],'selected':dict(counts),'normal':dict(normal),'all22runs_terminal':terminal,'merge_qualified':False}),flush=True)
   if terminal:record['stop_reason']='all22target runs terminal; strict final source/job/check gate remains separate';exitcode=0 if all(z['conclusion']=='success'for z in runs.values())else 1;break
   remaining=deadline-time.monotonic()
   if remaining>0:time.sleep(min(remaining,max(0,60-(time.monotonic()-cycle))))
  else:record['stop_reason']='bounded180min wall reached; no extension'
 except Exception as e:record.update(stop_reason='metadata error; stopped without retry',error=str(e));print(json.dumps({'error':str(e),'no_retry':True}),flush=True)
 finally:record.update(finished_utc=now(),elapsed_seconds=time.monotonic()-start,metadata_requests=api.count,observer_exit_code=exitcode,merge_qualified=False);save(out/'observer.json',record)
 return exitcode
if __name__=='__main__':sys.exit(main())
