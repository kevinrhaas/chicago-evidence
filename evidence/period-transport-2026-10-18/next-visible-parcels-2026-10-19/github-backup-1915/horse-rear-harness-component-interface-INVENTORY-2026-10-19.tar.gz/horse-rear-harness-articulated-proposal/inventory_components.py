# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only indexed coat ownership and saved-pose feasibility diagnostics.

No generated horse/strap coordinates, candidate, fit or runtime evaluator.
Source index components are not welded by geometric proximity.
"""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib, json, struct, sys
import numpy as np

HERE = Path(__file__).resolve().parent
HORSE = Path('/workspace/shared/horse-combined-oral-neck-mane-prefix-next/candidate-one/candidate.glb')
CAPTURES = Path('/workspace/shared/horse-ab70-3bb45-motion-next/runs/full63')
PARAMS = Path('/workspace/shared/horse-breeching-swept-route-next/proposed-parameters.json')
EXPECTED_HORSE = 'ab70aff958bc8a2780458d37212be1866c730817f485fbebbf53bd3c0e3931c3'
EXPECTED_GEAR = '3bb45abfad635bda74fd2aa999dcf869269e5efad1c888dfb4d615f7b0667825'
sys.path.insert(0, '/workspace/shared/horse-ab70-3bb45-motion-next')
from unsigned_distance import pts_tri

def need(value, message):
    if not value:
        raise ValueError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def parse_glb(raw):
    need(struct.unpack_from('<III', raw) == (0x46546c67, 2, len(raw)), 'GLB header')
    n, tag = struct.unpack_from('<II', raw, 12)
    need(tag == 0x4e4f534a, 'GLB JSON')
    doc = json.loads(raw[20:20+n])
    size, tag = struct.unpack_from('<II', raw, 20+n)
    need(tag == 0x004e4942 and 28+n+size == len(raw), 'GLB BIN')
    need(len(doc['buffers']) == 1 and 'uri' not in doc['buffers'][0], 'internal buffer')
    return doc, raw[28+n:]

def accessor(doc, binary, index):
    a = doc['accessors'][index]
    v = doc['bufferViews'][a['bufferView']]
    need('sparse' not in a and not a.get('normalized') and 'byteStride' not in v, 'accessor storage')
    dtype = {5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']]
    width = {'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']]
    start = v.get('byteOffset',0) + a.get('byteOffset',0)
    length = a['count'] * width * np.dtype(dtype).itemsize
    need(a.get('byteOffset',0) + length <= v['byteLength'], 'accessor view bounds')
    need(start + length <= len(binary) and start + length <= doc['buffers'][0]['byteLength'], 'buffer bounds')
    out = np.frombuffer(binary, dtype=dtype, count=a['count']*width, offset=start).reshape(-1,width)
    need(np.isfinite(out).all(), 'finite accessor')
    return out

def source_components(faces):
    parent = list(range(int(faces.max())+1))
    def root(v):
        while parent[v] != v:
            parent[v] = parent[parent[v]]
            v = parent[v]
        return v
    for a,b,c in faces:
        a,b,c = map(int,(a,b,c))
        ra = root(a)
        parent[root(b)] = ra
        parent[root(c)] = ra
    groups = {}
    for i, face in enumerate(faces):
        groups.setdefault(root(int(face[0])),[]).append(i)
    return list(groups.values())

def topology(faces):
    edges = defaultdict(list)
    for i, face in enumerate(faces):
        for j in range(3):
            a,b = map(int,(face[j],face[(j+1)%3]))
            edges[tuple(sorted((a,b)))].append((a,b,i))
    boundary = [list(v[0][:2]) for v in edges.values() if len(v)==1]
    bad = [list(k) for k,v in edges.items() if len(v)>2 or (len(v)==2 and v[0][:2] != v[1][:2][::-1])]
    return {'vertices':len(np.unique(faces)), 'edges':len(edges), 'faces':len(faces),
            'euler':len(np.unique(faces))-len(edges)+len(faces),
            'boundary_directed_edges':boundary,'nonmanifold_or_same_direction_edges':bad}

def load_capture(path, name):
    meta_raw = (path/(name+'.json')).read_bytes()
    meta = json.loads(meta_raw)
    buf = (path/(name+'.f64')).read_bytes()
    need(meta['buffer_sha256'] == sha(buf) and meta['precision'] == 'float64_world', 'saved capture buffer')
    need(meta['input'][1] == (EXPECTED_HORSE if name=='horse' else EXPECTED_GEAR), 'saved model identity')
    need(meta['triangleCount'] * 9 * 8 == len(buf), 'complete saved triangle bytes')
    out = np.frombuffer(buf, dtype='<f8').reshape(-1,3,3)
    need(np.isfinite(out).all(), 'finite captured coordinates')
    return meta, out, {'metadata_sha256':sha(meta_raw),'buffer_sha256':sha(buf),'path':str(path)}

def main():
    raw = HORSE.read_bytes()
    need(sha(raw)==EXPECTED_HORSE, 'immutable horse hash')
    doc,binary = parse_glb(raw)
    prim = doc['meshes'][0]['primitives'][0]
    need(doc['meshes'][0]['name']=='skinned_equine_coat' and prim.get('mode',4)==4, 'coat primitive')
    pos = accessor(doc,binary,prim['attributes']['POSITION'])
    joints = accessor(doc,binary,prim['attributes']['JOINTS_0'])
    weights = accessor(doc,binary,prim['attributes']['WEIGHTS_0'])
    face = accessor(doc,binary,prim['indices']).reshape(-1,3).astype(np.int64)
    need(len(pos)==len(joints)==len(weights) and len(face)==10724, 'complete coat')
    need(np.allclose(weights.sum(1),1,atol=1e-7,rtol=0), 'skin weights')
    owners = [n for n in doc['nodes'] if n.get('mesh')==0]
    need(len(owners)==1 and 'skin' in owners[0], 'unique coat skin')
    skin_joints = doc['skins'][owners[0]['skin']]['joints']
    components = source_components(face)
    need(len(components)==17, 'independent component count')
    idle_meta,idle,idle_pin = load_capture(CAPTURES/'pose-00-idle/idle-fit/capture','horse')
    need(idle_meta['meshes'][0]['count']==len(face) and idle_meta['meshes'][0]['start']==0, 'global face order')
    index_sha = sha(face.astype('<u4').tobytes())
    need(index_sha==idle_meta['meshes'][0]['indexStreamSHA256'], 'decoded/captured index stream')
    rows=[]
    face_component={}
    for c,ids in enumerate(components):
        for i in ids: face_component[i]=c
        vertices=np.unique(face[ids]); cohort=Counter()
        for v in vertices:
            signature=tuple((int(skin_joints[int(j)]),float(w)) for j,w in zip(joints[v],weights[v]) if w>0)
            cohort[signature]+=1
        rows.append({'component':c,'face_ids':ids,'source_vertex_ids':vertices.tolist(),
            'topology':topology(face[ids]),'source_position_bounds_m':[pos[vertices].min(0).tolist(),pos[vertices].max(0).tolist()],
            'actual_idle_world_bounds_m':[idle[ids].min((0,1)).tolist(),idle[ids].max((0,1)).tolist()],
            'skin_cohorts':[{'vertices':n,'joint_nodes_and_weights':[{'node':j,'name':doc['nodes'][j].get('name'),'weight':w} for j,w in signature]} for signature,n in sorted(cohort.items())]})
    seeds={str(i):{'source_mesh':0,'primitive':0,'face':i,'indices':face[i].tolist(),
                    'component':face_component[i],'barycentric':[1/3]*3,
                    'meaning':'Diagnostic face centroid only, NOT a ribbon anchor or chart'} for i in [51,69,1248,1618,318]}
    # Read all already-qualified captures; no model rendering or new pose qualification.
    motion=[]
    for folder in sorted(CAPTURES.glob('pose-*')):
        meta,tri,pin=load_capture(folder/'idle-fit/capture','horse')
        need(meta['meshes'][0]['indexStreamSHA256']==index_sha,'stable source topology')
        world={key:tri[int(key)].mean(0) for key in seeds}
        need(np.array(meta['root_world']).reshape(4,4).T.shape==(4,4),'root matrix')
        root_inv=np.linalg.inv(np.array(meta['root_world']).reshape(4,4).T)
        local={key:(root_inv@np.r_[v,1])[:3] for key,v in world.items()}
        motion.append({'pose':meta['pose'],'pin':pin,'root_local_seed_centroids_m':{k:v.tolist() for k,v in local.items()},
           'centroid_separations_m':{label:float(np.linalg.norm(local[a]-local[b])) for label,a,b in [('torso_l_to_hind_l','51','1248'),('torso_r_to_hind_r','69','1618'),('hind_l_to_hind_r','1248','1618')]}})
    need(len(motion)==63 and Counter(x['pose']['clip'] for x in motion)=={'idle':21,'walk':21,'trot':21},'actual 63 sample coverage')
    for clip in ['idle','walk','trot']:
        need(sorted(x['pose']['phase'] for x in motion if x['pose']['clip']==clip)==[i/20 for i in range(21)],'actual phase lattice')
    # Existing endpoint-to-protected-surface diagnostics; no endpoint feasibility claim from point distances.
    gm,gear,gpin=load_capture(CAPTURES/'pose-00-idle/idle-fit/capture','candidate')
    params=json.loads(PARAMS.read_text())['hindgear_contour_study']
    protected=[m for m in gm['meshes'] if m['name'] not in ['breeching','hip_support_l','hip_support_r']]
    need(len(protected)==33,'protected 33 parts')
    endpoints={}
    for label,point in [('breeching_front_l',params['breeching_route_m'][0]),('breeching_front_r',params['breeching_route_m'][-1]),('hip_top_l',params['hip_support_routes_m']['l'][-1]),('hip_top_r',params['hip_support_routes_m']['r'][-1])]:
        near=[]
        for part in protected:
            start,count=part['start'],part['count']; ds=pts_tri(np.array(point),gear[start:start+count]); k=int(ds.argmin())
            near.append({'part':part['name'],'distance_m':float(np.sqrt(ds[k])),'nearest_global_face':start+k})
        endpoints[label]={'original_root_local_point_m':point,'nearest_protected_parts':sorted(near,key=lambda x:x['distance_m'])[:5],
                          'limit':'Point-to-surfaces only, not a shared seam or complete attachment certificate'}
    summary={key:{'minimum_m':min(x['centroid_separations_m'][key] for x in motion),'maximum_m':max(x['centroid_separations_m'][key] for x in motion),
                 'span_m':max(x['centroid_separations_m'][key] for x in motion)-min(x['centroid_separations_m'][key] for x in motion)} for key in motion[0]['centroid_separations_m']}
    out={'status':'READ_ONLY_SOURCE_AND_SAVED_CAPTURE_DIAGNOSTICS; NOT a chart, candidate, fit or production acceptance',
         'horse_sha256':sha(raw),'coat_index_u32_sha256':index_sha,'idle_pin':idle_pin,
         'source_attributes_sha256':{name:sha(accessor(doc,binary,idx).tobytes()) for name,idx in prim['attributes'].items()},
         'components':rows,'diagnostic_seeds':seeds,'all63_saved_motion':motion,
         'diagnostic_centroid_separation_ranges':summary,'existing_endpoint_diagnostics':endpoints,
         'gear_idle_pin':gpin,'params_sha256':sha(PARAMS.read_bytes()),
         'refusals':['No cross-component triangle adjacency','No finalized full-width chart','No inferred source-owned seam from nearest distances','No elastic or material length inference from centroid separations','No new emitted geometry or fit rerun']}
    (HERE/'COMPONENT-AND-INTERFACE-INVENTORY.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'status':out['status'],'components':len(rows),'coat_faces':len(face),'saved_poses':len(motion),'centroid_diagnostics':summary,'endpoints':endpoints},indent=2))

if __name__=='__main__': main()
