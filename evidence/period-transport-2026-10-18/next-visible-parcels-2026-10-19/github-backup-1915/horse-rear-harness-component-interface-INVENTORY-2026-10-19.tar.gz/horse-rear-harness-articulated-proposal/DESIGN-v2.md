# New articulated rear harness v2 — SOURCE ONLY, not a candidate

SUPERSEDES the single-connected-chart assumption in frozen DESIGN.md. Independent source review found17 vertex-connected coat components: torso faces51/69 component0 (5423faces), upperhind1248 component3 (192faces),1618 component5 (192faces). No triangle adjacency exists between these regions. A combined coat chart is therefore impossible without a separate bridge/interface authority. Preserve the original design and its archive as a failed source assumption, not geometry failure.

Immutable parent: horse ab70aff958bc8a2780458d37212be1866c730817f485fbebbf53bd3c0e3931c3 + gear 3bb45abfad635bda74fd2aa999dcf869269e5efad1c888dfb4d615f7b0667825. Their 63 sampled strict-fit PASS and b8fac229 visual archive remain unchanged. No geometry was generated here. No new fitting, browser, parameter search, or source asset mutation occurred.

## Actual visible failure, by part

ACTUAL-IDLE-LANDMARKS.json binds the saved idle0 Float64 buffer/metadata and contains actual nearest horse triangles and global face indices, plus every sparse diagnostic sample. These are point-to-ALL-horse-triangle distances at selected actual gear vertices; they are neither exhaustive surface maxima nor a new collision certificate.

|Part|Sampled minimum/maximum distance|Meaning|
|---|---|---|
|breeching|12.886 /112.024 mm|Large rear stand-off is real, not merely perspective. Worst sampled point [0.225484,1.061500,-0.903830] is nearest coat face1248, on the upper hind segment.|
|hip_support_l|1.662 /29.829 mm|Dorsal-to-side support floats locally; its shared lower end belongs to the moving breeching junction. Worst sample nearest torso face51.|
|hip_support_r|3.361 /26.066 mm|Same issue, nearest torso face69 at worst sampled point.|
|girth|40.206 /145.120 mm|The large underbelly loop is GIRTH, not breeching. Its bottom [~0,.762,-.103] is below coat face318, whose vertices lie near Y.89–.96. This is a separate barrel-fit defect; don't move rear harness to conceal it.|
|shaft_tug_l|135.808 /227.707 mm|Tug is an intentionally external shaft-loop component, not a coat band. Gap alone is not a defect measure for a vehicle attachment. Its placement/support/vehicle interface needs separate work.|
|shaft_tug_support_l|87.783 /170.011 mm|Likewise distinguish the actual support webbing from a girth; needs a declared load-path/shaft endpoint rather than shrinking it to skin.|

The left/right trace, rein and round-check-rein parts have declared unbound endpoints. Their long straight appearance is not repaired by moving the breeching. Keep these byte-identical in this parcel, label unbound, and resolve against actual vehicle/driver endpoints later. No pulling, tension, pressure or force claim.

## Why the successful clearance route floats

The actual 3bb45 producer encloses the UNION of 63 root-local coat cross-sections in one convex XZ hull, full strap slab Y[1.034,1.128], Z<=-.33, and offsets it8mm. The entire106-ring breeching is then rigidly root-bound. It therefore wraps where a hind segment can be at ANY sampled time, rather than where the animal is NOW. Convexification also bridges between the separated hind columns/torso and removes anatomical concavity. It is correct as a conservative sampled collision construction, but cannot establish skin fit. Subtracting one radius or reducing the8mm offset would recreate the original fe76 walk0 70proper failure and does not address the incompatible frames.

The decoded horse has root node0 and hind_l_upper node37 / hind_r_upper node46, pivots [+/- .195,1.24,-.63], with actual nonidentity sagittal rest rotations. There is no separate animated pelvis bone. The croup/torso is primarily root-supported while the upper hind surfaces move. A single rigid band cannot follow both regions. Never invent a pelvis transform or replace the original leg rest transforms with identity.

## One concrete route authority: persistent coat chart, current-pose ribbon

Change ONLY breeching + hip_support_l/r (33 other named meshes protected). Keep widths52mm/23mm and thicknesses7mm/4mm, materials, rigs, source rights. Use the SAME8mm reconstructed construction offset as parent, defined as outer-coat surface to strap inner face; do not tune it. This definition differs from a centerline hull offset and must be explicit in new metadata. It is an engineering allowance, not a sourced historical measurement.

Author separate ordered, connected **rest coat patches** within each actual ab70 indexed coat component. A ribbon spanning torso and upperhind requires an explicitly named off-coat transition or sliding interface; it must not claim nonexistent source adjacency. The bridge must bind two source-owned boundary frames, have an authored rest length/slack rule and full-width/cap geometry, and pass ALLhorse contact checks. A fixed hardware join likewise needs explicit endpoint authority. Do not implement these as arbitrary elastic scaling or concealed hinges. Each patch is independently embedded; the combined bridge/patch ribbon requires an additional global embedding check. Every sample must name source mesh, primitive, triangle ID, barycentrics and oriented source-normal reference. The chart must identify croup/root-supported torso and both upper-hind ownership cohorts, with explicit topology adjacency, side and posterior homotopy. The actual diagnostic landmarks1248/51/69 are starting witnesses, NOT a completed chart. Nearest-point queries may help AUTHOR a chart but must never decide correspondence at runtime: no per-frame nearest-face jumps, no changing map at contact failure.

Evaluate each chart sample from the SAME actual deformed triangle used by the renderer/checker at that pose. Derive oriented tangents/normals from that current triangle/chart, preserving explicit reference orientation. Use a two-dimensional ribbon chart spanning the whole52/23mm width, not only a centerline projected onto skin. Form outer and inner thickness surfaces from its current-pose coat support. This makes support provenance and moving frame explicit and avoids clipping full-width corners into a locally curved thigh. Folds, inverted chart cells, degenerate normals or disconnected correspondence are refusals. Do not smooth after fitting unless the final emitted triangles are checked again.

At both lower hip/breeching junctions, a SINGLE shared attachment record owns both ribbon boundaries. Compute it once from the same persistent coat chart and reuse its exact world frame. Upper hip support endpoints stay source-owned on the croup chart, not on a fictitious pelvis node. Existing static lower socket positions cannot silently remain authoritative: the new sidecar must declare new articulated frames and old->new semantics. No endpoint floats or independent clip-specific coordinates. Root/head binding, other33 parts and their socket metadata stay exact. Define front breeching endpoints on the same side-coat chart, with a source-owned seam to the unchanged external retention hardware; if these fixed interfaces cannot join with declared widths/length, STOP and report an explicit scope blocker rather than moving hardware.

This is a surface-following reconstructed visual deformation, NOT leather physics. Measure route arclength/width and segment strain at all63 poses; no arbitrary stretch allowed. Before generation the author must select a concrete rest length/slack policy. If the source chart requires incompatible length changes, reject this route and disclose the limitation rather than baking arbitrary elastic scaling. Period texts describe the components, but do not establish our slack/pressure dimensions.

## Portable producer/caller boundary to freeze before candidate

A static GLB cannot alone encode a live coat-constrained ribbon. Proposed portable parcel: unchanged33 rigid parts in rest GLB, three original new ribbon meshes, an exact chart/attachment JSON, and ONE deterministic pure-JS evaluator reused verbatim by browser capture and viewer. The evaluator takes current actual horse world triangles + source topology/keyed association + current root/head matrices and produces the complete three named ribbon arrays. It has no randomness, nearest-face search, collision-driven retuning, or per-clip lookup. Any precomputed63-pose guide remains a diagnostic, not a substitute for a runtime deformation. Original glTF units/axes/metres are retained.

Source freeze requires: exact chart with barycentrics/full-width cells, immutable input/pin inventory, complete producer, actual caller wiring before world capture, explicit new socket semantics, width/thickness/length/slack rules, output counts and independent decoded readback. This directory is a DESIGN FREEZE WITH A CONFIRMED TOPOLOGY BLOCKER, not that completed executable freeze: no rest chart or generator is represented as finished. Do not release a candidate from this report alone.

## Unchanged acceptance and negative controls

1. Protect raw horse bytes and all33 nonrear gear parts P/N/material/topology/metadata; same33 actual source meshes, unique36parts total, complete nonempty triangle coverage and index streams. No hiding girth/traces or dropping faces.
2. Source chart positive-area/global embedding/edge adjacency; per-pose cells nonfolded, finite/unit frames, width/thickness readback; exact shared endpoints; explicit strain/slack bounds. Full ribbon surfaces/caps must be checked, not sample centerline only.
3. First idle0 + formerly failing walk0 actual candidate readback/capture against ALL13226horse triangles with unchanged1e-8 SAT/proper predicates. Then reviewedquarter8 and conditionalfull63; every clip/time/pose matrix/source hash fresh. No old proof inheritance.
4. Existing exact078 penetration negative, fe76 walk0 70proper and 3bb45 visibly floating case are preserved. The floating control must FAIL a separately declared visible-support metric even though it PASSES collision. A new metric must use complete ribbon-cell support coverage, report minimum/maximum gap and unsupported arclength; its thresholds need source rationale/review, not inferred from these sparse samples. Current sample maximum112mm is a witness, not the threshold.
5. New candidate visual A/B against immutable3bb45 in both viewports after technical qualification, showing same poses/cameras/gear visibility. Girth remains an explicitly open defect in that A/B. No continuous collision, actual hoof-grounding, pressure, anatomical/photographic or historical turnout acceptance.

## Historical bounds

Existing actually read Moore1891 No1 text supports folded/stitched breeching components; Hasluck1904 pp148–150 separates hip/bearer/body/shaft straps, and Dwyer[1886] pp260–261 discusses restraint direction. Cuyer1905 Fig40/70/86 previously viewed supports anatomy only, not our dimensions or1904 availability. Use existing source records; no new source IDs, breed, Chicago ownership or identified historical horse claim. No unseen plate tracing. Original asset CC0 provenance stays; research helper remains GPL-3.0-or-later.

## Next bounded source step after v2 review

Read-only source component/owner inventory on the exact ab70 primitive/index stream, retaining face IDs/boundary loops and existing skin weights. Derive separate candidate full-width patch domains on torso/upperhind (no mesh emission), then specify which actual boundary curves the rear ribbon may cross as a bridged span. Decide whether the current simplified independent thigh solids can support an anatomically credible breeching at all. If not, report the horse anatomy dependency rather than forcing a strap solution. Only then freeze a concrete caller/evaluator and rest-length/slack policy. No candidate release from this design.
