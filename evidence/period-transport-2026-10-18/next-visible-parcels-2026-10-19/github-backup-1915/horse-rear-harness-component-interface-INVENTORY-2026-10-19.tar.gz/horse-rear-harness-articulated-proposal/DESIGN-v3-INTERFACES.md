# Articulated rear harness v3: actual ownership and attachment boundary

This is a source and previously stored capture inventory, not an emitted strap or a new fit trial. It supplements DESIGN-v2.md and preserves both earlier documents. No app asset, horse geometry, capture or renderer was changed.

## Immutable authority

Horse ab70aff958bc8a2780458d37212be1866c730817f485fbebbf53bd3c0e3931c3; parent gear 3bb45abfad635bda74fd2aa999dcf869269e5efad1c888dfb4d615f7b0667825. Source coat mesh0/primitive0 has 10,724 indexed faces and 5,867 positions. Its decoded UInt32 triangle stream hashes to 13488909c1efd7f165f589a903c07634b72c0a99241b2bfc2832275726ca2d32. The other horse primitives remain in the eventual all-horse physical check; the coat inventory does not reduce that scope.

inventory_components.py parses the actual horse GLB, traverses index adjacency without welding, binds actual JOINTS_0/WEIGHTS_0 to skin joint node names, and checks all 63 existing Float64 world captures by model/buffer/source-index identities. COMPONENT-AND-INTERFACE-INVENTORY.json stores every component face and vertex ID, edge ownership, actual idle bounds, exact skin-cohort values, saved capture hashes and diagnostic ranges. All arithmetic uses the saved geometry; nothing is rendered or recaptured here.

## Confirmed body correspondence

There are 17 vertex-connected coat components. Torso/head component0 has 5,423 faces, left upper hind component3 has192, and right upper hind component5 has192. Both upper-hind components are closed Euler2 surfaces. Their source skins include real upper-hind, hock and root weights; a single upper-hind rigid matrix is insufficient even within one component. The torso/head component has head reconstruction boundaries and is not globally a closed sphere; a future local croup patch must prove its own disk/boundary, not infer it from the entire component.

The five prior nearest-face witnesses are now bound to exact original source indices and components. Their face-centroid barycentrics are diagnostic values only. They are not newly approved strap anchors. Across the existing 63 captures, torso-left/upperhind-left centroid separation spans24.819mm, the right pair11.554mm and the two upperhind centroids66.545mm. These separations demonstrate relative movement, not strap strain or slack, because the centroids are neither material strap endpoints nor a ribbon route.

Horse anatomy work in parallel is restricted to head/mouth on the separate57d cheek quality variant. Its owner confirms no croup/upper-hind change and no ab70 baseline mutation. Do not wait for an unplanned anatomy remesh or silently consume the separate head candidate.

## New actual interface blocker

The original breeching front root-local endpoints are [+/-0.3,1.1,-0.34]. The nearest protected gear surfaces are the respective traces, approximately56.050mm and56.080mm away. The two hip-support upper endpoints coincide at [0,1.525,-0.48]; their nearest protected longitudinal supports are approximately121.484mm away. These numbers are only point-to-full-triangle distances, with actual nearest global face IDs retained. They establish that there is no exact pre-existing seam at these endpoint points; they do not prove an alternative seam impossible elsewhere.

Consequently, DESIGN-v2's demand that new front breeching ends join unchanged external retention hardware is not executable within its current source authority. No existing holdback connection has been identified. Moving a strap endpoint to the nearest trace is not historically or mechanically established: a trace is not automatically a breeching retention member. Do not add a hidden connector or label an arbitrary trace contact as an approved join.

The upper hip endpoints are a shared pair junction. They may remain an explicitly reconstructed over-croup suspension junction if an actual full-width body chart supports that location; their shared point is not proof of attachment to a longitudinal support. Keep the source aliases and semantic meanings distinct.

## Bounded source options requiring a concrete scope decision

1. Complete a standalone three-part fitted-appearance study, keeping the33 other parts visible and byte exact. Its breeching front ends remain explicitly unbound until real vehicle/retention hardware exists. No assembled functional harness or load-path claim is permitted. This changes the interpretation of the front interface requirement and needs root scope release before a candidate.
2. Broaden the later assembled-harness parcel to actual source-supported holdback/retention components and a real vehicle shaft interface. Freeze actual vehicle socket positions and named strap/buckle authority before new endpoints or hardware are authored. This is a larger parcel and cannot be smuggled into the three-part scope.

Neither option cures the separate girth stand-off or unbound rein/trace ends. They remain visible defects and must not be hidden in an A/B.

## Executable source freeze still required

No new candidate is released by this inventory. A complete producer must still supply all of the following before an independent executable review:

- Separate full-width oriented source patch disks on actual components, each source vertex or exact barycentric cut alias owned by an original face, with full boundary and links. Source ownership is not a nearest-point runtime query.
- Any cross-component free span explicitly named off-coat, with two full-width frames, nonelastic rest length, endpoint sliding or slack rule and a deterministic refusal if unavailable. No fabricated indexed adjacency, elastic scale factor or per-clip table.
- One pure current-pose evaluator used verbatim by capture and the eventual viewer. It consumes actual current deformed source triangles and actual world/root matrices, then emits the complete rear strap surfaces including thickness/caps. All inversions/folds/unsupported patches must refuse. Renderer-parent inverse handling and actual source caller wiring must be present in review.
- One shared serialized junction record used by both hip and breeching surfaces, explicit front endpoint semantics, declared unchanged33 parts, and exact independently decoded readback.
- Frozen metric/rest-length limits derived from construction authority before trial; a8mm source-normal offset is an engineering allowance, not proof of full-surface clearance or historical measurement.

The current full63 baseline remains a sampled collision PASS and a visible-float control. Original fe76 walk0 and078 penetration controls remain immutable. A future candidate needs new unchanged all-horse/all-gear physical checks, sampled phases and actual both-viewport visual review. Nothing here proves continuous motion, forces, pulling, riding or photographic acceptance.
