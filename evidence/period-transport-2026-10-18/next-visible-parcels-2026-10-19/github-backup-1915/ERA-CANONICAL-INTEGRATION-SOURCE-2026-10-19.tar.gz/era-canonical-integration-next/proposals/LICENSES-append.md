PROPOSED APPEND TO assets/LICENSES.md AFTER INTEGRATOR REVIEW; no current registry bytes are replaced.

## Named era authoring studies (1812/1904), unaccepted prototypes

New files under assets/authored/humans/era_studies/{1812,1904} contain CC0-source prepared MakeHuman software bodies and original project-authored conjectural garment arrays/recipes. Body source metadata preserves the existing cleared source hashes and license; exact age target recipes accompany each immutable body. Original garment arrays, canonical composition adapters and engineering derivations are authored for this repository under its applicable original-work license. Garment_sources is empty: no photograph, museum garment, personal outfit, portrait or unknown-rights image was used to derive these garments.

The canonical caller reuses existing cleared skin_toigo_bronze and hair_short04 inputs under their existing unchanged SOURCE.json license evidence and exact file hashes. It does not relicense those assets. The source atlas is labeled young; using it on mature software bodies is an unaccepted engineering color-map choice, not an age-specific or personal complexion claim. Historical OCR citations remain identity/text evidence only and do not confer appearance rights or likeness provenance.

Exact body/garment hashes and derivations are in data/humans/recipes/era_studies/{1812,1904}.json and actual master metadata. No output is photographic, source-matched, period-wardrobe accepted, deformation accepted or scene eligible solely because this source is integrated.
