# Opt-in 1812 and 1904 canonical authoring integration proposal

This is an outside-app source parcel. No app file, existing 1835 builder, scene placement, workflow run, canonical Blender master or export was changed or produced. The source/array checks passed; BPy, decimation, skin-normal readback, animation deformation, physical garment fit, 2 mm sole contact, source/published browser appearance and photographic quality remain unaccepted.

`app/` contains exact proposed repository-relative files for the Chicago app repository. The only replacement of an existing file is the small backward-compatible `chicago/4d/tools/human_export.sh` optional `--output-dir` extension. Compare `proposals/PREIMAGES.json` and the reviewable patch before integration/rebase. All default/fixture/verify execution commands remain unchanged. No original 1835 path is modified. The new workflow is manual and opted in; it never commits or publishes a site.

## Historical and source scope

1812 is John Kinzie the elder, identity inferred on 1812-08-14, with a reconstructed age49 software body. It never substitutes John Harris Kinzie or borrows 1835 residency. Proposed household citations support identity/presence only. 1904 is the attested John Jacob Glessner identity on the existing scene date, with reconstructed age61 software body. Neither identity supplies a portrait likeness, measured complexion, known garment or driving/riding event.

Both original garment inputs remain immutable and wholly conjectural, with empty garment_sources. The 1812 shells are provisional plain shirt, waistcoat, trousers and low shoes; the 1904 civilian prototype is coat, waistcoat, shirt-front/collar, trousers and shoes. These are original engineering studies, not source-matched tailoring. Existing cleared CC0 skin and short04 hair are engineering inputs; the atlas is labeled young and has not been accepted as mature skin. Hair, eyes, proportions, palette and cut are reconstructed. Only standing/walking (plus 1904 passenger as an unperformed category) are allowed; no driver/rider role is added.

The immutable body/garment arrays and exact target recipes are included. Canonical-only source derivations are explicit: 1812 shoes shift +7.955081 mm, then bare-foot triangles touching below 139.524120 mm are masked; 1904 shoes shift -6 mm, then bare-foot triangles touching below 115 mm are masked. Exact retained source vertex/face maps and transforms are retained in metadata. Full source bodies remain authoritative for hair and custom-normal transfer; rendered bodies contain 22,228 and 22,308 triangles respectively. Five analytically inward 1904 garment parts have explicit canonical-only winding reversal. None of these array checks proves physical registration or fit; the unchanged source/published 2 mm and pose gates must still run.

## Integration sequence for root

1. After app PR1041/dev reconciliation, compare preimages, copy proposed new files, and apply the exporter patch only if its current semantics still match. Rebase source pins deliberately if app inputs changed; do not silently refresh them. Preserve original append-only LIBERTIES bytes.
2. Assign the next actual liberty heading after current dev merge and append the proposed text from `proposals/LIBERTIES-append.md`; append the asset provenance from `proposals/LICENSES-append.md` after review. No numeric liberty has been allocated here. The CLI requires a real existing heading.
3. Compile the actual 1812/1904 scenes with existing compile_scene.py. The new1812 household is source-backed; no compiled placeholder is included. Run `python tools/test_human_era_study_source.py --liberty L<actual>` and both source-only CLI modes. The scratch review used existing L418 solely to exercise heading parsing; that is not a new-era liberty assignment.
4. Use the manual `Chicago 4D — opt-in era authoring studies` workflow with era_study=both and the assigned liberty. It first runs unchanged fixture byte verification, reproduces the actual body bytes with human_base_prepare.py, builds fresh canonical masters with the installed pinned Blender, runs existing master export/LOD/container/normal/hair/animation-time gates, and retains all actual artifacts. The normal publisher and existing source/published human_teamster inspector run only inside the disposable CI checkout for the explicitly named new IDs. No site deployment or merge is performed.
5. Review actual canonical/export evidence and source/published captures before accepting fit, clothing, anatomy, mature skin or appearance. Fix failures with original assets preserved. Scene placement and interaction remain later reviewed work.

Equivalent explicit worker command after fixture verification and compilation:

```sh
bash tools/human_era_study.sh --era-study both --liberty L<actual> --output-dir /tmp/era-studies
```

The wrapper refuses missing pinned Blender, missing source inputs, unknown arguments, reused output directories or unmatched identity/date/roles. It never installs Blender. Each actual build/export is bounded to 600 seconds with first-failure shell propagation and retained logs. No real model execution occurred in this source parcel.

## Source verification and review

`evidence/SOURCE-CHECKS.json` contains actual relocated array/source checks and 25 refusal/parser controls. `evidence/SYNTAX-CHECKS.json` records Python AST, shell syntax and workflow YAML structure checks. These do not invoke BPy or any existing exporter body. The parser controls execute only the argument prefix before Blender-pin sourcing. Full source receipt retains exact footwear/body source maps. Original accepted source-only identity/body/clothing archives remain immutable outside this parcel, with independent review receipts recorded in `evidence/ORIGINS.json`.

The scratch overlay is a separate support-only validation root; it contains exact copies of current app helpers and genuinely compiled Kinzie people using unchanged compile_scene logic. None of those support copies or the scratch liberty heading is an app replacement. The proposal is intentionally not a generated .blend or a claim of portable export acceptance.
