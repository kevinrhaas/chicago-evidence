# SPDX-License-Identifier: GPL-3.0-or-later
"""Stored failed arrays only; NEVER imports horse producer/evaluator/checked."""
from pathlib import Path
import json,hashlib,sys,os,time,signal,importlib.util
import numpy as np
P=Path(__file__).parent
D=Path('/workspace/shared/horse-neutral-closed-anterior-producer-next')
HELP=Path('/workspace/shared/horse-neck-hybrid-pipeline-next')
CANDIDATE='ae1edb9d3ede8738ba19f531a1230d86d11e161de89ea39349b21f9af1692884'
def require(v,msg):
 if not v:raise ValueError(msg)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 require(sys.argv[1:2]==['ROOT_RELEASE_STORED_AE1E_DIAGNOSTIC']and len(sys.argv)==3,'Root release and exclusive output required');out=Path(sys.argv[2]);out.mkdir();r={'complete':False,'scope':'DIAGNOSTIC of immutable failed ae1e full head-internal stored arrays only, never candidate qualification','candidate_sha256':CANDIDATE,'bound_s':90,'cpu_affinity':sorted(os.sched_getaffinity(0))};start=time.monotonic()
 def save():r['elapsed_s']=time.monotonic()-start;(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
 def stop(*_):raise TimeoutError('90s stored diagnostic bound')
 signal.signal(signal.SIGALRM,stop);signal.alarm(90)
 try:
  require(r['cpu_affinity']==[0],'Exactly CPU0 required')
  for e in['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:require(os.environ.get(e)=='1','One-thread '+e)
  for f,w in json.loads((P/'PINS.json').read_text()).items():require(sha(Path(f))==w,'Pinned stored diagnostic input:'+f)
  sys.path.insert(0,str(HELP));from ownership import Model,triangle_labels
  from source_edges import owned_adjacency
  from check_idle import scan,world_aliases
  import official_fit_predicates as predicates
  raw=(D/'candidate-one/candidate.glb').read_bytes();require(hashlib.sha256(raw).hexdigest()==CANDIDATE,'Exact failed candidate');model=Model(raw);rb=json.loads((D/'candidate-one/readback.json').read_text());require(rb['PASS']is True and rb['candidate_sha256']==CANDIDATE,'Stored source/readback identity');labels={(x['mesh'],x['vertex']):x['label']for x in rb['source_labels']};model.source_face_owners={int(k):v for k,v in rb['source_face_owners'].items()};oldhead=set(json.loads(Path('/workspace/shared/horse-combined-oral-neck-mane-prefix-next/candidate-one/graft-proof.json').read_text())['head_faces']);head={int(v)for k,v in rb['old_to_new'].items()if int(k)in oldhead}|{g for g,o in model.source_face_owners.items()if o['kind']=='conforming_mouth'};require(len(head)==4916 and model.total==15020 and len(model.source_face_owners)==model.total,'Exact stored active head/owner coverage')
  spec=importlib.util.spec_from_file_location('stored_capture_validator',D/'idle-fit/validate_capture.py');validator=importlib.util.module_from_spec(spec);spec.loader.exec_module(validator);meta=json.loads((D/'idle-fit/capture/horse.json').read_text());buffer=(D/'idle-fit/capture/horse.f64').read_bytes();validator.validate('horse',meta,buffer);captured=np.frombuffer(buffer,dtype='<f8').reshape(-1,3,3);data=np.empty_like(captured);seen=set()
  for g in meta['meshes']:
   key=g['sourceMesh'],g['sourcePrimitive'];require(key in model.views and key not in seen,'Actual captured primitive association');seen.add(key);require(g['count']==len(model.views[key]['indices']),'Stored triangle count');data[model.start[key]:model.start[key]+g['count']]=captured[g['start']:g['start']+g['count']]
  require(seen==set(model.views),'All actual capture primitives');records=triangle_labels(model,labels);r['source_aliases']=world_aliases(records,data);sys.path.insert(0,'/workspace/shared/horse-neck-hybrid-pipeline-next');from hybrid_geometry import SEAM
  adjacency,portal,topology=owned_adjacency(records,head,model.total,1,-1,boundary_loop=['h:'+str(x)for x in SEAM]);r['topology']=topology;predicates.predicate_controls();save();result=scan('FAILED_ae1e_DIAGNOSTIC','head_internal',model,records,head,data,adjacency,out,False,declared_scope='ALL4916 failed-head triangles internal, stored captured binary64; no new P evaluation or model');r.update(complete=result['complete'],counts=result['counts'],witness_count=len(result['unexpected_witnesses']),completed_triangle_prefix=result.get('completed_head_triangle_prefix'));save()
 except BaseException as e:r['error']=repr(e);save();raise
 finally:signal.alarm(0);save()
if __name__=='__main__':main()
