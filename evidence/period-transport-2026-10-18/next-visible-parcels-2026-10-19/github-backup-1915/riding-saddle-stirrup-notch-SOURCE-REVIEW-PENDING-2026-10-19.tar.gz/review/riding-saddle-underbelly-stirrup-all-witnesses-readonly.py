"""Bounded existing captured geometry diagnostic only; no candidate authoring."""
from pathlib import Path
import hashlib,json,os,sys,time
import numpy as np
BASE=Path('/workspace/shared');SRC=BASE/'riding-saddle-underbelly-bisector-source-next';sys.path.insert(0,str(SRC))
from official_fit_predicates import sat,proper
from check_actual import load,array
CAP=BASE/'riding-saddle-underbelly-bisector-actual-one/capture'
OUT=BASE/'riding-saddle-underbelly-stirrup-ALL-WITNESSES.json'
started=time.monotonic();os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
receipt={'scope':'Readonly existing bisector captured pair survey for two original stirrup leathers vs remaining gear and all horse; no geometry creation, qualification or parameter search','passed':False,'pairs':[]}
def need(q,m):
 if not q:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save():receipt['elapsed_s']=time.monotonic()-started;OUT.write_text(json.dumps(receipt,indent=2)+'\n')
need(not OUT.exists(),'Fresh diagnostic receipt only')
try:
 m=json.loads((CAP/'capture.json').read_text());need(m['passed']is True,'Actual capture complete')
 need(m['inputs']['candidate']['sha256']=='83f7b0b927c316ec2efb360178cace360351f1e04a1431d240599ae9cc8682bd','Immutable bisector candidate')
 receipt['capture_metadata_sha256']=sha(CAP/'capture.json')
 def read(kind):
  meta=m['parts'][kind];f=CAP/(kind+'.f64');need(sha(f)==meta['sha256'],'Captured array pin')
  arr=np.frombuffer(f.read_bytes(),dtype='<f8').reshape(-1,3,3);parts=[]
  for p in meta['parts']:
   tri=arr[p['face_start']:p['face_start']+p['face_count']];parts.append({'name':p['name'],'tri':tri,'lo':tri.min(1),'hi':tri.max(1)})
  return parts
 gear=read('candidate_all');horse=read('horse');leathers=[q for q in gear if q['name']in('stirrup_leather_l','stirrup_leather_r')];need(len(leathers)==2,'Both original leathers')
 for A in leathers:
  for kind,targets in [('gear',gear),('horse',horse)]:
   for B in targets:
    if kind=='gear'and(A['name']==B['name']or B['name']=='stirrup_leather_l'):continue
    row={'kind':kind,'a':A['name'],'b':B['name'],'a_faces':len(A['tri']),'b_faces':len(B['tri']),'AABB_candidates':0,'raw_SAT':0,'strict_proper':0,'all_raw_witnesses':[]}
    receipt['pairs'].append(row)
    for i,a in enumerate(A['tri']):
     need(time.monotonic()-started<60,'60s total diagnostic bound')
     ids=np.flatnonzero(np.all(B['hi']>=A['lo'][i]-1e-8,axis=1)&np.all(B['lo']<=A['hi'][i]+1e-8,axis=1))
     for j in ids:
      j=int(j);row['AABB_candidates']+=1;bb=B['tri'][j]
      if not sat(a,bb):continue
      row['raw_SAT']+=1;w=proper(a,bb);row['strict_proper']+=int(w is not None)
      row['all_raw_witnesses'].append({'a_face':i,'b_face':j,'actual_coordinates':[a.tolist(),bb.tolist()],'proper':w})
    row['complete']=True;save()
 receipt['leather_bounds']={p['name']:{'min':p['tri'].min((0,1)).tolist(),'max':p['tri'].max((0,1)).tolist()}for p in leathers}
 receipt['passed']=True;save()
except BaseException as error:receipt['error']=repr(error);save();raise
print(json.dumps({'elapsed_s':receipt['elapsed_s'],'completed_pairs':len(receipt['pairs']),'hits':[{k:r[k]for k in('kind','a','b','raw_SAT','strict_proper')}for r in receipt['pairs']if r['raw_SAT']],'scope':receipt['scope']},indent=2))
