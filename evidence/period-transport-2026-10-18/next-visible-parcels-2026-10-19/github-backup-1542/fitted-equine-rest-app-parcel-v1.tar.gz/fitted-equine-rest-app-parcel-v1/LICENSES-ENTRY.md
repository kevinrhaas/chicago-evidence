## authored/transport/fitted_equine_rest/ — original resting horse and fitted harness (T-2793, T-2801)

authored/transport/fitted_equine_rest/LICENSE.txt
authored/transport/fitted_equine_rest/REPLAY-INDEX.json
authored/transport/fitted_equine_rest/SOURCE.json
authored/transport/fitted_equine_rest/gear-author-manifest.json
authored/transport/fitted_equine_rest/harness_fe76.glb
authored/transport/fitted_equine_rest/horse-author-authority.json
authored/transport/fitted_equine_rest/horse-author-graft-proof.json
authored/transport/fitted_equine_rest/horse-author-manifest.json
authored/transport/fitted_equine_rest/horse-author-packet.json
authored/transport/fitted_equine_rest/horse_ab70.glb
authored/transport/fitted_equine_rest/qualification-author-summary.json
authored/transport/fitted_equine_rest/qualification-idle0.json

Original project-authored procedural horse/harness geometry and authored data: CC0-1.0, author declarations in the retained manifests. No external model, image texture or photographic tracing. Recipe/source/license/evidence records are project-authored metadata; hashes identify exact masters and their unchanged original family IDs. Research GPL-3.0-or-later helper programs are not relicensed as CC0. Full source/notice closure archive SHA256 6f10c8fcf0d09de06d711d7c7c9a7f653fc3f58f754a4259b9e722abf43be8bc is indexed by REPLAY-INDEX.json; durable repository evidence location is recorded in REPLAY-INDEX.json. Canonical master staging is not parametric regeneration. Only idle0 fit is bounded; photographic/historical/date/motion/riding production gates remain open.

`authored/transport/fitted_equine_rest/LICENSE.txt` SHA256 `0aafc9a1d8247d769a30d20c9471bdfd86f185f4321428bdce0979e5f0eb9626`
`authored/transport/fitted_equine_rest/REPLAY-INDEX.json` SHA256 `a8992bbd30e0271500b739a00e383afe7dfecb2828963863ac544ce6f317296f`
`authored/transport/fitted_equine_rest/SOURCE.json` SHA256 `38830028d7cd77abc621be5f89d33aaf2ff058cae13dc4a89a644642dc173f42`
`authored/transport/fitted_equine_rest/gear-author-manifest.json` SHA256 `cfe85fbeeb30dda6f878009c01d67fc3032ff05acd77594edc1a381a735a55b9`
`authored/transport/fitted_equine_rest/harness_fe76.glb` SHA256 `fe76c95b49234da64700a1e20741b4998e8cfbae69571387d49bf5bb23ef04b1`
`authored/transport/fitted_equine_rest/horse-author-authority.json` SHA256 `30ddce57d243e083b59f9f5a638335829d667455d388e781bbfde58a3905e68a`
`authored/transport/fitted_equine_rest/horse-author-graft-proof.json` SHA256 `3ac3719d5cbaf065f8396aeeeda823687bbb0778ebcd86e4b0561459908eb6cf`
`authored/transport/fitted_equine_rest/horse-author-manifest.json` SHA256 `1228018c2a5df8edc38d1459c8ef2022ae3e97872669a12d302b945eddaa31dd`
`authored/transport/fitted_equine_rest/horse-author-packet.json` SHA256 `a1cf5716f230298841e565fbe3660b7df5a1f1d9a26ee432dc20816f605fcaee`
`authored/transport/fitted_equine_rest/horse_ab70.glb` SHA256 `ab70aff958bc8a2780458d37212be1866c730817f485fbebbf53bd3c0e3931c3`
`authored/transport/fitted_equine_rest/qualification-author-summary.json` SHA256 `ea1a4cc4b2a74e2fa416c3389f16bd92823795c7c91247bc54f6772576df1040`
`authored/transport/fitted_equine_rest/qualification-idle0.json` SHA256 `56aeafd97f528eba41a9369308c25e02d109f03fbcb1908805bf8f50a8d97621`
