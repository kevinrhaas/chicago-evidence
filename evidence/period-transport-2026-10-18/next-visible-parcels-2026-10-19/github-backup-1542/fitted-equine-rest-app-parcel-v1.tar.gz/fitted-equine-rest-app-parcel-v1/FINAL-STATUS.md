Ready for root review and installation ONLY AFTER the frozen09a release merges. No app files changed by this parcel.

Independent source review and bounded outside source+published-layout browser probes PASS;16actualframes, bothviewports,43draws/23072submittedtriangles at restingidle0. No performance-capacity inference. Exactservedsource/master bytes matched. Browser/server closed. Refer to BROWSER-EVIDENCE.json and separate ee5 evidence archive.

Installed source/published probes, actual new flat-step isolation measurement, license/liberties integration and full required gates remain root tasks. No fitted walk/trot, anatomy/photo/period/physics/rider acceptance; first corrected motion check failed at walk0 breeching. No parametric regeneration or clean-machine replay claim.
