Proposed existing T-2793 item (root merges into the current entry; no new ticket):

“A separate resting-horse study shows the reconstructed horse and shaped harness together, with camera views and gear visibility. Walking, riding and photographic refinement remain under review.”

STATUS / ROADMAP scope (root applies byte-safe updates around concurrent changes):
- Separate canonical-master idle-only viewer implemented; source/published image qualification follows actual installed probes.
- Existing horse, harness, hitch and old four-body-part checks remain bound to their original assets.
- Combined horse/gear motion remains open after the first corrected walk0 breeching failure; do not mark fitted animated tack complete.
- Staging exact CC0 authored masters does not complete parametric reauthoring, clean-machine research replay, anatomy/photo, load/contact, rider fit or traffic work.
