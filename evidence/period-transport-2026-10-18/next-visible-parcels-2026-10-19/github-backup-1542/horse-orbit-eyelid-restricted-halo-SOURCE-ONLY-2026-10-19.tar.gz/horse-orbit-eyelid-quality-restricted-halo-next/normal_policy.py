# SPDX-License-Identifier: CC0-1.0
"""Preserve explicitly source-owned non-boundary neck seam normals."""
EXPECTED={'h:48','h:60','h:71'}
def restricted_halo(halo,protected,boundary,labels,reasons):
 excluded=set(halo)&set(protected)
 if excluded&set(boundary):raise ValueError('Protectedorbitalboundaryoverlap')
 if{labels[i]for i in excluded}!=EXPECTED:raise ValueError('Unexpectedprotectednormalneighborcohort')
 if any(not reasons.get(i)or set(reasons[i])!={'hybrid_neck'}for i in excluded):raise ValueError('Unexpectedprotectedneighborowner')
 return set(halo)-excluded,excluded
