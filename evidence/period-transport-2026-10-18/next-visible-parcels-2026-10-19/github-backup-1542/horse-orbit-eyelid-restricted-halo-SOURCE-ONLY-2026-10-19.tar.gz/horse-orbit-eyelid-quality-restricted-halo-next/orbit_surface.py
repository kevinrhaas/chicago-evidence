# SPDX-License-Identifier: CC0-1.0
"""Original deterministic ordered orbit disk. Pure arrays; no horse IO/export.
All dimensions are reconstructed authoring choices, not measured anatomy.
"""
import math
import numpy as np

def require(ok,msg):
 if not ok:raise ValueError(msg)

def make_orbit(outer,side,surface_x):
 """18 exact ordered boundary points, signed side, original-chart X sampler.
 Returns localP, oriented face triples and explicit skin/iris/pupil owners.
 Caller owns source attributes and independent geometric validation.
 """
 P=np.asarray(outer,dtype=float);require(P.shape==(18,3)and np.isfinite(P).all(),'18finiteboundary');require(side in[-1,1],'side')
 cy,cz=.025,.150
 angles=np.unwrap(np.arctan2((P[:,1]-cy),P[:,2]-cz));d=np.diff(angles)
 require(np.all(d>0)or np.all(d<0),'strictangularorder')
 direction=1 if d[0]>0 else-1
 end=angles[0]+direction*2*math.pi;require(direction*(end-angles[-1])>0,'angularsingleturn')
 A=[]
 for i,a in enumerate(angles):A.extend([a,(a+(angles[i+1]if i<17 else end))/2])
 def almond(t):
  sn=math.sin(t);return np.array([cy+(.009 if sn>=0 else .007)*math.copysign(abs(sn),sn),cz+.021*math.cos(t)])
 rim=np.asarray([almond(t)for t in A]);Z=np.column_stack((rim,np.ones(36)));plane=np.linalg.lstsq(Z,np.asarray([surface_x(*yz)for yz in rim]),rcond=None)[0]
 def plane_x(y,z):return float(np.array([y,z,1.])@plane)
 V=P.tolist();F=[];owners=[];rings=[]
 def tri(a,b,c,owner):
  q=np.array([V[a],V[b],V[c]]);n=np.cross(q[1]-q[0],q[2]-q[0]);require(np.linalg.norm(n)>1e-14,'degenerateface')
  # Source-chart orientation: outward predominantly signed X.
  if direction==side:b,c=c,b
  require((n[0]if direction!=side else-n[0])*side>0,'Coherentprojectedwindingnotperfaceflip')
  F.append([a,b,c]);owners.append(owner)
 for alpha in[.35,.70,1.0]:
  ring=[]
  for k,t in enumerate(A):
   i=k//2;base=P[i,1:]if k%2==0 else(P[i,1:]+P[(i+1)%18,1:])/2
   yz=(1-alpha)*base+alpha*almond(t);x=float(surface_x(*yz));upper=max(0.,math.sin(t));roll=(.004*upper**2+.0015*max(0.,-math.sin(t))**2)*math.sin(math.pi*alpha)**2
   x=(1-alpha**3)*x+alpha**3*plane_x(*yz)+side*roll;ring.append(len(V));V.append([x,*yz])
  if not rings:
   for i in range(18):j=(i+1)%18;a,b=i,j;u,v,w=ring[2*i],ring[2*i+1],ring[(2*i+2)%36];tri(a,b,v,'skin');tri(a,v,u,'skin');tri(b,w,v,'skin')
  else:
   old=rings[-1]
   for i in range(36):j=(i+1)%36;tri(old[i],old[j],ring[j],'skin');tri(old[i],ring[j],ring[i],'skin')
  rings.append(ring)
 aperture=rings[-1];pupil=[]
 for t in A:
  yz=np.array([cy,cz])+.45*(almond(t)-[cy,cz]);x=plane_x(*yz)+side*.0035*(1-.45**2);pupil.append(len(V));V.append([x,*yz])
 # Quantize the actual exported global chart BEFORE choosing the cap diagonal.
 # A planar homothetic quad can otherwise round to either convex diagonal.
 origin=np.array([0.,1.88,.8])
 for i in range(18,len(V)):V[i]=((np.array(V[i])+origin).astype('<f4').astype(float)-origin).tolist()
 for i in range(36):
  j=(i+1)%36;a,b,c,d=aperture[i],aperture[j],pupil[j],pupil[i]
  chosen=convex_quad(V,[a,b,c,d],side)
  for f in chosen:tri(*f,'iris')
 center=len(V);V.append(((np.array([plane_x(cy,cz)+side*.0035,cy,cz])+origin).astype('<f4').astype(float)-origin).tolist())
 for i in range(36):tri(pupil[i],pupil[(i+1)%36],center,'pupil')
 validate_chart(V,F,side)
 validate_cap(V,F,owners,side)
 return{'positions':V,'faces':F,'owners':owners,'boundary':list(range(18)),'aperture':aperture,'pupil':pupil,'center':center,'rim_plane_coefficients':plane.tolist(),'cap':'piecewise elliptical concave-height paraboloid sampled at radii1,.45,0; all cap triangle supportingplanes require actual check','status':'ORIGINAL UNACCEPTED reconstruction; independent chart/self/owner checks required'}


def validate_chart(V,F,side):
 """Exact dyadic projected ownership/embedding; touching boundaries allowed.
 No tolerance and no nearest-face/proximity ownership.
 """
 a=np.asarray(V,float);require(np.isfinite(a).all(),'Finitechart');ratios=[float(x).as_integer_ratio()for x in a[:,1:].ravel()];den=max(d for _,d in ratios);Q=np.asarray([[n*(den//d)for n,d in ratios[i:i+2]]for i in range(0,len(ratios),2)],dtype=object)
 def orient(a,b,c):return(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
 def inside(p):
  winding=0
  for i in range(18):
   u,v=Q[i],Q[(i+1)%18];o=orient(u,v,p)
   if o==0 and min(u[0],v[0])<=p[0]<=max(u[0],v[0])and min(u[1],v[1])<=p[1]<=max(u[1],v[1]):return True
   if u[1]<=p[1]<v[1]and o>0:winding+=1
   if v[1]<=p[1]<u[1]and o<0:winding-=1
  return abs(winding)==1
 require(all(inside(p)for p in Q),'Allchartverticesinsideoriginalboundary')
 tris=[Q[f]for f in F];areas=[orient(*t)for t in tris];require(all(x*side>0 for x in areas),'Exactconsistentprojectedtrianglewinding')
 # A strict-interior intersection exists iff no separating edge axis has
 # disjoint/touch-only projection intervals. Integer arithmetic is exact.
 for i,A in enumerate(tris):
  for j in range(i):
   B=tris[j]
   if any(max(t[k]for t in A)<=min(t[k]for t in B)or max(t[k]for t in B)<=min(t[k]for t in A)for k in range(2)):continue
   separated=False
   for T in[A,B]:
    for u,v in zip(T,[T[1],T[2],T[0]]):
     axis=(v[1]-u[1],u[0]-v[0]);pa=[axis[0]*x[0]+axis[1]*x[1]for x in A];pb=[axis[0]*x[0]+axis[1]*x[1]for x in B]
     if max(pa)<=min(pb)or max(pb)<=min(pa):separated=True;break
    if separated:break
   require(separated,'Projectedglobalinteriortriangleoverlap')
 return{'dyadic_exact':True,'triangle_pairs_checked':len(F)*(len(F)-1)//2,'all_vertices_contained':True,'all_projected_interiors_disjoint':True}

def validate_cap(V,F,owners,side):
 """All cap triangles must support the convex outward cap vertex set.
 Binary64 determinants are converted to exact dyadic integers; no epsilon.
 """
 cap=[f for f,k in zip(F,owners)if k in['iris','pupil']];ids=sorted({i for f in cap for i in f});P=(np.asarray(V,float)+[0.,1.88,.8]).astype('<f4').astype(float);rat=[float(x).as_integer_ratio()for x in P.ravel()];den=max(d for _,d in rat);Q=np.asarray([[n*(den//d)for n,d in rat[i:i+3]]for i in range(0,len(rat),3)],dtype=object)
 for f in cap:
  a,b,c=Q[f];u=b-a;v=c-a;n=np.cross(u,v);require(n[0]*side>0,'Outwardcaporientation')
  for i in ids:require(sum(n[k]*(Q[i,k]-a[k])for k in range(3))<=0,'Actualcapconvexsupportplane')
 return{'exact_dyadic_convex_cap':True,'faces':len(cap),'vertices':len(ids)}


def convex_quad(V,ids,side):
 P=(np.asarray(V,float)[ids]+[0.,1.88,.8]).astype('<f4').astype(float);r=[float(x).as_integer_ratio()for x in P.ravel()];den=max(d for _,d in r);Q=np.asarray([[n*(den//d)for n,d in r[i:i+3]]for i in range(0,len(r),3)],dtype=object)
 for faces in [[[0,1,2],[0,2,3]],[[0,1,3],[1,2,3]]]:
  ok=True
  for f in faces:
   a,b,c=Q[f];n=np.cross(b-a,c-a)
   if n[0]*side<0:n=-n
   if n[0]*side<=0 or any(sum(n[k]*(p[k]-a[k])for k in range(3))>0 for p in Q):ok=False;break
  if ok:return[[ids[i]for i in f]for f in faces]
 raise ValueError('Noactualconvexcapquaddiagonal')
