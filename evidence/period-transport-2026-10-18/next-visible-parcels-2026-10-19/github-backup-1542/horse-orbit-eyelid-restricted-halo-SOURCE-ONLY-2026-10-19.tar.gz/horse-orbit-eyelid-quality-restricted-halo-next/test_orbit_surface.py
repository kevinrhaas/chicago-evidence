# SPDX-License-Identifier: CC0-1.0
import unittest,math,collections
import numpy as np
from orbit_surface import make_orbit,validate_chart,validate_cap
from normal_policy import restricted_halo
class Controls(unittest.TestCase):
 def outer(self,side=1):return[[side*.1,.025+.07*math.sin(t),.15+.065*math.cos(t)]for t in np.linspace(0,2*math.pi,18,endpoint=False)]
 def test_boundary_and_disk(self):
  o=self.outer();s=make_orbit(o,1,lambda y,z:.1);self.assertTrue(np.array_equal(s['positions'][:18],o));edges=collections.Counter(tuple(sorted((a,b)))for f in s['faces']for a,b in zip(f,f[1:]+f[:1]));self.assertEqual(sum(n==1 for n in edges.values()),18);self.assertEqual(len(s['positions'])-len(edges)+len(s['faces']),1);self.assertEqual(len(s['faces']),306)
 def test_negative_repeated_point(self):
  o=self.outer();o[3]=o[2]
  with self.assertRaises(ValueError):make_orbit(o,1,lambda y,z:.1)
 def test_negative_nonangular_boundary(self):
  o=self.outer();o[3],o[10]=o[10],o[3]
  with self.assertRaises(ValueError):make_orbit(o,1,lambda y,z:.1)
 def test_bilateral_and_no_overlay(self):
  a=make_orbit(self.outer(),1,lambda y,z:.1);b=make_orbit(self.outer(-1),-1,lambda y,z:-.1);P=np.array(a['positions']);Q=np.array(b['positions']);self.assertTrue(np.array_equal(P*np.array([-1,1,1]),Q));self.assertEqual(len(a['faces']),len({tuple(sorted(f))for f in a['faces']}));self.assertEqual(set(a['owners']),{'skin','iris','pupil'})
 def test_negative_tiny_boundary(self):
  o=[[.1,.025+.002*math.sin(t),.15+.002*math.cos(t)]for t in np.linspace(0,2*math.pi,18,endpoint=False)]
  with self.assertRaises(ValueError):make_orbit(o,1,lambda y,z:.1)
 def test_negative_flipped_chart(self):
  s=make_orbit(self.outer(),1,lambda y,z:.1);s['faces'][0]=s['faces'][0][::-1]
  with self.assertRaises(ValueError):validate_chart(s['positions'],s['faces'],1)
 def test_negative_duplicate_overlap(self):
  s=make_orbit(self.outer(),1,lambda y,z:.1);s['faces'].append(s['faces'][0])
  with self.assertRaises(ValueError):validate_chart(s['positions'],s['faces'],1)
 def test_negative_inverted_cap(self):
  s=make_orbit(self.outer(),1,lambda y,z:.1);s['positions'][s['center']][0]-=.02
  with self.assertRaises(ValueError):validate_cap(s['positions'],s['faces'],s['owners'],1)
 def test_restricted_normal_neighbors(self):
  labels={0:'h:48',1:'h:60',2:'h:71',3:'h:72'};reasons={i:{'hybrid_neck'}for i in range(3)};a,b=restricted_halo(set(range(4)),{0,1,2},{3},labels,reasons);self.assertEqual(a,{3});self.assertEqual(b,{0,1,2})
 def test_restricted_normal_negative(self):
  labels={0:'h:48',1:'h:60',2:'h:71'};reasons={i:{'hybrid_neck'}for i in range(3)}
  with self.assertRaises(ValueError):restricted_halo({0,1,2},{0,1,2},{0},labels,reasons)
  reasons[1]={'oral_channel'}
  with self.assertRaises(ValueError):restricted_halo({0,1,2},{0,1,2},set(),labels,reasons)
 def test_nonfinite_rejected(self):
  o=self.outer();o[0][0]=math.nan
  with self.assertRaises(ValueError):make_orbit(o,1,lambda y,z:.1)
if __name__=='__main__':unittest.main()
