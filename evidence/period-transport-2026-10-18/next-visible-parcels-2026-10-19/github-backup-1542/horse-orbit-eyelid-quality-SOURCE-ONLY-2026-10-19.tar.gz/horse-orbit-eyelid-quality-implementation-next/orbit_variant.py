# SPDX-License-Identifier: GPL-3.0-or-later
"""Original source-owned eyelid/cornea disk replacement. No IO at import."""
from pathlib import Path
import sys,json,hashlib,copy,collections
import numpy as np
BASE=Path('/workspace/shared/horse-cheek-throat-quality-next');sys.path.insert(0,str(BASE))
from checked_quality import checked as parent_checked
from input_contract import context as parent_context
from ownership import Model,ATTRS
from glb_data import append,encode
from sparse_rules import require
from orbit_surface import make_orbit
PARENT_SHA='57d63e2d7234380adeb727f5efeeed74d50629b2a8367ccea48961d6ecc5bec2'

def context():
 m,labels,head,owners,scopes,raw=parent_checked();require(hashlib.sha256(raw).hexdigest()==PARENT_SHA,'Exact57dqualityparent');source=parent_context()['source'];eyes=[];retired=set()
 for rec in source['records']:
  if rec['kind']!='eye':continue
  name=rec['name'];cohort={int(g)for g,o in owners.items()if o.get('kind')=='baseline_head'and o.get('tag')in[name,'skin:'+name]};require(len(cohort)==162,'Exactoriginalorbitaldisk');require(collections.Counter((m.descriptor(g)['mesh'],m.descriptor(g)['primitive'])for g in cohort)=={(0,0):108,(3,0):54},'Actualcoat/floormaterialownership');retired|=cohort
  boundary=[]
  for h in rec['outer']:
   ids=[i for(mi,i),tag in labels.items()if mi==0 and tag=='h:'+str(h)];require(len(ids)==1,'Uniqueexplicitouterheadalias');boundary.append(ids[0])
  eyes.append({'name':name,'record':rec,'retired':cohort,'boundary':boundary,'side':1 if name=='eye_l'else-1})
 require(len(eyes)==2 and len(retired)==324 and set(range(m.start[3,0],m.start[3,0]+len(m.views[3,0]['indices'])))<=retired,'Entireoldeyefloorretired');require(m.d['nodes'][next(i for i,n in enumerate(m.d['nodes'])if n.get('mesh')==0)]['skin']==m.d['nodes'][next(i for i,n in enumerate(m.d['nodes'])if n.get('mesh')==3)]['skin']==0,'Existingsharedskinpalette')
 return dict(model=m,labels=labels,head=head,owners=owners,scopes=scopes,raw=raw,source=source,eyes=eyes,retired=retired)

def bary(yz,q):
 a,b,c=q;mat=np.column_stack((b-a,c-a));det=np.linalg.det(mat)
 if abs(det)<1e-15:return None
 u,v=np.linalg.solve(mat,yz-a);w=np.array([1-u-v,u,v]);return w if w.min()>=-1e-10 else None

def chart_sampler(c,eye):
 m=c['model'];triangles=[]
 for g in sorted(eye['retired']):
  d=m.descriptor(g);v=m.views[d['mesh'],d['primitive']];ids=d['primitive_vertices'];a=v['attributes'];p=a['POSITION'][ids].astype(float)-[0,1.88,.8];triangles.append((p,a['JOINTS_0'][ids],a['WEIGHTS_0'][ids]))
 def sample(y,z):
  found=[]
  for p,j,w in triangles:
   bc=bary(np.array([y,z]),p[:,1:])
   if bc is not None:found.append((float(bc@p[:,0]),bc,j,w))
  require(bool(found),'Sampleinsideactualsourcechart');require(max(x[0]for x in found)-min(x[0]for x in found)<1e-8,'Singlevaluedsourcechart');return found[0]
 return sample

def evaluate(c):
 m=c['model'];old=m.views[0,0]['attributes'];arrays={k:old[k].copy().tolist()for k in ATTRS};skin=[];iris=[];pupil=[];new_labels={};eye_records=[];new_owner=[]
 for eye in c['eyes']:
  sample=chart_sampler(c,eye);outer=old['POSITION'][eye['boundary']].astype(float)-[0,1.88,.8];s=make_orbit(outer,eye['side'],lambda y,z:sample(y,z)[0]);local_to_actual=list(eye['boundary'])
  for k,p in enumerate(s['positions'][18:],18):
   _,bc,j,w=sample(p[1],p[2]);semantic=collections.defaultdict(float)
   for weight,js,ws in zip(bc,j,w):
    for ji,wi in zip(js,ws):
     if wi>0:semantic[int(ji)]+=float(weight*wi)
   values=sorted(((ji,max(0.,wi))for ji,wi in semantic.items()if wi>1e-12),key=lambda x:(-x[1],x[0]));require(0<len(values)<=4,'Newsemanticpalettebounded');total=sum(wi for _,wi in values);J=[ji for ji,_ in values]+[0]*(4-len(values));W=[wi/total for _,wi in values]+[0.]*(4-len(values));idx=len(arrays['POSITION']);local_to_actual.append(idx);arrays['POSITION'].append((np.asarray(p)+[0,1.88,.8]).tolist());arrays['NORMAL'].append([0.,0.,0.]);arrays['JOINTS_0'].append(J);arrays['WEIGHTS_0'].append(W);new_labels[idx]='orbit:'+eye['name']+':'+str(k)
  for fi,(f,owner)in enumerate(zip(s['faces'],s['owners'])):
   row=[local_to_actual[i]for i in f];{'skin':skin,'iris':iris,'pupil':pupil}[owner].append(row);new_owner.append([eye['name'],fi,owner,row])
  eye_records.append({'name':eye['name'],'outer_actual_vertices':eye['boundary'],'local_to_actual':local_to_actual,'new_local_surface':s,'retired_faces':sorted(eye['retired'])})
 arrays={k:np.asarray(v,dtype=old[k].dtype)for k,v in arrays.items()};keep=[i for i in range(len(m.views[0,0]['indices']))if m.start[0,0]+i not in c['retired']];coat=np.vstack((m.views[0,0]['indices'][keep],np.asarray(skin,dtype='<u4')));indices={(0,0):coat,(3,0):np.asarray(pupil,dtype='<u4'),(3,1):np.asarray(iris,dtype='<u4')}
 # Smooth connected lid skin, never globally blend ocular/material surfaces.
 sums=np.zeros_like(arrays['POSITION'],dtype=float);tri=arrays['POSITION'][coat].astype(float);areas=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);require(np.isfinite(areas).all()and np.all(np.linalg.norm(areas,axis=1)>2e-12),'Allcoatfacesnondegenerate');np.add.at(sums,coat[:,0],areas);np.add.at(sums,coat[:,1],areas);np.add.at(sums,coat[:,2],areas)
 boundary=set(i for e in c['eyes']for i in e['boundary']);halo=set(int(i)for f in m.views[0,0]['indices']if set(map(int,f))&boundary for i in f);protected=set()
 for g,o in c['owners'].items():
  if g in c['retired']:continue
  if o.get('kind')!='baseline_head'or o.get('tag')!='skin':
   d=m.descriptor(g)
   if d['mesh']==0:protected.update(d['primitive_vertices'])
 require(not(halo&protected),'Orbitalnormalhaloexcludesallprotectedfeatures');skinverts={i for f in skin for i in f};newids=set(range(len(old['POSITION']),len(arrays['POSITION'])));normal_ids=halo|skinverts|newids
 # Independent cap normals use cap-only incident areas; shared aperture normals
 # remain skin normals in coat and receive a separate intentional eye accessor.
 for i in normal_ids:
  if np.linalg.norm(sums[i])>1e-12:arrays['NORMAL'][i]=sums[i]/np.linalg.norm(sums[i])
 eyeN=arrays['NORMAL'].copy();caps=np.vstack((indices[3,0],indices[3,1]));capP=arrays['POSITION'][caps].astype(float);capA=np.cross(capP[:,1]-capP[:,0],capP[:,2]-capP[:,0]);require(np.all(np.linalg.norm(capA,axis=1)>2e-12),'Capnondegenerate');capS=np.zeros_like(sums)
 for k in range(3):np.add.at(capS,caps[:,k],capA)
 for i in set(map(int,caps.ravel())):require(np.linalg.norm(capS[i])>1e-12,'Capnormalvalid');eyeN[i]=capS[i]/np.linalg.norm(capS[i])
 
 for i in newids:
  if np.linalg.norm(sums[i])<=1e-12:arrays['NORMAL'][i]=eyeN[i]
 require(np.all(np.linalg.norm(arrays['NORMAL'],axis=1)>.99)and np.all(np.linalg.norm(eyeN,axis=1)>.99),'Allaccessorrowsunitincludinginactivecaprows')
 require(np.isfinite(arrays['NORMAL']).all()and np.isfinite(eyeN).all(),'Finitenormals');return arrays,eyeN,indices,{'eyes':eye_records,'old_coat_keep_indices':keep,'normal_halo':sorted(halo),'new_labels':{str(k):v for k,v in new_labels.items()},'new_owner_rows':new_owner,'status':'UNACCEPTED original reconstructed eyelid/iris/pupil disk'}

def authority(c,detail):
 return{'parent_sha256':PARENT_SHA,'retired_actual_faces':sorted(c['retired']),'geometry':'original connected eighteen-boundary orbital disk; fixed reconstructed21mm/9mm/7mm almond, asymmetric4mm/1.5mm skin relief, shared3.5mm cap','explicit_old_normal_halo':detail['normal_halo'],'protected':'allnon-eye positions/JW/indexowners; outsidehaloN; allrig/IBMs/actions/soles/sockets; oral/nostril/ear/neck/mane geometry','source_evidence':'Cuyer1905Fig92 later exposedmuscle analogy; no eye texture/photographic or historical likeness claim'}

def audit(raw,c,proof):
 old=c['model'];new=Model(raw);a,eyeN,idx,detail=evaluate(c);require(raw==serialize(c,a,eyeN,idx),'Exactallserializedappendmetadata/refs/doc/oldprefix/intendedpayload');require(proof['authority']==authority(c,detail)and proof['detail']==detail,'Completefixedsourceauthority');require(new.total==old.total-324+612,'Recomputedactualfacecount');require(set(new.views)==set(old.views)|{(3,1)},'Exactnewprimitiveownership')
 for key,v in old.views.items():
  if key in[(0,0),(3,0)]:continue
  w=new.views[key];require(v['material']==w['material']and v['indices'].tobytes()==w['indices'].tobytes(),'Allunaffectedindex/materialexact')
  for attr in ATTRS:require(v['attributes'][attr].tobytes()==w['attributes'][attr].tobytes(),'Allunaffectedattributeexact')
 for key in [(0,0),(3,0),(3,1)]:
  require(np.array_equal(new.views[key]['indices'],idx[key]),'Exactintendedemittedindices')
  for attr in ATTRS:
   expected=eyeN if attr=='NORMAL'and key[0]==3 else a[attr];require(new.views[key]['attributes'][attr].tobytes()==expected.tobytes(),'Actualreloadedintendedattributes')
 require([new.views[k]['material']for k in[(0,0),(3,0),(3,1)]]==[0,3,6],'Declaredskin/pupil/irisowners');halo=set(detail['normal_halo']);oldA=old.views[0,0]['attributes'];newA=new.views[0,0]['attributes']
 for attr in['POSITION','JOINTS_0','WEIGHTS_0']:require(newA[attr][:len(oldA[attr])].tobytes()==oldA[attr].tobytes(),'ALLoldcoatP/JWexact')
 for i in range(len(oldA['NORMAL'])):
  if i not in halo:require(newA['NORMAL'][i].tobytes()==oldA['NORMAL'][i].tobytes(),'AlloldNoutsidehaloexact')
 require(new.b[:len(old.b)]==old.b,'OldBINprefixexact');d,e=old.d,new.d;require(e['accessors'][:len(d['accessors'])]==d['accessors']and e['bufferViews'][:len(d['bufferViews'])]==d['bufferViews'],'Alloldstoragemetadataexact');require(len(e['accessors'])==len(d['accessors'])+8 and len(e['bufferViews'])==len(d['bufferViews'])+8,'Exactlyeightappendrecords')
 x,y=copy.deepcopy(d),copy.deepcopy(e)
 for q in[x,y]:
  q['meshes'][0]['primitives'][0]=None;q['meshes'][3]['primitives']=None;q.pop('accessors');q.pop('bufferViews');q['buffers'][0].pop('byteLength')
 y['materials']=y['materials'][:len(x['materials'])];require(x==y,'Allotherdocument/material/rig/frameexact')
 # Actual source labels and complete active face map are reconstructed from the
 # intended index arrays, never proximity. Each retained oriented face exact.
 remap={};owners={};labels={};head=set();scopes={k:set()for k in c['scopes']}
 for key,v in old.views.items():
  if key==(3,0):continue
  pairs=[(i,j)for j,i in enumerate(detail['old_coat_keep_indices'])]if key==(0,0)else[(i,i)for i in range(len(v['indices']))]
  for oi,ni in pairs:
   og=old.start[key]+oi;ng=new.start[key]+ni;remap[og]=ng
   require(og not in c['retired'],'Retirednotretained');owners[ng]=c['owners'].get(og,{'kind':'retained_body','parent_global_face':og})
   if og in c['head']:head.add(ng)
   for name,cohort in c['scopes'].items():
    if og in cohort:scopes[name].add(ng)
 for key,v in new.views.items():
  if key[0]in[0,3]:
   for i in set(map(int,v['indices'].ravel())):
    if str(i)in detail['new_labels']:labels[key[0],i]=detail['new_labels'][str(i)]
    elif key[0]==0:labels[0,i]=c['labels'].get((0,i),'body:0:'+str(i))
  else:
   for i in set(map(int,v['indices'].ravel())):labels[key[0],i]=c['labels'].get((key[0],i),'body:'+str(key[0])+':'+str(i))
 skin_start=len(detail['old_coat_keep_indices']);cursor={'skin':skin_start,'iris':0,'pupil':0}
 for name,fi,owner,row in detail['new_owner_rows']:
  key={'skin':(0,0),'iris':(3,1),'pupil':(3,0)}[owner];ng=new.start[key]+cursor[owner];cursor[owner]+=1;require(new.views[key]['indices'][ng-new.start[key]].tolist()==row,'Newactualfaceownerindex');owners[ng]={'kind':'orbit_quality','eye':name,'new_local_face':fi,'surface':owner};head.add(ng)
 require(len(remap)==old.total-324 and len(head)==len(c['head'])-324+612,'Completeold/newheadcoverage');require(len(owners)==new.total and len(set(remap.values()))==len(remap),'ALLactiveownersuniquelycovered');new.source_face_owners=owners
 return new,labels,head,owners,scopes,{'PASS':True,'candidate_sha256':hashlib.sha256(raw).hexdigest(),'total_faces':new.total,'head_faces':len(head),'new_eye_faces':612,'old_retired_faces':324,'old_to_new':{str(k):v for k,v in sorted(remap.items())},'source_labels':[{'mesh':mi,'vertex':i,'label':t}for(mi,i),t in sorted(labels.items())],'source_face_owners':{str(k):v for k,v in sorted(owners.items())},'status':'REST/source only; actualself/gear/visual/motion UNTESTED'}

def serialize(c,a,eyeN,idx):
 d=copy.deepcopy(c['model'].d);b=bytearray(c['model'].b);refs={}
 for attr in ATTRS:refs[attr]=append(d,b,a[attr],'VEC4'if attr in['JOINTS_0','WEIGHTS_0']else'VEC3',comp=5123 if attr=='JOINTS_0'else 5126)
 eye_ref=append(d,b,eyeN,'VEC3');irefs={k:append(d,b,v.reshape(-1),'SCALAR',comp=5125,target=34963)for k,v in idx.items()}
 d['meshes'][0]['primitives'][0]={'attributes':refs,'indices':irefs[0,0],'material':0};eyeattrs=dict(refs,NORMAL=eye_ref);d['meshes'][3]['primitives']=[{'attributes':eyeattrs,'indices':irefs[3,0],'material':3},{'attributes':eyeattrs,'indices':irefs[3,1],'material':6}];require(len(d['materials'])==6,'Exactparentmaterialpalette');d['materials'].append({'name':'original_reconstructed_equine_iris','pbrMetallicRoughness':{'baseColorFactor':[.12,.065,.025,1.],'metallicFactor':0.,'roughnessFactor':.28}})
 return encode(d,b)

def produce(out):
 out=Path(out);out.mkdir(parents=True,exist_ok=False);c=context();a,eyeN,idx,detail=evaluate(c);raw=serialize(c,a,eyeN,idx);(out/'UNVALIDATED-candidate.glb').write_bytes(raw);proof={'authority':authority(c,detail),'detail':detail,'candidate_sha256':hashlib.sha256(raw).hexdigest(),'status':'UNACCEPTED anatomical reconstruction trial'};*_,report=audit(raw,c,proof);(out/'candidate.glb').write_bytes(raw);(out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');(out/'readback.json').write_text(json.dumps(report,indent=2)+'\n');return report
if __name__=='__main__':print(json.dumps(produce(sys.argv[1])['candidate_sha256']))
