from pathlib import Path
import os,subprocess,time,json,signal
p=Path(__file__).parent; started=time.monotonic();report={'passed':False,'runs':[],'limit_s':120};rp=p/'operator-receipt.json';claim=rp.open('x');claim.write('{}\n');claim.close()
try:
 for label,args in [('source',[]),('published',['--published'])]:
  budget=120-(time.monotonic()-started)
  if budget<=0:raise TimeoutError('total120s bound')
  with (p/(label+'.log')).open('x')as log:
   child=subprocess.Popen(['node',str(p/'source/tools/transport/smoke_fitted_equine.cjs'),str(p/label),str(p/(label+'-receipts')),*args],env={**os.environ,'PW_EXECUTABLE':'/usr/bin/chromium','NODE_PATH':'/workspace/shared/chicago-browser/node_modules'},stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=child.wait(timeout=budget)
   except BaseException:
    os.killpg(child.pid,signal.SIGKILL);child.wait();raise
  report['runs'].append({'case':label,'exit_code':code});rp.write_text(json.dumps(report,indent=2)+'\n')
  if code:raise RuntimeError(label+' failed')
 report['passed']=True
except BaseException as e:report['error']=repr(e);raise
finally:report['elapsed_s']=time.monotonic()-started;rp.write_text(json.dumps(report,indent=2)+'\n')
