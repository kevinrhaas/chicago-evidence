# SPDX-License-Identifier: GPL-3.0-or-later
"""Stage hash-pinned original authored masters; does not generate geometry."""
from pathlib import Path
import argparse,hashlib,json,struct
PINS={'horse':'ab70aff958bc8a2780458d37212be1866c730817f485fbebbf53bd3c0e3931c3','gear':'fe76c95b49234da64700a1e20741b4998e8cfbae69571387d49bf5bb23ef04b1'}
RECORD_NAMES=('LICENSE.txt','REPLAY-INDEX.json','SOURCE.json','gear-author-manifest.json','horse-author-authority.json','horse-author-graft-proof.json','horse-author-manifest.json','horse-author-packet.json','qualification-author-summary.json','qualification-idle0.json')
RECORD_PATHS={'assets/authored/transport/fitted_equine_rest/'+name for name in RECORD_NAMES}
def need(ok,msg):
 if not ok:raise ValueError(msg)
def relative(root,name):
 p=Path(name);need(not p.is_absolute() and '..' not in p.parts,'Repository-relative path required');q=(root/p).resolve();need(q.is_relative_to(root.resolve()),'Path escaped root');return q
def document(raw):
 need(len(raw)>=28,'Truncated GLB');magic,version,size=struct.unpack_from('<III',raw);need(magic==0x46546c67 and version==2 and size==len(raw),'GLB header');n,t=struct.unpack_from('<II',raw,12);need(t==0x4e4f534a and 20+n<=len(raw),'JSON chunk');d=json.loads(raw[20:20+n]);need(not any('uri'in x for x in d.get('buffers',[])+d.get('images',[])),'External resource refused');return d
def inspect(d,kind):
 roots=d['scenes'][d.get('scene',0)]['nodes'];seen=set();todo=list(roots)
 while todo:
  i=todo.pop();need(type(i)is int and 0<=i<len(d['nodes']) and i not in seen,'Scene cycle/multiple ancestry');seen.add(i);todo.extend(d['nodes'][i].get('children',[]))
 names=[d['nodes'][i].get('name')for i in seen];required=['head','root']if kind=='horse'else['harness_head','root'];need(all(names.count(n)==1 for n in required),'Required unique active node')
 mesh_ids=[d['nodes'][i]['mesh']for i in seen if 'mesh'in d['nodes'][i]];tris=0
 for i in mesh_ids:
  for p in d['meshes'][i]['primitives']:
   need(p.get('mode',4)==4,'Triangle primitive required');count=d['accessors'][p['indices']]['count']if'indices'in p else d['accessors'][p['attributes']['POSITION']]['count'];need(count%3==0,'Triangle count');tris+=count//3
 if kind=='horse':need(sum(a.get('name')=='idle'for a in d.get('animations',[]))==1,'Unique idle animation')
 need(len(mesh_ids)==(5 if kind=='horse' else 36),'Active mesh count')
 return {'active_mesh_nodes':len(mesh_ids),'active_triangles':tris,'nodes':len(seen),'required_nodes':required}
def payload(root,recipe):
 need(recipe['study_id']=='fitted_equine_rest_study' and recipe['pose']=={'clip':'idle','time_s':0,'phase':0} and recipe['motion_enabled']is False,'Idle-only study contract')
 need(recipe['license']=='CC0-1.0' and recipe['production_accepted'] is False and recipe['date_eligibility']=='Development inspection only; no new scene/date eligibility asserted','License/development-only boundary')
 need(set(recipe['records'])==RECORD_PATHS,'Exact required provenance record cohort')
 output={};info={}
 for name,want in recipe['records'].items():need(hashlib.sha256(relative(root,name).read_bytes()).hexdigest()==want,'Source/provenance record SHA '+name)
 need(set(recipe['components'])==set(PINS),'Exact component cohort')
 for k,want in PINS.items():
  c=recipe['components'][k];need(c['sha256']==want and c['output']==k+'.glb','Immutable canonical component pin');raw=relative(root,c['master']).read_bytes();need(hashlib.sha256(raw).hexdigest()==want,'Master SHA '+k);info[k]=inspect(document(raw),k);output[k+'.glb']=raw
 study=dict(recipe);study['components']={k:{'url':k+'.glb','sha256':h,**info[k]}for k,h in PINS.items()};study['head_binding']='inverse(actual gear head parent world) * actual horse head world after idle0';output['study.json']=(json.dumps(study,indent=2,sort_keys=True)+'\n').encode();return output
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);a.add_argument('--parameters',default='data/transport/studies/fitted-equine-rest.json');a.add_argument('--output-dir',type=Path);a.add_argument('--verify',action='store_true');o=a.parse_args();root=o.root.resolve();recipe=json.loads(relative(root,o.parameters).read_text());out=o.output_dir or root/'renderers/web/transport/horse-fitted';files=payload(root,recipe)
 if o.verify:
  for n,b in files.items():need((out/n).read_bytes()==b,'Staged mismatch '+n)
 else:
  out.mkdir(parents=True,exist_ok=True)
  for n,b in files.items():(out/n).write_bytes(b)
 print(json.dumps({'passed':True,'operation':'verify'if o.verify else'stage','component_sha256':PINS,'geometry_generated':False,'scope':'exact authored masters and idle-only manifest; no fit replay or motion acceptance'}))
if __name__=='__main__':main()
