# Review/install/recovery

No automatic installation. Root first verifies protected source-pins against the intended merged app and reviews this proposal. Copy files/ as additive only, preserving existing viewer defaults. GPL license copy is included. Add an explicitly titled gallery link if desired; do not add a scene humans layer/placement. If unsuitable, remove this new people/otis directory/link; no other app file or resident identity needs rollback.

The placeholder qualified-delivery.json is deliberately unusable. Populate it ONLY from actual approved canonical CI/publication receipt (canonical run and four published GLB SHA256s for OtisLOD0..3); missing/null receipts refuse before loading. Never hash a fixture, relay blocked artifacts or infer bytes from old logs. Publish through existing normal assets/humans/web→site/data/humans/web path. Then perform an independent real browser test on installed page, exported geometry, identity/card/metadata, LODs and motion. Do not mark ready using node syntax check. Preserve the original receipt and source/published distinction.

Existing directory/card uses sidecars/1835/people.json and its existing deferred joins. Any missing join/problem must remain reported and fixed before acceptance; no fake biography/local substitute. Flat stage is solely inspection, not a Chicago location. Clothes/likeness/photo and main-scene budgets remain separately open.

This is a PUBLISHED-layout-only page: /4d/viewer/people/otis/ resolves ../../../data/ to /4d/data/. Do not serve raw renderers/web/people/otis without a data mapper; the raw source path resolves to renderers/data and is intentionally not an accepted deployment.
