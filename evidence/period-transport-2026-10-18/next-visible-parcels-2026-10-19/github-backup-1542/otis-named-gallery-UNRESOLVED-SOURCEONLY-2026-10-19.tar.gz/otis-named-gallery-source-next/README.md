# Named Otis1835 gallery proposal — SOURCE ONLY

Root must review before installation. Files mirror app-relative renderers/web/people/otis/. Nothing installed; no actual named GLBs loaded. Requires the normal approved canonical publication of bardwell_otis_1835 LOD0..3 into site/data/humans/web. Missing assets stop with explicit unavailable message, never substitute fixture/generic model. No artifact retry, relay or download attempted.

Uses existing createHumanAssets/createHumanLayer/HumanActor, exact existing reconstructed identity rc_bardwell_otis, existing mountPeople+open resident card and published sidecars/1835/people.json. Actual GLB scenes[].extras.chicago4d_human must assert asset/person/scene/grade/LOD and consistent review flags. All4 actual files must carry idle and walk. Metadata is not taken from URL. Card joins/provenance remain existing people.js responsibility; no new biography/identity database. Identity flags propagate to the study instance.

Page is1835 only; local(0,0) is an explicitly isolated inspection datum on a flat stage, not an authored Chicago placement. Walk is existing in-place clip, no route or driver proof. Header labels appearance/action reconstructed, no likeness/photo claim. No full-scene humans layer, instances files, terrain placement or budget edit. No anonymous fallback. Current asset/sidecar availability blocks actual acceptance, not identity policy.

Add a separate gallery link to people/otis/ only after root chooses site location. Existing PortableHumanActor has no import named PortableHumanActor: actual exported class is HumanActor, used through createHumanLayer. Source follows its real APIs rather than introducing a second rig player. Resizable actual canvas, explicit controls, pagehide disposal. This new page has NOT been browser-qualified; syntax parsing is not model acceptance.

Required before release: independent source/schema/API review; actual qualified GLB bytes/source hashes via normal publication; actual idle/walk and all4LODs; card identity/grade/review metadata; actual skin/clothes/morph/defaults; front/profile/three-quarter responsive framing, ground/sole drift and walk-loop review; loaded GLconsole; renderer costs/textures/bytes/timing. Keep existing normal/export/contact thresholds unchanged. An isolated page does not close T1789/T1790/T1792 or authorize a main-scene placement.

GPL-3.0-or-later new glue; existing model/source licensing stays in its recipe and assets/LICENSES.md. Do not copy unlicensed avatar or pretend software body choice is a portrait.
