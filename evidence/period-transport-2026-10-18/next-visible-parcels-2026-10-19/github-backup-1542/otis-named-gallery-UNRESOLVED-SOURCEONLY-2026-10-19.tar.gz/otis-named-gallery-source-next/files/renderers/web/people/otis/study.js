// SPDX-License-Identifier: GPL-3.0-or-later
// SOURCE ONLY: actual named GLBs unavailable locally; no fixture substitution.
import * as T from 'three';
import {createHumanAssets,createHumanLayer} from '../../js/humans.js';
import {mountPeople} from '../../js/people.js';
const PERSON='rc_bardwell_otis',ASSET='bardwell_otis_1835',base=new URL('../../../data/',location.href),status=document.querySelector('#status');
let renderer,layer,raf,resizeHandler,disposed=false;
const cleanup=()=>{if(disposed)return;disposed=true;cancelAnimationFrame(raf);if(resizeHandler)removeEventListener('resize',resizeHandler);layer?.dispose();renderer?.dispose();};
addEventListener('pagehide',cleanup,{once:true});
const alive=()=>{if(disposed)throw Error('study disposed during asynchronous load');};
const fail=e=>{status.textContent='Study unavailable: '+e.message;document.querySelectorAll('button,select').forEach(e=>e.disabled=true);console.error(e);};
try{
 const get=async p=>{const r=await fetch(new URL(p,base));if(!r.ok)throw Error(p+' HTTP'+r.status);return r.json();};
 const [directory,recipe,rules]=await Promise.all([get('sidecars/1835/people.json'),get('humans/recipes/worker_1835.json'),get('humans/contract.json')]);
 const person=directory.people.find(p=>p.id===PERSON),variant=recipe.proof_variants.find(p=>p.id===ASSET);
 if(!person||person.grade!=='reconstructed'||!variant||variant.person_reference_id!==PERSON||variant.person_reference_scene!=='1835'||rules.l1.in_force)throw Error('named identity/date/policy mismatch');
 const proofResponse=await fetch('./qualified-delivery.json');if(!proofResponse.ok)throw Error('qualified delivery receipt unavailable');const proof=await proofResponse.json();
 if(proof.asset_id!==ASSET||proof.person_reference_id!==PERSON||proof.scene!=='1835'||!proof.canonical_run||!Array.isArray(proof.lods)||proof.lods.length!==4||proof.lods.some((r,i)=>r.lod!==i||!/^[a-f0-9]{64}$/.test(r.sha256??'')))throw Error('qualified four-LOD delivery hashes not installed');
 const verifiedFetch=async href=>{const response=await fetch(href);if(!response.ok)return response;const bytes=await response.clone().arrayBuffer(),lod=proof.lods.find(r=>String(href).endsWith('/'+ASSET+'.lod'+r.lod+'.glb'));if(!lod)throw Error('unexpected asset request');const actual=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');if(actual!==lod.sha256)throw Error('qualified GLB byte hash mismatch');return response;};
 const assets=createHumanAssets({assetBase:base,fetchImpl:verifiedFetch});
 // Preload every actual delivery. No missing-LOD fallback or surrogate resident.
 let referenceMeta=null;
 for(let lod=0;lod<4;lod++){
  const g=await assets.acquire(ASSET,lod);try{alive();const doc=g.parser.json,meta=doc.scenes[doc.scene??0]?.extras?.chicago4d_human; if(!meta)throw Error('missing canonical scene provenance');
  if(!g.animations.some(c=>c.name==='idle'||c.name.startsWith('idle_'))||!g.animations.some(c=>c.name==='walk'||c.name.startsWith('walk_')))throw Error('actual named GLB lacks idle/walk at LOD'+lod);
  // Asset identity must be read from actual exported metadata, never a URL alone.
  if(meta.asset_id!==ASSET||meta.person_reference_id!==PERSON||meta.person_reference_scene!=='1835'||meta.person_reference_grade!=='reconstructed'||meta.lod!==lod)throw Error('actual asset metadata mismatch at LOD'+lod);
  if(referenceMeta&&(meta.review_required!==referenceMeta.review_required||meta.touches_removal!==referenceMeta.touches_removal))throw Error('LOD identity review metadata mismatch');referenceMeta??=meta;}finally{assets.release(ASSET,lod);}
 }
 alive();const scene=new T.Scene();scene.background=new T.Color('#e9e7df');scene.add(new T.HemisphereLight(0xffffff,0x777777,2));const sun=new T.DirectionalLight(0xffffff,2);sun.position.set(3,5,4);scene.add(sun);
 const camera=new T.PerspectiveCamera(40,1,.05,100);camera.position.set(3,1.6,4);camera.lookAt(0,.95,0);
 renderer=new T.WebGLRenderer({canvas:document.querySelector('canvas'),antialias:true});renderer.setPixelRatio(1);
 layer=createHumanLayer({assets,heightAt:()=>0,tier:'full'});scene.add(layer.group);
 const instance={id:'study_otis_1835',scene:'1835',person_id:PERSON,review_required:referenceMeta.review_required,touches_removal:referenceMeta.touches_removal,grade:'reconstructed',placement:{local_e:0,local_n:0,heading_deg:180},appearance:{asset_id:ASSET},lod:{policy:'fixed',fixed:0},animation:{loop:true,phase:0},behaviour:{state:'standing'},interaction:{selectable:true,opens:'resident_card',radius_m:0}};
 const actor=layer.add(instance,{person});await actor.setLod(0);alive();
 const problems=[];const people=await mountPeople({mount:document.querySelector('#people'),people:directory,registry:new Map(),dataBase:base,sceneId:'1835',problems});alive();
 layer.on('open',({personId})=>people.open(personId));document.querySelector('#card').onclick=()=>layer.select(PERSON);
 document.querySelector('#idle').onclick=()=>{if(!actor.setState('standing'))fail(Error('idle not playable'));};
 document.querySelector('#walk').onclick=()=>{if(!actor.setState('walking'))fail(Error('walk not playable'));};
 document.querySelector('#lod').onchange=async e=>{try{const lod=Number(e.target.value);instance.lod.fixed=lod;await actor.setLod(lod);}catch(e){fail(e);}};
 const resize=()=>{const c=renderer.domElement;renderer.setSize(c.clientWidth,c.clientHeight,false);camera.aspect=c.clientWidth/c.clientHeight;camera.updateProjectionMatrix();};resize();resizeHandler=resize;addEventListener('resize',resize);
 let last=null;const tick=t=>{if(disposed)return;const dt=last===null?0:Math.min((t-last)/1000,.05);last=t;layer.update(dt,camera);renderer.render(scene,camera);raf=requestAnimationFrame(tick);};raf=requestAnimationFrame(tick);
 status.textContent='Actual named asset loaded. Idle/walk are in-place study clips; no scene route or driver fit.';
 window.otisStudy={actor,layer,people,problems,personId:PERSON,assetId:ASSET,sourceOnlyUnqualified:true};
 
}catch(e){fail(e);cleanup();}
