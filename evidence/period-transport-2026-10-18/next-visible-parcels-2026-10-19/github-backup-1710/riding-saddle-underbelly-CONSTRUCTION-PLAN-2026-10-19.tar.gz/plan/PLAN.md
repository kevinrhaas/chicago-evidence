# New underbelly-to-girthing-leathers construction — PLAN ONLY

Root requested a different construction family after two real failures, not an offset search. Prior50463/b481closurefailure and8ce779/ba3eassemblyfailure remain immutable. No new component/route helper or candidate has been implemented, no new capture/SAT/browser run. Two small read-only maps inspect only existing8cebar vertices/face IDs. Rootapp aedc80126 is unaffected.

## Actual primary text reread BEFORE choosing the family

PRIMARY-EXCERPT.txt retains actual OCR from Lebeaud1833 printed27–28. P27: girthing leathers are little straps nailed to sidebars, THREE on each side, serving to attach girths. Following printed28: girths are 'generally three in number'; a surcingle is a FOURTH passing over the saddle and attached under the belly. The new source may depict the three-girth general family; this is not proof of any specific1835Chicago saddle, owner, strap count/cut/dimensions, buckle or nail pattern. The formerfullbackwrap is not silently promoted to an accepted surcingle. Actual pageimages remain unavailable/uncollated.1833publication reasonedUSPD, no hostlicensefield or invented registryID.

## One fixed hypothesis, explicit ownership

- Eleven saddle layer parts remain EXACT actual50463/8cegeometry, normals, indices/materials and originalrig/reins/sockets unchanged: panel_l/r,tree_sidebar_l/r,front_bow,rear_bow,seat_jockey,jockey_l/r,quarter_l/r. SourceAuthority517795 and recipeec719b also unchanged.
- Replace ONLY riding_girth plus existing billet_l and billet_r: fourteen changed-authoring parts total, fifteen unrelated parts exactA457. Keep29activeprimitivebatches/nodes; each billet mesh holds THREE named independent leathers; girth mesh holds THREE independent underbellybands. Existingthree-component authoring ledger, not unnamed merged shells or duplicate empty meshes.
- Three girth centers Z=-.30,-.18,-.06m, each55mm wide/4mm thick, from the selected actualsidebarcell centers. These dimensions and spacings are ORIGINAL reconstruction, not1833measurements. Source supports general count/materialfamily only. No fourth/surcingle, no invented buckle/nail-head shape or tooling.
- Each separate band runs ONLY below the body from leftside angle1.65rad to rightside2pi-1.65rad around axisY1.16m. It never crosses the spine/cushions. Actual body/seat stays unscaled/unmoved. Angle, clearance and cut are conjectural.

## Six concrete wood/leather root interfaces, not floating endpoints

The chosen attachment footprint is on each actualsidebar TOP surface, not its thick outerwall. Use existing-bar-top-footprints.json: actualZcells4,7,10; lastthreeangularcells21..23 on left, firstthree0..2 on right. Each footprint is six actual triangles/eight exact existing vertices,40mm inZ and about three angularcells long. This patch selection is originalengineering; it is not an asserted historical nail spacing.

Reuse the EXACT existingbar vertices/triangles as the leather foot's inner surface, reversed winding. The leather upper surface is4mm outward, forming a flat leather root resting on the wood as the text's nailed-strap family suggests; no visible nailgeometry or holding-strength claim is made. Continue its outeredge beneath the quarter, taper width40→24mm after leaving the bar, then descend on a declared body/stack envelope. Body/panel/tree/quarter collisions must be independently measured. The originally mapped outerwall endcap alternative (existing-bar-attachment-map.json) is retained as REJECTED: its13mm-thick edge root would be a poor leather section. It is not implemented or used for acceptance.

## Under-quarter leathers and underbelly bands

Six original leathers use the common layer authority to stay outside actualpanel/tree material and below the unchangedquarter exterior. No independent barebody offset through addedpadding. The free lowerleather section transitions toward body-following clearance once outsidepanel angularownership; it must not cross the quarter to get to its end. All actual faces tested; if no feasible corridor exists under fixedlayers, STOP rather than hide an overlap or alter the layers.

Each lowerleather end widens24→55mm to match its band; both share EXACT serialized four-corner endcap vertices. Band/leather meeting is a reconstructed mechanical interface, not an attested sewn/buckled construction; no fastener/load/adjustment acceptance. Six paired endcaps are boundary-only contacts, never interpenetrating volumes. No disconnected point/socket standing in for geometry.

For eachband, clip ALL actual retainedtorso triangles to its full55mmZslab, project the clipped surface toXY and derive a convex supporting contour. Fixed inner/outer support offsets6/10mm give4mm material; the contour method must account for all slab surfaces/between-knots geometry, not three sampled rays or a scalaroffsetsearch. Follow only the underbelly arc, with declaredside endpoints. A conservative hull can float excessively: record actual minimum/typical/maximum stand-off, and reject a visibly unsupported result rather than treating6mm minimum as quality acceptance. Actualwholehorse qualification includes all14172faces, not only thetorso projection. New gait/body/rider fit remains open.

## Component topology and immutable-input contracts

- Eleven layers: each one connected closedEuler2 shell as before, actualallattributes/indices byteexact8ce/50463. Full oldlayerBIN/accessor/view prefix exact.
- riding_girth: three named closed connectedEuler2 U-band solids, caps on bothends, no over-back segment; noEuler0loop. billet_l/r: three named closed connectedEuler2 components each, including explicitrootfoot and endcap. Nine new components plus eleven unchangedlayers =20declaredcomponents across14authoringmeshes. Ledger gives exact vertex/face ranges and attachment aliases; actualreadback verifies everyrange/triangle.
-15protectedmeshdefs, sourceoldBIN, allnode/rig/skin/rein/material/socket/animation contracts unchanged. Only newauthoredprimitives on threeexistingmeshes. Newsource CC0; inheritedGPL audithelpers stayGPL.

## Full raw-contact accounting; narrowly certified real interfaces

Ordinary all-pair SAT remains1e-8/touch-counting. All301 unordered changed/changed(91)+changed/fixed(210) partpairs and all14vsALLhorse tested, including caps. Every rawSAT retained; everystrictproper failure STOP. There are ONLY twelve declared interface IDs: six wood/leatherfoot patches and six leather/band endcaps. No wholemesh/wholepair exemption, no threshold waiver and no excluding underlyingwood/panel/horse.

For each registered interface, sourcealias records bind BOTH actualGLB primitive indices and actualserialized vertexidentity. Coincidenttriangle contacts require identicalactualthreevertexsets with opposing surfaceorientation; edge/point contacts require exactdyadic intersection-only certificates. Registeredpatch boundary-neighbor triangles may qualify ONLY through their exact sharededge/point, not as wholewaivedneighbors. Any contact beyond the declaredpatch/aliases or anyproper crossing fails. This requires a SMALL source-owned interface certificate extension; originalSAT/proper unchanged. RawSAT may bepositive at these physically intended contacts; report rawcounts and independently certifiedcontactcounts separately, never call it0rawSAT.

Allclosedcomponents first require fullself-embedding/vertexlinkproof. Before using winding to rule out nesting, verify each registeredpatch is a disk and each closedcomponent minus its disjointcontactpatches remains connected; select a strict noncontactprobe percomponent. Winding without that premise is NOT accepted. If source/serializedcontact cannot be proved exactly, STOP as unresolved; do not invent a tolerance.

## Review and ONE future bounded trial, not authorized by this document alone

1. Independent PLAN/source-interface/math review, including14/15scope and exactcap/foot contracts; root confirms expanded relatedbillet ownership.
2. Implement onefixed source/recipe/caller and independent actualguards. Review complete executable source before any build. Actualbodyinputs remain old6e9b only.
3. Reproduce originalA457closurefaces0/760 propernegative AND old8cepanel/girth propernegative from actualinputbytes (not cachedgreens). No rebranding earlierfails.
4. ONE boundedcandidate; exactlayer/protected/rig/readback/topology/Khronos checks; actualidle0self/all301interpart/wholehorse. StopFIRSTfailure, archive. No parametersearch or automaticretune.
5. Only fulltechnicalPASS permits a separately coordinated matchedbrowsercomparison. Sourcefamily support is not photograph/pressure/force/load/rider/motion acceptance. Allthosegates remainOPEN.
