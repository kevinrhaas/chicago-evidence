# SPDX-License-Identifier: CC0-1.0
"""Exact source-edge phase refinement of two front cut arcs; no XYZ."""
from pathlib import Path
from fractions import Fraction as F
import json
D=Path(__file__).parent
c=json.load(open(D/'cut-map.json'));K=c['ordered_cut_knots'];n=len(K)
def phase(theta,upper):return(F(46)-theta)/20 if upper else(theta-28)/16
def chart_at(u,upper):return[F('.532')if upper else F('.530'),F(46)-20*u if upper else 28+16*u]
def locate(u,upper):
 seg=12 if upper else 5;P=chart_at(u,upper);matches=[]
 for i,r in enumerate(K):
  if r['segment']!=seg:continue
  a=list(map(F,r['chart']));b=list(map(F,K[(i+1)%n]['chart']));lo,hi=sorted([a[1],b[1]])
  if lo<=P[1]<=hi:
   t=(P[1]-a[1])/(b[1]-a[1]);matches.append({'old_cut_edge':[i,(i+1)%n],'fraction':str(t),'source_chart':list(map(str,P))})
 assert matches,('Missing exact front correspondence',u,upper)
 return matches
U={F(0),F(1)}
for r in K:
 if r['segment']in[5,12]:U.add(phase(F(r['chart'][1]),r['segment']==12))
assert min(U)==0 and max(U)==1
rows=[{'transverse_phase':str(u),'lower_source_aliases':locate(u,False),'upper_source_aliases':locate(u,True)}for u in sorted(U)]
print(json.dumps({'status':'SOURCE chart correspondence only, no XYZ','front_transverse_union':rows,'count':len(rows),'edge_split_rule':'Every new phase splits the existing cut edge in both tissue complement and wet-lining interface; use one canonical alias front:<upper/lower>:rationalphase. Its exact sourceface barycentric aliases are interpolated along named old cut edge, never proximity.','cavity_front_binding':{'lower_inner_z':'.524','upper_inner_z':'.526','lower_floor_y':'-.212','upper_roof_y':'-.206','halfwidth_m':'.018','phase_map':'x = -.018+.036*transverse_phase on both ordered left-to-right front strips; upper oriented path reversed for edge winding; explicit endpointaliases join left/right side lining.'},'physical_claim':'None. Source-phase pairing establishes correspondence/topology only; actual allXYZ embedding and bit checks remain mandatory.'},indent=2))
