# SPDX-License-Identifier: CC0-1.0
"""Symbolic interface/station ledger over existing sources, no new XYZ evaluation."""
from pathlib import Path
import json
from fractions import Fraction as F
D=Path(__file__).parent;B=Path('/workspace/shared')
def run():
 s=json.load(open(B/'horse-oral-channel-diagonal-candidate/candidate-one/head-source-surface.json'));g=json.load(open(B/'horse-combined-oral-neck-mane-prefix-next/candidate-one/graft-proof.json'));c=json.load(open(D/'cut-map.json'));cm=json.load(open(D/'current-map.json'));rec=next(r for r in s['records']if r['name']=='mouth_oral');owners=g['source_face_owners'];opposites=[]
 for key,row in cm['shared_cut_edge_knots'].items():
  if len(row['source_face_owners'])!=1:continue
  a,b=row['source_edge'];found=[]
  for i,f in enumerate(s['faces']):
   for x,y in zip(f,f[1:]+f[:1]):
    if{a,b}=={x,y}:found.append((i,x,y,s['source_owners'][i]))
  assert len(found)==2 and found[0][1:3]==found[1][1:3][::-1]
  opposite=[v for v in found if v[0]not in row['source_face_owners']];assert len(opposite)==1 and opposite[0][3]['kind']=='oral_rim_connector'
  native=[]
  for i,x,y,o in found:
   actual=[int(k)for k,v in owners.items()if v.get('kind')=='oral_channel'and v.get('oral_generated_face')==i];assert len(actual)==1
   native.append({'oral_source_face':i,'directed_edge':[x,y],'source_owner':o,'current57d_global':actual[0]})
  opposites.append({'source_edge':row['source_edge'],'fraction':row['fraction'],'full_opposite_incidence':native,'new_split_alias':'plane420:'+key,'future_new_interface_owner':'lining_at_z420; both old incident triangles retire/split before replacement'})
 assert len(opposites)==4
 regions={0:'left_rear',1:'left_rear',2:'left_rear',3:'left_rear',4:'left_lower',5:'front_lower',6:'right_lower',7:'right_rear',8:'right_rear',9:'right_rear',10:'right_rear',11:'right_upper',12:'front_upper',13:'left_upper'}
 stations=[]
 for i,k in enumerate(c['ordered_cut_knots']):
  z,theta=map(F,k['chart']);region=regions[k['segment']]
  stations.append({'cut_alias':'cut:'+str(i),'segment':k['segment'],'region':region,'source_z':str(z),'source_theta':str(theta),'exterior_binding':'exact source-face barycentric aliases in cut-map','inner_longitudinal_binding':('source_z minus6mm'if region.startswith('front_')else'source_z; transition to6mm setback only atz>=.490'),'inner_transverse_binding':('same normalized source-theta phase in front strip; explicit top/bottom knot union required'if region.startswith('front_')else'left/right signed45mm throughz.420; fixed taper beyond; roof/floor endpoint or rear theta interpolation'),'semantic_JW':'explicit corresponding source-chart barycentric semantic weights; retained seam rawJW exact'})
 # Crescent loops are symbolic IDs, with exact original edge-membership for395.
 crescents=[]
 for side,start,end,arc in[(-1,0,4,set(range(4))),(1,28,32,set(range(7,11)))]:
  x=F(side)*F('.045');top=[];bottom=[];splits=[]
  for y,target in[(F('-.185'),top),(F('-.218'),bottom)]:
   ordered=( [rec['inner'][0]]+[rec['inner'][i]for i in range(65,59,-1)] if side<0 and y==F('-.185') else [rec['inner'][i]for i in range(32,39)] if side>0 and y==F('-.185') else [rec['inner'][i]for i in range(4,10)] if side<0 else [rec['inner'][i]for i in range(28,22,-1)] )
   assert all(s['positions'][ordered[i]][2]<s['positions'][ordered[i+1]][2]for i in range(len(ordered)-1))
   target.extend('oral:'+str(i)for i in ordered if F(str(s['positions'][i][2]))<=F('.395'))
   crossing=[tuple(sorted((a,b)))for a,b in zip(ordered,ordered[1:])if F(str(s['positions'][a][2]))<F('.395')<F(str(s['positions'][b][2]))];assert len(crossing)==1
   a,b=crossing[0];t=(F('.395')-F(str(s['positions'][a][2])))/(F(str(s['positions'][b][2]))-F(str(s['positions'][a][2])));alias='station395:'+str(a)+':'+str(b);target.append(alias);splits.append({'edge':[a,b],'fraction':str(t),'alias':alias,'all_source_incident_faces':[i for i,f in enumerate(s['faces'])if a in f and b in f]})
  cutids=[i for i,k in enumerate(c['ordered_cut_knots'])if k['segment']in arc];nextidx=(cutids[-1]+1)%len(stations);cutids.append(nextidx)
  # left rear path top->bottom; right rear is bottom->top.
  rear=['inner:'+str(i)for i in cutids];backids=[rec['inner'][i]for i in(range(0,5)if side<0 else range(28,33))]
  # ordered explicit loop; endpoints are intentional equivalence aliases.
  crescents.append({'side':side,'roof_source_path_back_to395':top,'floor_source_path_back_to395':bottom,'rear_inner_cut_path':rear,'old_backwall_vertical_path':['oral:'+str(i)for i in backids],'station395_splits':splits,'directed_loop_rule':('roof forward -> rear inner top-to-bottom -> floor reverse -> backwall bottom-to-top'if side<0 else'floor forward -> rear inner bottom-to-top -> roof reverse -> backwall top-to-bottom'),'endpoint_equivalences':{'rear_first':(top[-1]if side<0 else bottom[-1]),'rear_last':(bottom[-1]if side<0 else top[-1])},'orientation':'must verify actual source-phase directed edge pairing before actual build; no side-based flip exemption'})
 return{'status':'SOURCE symbolic interface map; no new XYZ horse geometry','four_plane_edge_full_incidence':opposites,'cut108_longitudinal_transverse_stations':stations,'posterior_crescents':crescents,'remaining':'Front upper/lower source-theta knot union and oriented full lining combinatorics must be proved by source helper before actualtrial.'}
if __name__=='__main__':print(json.dumps(run(),indent=2))
