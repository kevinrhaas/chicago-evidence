# SPDX-License-Identifier: CC0-1.0
"""Source-chart combinatorics only; no 3D output."""
import json
from pathlib import Path
from fractions import Fraction as F
from planar_complement import *
D=Path(__file__).parent;B=Path('/workspace/shared/horse-oral-channel-diagonal-candidate/source')
def chart():
 h=json.load(open(B/'frozen-head.json'));p=json.load(open(B/'oral-patch.json'));c=json.load(open(D/'cut-map.json'));K=[tuple(map(F,r['chart']))for r in c['ordered_cut_knots']];simple(K)
 uv={i:(F(str(x[2])),F((i-72)%48))for i,x in enumerate(h['positions'])if 72<=i<648};cut=list(zip(K,K[1:]+K[:1]));alltris=[];records=[]
 for face in p['proposed_retired_source_face_ids']:
  T=[uv[i]for i in h['faces'][face]];ce=[]
  for a,b in cut:
   midpoint=tuple((a[k]+b[k])/2 for k in range(2));s=[orient(T[i],T[(i+1)%3],midpoint)for i in range(3)]
   if min(s)>=0 or max(s)<=0:ce.append((a,b))
  polygons=arrangement(T,ce,K);keep=[];drop=[]
  for polygon in polygons:
   for tri in triangulate(polygon):
    q=tuple(sum(x[k]for x in tri)/3 for k in range(2));(drop if inside(q,K)else keep).append(tri)
  assert sum(area(t)for t in keep+drop)==abs(area(T));alltris+=keep
  records.append({'source_face':face,'retained_chart_triangles':[[list(map(str,v))for v in t]for t in keep],'removed_chart_triangles':[[list(map(str,v))for v in t]for t in drop]})
 V=set(v for t in alltris for v in t);E={}
 for t in alltris:
  for a,b in zip(t,t[1:]+t[:1]):E.setdefault(tuple(sorted((a,b))),[]).append((a,b))
 for e,rows in E.items():assert len(rows)==1 or(len(rows)==2 and rows[0]==rows[1][::-1]),'Conforming shared-edge ownership'
 boundary={e for e,rows in E.items()if len(rows)==1};outer={tuple(sorted((uv[a],uv[b])))for a,b in zip(p['rim_source_vertex_loop'],p['rim_source_vertex_loop'][1:]+p['rim_source_vertex_loop'][:1])};inner={tuple(sorted(e))for e in cut}
 assert boundary==outer|inner,'Only old66 and new108 boundary'
 assert len(V)-len(E)+len(alltris)==0,'Annulus Euler'
 return{'status':'2D exact source-chart complement ONLY; no XYZ geometry generated','global_cut_simple':True,'exact_per_source_triangle_coverage':True,'source_records':records,'complement_summary':{'V':len(V),'E':len(E),'F':len(alltris),'Euler':0,'outer_edges':len(outer),'inner_edges':len(inner),'all_shared_edges_opposite':True}}
if __name__=='__main__':print(json.dumps(chart(),indent=2))
