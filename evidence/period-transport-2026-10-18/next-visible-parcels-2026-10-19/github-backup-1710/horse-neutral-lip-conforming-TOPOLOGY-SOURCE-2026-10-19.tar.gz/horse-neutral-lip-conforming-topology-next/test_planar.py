import unittest
from fractions import Fraction as F
from planar_complement import *
def pts(a):return[tuple(map(F,p))for p in a]
class Tests(unittest.TestCase):
 def test_square(self):simple(pts([(0,0),(2,0),(2,2),(0,2)]))
 def test_bowtie(self):
  with self.assertRaises(AssertionError):simple(pts([(0,0),(2,2),(0,2),(2,0)]))
 def test_nonadjacent_touch(self):
  with self.assertRaises(AssertionError):simple(pts([(0,0),(2,0),(2,2),(1,0),(0,2)]))
 def test_duplicate(self):
  with self.assertRaises(AssertionError):simple(pts([(0,0),(2,0),(2,2),(0,0)]))
 def test_conforming_triangle_split(self):
  t=pts([(0,0),(4,0),(0,4)]);a,b=pts([(2,0),(0,2)]);p=arrangement(t,[(a,b)],[a,b]);self.assertEqual(len(p),2);self.assertEqual(sum(area(x)for x in p),16)
 def test_reversed_triangle(self):
  t=pts([(0,0),(0,4),(4,0)]);a,b=pts([(2,0),(0,2)]);p=arrangement(t,[(a,b)],[a,b]);self.assertEqual(sum(area(x)for x in p),16)
 def test_boundary_split_preserved(self):
  t=pts([(0,0),(4,0),(0,4)]);k=pts([(1,0)])[0];p=arrangement(t,[],[k]);tr=triangulate(p[0]);self.assertTrue(any(k in f for f in tr))
 def test_outside_edge_rejected(self):
  with self.assertRaises(AssertionError):arrangement(pts([(0,0),(4,0),(0,4)]),[tuple(pts([(5,5),(6,5)]))],[])
if __name__=='__main__':unittest.main()
