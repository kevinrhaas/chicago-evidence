# SPDX-License-Identifier: CC0-1.0
"""Exact rational 2D source-chart arrangement. Never constructs XYZ horse data."""
from fractions import Fraction as F
from functools import cmp_to_key

def sub(a,b):return(a[0]-b[0],a[1]-b[1])
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def orient(a,b,c):return cross(sub(b,a),sub(c,a))
def on(p,a,b):return orient(a,b,p)==0 and all(min(a[k],b[k])<=p[k]<=max(a[k],b[k])for k in range(2))
def area(poly):return sum(cross(a,b)for a,b in zip(poly,poly[1:]+poly[:1]))
def intersect(a,b,c,d):
 o=[orient(a,b,c),orient(a,b,d),orient(c,d,a),orient(c,d,b)]
 return(o[0]*o[1]<0 and o[2]*o[3]<0)or any([o[0]==0 and on(c,a,b),o[1]==0 and on(d,a,b),o[2]==0 and on(a,c,d),o[3]==0 and on(b,c,d)])
def simple(poly):
 assert len(set(poly))==len(poly) and area(poly)!=0,'Unique nondegenerate polygon'
 n=len(poly)
 for i in range(n):
  for j in range(i+1,n):
   if j in[(i+1)%n,(i-1)%n]:continue
   assert not intersect(poly[i],poly[(i+1)%n],poly[j],poly[(j+1)%n]),'Nonadjacent chart cut contact/cross'
def inside(p,poly):
 assert not any(on(p,a,b)for a,b in zip(poly,poly[1:]+poly[:1])),'Classification sample on boundary'
 odd=False
 for a,b in zip(poly,poly[1:]+poly[:1]):
  if(a[1]>p[1])!=(b[1]>p[1]):
   x=a[0]+(p[1]-a[1])*(b[0]-a[0])/(b[1]-a[1])
   if x>p[0]:odd=not odd
 return odd
def triangulate(poly):
 if area(poly)<0:poly=poly[::-1]
 remaining=poly[:];result=[]
 while len(remaining)>3:
  found=False
  for i,b in enumerate(remaining):
   a=remaining[i-1];c=remaining[(i+1)%len(remaining)]
   if orient(a,b,c)<=0:continue
   if any(min(orient(a,b,p),orient(b,c,p),orient(c,a,p))>=0 for p in remaining if p not in[a,b,c]):continue
   result.append([a,b,c]);remaining.pop(i);found=True;break
  assert found,'No nondegenerate conforming ear'
 assert orient(*remaining)>0;result.append(remaining);return result

def arrangement(triangle,cut_edges,all_knots):
 if area(triangle)<0:triangle=triangle[::-1]
 edges=set()
 def add(a,b):assert a!=b;edges.add(tuple(sorted((a,b))))
 for a,b in zip(triangle,triangle[1:]+triangle[:1]):
  pts={a,b}|{p for p in all_knots if on(p,a,b)};k=max(range(2),key=lambda k:abs(b[k]-a[k]));order=sorted(pts,key=lambda p:p[k])
  for x,y in zip(order,order[1:]):add(x,y)
 for a,b in cut_edges:
  assert all(min(orient(triangle[i],triangle[(i+1)%3],p)for i in range(3))>=0 for p in[a,b]),'Cut edge outside source triangle'
  add(a,b)
 adj={}
 for a,b in edges:adj.setdefault(a,[]).append(b);adj.setdefault(b,[]).append(a)
 def cmp(u,v):
  hu=0 if u[1]>0 or(u[1]==0 and u[0]>=0)else 1;hv=0 if v[1]>0 or(v[1]==0 and v[0]>=0)else 1
  if hu!=hv:return -1 if hu<hv else 1
  z=cross(u,v);assert z!=0 or u==v,'Overlapping collinear graph rays';return -1 if z>0 else 1 if z<0 else 0
 for a in adj:adj[a].sort(key=cmp_to_key(lambda b,c:cmp(sub(b,a),sub(c,a))))
 seen=set();polys=[]
 for a,b in[(a,b)for e in edges for a,b in[e,e[::-1]]]:
  if(a,b)in seen:continue
  path=[];start=(a,b)
  while(a,b)not in seen:
   seen.add((a,b));path.append(a);neighbors=adj[b];a,b=b,neighbors[(neighbors.index(a)-1)%len(neighbors)]
  assert(a,b)==start,'Graph cycle merges'
  if area(path)>0:polys.append(path)
 assert sum(area(p)for p in polys)==area(triangle),'Exact planar triangle coverage'
 return polys
