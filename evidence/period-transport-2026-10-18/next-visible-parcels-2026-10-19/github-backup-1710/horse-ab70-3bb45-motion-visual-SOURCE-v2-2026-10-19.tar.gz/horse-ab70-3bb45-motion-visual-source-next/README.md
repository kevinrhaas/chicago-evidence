# New sampled-motion visual study

This is a NEW outside-app study of immutable horse ab70 and harness3bb45. The earlier7c2 idle-only ab70/fe76 parcel, app and its qualification remain unchanged. The new pair passed actual idle/walk/trot21 samples each in2456.201765606005seconds, independently audited stored hashes and complete cohorts. This source neither reruns SAT nor manufactures stronger acceptance.

Controls select only those21 sample indices per actual decoded clip. There is no continuous autoplay. Both actual actor-root and head bindings use the previously reviewed parent-inverse helper before every rendered update. The receipt reads actual action/clip/time and world matrices after rendering, validates full referenced source-index coverage, and records every expected object reaching onAfterRender. Deformed vertices, strict2% framing and measured header/control bounds are CPU-double diagnostics, NOT GPU or Float32 skinning proof. PNG inspection is still required.

The light, camera-fit and post-render/control/disposal patterns adapt the reviewed riding-saddle-front-return-ab-source fixture; its qualification does not transfer. The actual_bindings and actual_primitive modules are exact copies from the frozen sampled-motion driver. SHA-checked fetched buffers themselves are parsed, external GLB resources are refused, source-declared indexed/nonindexed streams are complete, stale selected-state receipts cannot pass the driver, and scene/skeleton/texture/material/renderer resources are disposed. Negative checks corrupt each actual fetched component and dispose during a held gear fetch. All failures remain in a fresh exclusive output, with no automatic retry.

After independent source review and root confirming exclusive browser ownership, run the ONE permitted window with:

    python run_once.py --released-render-window --output /workspace/shared/horse-ab70-3bb45-motion-visual-FIRST

It has an unchanged120second outer cap and a shorter browser timer, captures6selected views per viewport (1280x800 and390x780), tests loop endpoint, hide/reset, keyboard/touch, fetched-hash refusal and cleanup, then closes browser/server. No source installation, app mutation, model generation, fit replay, people or historical-scene integration occurs. Ground contact, pulling forces, strap tension, riders, boarding, continuous collision, anatomical/photo quality and period/breed identity remain open. Source must remain frozen through the actual window.
