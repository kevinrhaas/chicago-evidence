// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import * as T from 'three';
import {qualifiedPose,assertActualPose} from './pose.mjs';
import {checkedSurfaces,actualWorldPoints,fitCamera,projectedBounds} from './inspection.mjs';
const durations={idle:1.25,walk:1.25,trot:0.7200000286102295},clips=Object.entries(durations).map(([name,d])=>new T.AnimationClip(name,d,[])),mixer=new T.AnimationMixer(new T.Object3D());
let poses=0;
for(const name of Object.keys(durations))for(const index of [0,5,15,20]){const p=qualifiedPose(clips,name,index,durations);mixer.stopAllAction();const a=mixer.clipAction(p.clip);a.reset().setLoop(T.LoopOnce,1);a.clampWhenFinished=true;a.play();mixer.setTime(p.time_s);assertActualPose(p,a,mixer);a.time+=.001;assert.throws(()=>assertActualPose(p,a,mixer),/disagreement/);poses++;}
for(const index of [-1,21,1.5,true,NaN])assert.throws(()=>qualifiedPose(clips,'walk',index,durations));assert.throws(()=>qualifiedPose([...clips,clips[0]],'idle',0,durations),/Unique/);assert.throws(()=>qualifiedPose(clips,'walk',0,{...durations,walk:9}),/duration/);
const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute([0,0,0,1,0,0,0,1,0,5000,5000,5000],3));g.setIndex([0,1,2]);const mesh=new T.Mesh(g,new T.MeshBasicMaterial()),scene=new T.Group();scene.add(mesh);scene.updateMatrixWorld(true);const assoc=new Map([[mesh,{meshes:0,primitives:0}]]),gltf={scene,parser:{associations:assoc,json:{meshes:[{name:'actual_triangle',primitives:[{mode:4,indices:0}]}]}}};const bytes=Buffer.alloc(12);[0,1,2].forEach((v,i)=>bytes.writeUInt32LE(v,i*4));const expected=[{name:'actual_triangle',sourceMesh:0,sourcePrimitive:0,positionCount:4,indexCount:3,indexed:true,indexStreamSHA256:createHash('sha256').update(bytes).digest('hex')}];
const surfaces=await checkedSurfaces(gltf,expected),points=actualWorldPoints(surfaces);assert.equal(points.length,3);assert(points.every(p=>p.length()<2),'Unused outlier must not inflate actual referenced framing');await assert.rejects(()=>checkedSurfaces(gltf,[{...expected[0],name:'wrong'}]),/coverage/);g.setDrawRange(0,0);await assert.rejects(()=>checkedSurfaces(gltf,expected),/drawRange/);g.setDrawRange(0,Infinity);
const body=[];for(const x of [-.6,.7])for(const y of [-.05,2.2])for(const z of [-1.4,1.8])body.push(new T.Vector3(x,y,z));let cameras=0;
for(const[w,h]of [[1280,600],[390,500],[390,320]])for(const view of ['threequarter','side','rear']){const camera=new T.PerspectiveCamera(36,w/h,.02,80);fitCamera(camera,body,view);const b=projectedBounds(camera,body);assert(b.depthValid&&b.left>=.02&&b.right<=.98&&b.top>=.02&&b.bottom<=.98);cameras++;}
g.dispose();mesh.material.dispose();mixer.stopAllAction();console.log(JSON.stringify({PASS:true,scope:'Synthetic actual Three and source-reference canaries ONLY; no browser/models/fit',actualClipEndpointsAndTimes:poses,strictCPUCameras:cameras,sourceCoverageControls:3}));
