// SPDX-License-Identifier: GPL-3.0-or-later
export function qualifiedPose(clips, name, index, declared) {
  if (!['idle', 'walk', 'trot'].includes(name) || !Number.isInteger(index) || index < 0 || index > 20) throw Error('Qualified clip and integer sample 0..20 required');
  const matches = clips.filter(c => c.name === name);
  if (matches.length !== 1) throw Error('Unique actual clip required');
  const clip = matches[0];
  if (!Number.isFinite(clip.duration) || clip.duration <= 0 || clip.duration !== declared[name]) throw Error('Actual clip duration differs from qualified source');
  return {clip, name, index, phase: index / 20, time_s: clip.duration * (index / 20), duration_s: clip.duration};
}
export function assertActualPose(pose, action, mixer) {
  if (action.getClip() !== pose.clip || action.time !== pose.time_s || mixer.time !== pose.time_s || action.clampWhenFinished !== true) throw Error('Actual selected clip/time/clamp disagreement');
}
