# SPDX-License-Identifier: GPL-3.0-or-later
"""ONE root-released <=120s render window; never start a geometric fit."""
from pathlib import Path
import argparse,subprocess,os,signal,time,json,hashlib,sys
P=Path(__file__).parent
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--released-render-window',action='store_true',required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();out=a.output.resolve()
 if out.exists():raise FileExistsError('Refuse existing render output')
 record=out.with_name(out.name+'-operator.json');start=time.monotonic();r={'PASS':False,'scope':'ONE controlled visual study, no new fit/capture qualification','bound_s':120}
 with record.open('x')as f:json.dump(r,f)
 try:
  for n,w in json.loads((P/'SOURCE-HASHES.json').read_text()).items():
   if hashlib.sha256((P/n).read_bytes()).hexdigest()!=w:raise ValueError('Frozen source '+n)
  for n,w in json.loads((P/'EXTERNAL-HASHES.json').read_text()).items():
   if hashlib.sha256(Path(n).read_bytes()).hexdigest()!=w:raise ValueError('Pinned external '+n)
  r['source_inventory_sha256']=hashlib.sha256((P/'SOURCE-HASHES.json').read_bytes()).hexdigest()
  with record.with_suffix('.stdout').open('xb')as stdout,record.with_suffix('.stderr').open('xb')as stderr:
   child=subprocess.Popen(['node',str(P/'run.cjs'),'--released-render-window',str(out)],stdout=stdout,stderr=stderr,start_new_session=True)
   try:code=child.wait(timeout=max(.01,120-(time.monotonic()-start)))
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait();code=124
   except BaseException:os.killpg(child.pid,signal.SIGKILL);child.wait();raise
  r['exit']=code
  if code:raise RuntimeError('FIRST visual-window failure '+str(code))
  receipt=json.loads((out/'receipt.json').read_text())
  if receipt.get('passed')is not True or receipt.get('closed')is not True or len(receipt.get('runs',[]))!=2 or any(x.get('passed')is not True or len(x.get('views',[]))!=6 for x in receipt['runs'])or len(receipt.get('negative',[]))!=3:raise ValueError('Complete both-viewport/control/cleanup evidence required')
  r['PASS']=True;r['receipt_sha256']=hashlib.sha256((out/'receipt.json').read_bytes()).hexdigest()
 except BaseException as e:r['error']=repr(e)
 finally:r['elapsed_s']=time.monotonic()-start;record.write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps(r));return 0 if r['PASS']else 2
if __name__=='__main__':sys.exit(main())
