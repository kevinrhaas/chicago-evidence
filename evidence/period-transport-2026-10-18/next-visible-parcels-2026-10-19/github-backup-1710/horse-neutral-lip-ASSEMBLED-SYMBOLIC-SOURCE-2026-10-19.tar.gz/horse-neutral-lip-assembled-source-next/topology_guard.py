# SPDX-License-Identifier: CC0-1.0
# Original source-only helper; explicit guards remain active under Python -O.
"""Pure directed simplicial disk guard, no positions or model IO."""
def require(value, message):
    if not value:
        raise AssertionError(message)
import collections

def disk(faces, expected_boundary):
    E = collections.defaultdict(list)
    V = set()
    links = collections.defaultdict(list)
    edgeF = collections.defaultdict(list)
    require(faces and len({tuple(sorted(t)) for t in faces}) == len(faces), 'No missing/duplicate faces')
    for index, t in enumerate(faces):
        require(len(t) == 3 and len(set(t)) == 3, 'Source contract violation')
        V.update(t)
        for i in range(3):
            links[t[i]].append((t[(i + 1) % 3], t[(i + 2) % 3]))
        for a, b in zip(t, t[1:] + t[:1]):
            E[tuple(sorted((a, b)))].append((a, b))
            edgeF[tuple(sorted((a, b)))].append(index)
    require(all((len(rows) == 1 or (len(rows) == 2 and rows[0] == rows[1][::-1]) for rows in E.values())), 'Opposite interface incidence')
    boundary = {tuple(sorted(rows[0])) for rows in E.values() if len(rows) == 1}
    require(boundary == expected_boundary, 'Exact expected boundary')
    require(len(V) - len(E) + len(faces) == 1, 'Euler disk')
    boundaryV = {v for e in boundary for v in e}
    for v, rows in links.items():
        A = collections.defaultdict(set)
        for a, b in rows:
            A[a].add(b)
            A[b].add(a)
        todo = [next(iter(A))]
        seen = set()
        while todo:
            a = todo.pop()
            if a not in seen:
                seen.add(a)
                todo.extend(A[a] - seen)
        require(len(seen) == len(A), 'Connected vertex link')
        degree = collections.Counter(map(len, A.values()))
        require(degree == collections.Counter({1: 2, 2: len(A) - 2} if v in boundaryV else {2: len(A)}), 'Disk vertex link')
    A = collections.defaultdict(set)
    for ids in edgeF.values():
        if len(ids) == 2:
            A[ids[0]].add(ids[1])
            A[ids[1]].add(ids[0])
    todo = [0]
    seen = set()
    while todo:
        a = todo.pop()
        if a not in seen:
            seen.add(a)
            todo.extend(A[a] - seen)
    require(len(seen) == len(faces), 'Connected face disk')
    return {'V': len(V), 'E': len(E), 'F': len(faces), 'Euler': 1, 'boundary': len(boundary), 'connected': True, 'directed_manifold': True}
