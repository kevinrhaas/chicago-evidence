# SPDX-License-Identifier: GPL-3.0-or-later
# Original source-only helper; explicit guards remain active under Python -O.
"""Glue symbolic replacement to ACTUAL source-labeled retained57d head, noXYZ."""
def require(value, message):
    if not value:
        raise AssertionError(message)
from pathlib import Path
import sys, json, hashlib
sys.path.insert(0, '/workspace/shared/horse-neutral-lip-source-phase-next')
from lip_variant import Model
from topology_guard import disk
B = Path('/workspace/shared')
D = Path(__file__).parent
raw = (B / 'horse-cheek-throat-quality-next/candidate-one/candidate.glb').read_bytes()
require(hashlib.sha256(raw).hexdigest() == '57d63e2d7234380adeb727f5efeeed74d50629b2a8367ccea48961d6ecc5bec2', 'Source contract violation')
m = Model(raw)
g = json.load(open(B / 'horse-combined-oral-neck-mane-prefix-next/candidate-one/graft-proof.json'))
labels = {(r['mesh'], r['vertex']): r['label'] for r in g['source_labels']}
owners = g['source_face_owners']
head = g['head_faces']
old = []
kept = []
removed = []
for gid in head:
    d = m.descriptor(gid)
    t = [labels[d['mesh'], i] for i in d['primitive_vertices']]
    old.append(t)
    o = owners[str(gid)]
    if o.get('kind') == 'oral_channel' and o['source_owner']['kind'] in ['oral_rim_connector', 'oral_roof', 'oral_floor', 'oral_back']:
        removed.append(gid)
    else:
        kept.append(t)
require(len(removed) == 334, 'Source contract violation')
E = {}
for t in old:
    for a, b in zip(t, t[1:] + t[:1]):
        E.setdefault(tuple(sorted((a, b))), []).append((a, b))
boundary = {e for e, rows in E.items() if len(rows) == 1}
parent = disk(old, boundary)
new = json.load(open(D / 'complete-symbolic.json'))
merged = kept + new['triangles']
receipt = disk(merged, boundary)
print(json.dumps({'status': 'ACTUAL retained sourceindices plus SYMBOLIC replacement ONLY, no XYZ evaluated', 'parent': parent, 'assembled_head': receipt, 'retired_current_mouth334': removed, 'new_symbolic_faces': len(new['triangles']), 'expected_parent_boundary': sorted([list(e) for e in boundary]), 'unproven': 'Actual newXYZ embedding,normals,weights,storage,gear,bit and appearance remain UNEXECUTED'}, indent=2))
