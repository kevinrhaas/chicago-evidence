# SPDX-License-Identifier: CC0-1.0
"""Both front strip phases are source-defined LEFT-to-RIGHT, no XYZ."""
from pathlib import Path
from fractions import Fraction as F
import json
D=Path(__file__).parent;c=json.load(open(D/'cut-map.json'));K=c['ordered_cut_knots'];n=len(K)
def locate(u,upper):
 segment=12 if upper else 5;theta=26+20*u if upper else 28+16*u;P=[F('.532')if upper else F('.530'),theta];out=[]
 for i,r in enumerate(K):
  if r['segment']!=segment:continue
  a=list(map(F,r['chart']));b=list(map(F,K[(i+1)%n]['chart']));lo,hi=sorted([a[1],b[1]])
  if lo<=theta<=hi:out.append({'old_cut_edge':[i,(i+1)%n],'fraction':str((theta-a[1])/(b[1]-a[1])),'source_chart':list(map(str,P))})
 if not out:raise ValueError('Missing sourcephase alias')
 return out
U={F(0),F(1)}
for r in K:
 if r['segment']==5:U.add((F(r['chart'][1])-28)/16)
 if r['segment']==12:U.add((F(r['chart'][1])-26)/20)
rows=[{'transverse_phase':str(u),'lower_source_aliases':locate(u,False),'upper_source_aliases':locate(u,True)}for u in sorted(U)]
print(json.dumps({'status':'SOURCE phase correction; no XYZ','front_transverse_union':rows,'count':len(rows),'phase_convention':'u0 left,u1 right for BOTH strips; upper directed loop traverses u1 to0, lower0to1','supersedes':'6b04 frontmap upper phase ran right-to-left but its xformula was labeled left-to-right; corrected source authority here before any geometry build','future_inner_x_expression':'-.018+.036*u for BOTH strips; no positions evaluated'},indent=2))
