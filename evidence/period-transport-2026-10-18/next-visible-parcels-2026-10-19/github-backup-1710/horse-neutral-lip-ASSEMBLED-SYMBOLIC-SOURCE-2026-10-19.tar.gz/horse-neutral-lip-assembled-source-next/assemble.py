# SPDX-License-Identifier: CC0-1.0
# Original source-only helper; explicit guards remain active under Python -O.
"""Symbolic source-owned mouth connectivity only. NO new horse XYZ arrays."""
def require(value, message):
    if not value:
        raise AssertionError(message)
from pathlib import Path
from fractions import Fraction as Q
import json, collections
from planar_complement import *
D = Path(__file__).parent
B = Path('/workspace/shared/horse-oral-channel-diagonal-candidate')

def key(p):
    return 'cut:' + ':'.join(map(str, p))

def inner(p):
    return 'inner:' + ':'.join(map(str, p))

def build():
    h = json.load(open(B / 'source/frozen-head.json'))
    patch = json.load(open(B / 'source/oral-patch.json'))
    s = json.load(open(B / 'candidate-one/head-source-surface.json'))
    cm = json.load(open(D / 'current-map.json'))
    im = json.load(open(D / 'interface-map.json'))
    fm = json.load(open(D / 'front-map.json'))
    cut = json.load(open(D / 'cut-map.json'))
    r = next((r for r in s['records'] if r['name'] == 'mouth_oral'))
    K = [tuple(map(Q, k['chart'])) for k in cut['ordered_cut_knots']]
    originalK = K[:]
    insert = set(K)
    for row in fm['front_transverse_union']:
        for name in ['lower_source_aliases', 'upper_source_aliases']:
            for a in row[name]:
                insert.add(tuple(map(Q, a['source_chart'])))
    sidepaths = {Q(26): [r['inner'][0]] + [r['inner'][i] for i in range(65, 59, -1)], Q(28): [r['inner'][i] for i in range(4, 10)], Q(44): [r['inner'][i] for i in range(28, 22, -1)], Q(46): [r['inner'][i] for i in range(32, 39)]}
    for theta, ids in sidepaths.items():
        for i in ids:
            z = Q(str(s['positions'][i][2]))
            if Q('.395') <= z <= Q('.420'):
                insert.add((z, theta))
        insert.update(((z, theta) for z in [Q('.395'), Q('.420'), Q('.490')]))
    refined = []
    sourceedges = []
    for j, (a, b) in enumerate(zip(K, K[1:] + K[:1])):
        pts = [p for p in insert if on(p, a, b)]
        axis = max(range(2), key=lambda k: abs(b[k] - a[k]))
        pts.sort(key=lambda p: (p[axis] - a[axis]) / (b[axis] - a[axis]))
        require(pts[0] == a and pts[-1] == b, 'Source contract violation')
        refined += pts[:-1]
        sourceedges += [j] * (len(pts) - 1)
    K = refined
    require(len(set(K)) == len(K), 'Source contract violation')
    simple(K)
    uv = {i: (Q(str(p[2])), Q((i - 72) % 48)) for i, p in enumerate(h['positions']) if 72 <= i < 648}
    uvlabels = {v: 'h:' + str(i) for i, v in uv.items()}
    ids = patch['proposed_retired_source_face_ids']
    triangles = []
    owners = []
    coords = {}

    def emit(t, owner):
        require(len(set(t)) == 3, 'Source contract violation')
        triangles.append(t)
        owners.append(owner)

    def add_chart_polygon(poly, labels, owner):
        require(len(poly) == len(set(poly)), 'Source contract violation')
        require(len(labels) == len(set(labels)), 'Source contract violation')
        lookup = dict(zip(poly, labels))
        coords.update({label: list(map(str, p)) for p, label in zip(poly, labels)})
        for t in triangulate(poly):
            emit([lookup[p] for p in t], owner)
    edges = list(zip(K, K[1:] + K[:1]))
    for face in ids:
        T = [uv[i] for i in h['faces'][face]]
        cuts = []
        for a, b in edges:
            q = tuple(((a[k] + b[k]) / 2 for k in range(2)))
            sign = [orient(T[i], T[(i + 1) % 3], q) for i in range(3)]
            if min(sign) >= 0 or max(sign) <= 0:
                cuts.append((a, b))
        for polygon in arrangement(T, cuts, K):
            for t in triangulate(polygon):
                q = tuple((sum((p[k] for p in t)) / 3 for k in range(2)))
                if not inside(q, K):
                    if area(T) < 0:
                        t = t[::-1]
                    emit([key(p) if p in set(K) else uvlabels[p] for p in t], {'kind': 'conforming_exterior', 'ancestor_face': face})
    equiv = {}
    split395 = {}
    for cres in im['posterior_crescents']:
        theta = Q(26) if cres['side'] < 0 else Q(46)
        for rec in cres['station395_splits']:
            a, b = rec['edge']
            y = Q(str(s['positions'][a][1]))
            th = theta if y < Q('-.18') and y > Q('-.20') else Q(28) if cres['side'] < 0 else Q(44)
            split395[th] = rec['alias']
            equiv[inner((Q('.395'), th))] = rec['alias']
    for th, ids2 in sidepaths.items():
        for i in ids2:
            z = Q(str(s['positions'][i][2]))
            if Q('.395') <= z < Q('.420'):
                equiv[inner((z, th))] = 'oral:' + str(i)
    for e, row in cm['shared_cut_edge_knots'].items():
        if len(row['source_face_owners']) == 1:
            a, b = row['source_edge']
            matching = [th for th, ids2 in sidepaths.items() if a in ids2 and b in ids2]
            require(len(matching) == 1, 'Source contract violation')
            equiv[inner((Q('.420'), matching[0]))] = 'plane420:' + e

    def canonical(x):
        return equiv.get(x, x)
    E = collections.defaultdict(list)
    for t in triangles:
        for a, b in zip(t, t[1:] + t[:1]):
            E[tuple(sorted((a, b)))].append((a, b))
    for a, b in edges:
        rows = E[tuple(sorted((key(a), key(b))))]
        require(len(rows) == 1, 'Source contract violation')
        x, y = rows[0]
        A = canonical(inner(a))
        B2 = canonical(inner(b))
        mapping = {key(a): A, key(b): B2}
        ix, iy = (mapping[x], mapping[y])
        emit([y, x, ix], {'kind': 'wet_lining'})
        emit([y, ix, iy], {'kind': 'wet_lining'})
    plane = Q('.420')
    stationextras = []
    for cres in im['posterior_crescents']:
        stationextras += cres['station395_splits']
    sourceP = s['positions']
    cavity = [row for row in cm['cavity202_source_owned_plane_partition']]

    def original(i):
        return 'oral:' + str(i)

    def planealias(a, b):
        return 'plane420:' + ':'.join(map(str, sorted((a, b))))

    def sourcepoly(row):
        f = row['vertices']
        out = []
        for a, b in zip(f, f[1:] + f[:1]):
            za, zb = (Q(str(sourceP[a][2])), Q(str(sourceP[b][2])))
            if za <= plane:
                out.append((original(a), tuple(map(lambda v: Q(str(v)), sourceP[a]))))
            if za < plane < zb or zb < plane < za:
                t = (plane - za) / (zb - za)
                p = tuple((Q(str(sourceP[a][k])) + t * (Q(str(sourceP[b][k])) - Q(str(sourceP[a][k]))) for k in range(3)))
                out.append((planealias(a, b), p))
        final = []
        for index, (label, p) in enumerate(out):
            final.append((label, p))
            other, q = out[(index + 1) % len(out)]
            a = int(label[5:]) if label.startswith('oral:') else None
            b = int(other[5:]) if other.startswith('oral:') else None
            if a is not None and b is not None:
                for extra in stationextras:
                    if set(extra['edge']) == {a, b}:
                        lo, hi = extra['edge']
                        t = Q(extra['fraction'])
                        P = tuple((Q(str(sourceP[lo][k])) + t * (Q(str(sourceP[hi][k])) - Q(str(sourceP[lo][k]))) for k in range(3)))
                        final.append((extra['alias'], P))
        return final
    cavitypolygons = []
    for row in cavity:
        if row['classification'] == 'anterior_retire':
            continue
        poly = sourcepoly(row)
        if len(poly) < 3:
            continue
        axes = (0, 1) if row['source_owner']['kind'] == 'oral_back' else (0, 2)
        P = [tuple((q[k] for k in axes)) for _, q in poly]
        labels = [x for x, _ in poly]
        tri0 = [sourceP[i] for i in row['vertices']]
        sgn = area([tuple((Q(str(p[k])) for k in axes)) for p in tri0])
        require(sgn, 'Source contract violation')
        before = len(triangles)
        add_chart_polygon(P, labels, {'kind': 'retained_cavity_clip', 'oral_source_face': row['oral_source_face']})
        if sgn < 0:
            for t in triangles[before:]:
                t.reverse()
        cavitypolygons.append({'face': row['oral_source_face'], 'ordered_aliases': labels})
    return dict(K=K, triangles=triangles, owners=owners, equiv=equiv, cavitypolygons=cavitypolygons, coords=coords)
if __name__ == '__main__':
    x = build()
    print(json.dumps({'status': 'PARTIAL SYMBOLIC ASSEMBLY; no newXYZ', 'refined_cut': [[str(v) for v in p] for p in x['K']], 'faces': x['triangles'], 'owners': x['owners'], 'equivalences': x['equiv'], 'cavity_polygons': x['cavitypolygons'], 'remaining': 'Anterior roof/floor panels and two posterior crescents not yet appended; manifold proof pending'}, indent=2))
