import unittest,copy,json
from pathlib import Path
from topology_guard import disk
class Controls(unittest.TestCase):
 def setUp(self):self.f=[['a','b','c'],['a','c','d']];self.b={tuple(sorted(x))for x in[['a','b'],['b','c'],['c','d'],['d','a']]}
 def test_disk(self):self.assertEqual(disk(self.f,self.b)['Euler'],1)
 def test_no_mutation(self):old=copy.deepcopy(self.f);disk(self.f,self.b);self.assertEqual(old,self.f)
 def test_missing_face(self):
  with self.assertRaises(AssertionError):disk(self.f[:1],self.b)
 def test_reversed_interface(self):
  with self.assertRaises(AssertionError):disk([self.f[0],self.f[1][::-1]],self.b)
 def test_duplicate_face(self):
  with self.assertRaises(AssertionError):disk(self.f+[self.f[0]],self.b)
 def test_split_only_one_side(self):
  with self.assertRaises(AssertionError):disk([['a','b','e'],['e','b','c'],self.f[1]],self.b)
 def test_foreign_boundary_alias(self):
  with self.assertRaises(AssertionError):disk([self.f[0],['a','c','foreign']],self.b)
 def test_full_symbolic_missing_lining(self):
  d=json.loads((Path(__file__).parent/'complete-symbolic.json').read_text());faces=d['triangles'];E={}
  for t in faces:
   for a,b in zip(t,t[1:]+t[:1]):E.setdefault(tuple(sorted((a,b))),[]).append((a,b))
  b={e for e,rows in E.items()if len(rows)==1};disk(faces,b)
  bad=faces[:];bad.pop(next(i for i,o in enumerate(d['owners'])if o['kind']=='wet_lining'))
  with self.assertRaises(AssertionError):disk(bad,b)
if __name__=='__main__':unittest.main()
