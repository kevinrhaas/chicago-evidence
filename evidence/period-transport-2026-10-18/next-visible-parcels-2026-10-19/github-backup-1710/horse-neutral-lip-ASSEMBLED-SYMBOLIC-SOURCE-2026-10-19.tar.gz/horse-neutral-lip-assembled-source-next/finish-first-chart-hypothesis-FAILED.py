# SPDX-License-Identifier: CC0-1.0
"""Assemble complete symbolic mouth disk. No new horse XYZ buffers/export."""
import collections,json
from pathlib import Path
from fractions import Fraction as Q
from assemble import build,inner
from planar_complement import *
D=Path(__file__).parent;B=Path('/workspace/shared/horse-oral-channel-diagonal-candidate')
def finish():
 x=build();s=json.load(open(B/'candidate-one/head-source-surface.json'));im=json.load(open(D/'interface-map.json'));cm=json.load(open(D/'current-map.json'));T=x['triangles'];O=x['owners'];E=collections.defaultdict(list)
 for t in T:
  for a,b in zip(t,t[1:]+t[:1]):E[tuple(sorted((a,b)))].append((a,b))
 assert all(len(v)==1 or len(v)==2 and v[0]==v[1][::-1]for v in E.values())
 bd=[v[0]for v in E.values()if len(v)==1];assert len({a for a,b in bd})==len(bd);nxt=dict(bd);seen=set();loops=[]
 for a,b in bd:
  if a in seen:continue
  path=[];p=a
  while p not in seen:seen.add(p);path.append(p);p=nxt[p]
  assert p==a;loops.append(path)
 assert sorted(map(len,loops))==[14,14,66,102,118]
 extra={e['alias']:e for c in im['posterior_crescents']for e in c['station395_splits']}
 def oldpoint(label):
  if label.startswith('oral:'):return tuple(Q(str(v))for v in s['positions'][int(label[5:])])
  if label.startswith('station395:'):e=extra[label];a,b=e['edge'];t=Q(e['fraction'])
  elif label.startswith('plane420:'):a,b=map(int,label.split(':')[1:]);t=Q(cm['shared_cut_edge_knots'][str(a)+':'+str(b)]['fraction'])
  else:raise ValueError(label)
  return tuple(Q(str(s['positions'][a][k]))+t*(Q(str(s['positions'][b][k]))-Q(str(s['positions'][a][k])))for k in range(3))
 panels=[]
 for loop in loops:
  if all(k.startswith('h:')for k in loop):continue
  new=[k for k in loop if k.startswith('inner:')];assert new
  theta=[Q(k.split(':')[2])for k in new]
  front=any(k.startswith('plane420:')for k in loop)
  kind=('front_roof'if max(theta)==46 else'front_floor')if front else('left_crescent'if max(theta)<30 else'right_crescent')
  poly=[]
  for label in loop:
   if label.startswith('inner:'):
    z,th=map(Q,label.split(':')[1:]);u=((th-26)/20 if kind=='front_roof'else(th-28)/16)if front else((th-26)/2 if kind=='left_crescent'else(46-th)/2)
    if front:
     if th in[Q(26),Q(28)]:u=Q(0)
     if th in[Q(44),Q(46)]:u=Q(1)
    q=(u,z)if front else(z,u)
   else:
    X,Y,Z=oldpoint(label)
    if front:
     # Semantic sourcecorner aliases must be exact chart endpoints even when
     # original serialized X differs by a final floating arithmetic bit.
     endpoint=[k for k,v in x['equiv'].items()if v==label]
     if endpoint:
      th=Q(endpoint[0].split(':')[2]);u=Q(0)if th in[26,28]else Q(1)
     else:u=(X+Q('.045'))/Q('.09')
     q=(u,Z)
    else:q=(Z,(Q('-.185')-Y)/Q('.033'))
   poly.append(q)
  assert len(set(poly))==len(poly),(kind,'Distinct symbolic interface chart knots')
  simple(poly);lookup=dict(zip(poly,loop));tri=triangulate(poly);sign=area(poly)
  for t in tri:
   # Filling an actual directed boundary must use its OPPOSITE orientation.
   ids=[lookup[p]for p in t]
   if sign>0:ids.reverse()
   T.append(ids);O.append({'kind':kind,'chart_only':True})
  panels.append({'kind':kind,'directed_boundary_to_reverse':loop,'intrinsic_chart':[[str(v)for v in q]for q in poly],'triangles':len(tri)})
 E=collections.defaultdict(list);V=set();links=collections.defaultdict(list)
 for t in T:
  assert len(set(t))==3;V.update(t)
  for i in range(3):links[t[i]].append((t[(i+1)%3],t[(i+2)%3]))
  for a,b in zip(t,t[1:]+t[:1]):E[tuple(sorted((a,b)))].append((a,b))
 assert all(len(v)==1 or len(v)==2 and v[0]==v[1][::-1]for v in E.values()),'Complete source interface opposite incidence'
 boundary=[v[0]for v in E.values()if len(v)==1];assert len(boundary)==66 and all(a.startswith('h:')and b.startswith('h:')for a,b in boundary)
 assert len(V)-len(E)+len(T)==1,'Complete replacement disk Euler1'
 # Every vertex link is exactly one cycle (interior) or one interval(boundary).
 boundaryV={a for e in boundary for a in e}
 for v,rows in links.items():
  A=collections.defaultdict(set)
  for a,b in rows:A[a].add(b);A[b].add(a)
  todo=[next(iter(A))];seen=set()
  while todo:
   a=todo.pop()
   if a not in seen:seen.add(a);todo.extend(A[a]-seen)
  assert len(seen)==len(A),'Disconnected vertex link'
  degree=collections.Counter(map(len,A.values()));assert degree==({1:2,2:len(A)-2}if v in boundaryV else{2:len(A)}),('Nonmanifold vertex link',v,degree)
 # Face connectivity follows shared edge incidence.
 Fadj=collections.defaultdict(set);edgeF=collections.defaultdict(list)
 for i,t in enumerate(T):
  for a,b in zip(t,t[1:]+t[:1]):edgeF[tuple(sorted((a,b)))].append(i)
 for ids in edgeF.values():
  if len(ids)==2:Fadj[ids[0]].add(ids[1]);Fadj[ids[1]].add(ids[0])
 todo=[0];seen=set()
 while todo:
  a=todo.pop()
  if a not in seen:seen.add(a);todo.extend(Fadj[a]-seen)
 assert len(seen)==len(T)
 return{'status':'COMPLETE SYMBOLIC source-owned replacement disk ONLY; NO newXYZ horse surface/export','summary':{'V':len(V),'E':len(E),'F':len(T),'Euler':1,'connected':True,'boundary66':True,'all_internal_edges_opposite':True,'all_vertex_links_disk_manifold':True,'refined_cut_knots':len(x['K'])},'triangles':T,'owners':O,'panels':panels,'seam_equivalences':x['equiv'],'refined_cut_source_chart':[[str(v)for v in p]for p in x['K']],'physical_claim':'None; intrinsic charts establish source topology only; producer/storage/sourcecaller and actualXYZ/gear/bit checks remain mandatory.'}
if __name__=='__main__':print(json.dumps(finish(),indent=2))
