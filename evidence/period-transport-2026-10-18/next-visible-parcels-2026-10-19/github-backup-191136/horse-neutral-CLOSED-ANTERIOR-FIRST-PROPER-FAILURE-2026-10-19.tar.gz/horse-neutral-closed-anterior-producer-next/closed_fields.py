# SPDX-License-Identifier: GPL-3.0-or-later
"""Fixed proposed tissue field definitions only; no invocation at import.
SOURCE phase: no actual new horse points are evaluated before released trial.
"""
from fractions import Fraction as Q
import bisect
import numpy as np
from lip_variant import weights

def require(value,message):
 if not value:raise ValueError(message)
def smooth(t):
 t=max(0.,min(1.,t));return t*t*t*(10+t*(-15+6*t))
def blend_scalar(a,b,t):return (1-t)*a+t*b

def extend(old_resolve,ctx,bindings,sourceproof):
 A=ctx['assembly'];table={k:{Q(q):tag for q,tag in v['by_phase'].items()}for k,v in A['source_ring_parameters'].items()};cache={}
 def rail(side,q):
  rows=table[side];keys=sorted(rows)
  if q in rows:
   sourceproof['seal_rail:'+side+':'+str(q)]={'source_alias':rows[q],'fraction':'0'}
   return old_resolve(rows[q])
  i=bisect.bisect_left(keys,q);require(0<i<len(keys),'Declared nonwrapped rail interpolation');a,b=keys[i-1],keys[i];fraction=(q-a)/(b-a);sourceproof['seal_rail:'+side+':'+str(q)]={'source_aliases':[rows[a],rows[b]],'fraction':str(fraction)};t=float(fraction);va,vb=old_resolve(rows[a]),old_resolve(rows[b]);J,W=weights([(1-t,va[1],va[2]),(t,vb[1],vb[2])]);return blend_scalar(va[0],vb[0],t),J,W,None
 def crease(q):
  # Original reconstructed authoring dimensions, NOT measurements from Cuyer.
  knots=[(Q(0),[-.065,-.209,.420]),(Q(1,6),[-.065,-.209,.465]),(Q(1,3),[-.018,-.209,.532]),(Q(1,2),[0.,-.209,.535]),(Q(2,3),[.018,-.209,.532]),(Q(5,6),[.065,-.209,.465]),(Q(1),[.065,-.209,.420])]
  require(0<=q<=1,'Outer U phase');keys=[k for k,_ in knots];i=min(max(bisect.bisect_right(keys,q)-1,0),len(keys)-2);a,A=knots[i];b,B=knots[i+1];s=smooth(float((q-a)/(b-a)));point=blend_scalar(np.asarray(A),np.asarray(B),s)+np.asarray([0.,1.88,.8]);normal=np.asarray([-np.cos(np.pi*float(q)),0.,np.sin(np.pi*float(q))]);return point,normal
 def resolve(tag):
  if not tag.startswith('seal:'):return old_resolve(tag)
  if tag in cache:return cache[tag]
  _,row,phase=tag.split(':');r=int(row);q=Q(phase);require(r in[1,2,3],'Exactly three owned lip rings');t=r/4;upper,lower=rail('upper',q),rail('lower',q);J,W=weights([(1-t,upper[1],upper[2]),(t,lower[1],lower[2])])
  if 0<=q<=1:
   center,normal=crease(q)
   if r==1:pos=.5*(upper[0]+center)+np.asarray([0.,.003,0.])+.002*normal
   elif r==2:pos=center-.002*normal
   else:pos=.5*(lower[0]+center)+np.asarray([0.,-.003,0.])+.002*normal
   region='continuous_outer_lip_roll_and_recessed_seam'
  else:
   # Labial cavity wall is actual replacement tissue, not a black occluder.
   # Corner return endpoints share this same inner row; outer endpoint shares
   # the explicit outer roll, so the annulus is closed without duplicated seams.
   require(Q(11,10)<=q<=Q(21,10),'Declared inner U, no invented corner nodes');pos=blend_scalar(upper[0],lower[0],t);region='continuous_inner_labial_wall'
  require(np.isfinite(pos).all(),'Finite proposed tissue point');require(abs(sum(W)-1)<2e-6 and all(w>=0 for w in W),'Source skin weights');value=(pos,J,W,None);cache[tag]=value;sourceproof[tag]={'region':region,'fixed_ring':r,'phase':str(q),'upper_source_rail_receipt':'seal_rail:upper:'+str(q),'lower_source_rail_receipt':'seal_rail:lower:'+str(q),'recipe':'fixed closed-anterior tissue; original neutral apposed-lip approximation, no jaw-opening acceptance'};return value
 return resolve,bindings,sourceproof
