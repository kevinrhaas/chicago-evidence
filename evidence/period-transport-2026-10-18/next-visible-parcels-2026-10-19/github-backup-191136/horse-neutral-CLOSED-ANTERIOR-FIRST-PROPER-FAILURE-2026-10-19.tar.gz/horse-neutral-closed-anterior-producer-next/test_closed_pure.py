# SPDX-License-Identifier: CC0-1.0
"""Extract only scalar algebra, no actual crease/rail/horse field invocation."""
from pathlib import Path
import ast,json
p=Path(__file__).parent/'closed_fields.py';t=ast.parse(p.read_text());nodes=[n for n in t.body if isinstance(n,ast.FunctionDef)and n.name in['require','smooth','blend_scalar']];ns={};exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'<pure-scalars>','exec'),ns)
def check(v):
 if not v:raise RuntimeError('Scalar control failed')
check(set(ns)-{'__builtins__'}=={'require','smooth','blend_scalar'});check(ns['smooth'](-1)==0);check(ns['smooth'](2)==1);check(ns['smooth'](.5)==.5);check(ns['blend_scalar'](7,19,0)==7);check(ns['blend_scalar'](7,19,1)==19);check(ns['blend_scalar'](7,19,.5)==13)
try:ns['require'](False,'expected')
except ValueError:pass
else:raise RuntimeError('Require refusal disabled')
print(json.dumps({'PASS':True,'count':8,'scope':'Only scalar algebra; no proposed horse/crease/rail P/JW evaluation'}))
