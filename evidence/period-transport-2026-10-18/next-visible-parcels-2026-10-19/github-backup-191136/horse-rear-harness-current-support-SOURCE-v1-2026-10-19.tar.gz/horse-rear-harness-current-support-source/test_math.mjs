// SPDX-License-Identifier: GPL-3.0-or-later
// Analytic source controls only. No actual horse evaluation or candidate.
import assert from 'node:assert/strict';
import {convexHull,offsetPolygon,clipPolygon,pairedArc,emitStrip,clipClosedAtY} from './evaluate.mjs';
const square=[[-1,-1],[1,-1],[1,1],[-1,1]],near=(a,b)=>assert.ok(Math.abs(a-b)<1e-12);
assert.deepEqual(convexHull([...square,[0,0],[0,-1],[1,1]]),square);
const expanded=offsetPolygon(square,.25);assert.deepEqual(expanded,[[-1.25,-1.25],[1.25,-1.25],[1.25,1.25],[-1.25,1.25]]);
const clipped=clipPolygon([[0,0,0],[2,0,0],[0,2,0]],0,1,-1);
assert.deepEqual(clipped,[[0,0,0],[1,0,0],[1,1,0],[0,2,0]]);
const rear=pairedArc(square,.1,1,0,0,true,p=>p[1]<=0),top=pairedArc(square,.1,1,0,0,true,p=>p[1]>=0);
assert.deepEqual(rear.map(p=>p[0]),[[1,0],[1,-1],[-1,-1],[-1,0]]);
assert.deepEqual(top.map(p=>p[0]),[[1,0],[1,1],[-1,1],[-1,0]]);
assert.deepEqual(rear.map(p=>p[1]),[[1.1,0],[1.1,-1.1],[-1.1,-1.1],[-1.1,0]]);
const frame={origin:[0,0,0],a:[1,0,0],b:[0,0,1],width:[0,1,0]},strip=emitStrip(rear,frame,.2,'analytic');
assert.equal(strip.positions.length/9,28);assert.ok(strip.positions.every(Number.isFinite));
for(const v of strip.logicalVertices)near(Math.abs(v[1]),.1);
const edges=new Map();for(const f of strip.logicalFaces)for(let j=0;j<3;j++){const a=f[j],b=f[(j+1)%3],key=[Math.min(a,b),Math.max(a,b)].join(':');if(!edges.has(key))edges.set(key,[]);edges.get(key).push([a,b]);}
for(const uses of edges.values()){assert.equal(uses.length,2);assert.deepEqual(uses[0],uses[1].toReversed());}
assert.equal(strip.logicalVertices.length-edges.size+strip.logicalFaces.length,2);
assert.throws(()=>convexHull([[0,0],[1,0],[2,0]]),/Nondegenerate/);
assert.throws(()=>offsetPolygon(square,0),/Positive/);
assert.throws(()=>pairedArc(square,.1,1,2,0,true,()=>true),/Two transverse/);
const upright={origin:[0,0,0],a:[1,0,0],b:[0,1,0],width:[0,0,1]},vertical=emitStrip([[[1,-1],[1.1,-1]],[[1,1],[1.1,1]]],upright,.2,'analytic-cut');
const cut=clipClosedAtY(vertical,0);assert.ok(cut.logicalVertices.every(v=>v[1]>=0));assert.equal(cut.clipOwnership.boundary.length,8);assert.equal(cut.clipOwnership.outputVertexOwners.length,cut.logicalVertices.length);near(cut.centerlineLengthM,1);
const cutEdges=new Map();for(const f of cut.logicalFaces)for(let j=0;j<3;j++){const a=f[j],b=f[(j+1)%3],key=[Math.min(a,b),Math.max(a,b)].join(':');if(!cutEdges.has(key))cutEdges.set(key,[]);cutEdges.get(key).push([a,b]);}
for(const uses of cutEdges.values()){assert.equal(uses.length,2);assert.deepEqual(uses[0],uses[1].toReversed());}
assert.equal(cut.logicalVertices.length-cutEdges.size+cut.logicalFaces.length,2);
console.log(JSON.stringify({PASS:true,scope:'Analytic polygon clipping/offset/homotopy/closed-strip topology/owned plane-cap controls only; no actual horse or model emitted',controls:12}));
