# Independent dev28c53 → dev0d739 change-impact assessment

Read-only audit; root remains sole application writer. Incoming dev is exactly0d739a9ecc08b18d5e8f3e3dc700a83343cc4aba; prior base28c53c7ce638c06830e8ec0313472c557b573d02. Git diff has65paths over7commits. Full text diff and path/stat lists are saved alongside this report. Root was still resolving the no-commit merge when the incoming-only budget was calculated; a final branch --for-diff calculation remains pending.

## Actual runtime and asset impact

- `tree-model.js` and `trees.js` add position-seeded standing dead trees, fallen logs and grape/creeper geometry to1812/1835 river woods, update instancing returns, LOD/wind behavior and empty-leaf batch representation. These alter scene geometry, counts and drawing cost, with potential effects on boot, budgets, ground/vegetation checks, shadows and visible frames. Flora index/z05 record semantics and reach readings change with the implementation.
-1904 1625Prairie GLBs and both manifests change. K01 generators add side-slope hipped dormers, individually located side-wall windows and rear-door transom handling. Structure and sidecar records carry the new geometry/research.
-Glessner structure/sidecar parameters add the joined north-stack monogram; masonry generators produce its strokes. All20parts of the canonical ignored-GLB recovery package and its manifest change. The current ignored master/web/light GLBs were independently hashed and all three are stale versus this new package; preserve and materialize canonical package outputs before validation/publish.
-Source/LIBERTIES, compiled liberties, source-use indices, reference-view match records, jaunt data and compiled changelog change. Research/readings are also changed, including new Glessner north-finial and Keith loggia-pair rules. A new north-finial check enters `check.sh`; source writer/step-isolation inventories and flora/planting reach readers change. A normal full permitted preflight on the resolved tree is required.
-The stone occlusion NPZ encoded bytes differ; this audit does not claim pixel/numerical equivalence merely because file sizes are close.

## Exactly what stays unchanged

All26 old aedc qualification CODE paths are untouched by the incoming dev commits.18 are branch-only paths absent from both dev heads; the other8 are byte-identical in both dev heads. All26 merged-index versions matched their exact old aedc SHA256 pins during audit. In particular, smoke renderer/workflow, human workflow and canonical human/seated/bench producers/bindings remain unchanged. No incoming human GLB/body/master/wardrobe, vendor or transport-model paths occur in the65-path list. This is source-impact evidence, not a claim that the old CI run executed on the new merge head.

## Existing policy calculation and proposed next qualification

`tools/smoke_budget.mjs --for <the65 actual incoming paths>` exited0. It requires parts1–15, because assets/ and structure records are broad mapped dependencies and three changed reference_views match records are unmapped (unknown paths conservatively require all). Tool source SHA256225178926072a6e8c012c214142b484b24e0c0be3f0223194d74f24ad0fc18c4. Exact output is saved. The policy's printed foreground recipes split all parts under historical600s command estimates; this does not mandate a particular18-run GitHub grid.

Historical whole-body cost output has12desktop and6mobile parts without a direct reading. Its53m49 recorded total is incomplete, not proof of a fresh whole-body duration or compliance with the150min job timeout.

After root commits and pushes the resolved merge and completes fresh preflight/publish, calculate the actual final branch diff again. Subject to that result and required actual normal checks, prefer ONE explicit unfiltered full-smoke workflow dispatch for the new exact SHA (blank viewport and blank stage, therefore both viewports/all parts) rather than a duplicate18-cell manual dispatch set. Keep all ordinary required automatic checks. The full-smoke workflow push trigger matches only its own workflow path, unchanged from aedc to this merge, so a new automatic full smoke cannot simply be assumed. If a genuinely fresh mandatory automatic full is triggered, use it rather than dispatch a duplicate.

Canonical named-human producer inputs are unchanged. Old canonical bothtrue run and18 strict selected successes remain immutable historical exact-source evidence; no old run is relabelled to the new SHA. A new optional bothtrue canonical run is not automatically justified by the incoming world diff; ordinary required PR human checks and any actual changed human/browser dependency still need their normal qualification. Root should review this scope before any dispatch.

Old aedc qualification remains invalidated: actualdev advanced and PR1041 became dirty. Original selected result was18SUCCESS and one InstallPlaywright setupFAILURE before assertions. Reviewed once-only diagnostic caller stopped BEFORE POST on dev drift. Zero rerunPOSTs, zero recovery observer, zero final verifier execution, zero merge. No assertion/timeout/source waiver is proposed.
