# First fixed notch/loop trial: decoded interface orientation FAILED

Root released exactly one trial on reviewed inventoryd615d98e,callerecf985a1,validator584230a2. The supported-profile caller inheritedCPU1 and terminated exit1 after4.811428 seconds.

All three original actual negative stages PASS: closure,ten proper old panel/girth witnesses,and all184raw/168proper inherited stirrup crossings. The build emitted candidateae0b84fca50d135dbd0d54c002fb054759c4ea9ae2ccb41595197d7feb545858.

Decoded readback refused `Opposing actual material-side interface orientation`. The exact traceback and failed readback receipt are preserved. No decoded interface packet was accepted. Khronos,capture,self,interpart,wholehorse and browser stages were NOT RUN. No source correction,retry or additional candidate followed.

This is a failed source/geometry interface hypothesis,not an environment failure or accepted fit. A narrow read-only saved-output orientation diagnosis may identify which contact failed; it cannot supply missing qualification or waive the guard. No photographic,period visual,rider,motion,pressure or load acceptance follows.
