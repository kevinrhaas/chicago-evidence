# SPDX-License-Identifier: GPL-3.0-or-later
"""Analytic rectangular-prism checker positives and concrete corruptions only."""
from pathlib import Path
import copy,json,subprocess,tempfile
import numpy as np
from check_serialized import verify_clip,topology,dimensions,self_check
P=Path(__file__).resolve().parent
def refuses(call):
    try:call()
    except ValueError:return
    raise AssertionError('Analytic corrupt source must refuse')
with tempfile.TemporaryDirectory(prefix='current-support-source-canary-')as temporary:
    file=Path(temporary)/'analytic.json'
    subprocess.run(['node',str(P/'make_checker_fixture.mjs'),str(file)],check=True,timeout=10)
    source=json.loads(file.read_text());verify_clip(source);dimensions(source);t,edges=topology(source['faces'],source['verticesFloat32'])
    tri=np.array(source['verticesFloat32'])[np.array(source['faces'])]
    result=self_check('analytic',tri,source['faces'],edges,{})
    assert result['complete']and result['strict_proper']==result['unexpected_SAT']==0
    bad=copy.deepcopy(source);bad['faces']=bad['faces'][:-1];refuses(lambda:topology(bad['faces'],bad['verticesFloat32']))
    bad=copy.deepcopy(source);next(o for o in bad['clipOwnership']['outputVertexOwners']if o['kind']=='original_strip_vertex')['vertex']=10000;refuses(lambda:verify_clip(bad))
    bad=copy.deepcopy(source);bad['verticesFloat32'][0][0]+=.0001;refuses(lambda:verify_clip(bad))
    bad=copy.deepcopy(source);bad['clipOwnership']['outputFaceOwners']=bad['clipOwnership']['outputFaceOwners'][:-1];refuses(lambda:verify_clip(bad))
    bad=copy.deepcopy(source);bad['clipOwnership']['outputVertexOwners'][0]['unexpected']=True;refuses(lambda:verify_clip(bad))
print(json.dumps({'PASS':True,'scope':'Analytic prism complete source replay/dimensions/topology/self plus5corruptions; no horse, actual candidate, capture, browser or fit','controls':9}))
