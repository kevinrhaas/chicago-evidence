# Opt-in 1904 canonical composition source

This parcel supplies relocatable proposed application files for the shared1812/1904 canonical-builder integration owned by period_1812. Nothing is installed or committed. BPy/Blender has not been installed, imported or executed, and no canonical.blend or GLB exists from this parcel.

Proposed module: `tools/human_era_study_1904.py`.
Proposed manifest: `data/humans/recipes/era_studies/glessner_john_j_1904.json`.
Exact prepared body/garment JSON: `assets/authored/humans/era_studies/1904/`.

The module has no CLI/default route and never imports/modifies the1835 builder. `validate_inputs(root,manifest)` validates root-relative exact input bytes, scene1904-07-01, actual compiled John Glessner/person/household/source references, age61 within60–61, reconstructed appearance and standing/walking/passenger only. It returns `(body, garment, identity)` without BPy. It refuses a future/other-era resident, driver role, likeness upgrade, production flag or changed actual body/garment.

`compose(root,manifest,authoring_output)` requires a fresh empty authoring scene and a new explicit.blend output. It builds one56-joint rig from the verified body rest coordinates, checks actual parents/rest endpoints, and creates body and thirteen civilian garment objects. All meshes are identity roots with Armature modifiers targeting that single rig. Actual BPy compatibility is unverified. Return keys are rig,collection,body_objects,garment_objects,body,identity plus garment/contract/material map/winding list. No file is saved by this function.

The shared caller owns exact cleared skin and short04 hair, eyes, real morph targets, fourLOD collections, sockets, idle/walk actions, scene.chicago4d_human metadata, real integrator-assigned liberty, canonical.blend saving and the unchanged human_export.sh --master path. Required slot names skin/eyes are supplied by that caller; this module explicitly remaps original civilian garment material labels to garment_upper/garment_lower/footwear and optional garment_outer variants. It does not invent a garment source citation or a recorded Glessner outfit.

## Explicit source correction while composing

The earlier unaccepted garment parameterization produces inward triangle parity for left sleeve, right lapel, collar and both trouser legs. Original serialized arrays/hash remain immutable. The module reverses exactly those five owned parts at mesh creation, recorded by source_winding_reversed and the returned list. WINDING-ORIENTATION-CONTROL.json checks the original analytic construction radial/forward direction against actual stored triangle cross products. This is an aggregate construction-parity proof, not self-embedding, per-face fit, normal-field, material or photographic acceptance. No double-sided material hides the issue.

## Source execution evidence

A scratch root containing proposed exact assets and copied actual1904 source/identity/contract records passes import-safe validation:14,517 body vertices/26,756 body triangles plus5,408 garment triangles. Nine planted faults are refused. No BPy or model generation occurs in that validation. SOURCE-INPUT-CHECKS.json preserves the actual result and scratch location. The shared caller will perform its own strict overlay checks for both eras before any CI source release.

## Provenance/metadata requirements for shared caller

asset_id `glessner_john_j_1904_study`; kind body; depiction grade reconstructed; person reference glessner_john_j, scene1904, identity grade attested. The two actual household citations are identity-only and must never imply portrait-derived clothing/skin. Garment sources remain empty; every garment cut/dimension/color/material and human body/height/action is reconstructed. Skin/hair are cleared engineering inputs, not age-specific/complexion/likeness facts. Include body/garment source SHA256, material remap and winding corrections in provenance JSON. Actor production eligibility remains false until actual ordinary acceptance gates; successful mechanical export is insufficient.

No liberty number is reserved. Require integrator-supplied --liberty resolving a real existing heading after rebase. Root may append the suggested declaration below under its selected real ID.

Suggested liberty text: “John J.Glessner's attested1904 identity is depicted with an originally reconstructed age61/1.75m body within his year-only age60–61 bound and wholly conjectural civilian coat/waistcoat/shirt-front/collar/trousers/lowshoes. Existing cleared generic skin/short hair are engineering components, not a recovered individual complexion, hairstyle or likeness. Exact garment cuts, dimensions, materials, colors, layer combination, body proportions and demonstration standing/walking/passenger actions are unsupported reconstruction. No driver/rider assignment, personal outfit, source-matched photographic appearance or actual event is claimed. Mechanical canonical/export checks do not close anatomical, clothing fit, seated/walk deformation, normal/material, photographic or scene-production acceptance.”

## Proposed license additions

Both proposed JSON files under assets/authored/humans/era_studies/1904 are authored/prepared source inputs dedicated CC0-1.0. The mature body derives from existing verified MakeHuman CC0 graphical targets, and retains that source manifest/target recipe provenance; original new garments derive only from original parametric construction and source-body landmarks, with no historical image or third-party code copied. Python composition code is original GPL-3.0-or-later. Root must add exact per-file hashes/provenance to assets/LICENSES.md and normal authored-master notices when the actual canonical master is produced. The previous body/civilian archives remain the authoring evidence, not proof of finished tailoring.

No app registration, eligible_people entry, world placement, animation quality, force interaction or photo completion is supplied by this source-only parcel. Coarse unsewn garment seams, layer/body intersections, skin/hair/eye anatomy and deformation remain actual-image/fit work for canonical CI and subsequent review.

## Canonical-only footwear visibility correction v2

Stored source readback found original bare soles atY0 under shoe soles atY+6mm. This revision preserves both immutable original inputs and explicitly translates each shoe down6mm in the canonical composition. Shoe tops then lie atY115mm. It removes each source body triangle having any vertex below that shoe-top threshold, prunes unused body vertices and records exact retained/removed face indices plus both UV-split and graphical-source vertex maps. Actual source-only derivative readback leaves11,985 body vertices/22,308 body triangles, removes4,448 triangles and retains zero barefoot vertices below the mask. Garment shape/winding inputs remain unchanged in their original files. No pose, deformation, shoe/body collision, cloth clearance or2mm grounding acceptance is claimed.

The manifest now explicitly declares canonical_derivations, and validation refuses a missing/changed policy. The shared caller must use body_object_sources for masked body normal/source-index correspondence; body remains the full immutable original for hair fitting and provenance. garment_object_sources carries the canonical-only shoe-shifted parts; canonical_derivations contains exact ownership and shifts. New canonical output metadata must preserve these operations. The earlier v1 source/archive remain immutable; no original body or garment bytes were rewritten.
