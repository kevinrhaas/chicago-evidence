// SPDX-License-Identifier: GPL-3.0-or-later
// Pure current-pose geometry construction. No file/network/Three dependency.
// SOURCE ONLY until separately released for one actual candidate.
export const POLICY = Object.freeze({
  version: 'current-support-visual-2',
  horseSHA256: 'ab70aff958bc8a2780458d37212be1866c730817f485fbebbf53bd3c0e3931c3',
  parentGearSHA256: '3bb45abfad635bda74fd2aa999dcf869269e5efad1c888dfb4d615f7b0667825',
  coatIndexSHA256: '13488909c1efd7f165f589a903c07634b72c0a99241b2bfc2832275726ca2d32',
  coatFaces: 10724,
  innerAllowanceM: .008,
  breechingWidthM: .052,
  breechingThicknessM: .007,
  hipWidthM: .023,
  hipThicknessM: .004,
  breechingY: 1.0875,
  hipBottomY: 1.1135,
  frontCutZ: -.34,
  sourceFrontZMax: -.33,
  junctionZ: -.6560736953365729,
  hipTopDirection: [0, 1.525 - 1.1135, -.48 - (-.6560736953365729)],
  maximumRelativeVisualLengthChange: .02,
  maximumPartTriangles: 4096,
  acceptance: 'Reconstructed fitted visual deformation; NOT nonelastic leather, forces, complete hitch, or continuous collision'
});
const need = (v,m) => { if (!v) throw Error(m); };
const add=(a,b)=>a.map((v,i)=>v+b[i]), sub=(a,b)=>a.map((v,i)=>v-b[i]);
const mul=(a,s)=>a.map(v=>v*s), dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
const norm=a=>Math.hypot(...a), unit=a=>{let n=norm(a);need(n>1e-12&&Number.isFinite(n),'Degenerate unit frame');return mul(a,1/n);};
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const cross2=(a,b)=>a[0]*b[1]-a[1]*b[0];
const mix=(a,b,t)=>add(mul(a,1-t),mul(b,t));
const finite=a=>a.every(Number.isFinite);

export function clipPolygon(poly, axis, value, sign) {
  const out=[];
  for(let i=0;i<poly.length;i++) {
    const a=poly[i],b=poly[(i+1)%poly.length],u=sign*(a[axis]-value),v=sign*(b[axis]-value);
    if(u>=0)out.push(a);
    if(u*v<0)out.push(mix(a,b,u/(u-v)));
  }
  return out;
}
export function convexHull(points) {
  need(points.length>=3&&points.every(finite),'Finite nonempty hull source');
  const p=[...new Map(points.map(x=>[x.join(','),x])).values()].sort((a,b)=>a[0]-b[0]||a[1]-b[1]);
  const half=ps=>{const h=[];for(const q of ps){while(h.length>1&&cross2(sub(h.at(-1),h.at(-2)),sub(q,h.at(-1)))<=0)h.pop();h.push(q);}return h;};
  const lo=half(p),hi=half([...p].reverse()),h=[...lo.slice(0,-1),...hi.slice(0,-1)];
  need(h.length>=3,'Nondegenerate convex support');
  return h;
}
export function offsetPolygon(p,r) {
  need(r>0&&Number.isFinite(r),'Positive construction allowance');
  return p.map((q,i)=>{
    const a=unit(sub(q,p[(i+p.length-1)%p.length])),b=unit(sub(p[(i+1)%p.length],q));
    const na=[a[1],-a[0]],nb=[b[1],-b[0]],d=cross2(na,nb);
    need(Math.abs(d)>1e-14,'Degenerate offset support corner');
    const u=dot(na,q)+r,v=dot(nb,q)+r;
    const out=[(u*nb[1]-na[1]*v)/d,(na[0]*v-u*nb[0])/d];
    need(finite(out),'Finite offset support');return out;
  });
}

function projectSlab(triangles, frame, halfWidth, cut=null) {
  const points=[];let clipped=0;
  for(let fi=0;fi<triangles.length/9;fi++) {
    const t=[];
    for(let k=0;k<3;k++) {
      const p=sub(Array.from(triangles.subarray(fi*9+k*3,fi*9+k*3+3)),frame.origin);
      t.push([dot(p,frame.a),dot(p,frame.b),dot(p,frame.width)]);
    }
    let poly=clipPolygon(t,2,-halfWidth,1);
    poly=clipPolygon(poly,2,halfWidth,-1);
    if(cut)poly=clipPolygon(poly,cut.axis,cut.value,cut.sign);
    if(poly.length){clipped++;for(const p of poly)points.push(p.slice(0,2));}
  }
  need(clipped>0,'Nonempty complete full-width current coat slab');
  return {hull:convexHull(points),clippedSourceFaces:clipped};
}

function intersections(poly,axis,value) {
  const hits=[];
  for(let i=0;i<poly.length;i++) {
    const a=poly[i],b=poly[(i+1)%poly.length],u=a[axis]-value,v=b[axis]-value;
    if(u===0)hits.push({point:a,edge:i,t:0});
    if(u*v<0){const t=u/(u-v);hits.push({point:mix(a,b,t),edge:i,t});}
  }
  const unique=[...new Map(hits.map(h=>[h.point.join(','),h])).values()];
  need(unique.length===2,'Two transverse support/cut intersections');
  return unique;
}
function rightAt(poly,y){return intersections(poly,1,y).sort((a,b)=>b.point[0]-a.point[0])[0].point[0];}
function leftAt(poly,y){return intersections(poly,1,y).sort((a,b)=>a.point[0]-b.point[0])[0].point[0];}

// A support edge has a corresponding outward-offset edge. Keep their exact
// pairing at cuts; independently clipping and resampling two loops is forbidden.
function pointOnParallelEdge(poly,outer,edge,axis,value) {
  const a=poly[edge],b=poly[(edge+1)%poly.length],den=b[axis]-a[axis];
  need(Math.abs(den)>1e-14,'Transverse offset edge at cut');
  const t=(value-a[axis])/den;need(t>=-1e-10&&t<=1+1e-10,'Matching outer support cut');
  return mix(outer[edge],outer[(edge+1)%outer.length],t);
}

function insertPairAt(pairs,point) {
  if(pairs.some(p=>norm(sub(p[0],point))<1e-12))return;
  for(let i=0;i<pairs.length-1;i++) {
    const a=pairs[i][0],b=pairs[i+1][0],d=sub(b,a),t=dot(sub(point,a),d)/dot(d,d);
    if(t>0&&t<1&&norm(sub(mix(a,b,t),point))<1e-12) {
      pairs.splice(i+1,0,[point,mix(pairs[i][1],pairs[i+1][1],t)]);return;
    }
  }
  throw Error('Shared junction is not on the actual support arc');
}
export function pairedArc(poly,thickness,axis,cut,sortAxis,descending,keepPoint) {
  const outer=offsetPolygon(poly,thickness),ends=intersections(poly,axis,cut).sort((a,b)=>(descending?-1:1)*(a.point[sortAxis]-b.point[sortAxis]));
  const [a,b]=ends;
  function walk(step){
    const pairs=[[a.point,pointOnParallelEdge(poly,outer,a.edge,axis,cut)]];
    let i=step===1?(a.edge+1)%poly.length:a.edge,stop=step===1?b.edge:(b.edge+1)%poly.length;
    for(let guard=0;guard<=poly.length;guard++) {
      if(i===stop){pairs.push([poly[i],outer[i]]);break;}
      pairs.push([poly[i],outer[i]]);i=(i+step+poly.length)%poly.length;
      need(guard<poly.length,'Finite support arc traversal');
    }
    pairs.push([b.point,pointOnParallelEdge(poly,outer,b.edge,axis,cut)]);
    return pairs.filter((p,i,all)=>i===0||norm(sub(p[0],all[i-1][0]))>1e-12);
  }
  const paths=[walk(1),walk(-1)].filter(p=>p.slice(1,-1).every(q=>keepPoint(q[0])));
  need(paths.length===1,'Unique declared support homotopy');return paths[0];
}

function finalizeMesh(vertices,faces,{name,width,frame,length,centerline,clipOwnership=null}) {
  const positions=new Float32Array(faces.length*9),normals=new Float32Array(positions.length);
  const signedVolume=faces.reduce((s,f)=>s+dot(vertices[f[0]],cross(vertices[f[1]],vertices[f[2]]))/6,0);
  need(Number.isFinite(signedVolume)&&Math.abs(signedVolume)>1e-12,'Nonzero closed strip volume');
  for(let i=0;i<faces.length;i++) {
    const f=signedVolume>0?faces[i]:[faces[i][0],faces[i][2],faces[i][1]];
    for(let j=0;j<3;j++)positions.set(vertices[f[j]],i*9+j*3);
    const a=Array.from(positions.subarray(i*9,i*9+3)),b=Array.from(positions.subarray(i*9+3,i*9+6)),c=Array.from(positions.subarray(i*9+6,i*9+9));
    const n=unit(cross(sub(b,a),sub(c,a)));for(let j=0;j<3;j++)normals.set(n,i*9+j*3);
  }
  need(faces.length<=POLICY.maximumPartTriangles,'Declared per-part triangle budget');
  return {name,positions,normals,logicalVertices:vertices,logicalFaces:signedVolume>0?faces:faces.map(f=>[f[0],f[2],f[1]]),centerlineLengthM:length,centerlineRootM:centerline,widthM:width,constructionFrame:frame,clipOwnership};
}

export function emitStrip(pairs,frame,width,name) {
  need(pairs.length>=2,'Nonempty strip');const vertices=[];
  for(const [inside,outside] of pairs) {
    const point=(q,s)=>add(frame.origin,add(mul(frame.a,q[0]),add(mul(frame.b,q[1]),mul(frame.width,s*width/2))));
    vertices.push(point(inside,-1),point(inside,1),point(outside,1),point(outside,-1));
  }
  const faces=[];
  for(let j=0;j<pairs.length-1;j++)for(let k=0;k<4;k++){let a=j*4+k,b=j*4+(k+1)%4;faces.push([a,b,b+4],[a,b+4,a+4]);}
  faces.push([0,2,1],[0,3,2]);let k=vertices.length-4;faces.push([k,k+1,k+2],[k,k+2,k+3]);
  const centers=pairs.map(([a,b])=>mix(a,b,.5));
  const length=centers.slice(1).reduce((s,p,i)=>s+norm(sub(p,centers[i])),0);
  const centerline=centers.map(p=>add(frame.origin,add(mul(frame.a,p[0]),mul(frame.b,p[1]))));
  return {...finalizeMesh(vertices,faces,{name,width,frame,length,centerline}),rings:pairs.length};
}

export function clipClosedAtY(part,y) {
  const input=part.logicalVertices,vertices=[],owners=[],faces=[],faceOwners=[],map=new Map(),cuts=new Map();
  const old=i=>{if(!map.has(i)){map.set(i,vertices.length);vertices.push(input[i]);owners.push({kind:'original_strip_vertex',vertex:i});}return map.get(i);};
  const edge=(a,b)=>{
    const lo=Math.min(a,b),hi=Math.max(a,b),key=lo+':'+hi;
    if(!cuts.has(key)){const u=input[lo][1]-y,v=input[hi][1]-y;need(u*v<0,'Strict source plane-edge crossing');const t=u/(u-v),p=mix(input[lo],input[hi],t);p[1]=y;cuts.set(key,vertices.length);vertices.push(p);owners.push({kind:'canonical_source_edge_plane_intersection',edge:[lo,hi],t,axis:1,value:y});}
    return cuts.get(key);
  };
  for(let fi=0;fi<part.logicalFaces.length;fi++){
    const f=part.logicalFaces[fi],poly=[];
    for(let j=0;j<3;j++){const a=f[j],b=f[(j+1)%3],u=input[a][1]-y,v=input[b][1]-y;if(u>=0)poly.push(old(a));if(u*v<0)poly.push(edge(a,b));}
    for(let j=1;j<poly.length-1;j++){faces.push([poly[0],poly[j],poly[j+1]]);faceOwners.push({kind:'clipped_original_strip_face',face:fi});}
  }
  const edges=new Map();for(const f of faces)for(let j=0;j<3;j++){const a=f[j],b=f[(j+1)%3],key=[Math.min(a,b),Math.max(a,b)].join(':');if(!edges.has(key))edges.set(key,[]);edges.get(key).push([a,b]);}
  const boundary=[...edges.values()].filter(x=>x.length===1).map(x=>x[0]);need(boundary.length>=3,'One nonempty source clipping cap');
  const next=new Map();for(const [a,b] of boundary){need(vertices[a][1]===y&&vertices[b][1]===y&&!next.has(a),'Exact owned plane boundary');next.set(a,b);}
  const loop=[Math.min(...next.keys())];while(next.get(loop.at(-1))!==loop[0]){const n=next.get(loop.at(-1));need(n!==undefined&&!loop.includes(n)&&loop.length<boundary.length,'One simple owned plane boundary cycle');loop.push(n);}need(loop.length===boundary.length,'No hidden extra clipping boundary');
  const center=loop.reduce((s,i)=>add(s,vertices[i]),[0,0,0]).map(v=>v/loop.length);center[1]=y;const ci=vertices.length;vertices.push(center);owners.push({kind:'owned_plane_cap_center',boundary:loop});
  for(const [a,b] of boundary){faces.push([ci,b,a]);faceOwners.push({kind:'owned_plane_cap_face',boundaryEdge:[a,b],center:ci});}
  const centerline=[];
  for(let i=0;i<part.centerlineRootM.length;i++){
    const a=part.centerlineRootM[i];if(i){const b=part.centerlineRootM[i-1];if((a[1]-y)*(b[1]-y)<0){const p=mix(b,a,(y-b[1])/(a[1]-b[1]));p[1]=y;centerline.push(p);}}
    if(a[1]>=y)centerline.push(a);
  }
  need(centerline.length>=2&&centerline[0][1]===y&&centerline.slice(1).every(p=>p[1]>y),'One clipped nominal material centerline');
  const length=centerline.slice(1).reduce((s,p,i)=>s+norm(sub(p,centerline[i])),0);
  return {...finalizeMesh(vertices,faces,{name:part.name,width:part.widthM,frame:part.constructionFrame,length,centerline,clipOwnership:{axis:1,value:y,inputVerticesRootM:input,inputFaces:part.logicalFaces,outputVertexOwners:owners,outputFaceOwners:faceOwners,boundary:loop,capCenter:ci}}),rings:part.rings};
}

export function evaluateCurrentSupport({coatRootTriangles,identity,referenceLengths=null,scope='idle-study'}) {
  need(coatRootTriangles instanceof Float64Array&&coatRootTriangles.length===POLICY.coatFaces*9,'Complete actual Float64 coat triangles');
  need(coatRootTriangles.every(Number.isFinite),'Finite actual current coat');
  need(identity?.horseSHA256===POLICY.horseSHA256&&identity?.coatIndexSHA256===POLICY.coatIndexSHA256,'Actual source identity');
  need(identity?.clip&&Number.isFinite(identity.timeS)&&Number.isFinite(identity.phase)&&identity.phase>=0&&identity.phase<=1,'Explicit actual pose identity');
  need(scope==='idle-study'||scope==='conditional-motion','Explicit acceptance scope');
  if(scope==='idle-study')need(identity.clip==='idle'&&identity.timeS===0&&identity.phase===0,'First target exact idle0 only');
  const rearFrame={origin:[0,POLICY.breechingY,0],a:[1,0,0],b:[0,0,1],width:[0,1,0]};
  const rear=projectSlab(coatRootTriangles,rearFrame,POLICY.breechingWidthM/2,{axis:1,value:POLICY.sourceFrontZMax,sign:-1});
  let rearInner=offsetPolygon(rear.hull,POLICY.innerAllowanceM);
  const u=unit(POLICY.hipTopDirection),hipFrame={origin:[0,POLICY.hipBottomY,POLICY.junctionZ],a:[1,0,0],b:u,width:[0,-u[2],u[1]]};
  const hip=projectSlab(coatRootTriangles,hipFrame,POLICY.hipWidthM/2);
  let hipInner=offsetPolygon(hip.hull,POLICY.innerAllowanceM);
  // One shared junction authority: maximum full-width current support required
  // by either construction. This is geometric union, never offset tuning.
  // Extend a vertical support stem through the exact oblique-width cap range.
  // Fixed source formula, not an offset/radius fit search. A horizontal cut
  // terminates the hips on top of the breeching instead of through its volume.
  const stemHalfU=POLICY.hipWidthM/2*Math.abs(hipFrame.width[1])/u[1]+2*POLICY.hipThicknessM;
  // The complete current hip hull extrema make the inserted stem globally
  // extreme. A local cap interval maximum can be undercut by convexification;
  // its analytic counterexample is preserved with the rejected v1 source.
  const joins={l:Math.max(rightAt(rearInner,POLICY.junctionZ),...hipInner.map(p=>p[0])),r:Math.min(leftAt(rearInner,POLICY.junctionZ),...hipInner.map(p=>p[0]))};
  need(joins.l>0&&joins.r<0,'Bilateral current support junctions');
  rearInner=convexHull([...rearInner,[joins.l,POLICY.junctionZ],[joins.r,POLICY.junctionZ]]);
  hipInner=convexHull([...hipInner,...[-stemHalfU,stemHalfU].flatMap(v=>[[joins.l,v],[joins.r,v]])]);
  const rearPairs=pairedArc(rearInner,POLICY.breechingThicknessM,1,POLICY.frontCutZ,0,true,p=>p[1]<=POLICY.frontCutZ+1e-12);
  // Include each exact inner junction on its support edge; matching outer
  // point is derived from that same edge, not an independent socket estimate.
  for(const x of [joins.l,joins.r])insertPairAt(rearPairs,[x,POLICY.junctionZ]);
  const hipFull=pairedArc(hipInner,POLICY.hipThicknessM,1,-stemHalfU,0,true,p=>p[1]>=-stemHalfU-1e-12);
  // Split the over-croup arc at X0. Side meshes get coincident, opposite caps.
  const top=intersections(hipInner,0,0).sort((a,b)=>b.point[1]-a.point[1])[0].point;
  insertPairAt(hipFull,top);const topIndex=hipFull.findIndex(p=>p[0]===top||norm(sub(p[0],top))<1e-12);
  need(topIndex>0&&topIndex<hipFull.length-1,'Two visible hip support halves');
  const right=hipFull.slice(0,topIndex+1),left=hipFull.slice(topIndex).reverse();
  const parts=[emitStrip(rearPairs,rearFrame,POLICY.breechingWidthM,'breeching'),clipClosedAtY(emitStrip(right,hipFrame,POLICY.hipWidthM,'hip_support_l'),POLICY.hipBottomY),clipClosedAtY(emitStrip(left,hipFrame,POLICY.hipWidthM,'hip_support_r'),POLICY.hipBottomY)];
  need(parts[0].logicalVertices.every(v=>v[2]<=POLICY.sourceFrontZMax),'Rear emitted full surface remains in actual source corridor');
  const junctions={};
  for(const [side,x]of Object.entries(joins)){
    const point=[x,POLICY.hipBottomY,POLICY.junctionZ].map(Math.fround),rearVertices=parts[0].logicalVertices.map(v=>v.map(Math.fround));
    const rearVertex=rearVertices.findIndex((v,i)=>i%4===1&&v.every((n,k)=>n===point[k]));
    need(rearVertex>=0,'Actual Float32 rear inner-top vertex owns visual junction');
    const hipPart=parts.find(p=>p.name==='hip_support_'+side),hipVertices=hipPart.logicalVertices.map(v=>v.map(Math.fround)),loop=hipPart.clipOwnership.boundary;
    const ownedEdges=loop.map((a,i)=>[a,loop[(i+1)%loop.length]]).filter(([a,b])=>{
      const u=hipVertices[a],v=hipVertices[b];return u[0]===point[0]&&v[0]===point[0]&&u[1]===point[1]&&v[1]===point[1]&&u[2]!==v[2]&&point[2]>=Math.min(u[2],v[2])&&point[2]<=Math.max(u[2],v[2]);
    });
    need(ownedEdges.length>0,'Actual Float32 owned hip cap boundary contains visual junction');
    junctions[side]={innerPointRootM:point,rearLogicalVertex:rearVertex,hipCapBoundaryEdge:ownedEdges[0],terminationPlaneY:POLICY.hipBottomY,
      semantics:'Exact Float32 visual point on rear source vertex and hip source cap edge; not shared-vertex material ownership, force, or vehicle hardware'};
  }
  const lengths=Object.fromEntries(parts.map(p=>[p.name,p.centerlineLengthM]));
  const relativeChanges=referenceLengths?Object.fromEntries(parts.map(p=>{const r=referenceLengths[p.name];need(Number.isFinite(r)&&r>0,'Immutable positive idle reference length');return[p.name,p.centerlineLengthM/r-1];})):null;
  if(scope==='conditional-motion')need(relativeChanges&&Object.values(relativeChanges).every(x=>Math.abs(x)<=POLICY.maximumRelativeVisualLengthChange),'Visual length-change budget exceeded; motion refused');
  return {parts,identity,policy:POLICY,lengths,relativeChanges,
    junctions,
    sourceCoverage:{rearClippedFaces:rear.clippedSourceFaces,hipClippedFaces:hip.clippedSourceFaces,coatFaces:POLICY.coatFaces},
    limits:['Three changed parts only;33 protected parts remain visible','Front breeching ends unbound','Girth float and unbound traces/reins unchanged','No leather physics, pressure, pulling, continuous collision or photographic acceptance']};
}
