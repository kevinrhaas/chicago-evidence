#!/usr/bin/env python3
"""Source-only exact-one diagnostic whole-workflow rerun. No request without --execute."""
import argparse,datetime,hashlib,importlib.util,json,pathlib,subprocess,time,sys
S=pathlib.Path('/workspace/shared');ROOT=pathlib.Path('/workspace/chicago');SHA='aedc80126c6178376d3fb60f40297bec5c7c9ec7';TREE='ead21d9876d3983f9f02217835a100b09ac49ada';RID=39289140294;JID=118184901931;BRANCH='steward/period-transport-2793';REPO='kevinrhaas/chicago';V=S/'verify_normal_dev_gates_v8_aedc80126.py';VHASH='87ad8568b3e4704a125122160f68d6686b5a7f51facdb71a8e50aca8cbc0b5e9'
def need(c,m):
 if not c:raise ValueError(m)
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def exact_failure(run,data):
 need(run['id']==RID and run['head_sha']==SHA and run['head_branch']==BRANCH and run['event']=='workflow_dispatch' and run['path']=='.github/workflows/chicago-4d-smoke.yml' and run['run_attempt']==1 and run['status']=='completed' and run['conclusion']=='failure','original failed run identity drift')
 need(data['total_count']==len(data['jobs'])==1,'unexpected failed job count');j=data['jobs'][0]
 need(j['id']==JID and j['run_id']==RID and j['head_sha']==SHA and j['run_attempt']==1 and j['name']=='smoke' and j['status']=='completed' and j['conclusion']=='failure','original failed job identity drift')
 for step in j['steps']:
  n=step['name'];want='failure' if n=='Install Playwright' else 'skipped' if n in ['Publish the mirror the smoke serves (site/4d/ is generated)','Run the smoke against the published mirror','Post Run actions/setup-node@v4'] else 'success'
  need(step['status']=='completed' and step['conclusion']==want,'original failed step pattern drift '+n)
 for name in ['Install Playwright','Publish the mirror the smoke serves (site/4d/ is generated)','Run the smoke against the published mirror']:need(sum(x['name']==name for x in j['steps'])==1,'missing/duplicate failure context step')
def original_set_ok(observer,latest,jobs,v):
 need('finished_utc'in observer and observer.get('all_19_selected_runs_terminal')is True and not observer.get('error'),'original observer not naturally terminal')
 need(observer.get('stop_reason')=='all selected workflow runs terminal; metadata only','original observer stop reason changed')
 ds=json.loads((S/'transport-smoke-dispatch-c02-aedc80126.json').read_text());can=json.loads((S/'human-seated-dispatch-aedc80126.json').read_text());ids={x['id']for x in ds['discovered_runs']}|{can['runs'][0]['id']};need(len(ids)==19 and {x['id']for x in latest['runs']}==ids,'original exact19 identities changed')
 for r in latest['runs']:
  need(r['head_sha']==SHA and r['head_branch']==BRANCH and r['run_attempt']==1 and r['status']=='completed','original run identity/nonterminal')
  if r['id']==RID:need(r['conclusion']=='failure','original target no longer failed')
  else:
   need(r['conclusion']=='success','additional selected failure: STOP');record=jobs[str(r['id'])];need(record['attempt']==1 and record['head_sha']==SHA,'original successful record identity mismatch');v.jobs_ok(record['jobs'],r['id'],{'humans':v.HUMAN_STEPS,'teamster-studies':v.TEAM_STEPS}if r['id']==can['runs'][0]['id']else{'smoke':v.SMOKE_STEPS})
def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');a.add_argument('--original-observer',type=pathlib.Path,default=S/'final-aedc80126-resumed-metadata');a.add_argument('--out',type=pathlib.Path,required=True);x=a.parse_args()
 if not x.execute:print(json.dumps({'execute':False,'run':RID,'attempt_from':1,'attempt_to':2,'endpoint':'repos/'+REPO+'/actions/runs/'+str(RID)+'/rerun','no_retry':True,'scope':'one unchanged diagnostic rerun, no transient-cause claim'},indent=2));return 0
 need(datetime.datetime.now(datetime.timezone.utc)<datetime.datetime(2026,10,19,19,52,15,tzinfo=datetime.timezone.utc),'original observation deadline expired; stop')
 need(hashlib.sha256(V.read_bytes()).hexdigest()==VHASH,'reviewed v8 source changed');sp=importlib.util.spec_from_file_location('v8',V);v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
 original_set_ok(v.load(x.original_observer/'observer.json'),v.load(x.original_observer/'latest.json'),v.load(x.original_observer/'terminal-jobs.json'),v)
 need(subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()==SHA and subprocess.check_output(['git','-C',str(ROOT),'rev-parse',SHA+'^{tree}'],text=True).strip()==TREE,'local app source drift');need(not subprocess.check_output(['git','-C',str(ROOT),'status','--porcelain=v1'],text=True).strip(),'app is dirty');v.source_ok({p:v.committed(p)for p in v.PINS})
 out=x.out.resolve();need(out.is_relative_to(S),'outside evidence path required');out.mkdir(exist_ok=False);(S/'aedc80126-smoke39289140294-once-only-rerun.lock').mkdir(exist_ok=False);deadline=time.monotonic()+min(45,(datetime.datetime(2026,10,19,19,52,15,tzinfo=datetime.timezone.utc)-datetime.datetime.now(datetime.timezone.utc)).total_seconds());receipt={'run_id':RID,'head_sha':SHA,'branch':BRANCH,'expected_attempt':2,'post_succeeded':False,'post_attempted':False,'unknown_cause':True,'source_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()};save(out/'intent.json',receipt)
 def remaining():
  left=deadline-time.monotonic();need(left>0,'45s/original absolute deadline reached; no request');return left
 def get(name,path):
  r=subprocess.run(['gh','api','--hostname','github.com','--method','GET','repos/'+REPO+'/'+path],capture_output=True,text=True,timeout=remaining());(out/(name+'.stdout.json')).write_text(r.stdout);(out/(name+'.stderr.txt')).write_text(r.stderr);need(r.returncode==0,'GET failed; no retry '+name);return json.loads(r.stdout)
 try:
  run=get('run-before','actions/runs/'+str(RID));jobs=get('jobs-before','actions/runs/'+str(RID)+'/attempts/1/jobs?per_page=100');exact_failure(run,jobs)
  pr=get('pr-before','pulls/1041');ref=get('branch-before','git/ref/heads/'+BRANCH);dev=get('dev-before','git/ref/heads/dev')
  need(pr['state']=='open' and pr['head']['sha']==SHA and pr['head']['ref']==BRANCH and pr['head']['repo']['full_name']==REPO and pr['base']['ref']=='dev' and pr['base']['sha']=='28c53c7ce638c06830e8ec0313472c557b573d02' and ref['object']['sha']==SHA and dev['object']['sha']==pr['base']['sha'],'remote PR/head/base drift')
  remaining();receipt['post_attempted']=True;save(out/'receipt.json',receipt)
  r=subprocess.run(['gh','api','--hostname','github.com','--method','POST','repos/'+REPO+'/actions/runs/'+str(RID)+'/rerun'],capture_output=True,text=True,timeout=remaining());(out/'post.stdout.txt').write_text(r.stdout);(out/'post.stderr.txt').write_text(r.stderr);receipt['returncode']=r.returncode;receipt['post_succeeded']=r.returncode==0;need(r.returncode==0,'POST failure or ambiguity; no retry')
 except Exception as e:receipt['error']=str(e)
 finally:receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(out/'receipt.json',receipt);print(json.dumps(receipt,indent=2))
 return 0 if receipt['post_succeeded']else 1
if __name__=='__main__':sys.exit(main())
