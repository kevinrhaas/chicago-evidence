import pathlib,importlib.util,json,copy,hashlib
S=pathlib.Path('/workspace/shared')
def module(name,p):
 sp=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
c=module('caller',S/'rerun_one_failed_smoke_aedc80126_SOURCE_ONLY.py');v=module('v8',S/'verify_normal_dev_gates_v8_aedc80126.py');v9=module('v9',S/'verify_normal_dev_gates_v9_aedc80126_RECOVERY_PENDING.py');w=module('watch',S/'watch_transport_metadata_aedc80126_one_recovery_SOURCE_ONLY.py');results=[]
def test(name,fn,want):
 try:fn();ok=True
 except Exception:ok=False
 results.append({'name':name,'expected_accept':want,'actual_accept':ok,'PASS':want==ok})
run=json.loads((S/'final-aedc80126-resumed-metadata/latest.json').read_text());failed=next(r for r in run['runs']if r['id']==c.RID);raw=json.loads((S/'final-aedc80126-resumed-metadata/metadata-responses/000016.json').read_text())['data'];test('actual original setup failure signature',lambda:c.exact_failure(failed,raw),True)
x=copy.deepcopy(raw);x['jobs'][0]['steps'][5]['conclusion']='failure';test('application smoke failure cannot substitute setup failure',lambda:c.exact_failure(failed,x),False)
x=copy.deepcopy(failed);x['run_attempt']=2;test('attempt2 cannot trigger second rerun',lambda:c.exact_failure(x,raw),False)
x=copy.deepcopy(raw);x['jobs'][0]['id']+=1;test('different failed job identity refused',lambda:c.exact_failure(failed,x),False)
# Entirely synthetic completed qualification records for testing the future caller guard only.
latest=copy.deepcopy(run);jobs={}
for r in latest['runs']:
 r['status']='completed';r['conclusion']='failure'if r['id']==c.RID else'success'
 if r['id']==c.RID:continue
 names={'humans':v.HUMAN_STEPS,'teamster-studies':v.TEAM_STEPS}if r['id']==39289017835 else{'smoke':v.SMOKE_STEPS}
 jobs[str(r['id'])]={'attempt':1,'head_sha':c.SHA,'jobs':[{'id':r['id']*10+i,'run_id':r['id'],'head_sha':c.SHA,'run_attempt':1,'name':n,'status':'completed','conclusion':'success','steps':[{'name':s,'status':'completed','conclusion':'success'}for s in steps]}for i,(n,steps)in enumerate(names.items())]}
obs={'finished_utc':'synthetic','all_19_selected_runs_terminal':True,'stop_reason':'all selected workflow runs terminal; metadata only'};test('synthetic exactly18 coherent success plus one exact failure',lambda:c.original_set_ok(obs,latest,jobs,v),True)
x=copy.deepcopy(latest);next(r for r in x['runs']if r['id']!=c.RID)['conclusion']='failure';test('additional selected failure stops plan',lambda:c.original_set_ok(obs,x,jobs,v),False)
x=copy.deepcopy(obs);x.pop('finished_utc');test('running original observer cannot be interrupted',lambda:c.original_set_ok(x,latest,jobs,v),False)
x=copy.deepcopy(jobs);k=next(iter(x));x[k]['jobs'][0]['steps'][0]['conclusion']='skipped';test('success parent with skipped mandatory step refused',lambda:c.original_set_ok(obs,latest,x,v),False)
test('source pins unchanged',lambda:v9.source_ok({p:v9.committed(p)for p in v9.PINS}),True)
test('v9 target attempt1 rejected',lambda:v9.run_ok(dict(failed,conclusion='success'),v9.SMOKE),False)
test('v9 target attempt2 accepted at identity gate only',lambda:v9.run_ok(dict(failed,conclusion='success',run_attempt=2),v9.SMOKE),True)
other=next(r for r in latest['runs']if r['id']not in [c.RID,39289017835]);test('v9 other leg attempt1 stays accepted',lambda:v9.run_ok(other,v9.SMOKE),True)
test('v9 other leg attempt2 refused',lambda:v9.run_ok(dict(other,run_attempt=2),v9.SMOKE),False)
test('v9 disabled until new actual job IDs bound',lambda:v9.jobs_ok([dict(jobs[str(other['id'])]['jobs'][0],run_id=c.RID,run_attempt=2)],c.RID,{'smoke':v9.SMOKE_STEPS}),False)
report={'scope':'OFFLINE pure guards; synthetic future success records explicitly labelled. No GET, POST, observer process, geometry, CI qualification or verifier main executed','controls':results,'PASS':all(r['PASS']for r in results),'hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in [S/'rerun_one_failed_smoke_aedc80126_SOURCE_ONLY.py',S/'verify_normal_dev_gates_v9_aedc80126_RECOVERY_PENDING.py',S/'watch_transport_metadata_aedc80126_one_recovery_SOURCE_ONLY.py']}};(S/'aedc80126-one-recovery-source-controls.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));assert report['PASS']
