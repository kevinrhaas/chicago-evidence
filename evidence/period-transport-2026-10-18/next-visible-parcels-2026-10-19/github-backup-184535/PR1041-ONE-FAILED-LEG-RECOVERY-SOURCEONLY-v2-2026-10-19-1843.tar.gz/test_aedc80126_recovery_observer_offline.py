import pathlib,importlib.util,json,copy,tempfile,unittest.mock as mock,contextlib,io
S=pathlib.Path('/workspace/shared');p=S/'watch_transport_metadata_aedc80126_one_recovery_SOURCE_ONLY.py';sp=importlib.util.spec_from_file_location('w',p);w=importlib.util.module_from_spec(sp);sp.loader.exec_module(w)
sha='aedc80126c6178376d3fb60f40297bec5c7c9ec7';target=39289140294;d=json.loads((S/'transport-smoke-dispatch-c02-aedc80126.json').read_text());c=json.loads((S/'human-seated-dispatch-aedc80126.json').read_text());actual=json.loads((S/'final-aedc80126-resumed-metadata/latest.json').read_text());initial=copy.deepcopy(actual)
for r in initial['runs']:r.update(status='completed',conclusion='failure'if r['id']==target else'success')
root=pathlib.Path(tempfile.mkdtemp(prefix='recovery-observer-offline-',dir=S));original=root/'original';original.mkdir();(original/'observer.json').write_text(json.dumps({'all_19_selected_runs_terminal':True,'stop_reason':'all selected workflow runs terminal; metadata only','latest_snapshot':initial}));jobs={str(r['id']):{'run_id':r['id'],'attempt':1,'head_sha':sha,'required_jobs_completed_success':True,'jobs':[]}for r in initial['runs']if r['id']!=target};(original/'terminal-jobs.json').write_text(json.dumps(jobs));receipt=root/'SYNTHETIC-accepted-post.json';receipt.write_text(json.dumps({'run_id':target,'head_sha':sha,'branch':d['branch'],'expected_attempt':2,'post_attempted':True,'post_succeeded':True}));results=[]
def case(name,mode,want):
 output=root/name;calls=[];cycles=[0]
 class API:
  def __init__(self,deadline,out):self.count=0
  def get(self,endpoint):
   self.count+=1;calls.append(endpoint)
   if mode=='get-error':raise RuntimeError('synthetic GET error; no retry')
   if '/actions/workflows/'in endpoint:
    cycles[0]+=1;rs=copy.deepcopy([r for r in initial['runs']if r['id']!=39289017835])
    for r in rs:
     if r['id']==target:
      if mode!='await-then-success'or cycles[0]>1:r.update(run_attempt=2,status='completed',conclusion='failure'if mode=='reproduced-failure'else'success')
      if mode=='regression':
       r.update(run_attempt=2 if cycles[0]==1 else 1,status='in_progress'if cycles[0]==1 else'completed',conclusion=None if cycles[0]==1 else'failure')
      if mode=='attempt3':r['run_attempt']=3
      if mode=='wronghead':r['head_sha']='0'*40
     elif mode=='other-rerun':r['run_attempt']=2
    return {'total_count':18,'workflow_runs':rs}
   if endpoint.endswith('/actions/runs/39289017835'):return copy.deepcopy(next(r for r in initial['runs']if r['id']==39289017835))
   if '/check-runs?'in endpoint:return {'total_count':0,'check_runs':[]}
   if endpoint.endswith('/pulls/1041'):return {'head':{'sha':sha},'draft':True}
   if f'/actions/runs/{target}/attempts/2/jobs?'in endpoint:
    return {'total_count':1,'jobs':[{'id':999999,'run_id':target,'head_sha':sha,'run_attempt':2,'name':'smoke','status':'completed','conclusion':'failure'if mode=='reproduced-failure'else'success','steps':[]}]}
   raise AssertionError('Unexpected endpoint '+endpoint)
 args=['x',str(S/'transport-smoke-dispatch-c02-aedc80126.json'),'--canonical',str(S/'human-seated-dispatch-aedc80126.json'),'--out',str(output),'--max-seconds','30','--recovery',str(receipt),'--original-observer',str(original)]
 with mock.patch('sys.argv',args),mock.patch.object(w,'MetadataAPI',API),mock.patch.object(w.time,'sleep',lambda _:None),contextlib.redirect_stdout(io.StringIO()):code=w.main()
 o=json.loads((output/'observer.json').read_text());ok=code==0
 good=ok==want
 if mode=='await-then-success':
  snaps=[json.loads(x)for x in (output/'snapshots.jsonl').read_text().splitlines()];good=good and len(snaps)==2 and next(r for r in snaps[0]['runs']if r['id']==target)['run_attempt']==1 and len([x for x in calls if f'/actions/runs/{target}/attempts/2/jobs?'in x])==1
 if mode=='get-error':good=good and len(calls)==1
 if mode=='reproduced-failure':good=good and o['all_19_selected_runs_terminal']and not o['all_19_selected_workflows_success']
 results.append({'name':name,'synthetic_mode':mode,'expected_success':want,'actual_success':ok,'cycles':cycles[0],'get_calls':len(calls),'PASS':good})
for name,mode,want in [('await-stale1-then-real2','await-then-success',True),('reproduced-setup-failure-stops','reproduced-failure',False),('regression-to-attempt1-stops','regression',False),('wrong-head-stops','wronghead',False),('attempt3-stops','attempt3',False),('other-leg-rerun-stops','other-rerun',False),('get-error-no-retry','get-error',False)]:case(name,mode,want)
r={'scope':'OFFLINE fully mocked MetadataAPI and sleep; synthetic future POST/run/job fixtures. No network, POST, process launch or CI qualification','controls':results,'PASS':all(x['PASS']for x in results)};(S/'aedc80126-recovery-observer-offline-controls.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));assert r['PASS']
