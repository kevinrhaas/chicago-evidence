# SPDX-License-Identifier: GPL-3.0-or-later
"""Original conjectural civilian clothing authoring, kept separate from workwear.

Output is an unaccepted prepared-mesh prototype, never a canonical or scene actor.
No Blender dependency. No historical image or pattern is copied. No known outfit
of John Glessner is claimed. Every cut, surface dimension and material is original.
"""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def resolve(root, recipe):
    if recipe.get("scene_date")!="1904-07-01" or recipe.get("person_reference_id")!="glessner_john_j" or recipe.get("roles")!=["standing","walking","passenger"]:
        raise ValueError("Only Glessner1904 reconstructed standing/walking/passenger prototype")
    if recipe.get("identity_grade")!="attested" or recipe.get("appearance_grade")!="reconstructed" or recipe.get("production_eligible") is not False:
        raise ValueError("Identity/appearance/eligibility boundaries must remain explicit")
    for key in ("identity_validator","identity_profile","body_input"):
        expected=recipe["body_sha256" if key=="body_input" else key+"_sha256"]
        if sha(recipe[key])!=expected:raise ValueError("Changed pinned source "+key)
    spec=importlib.util.spec_from_file_location("reviewed1904identity",recipe["identity_validator"])
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    identity=module.resolve_named(Path(root),json.loads(Path(recipe["identity_profile"]).read_text()))
    body=json.loads(Path(recipe["body_input"]).read_text())
    if body.get("license")!="CC0-1.0" or body.get("units")!="m" or body.get("up_axis")!="+Y" or body.get("forward_axis")!="+Z":
        raise ValueError("Cleared metre/Yup/+Z input required")
    if body["target_blend"]["phenotype"]["chosen_age_years"]!=61:
        raise ValueError("Wrong mature-body target")
    parents=dict(json.loads((Path(root)/"data/humans/contract.json").read_text())["skeleton"]["bones"])
    if len(body["skeleton"])!=56 or {b["name"]:b["parent"] for b in body["skeleton"]}!=parents:
        raise ValueError("Portable skeleton differs")
    return body,identity


class Mesh:
    def __init__(self,name,material):
        self.data={"name":name,"material":material,"positions_m":[],"triangles":[],"uvs":[],"weights":[]}
    def grid(self,rows,cols,point,weight):
        start=len(self.data["positions_m"])
        for r in range(rows+1):
            for c in range(cols+1):
                u,v=c/cols,r/rows
                self.data["positions_m"].append(point(u,v));self.data["uvs"].append([u,v]);self.data["weights"].append(weight(u,v))
        for r in range(rows):
            for c in range(cols):
                a=start+r*(cols+1)+c;b=a+1;d=a+cols+1;e=d+1
                self.data["triangles"].extend([[a,b,e],[a,e,d]])


def generate(body,recipe,identity):
    bones={b["name"]:b for b in body["skeleton"]};height=body["report"]["chosen_height_m"]
    shoulder=bones["upperarm_l"]["head_m"][1];neck=bones["neck_01"]["head_m"][1]
    hem=height*.48;waist=height*.585;meshes=[]
    # The coat is an original open-front surface, not the worker jacket recipe.
    coat=Mesh("civilian_open_front_coat_original","coat_dark_plain_reconstructed")
    def coatpoint(u,v):
        gap=.055+.53*v*v;theta=gap+u*(2*math.pi-2*gap)
        return [math.sin(theta)*(.225+.010*v),hem+(shoulder-hem+.012)*v,.028+math.cos(theta)*(.158-.006*v)]
    coat.grid(14,48,coatpoint,lambda u,v:{"spine_02":1.0});meshes.append(coat.data)
    for side,sign in (("l",1),("r",-1)):
        sleeve=Mesh("civilian_coat_sleeve_"+side,"coat_dark_plain_reconstructed")
        a=bones["upperarm_"+side]["head_m"];b=bones["hand_"+side]["head_m"]
        def point(u,v,a=a,b=b):
            center=[a[k]*(1-v)+b[k]*v for k in range(3)];rad=.080*(1-v)+.047*v
            return [center[0],center[1]+math.sin(2*math.pi*u)*rad,center[2]+math.cos(2*math.pi*u)*rad]
        def weights(u,v,side=side):
            q=max(0,min(1,(v-.35)/.30));return {k:w for k,w in [("upperarm_"+side,1-q),("lowerarm_"+side,q)] if w>0}
        sleeve.grid(12,24,point,weights);meshes.append(sleeve.data)
        # Reconstructed folded lapel panel; coarse unsewn surface.
        lapel=Mesh("civilian_lapel_"+side,"coat_dark_plain_reconstructed")
        lapel.grid(8,3,lambda u,v,sign=sign:[sign*(.020+.110*v+u*(.020+.025*v)),waist+(shoulder-waist)*v,.194-.025*v],lambda u,v:{"spine_02":1.0});meshes.append(lapel.data)
    vest=Mesh("civilian_waistcoat_front","waistcoat_plain_reconstructed")
    vest.grid(10,16,lambda u,v:[(u-.5)*(.32-.09*v),waist-.04+(shoulder-waist-.025)*v,.175-.13*((u-.5)*2)**2],lambda u,v:{"spine_02":1.0});meshes.append(vest.data)
    shirt=Mesh("civilian_shirt_front","shirt_plain_reconstructed")
    shirt.grid(8,8,lambda u,v:[(u-.5)*(.08+.12*(1-v)),waist+(neck-waist)*v,.169-.008*v],lambda u,v:{"spine_03":1.0});meshes.append(shirt.data)
    collar=Mesh("civilian_shirt_collar","shirt_plain_reconstructed")
    collar.grid(3,24,lambda u,v:[math.sin(2*math.pi*u)*(.073+.012*v),neck-.008-.025*v,.015+math.cos(2*math.pi*u)*(.061+.012*v)],lambda u,v:{"spine_03":1.0});meshes.append(collar.data)
    band=Mesh("civilian_trouser_waist_original","trousers_plain_reconstructed")
    band.grid(4,32,lambda u,v:[math.sin(2*math.pi*u)*.172,waist-.14+.14*v,.015+math.cos(2*math.pi*u)*.135],lambda u,v:{"pelvis":1.0});meshes.append(band.data)
    for side,sign in (("l",1),("r",-1)):
        ankle=bones["foot_"+side]["head_m"];thigh=bones["thigh_"+side]["head_m"]
        leg=Mesh("civilian_straight_trouser_"+side,"trousers_plain_reconstructed")
        def point(u,v,ankle=ankle,thigh=thigh):
            radius=.090*(1-v)+.060*v;cx=thigh[0]*(1-v)+ankle[0]*v;cy=(waist-.08)*(1-v)+(ankle[1]+.015)*v;cz=thigh[2]*(1-v)+ankle[2]*v
            return [cx+math.sin(2*math.pi*u)*radius,cy,cz+math.cos(2*math.pi*u)*radius*1.03]
        def weights(u,v,side=side):
            q=max(0,min(1,(v-.35)/.30));return {k:w for k,w in [("thigh_"+side,1-q),("calf_"+side,q)] if w>0}
        leg.grid(16,24,point,weights);meshes.append(leg.data)
        shoe=Mesh("civilian_closed_shoe_"+side,"shoes_plain_reconstructed")
        foot=[p for m in body["meshes"] for p,w in zip(m["positions_m"],m["weights"]) if w.get("foot_"+side,0)+w.get("ball_"+side,0)>.35]
        xmin,xmax=min(p[0] for p in foot)-.008,max(p[0] for p in foot)+.008
        zmin,zmax=min(p[2] for p in foot)-.010,max(p[2] for p in foot)+.010
        cx,cz=(xmin+xmax)/2,(zmin+zmax)/2;rx,rz=(xmax-xmin)/2,(zmax-zmin)/2
        shoe.grid(4,24,lambda u,v,cx=cx,cz=cz,rx=rx,rz=rz:[cx+math.sin(2*math.pi*u)*rx*(1-.18*v),.006+.115*v,cz+math.cos(2*math.pi*u)*rz*(1-.18*v)],lambda u,v,side=side:{"foot_"+side:1.0})
        # Closed flat sole polygon; shoe top remains a reconstructed opening.
        center=len(shoe.data["positions_m"]);shoe.data["positions_m"].append([cx,.006,cz]);shoe.data["uvs"].append([.5,.5]);shoe.data["weights"].append({"foot_"+side:1.0})
        for i in range(24):shoe.data["triangles"].append([center,i+1,i])
        meshes.append(shoe.data)
    result={"format":"chicago4d_prepared_civilian_prototype_v1","license":"CC0-1.0","units":"m","up_axis":"+Y","forward_axis":"+Z",
        "person_reference_id":"glessner_john_j","identity_grade":"attested","appearance_grade":"reconstructed","scene_date":"1904-07-01",
        "roles":["standing","walking","passenger"],"production_eligible":False,"body_input_sha256":recipe["body_sha256"],"skeleton":body["skeleton"],"meshes":meshes,
        "materials":{"coat_dark_plain_reconstructed":[.055,.060,.065,1],"waistcoat_plain_reconstructed":[.09,.095,.10,1],"shirt_plain_reconstructed":[.78,.76,.70,1],"trousers_plain_reconstructed":[.09,.09,.10,1],"shoes_plain_reconstructed":[.025,.020,.015,1]},
        "materials_basis":"Original flat PBR colors, not recovered textile, skin or photographic appearance","identity":identity,
        "garment_sources":[],"basis":recipe["basis"],"unsupported_choices":recipe["unsupported_choices"],
        "limitations":["Coarse open surfaces with unsewn coat/sleeve and trouser/waist seams; intersections may exist","No body-mask, seam continuity, layer clearance, clothing thickness or seated fit accepted","No production skin/hair, photographic anatomy, canonical master, LOD, GLB, motion or scene placement","Full clothing cut is conjectural; no source-matched1904 civilian outfit or personal garment ownership"]}
    validate_arrays(result,body)
    return result


def validate_arrays(result,body):
    if result["skeleton"]!=body["skeleton"]:raise ValueError("Body skeleton differs")
    names={b["name"] for b in body["skeleton"]}
    for m in result["meshes"]:
        n=len(m["positions_m"])
        if n!=len(m["uvs"]) or n!=len(m["weights"]):raise ValueError("Array count differs")
        if any(len(p)!=3 or not all(math.isfinite(v) for v in p) for p in m["positions_m"]):raise ValueError("Invalid position")
        for w in m["weights"]:
            if not w or len(w)>4 or set(w)-names or any(v<=0 or not math.isfinite(v) for v in w.values()) or abs(sum(w.values())-1)>1e-8:raise ValueError("Invalid weights")
        for t in m["triangles"]:
            if len(t)!=3 or len(set(t))!=3 or min(t)<0 or max(t)>=n:raise ValueError("Invalid triangle")


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--root",type=Path,required=True);p.add_argument("--output",type=Path,required=True);args=p.parse_args()
    recipe=json.loads((Path(__file__).parent/"civilian1904.recipe.json").read_text());body,identity=resolve(args.root,recipe);out=generate(body,recipe,identity)
    args.output.mkdir(parents=True,exist_ok=False);(args.output/"glessner1904.civilian.json").write_text(json.dumps(out,separators=(",",":"))+"\n")
    print(json.dumps({"status":"UNACCEPTED_RECONSTRUCTED_CIVILIAN_ARRAYS","components":len(out["meshes"]),"triangles":sum(len(m["triangles"]) for m in out["meshes"]),"body_age":61,"production_eligible":False}))


if __name__=="__main__":main()
