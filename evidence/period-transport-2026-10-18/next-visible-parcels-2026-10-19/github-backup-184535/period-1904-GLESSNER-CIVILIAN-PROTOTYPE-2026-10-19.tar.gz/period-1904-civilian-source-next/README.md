# John Glessner1904 — original conjectural civilian clothing prototype

This is a separate concrete named-civilian authoring parcel following the mature body input. It does not use or rename the Sears work-jacket output. It contains actual new prepared garment arrays (13 components/5,408 triangles), a generator, a strict explicit Blender attachment adapter and source/array/refusal receipts. Nothing is installed in the application or eligible for scene display. BPy has not been installed, imported or executed.

The garment set is an original plain open-front civilian coat with sleeves/lapels, waistcoat, shirt front/collar, trouser waist/two straight legs and two low closed-shoe constructions. All cut, dimensions, colors, material properties, closures, layer combination and tailoring are conjectural. The current dossier provides close-dated commercial coat/trouser/collar/pocket vocabulary in workwear, not a 1904 civilian suit pattern or Glessner's outfit. No source registry ID, personal purchase, recovered wardrobe or source-matched appearance is invented. The recipe's garment_sources array is deliberately empty. The owner permits transparently reconstructed appearance; a real integrator-owned LIBERTIES entry is required before application use.

John Glessner's identity is attested; his appearance and standing/walking/passenger demonstration are reconstructed. His mature61 CC0 engineering input represents one choice within the actual record's age60–61 uncertainty. Height1.75m and macro shape are not historical measurements or a photographic likeness. No driver, rider or professional-coachman assignment is allowed. No 1835 identity or clothing is moved into1904. Frances is not assigned this male-body wardrobe.

The generator validates exact mature-body bytes, the previously reviewed strict identity validator/profile and actual current1904 household/scene. The named civilian adapter separately requires an explicit matching nonproduction actor context; it refuses wrong person/era/roles, likeness upgrades, changed body or changed contract parents before BPy. Its source additionally checks the actual rig's person/date/ineligibility tags, identity object transform, all56 actual parents and source-matching rest endpoints (1e-7m Float32 engineering allowance) before attaching. Rest endpoints do not prove bone roll or accepted deformation.

## Actual limits

This is coarse geometric construction, not accepted tailoring or photographic modeling. The torso/sleeve armholes and trouser/waist connections are separate, unsewn surfaces. No body mask, cloth thickness, seam construction, body/garment or layer collision, material texture, coat drape, hands/reins, seated clearance, footboard, gait or deformation has been accepted. Some garment/body intersections may exist. The shirt is a front/collar layer under the coat, not a complete standalone shirt. The shoes have an original sole and open top, with no source-matched last or closure. Flat materials are unmeasured author choices; source/runtime normal fidelity is unverified. Full anatomical skin/hair, canonical master, fourLODs, glTF, animation and scene placement remain unfinished. No screenshot or actual browser result is claimed.

This is useful as a labeled original clothing-construction branch and the next canonical-builder seam. It must not close a photographic human, period garment, full driver or transport-interaction ticket. Future review should replace coarse seams with sewn pattern construction, inspect actual neutral-light anatomy and clothing, source-bound civilian dress, and run all ordinary canonical/export/LOD/deformation/source+published desktop/mobile gates.

## Reproduce without Blender

```
python /workspace/shared/period-1904-civilian-source-next/civilian1904.py --root /workspace/chicago/chicago/4d --output NEW_DIRECTORY
```

The output directory must be new. No default caller reaches the adapter. A future explicitly ineligible mature-body authoring rig must have exact source rest coordinates and metadata before the adapter can attach these garments. The existing1835 builder and its era guard remain unchanged.

Original Python code is GPL-3.0-or-later. Original garment geometry/recipe/output is dedicated CC0-1.0. Mature body retains verified MakeHuman graphical data CC0 provenance from the previous archive. No garment image pixels, traced silhouette, pattern diagram or third-party program logic is used. The archive includes exact dependency input bytes and hashes; all tracked application files remain unchanged.
