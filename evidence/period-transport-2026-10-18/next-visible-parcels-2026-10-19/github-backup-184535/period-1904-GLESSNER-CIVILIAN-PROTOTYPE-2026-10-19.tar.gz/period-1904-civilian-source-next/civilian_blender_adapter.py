# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicit unaccepted civilian authoring seam. BPy path has not been executed."""
import hashlib
import json
import math
import civilian1904


def validate(prototype,body_bytes,contract,actor_context):
    expected={"scene_date":"1904-07-01","person_reference_id":"glessner_john_j",
              "identity_grade":"attested","appearance_grade":"reconstructed","production_eligible":False}
    if not isinstance(actor_context,dict) or any(actor_context.get(k)!=v for k,v in expected.items()):
        raise ValueError("Explicit nonproduction Glessner1904 civilian caller required")
    if actor_context.get("roles")!=["standing","walking","passenger"]:
        raise ValueError("No driver/rider assignment is qualified")
    if any(prototype.get(k)!=v for k,v in expected.items()) or prototype.get("roles")!=actor_context["roles"]:
        raise ValueError("Prototype/person context differs")
    if prototype.get("format")!="chicago4d_prepared_civilian_prototype_v1" or prototype.get("garment_sources")!=[]:
        raise ValueError("Only explicitly unsourced-cut original civilian prototype is reviewed")
    if hashlib.sha256(body_bytes).hexdigest()!=prototype.get("body_input_sha256"):
        raise ValueError("Actual mature body bytes differ")
    body=json.loads(body_bytes)
    for data in (body,prototype):
        if data.get("license")!="CC0-1.0" or data.get("units")!="m" or data.get("up_axis")!="+Y" or data.get("forward_axis")!="+Z":
            raise ValueError("Cleared metre/Yup/+Z body and clothing required")
    if body["target_blend"]["phenotype"]["chosen_age_years"]!=61:
        raise ValueError("Mature-body age parameter differs")
    if len(prototype["skeleton"])!=56 or {b["name"]:b["parent"] for b in prototype["skeleton"]}!=dict(contract["skeleton"]["bones"]):
        raise ValueError("Portable skeleton hierarchy differs")
    civilian1904.validate_arrays(prototype,body)
    return body


def attach(prototype,body_bytes,contract,rig,collection,*,actor_context):
    body=validate(prototype,body_bytes,contract,actor_context)
    # Caller must construct and label a separate, ineligible mature-body rig.
    if rig.type!="ARMATURE" or rig.get("person_reference_id")!="glessner_john_j" or rig.get("scene_date")!="1904-07-01" or rig.get("production_eligible") is not False:
        raise ValueError("Dedicated nonproduction Glessner1904 authoring rig required")
    if set(rig.data.bones.keys())!={b["name"] for b in body["skeleton"]}:
        raise ValueError("Actual rig bone set differs")
    if any(abs(rig.matrix_world[r][c]-(1 if r==c else 0))>1e-8 for r in range(4) for c in range(4)):
        raise ValueError("Rig object must preserve source identity frame")
    for source in body["skeleton"]:
        bone=rig.data.bones[source["name"]]
        if (bone.parent.name if bone.parent else None)!=source["parent"]:
            raise ValueError("Actual rig parent differs")
        for key,actual in (("head_m",bone.head_local),("tail_m",bone.tail_local)):
            p=source[key];expected=(p[0],-p[2],p[1])
            if math.dist(actual,expected)>1e-7:
                raise ValueError("Actual rig rest endpoints differ from mature body")
    import bpy
    materials={}
    for key,rgba in prototype["materials"].items():
        material=bpy.data.materials.new(key);material.use_nodes=True
        shader=material.node_tree.nodes["Principled BSDF"];shader.inputs["Base Color"].default_value=rgba
        shader.inputs["Roughness"].default_value=.82
        materials[key]=material
    objects=[]
    for source in prototype["meshes"]:
        mesh=bpy.data.meshes.new(source["name"])
        mesh.from_pydata([(p[0],-p[2],p[1]) for p in source["positions_m"]],[],source["triangles"]);mesh.update()
        uv=mesh.uv_layers.new(name="UVMap")
        for polygon in mesh.polygons:
            polygon.use_smooth=True
            for loop in polygon.loop_indices:uv.data[loop].uv=source["uvs"][mesh.loops[loop].vertex_index]
        obj=bpy.data.objects.new(source["name"],mesh);collection.objects.link(obj);mesh.materials.append(materials[source["material"]])
        for bone in body["skeleton"]:obj.vertex_groups.new(name=bone["name"])
        for i,weights in enumerate(source["weights"]):
            for key,value in weights.items():obj.vertex_groups[key].add([i],value,"REPLACE")
        obj.modifiers.new("skin","ARMATURE").object=rig
        obj["person_reference_id"]="glessner_john_j";obj["scene_date"]="1904-07-01";obj["production_eligible"]=False
        obj["appearance_grade"]="reconstructed";obj["garment_cut_basis"]="Wholly original conjectural cut; no source-matched personal outfit"
        objects.append(obj)
    return objects
