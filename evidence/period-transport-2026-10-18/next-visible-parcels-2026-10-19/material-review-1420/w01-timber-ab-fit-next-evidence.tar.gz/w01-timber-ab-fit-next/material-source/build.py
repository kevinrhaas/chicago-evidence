# SPDX-License-Identifier: GPL-3.0-or-later
"""Bounded bench TOP ONLY material study; original geometry retained exactly."""
import json,struct,hashlib,argparse,copy,io
import numpy as np
from PIL import Image
def require(c,msg):
 if not c:raise ValueError(msg)
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--vehicle',type=Path,required=True);ap.add_argument('--library',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();a.output.mkdir(exist_ok=False)
raw=a.vehicle.read_bytes();require(hashlib.sha256(raw).hexdigest()=='f415e6fb79c9df9372c5b2ec6cb77c9a305117de3fa8e9c704c87d5c09a6aeb0','Exact baseline required');n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);b=bytearray(raw[28+n:]);base=copy.deepcopy(g);oldbin=bytes(b)
def read(i):
 x=g['accessors'][i];v=g['bufferViews'][x['bufferView']];return [struct.unpack_from('<3f',b,v.get('byteOffset',0)+x.get('byteOffset',0)+k*12)for k in range(x['count'])]
def attr(values,k):
 off=len(b);flat=[v for p in values for v in p];b.extend(struct.pack('<%df'%len(flat),*flat));vi=len(g['bufferViews']);g['bufferViews'].append({'buffer':0,'byteOffset':off,'byteLength':len(flat)*4,'target':34962});i=len(g['accessors']);g['accessors'].append({'bufferView':vi,'componentType':5126,'count':len(values),'type':'VEC'+str(k),'min':[min(v[j]for v in values)for j in range(k)],'max':[max(v[j]for v in values)for j in range(k)]});return i
m=next(x for x in g['meshes']if x['name']=='vehicle_body_timber');p=m['primitives'][0];pos=read(p['attributes']['POSITION']);norm=read(p['attributes']['NORMAL']);selected=[];keep=[]
# Exact retained original bench plank occupies first36 authored soup vertices.
bench=pos[:36];require(len(bench)==36 and all(-.5900001<=v[0]<=.5900001 and 1.5299999<=v[1]<=1.5800001 and .4999999<=v[2]<=.8000001 for v in bench),'Exact source bench plank ownership')
require(all(abs(min(v[k]for v in bench)-lo)<1e-7 and abs(max(v[k]for v in bench)-hi)<1e-7 for k,lo,hi in [(0,-.59,.59),(1,1.53,1.58),(2,.5,.8)]),'Exact bench envelope')
for i in range(0,len(pos),3):
 hit=i<36 and abs(norm[i][0])<.1
 (selected if hit else keep).extend(range(i,i+3))
require(len(selected)==24,'Eight actual broad bench triangles required')
p['attributes']={k:attr([v[i]for i in keep],3)for k,v in [('POSITION',pos),('NORMAL',norm)]}
def cross_coordinate(i):
 x,y,z=pos[i];nx,ny,nz=norm[i]
 if ny>.5:return z-.5
 if nz>.5:return .30+(1.58-y)
 if ny<-.5:return .35+(.8-z)
 if nz<-.5:return .65+(y-1.53)
 raise ValueError('End-grain face must not receive longitudinal grain')
uv=[((pos[i][0]+.59)/4.48+.137,cross_coordinate(i)/4.48+.29)for i in selected]
inputs={};g.setdefault('images',[]);g.setdefault('textures',[]);g.setdefault('samplers',[]);si=len(g['samplers']);g['samplers'].append({'magFilter':9729,'minFilter':9987,'wrapS':10497,'wrapT':10497});tex=[]
for suffix in ['basecolor','normal_gl','orm']:
 f=a.library/('clapboard_board_face_'+suffix+'.png');data=f.read_bytes();inputs[f.name]=hashlib.sha256(data).hexdigest()
 if suffix=='basecolor':
  arr=np.asarray(Image.open(io.BytesIO(data)).convert('RGB'),dtype=np.float64)/255;lin=np.where(arr<=.04045,arr/12.92,((arr+.055)/1.055)**2.4);mean=lin.mean(axis=(0,1));target=np.asarray(g['materials'][1]['pbrMetallicRoughness']['baseColorFactor'][:3]);normalized=lin*(target/mean);require(float(normalized.max())<1,'Normalization would clipgrain');srgb=np.where(normalized<=.0031308,normalized*12.92,1.055*normalized**(1/2.4)-.055);image=Image.fromarray(np.round(srgb*255).astype('uint8'));buf=io.BytesIO();image.save(buf,format='PNG',compress_level=9);data=buf.getvalue();(a.output/'bench_grain_linear_mean_normalized.png').write_bytes(data);normalization={'original_linear_mean':mean.tolist(),'target_existing_timber_linear_mean':target.tolist(),'scale':(target/mean).tolist(),'clipped_pixels':0,'relative_grain_preserved_before_quantization':True}
 b.extend(b'\0'*((-len(b))%4));vi=len(g['bufferViews']);g['bufferViews'].append({'buffer':0,'byteOffset':len(b),'byteLength':len(data)});b.extend(data);ii=len(g['images']);g['images'].append({'mimeType':'image/png','bufferView':vi});ti=len(g['textures']);g['textures'].append({'source':ii,'sampler':si});tex.append(ti)
b.extend(b'\0'*((-len(b))%4));mi=len(g['materials']);g['materials'].append({'name':'bench_top_cleared_board_grain_study','pbrMetallicRoughness':{'baseColorFactor':[1,1,1,1],'baseColorTexture':{'index':tex[0]},'metallicFactor':0,'roughnessFactor':1,'metallicRoughnessTexture':{'index':tex[2]}},'normalTexture':{'index':tex[1],'scale':.2},'extras':{'grade':'reconstructed application; original texture confidence attested/inferred is NOT wagon finish attestation','source':'Chicago1835PBR clapboard_board_face','normal_scale':'original unmeasured .2 engineering choice'}})
# Actual triangle UV derivatives; compute explicit tangent handedness.
import math
vectors=[];tbn_receipts=[]
for first in range(0,len(selected),3):
 ids=selected[first:first+3];pts=[pos[i]for i in ids];tc=uv[first:first+3];e1=[pts[1][k]-pts[0][k]for k in range(3)];e2=[pts[2][k]-pts[0][k]for k in range(3)];du1,dv1=[tc[1][k]-tc[0][k]for k in range(2)];du2,dv2=[tc[2][k]-tc[0][k]for k in range(2)];det=du1*dv2-du2*dv1
 if abs(det)<1e-14:raise ValueError('Degenerate UV triangle')
 tangent=[(e1[k]*dv2-e2[k]*dv1)/det for k in range(3)];bitangent=[(e2[k]*du1-e1[k]*du2)/det for k in range(3)]
 for idx in ids:
  nn=norm[idx];dot=math.fsum(tangent[k]*nn[k]for k in range(3));tt=[tangent[k]-dot*nn[k]for k in range(3)];length=math.sqrt(math.fsum(x*x for x in tt));tt=[x/length for x in tt];cross=[nn[1]*tt[2]-nn[2]*tt[1],nn[2]*tt[0]-nn[0]*tt[2],nn[0]*tt[1]-nn[1]*tt[0]];hand=1 if math.fsum(cross[k]*bitangent[k]for k in range(3))>0 else -1;vectors.append(tt+[hand]);tbn_receipts.append({'normal':list(nn),'tangent':tt,'handedness':hand,'derivative_u':tangent,'derivative_v':bitangent,'uv_determinant':det})
m['primitives'].append({'attributes':{'POSITION':attr([pos[i]for i in selected],3),'NORMAL':attr([norm[i]for i in selected],3),'TEXCOORD_0':attr(uv,2),'TANGENT':attr(vectors,4)},'material':mi})
g['buffers'][0]['byteLength']=len(b);j=json.dumps(g,separators=(',',':')).encode();j+=b' '*((-len(j))%4);out=struct.pack('<III',0x46546c67,2,28+len(j)+len(b))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(b),0x004e4942)+b;(a.output/'wagon-w01.glb').write_bytes(out)
report={'input_sha256':hashlib.sha256(raw).hexdigest(),'output_sha256':hashlib.sha256(out).hexdigest(),'selected_vertex_ids':selected,'old_binary_prefix_exact':bytes(b[:len(oldbin)])==oldbin,'nodes_skins_animations_exact':all(g.get(k)==base.get(k)for k in ['nodes','skins','animations','scenes']),'geometry_multiset_exact':sorted(pos)==sorted([pos[i]for i in keep]+[pos[i]for i in selected]),'uv_density_px_per_m':1024/4.48,'metric_span_m':4.48,'grain_axis':'+X bench length; continuous cross-section perimeter coordinate, bottom-back seam; bothUVaxes same4.48m scale','uv_triangle_anisotropy':1,'tbn_derivation':tbn_receipts,'linear_normalization':normalization,'scope':'Eight broad bench plank triangles only; two end faces retain original matching-mean solid timber, detailed endgrain UNRESOLVED; all other vehicle unchanged','source_hashes':inputs,'status':'UNACCEPTED visual candidate; no photographic/finish attestation'};(a.output/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
