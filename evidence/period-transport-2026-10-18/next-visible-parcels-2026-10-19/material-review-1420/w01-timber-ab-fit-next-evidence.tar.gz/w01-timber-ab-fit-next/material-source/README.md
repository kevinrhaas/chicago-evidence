# Bench timber continuity v3 — outside, unaccepted

ONE corrected materialcandidate; no app/browser changes. Sourcegrain is existing cleared projectprocedural clapboard_board_face, no architecturalcoursejoints and no photographic evidence. Actually read librarylicense requires provenance/confidence retained. Its original inferred/attested label is not wagonfinish attestation. No species, factorynewness, aging or historic paintcolor asserted.

Baseline timberfactor[.42,.26,.12] is already a reconstructed linearRGB choice, not measuredperiodcolor. To avoid darkimportedpatch, sourcebasecolor decoded sRGB→linear; eachchannel multiplied by baselinefactor/sourceWHOLEmapmean, then reencoded. Relative texture contrast perchannel preserved before8bitquantization;0clipping. No imagegrade/exposure/light changes. Roughness/normalmaps unchanged; normalstrength.2 remains originalunmeasured optical choice.

Only benchplank eightlong/broad triangles are textured; consistentgrainX and cross-sectionperimeter coordinate carries grain continuously top/front/bottom/back with one explicit bottom-back UV seam. Endfaces remain matchingmean solidoriginaltimber; no eligible actualendgrainmap found, so detailedendgrain remainsOPEN ratherthan fakinglongitudinalgrain on ends. Existing source36vertex plankownership+exactbox envelope guarded explicitly, and protectedinputhash/24selectedverts use ValueError checks that remainunder-O.

Actualbinaryreadback checks all eight UVtriangle metricaxes,zeroareas,TBNorientation andfullorientedPOSITION+NORMALtriangle multiset/nodes/rig. Geometry unchanged; no new clearanceclaim needed. Khronos0errors0warnings21infos. No photographic advancement accepted until matchedcamera A/Bactualimages. Existingc95/ccd and independentmobileframingfailure preserved separately. Root mustreview/release browser; camera2%criteria unchanged.

Reproduce: python build.py --vehicle F415.glb --library REPO/assets/textures/chicago_1835_pbr/walls/clapboard_board_face --output FRESH_DIR.
