# SPDX-License-Identifier: GPL-3.0-or-later
import struct,json,math,hashlib
from pathlib import Path
import numpy as np
O=Path(__file__).parent
def load(p):
 raw=p.read_bytes();n=struct.unpack_from('<I',raw,12)[0];return json.loads(raw[20:20+n]),raw[28+n:]
def read(d,b,i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];k=int(a['type'][-1]);return np.frombuffer(b,dtype='<f4',count=a['count']*k,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,k)
def triangles(d,b):
 return sorted(tuple(np.concatenate([read(d,b,p['attributes'][k])for k in ['POSITION','NORMAL']],axis=1).reshape(-1,18)[i])for m in d['meshes']for p in m['primitives']for i in range(len(read(d,b,p['attributes']['POSITION']))//3))
def require(x,s):
 if not x:raise ValueError(s)
d,b=load(O/'candidate/wagon-w01.glb');old,ob=load(Path('/workspace/shared/w01-supported-driver-next/export/wagon-w01.glb'));require(triangles(d,b)==triangles(old,ob),'actual geometry/normal triangles changed');require(all(d.get(k)==old.get(k)for k in ['nodes','scenes','skins','animations']),'articulation changed');p=d['meshes'][-1]['primitives'][-1];ps=read(d,b,p['attributes']['POSITION']).astype(float);ns=read(d,b,p['attributes']['NORMAL']).astype(float);uv=read(d,b,p['attributes']['TEXCOORD_0']).astype(float);ts=read(d,b,p['attributes']['TANGENT']).astype(float);rows=[]
for i in range(0,len(ps),3):
 e=np.stack([ps[i+1]-ps[i],ps[i+2]-ps[i]]);u=np.stack([uv[i+1]-uv[i],uv[i+2]-uv[i]]);det=float(np.linalg.det(u));area=float(np.linalg.norm(np.cross(*e))/2);require(area>0 and abs(det)>1e-12,'zeroarea');der=np.linalg.solve(u,e);lengths=np.linalg.norm(der,axis=1);require(np.max(abs(lengths-4.48))<2e-5,'metricdensity');require(abs(np.dot(der[0],der[1]))<1e-6,'stretchedaxes')
 for j in range(i,i+3):
  n=ns[j];t=ts[j,:3];v=np.cross(n,t)*ts[j,3];require(abs(np.dot(n,t))<1e-7 and abs(np.linalg.norm(t)-1)<1e-7 and abs(np.linalg.norm(v)-1)<1e-7,'TBNorthonormal');require(np.dot(t,der[0])>0 and np.dot(v,der[1])>0,'UVaxisorientation');require(ts[j,3]in[-1,1],'handedness')
 rows.append({'triangle':i//3,'world_area_m2':area,'uv_area':abs(det)/2,'world_m_per_uv_axis':lengths.tolist(),'tangent':ts[i].tolist(),'normal':ns[i].tolist()})
r={'passed':True,'actual_all_oriented_POSITION_NORMAL_triangle_multiset_exact':True,'actual_nodes_scenes_skins_animations_exact':True,'actual_TBN_and_metricUV_pass':True,'triangles':rows,'scope':'decoded candidate8bench broad triangles only; no visual/photo/endgrain acceptance'};(O/'candidate/independent-actual-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
