# T2804 opt-in named1835 seated driver — next canonical-authoring parcel

Outside frozen app only. This stages a visible seated named-resident result through the EXISTING canonical builder/portable export/HumanActor, conditional on the next actual CI bake. No Blender was installed/run; no app files or tickets were edited; no remote dispatch/browser was launched. Actual named CI GLBs are unavailable locally. The proposal never substitutes c4d_fixture, a generic person, an anonymous role, OBJ skin-only source geometry, or a new human runtime. Current visible canonical/clothed result is NOT claimed.

## Implemented source

- `files/chicago/4d/tools/human_teamster_blend.py`: current canonical source plus paired optional `--sit-drive-study`/`--sit-drive-vehicle`. Uses actual BPy bone rest matrices, pure original global→local rest-basis conversion and exact56bone pose set. Adds static looping `sit_drive` keys0/30 (1s) only when opted in. Unit scales are explicit, no scale animation channels, no rig topology or base mesh mutation. Original idle/walk action section is byte-identical; default branch behavior is source-preserved, not a new unexecuted Blender byte-proof.
- `tools/human_seated_study.py` + `data/humans/poses/w01/`: existing corrected source-LBS pose matrices for Otis Bardwell(rc_bardwell_otis), Joseph Dufresne(rc_dufresne_joseph), Martin Flynn(rc_flynn_martin), all existing reconstructed1835references. Explicit asset/person/date/body/posehash and physicalbench guards. Rigid rotation matrices refuse stretches/reflections. Data/age/height/anatomy are authoring reconstructions, not attested person facts or driving assignments.
- `tools/human_seated_driver.html/.mjs/.cjs`: actual exported named person sits on the physical supported W01 using unchanged HumanActor/createHumanAssets. Requires sit_drive rather than idle fallback, matching actual exported person/date, actual authored vehicle-sidecarhash and real existing person resolution. It plays real idle and sit to demonstrate actual surface deformation, then captures3angles on desktop/mobile CSSviewports from actual deformed indexedgeometry, using existing header-aware camera fitter. Unknown/1812/1904wardrobe fails. The study remains technical/unmounted; no scene population or historic assignment is created.
- `.github/workflows/chicago-4d-humans.yml`: explicit manual `build_seated_driver_study` input(defaultfalse), generates physicalbench, runs pure refusals, adds optional sit to three named canonical masters, runs ALL existing portable export/contracts/validator/general inspections, then named seated runtime pictures. The existing generic fixture branch and standard teamster defaults remain untouched. Bench and seated images/receipts join artifacts; no production publication/promote step.

## Physical frame and atomic dependency

Requires carriage_model's CURRENT supported-W01 parcel at `/workspace/shared/w01-supported-driver-next`, intended app generator/params paths `tools/transport/generate_wagon.py` and `data/transport/studies/wagon-driver-bench.json`. That owner supplies vehicle source/context patch; do not copy baseline empty sockets or old generated vehicle into its place. Candidate f415e6fb79c9df9372c5b2ec6cb77c9a305117de3fa8e9c704c87d5c09a6aeb0; frame metres,+Yup,+Zforward. Seat support at(0,1.58,.65), footprintx±.59,z.50..80; footboardtop1.12,x±.425,z1.12..1.42. The vehicle seat socket is a SUPPORT plane, never the pelvis. Static source pose includes full world registration against the wagon root. HumanActor heading180 produces yaw0, preserving authored +Zforward. Both roots co-located in the technical preview; no duplicate seat offset or rescaling. Future wagon attachment should parent actor under vehicle root, not translate the already registered pose onto the support socket.

Corrected bare-source pelvisY Otis1.669739842/Joseph+Martin1.671057435. Wrist targets are OPEN-hand datums, not clenched/palm rein grips. Existing source-LBS triangle/contact failures and correction history remain frozen in resident-wagon-driver-draft; not relabeled canonical or clothed. Actual new W01 furniture is same nominal support frame; actual Float32 geometry/contact remain authoritative.

## Checks actually run here

Ten pure tests PASS in0.203s against actual current prepared bodies/profile/currentf415sidecar: three exact named bindings, wrong person, wrong variantdate/profiledate, scaled/stale body, empty wagon, nonrigid pose and translated-child bone-chain stretch with recomputedhash refusal, parentrestbasis roundtrip. Python AST/Node source syntax and YAML parse pass. No BPy, export, screenshot, named asset load, actual garment/contact or CI execution occurred. The source helper's stricter matrix checks do not loosen contract tolerances. No full local gate was run while root64220qualifies.

Command for current outside check:

    python3 files/chicago/4d/tools/test_human_seated_study.py --source-root /workspace/chicago/chicago/4d --proposal-root files/chicago/4d --vehicle /workspace/shared/w01-supported-driver-next/export/wagon-w01.json

After ROOT installs the atomic vehicle+human proposal, manual canonical workflow `build_seated_driver_study=true` makes the first real clothed/model result. Existing base human export/contracts/Khronos/frame/surface/skin/face/hair/groundedwalk checks remain required. Additional runtime source command after actual export:

    NODE_PATH="$(npm root -g)" node tools/human_seated_driver.cjs /tmp/teamster-studies/seated-driver

Root owns LIBERTIES/license/changelog/ticket/derived-tail and integration decisions; existing L418workwear provenance must get an honest seated-study addendum before new master promotion. No new liberty ID is invented here. Actual named visible renders are required before T2804 can be considered complete.

## Material limitations to review in the actual CI pictures

Bare-source triangle registration is not clothed seat contact. Existing trouser/shoe/collar offsets can create bench/footboard penetration or floating despite bare-body near-contact; actual exported garment/shoe triangles must be measured and inspected, then the pose/furniture revised on that evidence. This parcel provides no false collision-clearance gate for unavailable clothing. It does not establish hip/elbow deformation, finger grip, body self-collision, rein endpoints, load/support strength, continuous motion, driver control, boarding, historical bench construction/ownership, individuality or photographic likeness. If CI images show problems, preserve failed artifacts and adjust actual authoring; never substitute metadata-only or fixture proof.

Original source helper/renderer/tests and project-derived builder/workflow code GPL-3.0-or-later. Original reconstructed numerical pose data follows cleared CC0human-input/output study scope; no photo tracing/pixels/external body/model/texture acquisition added. Existing canonical recipe/vendor licenses remain authoritative. Optional seated source is additive; current app W01/C01/hitch/humans are untouched by this package.
