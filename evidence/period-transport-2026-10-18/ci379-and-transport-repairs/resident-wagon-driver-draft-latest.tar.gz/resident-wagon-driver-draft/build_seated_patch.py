from pathlib import Path
import difflib,json
R=Path('/workspace/chicago/chicago/4d');O=Path(__file__).parent
old=(R/'tools/human_teamster_blend.py').read_text();new=old.replace("    p.add_argument('--body', type=Path)","    p.add_argument('--sit-drive-vehicle', type=Path, help='Actual exported bench-equipped wagon sidecar required with seated study')\n    p.add_argument('--sit-drive-study', type=Path, help='Explicit1835bench/resident source-pose profile; adds opt-in study clip only')\n    p.add_argument('--body', type=Path)")
new=new.replace('    rig.animation_data.action=None\n    for pose in rig.pose.bones:', '''    if args.sit_drive_study:
        from human_seated_study import load_study, desired_matrix, local_basis
        if not args.sit_drive_vehicle:raise ValueError('--sit-drive-study requires --sit-drive-vehicle exported sidecar')
        study_pose,study_metadata=load_study(args.sit_drive_study,variant,bodypath,scale,args.sit_drive_vehicle)
        if set(study_pose)!=set(bones):raise ValueError('seated study joint set differs from canonical rig')
        # Read actual Blender rest bases; do not reconstruct roll or treat global
        # deformations as parent-local quaternions.
        rests={n:[list(row) for row in rig.data.bones[n].matrix_local] for n in bones}
        desired={n:desired_matrix(study_pose[n],rests[n]) for n in bones}
        act=bpy.data.actions.new('sit_drive');act.use_fake_user=True
        rig.animation_data.action=act
        act['loop']=True
        act['motion_basis']='Original reconstructed static seated IK study; no driving forces or biological motion claim'
        act['driver_study_json']=json.dumps(study_metadata,sort_keys=True)
        for frame in (1,31):
            for name,parent in contract['skeleton']['bones']:
                pose=rig.pose.bones[name]
                matrix=local_basis(rests[name],desired[name],rests[parent] if parent else None,desired[parent] if parent else None)
                pose.rotation_mode='QUATERNION'
                pose.matrix_basis=Matrix(matrix)
                pose.keyframe_insert('rotation_quaternion',frame=frame)
                pose.keyframe_insert('location',frame=frame)
                pose.keyframe_insert('scale',frame=frame)
        linearize_action(act)
        scene['driver_study_json']=json.dumps(study_metadata,sort_keys=True)
    rig.animation_data.action=None
    for pose in rig.pose.bones:''')
new=new.replace("pose.rotation_mode='QUATERNION';pose.rotation_quaternion=(1,0,0,0)","pose.rotation_mode='QUATERNION';pose.rotation_quaternion=(1,0,0,0);pose.scale=(1,1,1)")
(O/'human_teamster_blend_proposed.py').write_text(new)
parts=[''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/tools/human_teamster_blend.py',tofile='b/tools/human_teamster_blend.py'))]
files={'tools/human_seated_study.py':O/'human_seated_study.py','data/humans/poses/w01/resident-driver-bindings.json':O/'resident-driver-bindings.json'}
for p in O.glob('*_1835-pose.json'):files['data/humans/poses/w01/'+p.name]=p
for dest,p in files.items():parts.append(''.join(difflib.unified_diff([],p.read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+dest)))
(O/'sit-drive-context.patch').write_text(''.join(parts))
