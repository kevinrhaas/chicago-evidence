# Glessner1904 civilian wardrobe: inspected evidence and remaining acquisition gap

2026-10-19. Outside-app research only. Existing person `glessner_john_j`, farm machinery executive, remains the identity. No coachman occupation, anonymous substitute, outfit, likeness or scene instance authored. No Blender, browser, app write, paid service or external message.

## What was actually inspected

### Chicago Tribune,26February1902: John B.Sherman portrait

Retained project record `cgs-2100-tribune-1902-sherman-portrait`; actual image `/workspace/chicago-images/prairie-1904/files/cgs-2100-tribune-1902-sherman-portrait.jpg` opened and visually read this assessment. Exact current bytes/SHA and full retained metadata in `inspected-source-records.json`.

Stable source/reproduction links: https://chicagology.com/chicagostreets/prairieavenue/2100prairie/ and https://chicagology.com/wp-content/themes/revolution-20/chicagoimages9/chicagotribunegraphic26feb1902sherman.jpg . Publication identified by retained project record as ChicagoTribune26February1902, caption “FOUNDER OF UNION STOCK-YARDS DEAD.—JOHN B.SHERMAN”. No printed page/plate number in retained record; do not fabricate one. **Publication date is not the portrait sitting date**. This is an obituary portrait of another named man, not Glessner and not a documented summer outing.

Visible: bust portrait inside ornamented oval; dark outer garment with folded lapel/collar edges; small light shirt-collar regions beside dark neckwear; cropped lower torso. The reproduction does not establish full coat length, buttons, rear vent, sleeve/cuff cut, trousers, shoes, hat, fabric fiber/weight, actual colors or summer use. Neckwear knot/type is not secure at this reproduction quality. It supports contemporary publication of layered civilian formal attire as context only. Do not transfer Sherman's beard, hair, anatomy or face to Glessner.

Rights: retained record classifies faithful reproduction of US1902publishednewspaper as public domain. That is a reasoned publication-date basis, not a new permission from Chicagology. It is the only inspected clothing image here with an exact1900–1904publicationdate and a clear pre1931USpublication rationale. It does NOT satisfy the requested summer full-garment or seated buggy reference on its own.

### Lowe collection mqc/75902: horses, vehicle and three men, catalogued c1900

Actual `/workspace/chicago-images/prairie-1904/files/a18-rba-lowe-glessner-stable-18th-c1900.jpg` opened and visually read. Holder item https://artic.contentdm.oclc.org/digital/collection/mqc/id/75902 ; catalog LoweDavidGarrardcollection2016.2,Box.FF4.2, unknownphotographer. Actual image shows a small wheeledvehicle atleft, severalhorses, and threestandingmen: nearestman's light longsleevedshirt with dark crossed backstraps, dark trousers/hat; middleman lightshirt/darkwaistcoat and trousers/hat; far-rightman's similar lightshirt/darkwaistcoat/hat. No seatedpassenger/driverpose is visible. These appear horse-handling/service activities, not evidence of Glessner's executive dress.

CRITICAL exclusions retained: catalog date is approximatec1900, library interval1895–1905, not exact1900–1904; catalog building attribution toGlessner is explicitly disputed underT2198 and geometry quarantined. No person identified. Leafedtrees suggest warmseason but do not date July or attest a summerwardrobe. Retained rights “public domain by age” does not itself establish firstpublication/authorship date for this unknownphotographer; holder asks publication inquiries. Therefore this assessment does **not** promote it to a newly cleared asset derivation reference. Textual observations only; no new crop/trace/garment asset derived. It cannot prove Glessner's horses, clothing, servants or1904fleet.

## Exact unfilled evidence need

No actually inspected, cleared1900–1904summer civilian clothing plate/fullfigure catalogpage or seatedbuggy driver/passenger photograph was obtained in this assessment. Do not mark that task complete. Existing SearsRoebuckCatalogueNo111,Spring1902 (metadataMarch1902) is a concrete next lead from sibling's retained riding-tack report: https://archive.org/details/sears-roebuck-catalogue-111 and https://archive.org/metadata/sears-roebuck-catalogue-111 . That report read fullOCR for saddle items, but no original clothingpagebytes retained here and no clothingplate viewed. Do not pretend a clothingitemnumber/page/cut was read. A pre1931USpublished1902catalog can provide a reasonedPD basis once actualtitle/date/pages verified; hostmetadata was reported to have no explicitrightsfield.

Current managednetwork status lists package/GitHub destinations, with no LOC/IA/Wikimedia or researchbrowser tool. Configuration state reportedunknown, not a fresh denial. No blocked destination request was made, no proxy/host bypass or repeatedartifactfetch attempted. This is an **unattempted access constraint**, not a claimed HTTP403 or automaticapproval rejection. Existing retained project records/images were fully usable. Next acquisition should use authorized research access and preserve exactmetadata/titlepage/printedpage/imagebytes/license rationale; no access change required merely to read this report.

## Bounded garment design brief (requirements, not historically verified cuts)

Use a separate civilian1904wardrobe profile on the matureGlessnerbody. An outer tailoredcoat with lapel geometry, separate shirt/collar/neckwear, trousers and closed shoes is a useful civilian layering candidate; the1902portrait supports only the visible upperlayers in general. Coatlength, buttoncount, lapelshape, waistshape, pocketstyle, trouserrise/cuffs, collarstyle, necktieform, summerfabric and hat remain unchosen pending actualperiodplates. Do not rename1835workerclothes or professionalcoachman'slivery. Do not infer darkwool, blackcolor or lightweightlinen from grayscale alone.

Engineering fit ranges may be used for a clearly labeled provisional toile, NOT sourcedgarment dimensions: shirtbodyclearance6–12mm, tailoredouterlayer12–25mm frombody before seatedpose; clothcollision tests must govern final ease, not these guesses. Collarfront must accommodate mature neck and jawmotion; sleeves must preserve elbowflexion and wrists; opencoatfront/hem need explicit seat/hipclearance. These ranges are authoredengineering allowances, not measurements from plates or Glessner's tailoring. No chest/waist/inseam measurement for him is known; use measuredmodel dimensions only, tagged reconstruction.

Separate attire variants by action: standing/walking first; passenger with seat/footboard/cushion and coatfold checks; owner-driver with reins/grip/armreach and clothmotion checks. Owner-driver is a reconstructed action while occupation stays executive. Existing1886horse/buggyownership and1887carriageouting text supplies historicalcontext but not a1904outfit, event, route, operator, specifichorse or survivingvehicle. Preserve existing identity/residence attestation separately from reconstructed appearance/action in the profile/card.

## Next concrete acceptance evidence

Acquire/view title/date and actualsummer1900–1904menscivilian catalog/plate; record exactprintedpage/item and visiblecut, material words, dimensions only where actuallyprinted. Obtain a separatelycleared actualseated civilianbuggyphoto inperiod, not servicegroomphotography reclassified as executive. Then author garmentpatternseams/layers against references, render front/profile/back/seated alongside images, and leave Glessner likeness/actualwardrobe unclaimed absent his cleared datedportrait or inventory. This report does not unblock productionwardrobe acceptance.
