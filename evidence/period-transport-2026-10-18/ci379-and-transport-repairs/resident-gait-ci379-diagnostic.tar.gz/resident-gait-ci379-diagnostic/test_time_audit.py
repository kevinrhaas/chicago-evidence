import json,struct,subprocess,sys,tempfile,unittest
from pathlib import Path
class Audit(unittest.TestCase):
 def run_case(self,start=0,end=1.2,speed=.6):
  doc={'accessors':[{'min':[start],'max':[end]}],'animations':[{'name':'walk','extras':{'speed_m_s':speed,'stance_fraction':.62,'cycle_duration_s':1.2},'samplers':[{'input':0}]}]}
  data=json.dumps(doc).encode();data+=b' '*((-len(data))%4);glb=struct.pack('<IIIII',0x46546c67,2,20+len(data),len(data),0x4e4f534a)+data
  with tempfile.TemporaryDirectory() as tmp:
   f=Path(tmp)/'synthetic-metadata-only.glb';f.write_bytes(glb)
   p=subprocess.run([sys.executable,str(Path(__file__).with_name('audit_human_animation_times.py')),str(f)],capture_output=True,text=True)
   return p.returncode,json.loads(p.stdout)
 def test_valid_serialized_metadata_only(self):
  code,r=self.run_case();self.assertEqual(code,0);self.assertTrue(r['passed']);self.assertIn('NOT decoded',r['scope'])
 def test_positive_frame_origin_refused(self):
  code,r=self.run_case(1/30,37/30);self.assertEqual(code,1);self.assertFalse(r['passed'])
 def test_missing_or_wrong_speed_refused(self):
  for speed in [None,1,.1]:
   code,r=self.run_case(speed=speed);self.assertEqual(code,1);self.assertFalse(r['passed'])
if __name__=='__main__':unittest.main()
