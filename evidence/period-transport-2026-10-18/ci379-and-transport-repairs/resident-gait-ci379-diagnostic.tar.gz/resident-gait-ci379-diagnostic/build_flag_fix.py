from pathlib import Path
import difflib
root=Path('/workspace/chicago/chicago/4d');out=Path('/workspace/shared/resident-gait-ci379-diagnostic')
p=root/'tools/human_export.py';old=p.read_text();new=old.replace('            export_frame_range=False,','''            export_frame_range=False,
            # Blender4.5.3 defaults to positive frame/30 timestamps. Only
            # independently verified authored rigs opt into zero-origin loops;
            # leave legacy fixture exporter kwargs exactly unchanged.
            **({'export_anim_slide_to_zero': True} if rigid_proof is not None else {}),''')
assert new!=old
(out/'human_export.proposed.py').write_text(new)
(out/'authored-zero-origin.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/tools/human_export.py',tofile='b/tools/human_export.py')))
