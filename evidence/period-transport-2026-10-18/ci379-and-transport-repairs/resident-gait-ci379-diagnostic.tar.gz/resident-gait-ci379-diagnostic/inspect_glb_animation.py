#!/usr/bin/env python3
"""Read actual artifact GLB clip metadata/timing; no Blender/browser or model changes."""
import json,sys,struct,hashlib
from pathlib import Path
for arg in sys.argv[1:]:
 p=Path(arg);data=p.read_bytes();magic,version,length=struct.unpack_from('<III',data);assert magic==0x46546c67 and version==2 and length==len(data)
 pos=12;doc=None;binary=b''
 while pos<len(data):
  size,kind=struct.unpack_from('<II',data,pos);chunk=data[pos+8:pos+8+size];pos+=8+size
  if kind==0x4e4f534a:doc=json.loads(chunk)
  elif kind==0x004e4942:binary=chunk
 out={'file':str(p),'sha256':hashlib.sha256(data).hexdigest(),'animations':[]}
 for animation in doc.get('animations',[]):
  a={'name':animation.get('name'),'extras':animation.get('extras'),'time_inputs':[]}
  for ix in sorted({s['input'] for s in animation['samplers']}):
   ac=doc['accessors'][ix];r={'accessor':ix,'count':ac['count'],'declared_min':ac.get('min'),'declared_max':ac.get('max')}
   view=doc.get('bufferViews',[])[ac['bufferView']] if 'bufferView'in ac else None
   if view and not view.get('extensions') and view.get('buffer',0)==0 and ac.get('componentType')==5126 and ac.get('type')=='SCALAR' and not ac.get('sparse'):
    start=view.get('byteOffset',0)+ac.get('byteOffset',0);stride=view.get('byteStride',4);times=[struct.unpack_from('<f',binary,start+i*stride)[0] for i in range(ac['count'])];r.update(decoded_min=min(times),decoded_max=max(times),decoded_span=max(times)-min(times),first=times[:3],last=times[-3:])
   else:r['decoded']='not attempted: compressed/unsupported accessor; declared bounds only'
   a['time_inputs'].append(r)
  out['animations'].append(a)
 print(json.dumps(out,indent=2))
