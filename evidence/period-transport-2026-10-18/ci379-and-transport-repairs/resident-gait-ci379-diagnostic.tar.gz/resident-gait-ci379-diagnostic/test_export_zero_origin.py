"""Actual exporter-call AST wiring, not Blender execution or export acceptance."""
import ast,unittest
from pathlib import Path
from types import SimpleNamespace
HERE=Path(__file__).parent
class Wiring(unittest.TestCase):
 def call(self,file,proof):
  tree=ast.parse(file.read_text());main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
  calls=[n for n in ast.walk(main) if isinstance(n,ast.Call) and ast.unparse(n.func)=='bpy.ops.export_scene.gltf'];self.assertEqual(len(calls),1)
  seen={}
  def capture(**kwargs):seen.update(kwargs)
  eval(compile(ast.fix_missing_locations(ast.Expression(calls[0])),str(file),'eval'),{'bpy':SimpleNamespace(ops=SimpleNamespace(export_scene=SimpleNamespace(gltf=capture))),'path':Path('/tmp/no-write.glb'),'rigid_proof':proof})
  return seen
 def test_legacy_fixture_kwargs_exactly_unchanged(self):
  old=self.call(Path('/workspace/chicago/chicago/4d/tools/human_export.py'),None);new=self.call(HERE/'human_export.proposed.py',None)
  self.assertEqual(old,new);self.assertNotIn('export_anim_slide_to_zero',new)
 def test_actual_authored_call_enables_only_supported_option(self):
  old=self.call(Path('/workspace/chicago/chicago/4d/tools/human_export.py'),{'proof':'stub'});new=self.call(HERE/'human_export.proposed.py',{'proof':'stub'})
  self.assertEqual(new.pop('export_anim_slide_to_zero'),True);self.assertEqual(old,new)
 def test_frame_math_not_export_proof(self):
  authored=list(range(1,38));self.assertEqual(len(authored),37)
  self.assertAlmostEqual(max(f/30 for f in authored),37/30)
  times=[(f-min(authored))/30 for f in authored];self.assertEqual(times[0],0);self.assertEqual(times[-1],1.2)
if __name__=='__main__':unittest.main()
