from pathlib import Path
import difflib
root=Path('/workspace/chicago/chicago/4d');out=Path('/workspace/shared/resident-gait-ci379-diagnostic');patch=[]
p=root/'tools/human_teamster_blend.py';old=p.read_text();new=old.replace("pose.keyframe_insert('rotation_quaternion',frame=frame)\n                pose.keyframe_insert('location',frame=frame)","# glTF preserves frame/30 time: walk must begin at0, end at1.2s.\n                keyframe=frame-1 if clip=='walk' else frame\n                pose.keyframe_insert('rotation_quaternion',frame=keyframe)\n                pose.keyframe_insert('location',frame=keyframe)")
assert old!=new
patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/tools/human_teamster_blend.py',tofile='b/tools/human_teamster_blend.py'))
(out/'walk-zero-origin-CONDITIONAL.patch').write_text(''.join(patch))
p=root/'tools/human_sole_contact.mjs';old=p.read_text();new=old.replace("throw Error('unique walk clip with expected duration required');", "throw Error('unique walk clip with expected duration required: '+JSON.stringify({expected_duration_s,observed:gltf.animations.map(c=>({name:c.name,duration_s:c.duration,track_time_bounds:c.tracks.map(t=>({name:t.name,first_s:t.times[0],last_s:t.times[t.times.length-1]}))}))}));")
assert old!=new
(out/'contact-diagnostics.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/tools/human_sole_contact.mjs',tofile='b/tools/human_sole_contact.mjs')))
