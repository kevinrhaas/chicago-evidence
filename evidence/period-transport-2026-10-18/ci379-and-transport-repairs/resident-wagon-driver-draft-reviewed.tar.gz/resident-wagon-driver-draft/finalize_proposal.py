import json,difflib,hashlib
from pathlib import Path
O=Path(__file__).parent
r=json.loads((O/'report.json').read_text());f=json.loads((O/'export/wagon-w01.json').read_text())['driver_furniture']
assert f['seat_surface_m']==[0,1.58,.65] and f['footboard_bounds_xz_m']==[-.425,.425,1.12,1.42]
d={'id':'wagon_w01_driver_bench_resident_study','scene':'1835','grade':'reconstructed','status':'outside-app proposal; no traffic/occupant acceptance','vehicle_variant':'wagon_w01_driver_bench_study','vehicle_parameters':'data/transport/studies/wagon-driver-bench.json','furniture_attested':False,'pose_kind':'sit_drive','coordinate_frame':'metres +Yup +Zforward','canonical_pose_status':'Source LBS global rest-to-pose matrices only; must convert/validate against canonical Blender rest axes','resident_bindings':[],'open_gates':['1835 furniture construction evidence','fastener/support strength','canonical Blender and final GLB pose equivalence','garment/shoe triangle contact','hands/palm grip and rein endpoints','continuous steering sweep','photographic quality and likeness']}
for row in r['residents']:
 p=O/(row['asset_id']+'-pose.json');d['resident_bindings'].append({'asset_id':row['asset_id'],'person_reference_id':row['person_reference_id'],'person_reference_grade':'reconstructed','body_sha256':row['body_sha256'],'pose_draft_file':p.name,'pose_draft_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'pelvis_head_m':row['pelvis_head_m'],'seat_surface_m':f['seat_surface_m'],'wrist_targets_m':row['socket_targets']['reins_grips'],'grip_status':'wrist heads, not yet palm grip sockets; finger closure unimplemented'})
(O/'resident-driver-bindings.json').write_text(json.dumps(d,indent=2)+'\n')
patch=(O/'wagon-driver-generator.patch').read_text()
text=(O/'wagon-driver-study.json').read_text();patch+=''.join(difflib.unified_diff([],text.splitlines(True),fromfile='/dev/null',tofile='b/data/transport/studies/wagon-driver-bench.json'))
(O/'wagon-driver-context.patch').write_text(patch)
