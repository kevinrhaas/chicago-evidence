"""Independent actual exported triangle/box SAT and support measurements."""
import json,struct,math,hashlib
from pathlib import Path
from solve import sub,dot,cross,norm
O=Path(__file__).parent
blob=(O/'export/wagon-w01.glb').read_bytes();length=struct.unpack_from('<I',blob,12)[0];g=json.loads(blob[20:20+length]);binary=blob[28+length:];f=g['extras']['driver_furniture']
parents={c:i for i,n in enumerate(g['nodes']) for c in n.get('children',[])}
def positions(n):
 out=[]
 for p in g['meshes'][n['mesh']]['primitives']:
  a=g['accessors'][p['attributes']['POSITION']];v=g['bufferViews'][a['bufferView']];off=v.get('byteOffset',0)+a.get('byteOffset',0)
  out.extend(struct.unpack_from('<3f',binary,off+12*i) for i in range(a['count']))
 return out
def world(v,i,deg):
 while True:
  n=g['nodes'][i]
  if n['name']=='vehicle_steer_front':
   a=math.radians(deg);x,y,z=v;v=[x*math.cos(a)+z*math.sin(a),y,-x*math.sin(a)+z*math.cos(a)]
  v=[x+t for x,t in zip(v,n.get('translation',[0,0,0]))]
  if i not in parents:return v
  i=parents[i]
def overlap(tri,lo,hi):
 c=[(a+b)/2 for a,b in zip(lo,hi)];h=[(b-a)/2 for a,b in zip(lo,hi)];v=[sub(p,c) for p in tri];e=[sub(v[(i+1)%3],v[i]) for i in range(3)];basis=[[1,0,0],[0,1,0],[0,0,1]];axes=basis+[cross(e[0],e[1])]+[cross(a,b) for a in e for b in basis]
 for axis in axes:
  if norm(axis)<1e-12:continue
  q=[dot(x,axis) for x in v];r=math.fsum(abs(x)*y for x,y in zip(axis,h))
  if min(q)>r+1e-9 or max(q)<-r-1e-9:return False
 return True
# Assert ALL authored part corner positions occur in actual merged export (float32 tolerance).
bodypoints=[];wheel=[]
for i,n in enumerate(g['nodes']):
 if 'mesh' not in n:continue
 chain=[];j=i
 while True:
  chain.append(g['nodes'][j]['name'])
  if j not in parents:break
  j=parents[j]
 if 'vehicle_body' in chain:bodypoints.extend(world(p,i,0) for p in positions(n))
 if any(x.startswith('vehicle_wheel_') for x in chain):wheel.append((i,positions(n)))
maxcorner=0
for p in f['parts']:
 for x in [p['min_m'][0],p['max_m'][0]]:
  for y in [p['min_m'][1],p['max_m'][1]]:
   for z in [p['min_m'][2],p['max_m'][2]]:maxcorner=max(maxcorner,min(math.dist([x,y,z],v) for v in bodypoints))
assert maxcorner<2e-7,maxcorner
checks=[]
for deg in [-8,-4,0,4,8]:
 collisions=[];count=0;min_gap=float('inf')
 for i,p in wheel:
  wp=[world(v,i,deg) for v in p]
  for part in f['parts']:
   lo,hi=part['min_m'],part['max_m'];wlo=[min(v[k] for v in wp) for k in range(3)];whi=[max(v[k] for v in wp) for k in range(3)]
   gap=math.sqrt(sum(max(lo[k]-whi[k],wlo[k]-hi[k],0)**2 for k in range(3)));min_gap=min(min_gap,gap)
   if gap>1e-9:continue
   for j in range(0,len(wp),3):
    count+=1
    if overlap(wp[j:j+3],lo,hi):collisions.append([g['nodes'][i]['name'],part['name'],j//3])
 checks.append({'steering_deg':deg,'wheel_furniture_triangle_intersections':len(collisions),'aabb_lower_bound_clearance_m':min_gap,'narrow_phase_triangles':count})
 assert not collisions,collisions[:3]
parts={p['name']:p for p in f['parts']};rail_top=g['extras']['parameters']['bed_top_m']+g['extras']['parameters']['body_m'][2]+.03
supports=[]
for p in f['parts']:
 if p['name'].startswith('driver_footboard_block'):
  supports.append({'name':p['name'],'floor_gap_m':p['min_m'][1]-.95,'board_underside_gap_m':parts['driver_footboard']['min_m'][1]-p['max_m'][1]})
assert all(abs(s['floor_gap_m'])<1e-12 and abs(s['board_underside_gap_m'])<1e-12 for s in supports)
report={'status':'actual exported geometry checks; no strength/cloth/selfcollision acceptance','glb_sha256':hashlib.sha256(blob).hexdigest(),'parts':len(parts),'part_corner_max_export_error_m':maxcorner,'bench_bottom_to_rail_top_gap_m':parts['driver_bench_plank']['min_m'][1]-rail_top,'footboard_support_contacts':supports,'steering_sample_checks':checks,'sampling_limitation':'Five sampled steering poses; not continuous swept-volume proof','baseline_glb_byte_identical':(O/'baseline/wagon-w01.glb').read_bytes()==(Path('/workspace/chicago/chicago/4d/renderers/web/transport/wagon/wagon-w01.glb')).read_bytes()}
(O/'geometry-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
