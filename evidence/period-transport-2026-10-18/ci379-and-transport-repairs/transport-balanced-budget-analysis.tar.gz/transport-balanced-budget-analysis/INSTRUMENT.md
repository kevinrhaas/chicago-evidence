# Prepared six-stand tree submission diagnostic — not run

Instrument: `measure_detail_trees_diagnostic.mjs`, an outside-app copy of the
existing `tools/measure_detail_ceilings.mjs` with its original documentation and
imports preserved. `HERE` explicitly points to the real application tools directory,
so relocation does not accidentally serve `/workspace/shared` as the app root.
Only JavaScript syntax was checked. No browser or application mutation occurred.

Root-authorized command after the active gate finishes (use a new output basename):

```
PW_EXECUTABLE=/usr/bin/chromium \
NODE_PATH=/workspace/shared/chicago-browser/node_modules \
DETAIL_PORT=4228 \
timeout --signal=TERM --kill-after=15s 240s \
  node /workspace/shared/transport-balanced-budget-analysis/measure_detail_trees_diagnostic.mjs \
  --only desktop --levels balanced --stepped \
  --json /tmp/e5-balanced-tree-six-stand.json \
  > /tmp/e5-balanced-tree-six-stand.log 2>&1
```

Default mirror is the existing `/workspace/chicago/site/4d`; `--mirror ABS_PATH`
can select a content-frozen published mirror. Add `--tree LABEL` to identify it.
Do not publish/rederive during the measurement. The invocation has a240-second
measurement timeout plus at most15 seconds to force-kill descendants during cleanup.
If a hard240-second wall deadline including cleanup is required, use225s instead
of240s. No promise of completion within that deadline is implied by syntax checks.

The script enforces published mode, desktop only, balanced only, all six default
stands, stepped rendering and an explicit JSON output. It rejects --price,
--flora, --against, optional South/Town stands and source mode to prevent accidental
expansion. It refuses to append to an existing incremental receipt file.

The six stands are Lake at Canal, Forks, open aerial, Lake and Market, West prairie
and Sauganash26m, in the original tool's ordering (frame stand last). Each ordinary
settle stops the animation loop and runs two production `a.step()` calls plus GPU
finish, as the source tool already supports. At each stand it reads the tree-on
frame, hides the existing `trees` group, settles/reads, restores the group in a
finally block and settles/reads again. No structure --price pass is run.

The tree submission delta is the actual whole-frame triangles/calls difference
between stable on and tree-hidden renders, including main and shadow contributions.
The independent restoration check requires **exactly zero** triangle and call
residual. A nonzero residual is an instrument failure and sets a nonzero exit code;
do not use that stand's subtraction as causal tree pricing. No tier threshold or
smoke assertion is changed. The existing tool still prints its budget diagnostic,
but this is not a normal CI smoke result or a replacement for its acceptance.

Every on/hidden/restored snapshot includes actual camera/player/detail, renderer
triangle/call/memory/program counts, tree stats (including grown LOD/shade census,
edgeThicket and youngInOpenings), flora stats/spread state, a separately labeled
owned-geometry census, and tree-bound texture UUID/dimensions/color-space plus
renderer texture count. Owned geometry totals are not called submitted triangles.
Texture/flora differences are recorded for diagnosis, not silently compensated.

Incremental concise stand summaries go to stdout/log. Full stand receipts are
appended immediately to `/tmp/e5-balanced-tree-six-stand.json.stands.jsonl`; the
normal complete JSON is written at successful sweep completion. A timeout retains
the rows already acquired. Avoid reusing that output basename on a later run.

The script tracks its own server and browser, closes them on SIGTERM/SIGINT or
uncaught exception, and retains the original normal page/browser/server shutdown.
`timeout` sends its signal to its owned process group and escalates after15 seconds
if cleanup stalls; do not kill unrelated shared Chromium processes by name.
