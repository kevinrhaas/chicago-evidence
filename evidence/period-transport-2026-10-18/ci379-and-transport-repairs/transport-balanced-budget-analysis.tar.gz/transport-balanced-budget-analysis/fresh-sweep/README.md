# Fresh published pricing sweep — prepared, not run

Script: `measure_fresh_sweep.mjs`, copied from the application's existing
`tools/measure_detail_ceilings.mjs`. Original documentation/import machinery is
preserved, with explicit real-app HERE at `/workspace/chicago/chicago/4d/tools`.
The only measurement mode allowed is both viewports, all three tiers and all six
default permanent budget stands. No --price, --flora, hidden-layer intervention,
source mode, --against, optional stands or filters are allowed.

Run only after root clears the active gate and freezes the published mirror:

```
PW_EXECUTABLE=/usr/bin/chromium \
NODE_PATH=/workspace/shared/chicago-browser/node_modules \
DETAIL_PORT=4231 \
timeout --signal=TERM --kill-after=15s 480s \
  node /workspace/shared/transport-balanced-budget-analysis/fresh-sweep/measure_fresh_sweep.mjs \
  --only both --stepped --json /tmp/e5-fresh-six-stand-two-viewport.json \
  > /tmp/e5-fresh-six-stand-two-viewport.log 2>&1
```

The existing published mirror is the default. `--mirror ABS_PATH` and `--tree LABEL`
may pin/label another already-published mirror. A new output basename is required
if the incremental JSONL already exists. The command has a480-second measurement
timeout, then at most15 seconds for force cleanup. For480 seconds including cleanup,
use465s instead. No completion duration is promised without execution.

The page URL includes `&keep-geometry=1`, matching normal smoke and retaining CPU
geometry for measurements. This does not waive triangle/call budgets or alter
scene, clocks or materials. The original stepped settle is unchanged: animation loop stopped; two production
`a.step()` calls followed by GPU finish. Camera placement, tier order and stand
ordering are unchanged. Every stand prints a current-stand record **before**
camera/settle work, then an actual cost row immediately after reading. Actual rows
are appended immediately to `JSON_OUTPUT.stands.jsonl`; complete normal-format JSON
is written at successful completion. Timed-out partial rows remain useful but do
not constitute a complete36-row sweep or establish the global maximum.

One nonmeasurement cleanup optimization: the page no longer rebuilds the boot tier
after its last recorded stand, because it is about to be closed. This avoids the
unmeasured final tier restoration that consumed time in earlier bounded probes.
All recorded measurements retain the exact original two-step settlement. The
tool's final heap snapshot therefore refers to the last measured tier, not a
restored boot tier; do not compare that heap number to older restored-tier receipts.

Normal pages/browser/server close after completion. Added SIGTERM/SIGINT and
uncaught-exception cleanup closes only the owned browser/server. The timeout
signals its process group and escalates after15 seconds; do not kill shared
Chromium processes by name. Source/stand/threshold files remain untouched.

Syntax was checked. No browser, CI, publisher, application edit or new cost result
was produced while preparing this script. Budget candidates must wait for actual
complete fresh results; the light floor remains1,190,000 under the current policy.
