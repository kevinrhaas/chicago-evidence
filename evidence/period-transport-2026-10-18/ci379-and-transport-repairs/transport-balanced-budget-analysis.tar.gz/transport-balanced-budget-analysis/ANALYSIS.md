# Balanced desktop ceiling failure at frozen e5

Read-only analysis. No browser, publisher, application mutation, threshold change,
CI dispatch or retry. Human preflight is running independently. Source refs:
`1b3c73d22016596d07b133019df24422c2b54790`, `a99f36238` and
`e5e726ba8d8030216ad7769f0878e99fe8dbe43d`.

## Observed failure and comparison

Frozen e5 run39175463315, stage5, log
`/workspace/shared/transport-split-evidence-e5e726ba8/39175463315-attempt-1.log`:
line496 records balanced2,545,975 versus2,535,000 at **West prairie**, a10,975
triangle overrun (about0.433%). West prairie itself draws271 calls. The reported
worst314 calls is a **different stand**, Lake and Market, below330. Do not conflate
the two worst-case poses.

|Tier|Prior 1b desktop worst triangles|Frozen e5 desktop worst triangles|Change|Ceiling|e5 margin|Prior/e5 worst calls|
|---|---:|---:|---:|---:|---:|---:|
|full|3,368,555|3,356,503|-12,052|3,400,000|43,497|319/319|
|balanced|2,517,414|2,545,975|+28,561|2,535,000|-10,975|314/314|
|light|1,091,251|1,135,749|+44,498|1,190,000|54,251|80/89|

All three worst-triangle stands are West prairie. Prior readings come from
`/tmp/transport-desktop-full-cancelled-39164186323.log`, lines808–810. That prior
whole run timed out and had other failures; these are its actual stage5 readings,
not a claim that the entire old suite passed. Its balanced stage5 ceiling did pass.

e5 balanced spread, same log line496:

|Stand|Triangles|Calls|
|---|---:|---:|
|West prairie|2,545,975|271|
|Lake at Canal|2,417,294|278|
|Lake and Market|2,299,343|314|
|Forks|2,049,469|227|
|Open aerial|1,764,711|223|
|Sauganash26m|1,729,100|235|

e5's exact-zero far-merge forward and restoration checks pass. Full and light
ceilings pass, no page errors are reported, and the human layer is mounted empty
with no human asset requests. This failure is not the earlier far-merge delta
assertion and is not a rendered resident fixture cost.

## Source changes that plausibly price the visible parcel

`1b → a99` changes the relevant tree renderer only in T-2807 commit
`65488b17c88eb1fca130d3d6774277ffb37beb40`, “woods in clumps and openings, and a
thicket at their prairie edge.” It changes `trees.js` by147 additions/5 deletions
and `tree-model.js` by50 additions/3 deletions. Exact diff is banked beside this
report as `woods-source-delta.patch`.

- Adds hazel, wild plum, hawthorn and gray dogwood edge-shrub architecture.
- Adds independent shrub caps3000/2200/1300 for full/balanced/light, edge and
  savanna planting, a mean-one clump field, and smaller young stems in openings.
- Offers an edge shrub before the old tree roll. This changes shared random-stream
  consumption and later planted jitter/species/geometry; a mean-one density field
  does not guarantee equal realized counts or equal visible triangles per tier.
- Coarse tree levels now retain the stoutest order-zero stem when the radius cut
  would otherwise remove every woody branch. That preserves visible shrub wood
  but adds coarse geometry relative to the former empty-wood case.

`main.js`, its numeric ceilings, `flora.js`, `terrain.js`, `tree-instances.js`,
the1835 scene record and flora data records are unchanged over this source comparison.
The old per-tier tree keep fractions and tree/thicket caps remain; new shrub caps
are additional. `a99 → e5` has **no renderer JS changes at all**. The transported
vehicle study assets are additive and not default-scene actors; no new consumer
was added to `main.js` in this comparison.

The observed tier pattern (full lower, balanced/light higher) is compatible with
T-2807's changed population, young-tree sizes and coarse geometry. It is stronger
evidence than a generic “the transport GLBs cost more” explanation. However, a
source diff and whole-scene totals **do not yet attribute the exact28,561** to
trees or divide the cost between shrubs, wood and changed tree placements.

## Stale tier / asynchronous sample alternatives

The smoke awaits `a.setDetail(level)`. The1835 applyDetail serial run awaits creation
of the replacement flora and trees and the street rebuild, then updates public
layer references. Tree instanced LOD selection updates synchronously for camera
distance in `tree-instances.js`. Thus a simple unawaited full-tree rebuild is not
established by source review. Numeric ceilings are read from the actual selected
tier, not an incorrectly hardcoded test fixture.

The camera-stand read still follows only two animation callbacks. Flora placement
and its worker/near-field landing can progress independently of visual clock;
the prior analysis showed that `a.step()` drains synchronous work. Async sampling
therefore remains a plausible confounder, not a demonstrated cause of this failure.
The fact that only the tightest tier breaches its tiny margin is also compatible
with genuine visible-parcel cost. Do not classify this red as inherited or timing
noise without a layer-attributed stable reading.

## Conditional budget arithmetic, not an applied recommendation

Prior balanced headroom:2,535,000−2,517,414=**17,586**.
At the current measured worst, adding30,000 gives2,565,000 and headroom**19,025**,
only1,439 more than the prior headroom. It also follows the existing documented
absolute-margin rule:2,545,975+16,806=2,562,781, rounded up to the next5,000 gives
**2,565,000**. This is a coherent candidate conscious re-budget for a priced visible
parcel, **conditional on** confirming stable six-stand/two-viewport worst readings
and attribution. It is not permission to replace a failed assertion with whatever
passes, and no number was changed here.

Full remains3,400,000. Light remains1,190,000; its floor is preserved. Call budgets
and call assertions remain unchanged. Do not retroactively edit old captured
measurements to make the history look like the new limit always applied.

## Next bounded probe after root clears the active gate

Use an already-published, content-frozen mirror with source/asset hashes. Existing
`tools/measure_detail_ceilings.mjs` covers the same **six permanent budget stands**:
Sauganash26m, Lake at Canal, Forks, open aerial, Lake and Market, West prairie.
The optional South/Town poses are additional diagnostics, not replacements for
those six. West prairie is exactly E−250,N−150,yaw90°,pitch−8°.

First sweep desktop and mobile at all tiers, with `--stepped` to stop the animation
loop and take two explicit steps plus GPU finish per settle. For example, after
root authorization, using the pinned mirror rather than publishing during a run:

```
PW_EXECUTABLE=/usr/bin/chromium NODE_PATH=/workspace/shared/chicago-browser/node_modules \
  node tools/measure_detail_ceilings.mjs --mirror FROZEN_MIRROR --only both \
  --stepped --price --json /tmp/t2807-six-stand-pricing.json
```

Read the tool's runtime budget before dispatch; split `--only desktop`/`mobile`
and `--levels` if required rather than start another unrestricted smoke. `--price`
prices structure-family roof cost at each tier's tightest stand; **it does not
isolate tree cost**. Its structure restore residual is useful readiness evidence.

For causal tree pricing, an outside copy should additionally capture actual
renderBufferDirect main/shadow per-layer deltas at all six stands, with on/hidden/
restored `trees` frames and strict zero restoration residual. Capture tree counters,
near/mid/far/shade counts, edgeThicket/youngInOpenings, flora spread counters,
actual detail level/camera and total renderer stats. Do not subtract an unstable
whole frame or count the whole tree-owned geometry as submitted geometry.

If still ambiguous, compare an isolated frozen e5 server whose **only** in-memory
module substitutions are the pre-T2807 `trees.js` and `tree-model.js`, versus e5's
modules, at the same stands/tiers/mirror assets. This is a diagnostic source-server
comparison, not a published site, repository mutation or baseline gate waiver.
Require unchanged non-tree layer counts and zero restore residuals before assigning
the net difference to T-2807. Do not run this extra comparison if the first
layer-attributed results already settle the question.

## Locations relevant to a later reviewed re-budget

- Runtime authority: `renderers/web/js/main.js` DETAIL.balanced.triangles near930.
  The associated `measured` string near934 and the historic margin explanation
  above DETAIL.full near787 document the policy. Append a dated new rationale;
  preserve prior dated readings.
- `tools/smoke_renderer.mjs` reads `a.detailLevels[level].triangles`; its strict
  worst-stand comparison follows the table. Do not weaken its assertion.
- `tools/measure_detail_ceilings.mjs` reads the same runtime table; it has no
  independent2535000 constant to tune.
- `renderers/web/js/trees.js` near2843 and
  `tools/timber_detail_baseline.json.rebanked_t2766` refer historically to the
  old2,535,000 and its headroom. Preserve the historical note; append current
  pricing provenance if relevant rather than falsifying the old observation.
- `docs/STATUS.md`, `docs/ROADMAP.md`, the owning ticket evidence and a concise
  changelog entry should state the actual measured parcel cost and remaining
  margins. Regenerated published `main.js` mirrors follow the normal publisher.
- Existing `docs/RESEARCH/glessner-performance-T-2227/*` and
  `docs/RESEARCH/glessner-copper-T-2220/*` contain old2535000 receipts. They are
  historical artifacts, **not constants to overwrite**.

No threshold, renderer or fixture change is part of this report.
