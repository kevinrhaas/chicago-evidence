# Stage5 fresh-frame settlement review

No application edits or new execution. Proposed patch changes only the stage5
detail sweep's local settle helper: retain its two animation callbacks, then call
the existing production `a.step()` before reading stats. Stand IDs, tier order,
ceiling constants and exact assertions are unchanged.

## Why this is the correct instrument boundary

`main.js::stats()` reads `renderer.info.render`, which describes the last submitted
render, not necessarily the current layer/camera state. `tick()` only calls
`confidence.render()` while the welcome gate is up when forced, capturing, or
`gateFrame.due()` reports a changed signature. Two requestAnimationFrame callbacks
do not promise a render was submitted or that sliced placement work is complete.

`a.step()` is explicitly the test API for a frame that must not race the loop:
it restores the governor's rest policy and calls `tick(Infinity, true)` under the
default `stepFloraSpread=false`. `Infinity` drains synchronous placement work;
`true` bypasses the gate's unchanged-frame hold. Renderer triangle/call counters
are updated synchronously by submission, so GPU finish is unnecessary merely to
read those counters. The existing callbacks remain useful for already scheduled
callbacks/worker replies; the final step then establishes the current frame.

This guarantees a fresh forced frame and drains work the step API promises to
drain. It does **not** promise all network images, texture residency uploads or
arbitrary worker jobs are globally finished. Layer/counter snapshots and reverse
restore proofs remain valuable. `gate-frame.js` watches many state changes but is
a draw-skipping optimization, not a general readiness handshake for measurements.

The source proof is sufficient to improve the sampling boundary; it does not
identify which old render or partial layer produced the exact prior CI total.

## New actual receipts and attribution limits

The first bounded stepped sweep retained four stable rows before timeout:

|Balanced desktop stand|Triangles|Calls|Submitted tree triangles/calls|Restore triangles/calls|
|---|---:|---:|---:|---:|
|Lake at Canal|2,416,472|278|216,322 /9|0 /0|
|Forks|2,103,992|232|256,978 /9|0 /0|
|Open aerial|1,764,711|223|431,330 /6|0 /0|
|Lake and Market|2,299,343|314|226,658 /9|0 /0|

Separate West prairie balanced receipt completed at **2,607,952 triangles,
271 calls**, versus frozen-e5 normal CI's2,545,975: **+61,977 whole-scene triangles**.
Actual tree hidden subtraction was250,248 triangles /9 calls; restoration was
exactly0 /0. Tree count and geometry are stable for that measured intervention.
Recorded flora spread counters did not change between on/restored snapshots;
this is not evidence that a spread landing during that interval caused the cost.

Do not conflate:

- **28,561**: old1b versus e5 balanced worst from two normal-CI readings; candidate
  parcel/integration change, not yet isolated tree attribution.
- **61,977**: whole-scene stepped-versus-normal-CI method difference at e5 West;
  not all new trees and not an added vehicle cost.
- **250,248**: total submitted tree-group cost at the stepped West stand; not
  T-2807's incremental tree cost.

The source hashes match e5's tree modules, while current main differs only in human
role-card handling and no figures draw. This supports a method/readiness difference
rather than a new visible human, but exact per-layer old-CI counters are absent.
To isolate T-2807's net cost requires the pre-parcel tree modules measured with
the same fresh-frame method or equivalent stable per-layer before evidence.

The active full/light West probe's already written full row is3,449,919 triangles,
301 calls, tree346,898 /9, restore0 /0. It exceeds3,400,000 by49,919. That is a new
real receipt to include in pricing; this report does not declare the still-running
whole probe complete or infer a light result.

## Budget consequence

The earlier conditional +30,000 balanced candidate priced the stale/normal-CI
2,545,975 reading. It is insufficient for the2,607,952 fresh stepped reading and
must not be presented as the final re-budget. The fresh-frame correction exposes
the actual cost to price; do not revert freshness merely to retain old numbers.

Keep all strict bars until the fresh-frame six-stand/two-viewport worst is known.
Then a conscious measured visible-parcel re-budget may follow the standing rule,
with separate old-parcel cost and instrument-correction explanations. Do not
attribute the entire method gap to T-2807 or call restored headroom a waiver.
Preserve the light floor and its explicit authorization rules, call budgets and
historical receipts. No budget change is proposed in this patch.
