from pathlib import Path
import difflib
repo=Path('/workspace/chicago');out=Path('/workspace/shared/resident-gait-ci379-diagnostic')
checkpath='chicago/4d/tools/check.sh';check=(repo/checkpath).read_text()
anchor='step "Portable human contract holds; every human GLB and instance is held to it (T-1786)"'
assert anchor in check
check=check.replace(anchor,'step "Authored human serialized animation bounds reject malformed metadata and nonzero origins" \\\\'+"\n"+'  python3 tools/test_human_animation_times.py'+"\n\n"+anchor)
# Ensure shell continuation has exactly one backslash.
check=check.replace('origins" \\\\','origins" \\')
workflowpath='.github/workflows/chicago-4d-humans.yml';workflow=(repo/workflowpath).read_text()
anchor='      - name: Validate the actual new GLB containers'
assert anchor in workflow
addition='''      - name: Audit declared resident animation time bounds before browser loading
        working-directory: chicago/4d
        run: |
          set -euo pipefail
          python3 tools/audit_human_animation_times.py \\
            assets/humans/{bardwell_otis_1835,dufresne_joseph_1835,flynn_martin_1835}.lod*.glb \\
            assets/humans/web/{bardwell_otis_1835,dufresne_joseph_1835,flynn_martin_1835}.lod*.glb \\
            | tee /tmp/teamster-studies/declared-animation-times.jsonl

'''
workflow=workflow.replace(anchor,addition+anchor)
patch=[]
for name,new in [('chicago/4d/tools/audit_human_animation_times.py',(out/'audit_human_animation_times.py').read_text()),('chicago/4d/tools/test_human_animation_times.py',(out/'test_time_audit.py').read_text()),(checkpath,check),(workflowpath,workflow)]:
 old=(repo/name).read_text() if (repo/name).exists() else ''
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+name if old else '/dev/null',tofile='b/'+name))
 if name==checkpath:(out/'check.proposed.sh').write_text(new)
 if name==workflowpath:(out/'workflow.proposed.yml').write_text(new)
(out/'timing-audit-integration-REPO-ROOT.patch').write_text(''.join(patch))
