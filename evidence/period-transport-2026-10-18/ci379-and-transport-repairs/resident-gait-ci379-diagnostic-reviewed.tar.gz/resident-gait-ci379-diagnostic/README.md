# CI379 sole-duration diagnosis and authored-only fix draft

Actual run39177201156 log1588 rejects the first published resident GLB in sampleSoleContact before metadata/contact checks: `unique walk clip with expected duration required`. The combined error does not itself disclose whether the cause is name count or duration. No actual resident artifact was obtained. No resident duration/contact is claimed measured.

Actual existing fixture GLB was stdlib-decoded: idle time inputs start0.0333333350718 and end2.03333330154, spanning2s. This establishes the portable exporter preserved positive frame1/30 timing on that fixture. Root's next CI must prove the resident result. No thresholds should change.

## Pinned official Blender4.5.3 source actually retrieved/read

All below use https://raw.githubusercontent.com/blender/blender/v4.5.3/scripts/addons_core/io_scene_gltf2/ prefix. Local copies are retained beside this report.

- `__init__.py` lines813–820: operator `export_anim_slide_to_zero` BoolProperty, description “Set all glTF animation starting at0.0s. Can be useful for looping animations”, **default=False**. Line1246 wires property to `gltf_anim_slide_to_zero`.
- `blender/exp/animation/action.py` lines296–310: if slide-to-zero enabled and start_frame>0, ACTIONS mode calls add_slide_data(start_frame,obj_uuid,action.name,…).
- `blender/exp/animation/anim_utils.py` lines89–93: records slide[uuid][key]=start_frame.
- `blender/exp/animation/keyframes.py` lines12–15: time = frame/(fps*fps_base).
- `blender/exp/animation/sampled/armature/sampler.py` lines100–110: if action has slide entry, subtract recorded start frame then recompute seconds with fps*fps_base before emitting times.

Current authored builder keys walk frames1..37 at30fps, representing37 inclusive samples of1.2s **span**. Without slide, the emitted timestamp formula implies1/30..37/30, whose max is1.2333333; Three clip.duration uses last time, not max-minus-min. With supported slide enabled, formula becomes0..36/30=1.2. This is a source-grounded diagnosis, awaiting actual resident metadata/next CI confirmation.

## Proposed integration

Apply **authored-zero-origin-and-diagnostics.patch** from4d root after source freeze. It adds `export_anim_slide_to_zero=True` only when independently verified authored `rigid_proof is not None`. Legacy fixture call omits this keyword entirely, preserving its existing kwargs/timestamps. Portable exporter currently creates that proof only for authored provenance opt-in after actual source-state verification. No geometry/scale/skin thresholds change.

The same patch includes viewer_survey's diagnostics-only error: expected duration/tolerance, observed walk count, every loaded clip name/duration and each track endpoint. No guard changes.

`walk-zero-origin-CONDITIONAL.patch` is an EARLIER ALTERNATIVE builder-key change; **do not apply it with the supported exporter-option fix**. No builder change is needed with the supported flag.

## Focused verification actually run

`python test_export_zero_origin.py`:3 tests pass. Tests extract/evaluate the real proposed export-call AST under a fake operator: fixture kwargs exactly equal existing call; authored kwargs differ only by supported True flag; arithmetic verifies37 keys/1.2s zero-origin span. This is wiring/math verification, not actual BPy export execution. Combined patch `git apply --check` passes. No local Blender/browser/app edits.

`audit_human_animation_times.py` is a proposed pre-browser CI command. Run against the actual freshly emitted resident master and web GLBs, e.g. `python3 tools/audit_human_animation_times.py assets/humans/{bardwell_otis_1835,dufresne_joseph_1835,flynn_martin_1835}.lod*.glb assets/humans/web/{bardwell_otis_1835,dufresne_joseph_1835,flynn_martin_1835}.lod*.glb`. It emits one JSON line per file: hash, names, unique serialized time min/max bounds and three motion extras; requires walk0..1.2 and matching .6/.62/1.2. Compressed accessors are explicitly metadata-only evidence, followed by actual loaded sampler in browser. Root owns workflow wiring. This helper has no GLB writes; fixture is expected to fail its new authored-only gates.

## Hardened audit integration follow-up

`timing-audit-integration-REPO-ROOT.patch` applies from repository root, unlike the earlier exporter patch which applies from4d. It contains the actual helper, portable `tools/test_human_animation_times.py`, a focused check.sh step and a pre-browser workflow step that audits all24 newly emitted resident master/web GLBs into `/tmp/teamster-studies/declared-animation-times.jsonl` (existing artifact directory).

The helper now returns bounded error receipts for malformed/unreadable input instead of assertion/index tracebacks. It requires FLOAT SCALAR positive-count time metadata; singleton finite numeric ordered nonnegative min/max; valid nonboolean integer accessor indices; nonempty animations/samplers; exactly one walk; and finite matching motion extras. Missing/bool/nonfinite bounds/counts/indices are refused. No args returns usage/exit2. Multiple files each receive a receipt, with exit1 if any fail. Rejected walk timing includes its actual serialized bound pairs for diagnosis. JSON NaN/Infinity tokens are rejected. No binary data is decoded or modified.

Ten actual-helper tests pass. The tests import the real helper, use temporary GLB containers only for metadata behavior and disable bytecode writes. They check malformed/empty input, bounds/order/origin/endpoints, extras, accessor type/count/index, CLI noargs/missing files, mixed success/error receipts and no writes to the input directory. They do not establish actual resident animation. Proposed shell syntax and workflow YAML parse pass; root-relative patch apply-check passes. Authored-only exporter fix and fixture kwargs remain unchanged.
