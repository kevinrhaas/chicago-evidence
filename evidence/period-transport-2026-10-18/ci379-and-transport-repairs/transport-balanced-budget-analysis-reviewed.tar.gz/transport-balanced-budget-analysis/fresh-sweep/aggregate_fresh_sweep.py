#!/usr/bin/env python3
"""Validate and aggregate exactly36 split fresh diagnostic rows. No renderer work."""
import argparse,json,math
from pathlib import Path
VIEWPORTS=('desktop 1280x800','mobile 390x780')
LEVELS=('full','balanced','light')
STANDS=('lake_at_canal','the_forks','from_above','lake_and_market','prairie_west','sauganash_26')
EXPECTED={(v,l,s) for v in VIEWPORTS for l in LEVELS for s in STANDS}
CAPS={'full':3400000,'balanced':2535000,'light':1190000}
MARGINS={'full':18059,'balanced':16806}

def load(path,expected_count,label):
    rows=[]
    for line_no,line in enumerate(path.read_text().splitlines(),1):
        if not line.strip():continue
        try:r=json.loads(line)
        except json.JSONDecodeError as e:raise ValueError(f'{path}:{line_no}: invalid JSON') from e
        if not isinstance(r,dict):raise ValueError(f'{path}:{line_no}: row must be object')
        key=(r.get('viewport'),r.get('level'),r.get('stand'))
        if key not in EXPECTED:raise ValueError(f'{path}:{line_no}: unexpected identity {key}')
        for name in ('triangles','calls'):
            n=r.get(name)
            if isinstance(n,bool) or not isinstance(n,(int,float)) or not math.isfinite(n) or n<0 or n!=int(n):
                raise ValueError(f'{path}:{line_no}: {name} must be finite nonnegative integer')
        rows.append({**r,'diagnostic_split':label,'receipt_file':str(path),'receipt_line':line_no})
    if len(rows)!=expected_count:raise ValueError(f'{path}: requires exactly{expected_count} rows, found{len(rows)}')
    return rows

def aggregate(first,continuation):
    rows=load(first,27,'initial480s_partial')+load(continuation,9,'mobile_continuation')
    bykey={}
    for r in rows:
        k=(r['viewport'],r['level'],r['stand'])
        if k in bykey:raise ValueError(f'duplicate stand receipt {k}')
        bykey[k]=r
    if set(bykey)!=EXPECTED:raise ValueError(f'coverage mismatch: missing={sorted(EXPECTED-set(bykey))}, unexpected={sorted(set(bykey)-EXPECTED)}')
    first_keys={(r['viewport'],r['level'],r['stand']) for r in rows[:27]}
    expected_first={(v,l,s)for v in VIEWPORTS for l in LEVELS for s in STANDS if v==VIEWPORTS[0] or l=='full' or l=='balanced' and s in STANDS[:3]}
    if first_keys!=expected_first:raise ValueError('initial27 coverage differs from recorded split; do not silently combine a different sweep')
    ordered=[bykey[(v,l,s)]for v in VIEWPORTS for l in LEVELS for s in STANDS]
    summary={}
    for l in LEVELS:
        group=[r for r in ordered if r['level']==l]
        maxtri=max(r['triangles']for r in group);maxcalls=max(r['calls']for r in group)
        where=lambda field,value:[{'viewport':r['viewport'],'stand':r['stand']}for r in group if r[field]==value]
        proposal=CAPS[l] if l=='light' else math.ceil((maxtri+MARGINS[l])/5000)*5000
        summary[l]={'maximum_triangles':maxtri,'triangle_locations':where('triangles',maxtri),'maximum_calls':maxcalls,'call_locations':where('calls',maxcalls),'current_triangle_cap':CAPS[l],'current_headroom':CAPS[l]-maxtri,'proposed_triangle_cap':proposal,'proposal_delta':proposal-CAPS[l],'proposal_headroom':proposal-maxtri,'preserved_absolute_margin':MARGINS.get(l),'rounding_rule':'unchanged light floor'if l=='light'else'ceil((measured global worst + original absolute margin)/5000)*5000','calls_cap_unchanged':330,'calls_within_cap':maxcalls<=330}
    return{'format':'fresh_split_diagnostic_sweep_v1','coverage':{'expected':36,'actual_unique':len(bykey),'viewports':VIEWPORTS,'levels':LEVELS,'stands':STANDS},'scope':'Split diagnostic runs using forced two production steps and GPU finish, keep-geometry=1. Initial run timed out after27 rows; continuation supplies9. Not one completed CI smoke run; no claim of exact causality relative to normal unforced CI samples.','render_source_identity':'Root reports379 rendering modules match frozen e5; aggregator validates numeric coverage only and does not independently attest module hashes.','source_receipts':[str(first),str(continuation)],'rows':ordered,'tiers':summary,'proposal_status':'Arithmetic candidate only; no app/budget change. Full/balanced preserve original absolute margins; light remains1190000. Actual scene/period/photographic acceptance is separate.'}

def markdown(d):
    out=['# Complete split fresh pricing diagnostic','',d['scope'],'','Validated **36 unique finite rows**, exactly2 viewports ×3 tiers ×6 stands.','', '|Tier|Worst triangles|Triangle location(s)|Worst calls|Call location(s)|Current cap|Candidate cap|Candidate headroom|','|---|---:|---|---:|---|---:|---:|---:|']
    loc=lambda items:'; '.join(x['viewport']+' / '+x['stand']for x in items)
    for l,r in d['tiers'].items():out.append(f"|{l}|{r['maximum_triangles']:,}|{loc(r['triangle_locations'])}|{r['maximum_calls']}|{loc(r['call_locations'])}|{r['current_triangle_cap']:,}|{r['proposed_triangle_cap']:,}|{r['proposal_headroom']:,}|")
    out+=['','Arithmetic candidates preserve18,059 full /16,806 balanced headroom before rounding up to5,000. Light remains1,190,000; calls remain330. No constants are changed.','','|Viewport|Tier|Stand|Triangles|Calls|Split|','|---|---|---|---:|---:|---|']
    for r in d['rows']:out.append(f"|{r['viewport']}|{r['level']}|{r['stand']}|{r['triangles']:,}|{r['calls']}|{r['diagnostic_split']}|")
    out+=['',d['render_source_identity'],'',d['proposal_status'],'']
    return '\n'.join(out)

def main():
    p=argparse.ArgumentParser();p.add_argument('--first',type=Path,required=True);p.add_argument('--continuation',type=Path,required=True);p.add_argument('--json',type=Path,required=True);p.add_argument('--markdown',type=Path,required=True);a=p.parse_args()
    try:d=aggregate(a.first,a.continuation)
    except (ValueError,OSError) as e:p.exit(1,f'REJECTED: {e}\n')
    a.json.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n');a.markdown.write_text(markdown(d));print(json.dumps({'validated_unique_rows':36,'tiers':d['tiers'],'json':str(a.json),'markdown':str(a.markdown)},indent=2))
if __name__=='__main__':main()
