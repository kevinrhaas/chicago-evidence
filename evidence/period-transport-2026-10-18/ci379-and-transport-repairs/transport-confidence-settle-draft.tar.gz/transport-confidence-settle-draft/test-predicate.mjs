import assert from 'node:assert/strict';import{sceneCaptureReady,advanceSceneSettle}from'./predicate.mjs';
const old={camera:{position:[122.5,2.555,100]},geometry:{fingerprint:'fd56ba31'},flora:{inFlight:true,landings:30,drained:30,abandoned:6,passes:{near:22,far:22}},textureResidency:{pending:0,resident:0}};
const landed={...old,geometry:{fingerprint:'9c08ad25'},flora:{inFlight:false,landings:32,drained:32,abandoned:6,passes:{near:23,far:23}}};
assert.equal(sceneCaptureReady(old),false);assert.equal(sceneCaptureReady(landed),true);
let s=advanceSceneSettle(null,old);assert.equal(s.settled,false);for(let i=0;i<3;i++){s=advanceSceneSettle(s,landed);assert.equal(s.settled,false);}s=advanceSceneSettle(s,landed);assert.equal(s.settled,true);
for(const changed of[{...landed,flora:{...landed.flora,inFlight:true}},{...landed,textureResidency:{pending:1}},{...landed,geometry:{fingerprint:'new'}},{...landed,camera:{position:[123,2.555,100]}}])assert.equal(advanceSceneSettle(s,changed).settled,false);
assert.equal(sceneCaptureReady({...landed,flora:{...landed.flora,inFlight:null}}),false);assert.equal(sceneCaptureReady({...landed,flora:{...landed.flora,passes:null}}),false);
// A single quiet frame between late arrivals must never complete readiness.
let p=null;for(const state of[landed,old,landed,old,landed]){p=advanceSceneSettle(p,state);assert.equal(p.settled,false);}
console.log('PASS observed in-flight/completed states, four-frame semantic stability, late work/camera/geometry/pending resets and malformed-state refusal');
