// SPDX-License-Identifier: GPL-3.0-or-later
export function sceneCaptureReady(state){
 const f=state?.flora,t=state?.textureResidency;
 return f?.inFlight===false&&['landings','drained','abandoned'].every(k=>Number.isInteger(f[k])&&f[k]>=0)&&['near','far'].every(k=>Number.isInteger(f.passes?.[k])&&f.passes[k]>=0)&&typeof state?.geometry?.fingerprint==='string'&&!!state.camera&&(t===null||Number.isInteger(t?.pending)&&t.pending===0);
}
export function advanceSceneSettle(previous,state){
 if(!sceneCaptureReady(state))return{key:null,unchanged:0,settled:false};
 // Only semantic counters: never frame/timing counters which advance forever.
 const key=JSON.stringify({camera:state.camera,geometry:state.geometry,flora:state.flora,textureResidency:state.textureResidency});
 const unchanged=previous?.key===key?previous.unchanged+1:1;
 return{key,unchanged,settled:unchanged>=4};
}
