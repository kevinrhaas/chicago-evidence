from pathlib import Path
import difflib
root=Path('/workspace/chicago/chicago/4d');out=Path('/workspace/shared/resident-skin-root-proposal');p=root/'tools/human_teamster_blend.py';old=p.read_text()
needle="        obj.parent = rig\n        mod = obj.modifiers.new('skin','ARMATURE')"
new=old.replace(needle,"        # Authored mesh stays a scene root. The Armature modifier binds the rig;\n        # parenting an identity mesh under the rig triggers glTF non-root warnings.\n        # Both objects are authored at identity; actor motion belongs to their group.\n        mod = obj.modifiers.new('skin','ARMATURE')")
assert new!=old
(out/'human_teamster_blend.proposed.py').write_text(new)
(out/'authored-root-mesh-CONDITIONAL.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/tools/human_teamster_blend.py',tofile='b/tools/human_teamster_blend.py')))
