"""Actual nested builder function under explicit fake BPy; no Blender execution."""
import ast,math,unittest
from pathlib import Path
from types import SimpleNamespace as NS
HERE=Path(__file__).parent
class Factory:
 def __init__(self,fn):self.fn=fn;self.values={}
 def new(self,*args,**kwargs):
  value=self.fn(*args,**kwargs);self.values[kwargs.get("name",args[0] if args else None)]=value;return value
 def __getitem__(self,key):return self.values[key]
def object_mesh(source):
 tree=ast.parse(source.read_text());f=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='object_mesh')
 class Mesh:
  def __init__(self,name):self.materials=[];self.name=name
  def from_pydata(self,points,edges,faces):
   self.points=points;self.faces=faces;self.loops=[NS(vertex_index=i)for face in faces for i in face];offset=0;self.polygons=[]
   for face in faces:self.polygons.append(NS(loop_indices=list(range(offset,offset+len(face)))));offset+=len(face)
  def update(self):self.uv_layers=Factory(lambda **k:NS(data=[NS(uv=None)for _ in self.loops]))
 class Object:
  def __init__(self,name,mesh):
   self.name=name;self.mesh=mesh;self.parent=None;self.groups={};self.mods=[]
   def group(name):
    weights={};self.groups[name]=weights;return NS(add=lambda ids,w,mode:weights.update({i:w for i in ids}))
   def modifier(name,kind):
    m=NS(name=name,type=kind,object=None);self.mods.append(m);return m
   self.vertex_groups=Factory(group);self.modifiers=Factory(modifier)
 rig=NS(name='c4d_armature');bpy=NS(data=NS(meshes=Factory(Mesh),objects=Factory(Object)))
 ns={'bpy':bpy,'contract':{'skeleton':{'bones':[['foot_l',None],['ball_l','foot_l']]}},'rig':rig,'materials':{'footwear':'original material'},'xyz':lambda v:(v[0],-v[2],v[1])}
 exec(compile(ast.fix_missing_locations(ast.Module(body=[f],type_ignores=[])),str(source),'exec'),ns)
 linked=[];col=NS(objects=NS(link=linked.append))
 obj=ns['object_mesh']('shoe',[(.1,0,-.1),(.2,0,-.1),(.1,0,.2)],[(0,1,2)],[(0,0),(1,0),(0,1)],[{'foot_l':1},{'foot_l':.5,'ball_l':.5},{'ball_l':1}],'footwear',col)
 return obj,rig,linked
# Pure 2D homogeneous FK with translation/rotation, standing in for the sagittal
# subspace. It is sufficient for the explicit identity-parent cancellation claim.
def mul(a,b):return [[sum(a[i][k]*b[k][j]for k in range(3))for j in range(3)]for i in range(3)]
def tx(x,y,a=0):return [[math.cos(a),-math.sin(a),x],[math.sin(a),math.cos(a),y],[0,0,1]]
def inv(a):
 r=[[a[0][0],a[1][0],0],[a[0][1],a[1][1],0],[0,0,1]];r[0][2]=-sum(r[0][k]*a[k][2]for k in range(2));r[1][2]=-sum(r[1][k]*a[k][2]for k in range(2));return r
def p(a,v):return [sum(a[i][j]*v[j]for j in range(3))for i in range(3)]
class Tests(unittest.TestCase):
 def test_actual_function_changes_only_mesh_parent(self):
  old,oldrig,_=object_mesh(Path('/workspace/chicago/chicago/4d/tools/human_teamster_blend.py'));new,rig,linked=object_mesh(HERE/'human_teamster_blend.proposed.py')
  self.assertIs(old.parent,oldrig);self.assertIsNone(new.parent);self.assertEqual(linked,[new]);self.assertEqual(old.mesh.points,new.mesh.points);self.assertEqual(old.mesh.faces,new.mesh.faces);self.assertEqual(old.groups,new.groups);self.assertEqual(old.mesh.materials,new.mesh.materials);self.assertIs(new.mods[0].object,rig);self.assertEqual(new.mods[0].type,'ARMATURE')
 def test_identity_parent_lbs_fk_equivalence_and_actor_group_motion(self):
  # skin world = meshWorld * inverse(meshWorld) * jointWorld * inverseBind * v.
  v=[.12,-.08,1];rest=tx(.2,1.3,.15);ibm=inv(rest)
  for phase in range(101):
   joint=mul(rest,tx(0,0,.5*math.sin(phase*.1)));actor=tx(2,.5,.7);worldjoint=mul(actor,joint)
   rigidentity=tx(0,0);meshidentity=tx(0,0)
   oldmesh=mul(mul(actor,rigidentity),meshidentity);newmesh=mul(actor,meshidentity)
   old=p(mul(mul(mul(oldmesh,inv(oldmesh)),worldjoint),ibm),v);new=p(mul(mul(mul(newmesh,inv(newmesh)),worldjoint),ibm),v)
   self.assertEqual(old,new)
 def test_nonidentity_parent_requires_additional_bind_analysis(self):
  # Reparenting a nonidentity transform without preserving world changes a point;
  # this proposal must not be generalized to arbitrary authored/imported rigs.
  self.assertNotEqual(p(tx(1,0),[.1,.2,1]),p(tx(0,0),[.1,.2,1]))
if __name__=='__main__':unittest.main()
