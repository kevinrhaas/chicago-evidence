# Conditional authored mesh-root hierarchy correction

Read-only diagnosis; no app/fixture changes or Blender/browser execution. CI379 reports24 exported files each with exactly7 `NODE_SKINNED_MESH_NON_ROOT` warnings,0 errors (e.g. log1468–1483). That log contains aggregate codes, **not JSON pointers**, so exact offending resident node indices/paths have not been inspected. Actual loaded rest/gait comparison did not finish. These warnings are not labeled harmless.

## Source-grounded cause candidate

Current `human_teamster_blend.py` creates a fresh factory-default armature object without object transforms, pre-bakes metric/source-axis conversion into mesh vertex coordinates via xyz(), and creates each mesh as a new identity object. In nested object_mesh(), line238 sets `obj.parent=rig`, then adds the Armature modifier whose object is rig. Bone animation keys target pose bones, not the armature object's TRS. Sockets are separately bone-parented and must remain so. The common mesh helper parents every body/garment/eye/footwear mesh beneath the armature. This is a direct source-level route to non-root skinned nodes and is consistent with the warning class/count, pending actual resident node pointers.

The legacy fixture intentionally follows its older parented layout; this proposal changes **only authored worker builder**. It does not alter fixture builder/export kwargs, source/baked mesh coordinates, vertex weights, UVs, morph targets, modifier target, sockets, hierarchy of bones, actions, or runtime actor-group parenting.

## Bounded proposed change

`authored-root-mesh-CONDITIONAL.patch` removes only `obj.parent=rig` in the authored object_mesh() helper. A fresh identity mesh remains a scene-root sibling of the identity rig. Its Armature modifier continues to refer to rig. The existing portable exporter explicitly selects rig, sockets and all active-LOD meshes independently, so scene-root meshes remain in its selection; it does not rely on descendant selection. Runtime motion must continue to act on the loaded scene/group containing **both** meshes and rig, not the rig object alone.

This is safe only under the current builder's fresh identity object frame, baked coordinates and pose-bone-only animation assumptions. It must not be generalized to arbitrary preexisting/reparented meshes, nonidentity armature transforms or armature-object animation without preserving/rederiving world and bind frames. Three/FK source math is not proof of Blender exporter hierarchy/IBM output.

## Tests actually run

Three tests pass without Blender:

1. Extract and execute the **actual nested object_mesh() function AST**, from current and proposed source, under explicit fake BPy. Both produce the same source-axis-converted triangle positions, topology, weights, materials and Armature target; old object parent is rig, proposed object parent is None. Mock does not simulate Blender UV/decimation/export internals.
2. Pure homogeneous sagittal FK/LBS identity-parent algebra over101 joint poses and a translated/rotated actor group gives equal old/new world points. This verifies the stated identity-frame premise, not an exported actual skin.
3. A nonidentity parent counterexample demonstrates that dropping inheritance without world/bind analysis cannot be generalized.

Patch apply-check passes against current builder. Tests/report/patch remain outside app.

## Required later actual evidence before adoption/acceptance

Obtain actual old/new exported resident GLBs and full validator issue pointers. Confirm the original7 warnings name precisely the mesh children removed by this source change; validate new master/web files and check warning count/pointers. Match mesh/material/triangle/skin/weights/morph layout and inspect joints/inverse binds/rest world frames. Use the existing decoded CPU surface/frame comparison on old versus root-mesh exports at default rest and every idle/walk sample (reset morph defaults); require existing tolerance rather than weakening it. Retain each GLB hash and raw comparison receipt. Then rerun actual loaded source/published sole contacts and camera/browser inspections. Source geometry equivalence alone is insufficient; different IBM serialization can be semantically equivalent but requires world-surface proof. No photographic/biological/period quality claim follows from warning removal.
