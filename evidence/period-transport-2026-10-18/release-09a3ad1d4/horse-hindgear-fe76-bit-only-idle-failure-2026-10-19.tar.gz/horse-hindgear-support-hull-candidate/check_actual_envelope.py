# SPDX-License-Identifier: CC0-1.0
"""Independent actual GLB full triangle projection/slab readback, no acceptance of tail/poses."""
from pathlib import Path
import ast,json,struct,hashlib,numpy as np
P=Path(__file__).parent;tree=ast.parse((P/'check_source_envelope.py').read_text());ns={'np':np};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in ['unit','separation']],type_ignores=[]),'projection_math','exec'),ns)
b=(P/'candidate-one/light_breastcollar_harness_reconstructed_01.glb').read_bytes();n=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+n]);binary=b[28+n:];h=json.loads((P/'support-hull-receipt.json').read_text());rows=[]
for part in ['breeching','hip_support_l','hip_support_r']:
 mesh=next(m for m in j['meshes']if m['name']==part);pr=mesh['primitives'];bad=[];gaps=[];bounds=[]
 for primitive in pr:
  if 'indices'in primitive:raise ValueError('Expanded actual primitive required')
  a=j['accessors'][primitive['attributes']['POSITION']];v=j['bufferViews'][a['bufferView']];off=v.get('byteOffset',0)+a.get('byteOffset',0)
  if a['componentType']!=5126 or a['type']!='VEC3' or a['count']%3:raise ValueError('Bad actual triangles')
  xyz=np.array([struct.unpack_from('<fff',binary,off+12*i)for i in range(a['count'])]);bounds.append([[float(xyz[:,k].min()),float(xyz[:,k].max())]for k in range(3)])
  if part=='breeching':inside=xyz[:,1].min()>=1.034 and xyz[:,1].max()<=1.128 and xyz[:,2].max()<=-.33;axes=[0,2];poly=h['rear_coat_hull']
  else:inside=xyz[:,2].min()>=-.67 and xyz[:,2].max()<=-.466;axes=[0,1];poly=h['hip_hulls'][part[-1]]['coat_hull']
  if not inside:bad.append({'guard':'actualfullwidthslab'})
  for index,t in enumerate(xyz.reshape(-1,3,3)):
   q=t[:,axes].copy()
   if part=='hip_support_r':q[:,0]*=-1
   gap=ns['separation'](q,np.array(poly));gaps.append(gap)
   if not np.isfinite(gap)or gap<=1e-7:bad.append({'triangle':index,'projection_gap_m':float(gap)})
 rows.append({'part':part,'all_actual_triangles':len(gaps),'minimum_projected_gap_m':float(min(gaps)),'bounds_m':bounds,'bad':bad,'PASS':not bad})
r={'PASS':all(x['PASS']for x in rows),'candidate_sha256':hashlib.sha256(b).hexdigest(),'rows':rows,'scope':'Actual full rectangularstrip/cap projection disjoint from fullcoat slab hull atrest; nottail/allhorse/pose/positiveEuclideanstandoff acceptance'};(P/'actual-envelope-check.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
raise SystemExit(0 if r['PASS']else 1)
