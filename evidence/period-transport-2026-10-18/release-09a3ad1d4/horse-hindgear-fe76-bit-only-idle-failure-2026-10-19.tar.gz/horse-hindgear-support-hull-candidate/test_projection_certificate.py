# SPDX-License-Identifier: CC0-1.0
import ast,unittest,numpy as np
from pathlib import Path
s=Path(__file__).with_name('check_source_envelope.py');tree=ast.parse(s.read_text());ns={'np':np};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in ['unit','separation']],type_ignores=[]),str(s),'exec'),ns)
class Projection(unittest.TestCase):
 def setUp(self):self.h=np.array([[0.,0.],[1.,0.],[1.,1.],[0.,1.]])
 def gap(self,p):return ns['separation'](np.array(p),self.h)
 def test_disjoint(self):self.assertGreater(self.gap([[2,0],[3,0],[2,1]]),.9)
 def test_overlap(self):self.assertLessEqual(self.gap([[.2,.2],[.8,.2],[.5,.8]]),0)
 def test_line_through(self):self.assertLessEqual(self.gap([[-1,.5],[2,.5],[2,.5]]),0)
 def test_point_inside(self):self.assertLessEqual(self.gap([[.5,.5]]*3),0)
 def test_contact(self):self.assertLessEqual(self.gap([[1,0],[2,0],[1,1]]),0)
 def test_small_gap_not_certificate(self):self.assertLess(self.gap([[1+5e-8,0],[2,0],[1+5e-8,1]]),1e-7)
if __name__=='__main__':unittest.main()
