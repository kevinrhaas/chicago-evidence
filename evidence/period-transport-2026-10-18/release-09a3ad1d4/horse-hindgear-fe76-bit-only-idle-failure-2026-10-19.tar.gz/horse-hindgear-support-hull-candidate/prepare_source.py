# SPDX-License-Identifier: CC0-1.0
"""Original source-only threepart contour preparation against pinned actual idle world skin."""
from pathlib import Path
import json,hashlib,math,difflib
import numpy as np
PINS={'/workspace/shared/horse-headgear-first-idle-plan-v3/capture/horse.json': '0ce987c24d4d71dd874feda8ff5cd1cbcf6d0717a7cb6473b15dbc79527ac3b0', '/workspace/shared/horse-headgear-first-idle-plan-v3/capture/horse.f64': 'c853a0dacebab450db4267a458c3493aff224920396c1db48ac4e7215a805be8', '/workspace/shared/horse-headgear-exact078-rebase/generate_harness.contour.py': '8b1e6c22e99d6fc57d08f012d6abf9bdf2a239d775353ec63f2e4e17aacf6c9b', '/workspace/shared/horse-headgear-exact078-rebase/parameters.contour.json': '75ae6ef221aaadb5342122d43abf41c3ed3a2d0568241b76a06725a9988801c9'}
for pin,sha in PINS.items():
 if hashlib.sha256(Path(pin).read_bytes()).hexdigest()!=sha:raise ValueError('Independent pinned source/capture mismatch '+pin)
P=Path(__file__).parent;R=Path('/workspace/shared/horse-headgear-exact078-rebase');C=Path('/workspace/shared/horse-headgear-first-idle-plan-v3/capture');m=json.loads((C/'horse.json').read_text());payload=(C/'horse.f64').read_bytes()
if hashlib.sha256(payload).hexdigest()!=m['buffer_sha256']:raise ValueError('horse actual buffer hash')
if m['input'][1]!='090be8fdc2516ee5b5c8f886026f441850cc208f17b6ede71fed9007ab80f12f':raise ValueError('wrong horse')
a=np.frombuffer(payload,dtype='<f8').reshape(m['triangleCount'],3,3);
if not np.isfinite(a).all():raise ValueError('Nonfinite pinned source geometry')
g=next(g for g in m['meshes']if g['name']=='skinned_equine_coat');tri=a[g['start']:g['start']+g['count']];e1=tri[:,1]-tri[:,0];e2=tri[:,2]-tri[:,0]
def ray(o,d):
 o=np.asarray(o,float);d=np.asarray(d,float);d/=np.linalg.norm(d);pv=np.cross(d,e2);det=(e1*pv).sum(1);inv=np.divide(1,det,out=np.zeros_like(det),where=np.abs(det)>1e-12);tv=o-tri[:,0];u=(tv*pv).sum(1)*inv;q=np.cross(tv,e1);v=q@d*inv;t=(e2*q).sum(1)*inv;ids=np.flatnonzero((abs(det)>1e-12)&(u>=-1e-10)&(v>=-1e-10)&(u+v<=1+1e-10)&(t>0))
 if not len(ids):raise ValueError('ray misses actual coat '+str((o.tolist(),d.tolist())))
 i=int(ids[np.argmax(t[ids])]);return float(t[i]),int(g['start']+i)
def dense(points,n):
 out=[]
 for a,b in zip(points,points[1:]):
  for j in range(n):out.append((np.array(a)*(1-j/n)+np.array(b)*(j/n)).tolist())
 return out+[points[-1]]
# Full-width slab hull includes all triangle interiors and between-knot overhangs.
def clip_plane(poly,axis,value,sign):
 out=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  u=sign*(a[axis]-value);v=sign*(b[axis]-value)
  if u>=0:out.append(a)
  if u*v<0:out.append(a+(b-a)*u/(u-v))
 return out
def cross2(a,b):return a[0]*b[1]-a[1]*b[0]
def hull(points):
 ps=sorted(set(tuple(map(float,x))for x in points));lo=[];hi=[]
 for q in ps:
  while len(lo)>1 and cross2(np.array(lo[-1])-lo[-2],np.array(q)-lo[-1])<=0:lo.pop()
  lo.append(q)
 for q in ps[::-1]:
  while len(hi)>1 and cross2(np.array(hi[-1])-hi[-2],np.array(q)-hi[-1])<=0:hi.pop()
  hi.append(q)
 return np.array(lo[:-1]+hi[:-1])
def slab_hull(planes,axes,sign=1):
 points=[]
 for t in tri:
  poly=list(t)
  for axis,value,sg in planes:
   poly=clip_plane(poly,axis,value,sg)
   if not poly:break
  for q in poly:
   point=q[axes].copy();point[0]*=sign;points.append(point)
 return hull(points)
def offset_polygon(poly,r):
 # Intersection of outward-offset support lines circumscribes true Minkowski disk.
 out=[]
 for i,q in enumerate(poly):
  prev=poly[i-1];nxt=poly[(i+1)%len(poly)];d=q-prev;e=nxt-q;nd=np.array([d[1],-d[0]])/np.linalg.norm(d);ne=np.array([e[1],-e[0]])/np.linalg.norm(e);mat=np.array([nd,ne]);rhs=np.array([nd@q+r,ne@q+r])
  if abs(np.linalg.det(mat))<1e-14:raise ValueError('Degenerate support edge; no silent simplification')
  out.append(np.linalg.solve(mat,rhs))
 return np.array(out)
def inside(poly,p,eps=1e-11):return all(cross2(b-a,p-a)>eps for a,b in zip(poly,np.roll(poly,-1,axis=0)))
def visible(poly,a,b):
 cuts=[0.,1.];d=b-a
 for u,v in zip(poly,np.roll(poly,-1,axis=0)):
  e=v-u;den=cross2(e,d)
  if abs(den)>1e-18:
   t=-cross2(e,a-u)/den
   if 0<t<1:cuts.append(float(t))
 cuts=sorted(cuts)
 return not any(inside(poly,a+d*((u+v)/2))for u,v in zip(cuts,cuts[1:])if v-u>1e-12)
def path(poly,a,b,filterpoint):
 a=np.asarray(a);b=np.asarray(b)
 if inside(poly,a)or inside(poly,b):raise ValueError('Fixed anchor inside expanded support hull')
 points=[a,b]+[q for q in poly if filterpoint(q)];dist=[float('inf')]*len(points);dist[0]=0;prev={};pending=set(range(len(points)))
 while pending:
  i=min(pending,key=lambda i:dist[i]);pending.remove(i)
  if not np.isfinite(dist[i]):raise ValueError('No legal contour path')
  if i==1:break
  for j in pending:
   if visible(poly,points[i],points[j]):
    d=dist[i]+np.linalg.norm(points[i]-points[j])
    if d<dist[j]:dist[j]=d;prev[j]=i
 result=[1]
 while result[-1]!=0:result.append(prev[result[-1]])
 return [points[i]for i in result[::-1]]
def sample_path(polyline,n=3):
 return dense([q.tolist()for q in polyline],n)
baseparams=json.loads(Path('/workspace/shared/horse-hindgear-threepart-candidate/source/parameters.json').read_text());fixed=baseparams['hindgear_contour_study']['lower_junctions'];witness=[]
rear=slab_hull([(1,1.034,1),(1,1.128,-1),(2,-.33,-1)],[0,2]);rearoff=offset_polygon(rear,.008);back=rearoff[np.argmin(rearoff[:,1])];landmarks=[np.array([.30,-.34]),np.array([fixed['l']['position_m'][0],fixed['l']['position_m'][2]]),back,np.array([fixed['r']['position_m'][0],fixed['r']['position_m'][2]]),np.array([-.30,-.34])];pts=[]
for segment,(a,b)in enumerate(zip(landmarks,landmarks[1:])):
 pp=sample_path(path(rearoff,a,b,lambda q:q[1]<=-.329999),3);lengths=[0.]
 for u,v in zip(pp,pp[1:]):lengths.append(lengths[-1]+np.linalg.norm(np.array(v)-u))
 for i,q in enumerate(pp):
  fraction=lengths[i]/lengths[-1];y=1.0875
  if segment==0:y=1.10*(1-fraction)+1.0875*fraction
  if segment==3:y=1.0875*(1-fraction)+1.10*fraction
  point=[q[0],y,q[1]]
  if not pts or np.linalg.norm(np.array(point)-pts[-1])>1e-12:pts.append(point)
junctions={}
for side in ['l','r']:
 oldpoint=fixed[side]['position_m'];i=min(range(len(pts)),key=lambda i:np.linalg.norm(np.array(pts[i])-oldpoint))
 if np.linalg.norm(np.array(pts[i])-oldpoint)>1e-12:raise ValueError('Protected lower junction missing')
 pts[i]=oldpoint; junctions[side]={'breeching_sample':i,'position_m':oldpoint}
routes={};hiphulls={}
for sign,side in [(1,'l'),(-1,'r')]:
 hh=slab_hull([(2,-.67,1),(2,-.466,-1)],[0,1],sign);ho=offset_polygon(hh,.008);lower=junctions[side]['position_m'];upper=[.13,1.50];xy=sample_path(path(ho,[sign*lower[0],lower[1]],upper,lambda q:q[0]>=-1e-12),4);route=[]
 for x,y in xy:
  fraction=(y-lower[1])/(1.50-lower[1]);z=lower[2]*(1-fraction)-.54*fraction;route.append([sign*x,y,z])
 if any(b[1]<=a[1]for a,b in zip(route,route[1:])):raise ValueError('Hip support path not monotoneY')
 route[0]=lower;route[-1]=[sign*.13,1.5,-.54];route+=dense([route[-1],[0,1.525,-.48]],10)[1:];routes[side]=route;hiphulls[side]={'coat_hull':hh.tolist(),'offset_hull':ho.tolist()}
(P/'support-hull-receipt.json').write_text(json.dumps({'scope':'source support hull, not generatedstrap fit','rear_coat_hull':rear.tolist(),'rear_expanded_hull':rearoff.tolist(),'hip_hulls':hiphulls,'slabs_m':{'breechingY':[1.034,1.128],'breechingZmax':-.33,'hipZ':[-.67,-.466]},'offset_m':.008,'reason':'Circumscribed support polygon includes full triangle/slab projections, no point-ray branch jumps'},indent=2)+'\n')
old=json.loads((R/'parameters.contour.json').read_text());old['hindgear_contour_study']={'grade':'reconstructed_engineering','horse_sha256':m['input'][1],'breeching_route_m':pts,'hip_support_routes_m':routes,'lower_junctions':junctions,'widths_m':{'breeching':.052,'hip_support':.023},'thickness_m':{'breeching':.007,'hip_support':.004},'source':'Actual binary64 full-width slab convex support envelope; no point-ray interpolation; tail included in final fit'}
(P/'source/parameters.json').write_text(json.dumps(old,indent=2)+'\n');s=(R/'generate_harness.contour.py').read_text();lines=[]
for line in s.splitlines():
 if line.startswith("strap('breeching',"):line="strap('breeching',p['hindgear_contour_study']['breeching_route_m'],.052,.007,width_axis=(0,1,0))"
 elif line.startswith(" strap('hip_support_'+side,"):line=" strap('hip_support_'+side,p['hindgear_contour_study']['hip_support_routes_m'][side],.023,.004,width_axis=(0,0,1))"
 lines.append(line)
s='\n'.join(lines)+'\n';oldline="nm='socket_harness_'+role+'_'+side;node(nm,translation=v,extras={'role':role,'fit':'unpassed'});anchors[nm]={'translation_m':v,'rotation_xyzw':[0,0,0,1],'horse_socket':('socket_equine_'+role+'_'+side) if role in ['trace','breeching','shaft'] else None}"
newline="if role=='breeching':v=p['hindgear_contour_study']['lower_junctions'][side]['position_m']\n  "+oldline
if oldline not in s:raise ValueError('socket source mismatch')
s=s.replace(oldline,newline);(P/'source/generate_harness.py').write_text(s);compile(s,'generator','exec')
(P/'source/generator.patch').write_text(''.join(difflib.unified_diff((R/'generate_harness.contour.py').read_text().splitlines(True),s.splitlines(True),fromfile='f89/generate_harness.py',tofile='hindgear/generate_harness.py')));(P/'route-witnesses.json').write_text(json.dumps(witness,indent=2)+'\n');(P/'source-inputs.json').write_text(json.dumps({'horse_capture_metadata_sha256':hashlib.sha256((C/'horse.json').read_bytes()).hexdigest(),'horse_capture_buffer_sha256':m['buffer_sha256'],'f89_generator_sha256':hashlib.sha256((R/'generate_harness.contour.py').read_bytes()).hexdigest(),'f89_parameters_sha256':hashlib.sha256((R/'parameters.contour.json').read_bytes()).hexdigest()},indent=2)+'\n');print('Source prepared only; no candidate generation',junctions)
