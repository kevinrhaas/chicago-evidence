# SPDX-License-Identifier: CC0-1.0
"""Source-frame certificate only; no GLB generated or actual fit acceptance."""
from pathlib import Path
import json,math,numpy as np
P=Path(__file__).parent;p=json.loads((P/'source/parameters.json').read_text())['hindgear_contour_study'];h=json.loads((P/'support-hull-receipt.json').read_text())
def unit(v):return v/np.linalg.norm(v)
def sections(points,w,t,axis):
 out=[];points=np.array(points,float);axis=np.array(axis,float)
 for j,c in enumerate(points):
  tangent=unit(points[min(len(points)-1,j+1)]-points[max(0,j-1)]);side=unit(axis-tangent*(axis@tangent));normal=unit(np.cross(tangent,side));out.append([c+side*sw*w/2+normal*st*t/2 for sw,st in[(-1,-1),(1,-1),(1,1),(-1,1)]])
 return np.array(out)
def separation(triangle,poly):
 axes=[]
 for points in [triangle,poly]:
  for a,b in zip(points,np.roll(points,-1,axis=0)):
   e=b-a
   if np.linalg.norm(e)>1e-14:axes.append(unit(np.array([-e[1],e[0]])))
 gaps=[]
 for n in axes:
  a=triangle@n;b=poly@n;gaps.append(max(a.min()-b.max(),b.min()-a.max()))
 return max(gaps)
rows=[]
for name,points,w,t,axis,axes,poly in [('breeching',p['breeching_route_m'],.052,.007,[0,1,0],[0,2],h['rear_coat_hull'])]+[('hip_support_'+side,p['hip_support_routes_m'][side],.023,.004,[0,0,1],[0,1],h['hip_hulls'][side]['coat_hull'])for side in ['l','r']]:
 s=sections(points,w,t,axis);planes=[];worst=float('inf');bad=[];sign=-1 if name.endswith('_r')else 1
 for j in range(len(s)-1):
  for k in range(4):
   for ids in [[(j,k),(j,(k+1)%4),(j+1,(k+1)%4)],[(j,k),(j+1,(k+1)%4),(j+1,k)]]:
    triangle=np.array([s[a,b][axes]for a,b in ids]);
    if name.startswith('hip'):triangle[:,0]*=sign
    gap=separation(triangle,np.array(poly));worst=min(worst,gap)
    if gap<=1e-7:bad.append({'segment':j,'sideface':k,'projection_separation_m':gap})
 for cap in [[s[0,0],s[0,2],s[0,1]],[s[0,0],s[0,3],s[0,2]],[s[-1,0],s[-1,1],s[-1,2]],[s[-1,0],s[-1,2],s[-1,3]]]:
  triangle=np.array([v[axes]for v in cap]);
  if name.startswith('hip'):triangle[:,0]*=sign
  gap=separation(triangle,np.array(poly));worst=min(worst,gap)
  if gap<=1e-7:bad.append({'cap':True,'projection_separation_m':gap})
 # Entire ribbon corner extrema must lie within source clipping slab; no skipped region.
 bounds=[[float(s[:,:,k].min()),float(s[:,:,k].max())]for k in range(3)];inside= bounds[1][0]>=1.034 and bounds[1][1]<=1.128 and bounds[2][1]<=-.33 if name=='breeching'else bounds[2][0]>=-.67 and bounds[2][1]<=-.466
 rows.append({'part':name,'source_expected_corner_bounds_m':bounds,'within_declared_full_slab':inside,'minimum_projected_separation_m':worst,'bad_faces':bad,'PASS':inside and not bad})
r={'PASS':all(r['PASS']for r in rows),'rows':rows,'scope':'Predicted actual strap section frames vs complete convex projected coat slab; no tail/allhorse/posed/actualGLB proof'};(P/'source-envelope-check.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({**r,'rows':[{k:v for k,v in z.items()if k!='bad_faces'}|{'bad_face_count':len(z['bad_faces'])}for z in rows]}))
raise SystemExit(0 if r['PASS']else 1)
