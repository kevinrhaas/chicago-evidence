# Fullstrip-support correction: actualidle hindgear clear; overall FAIL on bit

Actualprevious67failure preserved at /workspace/shared/horse-hindgear-67-first-idle-failure-2026-10-19.tar.gz SHAf5dde085ba0dc1400d5ab924fabfb5baf47d6815d759946b406450bcc5b7278b. Diagnosis:point-ray envelope switchedbranches betweenknots; all12breechingcontactssegments11/84 and48hipcontactssegment9. No amountofendpoint-only support proved between-knotrectangleclearance.

Materiallynew source clips ALL090coat triangles to fullconservative actualsection slabs and constructs convexsupportcontours includingoverhangs. Outwardhalfplaneoffset iscircumscribed; visibilitypaths preserve rear/sidehomotopy, fixedlowerjunctions andupperanchors. No smoothing or scalarsearch. PredictedFULLrectangletriangles/caps pass projectednumericseparation/slabbounds;6analyticcontrols normal/-O pass. Independentcarriage_model review found no sourceblockers, retained here. NumericFloat64clip/hull is not anexact-arithmetic or3Dpositiveclearance proof.

AuthorizedONEbuild0.61sec:fe76c95b49234da64700a1e20741b4998e8cfbae69571387d49bf5bb23ef04b1. RestcontractPASS:33protectedparts exact67/f89 lineage, allanchors nowexact67 (nonewrelocation), license/provenance/materials/rig/bindings exact; actual52/23mmwidth and7/4mmthickness andjoinsreadbackpass. ActualemittedALLtriangles includingendcaps projectednumericrestguardPASS:556breechingtrianglesminimum4.499974mmseparatingaxisgap;212triangleseachhipminimum.420674mmgap. Theseareprojectionlowerseparationguards,notEuclideanstandoff/pressurequality.

ThenauthorizedONEbinary64actualThreeidle0capture→all36/allhorsestrictfit,6.208sec,EXIT2. measurement_complete=true,fit_passed=false,error=null. Exacthorse090,baseline078,fe76pins,fullunique36/indexstreamcoverage andactualFloat64bufferhashes checked. Baselinefiveheadstraps262raw/258proper. Candidate44rawSAT/44proper: **ONLYbit_bar44**. Allother35parts0/0 atthisONEpose, includingthreecorrectedhindparts,fourpriorqualifiedbodyparts andfiveidleclearheadstraps. No renamed/excludedbitcontacts; no automaticpassbecauseonlyonepartfails.

| Part | f89idleproper | 67idleproper | fe76idleproper |
|---|---:|---:|---:|
|breeching|88|12|0|
|hip_support_l|10|24|0|
|hip_support_r|10|24|0|
|bit_bar|44|44|44|

Globalfit remainsFALSE. Currenthorse mouth isclosedgroove withnosealedoralvoid; bitintersects29coat+15lipprimitive. Separateoralinterfaceproposal at /workspace/shared/horse-oral-interface-source-proposal/PROPOSAL.md requiresnewheadauthority, exactcutcohorts andrealcavity; no exemption/shrink/hide authorized. Source/protectedneck/earroot changes wouldinvalidatefuturepairfit.

All63posequalification,volumeinside/positiveunsigneddistance,continuousmotion/taildynamics,force/pressure,periodgear/fitting andvisualphotographicquality remainOPEN. Convexenvelope may introduceexcessivefloatinggear; no browser/render inspected thiscandidate. Onlyidle0 is measured; do notpromote35zero-SATparts intooverallfit/visualacceptance. Noactualhorse/app/ticket/CIchange,extra candidategeneration,autotuning orfitretry. Fullsource/guardresults/all36witnesses/Float64buffers/stdoutstderr preserved.
