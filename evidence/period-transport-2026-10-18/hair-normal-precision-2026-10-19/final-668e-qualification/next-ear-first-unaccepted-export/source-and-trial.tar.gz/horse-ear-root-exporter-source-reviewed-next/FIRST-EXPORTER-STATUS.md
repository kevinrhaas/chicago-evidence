# Exporter source revision — no actual horse generation/export executed

NEW sibling directory; the archived31fa193b... source parcel and all original geometry/failure archives remain unchanged. This revision implements the missing exporter in source only. No actual source candidate or GLB has been built/exported, no Blender/browser/GPU/SAT sweep has run, and no app/ticket/CI files changed. Source syntax and tiny synthetic array/storage controls are the entire executed scope.

Implemented exporter path (UNEXECUTED on a horse)

export_glb.py requires --export-reviewed-candidate, a NEW child output directory, frozen090 input byte hashes and the exact reviewed source candidate. It reconstructs the deterministic source edit and demands identical ownership/data, then audits complete source topology before proceeding. It does not accept a broad region exemption or a different source candidate. All radial interval/source-owner checks remain from the reviewed builder.

The source maps precisely6skull face replacements and176ear-root retirements into actual oriented primitive index triples. It rejects duplicates, unexpected source material/layout or extra retirement. Remaining original indexed faces are retained, with explicit old→new face maps. New complement/bridge faces attach through shared active source vertex references; source-edge knots have the previously checked2declared incident owners.

The authored exporter keeps original binary bytes/accessors/views unchanged and appends new active storage. Original positions, joints and weights remain bit-exact. All48portal/band vectors (including normals) are checked exactly after serialization/redecode. Only22coat+18inner actual root-ring normal vertices may change; all other original normals remain exact. Cut normals use the joined source graph; old protected48 normals are never recomputed. Actual ring aliases across material seams receive identical position/normal/joint/weight fields, with upper ring weights preserved rather than head-only replacement. New cut weights interpolate actual decoded source joint fields, merge at most4influences and normalize; only original root/head influences are permitted.

Newcut positions use actual decoded old triangle barycentrics and must remain within2e-7m of the frozen source recipe under float32 quantization. This is ONLY a source ownership/quantization condition; the existing SAT1e-8/proper-crossing and5mm gear guard are untouched. The actual emitted-float32 candidate can still fail intersections or shading and must be tested without relaxing those guards.

Nodes, rest hierarchy, IBMs, clips/samplers, sockets, scene, material values and all unrelated primitives stay exact. Full old vertex prefixes are checked before serialization; the serialized GLB is decoded again and checked against those expected fields. New sidecars remove obsolete vertex_ranges, provide actual referenced vertex/index counts plus precise source/primitive remaps, and explicitly retain baseline failure evidence. New authority pins its actual exported bytes/producer/source, without borrowing old authority pins or claiming tests not run.

The eventual emitted status is always UNACCEPTED. Export-local topology/preservation is not a63pose, gear, continuous-time, performance or photographic acceptance. Candidate all63head+ears+adjacentneck/body strict crossings, realLBS seam checks, unchanged078FIRSTfit, Khronos, deterministic actual rebuilds and visual review remain REQUIRED and NOT EXECUTED. Prior baseline832sampled ear attachment pairs and258idle gear crossings remain documented as BASELINE failures, not relabeled candidate measurements.

Executed lightweight proof

All Python sources compile. test_export_rules.py:14tiny synthetic controls pass normal and optimized Python (weight interpolation, invalid barycentrics/negative/fifth weights, normal halo, protected48 normals, old position/weight corruption, seam weight mismatch, exact retirement, append-only storage, uint16joint storage and normalized accessor refusal). No test calls Builder.build(), execute_export() or encode() on a horse; storage tests append a single synthetic accessor in memory, never serialize/write a GLB. The previously archived8generic planar/topology controls remain source only and unchanged. UNIT-RECEIPT.json records this scope and source hashes.

Future commands — DO NOT execute until root releases actual generation

    python generate_source.py --input-dir <frozen090trial1> --output-dir <NEWsource-output> --generate-reviewed-candidate
    python audit_source.py <NEWsource-output>/candidate-source-edit.json --input-dir <frozen090trial1>
    python export_glb.py --input-dir <frozen090trial1> --source-candidate <NEWsource-output>/candidate-source-edit.json --output-dir <THISdirectory/NEWexport-output> --export-reviewed-candidate

First actual failure must be archived and reported before repair. No actual candidate/export-ready success is claimed by authored, compiled source.
