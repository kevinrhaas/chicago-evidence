# SPDX-License-Identifier: CC0-1.0
"""Original reviewed22/18 ear-root surgery. Generation requires explicit CLI flag.
UNEXECUTED candidate mesh: authoring syntax/light fixtures are not mesh proof.
"""
from pathlib import Path
import argparse,json,hashlib,math
import numpy as np
from planar import need,area,triangulate,bounded_faces,point_in_polygon,coverage
from export_rules import retained_edge_material
P=Path(__file__).parent
PINS={'glb':'090be8fdc2516ee5b5c8f886026f441850cc208f17b6ede71fed9007ab80f12f','head':'ac4d96ab6ae8d0ef5956686a3a9c213ebce1dd9e76f5e91c4e376b319429b5b3','ears':'c769254c0effdeda19aa9495bcd66da0661c71065097a5fde7e633417889deb9','producer':'883fb2607a5ccb150c84b41985f62864b26d64db62052446ca45bfda9d99c5e9','recipe':'e78d8059d5dbeeee47a3427bb0d60527ade131e141a975418f10a0f82b65163a','cohorts':'662b05cf50abe9d916d42bab0b0cdd08b4d55a67faf5b9ddfc6472badbca810d'}
ALLOWED={-1:{16,17,19},1:{4,6,7}}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inputs(base):
 paths={'glb':base/'equine_light_harness_skinned_prototype_01.glb','head':base/'head-source-surface.json','ears':base/'ear-source-surfaces.json','producer':base/'manifest.json','recipe':P/'CONCRETE-CHART.json','cohorts':P/'EAR-COHORTS.json'}
 for k,p in paths.items():need(sha(p)==PINS[k],'Frozen input bytes mismatch:'+k)
 return paths,json.loads(paths['head'].read_text()),json.loads(paths['ears'].read_text()),json.loads(paths['recipe'].read_text()),json.loads(paths['cohorts'].read_text())

def bary3(p,triangle):
 a,b,c=np.asarray(triangle,float);basis=np.stack([b-a,c-a],axis=1);xy=np.linalg.lstsq(basis,p-a,rcond=None)[0];need(np.linalg.norm(a+basis@xy-p)<1e-11,'Point outside source plane');return np.array([1-xy.sum(),*xy])

def contract(head,recipe):
 v=np.asarray(head['positions'],float);f=np.asarray(head['faces']);edgeowners={}
 for i,t in enumerate(f):
  for a,b in zip(t,np.roll(t,-1)):edgeowners.setdefault(tuple(sorted((int(a),int(b)))),[]).append(i)
 rows=[]
 for row in recipe['rows']:
  side=row['side'];need(set(row['boundary_split_source_faces'])==ALLOWED[side],'Extra/missing skull face exception');need(len(row['conforming_loop'])==22 and len(row['original_18_projected_points'])==18,'22/18contract')
  focus=np.array(row['projection_focus_actual_ring1_centroid_m']);leaf=np.array([q['leaf_point_local_m']for q in row['original_18_projected_points']]);intervals=[]
  for q in row['extra_source_edge_crossings']:
   owners=edgeowners[tuple(sorted(q['crossed_source_edge']))];need(len(owners)==2 and set(owners)<=ALLOWED[side],'Shared edge would require undeclared adjacent face');need(len(owners)==len(set(owners)),'Duplicate source owner')
  for interval in row['source_segment_ownership']:
   fi=interval['source_face'];need(fi in ALLOWED[side],'Undeclared interval face');a,b,c=v[f[fi]];n=np.cross(b-a,c-a);i=interval['ear_edge'];A=leaf[i];B=leaf[(i+1)%18];numerator=float(n@(a-focus));den=[];rho=[];members=[]
   for s in[interval['s0'],(interval['s0']+interval['s1'])/2,interval['s1']]:
    L=A+s*(B-A);D=float(n@(L-focus));need(abs(D)>1e-12,'Radial interval denominator near zero');r=numerator/D;K=focus+r*(L-focus);bc=bary3(K,v[f[fi]]);need(0<r<1 and min(bc)>-1e-9,'Radial interval leaves source face or positive span');den.append(D);rho.append(r);members.append(bc.tolist())
   need(min(den)>0 or max(den)<0,'Denominator sign reverses on linear interval');intervals.append({**interval,'denominator_end_mid_end':den,'rho_end_mid_end':rho,'source_membership_barycentric':members})
  rows.append({'side':side,'intervals':intervals,'shared_source_edge_split_owners_both_declared':True})
 return{'status':'light contract checks only, NOT generated mesh','rows':rows}

class Builder:
 def __init__(self,head,ears,recipe,cohorts):
  self.head=head;self.ears=ears;self.recipe=recipe;self.cohorts=cohorts;self.vertices={};self.new=[];self.face_records=[];self.proofs=[]
  for i,p in enumerate(head['positions']):self.vertices['h:'+str(i)]={'position':p,'kind':'existing_head','source_vertex':i}
 def add(self,key,record):
  need(key not in self.vertices,'Duplicate construction vertex');self.vertices[key]=record;return key
 def point(self,k):return np.array(self.vertices[k]['position'],float)
 def face(self,ids,owner):need(len(set(ids))==3,'Duplicate triangle IDs');self.new.append(list(ids));self.face_records.append(owner)
 def skull(self,row):
  side=row['side'];lower=[];v=np.asarray(self.head['positions'],float);f=np.asarray(self.head['faces']);focus=np.array(row['projection_focus_actual_ring1_centroid_m']);leaf=np.array([q['leaf_point_local_m']for q in row['original_18_projected_points']]);ly=leaf[0,1];poly=leaf[:,[0,2]].tolist()
  def project(p):need(p[1]>focus[1],'Projection denominator');return(focus[[0,2]]+(p[[0,2]]-focus[[0,2]])*(ly-focus[1])/(p[1]-focus[1])).tolist()
  for i,q in enumerate(row['conforming_loop']):lower.append(self.add('cut:'+str(side)+':'+str(i),{'position':q['position_local_m'],'kind':'skull_cut','side':side,'source_face':q['source_face'],'barycentric':q['barycentric']}))
  # Replace only6 exact faces with their constrained OUTSIDE complement.
  for fi in sorted(ALLOWED[side]):
   source=f[fi];tri=v[source];pts={'h:'+str(i):xy for i,xy in zip(source,[[0.,0.],[1.,0.],[0.,1.]])};boundaries=[];edges=set()
   for key in lower:
    try:bc=bary3(self.point(key),tri)
    except ValueError:continue
    if min(bc)>=-1e-9:pts[key]=[float(bc[1]),float(bc[2])]
   # Split each old triangle edge at every actual shared-edge cut knot.
   for e in range(3):
    A='h:'+str(source[e]);B='h:'+str(source[(e+1)%3]);a=np.array(pts[A]);b=np.array(pts[B]);d=b-a;ordered=[]
    for key,p in pts.items():
     q=np.array(p);t=float((q-a)@d/(d@d))
     if-1e-9<=t<=1+1e-9 and np.linalg.norm(q-a-t*d)<1e-10:ordered.append((t,key))
    ordered.sort();need(ordered[0][1]==A and ordered[-1][1]==B,'Source edge ownership/order')
    for(_,a),(_,b)in zip(ordered,ordered[1:]):edges.add(tuple(sorted((a,b))))
   need(len(row['source_segment_ownership'])==22,'Incomplete lower interval table')
   for i,interval in enumerate(row['source_segment_ownership']):
    if interval['source_face']!=fi:continue
    a,b=lower[i],lower[(i+1)%22];need(a in pts and b in pts,'Both interval endpoints must own this face');edges.add(tuple(sorted((a,b))))
   loops=bounded_faces(pts,edges);alltris=[];outside=[];inside=[]
   for loop in loops:
    ts=triangulate(loop,pts);alltris.extend(ts)
    for t in ts:
     centre=sum((self.point(i)for i in t),np.zeros(3))/3
     (inside if point_in_polygon(project(centre),poly)else outside).append(t)
   need(alltris and inside and outside,'Source face must be partially cut, never wholly erased');coverage(alltris,pts,['h:'+str(i)for i in source])
   for t in outside:self.face(t,{'kind':'skull_complement','source_face':fi,'side':side})
   self.proofs.append({'source_face':fi,'side':side,'constraint_edges':[list(e)for e in sorted(edges)],'new_complement_triangles':len(outside),'retired_inside_subtriangles':len(inside),'all_source_vertices_preserved':True})
  return lower
 def bridge(self,row,lower):
  side=row['side'];upper=[]
  original=next(r for r in self.cohorts['ear_root_cohorts']if r['side']==side)
  for i,q in enumerate(original['ordered_root_boundary']):upper.append(self.add('earring:'+str(side)+':'+str(i),{'position':q['position_local_m'],'kind':'existing_ear_root_ring','side':side,'source_owners':q['source_owners']}))
  # Conforming lower knot sequence and intervals use exactly the same s=i+t.
  for i in range(18):
   q0=next(k for k,q in enumerate(row['conforming_loop'])if q.get('ear_boundary_corner')==i);q1=next(k for k,q in enumerate(row['conforming_loop'])if q.get('ear_boundary_corner')==(i+1)%18);chain=[lower[q0]];k=q0
   while k!=q1:k=(k+1)%22;chain.append(lower[k]);need(len(chain)<=6,'Unexpected knot chain')
   loop=[upper[i],*chain,upper[(i+1)%18]];A=self.point(upper[i]);U=self.point(upper[(i+1)%18])-A;U/=np.linalg.norm(U);V=self.point(chain[0])-A;V-=U*(V@U);V/=np.linalg.norm(V);normal=np.cross(U,V);points={key:[float((self.point(key)-A)@U),float((self.point(key)-A)@V)]for key in loop}
   need(max(abs(float((self.point(key)-A)@normal))for key in loop)<1e-11,'Bridge patch escapes actual radial leafedge plane')
   if area([points[k]for k in loop])<0:points={k:[p[0],-p[1]]for k,p in points.items()}
   ts=triangulate(loop,points);proof=coverage(ts,points,loop)
   boundary_positions=[tuple(self.point(upper[i])),tuple(self.point(upper[(i+1)%18]))];owner=retained_edge_material(self.ears,original['component_face_tables'],boundary_positions)
   for t in ts:self.face(t,{'kind':'radial_bridge','side':side,'ear_edge':i,'material':owner['material'],'upper_edge_owner':owner})
   self.proofs.append({'side':side,'ear_edge':i,'bridge_patch':proof,'boundary_loop':loop,'complete_lower_chain':chain,'upper_edge_retained':True,'material_owner':owner})
 def build(self):
  for row in self.recipe['rows']:self.bridge(row,self.skull(row))
  return{'status':'original UNACCEPTED candidate; execution alone is not proof','vertices':self.vertices,'new_faces':self.new,'new_face_owners':self.face_records,'retire_source_head_faces':sorted(set.union(*ALLOWED.values())),'ear_retirement_and_retained_boundary':self.cohorts['ear_root_cohorts'],'planar_construction_proofs':self.proofs,'protected_contract':'48portal/band attributes exact; all outside6faces/earroot retirement geometry exact; only rootring normals may change; no rig/gear/clip/socket/sole changes'}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--input-dir',type=Path,required=True);ap.add_argument('--output-dir',type=Path);ap.add_argument('--generate-reviewed-candidate',action='store_true');args=ap.parse_args();paths,h,e,r,c=inputs(args.input_dir);light=contract(h,r)
 if not args.generate_reviewed_candidate:print(json.dumps({'status':'contract checked; generation NOT requested','sides':len(light['rows'])}));return
 need(args.output_dir is not None,'Explicit output dir required');need(not args.output_dir.exists(),'Refuse overwrite prior witness directory');args.output_dir.mkdir(parents=True);builder=Builder(h,e,r,c)
 try:result=builder.build()
 except Exception as error:
  partial={'status':'FAILED partial source construction; NOT a valid mesh','error':str(error),'vertices':builder.vertices,'new_faces':builder.new,'new_face_owners':builder.face_records,'completed_planar_proofs':builder.proofs};(args.output_dir/'FAILED-source-partial.json').write_text(json.dumps(partial,indent=2)+'\n');raise
 (args.output_dir/'candidate-source-edit.json').write_text(json.dumps(result,indent=2)+'\n');(args.output_dir/'interval-contract.json').write_text(json.dumps(light,indent=2)+'\n')
 # No GLB exporter is implicitly invoked. The separate export_glb.py requires
 # an explicit review flag and rechecks the actual source topology.
 print('UNACCEPTED source candidate only; export_glb.py requires separate reviewed execution')
if __name__=='__main__':main()
