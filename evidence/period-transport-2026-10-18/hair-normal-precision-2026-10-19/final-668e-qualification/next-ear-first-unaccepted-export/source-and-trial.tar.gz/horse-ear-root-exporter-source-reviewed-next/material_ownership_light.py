# SPDX-License-Identifier: CC0-1.0
"""Read-only existing18edge material ownership; no candidate generation."""
from pathlib import Path
import json
from generate_source import inputs
from export_rules import retained_edge_material
P=Path(__file__).parent

def main():
 _,_,ears,_,cohorts=inputs(Path('/workspace/shared/horse-head-groove-coat-next/trial1'));rows=[]
 for side in cohorts['ear_root_cohorts']:
  boundary=side['ordered_root_boundary'];owners=[]
  for i,q in enumerate(boundary):owners.append({'ear_edge':i,**retained_edge_material(ears,side['component_face_tables'],[q['position_local_m'],boundary[(i+1)%18]['position_local_m']])})
  rows.append({'side':side['side'],'upper_edges':owners,'coat0_edges':sum(q['material']==0 for q in owners),'concave5_edges':sum(q['material']==5 for q in owners)})
 r={'scope':'Actual frozen090existing root-edge material ownership only. NO source candidate/GLB built/exported.','rows':rows};(P/'MATERIAL-OWNERSHIP-LIGHT.json').write_text(json.dumps(r,indent=2)+'\n');print([(q['side'],q['coat0_edges'],q['concave5_edges'])for q in rows])
if __name__=='__main__':main()
