# SPDX-License-Identifier: CC0-1.0
"""UNEXECUTED original append-only GLB exporter for the reviewed ear-root parcel.
Import/unit controls never construct a horse. Actual export needs explicit flag,
exact090inputs, deterministic source reconstruction and source topology success.
No SAT tolerance, posed fit or failure acceptance is changed by this module.
"""
from pathlib import Path
import argparse,copy,json,hashlib
import numpy as np
from planar import need
from generate_source import inputs,contract,Builder,ALLOWED
from audit_source import assemble,topology
from glb_data import parse,read,append,encode
from export_rules import ATTRS,blend_weights,verify_unchanged_prefix,verify_protected48,verify_alias_fields,verify_retirement,verify_emitted_indices,verify_complete_seam,verify_protected_document,verify_skin_identity
ORIGIN=np.array([0.,1.88,.8])
MATCH=2e-7 # Source↔decoded float32 ownership matching ONLY, never SAT/fit tolerance.
def digest(b):return hashlib.sha256(b).hexdigest()
def cycle(t):return min(tuple(t),tuple(t[1:]+t[:1]),tuple(t[2:]+t[:2]))
def unit(v):
 n=float(np.linalg.norm(v));need(np.isfinite(v).all()and n>1e-12,'Invalid normal');return(v/n).astype('<f4')

def execute_export(base,candidate,checkpoint=None):
 paths,head,ears,recipe,cohorts=inputs(base);light=contract(head,recipe)
 expected=Builder(head,ears,recipe,cohorts).build()
 need(candidate==expected,'Candidate source edit does not exactly match reviewed generator/recipe')
 sv,sf,owners=assemble(candidate,head,ears);source_topology=topology(sv,sf,['h:'+str(i)for i in head['portal']])
 raw=paths['glb'].read_bytes();original,oldbin=parse(raw);d=copy.deepcopy(original);blob=bytearray(oldbin);producer=json.loads(paths['producer'].read_text());working={};source_ears={e['name']:e for e in ears}
 for material,name in[(0,'skinned_equine_coat'),(5,'skinned_equine_ear_inner')]:
  hits=[(i,m)for i,m in enumerate(d['meshes'])if m['name']==name];need(len(hits)==1,'Missing/ambiguous authored material mesh');mi,m=hits[0];need(len(m['primitives'])==1,'Unexpected root mesh primitive layout');p=m['primitives'][0];need(p['material']==material and set(p['attributes'])==set(ATTRS),'Unexpected root attribute/material contract');attrs={k:read(d,blob,p['attributes'][k])for k in ATTRS};indices=read(d,blob,p['indices']).ravel().reshape(-1,3);rr=[r for r in producer['vertex_ranges']if r['material']==material and r['joint']=='head'];need(len(rr)==1,'Missing precise old semantic head range');r=rr[0];working[material]={'mesh':mi,'primitive':0,'old':attrs,'active':{k:v.copy()for k,v in attrs.items()},'old_indices':indices,'range':range(r['vertex_start'],r['vertex_start']+r['vertex_count']),'remove':set(),'normal_halo':set(),'triangle_lookup':{cycle(list(map(int,t))):i for i,t in enumerate(indices)}}
 def field(mat,i):return{k:working[mat]['old'][k][i].copy()for k in ATTRS}
 def locate(mat,pos):
  w=working[mat];ids=np.array(list(w['range']),int);expected=np.asarray(pos)+ORIGIN;dist=np.linalg.norm(w['old']['POSITION'][ids].astype(float)-expected,axis=1);matches=ids[dist<=MATCH];need(len(matches)==1,'Ambiguous/missing actual semantic source vertex');return int(matches[0])
 headmap={}
 def hvertex(i):
  if i not in headmap:headmap[i]=locate(0,head['positions'][i])
  return headmap[i]
 protected=[hvertex(i)for i in range(48)];need(len(set(protected))==48,'Protected48 source aliases')
 def oldface(mat,vertex_ids):
  key=cycle(vertex_ids);need(key in working[mat]['triangle_lookup'],'Actual oriented source face absent');return working[mat]['triangle_lookup'][key]
 actual_skull=set();actual_ears={};retired_records=[]
 for fi in candidate['retire_source_head_faces']:
  need(fi in set.union(*ALLOWED.values()),'Undeclared skull retirement');ids=[hvertex(i)for i in head['faces'][fi]];actual=oldface(0,ids);need(actual not in working[0]['remove'],'Duplicate skull retirement');working[0]['remove'].add(actual);actual_skull.add(fi);retired_records.append({'kind':'skull','source_face':fi,'mesh':working[0]['mesh'],'old_primitive_triangle':actual,'old_vertex_ids':ids})
 expected_ears={}
 for side in cohorts['ear_root_cohorts']:
  for comp in side['component_face_tables']:
   name=comp['source_component'];e=source_ears[name];mat=e['material'];need(mat in working,'Unexpected ear material');expected_ears[name]=set(comp['lower_rows0_1_faces_retire']);actual_ears[name]=set()
   for fi in comp['lower_rows0_1_faces_retire']:
    ids=[locate(mat,e['positions_local'][i])for i in e['faces'][fi]];actual=oldface(mat,ids);need(actual not in working[mat]['remove'],'Duplicate ear retirement');working[mat]['remove'].add(actual);actual_ears[name].add(fi);retired_records.append({'kind':'ear_root','component':name,'source_face':fi,'mesh':working[mat]['mesh'],'old_primitive_triangle':actual,'old_vertex_ids':ids})
 verify_retirement(actual_skull,actual_ears,set.union(*ALLOWED.values()),expected_ears)
 need(sum(len(w['remove'])for w in working.values())==182,'Expected6skull+176earroot faces only')
 # Area-weighted normals on the actual connected SOURCE graph. Only new cut
 # vertices and the exact18vertex-per-ear ring may use these new normals.
 normals={k:np.zeros(3)for k in sv}
 for t in sf:
  a,b,c=[np.array(sv[k])for k in t];n=np.cross(b-a,c-a)
  for k in t:normals[k]+=n
 resolved={};ring_aliases={};new_position_errors=[]
 for key,r in candidate['vertices'].items():
  if r['kind']!='existing_ear_root_ring':continue
  aliases=[]
  for owner in r['source_owners']:
   e=source_ears[owner['component']];mat=e['material'];i=locate(mat,e['positions_local'][owner['source_vertex']]);aliases.append((mat,i,field(mat,i)))
  verify_alias_fields([q[2]for q in aliases]);normal=unit(normals[key]);canonical={k:v.copy()for k,v in aliases[0][2].items()};canonical['NORMAL']=normal
  for mat,i,_ in aliases:working[mat]['active']['NORMAL'][i]=normal;working[mat]['normal_halo'].add(i)
  coat_owner=[i for mat,i,_ in aliases if mat==0];need(len(coat_owner)<=1 and len({(mat,i)for mat,i,_ in aliases})==len(aliases),'Repeated ring source owner');ring_aliases[key]={'aliases':[{'material':mat,'vertex':i}for mat,i,_ in aliases],'coat_existing_vertex':coat_owner[0]if coat_owner else None,'fields':canonical}
 need({mat:len(w['normal_halo'])for mat,w in working.items()}=={0:22,5:18},'Exact ear-root normal halo must be22coat+18inner vertices')
 # No bone is introduced: interpolated cut influences must remain root/head.
 allowed_joints={int(j)for i in protected for j,w in zip(working[0]['old']['JOINTS_0'][i],working[0]['old']['WEIGHTS_0'][i])if w>0};need(len(allowed_joints)==2,'Expected actual root/head influence set');skin_identity=verify_skin_identity(original,[w['mesh']for w in working.values()],allowed_joints)
 for alias in ring_aliases.values():need({int(j)for j,w in zip(alias['fields']['JOINTS_0'],alias['fields']['WEIGHTS_0'])if w>0}<=allowed_joints,'Existing rootring uses a foreign joint')
 append_fields={mat:[]for mat in working};new_vertex_records=[];shared_fields={}
 def vertex(mat,key):
  token=(mat,key)
  if token in resolved:return resolved[token]
  r=candidate['vertices'][key]
  if r['kind']=='existing_head':
   need(mat==0,'Original skull vertex cannot change material');idx=hvertex(r['source_vertex']);need(np.array_equal(working[0]['active']['POSITION'][idx],working[0]['old']['POSITION'][idx]),'Protected source position changed');resolved[token]=idx;return idx
  if r['kind']=='existing_ear_root_ring':
   alias=ring_aliases[key];existing=[q['vertex']for q in alias['aliases']if q['material']==mat];need(len(existing)<=1,'Ambiguous same-material ring owner')
   if existing:resolved[token]=existing[0];return existing[0]
   f={k:v.copy()for k,v in alias['fields'].items()}
  elif r['kind']=='skull_cut':
   if key not in shared_fields:
    tri=head['faces'][r['source_face']];sources=[field(0,hvertex(i))for i in tri];bc=r['barycentric'];j,w=blend_weights([q['JOINTS_0']for q in sources],[q['WEIGHTS_0']for q in sources],bc)
    need({a for a,b in zip(j,w)if b}<=allowed_joints,'New bone influence forbidden');position=np.asarray(sum((float(c)*q['POSITION'].astype(float)for c,q in zip(bc,sources)),np.zeros(3)),dtype='<f4');delta=float(np.linalg.norm(position.astype(float)-(np.array(r['position'])+ORIGIN)));need(delta<=MATCH,'New cut exceeded float32 source-match bound');new_position_errors.append(delta);shared_fields[key]={'POSITION':position,'NORMAL':unit(normals[key]),'JOINTS_0':np.asarray(j,dtype=working[0]['old']['JOINTS_0'].dtype),'WEIGHTS_0':np.asarray(w,dtype='<f4')}
   f={k:v.copy()for k,v in shared_fields[key].items()}
  else:raise ValueError('Unknown source vertex kind')
  need(all(np.isfinite(f[k]).all()for k in ATTRS),'Nonfinite new vertex');idx=len(working[mat]['old']['POSITION'])+len(append_fields[mat]);append_fields[mat].append(f);new_vertex_records.append({'source_id':key,'material':mat,'active_vertex':idx,'kind':r['kind']});resolved[token]=idx;return idx
 newfaces={mat:[]for mat in working};newface_owners={mat:[]for mat in working}
 need(len(candidate['new_faces'])==len(candidate['new_face_owners'])and candidate['new_faces'],'Missing new ownership')
 for source_index,(t,owner)in enumerate(zip(candidate['new_faces'],candidate['new_face_owners'])):
  mat=0 if owner['kind']=='skull_complement'else owner.get('material');need(mat in working,'Missing/foreign bridge material ownership');newfaces[mat].append([vertex(mat,k)for k in t]);newface_owners[mat].append({'source_new_face':source_index,**owner})
 for mat in working:
  newfaces[mat]=np.asarray(newfaces[mat],dtype='<u4').reshape(-1,3)
  for k in ATTRS:
   if append_fields[mat]:working[mat]['active'][k]=np.concatenate([working[mat]['active'][k],np.asarray([f[k]for f in append_fields[mat]],dtype=working[mat]['old'][k].dtype)])
 verify_protected48(working[0]['old'],working[0]['active'],protected)
 primitive_maps=[]
 for mat,w in working.items():
  verify_unchanged_prefix(w['old'],w['active'],w['normal_halo']);keep=np.array([i for i in range(len(w['old_indices']))if i not in w['remove']],int);active=w['old_indices'][keep]
  if len(newfaces[mat]):active=np.concatenate([active,newfaces[mat]])
  w['expected_active_indices']=active.copy()
  p=d['meshes'][w['mesh']]['primitives'][0]
  for k in ATTRS:
   oldacc=original['accessors'][p['attributes'][k]];p['attributes'][k]=append(d,blob,w['active'][k],oldacc['type'],oldacc['componentType'])
  p['indices']=append(d,blob,active.ravel(),'SCALAR',5125,34963);primitive_maps.append({'mesh':w['mesh'],'primitive':0,'material':mat,'old_to_new_retained_triangles':[{'old':int(old),'new':int(new)}for new,old in enumerate(keep)],'retired_old_triangles':sorted(w['remove']),'new_faces_start':len(keep),'new_faces_count':len(newfaces[mat]),'new_face_source_owners':newface_owners[mat],'normal_halo_old_vertices':sorted(w['normal_halo'])})
 # Every cut/ring material duplicate shares exact actual POS/N/J/W.
 seam_records=[]
 for key in sorted(set(shared_fields)|set(ring_aliases)):
  active_owners=[{'material':mat,'vertex':i}for(mat,k),i in resolved.items()if k==key]
  need(active_owners,'Missing active source seam owner');fields=[{k:working[q['material']]['active'][k][q['vertex']]for k in ATTRS}for q in active_owners];verify_alias_fields(fields);need(all(np.array_equal(fields[0]['NORMAL'],q['NORMAL'])for q in fields[1:]),'Root/cut normal seam');seam_records.append({'source_id':key,'owners':active_owners})
 for k in['nodes','skins','animations','materials','scenes','scene','asset']:need(original.get(k)==d.get(k),'Protected document changed:'+k)
 need(bytes(blob[:len(oldbin)])==bytes(oldbin),'Original binary bytes altered');need(d['accessors'][:len(original['accessors'])]==original['accessors']and d['bufferViews'][:len(original['bufferViews'])]==original['bufferViews'],'Old accessor/view modified')
 for mi,m in enumerate(original['meshes']):
  for pi,p in enumerate(m['primitives']):
   if not any(mi==w['mesh']and pi==0 for w in working.values()):need(p==d['meshes'][mi]['primitives'][pi],'Unrelated primitive changed')
 encoded=encode(d,blob)
 if checkpoint is not None:checkpoint(encoded) # preserve UNVALIDATED bytes before checks
 # Re-decode the serialized candidate; pre-serialization array checks alone
 # must not stand in for actual emitted attribute preservation.
 emitted,emitted_bin=parse(encoded)
 need(bytes(emitted_bin[:len(oldbin)])==bytes(oldbin),'Emitted old binary prefix changed')
 for mat,w in working.items():
  p=emitted['meshes'][w['mesh']]['primitives'][0];actual={k:read(emitted,emitted_bin,p['attributes'][k])for k in ATTRS}
  for k in ATTRS:need(np.array_equal(actual[k],w['active'][k]),'Emitted attribute mismatch:'+k)
  actual_indices=read(emitted,emitted_bin,p['indices']).ravel().reshape(-1,3);verify_emitted_indices(actual_indices,w['expected_active_indices'],len(actual['POSITION']))
  verify_unchanged_prefix(w['old'],actual,w['normal_halo'])
  if mat==0:verify_protected48(w['old'],actual,protected)
 verify_protected_document(original,emitted)
 for mi,m in enumerate(original['meshes']):
  for pi,p in enumerate(m['primitives']):
   if not any(mi==w['mesh']and pi==0 for w in working.values()):need(p==emitted['meshes'][mi]['primitives'][pi],'Serialized unrelated primitive changed')
 for seam in seam_records:
  fs=[]
  for q in seam['owners']:
   w=working[q['material']];p=emitted['meshes'][w['mesh']]['primitives'][0];fs.append({k:read(emitted,emitted_bin,p['attributes'][k])[q['vertex']]for k in ATTRS})
  verify_complete_seam(fs)
 proof={'status':'UNACCEPTED export-local invariants only; candidate SAT/gear pending','input_glb_sha256':digest(raw),'frozen_input_byte_pins':{k:digest(p.read_bytes())for k,p in paths.items()},'candidate_glb_sha256':digest(encoded),'source_topology':source_topology,'protected48_all_attributes_exact':True,'all_old_POS_JOINTS_WEIGHTS_exact':True,'only_exact_rootring_old_NORMAL_halo_changed':{str(mat):sorted(w['normal_halo'])for mat,w in working.items()},'rig_rest_IBMs_nodes_sockets_materials_clips_exact':True,'original_binary_prefix_exact':True,'retired_source_face_owners':retired_records,'actual_primitive_remaps':primitive_maps,'new_vertex_source_owners':new_vertex_records,'new_face_source_owners':candidate['new_face_owners'],'cut_and_ring_seam_records':seam_records,'ring_shared_fields_exact':True,'actual_skin_and_joint_identity':skin_identity,'bridge_material_policy':'Each radial patch inherits actual retained upper ear boundary edge material (coat0 or concave5); no blanket coat relabel','emitted_indices_bounds_and_retirement_exact':True,'serialized_seams_and_protected_document_rechecked':True,'max_source_to_float32_cut_position_delta_m':max(new_position_errors,default=0),'source_match_tolerance_scope':'2e-7m identity/float32 mapping only; SAT1e-8/proper/5mm gear guard unchanged','strict_all63_head_ears_neck_body_self_fit':'NOT RUN; required','unchanged078_first_gear_fit':'NOT RUN; required; prior idle0failure retained','photographic_anatomical_acceptance':False,'light_interval_contract':light}
 counts=[{'mesh':mi,'name':m['name'],'primitives':[{'primitive':pi,'material':p['material'],'active_triangles':d['accessors'][p['indices']]['count']//3,'vertex_accessor_count':d['accessors'][p['attributes']['POSITION']]['count'],'active_referenced_vertex_count':len(np.unique(read(emitted,emitted_bin,p['indices'])))}for pi,p in enumerate(m['primitives'])]}for mi,m in enumerate(d['meshes'])]
 manifest={'schema':'c4d_unaccepted_ear_root_candidate_v1','license':'CC0-1.0','status':'UNACCEPTED; all63 strict self/body/gear and render gates OPEN','input090_sha256':digest(raw),'glb_sha256':digest(encoded),'input_producer_sha256':digest(paths['producer'].read_bytes()),'bytes':len(encoded),'actual_mesh_primitive_table':counts,'triangles':sum(p['active_triangles']for m in counts for p in m['primitives']),'mesh_draws':sum(len(m['primitives'])for m in d['meshes']),'skin_joints':len(d['skins'][0]['joints']),'frame':producer['frame'],'locomotion':producer['locomotion'],'sockets':producer['sockets'],'old_vertex_ranges_removed':'Not an active-surface authority; explicit face/source remaps in export-local-proof.json','baseline_failures_retained':{'854_head_ear_sampled_pairs':832,'854_078_idle0_strict_gear_pairs':258},'candidate_collision_results':'UNTESTED; source topology/export equality do not waive guards','bridge_material_policy':'Inherit coat0 or concave5 from actual retained upper boundary edge; preserve existing cup/exterior distinction','bridge_patch_source_material_owners':[r for r in candidate['planar_construction_proofs']if 'ear_edge'in r]}
 return encoded,manifest,proof

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--input-dir',type=Path,required=True);ap.add_argument('--source-candidate',type=Path,required=True);ap.add_argument('--output-dir',type=Path,required=True);ap.add_argument('--export-reviewed-candidate',action='store_true');args=ap.parse_args();need(args.export_reviewed_candidate,'Actual export requires explicit reviewed-candidate flag');need(args.output_dir.parent.resolve()==Path(__file__).parent.resolve(),'Outside study output only');need(not args.output_dir.exists(),'Refuse overwrite prior witness');edit=json.loads(args.source_candidate.read_text());args.output_dir.mkdir()
 try:encoded,manifest,proof=execute_export(args.input_dir,edit,lambda b:(args.output_dir/'UNVALIDATED-candidate.glb').write_bytes(b))
 except Exception as error:
  (args.output_dir/'FAILED-export.json').write_text(json.dumps({'status':'FAILED; no acceptance','error':str(error),'source_candidate_sha256':digest(args.source_candidate.read_bytes()),'unvalidated_bytes_saved':(args.output_dir/'UNVALIDATED-candidate.glb').exists()},indent=2)+'\n');raise
 (args.output_dir/'equine_ear_root_candidate.glb').write_bytes(encoded);(args.output_dir/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(args.output_dir/'export-local-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
 def pin(p,label):return {'path':label,'sha256':digest(p.read_bytes())}
 authority={'schema':'c4d_unaccepted_ear_root_export_authority_v1','status':'UNACCEPTED; no candidate posed self/gear/render proof','input090_glb_sha256':manifest['input090_sha256'],'source_candidate_input':{'sha256':digest(args.source_candidate.read_bytes()),'role':'external exact source-candidate input, no runtime path dependence'},'pins':[pin(args.output_dir/name,name)for name in ['equine_ear_root_candidate.glb','manifest.json','export-local-proof.json']]+[pin(p,'../'+p.name)for p in sorted(Path(__file__).parent.glob('*.py'))],'actual_guard_scope':'export-local invariants only; source-match2e-7 is not SAT tolerance','required_pending':['Khronos0errors/warnings','twoexactbuilds','actual63head/ear+neck/body SAT/proper+self','boundary+protected48 posed LBS','unchanged078 FIRSTgear fit','normal/render/period/anatomy/photo review'],'baseline_failures_retained':manifest['baseline_failures_retained']};(args.output_dir/'authority.json').write_text(json.dumps(authority,indent=2)+'\n');print('UNACCEPTED candidate exported; no collision/gear/render acceptance')
if __name__=='__main__':main()
