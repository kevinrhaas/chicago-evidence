# Reviewed exporter source revision — actual execution still HELD

Directory: horse-ear-root-exporter-source-reviewed-next. Original31fa source archive and first unexecuted6fee exporter archive remain immutable. No actual source candidate or GLB has been generated/exported, no encode()/execute_export()/Builder.build() horse path has run, no Blender/browser/GPU/SAT sweeps or app/ticket/CI edits occurred. This is authored source with synthetic/light checks only.

Independent source-review corrections

1. Bridge materials are no longer implicitly all-coat. Each radial leafedge patch inherits the UNIQUE actual retained upper boundary edge owner. The light existing-source scan proves10coat0 and8concave5 edges per ear. Both material groups receive their new faces/fields. All material factors/textures remain unchanged; source and eventual manifest/proof disclose the patch owner and original source face. The first all-coat source draft was never executed and remains archived separately.
2. Authored emitted-byte checks now re-decode each active attribute AND exact expected index array, verify index bounds/retirement correspondence, source cut/root material seams (POSITION/NORMAL/JOINTS/WEIGHTS), every protected document field and unrelated primitive after serialization.
3. glb_data.read rejects invalid accessor/view/buffer indices, strided/sparse/normalized data, per-view overflow, declared-buffer overflow and misalignment. Append-only storage preserves the original binary prefix and old accessor/view definitions.
4. Actual skin identity is explicit: coat/inner owners must both use reviewed sole skin0; allowed palette indices are bounds-resolved to actual node names exactly{root,head}. The sorted receipt uses JSON-native ints/strings. Rootring nonzero influences must also belong to that actual set; two arbitrary joints are not sufficient.
5. First failure recovery is authored: the source generator saves partial vertices/face ownership/finished planar proofs on error; exporter saves UNVALIDATED bytes immediately after encoding and BEFORE emitted checks. Failure JSON and exact input hashes remain. These paths have NOT been exercised on a horse.

Unchanged constraints

Exact090input bytes;22lower/18upper source chart; exact6skull complement-only split and176earroot retirement; source-edge knots on BOTHincidentfaces; every radial patch's plane/coverage/injectivity; all48protected attribute vectors; all old positions/joints/weights and outside-halo normals; old visible upper-ear shape; rig/rest/IBMs/sockets/clips/soles/body/gear. Only the exact rootring22coat+18inner old normal vectors may change, never protected48normals. Original cut weights come from actual decoded source fields and shared seams must match exactly. Source↔float32 ownership bound2e-7m is NOT SAT/fit tolerance. SAT1e-8/proper-cross and existing5mm gear guards are unchanged.

New geometry remains entirely UNTESTED. Prior832head-ear sampled contacts and258idle bridle crossings are retained as baseline failures; exporter-local/source proof cannot waive them. No photographic/anatomical/period/continuous-time/performance acceptance follows authored code.

Executed proof scope

All current Python source compiles.28small synthetic tests pass normal and optimized Python: weight/field preservation, protected48, allowed normal halo, seam mismatches, retirement/index order/bounds, accessor storage/view/buffer bounds, root/head skin identity/JSON receipt, material owner ambiguity and source concave material preservation. No test serializes a GLB or constructs a horse; one synthetic accessor is appended only in memory. MATERIAL-OWNERSHIP-LIGHT.json is a read-only original root-edge owner scan, not a new mesh result. The previously executed8generic planar/topology fixture proofs remain in the parent source receipt, not relabeled actual candidate tests.

Proposed bounded actual execution, awaiting root release

A. One CPU process, new output names, at most60s: run generate_source.py with explicit --generate-reviewed-candidate against frozen090, then audit_source.py. STOP/archive on first source/planar/topology failure; no export or repair. This exercises the actual6face complements,22/18patches and full connected source graph for the first time.

B. Only after A passes and root permits continuation: run export_glb.py once with --export-reviewed-candidate into a NEW child directory, performing exact decoded retirement/attributes/protected48/skin/seam checks. STOP/archive first failure. Run Khronos without threshold changes; a second deterministic source+export build only if the first succeeds. This is export-local proof, not a model pass.

C. Separate released CPU scope after successful A/B: actual63decoded head+ear and adjacent neck/body strict self/SAT/area/boundary checks, preserved parent controls, unchanged078FIRSTgear fit and witness preservation before any reroute. No browser until root releases a window after actual reports. All photographs/anatomy/history gates remain open.

Example commands (NOT executed)

    python generate_source.py --input-dir <frozen090trial1> --output-dir <NEWsource-output> --generate-reviewed-candidate
    python audit_source.py <NEWsource-output>/candidate-source-edit.json --input-dir <frozen090trial1>
    python export_glb.py --input-dir <frozen090trial1> --source-candidate <NEWsource-output>/candidate-source-edit.json --output-dir <THISdirectory/NEWexport-output> --export-reviewed-candidate

The explicit output flags do not replace root's current execution hold.
