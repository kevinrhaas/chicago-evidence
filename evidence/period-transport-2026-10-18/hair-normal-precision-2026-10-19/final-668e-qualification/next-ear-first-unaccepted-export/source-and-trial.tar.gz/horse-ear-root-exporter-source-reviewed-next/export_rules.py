# SPDX-License-Identifier: CC0-1.0
"""Pure attribute, frozen-cohort and preservation rules, independently testable."""
import numpy as np
from planar import need
ATTRS=('POSITION','NORMAL','JOINTS_0','WEIGHTS_0')
def blend_weights(joints,weights,coefficients):
 need(len(joints)==len(weights)==len(coefficients),'Weight source count');need(np.isfinite(coefficients).all()and min(coefficients)>=-1e-9 and abs(sum(coefficients)-1)<1e-9,'Bad barycentric coefficients');combined={}
 for ids,ws,c in zip(joints,weights,coefficients):
  need(np.isfinite(ws).all()and min(ws)>=0,'Bad source weights')
  for j,w in zip(ids,ws):
   if w:combined[int(j)]=combined.get(int(j),0)+float(c)*float(w)
 combined={j:max(0,w)for j,w in combined.items()if w>1e-14};need(0<len(combined)<=4,'Too many/no influences');total=sum(combined.values());need(total>0,'Zero influence');ids=sorted(combined);out=[combined[j]/total for j in ids];return ids+[0]*(4-len(ids)),out+[0.]*(4-len(out))

def verify_unchanged_prefix(old,new,normal_halo):
 need(set(old)==set(new)==set(ATTRS),'Unknown/missing skin attribute')
 count=len(old['POSITION']);need(all(len(new[k])>=count for k in ATTRS),'Dropped original vertices');halo=set(normal_halo);need(all(isinstance(i,int)and 0<=i<count for i in halo),'Invalid normal halo')
 for k in ATTRS:
  if k=='NORMAL':
   mask=np.ones(count,bool);mask[list(halo)]=False;need(np.array_equal(old[k][mask],new[k][:count][mask]),'Normal changed outside rootring halo')
  else:need(np.array_equal(old[k],new[k][:count]),'Protected '+k+' changed')
 return True

def verify_protected48(old,new,ids):
 need(len(ids)==48 and len(set(ids))==48,'Protected48 ownership')
 for k in ATTRS:need(np.array_equal(old[k][ids],new[k][ids]),'Protected48 '+k+' changed')
 return True

def verify_alias_fields(fields):
 need(fields,'Missing seam owners')
 for f in fields[1:]:
  for k in['POSITION','JOINTS_0','WEIGHTS_0']:need(np.array_equal(fields[0][k],f[k]),'Source seam owner fields differ:'+k)
 return True

def verify_retirement(actual_skull,actual_ears,expected_skull,expected_ears):
 need(actual_skull==expected_skull and len(actual_skull)==6,'Extra/missing skull face exception');need(actual_ears==expected_ears and sum(len(v)for v in actual_ears.values())==176,'Extra/missing ear face exception');return True

def verify_emitted_indices(actual,expected,vertex_count):
 need(np.array_equal(actual,expected),'Emitted indices differ from exact retirement/new-face map');need(actual.size>0 and int(actual.min())>=0 and int(actual.max())<vertex_count,'Emitted index out of bounds');return True

def verify_complete_seam(fields):
 verify_alias_fields(fields)
 for f in fields[1:]:need(np.array_equal(fields[0]['NORMAL'],f['NORMAL']),'Serialized seam normal differs')
 return True

def verify_protected_document(old,new):
 for k in['nodes','skins','animations','materials','scenes','scene','asset']:need(old.get(k)==new.get(k),'Protected document mismatch:'+k)
 return True

def retained_edge_material(ears,component_tables,boundary_positions):
 owners=[]
 for comp in component_tables:
  e=next(q for q in ears if q['name']==comp['source_component'])
  for fi in comp['remaining_leaf_faces_exact']:
   positions=[tuple(e['positions_local'][k])for k in e['faces'][fi]]
   if all(tuple(p)in positions for p in boundary_positions):owners.append({'component':e['name'],'source_face':fi,'material':e['material']})
 need(len(owners)==1,'Bridge upper boundary must have ONE retained source edge owner');need(owners[0]['material']in[0,5],'Unexpected original ear material');return owners[0]

def verify_skin_identity(document,mesh_ids,allowed_indices):
 need(len(document.get('skins',[]))==1,'Expected one reviewed skin');associations=[]
 for mi in sorted(mesh_ids):
  owners=[(i,n)for i,n in enumerate(document['nodes'])if n.get('mesh')==mi];need(len(owners)==1,'Missing/ambiguous skinned mesh owner');ni,node=owners[0];need(node.get('skin')==0,'Coat/inner mesh must use the same reviewed skin0');associations.append({'mesh':int(mi),'owner_node':int(ni),'owner_name':str(node.get('name','')),'skin':0})
 palette=document['skins'][0]['joints'];identities=[]
 for value in sorted(allowed_indices):
  j=int(value);need(0<=j<len(palette),'Joint palette index out of bounds');ni=palette[j];need(isinstance(ni,int)and 0<=ni<len(document['nodes']),'Joint node index out of bounds');name=document['nodes'][ni].get('name');need(isinstance(name,str),'Unnamed joint node');identities.append({'skin_palette_index':j,'node':ni,'name':name})
 need(len(identities)==2 and{q['name']for q in identities}=={'root','head'},'Influence set must resolve to actual root/head nodes');return{'skin_index':0,'mesh_associations':associations,'influence_node_identities':identities}
