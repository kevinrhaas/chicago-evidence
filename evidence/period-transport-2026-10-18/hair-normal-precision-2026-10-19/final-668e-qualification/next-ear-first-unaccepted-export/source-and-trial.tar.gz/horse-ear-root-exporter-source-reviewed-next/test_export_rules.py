# SPDX-License-Identifier: GPL-3.0-or-later
"""Synthetic tiny arrays only: NEVER calls candidate generation or export."""
import unittest,copy,numpy as np
from export_rules import blend_weights,verify_unchanged_prefix,verify_protected48,verify_alias_fields,verify_retirement,verify_emitted_indices,verify_complete_seam,verify_protected_document,retained_edge_material,verify_skin_identity
from glb_data import append,read

def attrs(n=64):return{'POSITION':np.zeros((n,3),dtype='<f4'),'NORMAL':np.tile(np.array([[0,1,0]],dtype='<f4'),(n,1)),'JOINTS_0':np.tile(np.array([[0,1,0,0]],dtype='<u2'),(n,1)),'WEIGHTS_0':np.tile(np.array([[.2,.8,0,0]],dtype='<f4'),(n,1))}
class ExportControls(unittest.TestCase):
 def test_actual_joint_weight_blend_contract(self):
  j,w=blend_weights([[0,1,0,0],[1,0,0,0],[0,1,0,0]],[[.5,.5,0,0],[.8,.2,0,0],[.2,.8,0,0]],[.25,.25,.5]);self.assertEqual(j,[0,1,0,0]);self.assertAlmostEqual(w[0],.275);self.assertAlmostEqual(w[1],.725)
 def test_invalid_barycentric_rejected(self):
  with self.assertRaises(ValueError):blend_weights([[0,1,0,0]],[[.5,.5,0,0]],[1.2])
 def test_prefix_and_only_declared_normal_halo(self):
  a=attrs();b=copy.deepcopy(a);b['NORMAL'][50]=[1,0,0];self.assertTrue(verify_unchanged_prefix(a,b,{50}));self.assertTrue(verify_protected48(a,b,list(range(48))))
 def test_outside_halo_change_rejected(self):
  a=attrs();b=copy.deepcopy(a);b['NORMAL'][51]=[1,0,0]
  with self.assertRaises(ValueError):verify_unchanged_prefix(a,b,{50})
 def test_any_old_position_change_rejected(self):
  a=attrs();b=copy.deepcopy(a);b['POSITION'][50,0]=.001
  with self.assertRaises(ValueError):verify_unchanged_prefix(a,b,{50})
 def test_protected48_normals_not_exempted(self):
  a=attrs();b=copy.deepcopy(a);b['NORMAL'][3]=[1,0,0]
  with self.assertRaises(ValueError):verify_protected48(a,b,list(range(48)))
 def test_weight_change_not_allowed_even_in_normal_halo(self):
  a=attrs();b=copy.deepcopy(a);b['WEIGHTS_0'][50]=[.3,.7,0,0]
  with self.assertRaises(ValueError):verify_unchanged_prefix(a,b,{50})
 def test_shared_source_seam_rejects_wrong_joint_weights(self):
  a={k:v[0]for k,v in attrs().items()};b=copy.deepcopy(a);b['WEIGHTS_0']=np.array([.3,.7,0,0],dtype='<f4')
  with self.assertRaises(ValueError):verify_alias_fields([a,b])
 def test_retirement_exact6plus176(self):
  skull={4,6,7,16,17,19};ear={str(i):set(range(n))for i,n in enumerate([56,32,56,32])};self.assertTrue(verify_retirement(skull,ear,skull,ear))
  with self.assertRaises(ValueError):verify_retirement(skull|{20},ear,skull,ear)
 def test_append_only_buffer_preserves_old_bytes(self):
  # Raw accessor storage only, not a GLB export/encoding call.
  d={'accessors':[],'bufferViews':[]};blob=bytearray(b'ORIGINAL');prefix=bytes(blob);i=append(d,blob,[[1.,2.,3.]],'VEC3');self.assertEqual(bytes(blob[:len(prefix)]),prefix);np.testing.assert_array_equal(read(d,blob,i),[[1.,2.,3.]])
 def test_joint_uint16_storage(self):
  d={'accessors':[],'bufferViews':[]};blob=bytearray();i=append(d,blob,[[0,1,0,0]],'VEC4',5123);self.assertEqual(read(d,blob,i).dtype,np.dtype('<u2'))
 def test_normalized_accessor_refused(self):
  d={'accessors':[],'bufferViews':[]};blob=bytearray();i=append(d,blob,[[0,1,0,0]],'VEC4',5123);d['accessors'][i]['normalized']=True
  with self.assertRaises(ValueError):read(d,blob,i)
 def test_fifth_influence_rejected(self):
  with self.assertRaises(ValueError):blend_weights([[0,1,2,3],[4,1,2,3]],[[.25,.25,.25,.25],[.25,.25,.25,.25]],[.5,.5])
 def test_negative_source_weight_rejected(self):
  with self.assertRaises(ValueError):blend_weights([[0,1,0,0]],[[1.1,-.1,0,0]],[1])
 def test_emitted_retirement_index_order_corruption(self):
  with self.assertRaises(ValueError):verify_emitted_indices(np.array([[0,2,1]]),np.array([[0,1,2]]),3)
 def test_emitted_index_bounds(self):
  a=np.array([[0,1,3]])
  with self.assertRaises(ValueError):verify_emitted_indices(a,a,3)
 def test_emitted_seam_normal_corruption(self):
  a={k:v[0]for k,v in attrs().items()};b=copy.deepcopy(a);b['NORMAL']=np.array([1,0,0],dtype='<f4')
  with self.assertRaises(ValueError):verify_complete_seam([a,b])
 def test_emitted_document_mutation(self):
  a={'nodes':[{'name':'root'}],'animations':[{'name':'walk'}]};b=copy.deepcopy(a);b['animations'][0]['name']='changed'
  with self.assertRaises(ValueError):verify_protected_document(a,b)
 def test_accessor_cannot_cross_own_view_even_if_buffer_longer(self):
  d={'accessors':[],'bufferViews':[]};b=bytearray();i=append(d,b,[[1.,2.,3.]],'VEC3');b.extend(b'padding-data');d['buffers'][0]['byteLength']=len(b);d['bufferViews'][0]['byteLength']=4
  with self.assertRaises(ValueError):read(d,b,i)
 def test_accessor_wrong_buffer_rejected(self):
  d={'accessors':[],'bufferViews':[]};b=bytearray();i=append(d,b,[[1.,2.,3.]],'VEC3');d['bufferViews'][0]['buffer']=1
  with self.assertRaises(ValueError):read(d,b,i)
 def test_accessor_view_exceeds_declared_buffer(self):
  d={'accessors':[],'bufferViews':[]};b=bytearray();i=append(d,b,[[1.,2.,3.]],'VEC3');d['buffers'][0]['byteLength']=4
  with self.assertRaises(ValueError):read(d,b,i)
 def test_negative_accessor_index_rejected(self):
  d={'accessors':[],'bufferViews':[]};b=bytearray();append(d,b,[[1.,2.,3.]],'VEC3')
  with self.assertRaises(ValueError):read(d,b,-1)
 def test_original_concave_edge_material_preserved(self):
  e=[{'name':'inner','material':5,'positions_local':[[0,0,0],[1,0,0],[0,1,0]],'faces':[[0,1,2]]}];t=[{'source_component':'inner','remaining_leaf_faces_exact':[0]}];self.assertEqual(retained_edge_material(e,t,[[0,0,0],[1,0,0]])['material'],5)
 def test_ambiguous_edge_material_rejected(self):
  e=[{'name':n,'material':m,'positions_local':[[0,0,0],[1,0,0],[0,1,0]],'faces':[[0,1,2]]}for n,m in [('inner',5),('outer',0)]];t=[{'source_component':q['name'],'remaining_leaf_faces_exact':[0]}for q in e]
  with self.assertRaises(ValueError):retained_edge_material(e,t,[[0,0,0],[1,0,0]])
 def skin_document(self):return{'skins':[{'joints':[0,1]}],'nodes':[{'name':'root'},{'name':'head'},{'name':'coat','mesh':0,'skin':0},{'name':'inner','mesh':1,'skin':0}]}
 def test_actual_palette_names_and_json_native_receipt(self):
  import json
  r=verify_skin_identity(self.skin_document(),[1,0],{np.uint16(1),np.uint16(0)});self.assertEqual([x['name']for x in r['influence_node_identities']],['root','head']);json.dumps(r)
 def test_other_two_joint_names_rejected(self):
  d=self.skin_document();d['nodes'][1]['name']='fore_l'
  with self.assertRaises(ValueError):verify_skin_identity(d,[0,1],{0,1})
 def test_different_skin_association_rejected(self):
  d=self.skin_document();d['nodes'][3]['skin']=1
  with self.assertRaises(ValueError):verify_skin_identity(d,[0,1],{0,1})
 def test_out_of_palette_index_rejected(self):
  with self.assertRaises(ValueError):verify_skin_identity(self.skin_document(),[0,1],{0,2})
if __name__=='__main__':unittest.main()
