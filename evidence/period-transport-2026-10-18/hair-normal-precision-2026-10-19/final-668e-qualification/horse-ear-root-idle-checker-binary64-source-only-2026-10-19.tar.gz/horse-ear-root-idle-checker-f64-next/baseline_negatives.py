# SPDX-License-Identifier: GPL-3.0-or-later
"""Source-owner negatives derived from immutable prior actual idle0 receipts."""
import json,hashlib
PINS={'posed-head-self.json':'a8b9b15c3e4361e91585022baa4e6d163813e03935b46e9a253e9e8ac10be863','witness-owners.json':'d608e3a92ce501ea04cfe87cb94a2d518b538d97870edad79811129de0def2d1'}
def expected_cohort(directory):
 docs={}
 for n,h in PINS.items():
  raw=(directory/n).read_bytes()
  if hashlib.sha256(raw).hexdigest()!=h:raise ValueError('Prior negative receipt SHA mismatch: '+n)
  docs[n]=json.loads(raw)
 rows=[r for r in docs['posed-head-self.json']['rows']if r['clip']=='idle'and r['phase']==0]
 if len(rows)!=1:raise ValueError('Ambiguous prior idle0 negative receipt')
 owners={r['global_triangle']:r['source_matches']for r in docs['witness-owners.json']['rows']};result=set()
 for w in rows[0]['strict_crossings']:
  if not w.get('proper'):raise ValueError('Prior negative lacks strict proper witness')
  a,b=[owners[i]for i in[w['a_global'],w['b_global']]]
  if len(a)!=1 or len(b)!=1:raise ValueError('Ambiguous prior source owner')
  a,b=a[0],b[0]
  if a['source']!='continuous_head':a,b=b,a
  if a['source']!='continuous_head'or len(a['source_face_ids'])!=1 or len(b['source_face_ids'])!=1:raise ValueError('Unexpected prior negative signature')
  result.add((a['source_face_ids'][0],b['source'],b['source_face_ids'][0]))
 explicit={(17,'ear_outer_-1',i)for i in range(259,266)}|{(17,'ear_concave_-1',i)for i in[10,12,13,14,15]}
 if result!=explicit or len(rows[0]['strict_crossings'])!=12:raise ValueError('Prior actual twelve-signature cohort changed')
 return result

def signature(a,b):
 if a.get('kind')=='baseline_ear':a,b=b,a
 if a.get('kind')!='baseline_head'or b.get('kind')!='baseline_ear':return None
 return(a['source_head_face'],b['component'],b['source_face'])

def verify_negative_cohort(scopes,directory):
 expected=expected_cohort(directory);found=set();other=[]
 for r in scopes:
  for w in r['unexpected_witnesses']:
   s=signature(w['a_source_face_owner'],w['b_source_face_owner'])
   if w['kind']=='unexpected_strict_proper'and w.get('proper_witness')is not None and s in expected:found.add(s)
   else:other.append({'a_global':w['a_global'],'b_global':w['b_global'],'kind':w['kind'],'source_signature':s})
 missing=expected-found
 return{'complete':not missing and all(r['complete']for r in scopes),'expected_count':12,'detected_strict_known_count':len(found),'missing_signatures':sorted(missing),'expected_signatures':sorted(expected),'detected_signatures':sorted(found),'additional_findings_separate':other,'provenance_sha256':PINS,'status':'Known negative failures retained; no candidate exemption'}
