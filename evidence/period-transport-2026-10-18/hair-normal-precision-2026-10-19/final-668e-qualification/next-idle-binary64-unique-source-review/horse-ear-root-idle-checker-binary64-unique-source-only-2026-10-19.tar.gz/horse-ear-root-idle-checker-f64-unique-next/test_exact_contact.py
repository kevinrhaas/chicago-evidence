# SPDX-License-Identifier: GPL-3.0-or-later
import unittest
from exact_contact import source_vertex_only,ray_inside_cone,source_edge_only
class ExactContactControls(unittest.TestCase):
 def test_coplanar_point_only(self):
  a=[[0,0,0],[1,0,0],[0,1,0]];b=[[0,0,0],[-1,0,0],[0,-1,0]];self.assertIsNotNone(source_vertex_only(a,b,0,0))
 def test_non_coplanar_point_only(self):
  a=[[0,0,0],[1,0,0],[0,1,0]];b=[[0,0,0],[-1,0,1],[0,-1,1]];self.assertIsNotNone(source_vertex_only(a,b,0,0))
 def test_shared_vertex_but_interior_crossing_not_certified(self):
  a=[[0,0,0],[1,0,0],[0,1,0]];b=[[0,0,0],[.5,.5,-1],[.5,.5,1]];self.assertIsNone(source_vertex_only(a,b,0,0))
 def test_unowned_edge_overlap_not_certified(self):
  a=[[0,0,0],[1,0,0],[0,1,0]];b=[[0,0,0],[.5,0,0],[0,-1,0]];self.assertIsNone(source_vertex_only(a,b,0,0))
 def test_coplanar_area_overlap_not_certified(self):
  a=[[0,0,0],[1,0,0],[0,1,0]];b=[[0,0,0],[.5,0,0],[0,.5,0]];self.assertIsNone(source_vertex_only(a,b,0,0))
 def test_same_source_id_with_nonexact_world_point_rejected(self):
  a=[[0,0,0],[1,0,0],[0,1,0]];b=[[1e-12,0,0],[-1,0,0],[0,-1,0]];self.assertIsNone(source_vertex_only(a,b,0,0))
 def test_integer_cone_membership(self):
  self.assertTrue(ray_inside_cone((1,1,0),(1,0,0),(0,1,0)));self.assertFalse(ray_inside_cone((-1,1,0),(1,0,0),(0,1,0)))
 def test_registered_edge_noncoplanar_geometry(self):
  a=[[0,0,0],[1,0,0],[0,1,0]];b=[[1,0,0],[0,0,0],[0,0,1]];self.assertIsNotNone(source_edge_only(a,b,['p','q','a'],['q','p','b']))
 def test_registered_edge_coplanar_opposite_halves(self):
  a=[[0,0,0],[1,0,0],[0,1,0]];b=[[1,0,0],[0,0,0],[0,-1,0]];self.assertIsNotNone(source_edge_only(a,b,['p','q','a'],['q','p','b']))
 def test_registered_edge_coplanar_foldover_rejected(self):
  a=[[0,0,0],[1,0,0],[0,1,0]];b=[[1,0,0],[0,0,0],[.25,.5,0]];self.assertIsNone(source_edge_only(a,b,['p','q','a'],['q','p','b']))
 def test_edge_source_orientation_alone_rejected(self):
  a=[[0,0,0],[1,0,0],[0,1,0]];b=[[0,0,0],[1,0,0],[0,-1,0]];self.assertIsNone(source_edge_only(a,b,['p','q','a'],['p','q','b']))
if __name__=='__main__':unittest.main()
