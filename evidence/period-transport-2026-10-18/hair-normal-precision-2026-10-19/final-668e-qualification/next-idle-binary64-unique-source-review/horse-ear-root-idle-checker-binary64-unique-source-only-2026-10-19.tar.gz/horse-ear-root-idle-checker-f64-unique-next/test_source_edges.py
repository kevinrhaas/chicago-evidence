# SPDX-License-Identifier: GPL-3.0-or-later
import unittest,copy
from source_edges import owned_adjacency

def disk_and_rest():
 p=['h:'+str(i)for i in range(24)];head=[[p[i],p[(i+1)%24],'centre']for i in range(24)];rest=[[p[(i+1)%24],p[i],'rest:'+str(i)]for i in range(24)];return head+rest,set(range(24))
class SourceEdgeControls(unittest.TestCase):
 def test_only_declared_opposite_edge_and_portal_registration(self):
  r,h=disk_and_rest();a,p,t=owned_adjacency(r,h,len(r),1,1);self.assertEqual(len(a),24);self.assertEqual(len(p),24);self.assertEqual(t['boundary_edges'],24)
 def test_wrong_portal_winding_rejected(self):
  r,h=disk_and_rest();r[24]=r[24][::-1]
  with self.assertRaises(ValueError):owned_adjacency(r,h,len(r),1,1)
 def test_duplicate_portal_owner_rejected(self):
  r,h=disk_and_rest();r.append(r[24])
  with self.assertRaises(ValueError):owned_adjacency(r,h,len(r),1,1)
 def test_baseline_three_components_euler5(self):
  r,h=disk_and_rest()
  for side in['earL','earR']:
   v=[side+str(i)for i in range(4)];start=len(r);r.extend([[v[0],v[2],v[1]],[v[0],v[1],v[3]],[v[1],v[2],v[3]],[v[2],v[0],v[3]]]);h.update(range(start,start+4))
  _,_,t=owned_adjacency(r,h,len(r),3,5);self.assertEqual(t['components'],3);self.assertEqual(t['Euler'],5)
if __name__=='__main__':unittest.main()
