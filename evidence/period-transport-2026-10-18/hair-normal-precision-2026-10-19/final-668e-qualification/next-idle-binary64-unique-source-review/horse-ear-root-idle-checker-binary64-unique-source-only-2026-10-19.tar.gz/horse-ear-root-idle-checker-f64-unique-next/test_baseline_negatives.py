# SPDX-License-Identifier: GPL-3.0-or-later
import unittest
from pathlib import Path
from baseline_negatives import expected_cohort,verify_negative_cohort
class Controls(unittest.TestCase):
 def rows(self):
  out=[]
  for h,c,f in expected_cohort(Path(__file__).parent/'provenance'):
   out.append({'a_source_face_owner':{'kind':'baseline_head','source_head_face':h},'b_source_face_owner':{'kind':'baseline_ear','component':c,'source_face':f},'kind':'unexpected_strict_proper','proper_witness':{'point':True},'a_global':1,'b_global':f})
  return out
 def check(self,rows):return verify_negative_cohort([{'scope':'head_internal','complete':True,'unexpected_witnesses':rows}],Path(__file__).parent/'provenance')
 def test_all12(self):self.assertTrue(self.check(self.rows())['complete'])
 def test_one_missing_fails(self):self.assertFalse(self.check(self.rows()[:-1])['complete'])
 def test_raw_only_fails(self):
  r=self.rows();r[0]['kind']='unexpected_raw_SAT';self.assertFalse(self.check(r)['complete'])
 def test_duplicates_do_not_fill_missing(self):
  r=self.rows();r[-1]=r[0];self.assertFalse(self.check(r)['complete'])
 def test_all12_plus_duplicate_rejected(self):
  r=self.rows();r.append(dict(r[0]));d=self.check(r);self.assertFalse(d['complete']);self.assertEqual(len(d['duplicate_known_signatures']),1);self.assertEqual(len(d['duplicate_actual_pairs']),1)
 def test_same_signature_different_pair_rejected(self):
  r=self.rows();x=dict(r[0]);x['a_global']=9;r.append(x);d=self.check(r);self.assertFalse(d['complete']);self.assertEqual(len(d['duplicate_known_signatures']),1)
 def test_broader_separate(self):
  r=self.rows();extra=dict(r[0]);extra['b_source_face_owner']={'kind':'baseline_ear','component':'ear_outer_-1','source_face':0};r.append(extra);d=self.check(r);self.assertTrue(d['complete']);self.assertEqual(len(d['additional_findings_separate']),1)
if __name__=='__main__':unittest.main()
