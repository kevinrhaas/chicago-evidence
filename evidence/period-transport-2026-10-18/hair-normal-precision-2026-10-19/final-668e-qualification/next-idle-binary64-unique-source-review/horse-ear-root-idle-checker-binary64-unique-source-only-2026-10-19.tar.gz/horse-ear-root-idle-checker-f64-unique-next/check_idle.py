# SPDX-License-Identifier: GPL-3.0-or-later
"""Prepared ONLY. Actual idle0 CPU check requires separate root release.
No geometry mutation, gear capture, browser, GPU, Blender or63pose sweep.
"""
from pathlib import Path
import argparse,json,hashlib,time,traceback
import numpy as np
import official_fit_predicates as predicates
from planar import need
from ownership import pinned,frozen_baseline,candidate_from_maps,triangle_labels,verify_source_seams,PINS
from source_edges import owned_adjacency
from classify_contact import classify_raw
from exact_contact import source_edge_only
from baseline_negatives import verify_negative_cohort

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,r):p.write_text(json.dumps(r,indent=2)+'\n')
def jsonpin(p,k):return json.loads(pinned(p,k))

def load_capture(directory,label,model,want):
 meta=json.loads((directory/(label+'.json')).read_text());datafile=directory/(label+'.f64');need(meta['input_sha256']==want and sha(datafile)==meta['buffer_sha256'],'Actual capture input/data hash');need(meta['pose']['clip']=='idle'and meta['pose']['time_s']==0 and meta['pose']['phase']==0,'Only actual idle0 supported');need(meta['triangleCount']==model.total,'Actual full active triangle count');seen=set()
 need(meta.get('storage')=={'format':'IEEE754-binary64','byte_order':'little-endian','bytes_per_coordinate':8,'bytes_per_triangle':72,'coordinate_stage':'Three-CPU-after-skinning-and-matrixWorld','post_world_rounding':False},'Capture must preserve actual world binary64 without post-world rounding')
 for p in meta['primitives']:
  key=p['mesh'],p['primitive'];need(key in model.views and key not in seen,'Actual GLTFLoader association ownership');seen.add(key);v=model.views[key];need(p['start']==model.start[key]and p['count']==len(v['indices'])and p['vertex_accessor_count']==len(v['attributes']['POSITION']),'Capture/index active ownership mismatch');need(len(p['skin_joint_names'])==15,'Unexpected actual skin')
 need(seen==set(model.views),'Missing actual primitive capture');data=np.memmap(datafile,mode='r',dtype='<f8',shape=(model.total,3,3));need(datafile.stat().st_size==model.total*72 and np.isfinite(data).all(),'Actual capture buffer extent/nonfinite');areas=np.linalg.norm(np.cross(data[:,1]-data[:,0],data[:,2]-data[:,0]),axis=1)/2;need(float(areas.min())>1e-12,'Actual emitted degenerate triangle');return meta,data,areas

def world_aliases(records,data):
 points={}
 for t,tri in zip(records,data):
  for source,p in zip(t,tri):
   value=tuple(map(float,p));old=points.setdefault(source,value);need(old==value,'Actual posed source alias coordinates not bit-exact:'+source)
 return len(points)

def scan(label,scope,model,records,head,data,adjacency,out,stop_first):
 started=time.monotonic();selected=sorted(head);target_ids=np.array(selected if scope=='head_internal'else sorted(set(range(model.total))-head),int);target=np.asarray(data[target_ids],float);lo=target.min(1);hi=target.max(1);counts={'source_edge_wholepairs_certified':0,'uncertified_source_edge_pairs':0,'AABB_pairs_requiring_SAT':0,'raw_SAT':0,'strict_proper':0,'proven_source_vertex_only':0,'unexpected_SAT':0};accepted=[];unexpected=[];edges_certified=[];progress={'label':label,'scope':scope,'complete':False,'counts':counts,'accepted_point_certificates':accepted,'actual_source_edge_certificates':edges_certified,'unexpected_witnesses':unexpected,'SAT_epsilon_unchanged':1e-8,'point_certificate_tolerance':None}
 def save():progress['elapsed_s']=time.monotonic()-started;write(out/(label+'-'+scope+'.json'),progress)
 for order,gi in enumerate(selected):
  a=np.asarray(data[gi],float);possible=np.flatnonzero(np.all(hi>=a.min(0)-1e-8,axis=1)&np.all(lo<=a.max(0)+1e-8,axis=1))
  for k in possible:
   gj=int(target_ids[k])
   if scope=='head_internal'and gj<=gi:continue
   b=target[k];uncertified_edge=False
   if tuple(sorted((gi,gj)))in adjacency:
    edge_proof=source_edge_only(a,b,records[gi],records[gj])
    if edge_proof is not None:
     counts['source_edge_wholepairs_certified']+=1;edges_certified.append({'a':gi,'b':gj,'proof':edge_proof});continue
    counts['uncertified_source_edge_pairs']+=1;uncertified_edge=True
   counts['AABB_pairs_requiring_SAT']+=1
   sat=predicates.sat(a,b)
   if not sat:
    need(not uncertified_edge,'Registered actual edge lacks certificate and SAT unexpectedly denies contact');continue
   counts['raw_SAT']+=1;proper=predicates.proper(a,b);counts['strict_proper']+=int(proper is not None);result=classify_raw(a,b,records[gi],records[gj],proper)
   if result['kind']=='proven_source_vertex_only':
    counts['proven_source_vertex_only']+=1;accepted.append({'a':gi,'b':gj,**result});continue
   counts['unexpected_SAT']+=1;unexpected.append({'a_global':gi,'b_global':gj,'a_owner':model.descriptor(gi),'b_owner':model.descriptor(gj),'a_source_face_owner':getattr(model,'source_face_owners',{}).get(gi,{'kind':'rest_active_primitive'}),'b_source_face_owner':getattr(model,'source_face_owners',{}).get(gj,{'kind':'rest_active_primitive'}),'a_source_vertices':records[gi],'b_source_vertices':records[gj],'actual_triangles_world':[a.tolist(),b.tolist()],**result});save()
   if stop_first:return progress
  progress['completed_head_triangle_prefix']=order+1
  if order%250==0:save()
 progress['complete']=True;save();return progress

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--baseline-dir',type=Path,required=True);ap.add_argument('--candidate-dir',type=Path,required=True);ap.add_argument('--source-candidate',type=Path,required=True);ap.add_argument('--capture-dir',type=Path,required=True);ap.add_argument('--output-dir',type=Path,required=True);args=ap.parse_args();need(not args.output_dir.exists(),'Refuse overwrite prior numerical witnesses');args.output_dir.mkdir(parents=True);out=args.output_dir;started=time.monotonic()
 try:
  baseline_raw=pinned(args.baseline_dir/'equine_light_harness_skinned_prototype_01.glb','baseline');candidate_raw=pinned(args.candidate_dir/'equine_ear_root_candidate.glb','candidate');producer=jsonpin(args.baseline_dir/'manifest.json','producer090');head=jsonpin(args.baseline_dir/'head-source-surface.json','head');ears=jsonpin(args.baseline_dir/'ear-source-surfaces.json','ears');proof=jsonpin(args.candidate_dir/'export-local-proof.json','proof');fresh_producer=jsonpin(args.candidate_dir/'manifest.json','producer260');source=jsonpin(args.source_candidate,'source_candidate')
  old,ol,oh,oo=frozen_baseline(baseline_raw,producer,head,ears);new,nl,nh,no,reverse=candidate_from_maps(candidate_raw,old,ol,oh,oo,proof,source);need(fresh_producer['triangles']==new.total,'Current active producer count');verify_source_seams(old,ol);verify_source_seams(new,nl);old.source_face_owners=oo;new.source_face_owners=no;orows=triangle_labels(old,ol);nrows=triangle_labels(new,nl);oa,op,ot=owned_adjacency(orows,oh,old.total,3,5);na,np_,nt=owned_adjacency(nrows,nh,new.total,1,1)
  om,od,oareas=load_capture(args.capture_dir,'baseline',old,PINS['baseline']);nm,nd,nareas=load_capture(args.capture_dir,'candidate',new,PINS['candidate']);need(om['pose']==nm['pose']and om['root_world']==nm['root_world']and om['head_world']==nm['head_world'],'Baseline/candidate actual frame/pose mismatch');world_aliases(orows,od);world_aliases(nrows,nd)
  ownership={'status':'Actual active index/source ownership verified only','baseline_head_triangles':len(oh),'candidate_head_triangles':len(nh),'candidate_rest_triangles':new.total-len(nh),'baseline_topology':ot,'candidate_topology':nt,'baseline_head_global_ids':sorted(oh),'candidate_head_global_ids':sorted(nh),'candidate_primitive_active_maps':proof['actual_primitive_remaps'],'source_edge_registration_requires_actual_dyadic_nonfoldover_certificate':True,'one_shared_vertex_not_excluded':True,'coordinate_identity_scope':'Pinned semantic source ranges plus explicit source/primitive maps; no whole-coat nearest-point ownership','input_pins':PINS};write(out/'active-ownership.json',ownership);write(out/'source-face-owners.json',{'baseline':oo,'candidate':no,'candidate_to_baseline_retained_face_map':reverse})
  predicates.predicate_controls();baseline_scopes=[]
  for scope,adj in[('head_internal',oa),('head_vs_all_rest',op)]:baseline_scopes.append(scan('baseline',scope,old,orows,oh,od,adj,out,False))
  negative_report=verify_negative_cohort(baseline_scopes,Path(__file__).parent/'provenance');write(out/'baseline-negative-control.json',negative_report);need(negative_report['complete'],'Baseline known12 negative control INCOMPLETE; STOP')
  results=[]
  for scope,adj in[('head_internal',na),('head_vs_all_rest',np_)]:
   r=scan('candidate',scope,new,nrows,nh,nd,adj,out,True);results.append({'scope':scope,'counts':r['counts'],'complete':r['complete']})
   if r['counts']['unexpected_SAT']or r['counts']['strict_proper']:
    write(out/'RESULT.json',{'pass':False,'status':'FIRST candidate unexpectedSAT/proper failure; STOP, no repair/gear','candidate_scopes':results,'other_scopes':'UNTESTED if absent','elapsed_s':time.monotonic()-started});raise SystemExit(1)
  write(out/'RESULT.json',{'pass':True,'status':'Bounded actual idle0 source-simplex/contact geometry ONLY; UNACCEPTED overall','candidate_scopes':results,'gear':'NOT RUN','all63poses':'NOT RUN','render/anatomy/photo':'NOT ACCEPTED','elapsed_s':time.monotonic()-started})
 except Exception as error:
  write(out/'FAILED.json',{'status':'FAILED checker/input/source/capture proof; STOP','error':str(error),'traceback':traceback.format_exc(),'elapsed_s':time.monotonic()-started});raise
if __name__=='__main__':main()
