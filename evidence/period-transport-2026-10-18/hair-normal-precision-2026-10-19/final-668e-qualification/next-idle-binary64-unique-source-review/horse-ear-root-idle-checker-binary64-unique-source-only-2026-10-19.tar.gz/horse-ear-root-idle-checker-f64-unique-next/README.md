# Prepared idle0 head/ear checker — NOT EXECUTED on horse

This is a source-only proposal. Candidate and baseline GLBs, poses, SAT, gear and visual acceptance have NOT been measured by this checker. Existing exports remain unchanged. Root release is required before either command below runs.

Scope: actual indexed 2960-face candidate head/ears internally and against every other active horse triangle, plus the actual 090 parent under identical scope as a negative control. Actual parser mesh/primitive associations, skinned world positions and active source ownership are checked. Ownership matching is restricted to pinned semantic head ranges; duplicate body positions cannot establish head identity.

Registered opposite source edges are excluded only after an exact dyadic actual-coordinate certificate: equal endpoints and nondegenerate distinct planes, or exactly coplanar third vertices on opposite edge halfplanes. Coplanar foldover has no certificate. Shared single vertices still undergo unchanged SAT and proper predicates; proper crossings always fail. A raw SAT contact can pass only with an exact certificate restricting the intersection to its one registered identical source point. Unexplained contacts fail. SAT epsilon remains 1e-8; no contact tolerance is introduced.

Counters distinguish certified source edges, uncertified edges, raw SAT, strict proper, certified source-point-only contacts and unexpected SAT. First candidate unexpected/proper failure stops and saves witnesses. Parent failures are retained as negatives, never exemptions. A candidate pass establishes only this discrete idle0 scope, not 63 poses, bridle fit, anatomy or photographic acceptance.

## Proposed ONE bounded execution (AWAIT ROOT RELEASE)

Run CPU capture first, then checker only on exit0, using NEW capture/result directories. Entire sequential capture/check must be externally capped at 120 seconds; preserve logs and any partial output on timeout/failure; no retry or repair.

```
node --loader /workspace/shared/horse-ear-root-idle-checker-f64-unique-next/three-loader.mjs /workspace/shared/horse-ear-root-idle-checker-f64-unique-next/capture_idle.mjs --candidate /workspace/shared/horse-ear-root-exporter-source-reviewed-next/export-trial1/equine_ear_root_candidate.glb --baseline /workspace/shared/horse-head-groove-coat-next/trial1/equine_light_harness_skinned_prototype_01.glb --output-dir NEW_CAPTURE
/workspace/shared/chicago-venv/bin/python /workspace/shared/horse-ear-root-idle-checker-f64-unique-next/check_idle.py --baseline-dir /workspace/shared/horse-head-groove-coat-next/trial1 --candidate-dir /workspace/shared/horse-ear-root-exporter-source-reviewed-next/export-trial1 --source-candidate /workspace/shared/horse-ear-root-exporter-source-reviewed-next/source-trial1/candidate-source-edit.json --capture-dir NEW_CAPTURE --output-dir NEW_RESULTS
```

27 Python synthetic source/control tests pass under normal Python and -O. These tests do not load or generate horse geometry. Node capture syntax is checked. No execution time for the actual scope is claimed. GPL-3.0-or-later checker/certificate code; copied glb_data/planar retain their original SPDX; copied official predicates remain unchanged GPL. No asset licensing changes.

## Reviewed revision blockers addressed

Capture stores actual post-skin/world JavaScript doubles as explicit writeDoubleLE binary64 (.f64), without Float32 conversion; checker enforces storage metadata and72bytes/triangle. A tiny Node control proves exact double roundtrip and detects float32 information loss.

All12 actual prior idle0 proper negative signatures are derived from hash-pinned copied posed-head-self.json and witness-owners.json. Expected source face17 versus outer right ear259..265 and concave right ear10,12,13,14,15 must ALL recur as strict proper findings. Missing, raw-only, duplicated or incomplete coverage stops before candidate. Broader findings remain separate. Receipt coordinates were historically rounded; only source-owner identity and existing failure provenance are reused; fresh actual coordinates will be binary64.

No actual horse capture/check has run. Original a5dc archive is unchanged.

Final revision: expected known signatures must occur EXACTLY ONCE each. Occurrences include scope and sorted actual triangle pair; duplicate-known signatures and duplicate actual pairs are recorded and force incomplete/STOP. Controls include all12 plus duplicate, and same signature with different actual pair. Prior216352 archive remains frozen.
