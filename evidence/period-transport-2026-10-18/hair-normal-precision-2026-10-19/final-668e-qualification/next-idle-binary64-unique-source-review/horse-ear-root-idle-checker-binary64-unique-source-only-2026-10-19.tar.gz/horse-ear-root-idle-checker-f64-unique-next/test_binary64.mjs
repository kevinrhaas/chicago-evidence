// SPDX-License-Identifier: GPL-3.0-or-later
import assert from'node:assert/strict';
const actual=new Float64Array([1.976602554321289+1e-10,-.06963729113340378+1e-11,Math.PI]);const bytes=Buffer.alloc(actual.length*8);actual.forEach((v,i)=>bytes.writeDoubleLE(v,i*8));actual.forEach((v,i)=>assert.equal(bytes.readDoubleLE(i*8),v));assert.notEqual(Math.fround(actual[0]),actual[0]);assert.equal(bytes.length,24);console.log('PASS binary64 exact roundtrip; binary32 rounding negative control');
