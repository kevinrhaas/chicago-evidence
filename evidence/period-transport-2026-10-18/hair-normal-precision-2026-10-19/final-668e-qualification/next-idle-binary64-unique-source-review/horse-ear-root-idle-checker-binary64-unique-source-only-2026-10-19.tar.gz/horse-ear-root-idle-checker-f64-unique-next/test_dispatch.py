# SPDX-License-Identifier: GPL-3.0-or-later
import unittest,numpy as np
from ownership import semantic_match,PINS
from classify_contact import classify_raw
class DispatchControls(unittest.TestCase):
 def test_body_duplicate_does_not_override_semantic_head_range(self):
  pos=np.array([[0,0,0],[1,0,0],[0,0,0],[1,0,0]],dtype='<f4');self.assertEqual(semantic_match(pos,range(2,4),[0,0,0]),2)
 def test_whole_mesh_ambiguous_duplicate_rejected(self):
  pos=np.array([[0,0,0],[0,0,0]],dtype='<f4')
  with self.assertRaises(ValueError):semantic_match(pos,range(2),[0,0,0])
 def test_proper_witness_never_exempted_by_owned_vertex(self):
  a=[[0,0,0],[1,0,0],[0,1,0]];b=[[0,0,0],[-1,0,0],[0,-1,0]];r=classify_raw(a,b,['p','a','b'],['p','c','d'],{'forced_control':'muststayred'});self.assertEqual(r['kind'],'unexpected_strict_proper')
 def test_registered_point_only_dispatch(self):
  a=[[0,0,0],[1,0,0],[0,1,0]];b=[[0,0,0],[-1,0,0],[0,-1,0]];self.assertEqual(classify_raw(a,b,['p','a','b'],['p','c','d'],None)['kind'],'proven_source_vertex_only')
 def test_unowned_point_contact_stays_failure(self):
  a=[[0,0,0],[1,0,0],[0,1,0]];b=[[0,0,0],[-1,0,0],[0,-1,0]];self.assertEqual(classify_raw(a,b,['p','a','b'],['unowned','c','d'],None)['kind'],'unexpected_raw_SAT')
 def test_vertex_identity_does_not_excuse_unowned_edge_overlap(self):
  a=[[0,0,0],[1,0,0],[0,1,0]];b=[[0,0,0],[.5,0,0],[0,-1,0]];self.assertEqual(classify_raw(a,b,['p','a','b'],['p','c','d'],None)['kind'],'unexpected_raw_SAT')
 def test_all_frozen_pins_are_full_sha256(self):
  for v in PINS.values():self.assertEqual(len(v),64);int(v,16)
if __name__=='__main__':unittest.main()
