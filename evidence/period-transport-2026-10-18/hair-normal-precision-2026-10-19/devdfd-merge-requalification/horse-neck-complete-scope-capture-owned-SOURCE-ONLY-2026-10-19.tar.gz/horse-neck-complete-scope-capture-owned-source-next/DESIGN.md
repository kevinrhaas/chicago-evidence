# Complete neck checker + metadata producer — SOURCE/MOCK ONLY

All previous789337 and2ad578 archives are untouched. No actual horse geometry/export/capture/SAT/parameter evaluation or metadata production has run.13synthetic/mock tests pass normal and -O; source syntax compiles. Initial test authoring had one syntax typo and two controls aimed at irrelevant mockfaces; corrected targets remove selectedface48 and reverse boundary-ownerface47. These were test authoring failures, not actualhorse evidence.

## Dedicated96face scope

`neck_scope.annulus_ownership` maps original source loft strips7/8 through exact oriented primitive index triples, never proximity. Unique96active faces, one component/Euler0, exact two24edge loops (ring7 body168..191 and portalh0..23) required. This is explicitly an ANNULUS, not a head disk. Each shared edge requires exactlytwo opposite source owners; actual nonfoldover certificate is still required by unchanged scan. No wholepair skip based only on registration.

`check_changed_neck` scans96face internal unorderedpairs, then96versusALLremainingactivehorse (including remainingbody/head/ears). Unchanged SAT1e-8/proper, exactdyadic actualedge and point rules, rawSAT categories and first unexpected/proper STOP are inherited. Generic engine labels retain head_internal/head_vs_all_rest only as scan selectors; receipt explicitly identifies changed_neck_INTERNAL/changed_neck_vsALL_REMAINING. `check_threeway` verifies annulus ownership before ANY collision; then original090known12/parent26027negative, freshheadinternal→headvsALLrest, then dedicatedneckinternal→neckvsALLrest. Later absent scopes remain UNTESTED after first failure. No waivers or rawSAT exemptions added.

## Actual-byte metadata producer proposal

`produce_metadata` takes actual immutable parent/newGLB/proof bytes and pinned original090/earproducer/proof/source/authority bytes. It verifies every supplied SHA/actual shape, primitive identity/index and sparse attribute extent, originalaccessor/view/BIN/document protection, decodedproof linkage, source-owned2960head+ears,24portal aliases and96neckannulus. Source reconstruction calls frozen090→26027 maps; no caller-supplied ownership callback or proximity inference. Only after allchecks can it serialize deterministic newmanifest,authority,packet bytes. There is nogeometrygenerator here. It never writes/publishes or declares acceptance.

Newmanifest references actualnewGLB+proof, original090/26027, explicitPOS192..215/NORMAL168..215 and allotherattributesexact; authorityreferences actualGLB+manifest+oldproducerchain. Packetbinds actualfileSHAs and canonicalrelative filenames. No selfhashcycles. The newmetadata is UNACCEPTED and lists collision/63poses/gear/visualanatomyphoto NOT RUN. Raw formatting helper `build_metadata` exists for mocks only; its output is never sufficient for acceptance: future exact root-pinned files+packet and full threewaybyteverification remain mandatory.

Actualfuturecandidate and itsmetadata DO NOT EXIST. This proposal closes source scope design, not actual feasibility, chain qualification, collision/gear or photographic gates. Freshactualgeneration, localexport and boundedreadback trial need independentreview/rootrelease; no execution command is authorized by this parcel.

## Reviewed preservation/portability revision

`with_exclusive_output` atomically creates the NEWoutputdirectory outside its exception handler; preexisting/racingdirectory refuses without any failurewrite. Only ownedfreshdir can receive FIRST-FAILURE. Sentinelbytes test preserves both prior sentinel and priorFIRSTFAILURE unchanged; mockownedfailure saves its own receipt. The innerworker no longer owns mkdir.

Packetcomponents require exact canonicalbasenames candidate.glb,manifest.json,sparse-export-proof.json,authority.json and resolvedparent containment; absolute,parentescape,renames and escaping symlinks refuse. Capture repeats candidatebasename/realpath guard. `declared_scope` enters scan progress BEFORE any save, rather than after serialization.

Metadata manifest/authority/packet now all bind the complete recursive local .py/.mjs helperinventory+canonicalinventorydigest, not producer.pyalone. Chainverifier compares that inventory against its actual localhelpers before collision. Sourceinventory and escapedpath controls added.17synthetic/mock tests normal/-O PASS. No actualhorse I/O/evaluation, generation/export/capture/SAT or metadata production ran. Originaldc7archive remains untouched.

## Capture-output exclusive ownership correction

Capture now imports claimCaptureOutput: optional recursive PARENT creation followed by atomic NONRECURSIVE leafmkdir. No existsSync+recursiveleaf acceptance remains. Claim occurs before receipt construction/try/finally, so preexisting/racedleaf refuses without any capture/failurewrites. Nodecontrols preserve exactexisting sentinel+capturereceipt bytes, injectcompeting leafcreation betweenparentmkdir andleafclaim, confirmracesentinelunchanged, and exercisefreshclaim. These load only outputhelper and tempfiles, not Three/GLTF/horseinputs. Nodecontrol+capturesyntax pass. No actualcapture/export/SAT ran; previousd011 archive is unchanged.
