# SPDX-License-Identifier: GPL-3.0-or-later
"""SOURCE ONLY. Running requires separate explicit root release; not run here."""
from pathlib import Path
import json,hashlib,subprocess,time,os,signal,argparse
ROOT=Path(__file__).parent
PYTHON='/workspace/shared/chicago-venv/bin/python'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def execute_once(output,release_token):
 start=time.monotonic() # Entire90s wall budget begins BEFORE pins/setup
 if release_token!='ROOT_RELEASE_ONE_QUARTERVECTOR':raise ValueError('Separate root execution release required')
 pins=json.loads((ROOT/'pinned-sources.json').read_text())
 for path,want in pins.items():
  if sha(path)!=want:raise ValueError('SOURCE PIN MISMATCH before execution:'+path)
 out=Path(output);out.mkdir(parents=True,exist_ok=False) # exclusive outerclaim before writes
 vector=[.25]*24;(out/'vector.json').write_text(json.dumps(vector)+'\n')
 receipt={'status':'STARTED UNACCEPTED diagnostic','source_pins':pins,'explicit_vector':vector,'vector_sha256':sha(out/'vector.json'),'per_phase_cap_s':30,'overall_cap_s':90,'deadline_scope':'all wall time from first execute_once entry INCLUDING source hashing and setup','stages':[],'future_rest_readback':'PENDING independent readback before ANY futurecapture','capture_SAT_gear_browser_Blender':'NOT AUTHORIZED/NOT RUN','declared_input_pins':json.loads((ROOT/'declared-input-pins.json').read_text())}
 def save():(out/'operator-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 receipt['setup_elapsed_s']=time.monotonic()-start;save()
 commands=[[PYTHON,str(ROOT/'stage_export.py'),str(out)],[PYTHON,str(ROOT/'stage_metadata.py'),str(out)],['node',str(ROOT/'stage_khronos.cjs'),str(out)]]
 for index,cmd in enumerate(commands,1):
  budget=min(30,90-(time.monotonic()-start));receipt['current_stage']=index;save()
  if budget<=0:receipt.update(status='FIRST FAILURE deadline STOP',elapsed_s=time.monotonic()-start);save();return 124
  with(out/f'phase{index}.stdout.log').open('wb')as stdout,(out/f'phase{index}.stderr.log').open('wb')as stderr:
   try:
    process=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,start_new_session=True)
    try:code=process.wait(timeout=budget)
    except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait();code=124
   except Exception as error:stderr.write((str(error)+'\n').encode());code=127
  receipt['elapsed_s']=time.monotonic()-start;receipt['stages'].append({'stage':index,'command':cmd,'exit_code':code,'elapsed_total_s':time.monotonic()-start});save()
  if code!=0:receipt.update(status='FIRST FAILURE STOP; no retry/repair/search');save();return code
 receipt.update(status='LOCAL export/metadata/Khronos ONLY; UNACCEPTED; independent REST readback PENDING',elapsed_s=time.monotonic()-start);save();return 0
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output-dir',required=True);ap.add_argument('--release-token',required=True);a=ap.parse_args();raise SystemExit(execute_once(a.output_dir,a.release_token))
