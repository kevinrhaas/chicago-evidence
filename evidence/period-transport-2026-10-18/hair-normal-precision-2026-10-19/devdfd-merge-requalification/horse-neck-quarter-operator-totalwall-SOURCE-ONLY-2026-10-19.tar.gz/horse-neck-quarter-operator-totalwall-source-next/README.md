# ONE quarter-vector operator — SOURCE ONLY, NOT RUN

This driver is prepared for review, not an execution release. No actualhorse GLB or sidecar has been read by this parcel; no functions/parameters on horse, export, metadata production, Khronos, capture or SAT ran. Syntax checking only. A draft driver named operator.py shadowed Python stdlib; renamed run_quarter_trial.py before final syntax pass. No model evidence involved.

Frozen exporter2ad runs in its OWN Python process/import namespace, then frozenbe78 metadata producer in a SECOND Python process, then local Khronos in a THIRD Node process. No shared Python module cache. Explicit sole vector[0.25]*24 is written+SHA-recorded beforephase1; engineering diagnostic selection, nofit/period claim and no parametersearch/default/retry. Exact090/26027/inputsource paths and hashes are declared; each worker's frozen validators enforce them before coordinate evaluation. Future invocation requires independently reviewed frozenoperatorarchive plus exact ROOT_RELEASE_ONE_QUARTERVECTOR token; tokentext itself is not authorization.

Exclusive outerdirectory is atomically created beforewrite.47source/data-pins cover all exporter+metadata .py/.mjs helpers, driver stages, declaredinputpins, local validator package/index/compiledbytes, and externalThree module/core/GLTFLoader/BufferGeometryUtils + actualthree-loader bytes for FUTUREcapture. These hashes are verified before anyphase, copied into operatorreceipt with vector/exitcodes/commands/logs. No futurecapture is run here. Sourcepinsfile integrity is supplied by independent rootarchivepin; don't regenerate it silently to accommodate a mismatch.

Eachphase<=30seconds, allthree share90seconds overall; separate stdout/stderr logs and stageexitcodes. Timeout kills ownedprocessgroup and STOP; spawnerror127 and anynonzero STOP before laterphases. Exportwrapper preserves UNVALIDATEDbytes and firstfailure proof. Metadata stage createscanonicalfiles by copyingACTUALexportedGLB/proof bytes unchanged, then writesdeterministic manifest/authority/packet fromvalidatedactualbytes. Bothactualcopies re-read for exactequality; futurepacketlinks actualSHA, neverfakeplaceholders. Metadata sourceinventory contains fullbe78helperfiles byexistingproducer policy; operatorreceipt additionally pins full2ad/exporter+driver+externalruntime inputs.

Khronos requires0errors/0warnings and savesfullreport. Success means localexport/metadata/Khronos only: independentRESTreadback remains EXPLICITLYPENDING beforeanyfuturecapture, collision,63poses, gear or browser. All source and failures remain unaccepted. No app, tickets, CI or Blender mutation.

Proposed command AFTER rootrelease (do not run while source-only):
```
/workspace/shared/chicago-venv/bin/python /workspace/shared/horse-neck-quarter-operator-totalwall-source-next/run_quarter_trial.py --output-dir NEW_EXCLUSIVE_OUTER_DIR --release-token ROOT_RELEASE_ONE_QUARTERVECTOR
```
No actual outputdirectory is chosen or created by this source parcel.

Tiny total-wall correction: monotonicdeadline starts at FIRSTexecute_onceentry, before anypinchecks/setup. Allworker budgets subtract that elapsedtime; expiredsetup refuses workerlaunch. Setup and totalelapsed are recorded. Perphase30s andexclusiveoutput remainunchanged. Onlysyntaxchecked; no actualfunction/horseIO. Prior57archive frozen.
