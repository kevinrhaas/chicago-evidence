# SPDX-License-Identifier: GPL-3.0-or-later
"""UNEXECUTED actual-neck scope adapter; topology is annulus, NOT head disk."""
from collections import defaultdict
from sparse_rules import require
from check_idle import scan,write
from neck_band_proposal import neck_strip_source_faces

def cycle(t):return min(tuple(t),tuple(t[1:]+t[:1]),tuple(t[2:]+t[:2]))
def annulus_ownership(model,records):
 v=model.views[0,0];lookup=defaultdict(list)
 for i,t in enumerate(v['indices']):lookup[cycle(list(map(int,t)))].append(model.start[0,0]+i)
 selected=set();sourceowners={}
 for r in neck_strip_source_faces():
  hits=lookup[cycle(r['vertices'])];require(len(hits)==1,'Missing/duplicate actual source-owned neck face');g=hits[0];selected.add(g);sourceowners[g]=r
 require(len(selected)==96,'Exact source-owned96 face annulus required')
 edgeuses=defaultdict(list);vertices=set();graph=defaultdict(set)
 for g in selected:
  t=records[g];vertices.update(t)
  for a,b in zip(t,t[1:]+t[:1]):edgeuses[tuple(sorted([a,b]))].append((g,a,b));graph[a].add(b);graph[b].add(a)
 expected=set()
 for ring in[[f'body:0:{i}'for i in range(168,192)],[f'h:{i}'for i in range(24)]]:
  expected|={tuple(sorted([ring[i],ring[(i+1)%24]]))for i in range(24)}
 boundary={e for e,u in edgeuses.items()if len(u)==1};require(boundary==expected,'Annulus must have exactly two declared24edge loops')
 require(len(vertices)-len(edgeuses)+96==0,'Neck strip annulus Euler must0')
 seen=set();todo=[next(iter(vertices))]
 while todo:
  q=todo.pop()
  if q in seen:continue
  seen.add(q);todo.extend(graph[q]-seen)
 require(seen==vertices,'Neck strip annulus mustone component')
 all_edges=defaultdict(list)
 for g,t in enumerate(records):
  for a,b in zip(t,t[1:]+t[:1]):
   e=tuple(sorted([a,b]))
   if e in edgeuses:all_edges[e].append((g,a,b))
 internal=set();external=set()
 for e,u in all_edges.items():
  require(len(u)==2 and u[0][1:]==u[1][:0:-1],'Neck sourceedge requires unique opposite owner; noTjunction/duplicate')
  a,b=u[0][0],u[1][0];pair=tuple(sorted([a,b]))
  (internal if a in selected and b in selected else external).add(pair)
 return selected,internal,external,sourceowners,{'faces':96,'components':1,'Euler':0,'boundary_edges':48,'boundary_loops':2,'topology':'source-owned two-strip annulus'}

def check_changed_neck(model,records,data,out):
 selected,internal,external,owners,topology=annulus_ownership(model,records)
 write(out/'changed-neck-ownership.json',{'actual_global_faces':sorted(selected),'source_face_owners':owners,'topology':topology})
 # Same scan semantics: internal unordered pairs once; external selected vsallrest.
 # Exactactual edge certificate still required inside scan; registration alone never skips.
 scopes=[]
 for engine_scope,meaning,edges in[('head_internal','changed_neck_INTERNAL',internal),('head_vs_all_rest','changed_neck_vsALL_REMAINING_active_horse',external)]:
  r=scan('changed_neck96',engine_scope,model,records,selected,data,edges,out,True);r['declared_scope']=meaning;scopes.append(r)
  if r['counts']['unexpected_SAT']or r['counts']['strict_proper']:return False,scopes
 return True,scopes
