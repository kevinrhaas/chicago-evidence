# SPDX-License-Identifier: GPL-3.0-or-later
"""SOURCE ONLY, no automatic invocation. Produces metadata, never geometry."""
import json,hashlib
from ownership import Model,PINS,frozen_baseline,candidate_from_maps,triangle_labels,verify_source_seams
from neck_scope import annulus_ownership
from chain_rules import PARENT_AUTHORITY,real_sha
from storage_rules import verify_storage
from sparse_rules import require,sparse_proof

def digest(b):return hashlib.sha256(b).hexdigest()
def encoded(d):return(json.dumps(d,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def build_metadata(glb_sha,proof_sha,source_sha,validation):
 for h in[glb_sha,proof_sha,source_sha]:real_sha(h)
 require(glb_sha not in[PINS['baseline'],PINS['candidate']],'New candidate actualSHA required')
 require(validation=={'triangles':11452,'head_ear_triangles':2960,'neck_changed_source_faces':96,'all_other_attributes_exact':True,'index_ownership_exact':True,'storage_verified':True},'Complete local shape/range proof required')
 m={'status':'UNACCEPTED','glb_sha256':glb_sha,'parent_glb_sha256':PINS['candidate'],'original090_glb_sha256':PINS['baseline'],'sparse_proof_sha256':proof_sha,'producer_source_sha256':source_sha,'position_allowed':list(range(192,216)),'normal_allowed':list(range(168,216)),'all_other_attributes_exact':True,'head_ear_source_face_ownership':'unchanged_26027','local_validation':validation,'not_run':['collision','63poses','gear','visual_anatomy_photographic_acceptance']}
 mr=encoded(m);a={'status':'UNACCEPTED','glb_sha256':glb_sha,'parent_glb_sha256':PINS['candidate'],'manifest_sha256':digest(mr),'producer_source_sha256':source_sha,'original_ear_producer_pins':PINS,'original_ear_authority_sha256':PARENT_AUTHORITY};ar=encoded(a)
 packet={'status':'UNACCEPTED','parent090_glb_sha256':PINS['baseline'],'ear_parent_glb_sha256':PINS['candidate'],'neck':{k:{'path':n,'sha256':h}for k,n,h in[('glb','candidate.glb',glb_sha),('proof','sparse-export-proof.json',proof_sha),('manifest','manifest.json',digest(mr)),('authority','authority.json',digest(ar))]}}
 return mr,ar,encoded(packet)

def produce_metadata(parent_glb,actual_glb,actual_proof,ear_manifest,ear_proof,ear_source,ear_authority,original090_inputs):
 # This function is UNEXECUTED; arguments are actual immutable bytes, not callerclaims.
 for raw,key in[(parent_glb,'candidate'),(ear_manifest,'producer260'),(ear_proof,'proof'),(ear_source,'source_candidate')]:require(digest(raw)==PINS[key],'Original chain bytes changed:'+key)
 require(digest(ear_authority)==PARENT_AUTHORITY,'Original authority bytes changed')
 proof=json.loads(actual_proof);newsha=digest(actual_glb);require(proof['output_sha256']==newsha and proof['input_pins']==PINS and proof['authority_sha256']==PARENT_AUTHORITY,'Actual proof/input chain')
 old=Model(parent_glb);new=Model(actual_glb);require(old.total==new.total==11452 and set(old.views)==set(new.views),'Exact active shape')
 import numpy as np
 for key,v in old.views.items():
  w=new.views[key];require(v['material']==w['material']and v['mesh_name']==w['mesh_name']and np.array_equal(v['indices'],w['indices']),'Exact active identity/index ownership')
  for k,a in v['attributes'].items():
   allowed=range(192,216)if key==(0,0)and k=='POSITION'else range(168,216)if key==(0,0)and k=='NORMAL'else[]
   p=sparse_proof(a,w['attributes'][k],allowed)
   if key==(0,0):require(p==proof['sparse_proof'][k],'Actual sparse proof mismatch')
 refs=new.d['meshes'][0]['primitives'][0]['attributes'];verify_storage(old.d,old.b,new.d,new.b,refs['POSITION'],refs['NORMAL'])
 # Source ownership is reconstructed from actual pinned original090 files, not callbackclaims.
 for key in['baseline','producer090','head','ears']:
  require(digest(original090_inputs[key])==PINS[key],'Original090sourcechain:'+key)
 base,bl,bh,bo=frozen_baseline(original090_inputs['baseline'],json.loads(original090_inputs['producer090']),json.loads(original090_inputs['head']),json.loads(original090_inputs['ears']))
 ear,labels,heads,owners,_=candidate_from_maps(parent_glb,base,bl,bh,bo,json.loads(ear_proof),json.loads(ear_source))
 verify_source_seams(new,labels);records=triangle_labels(new,labels)
 selected,_,_,_,_=annulus_ownership(new,records)
 counts={'head_ear_triangles':len(heads),'neck_changed_source_faces':len(selected)}
 require(counts=={'head_ear_triangles':2960,'neck_changed_source_faces':96},'Actual source-owner coverage')
 validation={'triangles':11452,**counts,'all_other_attributes_exact':True,'index_ownership_exact':True,'storage_verified':True}
 source_sha=digest(open(__file__,'rb').read());return build_metadata(newsha,digest(actual_proof),source_sha,validation)
