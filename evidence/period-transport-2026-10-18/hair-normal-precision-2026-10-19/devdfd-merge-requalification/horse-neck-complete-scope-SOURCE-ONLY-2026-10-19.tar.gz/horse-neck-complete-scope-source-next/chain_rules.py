# SPDX-License-Identifier: GPL-3.0-or-later
"""Source-only three-way provenance gate. No future candidate is pinned yet."""
import json,hashlib,re,copy
from pathlib import Path
import numpy as np
from ownership import PINS,Model,frozen_baseline,candidate_from_maps,verify_source_seams,triangle_labels
from sparse_rules import require,sparse_proof,intended_readback
from storage_rules import verify_storage
PARENT_AUTHORITY='3a95abf8e9f8d3e9d5180b1c988f4334ea00f88824d4131308c22ee22d2c1f4a'

def sha(raw):return hashlib.sha256(raw).hexdigest()
def real_sha(value):
 require(isinstance(value,str)and re.fullmatch('[0-9a-f]{64}',value)is not None and len(set(value))>1,'Missing/placeholder SHA forbidden')
 return value

def linked_metadata(chain,manifest,proof,authority):
 # File bytes are separately hash-pinned BEFORE this semantic link gate.
 require(chain['parent090_glb_sha256']==PINS['baseline']and chain['ear_parent_glb_sha256']==PINS['candidate'],'Exact090→260parent chain')
 new=real_sha(chain['neck']['glb']['sha256']);require(new not in[PINS['baseline'],PINS['candidate']],'Future candidate must have separate actual SHA')
 for role in['glb','manifest','proof','authority']:real_sha(chain['neck'][role]['sha256'])
 require(manifest['glb_sha256']==new and manifest['parent_glb_sha256']==PINS['candidate'],'New manifest chain')
 require(manifest['sparse_proof_sha256']==chain['neck']['proof']['sha256'],'Manifest proof link')
 require(authority['glb_sha256']==new and authority['parent_glb_sha256']==PINS['candidate']and authority['manifest_sha256']==chain['neck']['manifest']['sha256'],'New authority chain')
 require(proof['output_sha256']==new and proof['input_pins']==PINS and proof['authority_sha256']==PARENT_AUTHORITY,'Original ear producer/proof chain preserved')
 require(manifest['position_allowed']==list(range(192,216))and manifest['normal_allowed']==list(range(168,216))and manifest['all_other_attributes_exact']is True,'Explicit new source authority')
 require(manifest['head_ear_source_face_ownership']=='unchanged_26027'and manifest['status']=='UNACCEPTED','No ownership/acceptance relabel')
 return new

def read_pinned(entry,base):
 h=real_sha(entry['sha256']);p=(base/entry['path']).resolve();raw=p.read_bytes();require(sha(raw)==h,'File SHA mismatch:'+str(p));return raw

def verify_threeway(chain_file,chain_sha,base090,ear_dir,ear_source):
 chain_raw=Path(chain_file).read_bytes();require(sha(chain_raw)==real_sha(chain_sha),'Reviewed packet SHA mismatch');chain=json.loads(chain_raw)
 def oldfile(path,key):
  raw=Path(path).read_bytes();require(sha(raw)==PINS[key],'Frozen input SHA mismatch:'+key);return raw
 oldraw=oldfile(base090/'equine_light_harness_skinned_prototype_01.glb','baseline');earraw=oldfile(ear_dir/'equine_ear_root_candidate.glb','candidate')
 producer=json.loads(oldfile(base090/'manifest.json','producer090'));head=json.loads(oldfile(base090/'head-source-surface.json','head'));ears=json.loads(oldfile(base090/'ear-source-surfaces.json','ears'))
 earproof=json.loads(oldfile(ear_dir/'export-local-proof.json','proof'));oldfile(ear_dir/'manifest.json','producer260');earsource=json.loads(oldfile(ear_source,'source_candidate'))
 require(sha((ear_dir/'authority.json').read_bytes())==PARENT_AUTHORITY,'Ear authority pin')
 base=Path(chain_file).parent;payload={k:read_pinned(chain['neck'][k],base)for k in['glb','manifest','proof','authority']};manifest=json.loads(payload['manifest']);proof=json.loads(payload['proof']);authority=json.loads(payload['authority']);newsha=linked_metadata(chain,manifest,proof,authority)
 old,ol,oh,oo=frozen_baseline(oldraw,producer,head,ears);ear,el,eh,eo,remap=candidate_from_maps(earraw,old,ol,oh,oo,earproof,earsource);neck=Model(payload['glb'])
 require(neck.total==ear.total==11452 and set(neck.views)==set(ear.views),'Exact active11452 index ownership')
 for key,v in ear.views.items():
  w=neck.views[key];require(v['material']==w['material']and v['mesh_name']==w['mesh_name']and np.array_equal(v['indices'],w['indices']),'Primitive identity/index/source ownership changed')
  for k,a in v['attributes'].items():
   allowed=range(192,216)if key==(0,0)and k=='POSITION'else range(168,216)if key==(0,0)and k=='NORMAL'else[]
   actual=sparse_proof(a,w['attributes'][k],allowed)
   if key==(0,0):require(actual==proof['sparse_proof'][k],'Sparse proof differs from decoded attributes')
 refs=neck.d['meshes'][0]['primitives'][0]['attributes'];verify_storage(ear.d,ear.b,neck.d,neck.b,refs['POSITION'],refs['NORMAL'])
 verify_source_seams(neck,el);require(len(eh)==2960,'Head+ear exact cohort2960')
 # Source labels/owners copied ONLY after exact topology/attribute protections.
 for m,own in[(old,oo),(ear,eo),(neck,eo)]:m.source_face_owners=own
 return {'baseline':(old,ol,oh,oo),'ear_parent':(ear,el,eh,eo),'neck_candidate':(neck,el,eh,eo),'neck_sha256':newsha,'proof':proof,'manifest':manifest,'chain':chain}
