# Three-way neck checker adaptation — SOURCE/MOCK ONLY, UNEXECUTED

Frozen f64unique checker remains untouched. This NEW sibling reuses unchanged SAT1e-8/proper, exact source-edge/point certificates, source maps and original090 known12 negatives. No actual candidate generation/export, capture, parameter evaluation, SAT, GPU/browser or app write occurred. Seven mock link/negative-owner controls pass normal and -O; source syntax passes. Mock hashes test metadata syntax only, never constitute an accepted file pin.

## Mandatory provenance before ANY collision

An exact root-reviewed packet SHA is required. Packet must bind actual090 parent hash,26027 ear parent hash and four actual future-neck file hashes: GLB, authoritative manifest, sparse export proof, authority. Missing, placeholder, parent-as-candidate, bad linkage, absent files or byte mismatch STOP. Future manifest must link actual GLB,parent26027,proof SHA, explicitPOS192..215/NORMAL168..215 permissions, unchanged26027head/ear face ownership and UNACCEPTED status. Authority must link actualGLB,parent and manifest SHA. Proof must retain original090→26027 pins/parent authority and actual new output SHA.

Those future manifest/authority artifacts DO NOT EXIST in this proposal and are not fabricated. The earlier exporter proposal returns bytes+sparse proof only; it still needs an authoritative separately reviewed metadata producer before an actual chain can pass. Do not substitute a placeholder, dynamically trust a candidate's self-declared digest or reuse parent metadata unchanged. Current chain is intentionally NOT demonstrable until actual output bytes and independently pinned sidecars exist.

Rest/active preflight loads exact090producer/head/ears and26027source/proof/manifest/authority, reconstructs existing source ownership via declared primitive maps, then compares the entire future model against26027. Every primitive/material/active index and all attributes outside POS192..215/NORMAL168..215 must be exact; all weights/joints, all head/ears/protected48/24portal alias fields and rig/clips remain exact. Only2declared append-only accessor refs/storage may change, protecting original accessor/view/BIN metadata.2960head+ear ownership is inherited only after exact topology proof, against all11452active triangles. No proximity-derived candidate ownership.

Capture retains the original CPU algorithm unchanged: actual GLTFLoader indexed skin/world coordinates, Float64Array, writeDoubleLE, explicit IEEEbinary64 metadata,72bytes/triangle, no post-world rounding. A separately pinned packet identifies future candidate bytes, and original090/26027 hashes remain hardcoded. Capture is not a provenance/fit acceptance by itself. Full preflight occurs before collision; all3capture hashes/storage/frames/source aliases must validate before any SAT.

## Future ordered checks, not executed

090 actual full internal+head-vsALLrest negative scans, requiring ALL12known strict negatives exactly once from original copied hash-pinned provenance.26027 actual full same-scope scans, requiring exactly the actual retained headface33/neck207,208,232 negative by source labels, not raw global IDs; prior receipt SHA67594ff46f31b4edbd51dba5028f0aaa0816b70bf6dd80e170e324eb4c1d3e58 validates origin. Keep broader negative findings separate.

Fresh future candidate INTERNAL first, then head/ears-vsALLrest. Whole source-edge pairs may skip only with exact actual nonfoldover certificate; shared-source-point pairs still run SAT/proper, and proper crossings cannot be excused. First unexpectedSAT OR proper crossing saves partial and STOP; absent scopes UNTESTED. Even a discrete idle pass cannot establish63poses, changed-neck-vsALLhorse collision scope, gear, anatomy or photographic acceptance. The dedicated whole changed-neck versus all body sweep remains an additional required gate after this adaptation; do not silently claim head-vsrest covers neck-vs-torso.

No execution command is authorized. Source functions have no CLI and no candidate SHA placeholder. The persisted firstfailure wrapper records failures without retries. Original ear and neck failure archives stay frozen.
