# SPDX-License-Identifier: CC0-1.0
from pathlib import Path
import hashlib,json

def helper_inventory(directory):
 base=Path(directory)
 return{str(p.relative_to(base)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(base.rglob('*'))if p.is_file()and p.suffix in['.py','.mjs']and'__pycache__'not in p.parts}
def inventory_sha(inventory):return hashlib.sha256(json.dumps(inventory,sort_keys=True,separators=(',',':')).encode()).hexdigest()
