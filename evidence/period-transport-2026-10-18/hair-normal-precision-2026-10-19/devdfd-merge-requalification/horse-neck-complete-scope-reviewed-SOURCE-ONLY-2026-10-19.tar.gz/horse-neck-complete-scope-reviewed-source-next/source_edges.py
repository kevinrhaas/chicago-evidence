# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicit owned source edges, not shared-position/bbox exclusions."""
from planar import need

def edge_table(records,selected):
 edges={}
 for fi in sorted(selected):
  t=records[fi];need(len(set(t))==3,'Repeated source triangle vertex')
  for a,b in zip(t,t[1:]+t[:1]):edges.setdefault(tuple(sorted((a,b))),[]).append((fi,a,b))
 return edges

def owned_adjacency(records,head,total,expected_components,expected_euler):
 portal=['h:'+str(i)for i in range(24)];boundary={tuple(sorted((a,b)))for a,b in zip(portal,portal[1:]+portal[:1])};edges=edge_table(records,head);actual_boundary=set();pairs=set();active={k for i in head for k in records[i]};neighbors={k:set()for k in active}
 for edge,uses in edges.items():
  a,b=edge;neighbors[a].add(b);neighbors[b].add(a)
  if len(uses)==1:actual_boundary.add(edge)
  else:
   need(len(uses)==2 and uses[0][1:]==uses[1][1:][::-1],'Head source edge ownership/winding failure');pairs.add(tuple(sorted((uses[0][0],uses[1][0]))))
 need(actual_boundary==boundary,'Actual source-owned portal boundary mismatch');components=0;seen=set()
 for start in sorted(active):
  if start in seen:continue
  components+=1;pending=[start]
  while pending:
   q=pending.pop()
   if q in seen:continue
   seen.add(q);pending.extend(neighbors[q]-seen)
 euler=len(active)-len(edges)+len(head);need(components==expected_components and euler==expected_euler,'Actual source active topology mismatch')
 # Only those actual non-head edges which use exact protected portal aliases
 # may be whole-pair exclusions against the neck/body.
 rest=set(range(total))-set(head);rest_edges=edge_table(records,rest);portal_pairs=set()
 for edge in boundary:
  h=edges[edge];r=rest_edges.get(edge,[]);need(len(h)==len(r)==1 and h[0][1:]==r[0][1:][::-1],'Actual neckportal edge pair not unique/opposite');portal_pairs.add(tuple(sorted((h[0][0],r[0][0]))))
 return pairs,portal_pairs,{'components':components,'Euler':euler,'head_faces':len(head),'head_source_edges':len(edges),'owned_head_adjacency_pairs':len(pairs),'owned_portal_neck_pairs':len(portal_pairs),'boundary_edges':24}
