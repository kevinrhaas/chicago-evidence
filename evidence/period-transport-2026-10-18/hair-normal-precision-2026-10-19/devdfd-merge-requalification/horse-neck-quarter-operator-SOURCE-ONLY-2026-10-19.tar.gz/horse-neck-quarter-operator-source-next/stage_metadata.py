# SPDX-License-Identifier: GPL-3.0-or-later
"""UNEXECUTED isolated be78 metadata subprocess; never exports geometry."""
import sys,shutil
from pathlib import Path
sys.path.insert(0,'/workspace/shared/horse-neck-complete-scope-capture-owned-source-next')
from metadata_producer import produce_metadata
out=Path(sys.argv[1]);stage=out/'metadata';stage.mkdir();export=out/'export';parent=Path('/workspace/shared/horse-ear-root-exporter-source-reviewed-next/export-trial1');base=Path('/workspace/shared/horse-head-groove-coat-next/trial1')
actual=(export/'UNACCEPTED-candidate.glb').read_bytes();proof=(export/'sparse-export-proof.json').read_bytes()
original={k:(base/n).read_bytes()for k,n in[('baseline','equine_light_harness_skinned_prototype_01.glb'),('producer090','manifest.json'),('head','head-source-surface.json'),('ears','ear-source-surfaces.json')]}
mr,ar,packet=produce_metadata((parent/'equine_ear_root_candidate.glb').read_bytes(),actual,proof,(parent/'manifest.json').read_bytes(),(parent/'export-local-proof.json').read_bytes(),Path('/workspace/shared/horse-ear-root-exporter-source-reviewed-next/source-trial1/candidate-source-edit.json').read_bytes(),(parent/'authority.json').read_bytes(),original)
(stage/'candidate.glb').write_bytes(actual);(stage/'sparse-export-proof.json').write_bytes(proof)
for n,b in[('manifest.json',mr),('authority.json',ar),('packet.json',packet)]:
 with(stage/n).open('xb')as f:f.write(b)
if (stage/'candidate.glb').read_bytes()!=actual or(stage/'sparse-export-proof.json').read_bytes()!=proof:raise ValueError('Canonical actual-byte copies differ')
