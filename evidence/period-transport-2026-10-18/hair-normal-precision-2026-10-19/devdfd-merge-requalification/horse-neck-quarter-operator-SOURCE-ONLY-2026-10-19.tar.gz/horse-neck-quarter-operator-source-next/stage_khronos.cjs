// SPDX-License-Identifier: GPL-3.0-or-later
// UNEXECUTED future local validator phase; not fit/rest/render acceptance.
const fs=require('node:fs'),path=require('node:path');
const validator=require('/workspace/shared/transport-tools/node_modules/gltf-validator');
(async()=>{const out=process.argv[2],raw=fs.readFileSync(path.join(out,'metadata/candidate.glb'));const report=await validator.validateBytes(new Uint8Array(raw),{uri:'candidate.glb',maxIssues:10000});fs.writeFileSync(path.join(out,'khronos.json'),JSON.stringify(report,null,2)+'\n');if(report.issues.numErrors||report.issues.numWarnings)process.exitCode=1;})().catch(e=>{console.error(e.stack);process.exitCode=1;});
