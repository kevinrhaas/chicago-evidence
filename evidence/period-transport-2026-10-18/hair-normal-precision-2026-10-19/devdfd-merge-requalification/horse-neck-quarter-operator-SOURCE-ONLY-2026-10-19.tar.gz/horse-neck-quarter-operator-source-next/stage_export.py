# SPDX-License-Identifier: GPL-3.0-or-later
"""UNEXECUTED future export subprocess; original2ad sources remain frozen."""
import sys,json
from pathlib import Path
sys.path.insert(0,'/workspace/shared/horse-neck-explicit-exporter-final-source-next')
from persisted_trial import run_once
out=Path(sys.argv[1]);vector=json.loads((out/'vector.json').read_text())
if vector!=[.25]*24:raise ValueError('ONLY explicit quartervector authorized by this driver')
run_once(out/'export',Path('/workspace/shared/horse-head-groove-coat-next/trial1'),Path('/workspace/shared/horse-ear-root-exporter-source-reviewed-next/export-trial1'),Path('/workspace/shared/horse-ear-root-exporter-source-reviewed-next/source-trial1/candidate-source-edit.json'),vector)
