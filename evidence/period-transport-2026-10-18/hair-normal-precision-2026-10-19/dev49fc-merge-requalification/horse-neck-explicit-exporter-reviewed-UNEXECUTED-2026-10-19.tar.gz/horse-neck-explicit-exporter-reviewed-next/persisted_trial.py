# SPDX-License-Identifier: GPL-3.0-or-later
"""UNEXECUTED future FIRST-failure wrapper; no CLI/automatic call."""
from pathlib import Path
import json,hashlib,traceback
from proposed_export import proposed_once

def run_once(output_dir,baseline,candidate,source,explicit_vector):
 out=Path(output_dir)
 if out.exists():raise ValueError('Refuse overwrite prior trial')
 out.mkdir(parents=True)
 receipt={'status':'STARTED UNACCEPTED source-local export only','input_paths':list(map(str,[baseline,candidate,source])),'explicit_vector':explicit_vector,'checks_not_run':['collision','63poses','gear','render']}
 def save(): (out/'first-trial-receipt.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
 try:
  # Invalid/non-JSON parameters must still persist a textual failure.
  save();raw,proof=proposed_once(baseline,candidate,source,explicit_vector,checkpoint=lambda raw:(out/'UNVALIDATED-candidate.glb').write_bytes(raw))
  (out/'UNACCEPTED-candidate.glb').write_bytes(raw);(out/'sparse-export-proof.json').write_text(json.dumps(proof,indent=2,allow_nan=False)+'\n')
  receipt.update(status='LOCAL EXPORT ONLY; UNACCEPTED; no mechanical acceptance',output_sha256=hashlib.sha256(raw).hexdigest());save()
 except BaseException as e:
  receipt['explicit_vector_repr']=repr(explicit_vector);receipt.pop('explicit_vector',None);receipt.update(status='FIRST FAILURE STOP; no retry/repair',error=str(e),traceback=traceback.format_exc());save();raise
