# SPDX-License-Identifier: CC0-1.0
import unittest,copy
from storage_rules import verify_storage
class Controls(unittest.TestCase):
 def fixture(self):
  old={'accessors':[{'old':'preserved'}],'bufferViews':[{'old':'view'}],'buffers':[{'byteLength':4,'name':'source'}],'meshes':[{'primitives':[{'attributes':{'POSITION':0,'NORMAL':0}}]}]};new=copy.deepcopy(old)
  for off in[4,16]:
   new['accessors'].append({'bufferView':len(new['bufferViews']),'componentType':5126,'count':1,'type':'VEC3','min':[0,0,0],'max':[0,0,0]});new['bufferViews'].append({'buffer':0,'byteOffset':off,'byteLength':12,'target':34962})
  new['buffers'][0]['byteLength']=28;new['meshes'][0]['primitives'][0]['attributes']={'POSITION':1,'NORMAL':2}
  return old,bytearray(b'abcd'),new,bytearray(b'abcd'+bytes(24))
 def test_valid(self):verify_storage(*self.fixture(),1,2)
 def test_old_accessor_rejected(self):
  a,b,c,d=self.fixture();c['accessors'][0]['old']='changed'
  with self.assertRaises(ValueError):verify_storage(a,b,c,d,1,2)
 def test_old_view_rejected(self):
  a,b,c,d=self.fixture();c['bufferViews'][0]['old']='changed'
  with self.assertRaises(ValueError):verify_storage(a,b,c,d,1,2)
 def test_old_bin_rejected(self):
  a,b,c,d=self.fixture();d[0]=0
  with self.assertRaises(ValueError):verify_storage(a,b,c,d,1,2)
 def test_buffer_metadata_rejected(self):
  a,b,c,d=self.fixture();c['buffers'][0]['name']='changed'
  with self.assertRaises(ValueError):verify_storage(a,b,c,d,1,2)
 def test_extra_document_rejected(self):
  a,b,c,d=self.fixture();c['unknown']='changed'
  with self.assertRaises(ValueError):verify_storage(a,b,c,d,1,2)
if __name__=='__main__':unittest.main()
