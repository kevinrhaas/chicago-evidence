# SPDX-License-Identifier: CC0-1.0
import unittest
import numpy as np
from sparse_rules import sparse_proof,explicit_parameters,intended_readback
class Controls(unittest.TestCase):
 def test_intended_wrong_allowed_value_rejected(self):
  intended=np.array([[0.,1.]],dtype='f4');wrong=np.array([[0.,2.]],dtype='f4')
  self.assertTrue(sparse_proof(intended,wrong,[0]))
  with self.assertRaises(ValueError):intended_readback(intended,wrong)
 def test_intended_exact(self):self.assertTrue(intended_readback(np.zeros((1,3),dtype='f4'),np.zeros((1,3),dtype='f4')))
 def test_lists_and_numpy(self):
  for a,b in[([[0.,1.],[1.,2.]],[[0.,1.],[1.,3.]]),(np.array([[0.,1.],[1.,2.]]),np.array([[0.,1.],[1.,3.]]))]:self.assertEqual(sparse_proof(a,b,[1])['changed_rows'],[1])
 def test_nan_rejected(self):
  with self.assertRaises(ValueError):sparse_proof([[float('nan')]],[[float('nan')]],[])
 def test_protected_rejected(self):
  with self.assertRaises(ValueError):sparse_proof([[1.]],[[2.]],[])
 def test_shape_rejected(self):
  with self.assertRaises(ValueError):sparse_proof([[1.]],[[1.,2.]],[])
 def test_dtype_rejected(self):
  with self.assertRaises(ValueError):sparse_proof(np.ones((1,1),dtype='f4'),np.ones((1,1),dtype='f8'),[])
 def test_explicit_vector(self):self.assertTrue(np.array_equal(explicit_parameters([.5]*24),[.5]*24))
 def test_no_default_search_or_bad_vector(self):
  for v in[None,[],[True]*24,[0.]*24,[float('nan')]*24,[.500001]*24,['.5']*24]:
   with self.assertRaises(ValueError):explicit_parameters(v)
if __name__=='__main__':unittest.main()
