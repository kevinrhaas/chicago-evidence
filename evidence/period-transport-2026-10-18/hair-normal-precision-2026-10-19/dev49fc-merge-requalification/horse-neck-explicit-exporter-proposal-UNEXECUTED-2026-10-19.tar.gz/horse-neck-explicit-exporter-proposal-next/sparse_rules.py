# SPDX-License-Identifier: CC0-1.0
import numpy as np

def require(ok,message):
 if not ok:raise ValueError(message)

def sparse_proof(before,after,allowed):
 a=np.asarray(before);b=np.asarray(after)
 require(a.shape==b.shape and a.dtype==b.dtype,'Shape/dtype changed')
 require(np.isfinite(a).all()and np.isfinite(b).all(),'Nonfinite attributes')
 require(a.ndim==2,'Expected attribute rows')
 changed=np.flatnonzero(np.any(a!=b,axis=1)).tolist()
 require(set(changed)<=set(allowed),'Protected sparse attribute modified')
 return {'changed_rows':changed,'allowed_rows':sorted(allowed),'protected_rows_exact':True,'finite':True}

def explicit_parameters(value):
 require(isinstance(value,list)and len(value)==24,'Exactly one explicit24-entry JSON vector required; no default/search')
 require(all(type(v)in[int,float]for v in value),'Numeric nonboolean parameters required')
 a=np.array(value,dtype=float);require(np.isfinite(a).all()and np.all(a>0)and np.all(a<=.5),'Require0<lambda<=.5 engineering continuation bound')
 return a
