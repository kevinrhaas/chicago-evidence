# SPDX-License-Identifier: GPL-3.0-or-later
"""UNEXECUTED proposal: requires separate root release before any real call.
No CLI or automatic execution. No search, tolerance waiver, SAT or acceptance.
"""
from pathlib import Path
import json,hashlib,copy
import numpy as np
from ownership import pinned,Model,frozen_baseline,candidate_from_maps,verify_source_seams,PINS,ATTRS
from glb_data import read,append,encode
from neck_band_proposal import symbolic_plan,proposed_band,neck_strip_source_faces
from sparse_rules import require,sparse_proof,explicit_parameters
AUTHORITY='3a95abf8e9f8d3e9d5180b1c988f4334ea00f88824d4131308c22ee22d2c1f4a'

def verified_inputs(baseline,candidate,source):
 # Every IO/hash/ownership check occurs BEFORE parameter evaluation.
 oldraw=pinned(baseline/'equine_light_harness_skinned_prototype_01.glb','baseline');raw=pinned(candidate/'equine_ear_root_candidate.glb','candidate')
 producer=json.loads(pinned(baseline/'manifest.json','producer090'));head=json.loads(pinned(baseline/'head-source-surface.json','head'));ears=json.loads(pinned(baseline/'ear-source-surfaces.json','ears'))
 proof=json.loads(pinned(candidate/'export-local-proof.json','proof'));manifest=json.loads(pinned(candidate/'manifest.json','producer260'));source_doc=json.loads(pinned(source,'source_candidate'))
 authority=(candidate/'authority.json').read_bytes();require(hashlib.sha256(authority).hexdigest()==AUTHORITY,'Authority SHA')
 join=producer['join_trial']['records'];symbolic_plan(join['neck'],join['head'])
 for role,weight in [('neck',.25),('head',.8)]:require(join[role]['role']==role and join[role]['material']==0 and join[role]['head_weight']==weight,'Source role/material/weight mismatch')
 ranges=[r for r in producer['vertex_ranges']if r['original_node']=='continuous_body_neck'];require(len(ranges)==1,'Neck semantic source range');r=ranges[0];require(r['material']==0 and r['vertex_start']==0 and r['vertex_count']==241,'Neck source range identity')
 old,labels,heads,owners=frozen_baseline(oldraw,producer,head,ears);model,labels,heads,owners,reverse=candidate_from_maps(raw,old,labels,heads,owners,proof,source_doc);verify_source_seams(model,labels)
 require(model.total==11452,'Exact candidate active count');coat=model.views[0,0];require(coat['mesh_name']=='skinned_equine_coat'and coat['material']==0,'Actual neck coat owner')
 attrs=coat['attributes']
 for k in ATTRS:require(np.array_equal(attrs[k][:241],old.views[0,0]['attributes'][k][:241])and np.isfinite(attrs[k]).all(),'Exact retained neck attribute prefix/finite:'+k)
 require(np.all(np.abs(np.linalg.norm(attrs['NORMAL'].astype(float),axis=1)-1)<1e-5),'Input normal unit contract')
 nodes=[n for n in model.d['nodes']if n.get('mesh')==0];require(len(nodes)==1 and nodes[0].get('skin')==0,'Coat skin association')
 palette=model.d['skins'][0]['joints'];require([model.d['nodes'][palette[i]]['name']for i in[0,1]]==['root','head'],'Actual root/head joint identities')
 for indices,weights in[(range(192,216),[.75,.25,0,0]),(range(216,240),[.5,.5,0,0]),(range(1049,1073),[.2,.8,0,0])]:
  for i in indices:
   require(np.array_equal(attrs['JOINTS_0'][i],[0,1,0,0])and np.array_equal(attrs['WEIGHTS_0'][i],np.array(weights,dtype=attrs['WEIGHTS_0'].dtype)),'Actual bound joint/weight vector')
 # Require every affected original loft triangle survives with unique actual ownership.
 face_ids=[]
 for record in neck_strip_source_faces():
  f=record['vertices'];matches=[i for i,t in enumerate(coat['indices'])if list(map(int,t))in[f,f[1:]+f[:1],f[2:]+f[:2]]]
  require(len(matches)==1,'Missing/duplicate source-owned affected neck triangle');face_ids.append(matches[0])
 require(len(set(face_ids))==96,'Exact96 active affected faces')
 return raw,model,attrs,face_ids,manifest

def proposed_once(baseline,candidate,source,explicit_vector):
 raw,model,attrs,faces,manifest=verified_inputs(Path(baseline),Path(candidate),Path(source))
 lam=explicit_parameters(explicit_vector);p=attrs['POSITION'].copy();n=attrs['NORMAL'].copy();before=p.copy()
 # No proximity inference: producer-owned head portal/band indices.
 values=np.asarray(proposed_band(p[216:240].astype(float),p[1049:1073].astype(float),lam),dtype=p.dtype)
 # Additional local displacement guard ties budget to each original final neck column.
 budget=np.linalg.norm(before[192:216].astype(float)-before[216:240].astype(float),axis=1)
 require(np.all(np.linalg.norm(values.astype(float)-before[192:216].astype(float),axis=1)<=budget),'Proposed move exceeds original local neck-column length; STOP')
 p[192:216]=values
 idx=model.views[0,0]['indices'];tri=p[idx].astype(float);area=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);require(np.isfinite(area).all()and np.all(np.linalg.norm(area,axis=1)>2e-12),'Nonfinite/degenerate actual face')
 accum=np.zeros_like(p,dtype=float)
 for k in range(3):np.add.at(accum,idx[:,k],area)
 # Only vertices in ring7+ring8 own changed area-normal sums; portal ring9 is explicitly FIXED.
 halo=list(range(168,216));norm=np.linalg.norm(accum[halo],axis=1);require(np.all(norm>1e-12),'Invalid bounded normal halo');n[halo]=(accum[halo]/norm[:,None]).astype(n.dtype)
 sparse={'POSITION':sparse_proof(attrs['POSITION'],p,range(192,216)),'NORMAL':sparse_proof(attrs['NORMAL'],n,halo)}
 for k in ['JOINTS_0','WEIGHTS_0']:sparse[k]=sparse_proof(attrs[k],attrs[k],[])
 # Head/ear and all other mesh attributes have no authorized edit; append-only serialization proposal.
 d=copy.deepcopy(model.d);blob=bytearray(model.b);prim=d['meshes'][0]['primitives'][0]
 require(len(d['meshes'][0]['primitives'])==1,'Unexpected coat accessor sharing')
 for k,a in [('POSITION',p),('NORMAL',n)]:prim['attributes'][k]=append(d,blob,a,'VEC3',5126)
 exported=encode(d,blob);reloaded=Model(exported)
 for key,v in model.views.items():
  rv=reloaded.views[key];require(np.array_equal(v['indices'],rv['indices']),'Indices changed')
  for k,a in v['attributes'].items():sparse_proof(a,rv['attributes'][k],range(192,216)if key==(0,0)and k=='POSITION'else halo if key==(0,0)and k=='NORMAL'else[])
 # Protected document equality except the two permitted accessor refs and appended storage.
 a=copy.deepcopy(model.d);b=copy.deepcopy(reloaded.d)
 for doc in[a,b]:
  for k in ['POSITION','NORMAL']:doc['meshes'][0]['primitives'][0]['attributes'].pop(k)
  for k in['accessors','bufferViews','buffers']:doc.pop(k,None)
 require(a==b,'Protected rig/nodes/skins/clips/materials/scenes/document changed')
 return exported,{'status':'UNACCEPTED local sparse export only; all collision/deformation/gear/visual checks NOT RUN','input_pins':PINS,'authority_sha256':AUTHORITY,'lambda_vector':list(map(float,lam)),'sparse_proof':sparse,'output_sha256':hashlib.sha256(exported).hexdigest(),'attribute_before_after_sha256':{k:{'before':hashlib.sha256(attrs[k].tobytes()).hexdigest(),'after':hashlib.sha256(reloaded.views[0,0]['attributes'][k].tobytes()).hexdigest()}for k in ATTRS},'all_other_attribute_arrays_exact':True,'protected_document_exact':True,'all_indices_exact':True,'affected_actual_neck_faces':faces,'normal_halo_policy':'ring7+8 only; fixed portal normals may expose shading discontinuity','source_manifest_reference_only':hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()}
