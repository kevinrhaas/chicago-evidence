# SPDX-License-Identifier: GPL-3.0-or-later
"""UNEXECUTED on horse. Original bounded neck-band continuation proposal.
No IO/export. Pure synthetic controls only. This does NOT prove embedding.
"""
import math
NECK_BAND=tuple(range(192,216))
NECK_PORTAL=tuple(range(216,240))
NECK_PRECEDING=tuple(range(168,192))
HEAD_PORTAL=tuple(range(24))
HEAD_BAND=tuple(range(24,48))

def require(test,message):
 if not test:raise ValueError(message)

def symbolic_plan(neck_record,head_record):
 require(tuple(neck_record['band'])==NECK_BAND,'Unexpected source-owned neck band')
 require(tuple(neck_record['interface'])==NECK_PORTAL,'Unexpected source-owned neck portal')
 require(tuple(head_record['interface'])==tuple(range(1025,1049)),'Unexpected producer head portal')
 require(tuple(head_record['band'])==tuple(range(1049,1073)),'Unexpected producer head band')
 return {'status':'SOURCE PROPOSAL; horse geometry/export/embedding UNEXECUTED',
  'position_changes_permitted':list(NECK_BAND),
  'normal_changes_permitted':list(NECK_BAND),
  'joints_weights_changes_permitted':[],
  'indices_changes_permitted':[],
  'rows':[{'neck_band':192+i,'neck_portal':216+i,'head_source_portal':i,'head_source_band':24+i,'producer_head_portal':1025+i,'producer_head_band':1049+i,'neck_preceding':168+i,'formula':'C_i = Q_i - lambda_i * (H_i-Q_i)'}for i in range(24)],
  'protected_head_attributes':['POSITION','NORMAL','JOINTS_0','WEIGHTS_0'],
  'required_fresh_guards':['all48headvectors_exact','allhead_ear_positions_exact','alloutside_neckband_vectors_exact','source_index_ownership_exact','strict_fullhead_and_ears_vs_ALL_rest','whole_changed_neck_strip_self_and_vsALLbody','63poses_after_idlepass','unchanged_gear_after_selfpass'],
  'not_proven':['parameter_feasibility','global_surface_embedding','pose_embedding','anatomical_or_visual_acceptance']}

def proposed_band(portal,head_band,lambdas):
 """Would run ONLY after release on actual input; presently synthetic tests.
 Per-column opposite continuation is a construction hypothesis, not SAT waiver.
 """
 require(len(portal)==len(head_band)==len(lambdas)==24,'Exact24 correspondence required')
 result=[]
 for q,h,lam in zip(portal,head_band,lambdas):
  require(len(q)==len(h)==3 and all(math.isfinite(x)for x in[*q,*h,lam]),'Nonfinite/bad input')
  require(0<lam<=1,'Bounded positive continuation only')
  direction=[h[k]-q[k]for k in range(3)]
  require(sum(x*x for x in direction)>0,'Collapsed protected head column')
  result.append([q[k]-lam*direction[k]for k in range(3)])
 return result

def neck_strip_source_faces():
 """Both incident strips of ring8; global triangle IDs must be remapped.
 This is SOURCE loft connectivity, not stale global ID inference.
 """
 out=[]
 for j in[7,8]:
  for k in range(24):
   a=j*24+k;b=j*24+(k+1)%24;c=b+24;d=a+24
   for parity,face in enumerate([(a,b,c),(a,c,d)]):out.append({'source_loft_face':j*48+k*2+parity,'vertices':list(face),'strip':j})
 return out

def verify_sparse_change(before,after,allowed):
 require(len(before)==len(after),'Attribute count changed')
 changed=[i for i,(a,b)in enumerate(zip(before,after))if a!=b]
 require(set(changed)<=set(allowed),'Protected attribute changed')
 return changed
