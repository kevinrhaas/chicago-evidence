# Neck-side portal repair proposal — SOURCE ONLY, UNEXECUTED

The fresh strict crossing is retained090 head sourceface33 vs neck source loftface414. Frozen source loft construction defines24samples per ring;414=(8*48+15*2), vertices207/208/232. Current global IDs are2055/690; parent headglobal2061 maps to exactly the same retained sourceface33. The portal alias232=h16 is correct. Two incident triangles share only that point, and the actual crossing lies beyond it. This is a real retained geometry defect, not ownership or acceptable adjacency.

## Bounded hypothesis

Only neck ring8 (192..215) positions and normals may change. Its two incident source strips7/8 contain96triangles. Keep ring7 (168..191), neck ring9 portal216..239, all head/ear positions and all48 protected head POSITION/NORMAL/JOINTS_0/WEIGHTS_0 vectors EXACT. The explicit producer record maps portal216+i to head1025+i, and head band1049+i to source24+i. Do not infer these by proximity. Keep every index, rig/rest/IBM/socket/clip/sole and all gear exact. No new geometry was generated.

For a first candidate, define each ring8 sample C_i from fixed portal Q_i and corresponding fixed head-band H_i by C_i=Q_i-lambda_i*(H_i-Q_i),0<lambda_i<=1. This continues each corresponding head column in the opposite direction on the neck side. Lambda is an explicit reconstructed design parameter, NOT a source-derived anatomical measurement. It does NOT establish circumferential separation or whole strip embedding. There is no selected actual lambda vector or actual candidate in this parcel.

This construction addresses the currently reversed/folded local continuation without moving the protected head. It is only a feasibility hypothesis: keeping fixed ring7 can create pinching, self-crossing, or an ugly neck. Full actual triangle guards must reject these; topology, zero seam gap, a per-column direction test or assigned normals alone cannot establish an embedded surface. Source code returns only a bounded proposal and offers a pure function exercised on synthetic grids, never actual horse coordinates.

## Normal and deformation constraints

Weights/joints remain unchanged for this first proposal: ring8 original root/head .75/.25, portal .5/.5, headband .2/.8. Matching rest position is insufficient under animation, so all63poses remain required after idle. Preserve portal normals exactly on both aliases; recompute only ring8 normals from actual affected surface, retaining unrelated normals. If that creates unacceptable normal discontinuity, report it rather than modifying protected head vectors. Area-weighted normal consistency at the protected seam is not guaranteed by this design. Any extension to ring7 or head firstband must be separately declared and reviewed before generation.

## Intended future sequence, requires root release

Pin exact26027 GLB/current producer and090source producer, verify source records and retired/current primitive maps. Build ONE explicit candidate from the declared24band vertices only, remapping source96face cohort to actual active indices; preserve all unaffected arrays with equality proofs. Reject nonfinite/degenerate faces, bad topology, source-edge foldover, missing alias ownership and any protected change. Then unchanged binary64 full head/ears internal +vsALLrest idle0 (including ALL previous actual baseline negatives), and changed neck region vsALL active horse, with same strict SAT1e-8/proper rules and certified owned simplex contacts only. No head-vs-rest skipping. First failure stops. Only a later release may authorize63poses, unchanged gear clearance and visible quality review. Existing candidate26027 remains FAILED/unaccepted; no earlier passes cover future geometry.

Feasibility is UNPROVEN. No actual measurements, candidate/export, capture, SAT, gear, Blender, browser or app edits occurred for this proposal. Seven synthetic topology/ownership/input controls pass normal and -O. Original failed archives remain unchanged.
