# SPDX-License-Identifier: GPL-3.0-or-later
import unittest,copy
from neck_band_proposal import *
class Controls(unittest.TestCase):
 def test_owned_map(self):
  p=symbolic_plan({'band':list(NECK_BAND),'interface':list(NECK_PORTAL)},{'interface':list(range(1025,1049)),'band':list(range(1049,1073))});self.assertEqual(p['rows'][16]['neck_portal'],232);self.assertEqual(p['rows'][16]['head_source_band'],40)
 def test_wrong_correspondence_rejected(self):
  with self.assertRaises(ValueError):symbolic_plan({'band':list(NECK_BAND),'interface':list(reversed(NECK_PORTAL))},{})
 def test_continuation_no_input_mutation(self):
  q=[[float(i),0.,0.]for i in range(24)];h=[[float(i),0.,1.]for i in range(24)];saved=copy.deepcopy((q,h));r=proposed_band(q,h,[.5]*24);self.assertEqual(r[0],[0.,0.,-.5]);self.assertEqual((q,h),saved)
 def test_bad_or_collapsed_column_rejected(self):
  q=[[0.,0.,0.]]*24
  with self.assertRaises(ValueError):proposed_band(q,q,[.5]*24)
  with self.assertRaises(ValueError):proposed_band(q,[[0.,0.,1.]]*24,[-.5]*24)
 def test_exact_affected_source_faces(self):
  fs=neck_strip_source_faces();self.assertEqual(len(fs),96);self.assertEqual(len({r['source_loft_face']for r in fs}),96);self.assertIn({'source_loft_face':414,'vertices':[207,208,232],'strip':8},fs)
 def test_protected_change_rejected(self):
  with self.assertRaises(ValueError):verify_sparse_change([[0.]]*241,[[1.]]+[[0.]]*240,NECK_BAND)
 def test_band_only_allowed(self):
  b=[[0.]]*241;a=list(b);a[207]=[1.];self.assertEqual(verify_sparse_change(b,a,NECK_BAND),[207])
if __name__=='__main__':unittest.main()
