export function recoveredDisplayDiagnostic(state) {
  const d = state?.diagnostic;
  return state?.readable === true && state.reloadButton === false
    && /^Display reset /.test(state.notice ?? '') && state.text === state.notice
    && d?.previousLost === true && d.previousPage !== d.currentPage
    && typeof d.previousPage === 'string' && typeof d.currentPage === 'string'
    && d.copyVisible === true && d.copyMatchesPrevious === true;
}
