import assert from'node:assert/strict';import{createBlackbox,wasCut,summary,report}from'./blackbox.mjs';import{recoveredDisplayDiagnostic}from'./predicate.mjs';
const entries=new Map(),store={getItem:k=>entries.get(k)??null,setItem:(k,v)=>entries.set(k,v)};let time=10000;const now=()=>time;
function navigate(prior,detail){prior?.end('left');const box=createBlackbox({year:'1835',store,now});box.log('boot',{to:detail+'@1'});return box;}
let box=navigate(null,'balanced');box.log('ready');time+=142500;box.log('lost');box.log('restored');box=navigate(box,'balanced');
assert.equal(wasCut(box.previous,time),true,'actual frozen blackbox explicitly retains clean-reload lost context');
function receipt(b){return{notice:summary(b.previous),text:summary(b.previous),readable:true,reloadButton:false,diagnostic:{previousLost:b.previous.entries.some(e=>e.k==='lost'),previousPage:b.previous.page,currentPage:b.box.page,copyVisible:true,copyMatchesPrevious:report(b.previous)===JSON.stringify(b.previous)}};}
let r=receipt(box);assert.equal(recoveredDisplayDiagnostic(r),true);
for(const mutation of[{...r,notice:null},{...r,reloadButton:true},{...r,readable:false},{...r,text:'unrelated'},{...r,diagnostic:{...r.diagnostic,copyMatchesPrevious:false}},{...r,diagnostic:{...r.diagnostic,previousPage:r.diagnostic.currentPage}},{...r,diagnostic:{...r.diagnostic,previousLost:false}}])assert.equal(recoveredDisplayDiagnostic(mutation),false);
time+=3200;box.log('lost');box.log('restored');box=navigate(box,'light');assert.equal(recoveredDisplayDiagnostic(receipt(box)),true,'manual lowered-tier navigation retains second record');
console.log('PASS real frozen blackbox lost→restore→clean navigation twice; exact diagnostic predicate and7negative refusals. No browser/tier mechanism claim.');
