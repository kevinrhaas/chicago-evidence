import pathlib,subprocess,json,sys
P=pathlib.Path(__file__).parent;sys.path.insert(0,str(P.parent/'proposal/tools'));import human_hair_short04 as hair
root=pathlib.Path('/workspace/chicago');config=json.loads((P.parent/'hair_component.recipe.json').read_text())
for age in [25,35]:
 data=subprocess.check_output(['git','show',f'45bb1933e:chicago/4d/assets/authored/humans/makehuman_hm08/prepared_adult_{age}.json'],cwd=root);body=json.loads(data);mesh,texture,report=hair.fit(body,config,P.parent/'proposal')
 # Inspect original source image + exact source repeating UV, no image editing.
 mesh['uvs']=[[u,(v*2057-1)/2048]for u,v in mesh['uvs']]
 (P/f'fit{age}.json').write_text(json.dumps({'body':body['meshes'][0],'hair':mesh,'fit_report':report},separators=(',',':')))
blob=subprocess.check_output(['git','show','45bb1933e:chicago/4d/assets/authored/humans/skin_toigo_bronze/young_lightskinned_male_diffuse_Bronze.png'],cwd=root);(P/'skin.png').write_bytes(blob)
