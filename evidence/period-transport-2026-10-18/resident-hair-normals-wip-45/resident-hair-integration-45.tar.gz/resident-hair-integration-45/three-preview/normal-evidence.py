import json,pathlib,math,collections
import numpy as np
from PIL import Image
P=pathlib.Path(__file__).parent;m=json.loads((P/'fit25.json').read_text())['body'];p=np.asarray(m['positions_m'],dtype=np.float32);tri=np.asarray(m['triangles']);ids=np.asarray(m['source_vertex_indices']);area=np.cross(p[tri[:,1]]-p[tri[:,0]],p[tri[:,2]]-p[tri[:,0]]);split=np.zeros(p.shape,dtype=np.float64)
for col in range(3):np.add.at(split,tri[:,col],area)
shared=np.zeros((int(ids.max())+1,3),dtype=np.float64);np.add.at(shared,ids,split);old=split/np.maximum(np.linalg.norm(split,axis=1,keepdims=True),1e-30);new=shared[ids]/np.maximum(np.linalg.norm(shared[ids],axis=1,keepdims=True),1e-30)
groups=collections.defaultdict(list)
for i,sid in enumerate(ids):groups[int(sid)].append(i)
metrics=[]
for sid,indices in groups.items():
 if len(indices)<2:continue
 angles=[math.degrees(math.acos(float(np.clip(np.dot(old[a],old[b]),-1,1))))for a in indices for b in indices]
 pos=p[indices[0]]
 metrics.append({'source':sid,'max_duplicate_angle_deg':max(angles),'position':pos.tolist(),'neck':bool(1.49<=pos[1]<=1.60)})
neck=[x for x in metrics if x['neck']];report={'method':'area-weighted trianglecross normal sums on actual Float32 body geometry; union only original source_vertex_indices, no position epsilon merge','body_seam_groups':len(metrics),'neck_seam_groups':len(neck),'max_neck_duplicate_angle_deg':max(x['max_duplicate_angle_deg']for x in neck),'neck_groups_over_10deg':sum(x['max_duplicate_angle_deg']>10 for x in neck),'worst_neck_groups':sorted(neck,key=lambda x:-x['max_duplicate_angle_deg'])[:8],'shared_duplicate_normal_difference_max':max(np.linalg.norm(new[a]-new[b])for ix in groups.values()for a in ix for b in ix),'pixel_comparisons':[]}
for view,box in [('profile',(480,660,740,940)),('three-quarter',(600,720,820,960))]:
 a=np.asarray(Image.open(P/f'normals-split-{view}.png').convert('RGB').crop(box),dtype=np.float64);b=np.asarray(Image.open(P/f'normals-shared-{view}.png').convert('RGB').crop(box),dtype=np.float64);delta=abs(a-b);report['pixel_comparisons'].append({'view':view,'neck_ROI_xyxy':box,'mean_abs_RGB_delta_255':float(delta.mean()),'max_abs_channel_delta_255':float(delta.max()),'pixels_any_channel_delta_over_8':int((delta.max(axis=2)>8).sum()),'ROI_pixels':int(delta.shape[0]*delta.shape[1])})
(P/'normal-evidence.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='worst_neck_groups'},indent=2))
