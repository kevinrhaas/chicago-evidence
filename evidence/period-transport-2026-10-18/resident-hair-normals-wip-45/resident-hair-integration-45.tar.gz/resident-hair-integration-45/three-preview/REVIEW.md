# Actual Three source-fit preview review

2026-10-19. Six real Chromium/Three0.185.1renders viewed: adult25/35 each front, profile, three-quarter. Frozen45bb1933e prepared body and exact licensed skin bytes read via gitshow, original short04 texture2048² unchanged; fittedhair UV transform reversed to original source repeatUV for this diagnostic. Packed/derivedatlas or canonicalGLB not exercised. Neutral hemisphere+two white directional lights, orthographic head framing, sRGB, no tonemapping; original source textureLinear+REPEAT and no mipmaps. This explicitly tests source fit, not mip/export correctness.

One ownedbrowser andserver closed in finally; run.log receipt6cases/zeroerrors. Actual2draws/27,806tris (body26,756+hair1050). No application writes/publication. Scripts and actualscreenshots retained here.

Observed allsix images:

- Full central scalp coverage and coherent sweptstrandflow; temples/sideburns and earoutline legible. No broad scalp hole or gross ear penetration seen from these views. This is visual observation, not trianglecollision proof.
- Crown/profile silhouette remains visibly faceted. Multiple outer cards protrude or separate from bulk; graybackground wedges/slivers appear between top/outer cards. These are suspicious card/alphaedge artifacts, not accepted grooming. On front right crown and nearthreequartertop they are clear atcloseview.
- Nape is relatively long with several thin danglingcardends and squared/scallopedterminaledge. Rearneck/garmentcollision not tested; collar absent in this numerical bodypreview. Cannot approve collision from these images.
- Near upper ear/temple card ends meet tightly; no clear earclipping instaticview, but smallsurfaceintersections or animated ear/head/jaw issues cannot be ruled out.
- Skintexture/geometry displays an abrupt neckpatchboundary. This is existingbody/atlascontext, not hairfit improvement or proof of a newhairfailure. Openred eyeareas are expected because sourcepreparedbody has no canonicaleyecomponents added; these previews do not replace currentcanonicaleyes.
- Adult35 remains very similar to25. Hair does not create distinct individuallyvalidated Joseph/Martin likenesses; labels correctly retain both residentreferences for shared35body.

Recommendation to parent: sourcefit is technically useful and noticeably more coherent than rejectedoriginalscratchgroom, but adopt only as a provisionalsourcecomponent with explicit crown/nape/alpha review open. No claim of photoquality, periodhairstyle, sweptcollision or canonicalassetacceptance. ActualcanonicalnodealphaMASK/export/paddedUVs/mips must be reviewed afterCI; this sourcepreview cannot discharge them.
