# Portable hair-only proposal against frozen human45bb1933e

Outside-app proposal. Current transport checkout untouched. No Blender, browser, CI, publish or asset acceptance.

## Review/apply later

1. Begin from the accepted human branch containing45bb1933e; preserve subsequent rootQA/gait edits. `hair-only-45bb1933e.patch` changes only canonicalbuilder, worker1835recipe and adds originalGPLhairfitter. It was rebuilt from `git show45bb1933e`, not the currenttransportcheckout. Copying completeproposedbuilder over newerrootcode is inappropriate; use contextual patch/rebase.
2. Explicitly ingest ONLY `proposal/assets/authored/humans/hair_short04/` into assets path. Sevenfiles: exact originalOBJ,mhclo,mhmat,PNG; explicitlylabeledderivedpaddedPNG; projectREADME; hashmanifest. No range cache, completepack, othercandidates, exporterprogramorAGPLshader included. Binaryassets are separate from textualpatch.
3. Append reviewed `LICENSES.component-entry.md` to assets/LICENSES.md. It covers allseven exactcomponentpaths with actualSHA, asset-specificCC0noticequotes/copyrightcontacts, sourceURL/ETag, originalversusderived/documentaryterms. Existingcanonical/master/webexportlicenseentries remainadditive; rebuiltGLB/blendhashes do notexistyet andarenotfabricated.
4. Append reviewed `L418.hair-addendum.md` under existingL418; no newperson, biography, historicalgroom claim or automaticphotographicacceptance. IDs remainrc_bardwell_otis/rc_dufresne_joseph/rc_flynn_martin, outputs unchangedbardwell_otis_1835/dufresne_joseph_1835/flynn_martin_1835.
5. Source-manifestSHA in proposedrecipe is `68a02130cd50dd0d727f31f8f53702fe91bd9ecb9aa98309a7814191abf89e99`. Fitter verifies this BEFORE sourcefilehashes, actualoriginalCC0headers andrequiredsourcebodyreferences. Sourceoriginals remainbyteidentical. README is originalCC0documentarydata, notmisclassifiedupstreamprogramcode.

## Actual focused checks

`python audit.py` reads body25/35 directly withgitshow45bb1933e, avoidingcurrenttransportcheckout. Actualfit, sourceUVcorner/triangle preservation, zeropositiondelta versus reviewedfit, allUVwithin0–1, positive normalized≤4boneweights, repeatability andbadmanifest/missingsourcemaprejects PASS. Python syntax compiles. `gitapply--check --unsafe-paths --directory=<thisfolder>/frozen-base hair-only-45bb1933e.patch` PASS; noapplicationmutation. The unsafe-paths flag here permits only the explicitoutsideappscratchprefix; no app writes needed.

The paddingproof is retaineduv-padding-validation.json: originalREPEAT vsderivedCLAMP base-levelbilinear maxerror5.8e-11/255 over991authoredUV+5000samples/body. OriginalVmax1.0031 → derivativeVmax.9991972776 by affineVnew=(2048V+1)/2057 andperiodic8top/1bottomrows. No mip/aniso equivalenceclaim. Actualsourceoriginaltexturehash0bef7fc0e403db5a40fabb2111ebfa6f7e8158e204c6e56b8da98e9ef527846e unchanged.

## Cost/quality limits

PerLOD:991UVsplitverts,1050triangles,1extradraw. AllfourLODs retainexactsourcehairtopology pending measuredlowerLODadaptation; no invisibledecimationdamage claimed. Atlas2048x2057RGBA=16,850,944decodedbytes beforemips. GLBcompressedsize, perresident/crossLODimagecache/dedup, fullpersonbudgetawaitactualCI. Fittedhairskinweights clampone tinynegativeinterpolationrow(maxmass.0000127), zeroweightmassprunedafter4. Neck/clavicle/napeweightsretained; deformationnotreviewed.

PinnedBlender4.5.3actualexporterSOURCE recognizes proposedpreferred1-(Alpha<.4) graph asMASK/.4. SeeEXPORTER-ALPHA-AUDIT.md forlineevidence+receiptpaths. Thisisstaticcodesupport, not verifiedBPy/export. ActualCI mustassertMASKcutoff.4/doubleSide/decodedatlas/skinnedprimitive andrenderedalphaedges, facial/head/neckmotion, scalp/ear/collarfit, material/PBRresponse, allLODs/mobile. Historicalgroom, individualappearance andphotographicacceptance remainopen.

**Selected-texture hardening:** Outside fitter now requires config.texture to be a canonical safe relative path, an actual verified SOURCE.json member, AND the assessed padded derivative name. A separately manifest-listed original image cannot be silently selected with transformedUVs. Real negative cases traversal, absolute, unlisted and wrong verified original all reject; audit.py exercises them on actual25/35bodyinputs. No unchecked arbitrarypath is returned.
