# Blender4.5.3 exporter alpha audit (static, not executed)

Actual files read via permitted official GitHub raw URLs, no Blender or application invocation:

- https://raw.githubusercontent.com/blender/blender/v4.5.3/scripts/addons_core/io_scene_gltf2/blender/exp/material/search_node_tree.py
- https://raw.githubusercontent.com/blender/blender/v4.5.3/scripts/addons_core/io_scene_gltf2/blender/exp/material/materials.py

Exact bytes/SHA are retained in sibling `/workspace/shared/resident-hair-integration/exporter-audit/receipts.json` with downloaded GPL exporter source. That audit code is not CC0 data and is not copied into application or source asset component. Repository generators/blender.pin names4.5.3binary and checksum; GitHubv4.5.3 is the matching source release. No claim the actual worker binary has been byte-inspected or run here.

`search_node_tree.py:488` gather_alpha_info calls detect_alpha_clip. Atlines508–510 a detected cutoff produces alphaMode='MASK' and alphaCutoff=cutoff. `detect_alpha_clip` at568 supports three patterns. It explicitly calls the simple GREATER_THAN form legacy/backward-compatible and “Wrong when X = cutoff”. Preferred general threshold pattern is `1-(X<cutoff)`, representing >=. Atlines580–592 it recognizes SUBTRACT with input0constant1 and input1linked toLESS_THAN whose input0istexture/nonconstant, input1constantcutoff. It advances navigation to underlying texture input and returnscutoff. `materials.py:224–239` propagates MASK and preservesnondefault.4cutoff.

Proposal now uses that preferred exact1-(Alpha<.4) pattern, rather than prior strictGREATER_THAN. TextureAlpha→LESS_THAN(input1=.4)→SUBTRACT(input0=1,input1=lessresult)→PrincipledAlpha. This agrees with glTF threshold acceptance at equality and source CPU preview's alpha102/255=.4. The material's explicit double-sided setting maps through existing exporter logic, but that too must be checked on emittedbytes.

Static source support is established. Actual generated BPy node graph, exporter socket-navigation recognition, alphaModeMASK/cutoff.4 in finalGLB, combined base-color/alpha texture packing, decoded atlas, runtime minification and hair-edge acceptance remain **UNEXECUTED**. CI must assert actualmaterial.alphaMode==='MASK', abs(alphaCutoff-.4)<1e-6, doubleSidedtrue, textureimage decoded2048x2057 (or explicitlyvalidated derivative), no mysterious opaque fallback; inspect actual renders. A passing pure fit test cannot substitute for those checks.
