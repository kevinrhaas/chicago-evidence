# Body-only source-normal repair proposal against45bb1933e

Outside-app originalGPLcode. No app edits, Blender, browser rerun, texture edits, publication or acceptance. Independent of hair patch; files underproposal are review copies, not a command to overwrite concurrentrootQA/gaitcode.

## Proven defect and bounded repair

Actualsource-fit comparison removed the large neck triangle using ONLY area-weighted normals shared across exactsource_vertex_indices. Sourcepositions, triangleindices, UVs, weights andskinimage remainedunchanged. See sibling `/workspace/shared/resident-hair-integration-45/three-preview/NORMAL-DIAGNOSIS.md` and before/afterscreenshots. Neck115seamgroups:65had>10degreesUVsplitnormaldisagreement,max81.51degrees; sharing yields0duplicate disagreement. This fixes a sourcepreviewnormalartifact, not photographicappearance generally.

`human_source_normals.py` validates exactsourceIDs, finitevertices/validorientednondegeneratefaces andcoincidentrestpositions within1nm forduplicates. It sums rawtrianglecross vectors (twiceorientedarea) bysourceID withmath.fsum thennormalizes, returning independent normalarrays withoutmutatinginputs. It neverepsilonweldsdifferentIDs, changesgeometry, normalizesfacevectorsbeforeweighting orsilentlyacceptsnoncoincidentduplicateIDs. Opposingorientednormals thatcanceltozero failclearly.

`body-normals-only-45bb1933e.patch` onlyextendsobject_mesh'soptionalargument and passesm.source_vertex_indices in BODYcalls. After meshupdate/UVloops/smoothflags it convertsvectors through existingorthogonalframe/normalizes andsets per-loopcustomnormals. Garment/shoe/collar/eye/haircalls remainunchanged; rig/gait/QA/metadatauntouched. Assignment occursbeforeexistingLODdecimation andarmaturemodifier. No topology/UV/weight edits.

ActualofficialBlender4.5.3RNA source statically defines `Mesh.normals_split_custom_set(normals)` forper-loopcustomnormals. ExactpermittedGitHubsourceURL+SHA inBPy-api-source-receipt.json, originalGPLsource retained onlyforoutsideaudit asBlender45-rna-mesh-api.audit.cc; notcopiedintoproposalcode/assets. ActualBPyexecution hasnotoccurred.

## Focused validation

`python test_normals.py` =>5testsPASS. Independenttwofacesfixturechecks unequalarea2:1 analyticallyexpectednormal(0,1/sqrt5,2/sqrt5); bothwindingreversal andsameposition/differentsourceIDs staycorrect. Noncoincidentduplicates/badindices/degeneratefacesreject. Actualfrozen25/35bodies readvia gitshow45:14,517normalrows/13,380uniqueIDs, unitnormals, identicalseamduplicates, determinism andfullinputnonmutationPASS. ExactfrozenbodySHA inactual-source-test-receipt.json. Pythonproposedbuildersyntaxcompiles; gitapply--check againstoutsidefrozen-basePASS.

## Integration/acceptance still required

Review/apply contextualpatch onhumanbranch; do notcopycompletebuilder overnewerrootchanges. It is disjointfromhairmaterialprovenance; combineviaordinarypatchreview. Normaltool isprojectGPL, not aCC0asset requiringgraphicalassetlicenseentry. No historicalidentity/likenessclaimaltered.

CanonicalCI mustexerciseactualsupportedBPycall, inspectLOD0bodycornernormals atsourceUVseams, andcompareactualdecodedGLBNORMAL/UV/positionbuffers andclose neckrenders. Blenderdecimation maytransfer/rebuildcustomnormaldata; checkeachLOD, notassume. Morphskin deformation, per-loopcustomnormalexport, normal/tangent/texturebehavior and canonicalappearanceremainunverified. IfLODreductionlosesnormalintent, derive/auditappropriatepostreductiontransfer ratherthandeclareallsmooth. Rawsourcefulldensityrestnormalproofdoesnotestablishanimatednormalsorfinalanatomy/photographicquality.
