# SPDX-License-Identifier: GPL-3.0-or-later
"""Frozen source LBS triangles versus decoded exported axis-aligned OBBs.

All furniture is unrotated in body frame. SAT is exact for triangle/OBB;
polygon clipping distinguishes solid-interior entry from surface-only contact.
"""
import json,math,struct,hashlib
from pathlib import Path
from solve import sub,add,scale,dot,cross,norm,mv
O=Path(__file__).parent
EPS=1e-10

def sat(tri,lo,hi):
 c=[(a+b)/2 for a,b in zip(lo,hi)];h=[(b-a)/2 for a,b in zip(lo,hi)];v=[sub(p,c) for p in tri];e=[sub(v[(i+1)%3],v[i]) for i in range(3)];basis=[[1,0,0],[0,1,0],[0,0,1]]
 for axis in basis+[cross(e[0],e[1])]+[cross(a,b) for a in e for b in basis]:
  if norm(axis)<1e-14:continue
  q=[dot(x,axis) for x in v];r=math.fsum(abs(x)*y for x,y in zip(axis,h))
  if min(q)>r or max(q)<-r:return False
 return True

def clip(tri,lo,hi):
 p=tri
 for k in range(3):
  for bound,sign in [(lo[k],1),(hi[k],-1)]:
   q=[]
   if not p:return []
   for a,b in zip(p,p[1:]+p[:1]):
    da,db=(a[k]-bound)*sign,(b[k]-bound)*sign
    if da>=0:q.append(a)
    if (da>=0)!=(db>=0):q.append(add(a,scale(sub(b,a),da/(da-db))))
   p=q
 return p

def exported_boxes():
 blob=(O/'export/wagon-w01.glb').read_bytes();n=struct.unpack_from('<I',blob,12)[0];g=json.loads(blob[20:20+n]);binary=blob[28+n:];points=[]
 # Merged body surface primitives have no transforms beyond identity body/root.
 for node in g['nodes']:
  if 'mesh' not in node or not node['name'].startswith('vehicle_body_'):continue
  for p in g['meshes'][node['mesh']]['primitives']:
   a=g['accessors'][p['attributes']['POSITION']];v=g['bufferViews'][a['bufferView']];off=v.get('byteOffset',0)+a.get('byteOffset',0)
   points.extend(struct.unpack_from('<3f',binary,off+12*i) for i in range(a['count']))
 parts=[p for p in g['extras']['driver_furniture']['parts'] if p['role']=='timber']
 P=g['extras']['parameters'];_,W,H=P['body_m'];BED=P['bed_top_m'];L=P['body_m'][0]
 for side in [-1,1]:parts.append(dict(name='existing_top_rail_'+str(side),min_m=[side*W/2-.0275,BED+H-.01,-(L+.05)/2],max_m=[side*W/2+.0275,BED+H+.03,(L+.05)/2]))
 out=[]
 for p in parts:
  corners=[]
  for x in [p['min_m'][0],p['max_m'][0]]:
   for y in [p['min_m'][1],p['max_m'][1]]:
    for z in [p['min_m'][2],p['max_m'][2]]:
     q=min(points,key=lambda q:math.dist(q,[x,y,z]));assert math.dist(q,[x,y,z])<2e-7;corners.append(q)
  out.append(dict(name=p['name'],lo=[min(v[k] for v in corners) for k in range(3)],hi=[max(v[k] for v in corners) for k in range(3)]))
 return out,hashlib.sha256(blob).hexdigest()

def main(corrected=False):
 boxes,glbhash=exported_boxes();bindings=json.loads((O/'resident-driver-bindings.json').read_text());rows=[]
 for binding in bindings['resident_bindings']:
  age=25 if binding['asset_id']=='bardwell_otis_1835' else 35;path=O/f'frozen-adult{age}.json';assert hashlib.sha256(path.read_bytes()).hexdigest()==binding['body_sha256']
  d=json.loads(path.read_text());bones={b['name']:b for b in d['skeleton']};m=d['meshes'][0];posefile=(binding['asset_id']+'-triangle-corrected-pose.json') if corrected else binding['pose_draft_file'];pose=json.loads((O/posefile).read_text())['bone_global_head_rotation']
  points=[]
  for v,w in zip(m['positions_m'],m['weights']):
   p=[0.,0.,0.]
   for name,weight in w.items():p=add(p,scale(add(pose[name]['head_m'],mv(pose[name]['rotation_3x3'],sub(v,bones[name]['head_m']))),weight))
   points.append(p)
  results=[]
  for box in boxes:
   lo,hi=box['lo'],box['hi'];inside=[];contacts=[];testcount=0;maxdepth=0
   for index,indices in enumerate(m['triangles']):
    tri=[points[i] for i in indices]
    if any(max(p[k] for p in tri)<lo[k]-EPS or min(p[k] for p in tri)>hi[k]+EPS for k in range(3)):continue
    testcount+=1
    innerlo=[x+EPS for x in lo];innerhi=[x-EPS for x in hi]
    if sat(tri,innerlo,innerhi):
     poly=clip(tri,innerlo,innerhi)
     if poly:
      center=[math.fsum(p[k] for p in poly)/len(poly) for k in range(3)];depth=min(min(center[k]-lo[k],hi[k]-center[k]) for k in range(3));maxdepth=max(maxdepth,depth);inside.append(index);continue
    expandedlo=[x-EPS for x in lo];expandedhi=[x+EPS for x in hi]
    if sat(tri,expandedlo,expandedhi):
     poly=clip(tri,expandedlo,expandedhi);top=bool(poly) and all(abs(p[1]-hi[1])<=2*EPS for p in poly)
     expected=(box['name']=='driver_bench_plank' or box['name']=='driver_footboard') and top
     contacts.append(dict(triangle=index,type='intended_top_touch_candidate' if expected else 'other_surface_touch',dominant_bones=sorted({max(m['weights'][i],key=m['weights'][i].get) for i in indices})))
   results.append(dict(part=box['name'],sat_candidates=testcount,strict_interior_triangles=len(inside),penetrating_triangle_ids=inside,max_clipped_centroid_interior_depth_m=maxdepth,surface_contacts=contacts))
  hands={}
  for side in ['l','r']:
   hand=bones['hand_'+side];thumb=bones['thumb_01_'+side]['head_m'];index=bones['index_01_'+side]['head_m'];middle=bones['middle_01_'+side]['head_m'];little=bones['pinky_01_'+side]['head_m'] if 'pinky_01_'+side in bones else bones['ring_01_'+side]['head_m']
   long=scale(sub(middle,hand['head_m']),1/norm(sub(middle,hand['head_m'])));across=scale(sub(index,little),1/norm(sub(index,little)));normal=scale(cross(long,across),1/norm(cross(long,across)))
   center=scale(add(hand['head_m'],middle),.5);weighted=[(i,v) for i,(v,w) in enumerate(zip(m['positions_m'],m['weights'])) if w.get('hand_'+side,0)>=.7 and dot(sub(v,hand['head_m']),long)>.015 and dot(sub(v,hand['head_m']),long)<math.dist(hand['head_m'],middle) and abs(dot(sub(v,center),across))<.018]
   dist=[dot(sub(v,center),normal) for i,v in weighted];assert dist
   # Both surfaces recorded: source convention has not yet established anatomical palm normal.
   frame=pose['hand_'+side];posed=lambda p:add(frame['head_m'],mv(frame['rotation_3x3'],sub(p,hand['head_m'])))
   anchors=[add(center,scale(normal,s)) for s in [min(dist),max(dist)]]
   hands[side]=dict(wrist_m=frame['head_m'],palm_center_bone_derived_m=posed(center),surface_candidates_m=[posed(a) for a in anchors],hand_weighted_source_vertices=len(weighted),source_surface_signed_range_m=[min(dist),max(dist)],surface_candidate_vertex_indices=[min(weighted,key=lambda pair:abs(dot(sub(pair[1],center),normal)-s))[0] for s in [min(dist),max(dist)]],actual_skinned_surface_vertex_candidates_m=[points[min(weighted,key=lambda pair:abs(dot(sub(pair[1],center),normal)-s))[0]] for s in [min(dist),max(dist)]],contact_status='Open hand. Bone-derived palm frame and weighted-skin thickness candidates, not a closed grip or rein contact.',thumb_base_m=posed(thumb),index_base_m=posed(index),middle_base_m=posed(middle))
  rows.append(dict(asset_id=binding['asset_id'],person_reference_id=binding['person_reference_id'],body_sha256=binding['body_sha256'],triangle_box_results=results,hand_anchors=hands))
 report=dict(status='Frozen45bb1933 actual source-body LBS vs decodedGLB boxes; canonical garments/export untested',epsilon_m=EPS,epsilon_basis='0.1nm float64 comparison band, not float32 geometry rounding allowance',glb_sha256=glbhash,residents=rows)
 (O/('triangle-corrected-contact-report.json' if corrected else 'triangle-contact-report.json')).write_text(json.dumps(report,indent=2)+'\n')
 for row in rows:print(row['asset_id'],[(r['part'],r['strict_interior_triangles'],len(r['surface_contacts']),r['max_clipped_centroid_interior_depth_m']) for r in row['triangle_box_results']]);print('hands',row['hand_anchors'])
if __name__=='__main__':
 import sys
 main('--corrected' in sys.argv)
