import unittest,json
from qualify_contacts import sat,clip,O
class Contact(unittest.TestCase):
 def test_crossing_without_any_inside_vertex(self):
  tri=[[-2,0,0],[2,0,0],[0,2,0]];lo=[-1,-1,-1];hi=[1,1,1]
  self.assertFalse(any(all(lo[k]<v[k]<hi[k] for k in range(3)) for v in tri))
  self.assertTrue(sat(tri,lo,hi));self.assertTrue(clip(tri,lo,hi))
 def test_touch_vs_interior(self):
  tri=[[-.2,1,-.2],[.2,1,-.2],[0,1,.2]]
  self.assertTrue(sat(tri,[-1,-1,-1],[1,1,1]))
  self.assertFalse(sat(tri,[-1+1e-9]*3,[1-1e-9]*3))
 def test_failed_original_preserved_and_correction(self):
  old=json.loads((O/'triangle-contact-report.json').read_text());new=json.loads((O/'triangle-corrected-contact-report.json').read_text())
  self.assertEqual(len(old['residents']),3);self.assertEqual([r['body_sha256'] for r in old['residents']],[r['body_sha256'] for r in new['residents']])
  for a,b in zip(old['residents'],new['residents']):
   self.assertGreater(sum(r['strict_interior_triangles'] for r in a['triangle_box_results']),0)
   self.assertEqual(sum(r['strict_interior_triangles'] for r in b['triangle_box_results']),0)
   foot=next(r for r in b['triangle_box_results'] if r['part']=='driver_footboard')
   self.assertEqual(len(foot['surface_contacts']),12)
   self.assertTrue(all(c['type']=='intended_top_touch_candidate' for c in foot['surface_contacts']))
if __name__=='__main__':unittest.main()
