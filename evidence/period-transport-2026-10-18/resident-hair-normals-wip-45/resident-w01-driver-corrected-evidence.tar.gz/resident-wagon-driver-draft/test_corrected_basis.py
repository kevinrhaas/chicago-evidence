"""Actual source-body FK/LBS regression across distinct bone rest-roll bases.

Blender rest bases are read at execution; these rotated rest frames deliberately
exercise basis invariance, not an unexecuted claim to reconstruct Blender roll.
"""
import unittest,json,math,hashlib,tempfile
from human_seated_study import *
from solve import R,O,align,sub,mv,add,scale

def point(m,p):return [math.fsum(m[i][j]*p[j] for j in range(3))+m[i][3] for i in range(3)]
def c(p):return [p[0],-p[2],p[1]]
def ci(p):return [p[0],p[2],-p[1]]
class SeatedBasis(unittest.TestCase):
 def test_actual_source_fk_lbs_across_rest_rolls(self):
  recipe=json.loads((O/'frozen-worker-recipe.json').read_text());worst=0;reports=[]
  for variant in recipe['proof_variants']:
   path=O/f"frozen-adult{variant['body_parameters']['engineering_age_years']}.json";body=json.loads(path.read_text());pose,meta=load_study(O/'resident-driver-bindings-triangle-corrected.json',variant,path,1,O/'export/wagon-w01.json')
   for roll in (0,.7,-1.1):
    rest={};desired={};recovered={}
    for bone in body['skeleton']:
     n=bone['name'];direction=c(sub(bone['tail_m'],bone['head_m']));q=align([0,1,0],direction)
     twist=[[math.cos(roll),0,math.sin(roll)],[0,1,0],[-math.sin(roll),0,math.cos(roll)]]
     rot=[[math.fsum(q[i][k]*twist[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
     rest[n]=transform(rot,c(bone['head_m']));desired[n]=desired_matrix(pose[n],rest[n])
    for bone in body['skeleton']:
     n,parent=bone['name'],bone['parent'];local=local_basis(rest[n],desired[n],rest.get(parent),desired.get(parent))
     recovered[n]=mm(rest[n],local) if parent is None else mm(mm(mm(recovered[parent],inverse_rigid(rest[parent])),rest[n]),local)
     self.assertLess(max(abs(recovered[n][i][j]-desired[n][i][j]) for i in range(4) for j in range(4)),1e-12)
    deformation={n:mm(recovered[n],inverse_rigid(rest[n])) for n in rest}
    B={b['name']:b for b in body['skeleton']};actual=[];maximum=0
    for v,w in zip(body['meshes'][0]['positions_m'],body['meshes'][0]['weights']):
     result=[0.,0.,0.];expected=[0.,0.,0.]
     for n,weight in w.items():
      result=add(result,scale(ci(point(deformation[n],c(v))),weight))
      expected=add(expected,scale(add(pose[n]['head_m'],mv(pose[n]['rotation_3x3'],sub(v,B[n]['head_m']))),weight))
     maximum=max(maximum,math.dist(result,expected));actual.append(result)
    self.assertLess(maximum,2e-12);worst=max(worst,maximum)
    for side in ('l','r'):
     foot=[p for p,w in zip(actual,body['meshes'][0]['weights']) if w.get('foot_'+side,0)+w.get('ball_'+side,0)>=.9]
     self.assertLess(abs(min(v[1] for v in foot)-1.1200000047683716),2e-12)
     self.assertTrue(all(-.425<=v[0]<=.425 and 1.12<=v[2]<=1.42 for v in foot))
    pelvis=B['pelvis']['head_m'];candidates=[p for p,v,w in zip(actual,body['meshes'][0]['positions_m'],body['meshes'][0]['weights']) if abs(v[0])<.18 and pelvis[1]-.18<v[1]<pelvis[1]+.04 and v[2]<pelvis[2] and w.get('pelvis',0)+w.get('thigh_l',0)+w.get('thigh_r',0)>.5 and .5<=p[2]<=.8]
    self.assertGreater(min(p[1] for p in candidates),1.58)
    reports.append(dict(asset=variant['id'],rest_roll_rad=roll,max_fk_lbs_error_m=maximum,seat_min_gap_m=min(p[1] for p in candidates)-1.58))
  (O/'triangle-corrected-rest-basis-regression.json').write_text(json.dumps(dict(status='purePython actualsource FK/LBS; Blender rest matrices/export pending',worst_error_m=worst,cases=reports),indent=2)+'\n')
 def test_reference_and_scale_guard(self):
  v=json.loads((O/'frozen-worker-recipe.json').read_text())['proof_variants'][0]
  with self.assertRaisesRegex(ValueError,'unscaled'):load_study(O/'resident-driver-bindings-triangle-corrected.json',v,O/'frozen-adult25.json',1.1,O/'export/wagon-w01.json')
  bad=dict(v,person_reference_id='new_person')
  with self.assertRaisesRegex(ValueError,'matching'):load_study(O/'resident-driver-bindings-triangle-corrected.json',bad,O/'frozen-adult25.json',1,O/'export/wagon-w01.json')
 def test_actual_furniture_guard(self):
  v=json.loads((O/'frozen-worker-recipe.json').read_text())['proof_variants'][0]
  with self.assertRaisesRegex(ValueError,'physical bench'):
   load_study(O/'resident-driver-bindings-triangle-corrected.json',v,O/'frozen-adult25.json',1,O/'baseline/wagon-w01.json')
  d=json.loads((O/'export/wagon-w01.json').read_text());d['driver_furniture']['seat_surface_m'][1]+=.01
  with tempfile.TemporaryDirectory() as folder:
   path=Path(folder)/'changed.json';path.write_text(json.dumps(d))
   with self.assertRaisesRegex(ValueError,'dimensions changed'):
    load_study(O/'resident-driver-bindings-triangle-corrected.json',v,O/'frozen-adult25.json',1,path)
if __name__=='__main__':unittest.main()
