# SPDX-License-Identifier: GPL-3.0-or-later
"""Separate proposed correction; preserve original pose and provenance files."""
import json,math
from qualify_contacts import O,clip,exported_boxes
from solve import solve
boxes,_=exported_boxes();bench=next(b for b in boxes if b['name']=='driver_bench_plank');top=bench['hi'][1];footboard_top=next(b for b in boxes if b['name']=='driver_footboard')['hi'][1]
def exact_surface_gap(points,triangles):
 minimum=float('inf')
 for ids in triangles:
  tri=[points[i] for i in ids]
  if max(v[0] for v in tri)<bench['lo'][0] or min(v[0] for v in tri)>bench['hi'][0] or max(v[2] for v in tri)<bench['lo'][2] or min(v[2] for v in tri)>bench['hi'][2]:continue
  polygon=clip(tri,[bench['lo'][0],-10,bench['lo'][2]],[bench['hi'][0],10,bench['hi'][2]])
  if polygon:minimum=min(minimum,min(v[1] for v in polygon))
 return minimum-top
rows=[]
for age,ids in [(25,['bardwell_otis_1835']),(35,['dufresne_joseph_1835','flynn_martin_1835'])]:
 body=json.loads((O/f'frozen-adult{age}.json').read_text());old=json.loads((O/(ids[0]+'-pose.json')).read_text());py=old['bone_global_head_rotation']['pelvis']['head_m'][1];low=py;high=py+.01
 # Conservatively register actual triangle footprint to exported top, with1micrometre separation.
 for _ in range(24):
  middle=(low+high)/2;points,T,chains=solve(body,middle,footboard_top);gap=exact_surface_gap(points,body['meshes'][0]['triangles'])
  if gap<1e-6:low=middle
  else:high=middle
 points,T,chains=solve(body,high,footboard_top);gap=exact_surface_gap(points,body['meshes'][0]['triangles'])
 for asset in ids:
  (O/(asset+'-triangle-corrected-pose.json')).write_text(json.dumps({'frame':'metres +Yup +Zforward','status':'Proposed triangle-footprint pelvis registration; not canonical Blender acceptance','bone_global_head_rotation':{n:{'head_m':t,'rotation_3x3':rot} for n,(rot,t) in T.items()}},indent=2)+'\n')
  rows.append(dict(asset_id=asset,original_pelvis_y_m=py,proposed_pelvis_y_m=high,change_m=high-py,exact_triangle_footprint_gap_m=gap,maximum_chain_endpoint_error_m=max(c['endpoint_error_m'] for c in chains)))
(O/'triangle-correction-proposal.json').write_text(json.dumps({'status':'Separate correction proposal; original pose/patch unchanged','contact_clearance_m':1e-6,'footboard_actual_decoded_top_m':footboard_top,'rows':rows},indent=2)+'\n');print(rows)
