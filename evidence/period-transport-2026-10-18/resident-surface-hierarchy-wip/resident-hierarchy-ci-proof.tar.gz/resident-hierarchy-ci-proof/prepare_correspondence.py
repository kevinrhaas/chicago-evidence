from pathlib import Path
import difflib
repo=Path('/workspace/chicago');out=Path('/workspace/shared/resident-hierarchy-ci-proof');base='chicago/4d/tools/'
p=repo/(base+'human_frame_compare.js');old=p.read_text()
anchor='function release(scene)'
helper="""function sortUniqueMeshes(meshes){
  const names=new Set();for(const m of meshes){if(typeof m.name!=='string'||!m.name||names.has(m.name))throw Error('missing or duplicate loaded skinned mesh name');names.add(m.name);}
  return meshes.slice().sort((a,b)=>a.name<b.name?-1:a.name>b.name?1:0);
}
"""
new=old.replace(anchor,helper+anchor).replace('return{...asset,meshes,bind:[]};','return{...asset,meshes:sortUniqueMeshes(meshes),bind:[]};')
# Keep existing comparisons and tolerance. Add explicit order correspondence receipt.
new=new.replace('mesh_count:raw.meshes.length,','mesh_count:raw.meshes.length,mesh_correspondence:{method:\'unique loaded mesh names sorted by deterministic UTF16 order; layout must match exactly\',names:raw.meshes.map(m=>m.name)},')
new=new.replace('actual decoded CPU-skinned world vertices, raw export versus frame-cleaned/source-skin-consolidated export only; not Meshopt parity, photographic quality or a continuous-time proof','actual decoded CPU-skinned world vertices of explicitly supplied GLB pairs; not historical artifact identity, Meshopt parity, photographic quality or a continuous-time proof')
assert new!=old
(out/'human_frame_compare.js').write_text(new)
p=repo/(base+'test_human_inspection.mjs');testold=p.read_text()
addition="""
// Hierarchy traversal changes cannot change vertex correspondence. Real Three
// CPU-skinned/morphed meshes are reordered by unique names, never array position.
const orderA=model(.4),orderB=model(.4),extraA=model(.2),extraB=model(.2);
for(const [m,name]of [[orderA,'body'],[orderB,'body'],[extraA,'hair'],[extraB,'hair']]){m.meshes[0].name=name;for(const clip of m.animations)for(const track of clip.tracks)track.name=track.name.replace('adult.',name+'.');}
orderA.scene.add(extraA.scene);orderB.scene.add(extraB.scene);
orderA.meshes.push(extraA.meshes[0]);orderB.meshes.unshift(extraB.meshes[0]);
assert.notDeepEqual(orderA.meshes.map(m=>m.name),orderB.meshes.map(m=>m.name));
orderA.meshes=ctx.sortUniqueMeshes(orderA.meshes);orderB.meshes=ctx.sortUniqueMeshes(orderB.meshes);
ctx.bind(orderA);ctx.bind(orderB);ctx.pose(orderA,null,0);ctx.pose(orderB,null,0);
assert.equal(ctx.maximumPointDisplacement(ctx.surface(orderA),ctx.surface(orderB)),0);
assert.equal(JSON.stringify(ctx.layout(orderA)),JSON.stringify(ctx.layout(orderB)));
assert.equal(ctx.sampleNamedMorphs(orderA,orderB).maximum_vertex_delta_m,0);
assert.throws(()=>ctx.sortUniqueMeshes([orderA.meshes[0],orderA.meshes[0]]),/duplicate/);
const missingName=model();missingName.meshes[0].name='';assert.throws(()=>ctx.sortUniqueMeshes(missingName.meshes),/missing/);
"""
testnew=testold+'\n'+addition;(out/'test_human_inspection.mjs').write_text(testnew)
patch=[]
for name,a,b in [(base+'human_frame_compare.js',old,new),(base+'test_human_inspection.mjs',testold,testnew)]:patch.extend(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(out/'correspondence-REPO-ROOT.patch').write_text(''.join(patch))
