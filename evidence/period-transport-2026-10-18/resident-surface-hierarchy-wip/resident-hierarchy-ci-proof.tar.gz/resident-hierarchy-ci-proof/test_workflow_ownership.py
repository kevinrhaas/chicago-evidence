"""Parsed YAML ownership regression for the outside CI proposal (requires PyYAML)."""
import unittest
from pathlib import Path
import yaml
HERE=Path(__file__).parent
class Ownership(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.old=yaml.safe_load((HERE/'workflow.baseline.yml').read_text());cls.new=yaml.safe_load((HERE/'workflow.proposed.yml').read_text())
 def test_legacy_humans_job_exactly_unchanged(self):self.assertEqual(self.old['jobs']['humans'],self.new['jobs']['humans'])
 def test_one_control_step_owned_only_by_teamster_studies(self):
  name='Build same-new-master parented hierarchy controls (test artifacts only)'
  for key,job in self.new['jobs'].items():self.assertEqual(sum(s.get('name')==name for s in job['steps']),1 if key=='teamster-studies' else 0,key)
  steps=self.new['jobs']['teamster-studies']['steps'];names=[s.get('name')for s in steps]
  self.assertLess(names.index('Build three canonical masters and export through the portable path'),names.index(name));self.assertLess(names.index(name),names.index('Install Playwright'))
 def test_control_export_evidence_is_isolated(self):
  steps=self.new['jobs']['teamster-studies']['steps'];control=next(s for s in steps if s.get('name','').startswith('Build same-new-master'))
  self.assertEqual(control['env']['HUMAN_EXPORT_EVIDENCE_DIR'],'/tmp/teamster-studies/hierarchy-controls/frame-evidence')
  production=next(s for s in steps if s.get('name','').startswith('Build three canonical'))
  self.assertNotEqual(control['env']['HUMAN_EXPORT_EVIDENCE_DIR'],production['env']['HUMAN_EXPORT_EVIDENCE_DIR'])
 def test_three_control_comparison_pairs_and_one_validator_step(self):
  steps=self.new['jobs']['teamster-studies']['steps'];validators=[s for s in steps if s.get('name','').startswith('Validate hierarchy control warnings')];self.assertEqual(len(validators),1)
  measurement=next(s for s in steps if s.get('name','').startswith('Measure all human exports'))
  control_lines=[line for line in measurement['run'].splitlines()if '--frame-pair /tmp/teamster-studies/hierarchy-controls/'in line];self.assertEqual(len(control_lines),3)
  for name in ['bardwell_otis_1835','dufresne_joseph_1835','flynn_martin_1835']:
   self.assertEqual(sum(name+'.lod0.glb assets/humans/'+name+'.lod0.glb'in line for line in control_lines),1)
if __name__=='__main__':unittest.main()
