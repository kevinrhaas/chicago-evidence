# Same-new-master hierarchy proof proposal (outside app)

Base checkout45bb1933e, 2026-10-19. **No app writes, local Blender execution or browser execution.** Apply `hierarchy-proof-REPO-ROOT.patch` from repository root after root's timing/hair work is ready. Upcoming hair must use the existing shared object_mesh helper or independently satisfy the same identity/root/modifier assumptions. This is a prospective controlled new-build comparison, not inspection of blocked old CI45 artifacts.

## Production and control

Production change removes only obj.parent=rig from authored human_teamster_blend.py's common object_mesh. Pose bones, modifiers, data, weights, morphs, materials, source axes and sockets remain authored as before. Legacy fixture builder/export kwargs are untouched.

In the pinned CI worker, newly generated production canonical master is then loaded by `human_hierarchy_control.py --test-only-parented-control`. This is deliberately a clone control rather than a second body regeneration: it preserves the same actual body, upcoming hair, wardrobe, actions, scene provenance and other metadata. It verifies actual source rigid-rig proof, root identity object frames and identity parent inverses; refuses preexisting parents, wrong Armature modifier targets, duplicate/empty mesh names and object-transform animation (legacy/layered curves). It reparents only the skin meshes to the identity rig and restores exact matrix_world copies. It checks source mesh data identities and post-evaluation identity world frames. Embedded provenance remains unchanged; only the external receipt labels this file TEST ARTIFACT and records source/control SHA256 and changed parent names/world matrices. Original canonical master hash must remain unchanged. Source, output and receipt paths must differ; control outputs must stay under/tmp. The explicit opt-in helper is never called from production generation/publishing.

Control file is exported with actual human_export.py (including current authored-only rigid frame repair/zero-origin option) into isolated /tmp paths. The same strict human_skin_canonicalize.py consolidates exact-equivalent skin palettes. No derivative compression is applied to control; it is compared against the production **source** LOD0, not the published Meshopt file. Existing independent actual source/published sole-contact runs continue unchanged.

## Actual comparison and validator receipts proposed

Workflow runs actual Khronos validation on each of three control/source LOD0 pairs. A concise JSON line records hashes, every warning/error's exact pointer/code/message, resolved node name/mesh/skin/parent indices, counts and truncation flag. Control must have only non-root skin warnings with actual skinned child node pointers; production must have no warnings/errors. Unexpected issues fail rather than being described as harmless.

Existing frame comparison is extended only to make point correspondence independent of scene traversal: loaded skinned meshes are sorted by **unique loaded mesh name** in deterministic UTF16 order. Empty/duplicate names reject. The existing exact per-mesh vertex/index/material/group/drawrange/morph layouts and clip facts must still match. This matters because moving meshes out of the armature can reorder scene traversal while preserving their geometry. Receipts record correspondence names explicitly.

The existing comparator samples actual decoded CPU morph+skin world vertices at default rest and21 phases of every clip, plus each named morph independently at weight1 (other defaults retained) at rest and one available walk midpoint. Its unchanged0.0001m tolerance applies to all differences. Full per-phase/morph receipts remain in inspection.json; normal log gains concise input hashes, correspondence, rest/max/morph deltas, tolerance and verdict. No loaded motion comparison is claimed run here.

## Verification actually performed outside app

- Five pure helper tests pass against the actual proposed reparent_control function under explicit matrix/object stubs: parent-only mutation/data retention, refusal before mutation for bad frames/parents/targets/names, legacy+layered object animation refusal, pose animation allowance, explicit opt-in and/tmp/distinct-path guards before BPy import.
- Existing real Three185 inspection/morph regression plus new actual CPU-skinned/morphed reordered-mesh correspondence regression passes. Duplicate/empty names refuse. No WebGL/browser or resident model used.
- Actual installed Khronos validator was exercised on **scratch copies of the existing authored fixture**, one unchanged parented copy and one JSON-hierarchy-only root copy with BIN unchanged. Its receipt resolves the expected parented warning `/nodes/59`, node c4d_fixture_lod0, mesh0, skin0, parent60; root copy has0warnings/0errors. These are only validator-helper regression fixtures, not newly exported resident evidence or an app fixture change. Receipt: validator-unit-fixtures/receipt.jsonl.
- JS syntax, proposed workflow YAML and new shell step syntax pass; full combined patch apply-check passes against frozen45 checkout. No actual BPy/export/controlled-resident comparison has run.

Required adoption proof is the next pinned worker's actual source/control validator pointers and strict decoded surface receipts, then unchanged source/published gait/camera gates. Hierarchy warning removal does not establish anatomy, clothing fit, photographic appearance, likeness, biological motion or period accuracy.

## Corrected workflow ownership and persisted provenance

The first draft incorrectly replaced both jobs' `Install Playwright` anchors. The corrected combined patch scopes insertion strictly after the `teamster-studies:` boundary; legacy `humans` parsed job must equal its baseline exactly. Four parsed YAML tests in test_workflow_ownership.py verify exactly one teamster control step and zero elsewhere; production-before-control-before-Playwright order; isolated control frame-evidence environment; three control pairs and one validator step. All pass. The generator contains the core ownership assertions as well. New shell steps and helper AST parse, and combined patch still applies to the current dirty hair/normals tree.

The clone helper now checks embedded provenance both before saving and **after reopening the saved control master** in the pinned worker. Its receipt records serialized_provenance_reloaded_and_equal only after exact JSON equality with the original source provenance and original-source SHA equality. This remains a proposed actual-CI proof; no local BPy run is claimed. It does not relabel or rewrite the embedded production master provenance to make the comparison pass.
