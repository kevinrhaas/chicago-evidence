from pathlib import Path
import difflib
repo=Path('/workspace/chicago');out=Path('/workspace/shared/resident-hierarchy-ci-proof');base='chicago/4d/tools/'
p=repo/'.github/workflows/chicago-4d-humans.yml';old=p.read_text();anchor='      - name: Install Playwright'
assert anchor in old
step='''      - name: Build same-new-master parented hierarchy controls (test artifacts only)
        working-directory: chicago/4d
        env:
          BLENDER_CACHE: /opt/blender-dl
          HUMAN_EXPORT_EVIDENCE_DIR: /tmp/teamster-studies/hierarchy-controls/frame-evidence
        run: |
          set -euo pipefail
          source generators/blender.pin
          for variant in bardwell_otis_1835 dufresne_joseph_1835 flynn_martin_1835; do
            control="/tmp/teamster-studies/hierarchy-controls/$variant"
            mkdir -p "$control/raw"
            "$BLENDER_CACHE/$BLENDER_DIR/blender" -b -noaudio --factory-startup --python-exit-code 1 \\
              --python tools/human_hierarchy_control.py -- --test-only-parented-control \\
              --source "assets/authored/humans/teamsters/$variant/canonical.blend" \\
              --output "$control/control.blend" --receipt "$control/control-receipt.json" \\
              2>&1 | tee "$control/clone.log"
            "$BLENDER_CACHE/$BLENDER_DIR/blender" -b -noaudio "$control/control.blend" --python-exit-code 1 \\
              --python tools/human_export.py -- "$control/raw" 2>&1 | tee "$control/export.log"
            python3 tools/human_skin_canonicalize.py "$control/raw/$variant.lod0.glb" \\
              "$control/$variant.lod0.glb" --diagnostics "$control/skin-diagnostics.json"
          done
'''
boundary=old.index('  teamster-studies:')
assert old[boundary:].count(anchor)==1
new=old[:boundary]+old[boundary:].replace(anchor,step+anchor,1)
anchor='      - name: Measure all human exports and inspect the workwear studies'
validator='''      - name: Validate hierarchy control warnings with exact node pointers
        working-directory: chicago/4d
        run: |
          set -euo pipefail
          NODE_PATH="$(npm root -g)" node tools/validate_hierarchy_controls.mjs \\
            /tmp/teamster-studies/hierarchy-controls/bardwell_otis_1835/bardwell_otis_1835.lod0.glb assets/humans/bardwell_otis_1835.lod0.glb \\
            /tmp/teamster-studies/hierarchy-controls/dufresne_joseph_1835/dufresne_joseph_1835.lod0.glb assets/humans/dufresne_joseph_1835.lod0.glb \\
            /tmp/teamster-studies/hierarchy-controls/flynn_martin_1835/flynn_martin_1835.lod0.glb assets/humans/flynn_martin_1835.lod0.glb \\
            | tee /tmp/teamster-studies/hierarchy-controls/validator-pointers.jsonl
'''
assert anchor in new;new=new.replace(anchor,validator+anchor)
needle='--frame-samples 21 \\'
assert needle in new
pairs='''--frame-samples 21 \\
            --frame-pair /tmp/teamster-studies/hierarchy-controls/bardwell_otis_1835/bardwell_otis_1835.lod0.glb assets/humans/bardwell_otis_1835.lod0.glb \\
            --frame-pair /tmp/teamster-studies/hierarchy-controls/dufresne_joseph_1835/dufresne_joseph_1835.lod0.glb assets/humans/dufresne_joseph_1835.lod0.glb \\
            --frame-pair /tmp/teamster-studies/hierarchy-controls/flynn_martin_1835/flynn_martin_1835.lod0.glb assets/humans/flynn_martin_1835.lod0.glb \\'''
new=new.replace(needle,pairs)
import yaml
before_yaml=yaml.safe_load(old);after_yaml=yaml.safe_load(new)
assert after_yaml['jobs']['humans']==before_yaml['jobs']['humans']
name='Build same-new-master parented hierarchy controls (test artifacts only)'
assert sum(s.get('name')==name for s in after_yaml['jobs']['teamster-studies']['steps'])==1
assert sum(s.get('name')==name for s in after_yaml['jobs']['humans']['steps'])==0
control=next(s for s in after_yaml['jobs']['teamster-studies']['steps'] if s.get('name')==name)
assert control['env']['HUMAN_EXPORT_EVIDENCE_DIR']=='/tmp/teamster-studies/hierarchy-controls/frame-evidence'
(out/'workflow.proposed.yml').write_text(new)
# Production root meshes; hair patch should continue to use the same object_mesh helper.
p=repo/(base+'human_teamster_blend.py');builderold=p.read_text();buildernew=builderold.replace('        obj.parent = rig\n        mod =', '        # Authored identity mesh is a root; skin modifier references the rig.\n        mod =')
assert buildernew!=builderold
# Concise actual comparison summaries; unchanged0.1mm default remains authoritative.
p=repo/(base+'human_teamster.mjs');runnerold=p.read_text();runnernew=runnerold.replace('report.frame_repair_comparisons.push(result);',"report.frame_repair_comparisons.push(result);console.log(JSON.stringify({scope:'actual explicitly supplied GLB CPU surface comparison; not old-artifact or photographic proof',inputs:result.inputs,mesh_correspondence:result.mesh_correspondence,samples_per_clip:result.samples_per_clip,rest_maximum_vertex_delta_m:result.rest_maximum_vertex_delta_m,maximum_vertex_delta_m:result.maximum_vertex_delta_m,named_morph_maximum_vertex_delta_m:result.morph_samples.maximum_vertex_delta_m,tolerance_m:result.tolerance_m,passed:result.passed}));")
assert runnernew!=runnerold
checkp=repo/(base+'check.sh');checkold=checkp.read_text();anchor='step "Portable human contract holds; every human GLB and instance is held to it (T-1786)"';assert anchor in checkold
checknew=checkold.replace(anchor,'step "Hierarchy control refuses nonidentity frames and object animation before mutation" \\'+"\n"+'  python3 tools/test_human_hierarchy_control.py'+"\n\n"+anchor)
files=[('.github/workflows/chicago-4d-humans.yml',old,new),(base+'human_teamster_blend.py',builderold,buildernew),(base+'human_teamster.mjs',runnerold,runnernew),(base+'check.sh',checkold,checknew)]
for name in ['human_hierarchy_control.py','test_human_hierarchy_control.py','validate_hierarchy_controls.mjs']:files.append((base+name,'',(out/name).read_text()))
patch=[]
for name,a,b in files:patch.extend(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+name if a else '/dev/null',tofile='b/'+name))
(out/'workflow-control-REPO-ROOT.patch').write_text(''.join(patch))
