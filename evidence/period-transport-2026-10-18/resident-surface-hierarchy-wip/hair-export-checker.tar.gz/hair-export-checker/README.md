# Proposed actual exported hair checks

Outside-app review files only; current app unchanged. No Blender, new browser, actual human export, CI or photographic acceptance. Patches checked against current human files (base hashes in source-bases.json). Do not overwrite full proposed HTML over concurrent changes; review contextual patches.

## Patches

- `hair-contract-checker.proposed.patch`: adds Python embedded-container/image checker, actual loaded Three checker, their focused negative tests, and invokes the loaded checker from existing human_teamster.html inspect(). Existing master/web inspections already cover every resident/LOD on both viewports; new `checks.hair_export_contract` joins their existing failure reporting. It does not introduce an avatar runtime path.
- `workflow-owner-review.patch`: proposed owner-reviewed CI step after exports/time audit and before Khronos validation. Runs focused tests and all24 expected resident source/webLOD0..3 containers. Workflow remains unapplied. Missing files fail; no silent glob skip.
- `normal-preexport-audit.proposed.patch`: separate tiny builder insertion immediately after body custom normal setter, LOD0 only. Reads actual custom-normal existence/count/vectors, rejects missing/nonfinite or >1e-3 vector difference and prints resident mesh/count/max/mean. BPy execution pending. No claim about emitted GLB normals.

## What is actually checked

Python: exact one short04 material, MASK/.4/doubleSided, actual base-color TEXCOORD_0 binding, directly embedded PNG (no URI/JPEG), Pillow full image decode and alpha with both cutout/visible values; expected actual source/web dimensions; material used by actual skin-referencing drawable triangle primitives with NORMAL/UV/JOINTS/WEIGHTS accessor shapes/counts. Container check intentionally does NOT pretend to decode Meshopt geometry.

Three function runs on GLTFLoader's actual decoded SkinnedMeshes, after existing Meshopt loading: actual nonempty skin/skeleton, decoded geometry/index count, finite positions/normals/UVs, normalized nonnegative4weights and valid bone indices, normal unit length, UV bounds, actual material alphaTest=.4/DoubleSide and actual decoded image dimensions. Those are actual runtime contract assertions once CI executes; synthetic tests alone do not prove new exports. Existing Khronos, full human contract, deformation/animation and screenshot gates remain.

Normal magnitude tolerance.005, weight sum tolerance.002 and UV unit-range slack.0001 account for authored Meshopt quantization, not pointwise attribute equivalence. These bounds are recorded in the function; errors retain mesh/vertex details.

## Exact resize expectation from the existing pipeline

Source atlas must decode2048x2057 for every LOD. Existing human_export.sh caps web textures2048/1024/512/256, preserves alpha PNG via audited scratch labels, then Meshopt. No exemption or budget increase proposed.

Pinned glTF-Transform4.5.0 actual texture-compress.ts calls utils.ts fitWithin. Its sequential width-then-height flooring produces **webLOD0=2039x2048, LOD1=1020x1024, LOD2=510x512, LOD3=255x256** from2048x2057. A single nearest-aspect formula would yield different lower-LOD widths; checker uses the actual pinned implementation's results. Exact permitted source URLs/hashes in resize-source-receipts.json. Source files retained for outside audit, not copied into app code. Alpha image remains PNG and actually decodes with cutout/visible alpha. This verifies encoding/size, NOT preserved hairstyle appearance under Lanczos/mips/aniso.

Original source-padding arithmetic proves only unminified source-level bilinear equivalence. Resized web atlas, generated mipmaps, minification, actual alpha silhouette and close quality still require real renders. No source image edited by these tests.

## Focused tests and current evidence

`python proposal/tools/test_human_hair.py`:4 unittest methods including source actual embedded PNG and all4web sizes, plus refusals for opaque/wrongcutoff/notdouble-sided/external/JPEG/missing skin/missing weights/mismatchedcounts/unusedmaterial, wrongsize/allopaquealpha/corruptPNG. These use real syntheticGLB/PNG bytes, no mocked image headers. Geometry's actual loaded interpretation is covered separately.

`node proposal/tools/test_human_hair_runtime.mjs`:9 positive/negative decoded-object contracts including missing skin/weights, zero weights, out-of-range UV, zero normal, lost alpha, wrong image size and wrong sidedness. These are explicit synthetic Three-shaped fixtures, not disguised actual export evidence.

Syntax and all3 gitapply checks pass. Actual new source/web hair GLBs are not yet available; new canonical checks have NOT run against them.

## BPy normal audit and emitted-normal gap

Actual Blender4.5.3 mesh_normals.cc stores custom corner normals as short2, rounds normalized angular parameters by SHRT_MAX and treats near-auto normals within1e-4 as no-op. Therefore1e-6 float32-only readback equivalence is unjustified. Parent-approved1e-3 vector tolerance is a conservative engineering acceptance/reporting choice, NOT a proven codec worst-case bound. Audit actual per-residentLOD0 corner count and max/mean before modifiers/export; log scope explicitly local only. Actual APIs verified in official v4.5.3 RNA source, but audit never executed locally.

A reliable sourceLOD0 exported NORMAL correspondence needs the actual new GLB to establish exporter splitting, object/bone frame and skin canonicalization. Prepared source_vertex_indices are not emitted as attributes; nearest-position matching across frames or reordered/quantized Meshopt is not a sound proof. This proposal does not fabricate pointwise/crossLOD normal preservation. Actual canonical neck renders, rawLOD0 decoded-normal correspondence and decimated/morph normal behavior remain open. Generic finite/unit decoded normals are a useful corruption baseline only.
