# Authored skin/export repair proposal — not applied

All files here are outside the application. No Blender run, fixture-byte change or contract weakening was performed. The failed CI artifact remains inaccessible, so its precise source skin counts/palettes have not been observed; this diagnoses reproducible mechanisms and a guarded correction, not a claim to have inspected those missing files.

## Cause reproduced with the local fixture

`human_contract._skeleton_facts()` intentionally concatenates the ordered joint list of **every** skin. glTF Transform 4.5.0 `quantize.ts` clones a skin and adjusts its inverse bind matrices for each mesh's quantization offset/scale, then prunes unused originals and deduplicates equivalent corrected skins. Thus there are two distinct ways to trip the unchanged guard without renaming a bone:

1. Duplicate equivalent source skins: 2×56 ordered names become 1×56 after cleanup.
2. A source skin shared by meshes with different position bounds: default per-mesh quantization produces 2×56 corrected palettes from 1×56.

The CLI's documented `--quantization-volume scene` applies one quantization transform throughout the single-asset GLB. In the second repro it keeps exactly one corrected skin. It does not turn different actual source bindings into equal bindings, which is why strict source consolidation is a separate step.

`reproduction-results.json` compares the existing `_skeleton_facts` function unchanged. Both original repros fail its exact equality; strict equivalent-skin consolidation plus scene quantization passes exact equality. Relevant installed source: `functions/src/quantize.ts` transformMeshParents/transformSkin, cleanup around lines 185–199; `functions/src/dedup.ts` dedupSkins around lines 314–342. No joint-array reordering was observed in these tests.

## Proposed implementation

- `human_skin_canonicalize.py`: original standard-library-only module/CLI. Accepts an input GLB and a separate output path; canonical `.blend` and input bytes are not touched. Compares **actual ordered joint node IDs**, all skin metadata (including root/name/extras/extensions), and decoded float32 inverse-bind matrices exactly. Different accessor indices with exactly equal matrix values are equivalent. Missing inverse binds use glTF's identity default. Unsupported/sparse/external/non-finite bindings fail for inspection rather than being guessed.
- Equivalent skins consolidate to their first representative; mesh skin references remap to it. BIN bytes, geometry, weights, morphs, animations, node transforms and matrices are unchanged. Default mode requires a single resulting skin and refuses distinct palettes. Group mode is available to tests and never merges unequal bindings.
- `diagnostics(raw)` reports skin counts, ordered indices/names, actual inverse binds, node skin references and node-scale residuals. It reports the CI-style thigh scale residue without normalizing or concealing it. Root's canonical-rig/bone-scale correction remains a separate task.
- `human-export-authored-only.patch` updates only the authored `MODE=master` path: strict source-export consolidation before installing the source GLB, then `meshopt --quantization-volume scene` for its web derivative. The fixture/verify `cp` and Meshopt lines remain byte-for-byte unchanged. Install the module as `tools/human_skin_canonicalize.py` if applying the patch.

## Tests and limits

Eight meaningful unit tests pass: duplicate remapping with unchanged BIN/geometry/animations, equal matrix values through distinct accessor IDs, rejection of reordered joint palettes, rejection of same names on different actual nodes, rejection of changed inverse binds, rejection of differing metadata, group-mode preservation of distinct palettes, and scale diagnostics that leave transforms untouched. Tests synthesize inputs from the real fixture and do not depend on this session's scratch models.

Run outside the app:

```sh
TEST_HUMAN_FIXTURE=/workspace/chicago/chicago/4d/assets/humans/c4d_fixture.lod0.glb python /workspace/shared/human-export-repair/test_human_skin_canonicalize.py
```

After installation in `tools/`, the test defaults to `assets/humans/c4d_fixture.lod0.glb` relative to the project root.

Khronos validator results are in `khronos-validation.json`: **zero errors**, with two `NODE_SKINNED_MESH_NON_ROOT` warnings on each doubled toy (one per mesh). The unchanged original fixture already has one warning of that same kind. They are inherited fixture hierarchy warnings, not silently treated as zero warnings or caused by palette remapping. This proposal does not change hierarchy to hide them. Real CI exports need their own validation and browser/pose inspection when accessible.

Canonical source consolidation intentionally changes redundant exported skin metadata while preserving actual binding. It must not be used to merge different matrices or to pad a derivative with unused skins merely to satisfy the guard. Keep all existing frame, ordered-joint, skeleton, material, morph and provenance assertions intact.
