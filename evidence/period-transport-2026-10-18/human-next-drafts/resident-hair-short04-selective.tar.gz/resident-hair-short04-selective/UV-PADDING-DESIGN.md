# Source-preserving UV overflow draft

Original source Vmax=1.0031. Clamping to1 discards the periodic bottom-image samples used above the top edge. Wrapping each vertex separately would change interpolation across triangles. Neither is acceptable silently.

Draft: keep all source bytes intact. Create a derivative2048x2057RGBA image:8 rows copied from original bottom above the image;1 row copied from original top below it. Keep U unchanged, transform EVERY V with `(2048*V+1)/2057`. This affine mapping preserves triangle interpolation. Result Vrange [.0184073894,.9991972776], strictly inside0..1. No geometry, original UV or weights changed in this assessment. The8-row top gutter covers6.3488 pixels of source overflow plus the bilinear footprint.

`assess_uv_padding.py` verifies sourceSHA before processing, writes an explicitly named draft derivative, and compares source REPEAT to derivative CLAMP using pixel-center bilinear sampling. Both body meshes:991 authored UVs plus5000 deterministically seeded samples each; maximum error5.80e-11 in0..255RGBA units. This is arithmetic evidence for unminified bilinear equivalence, not GPU/export/mipmap validation. Image is CC0 source-derived; parser/arithmetic original.

Integration still requires actual glTF UV/texture orientation, packing and validation, and real mipmap/trilinear/anisotropic minification testing. A gutter adequate at base level may not preserve sampling with broad footprints or independently generated mipmaps. If that visibly differs, author per-level periodic padding/mips or use another verified compatible representation; do not call this complete from the base-level test. Clamp renderer sampling only after equivalence has been verified for its actual filter path. No app integration authorized or performed.
