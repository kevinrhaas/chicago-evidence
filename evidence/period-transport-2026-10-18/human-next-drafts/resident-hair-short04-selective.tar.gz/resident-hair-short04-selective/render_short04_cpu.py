"""CPU diagnostic alpha-card front/profile projection; not a GPU groom acceptance."""
import json,pathlib,math
from array import array
from PIL import Image,ImageDraw
P=pathlib.Path(__file__).parent;ROOT=pathlib.Path('/workspace/chicago/chicago/4d');skin=Image.open('/workspace/shared/human-source-candidates/skin-selected/skins/toigo_light_skin_male_bronze/young_lightskinned_male_diffuse_Bronze.png').convert('RGB');iris=Image.open('/workspace/shared/eye-quality-draft/original_iris.png');reports=[]
for age in [25,35]:
 body=json.loads((ROOT/f'assets/authored/humans/makehuman_hm08/prepared_adult_{age}.json').read_text());hair=json.loads((P/f'short04_fitted_adult{age}.json').read_text());eyes=json.loads(pathlib.Path(f'/workspace/shared/eye-quality-draft/eyes_adult{age}_lod0.json').read_text());texture=Image.open(P/hair['material']['texture']);tx=texture.load()
 for view in ['front','profile']:
  im=Image.new('RGB',(1000,1000),(225,228,224));draw=ImageDraw.Draw(im);visible=Image.new('L',im.size,0);vdraw=ImageDraw.Draw(visible);vp=visible.load();out=im.load();scalpmask=Image.new('L',im.size,0);sdraw=ImageDraw.Draw(scalpmask);polygons=[];zbuffer=array('f',[-float('inf')])*(1000*1000)
  def project(p):return (500+(p[0] if view=='front' else .045-p[2])*3300,940-(p[1]-1.49)*3300)
  for m in [*body['meshes'],*eyes['meshes'],hair['mesh']]:
   ishair=m['material']=='hair__makehuman_short04'
   if m['material']=='eyes__cornea':continue
   for face in m['triangles']:
    vs=[m['positions_m'][i] for i in face]
    if min(p[1] for p in vs)<1.49 or max(abs(p[0]) for p in vs)>.15:continue
    uv=[m['uvs'][i] for i in face];avg=[sum(p[j] for p in uv)/3 for j in [0,1]];mat=m['material']
    if not ishair:
     source=skin if mat=='skin' else iris if mat=='eyes__iris' else None
     if source:col=source.getpixel((min(source.width-1,max(0,int(avg[0]*(source.width-1)))),min(source.height-1,max(0,int((1-avg[1])*(source.height-1))))))
     elif mat=='eyes__sclera':col=(220,215,203)
     else:col=(2,2,2)
    else:col=None
    a,b,c=vs;u=[b[j]-a[j] for j in range(3)];v=[c[j]-a[j] for j in range(3)];n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];length=math.sqrt(sum(x*x for x in n)) or 1;light=(n[2] if view=='front' else n[0])/length;shade=.68+.32*(abs(light) if ishair else max(0,light));depth=sum(p[2 if view=='front' else 0] for p in vs)/3
    polygons.append((depth,[project(p) for p in vs],col,shade,uv,ishair,[p[2 if view=='front' else 0] for p in vs],mat))
  for depth,pts,col,shade,uv,ishair,depths,mat in polygons:
   (ax,ay),(bx,by),(cx,cy)=pts;den=(by-cy)*(ax-cx)+(cx-bx)*(ay-cy)
   if abs(den)<1e-10:continue
   for yy in range(max(0,int(min(ay,by,cy))),min(1000,int(max(ay,by,cy))+2)):
    for xx in range(max(0,int(min(ax,bx,cx))),min(1000,int(max(ax,bx,cx))+2)):
     a=((by-cy)*(xx+.5-cx)+(cx-bx)*(yy+.5-cy))/den;b=((cy-ay)*(xx+.5-cx)+(ax-cx)*(yy+.5-cy))/den;c=1-a-b
     if min(a,b,c)<-.00001:continue
     depth=a*depths[0]+b*depths[1]+c*depths[2];idx=yy*1000+xx
     if depth<=zbuffer[idx]:continue
     u=a*uv[0][0]+b*uv[1][0]+c*uv[2][0];v=a*uv[0][1]+b*uv[1][1]+c*uv[2][1]
     if ishair:
      color=tx[min(texture.width-1,max(0,round((u%1)*(texture.width-1)))),min(texture.height-1,max(0,round((1-(v%1))*(texture.height-1))))]
      if color[3]<102:continue
     else:
      source=skin if mat=='skin' else iris if mat=='eyes__iris' else None
      color=source.getpixel((min(source.width-1,max(0,round(u*(source.width-1)))),min(source.height-1,max(0,round((1-v)*(source.height-1)))))) if source else col
     out[xx,yy]=tuple(round(color[j]*shade) for j in range(3));vp[xx,yy]=255 if ishair else 0;zbuffer[idx]=depth
  sm=list(scalpmask.getdata());vm=list(visible.getdata());n=sum(bool(x) for x in sm);coverage=sum(bool(a and b) for a,b in zip(sm,vm))/n if n else None
  reports.append({'age':age,'view':view,'visible_hair_pixels':sum(bool(x) for x in vm),'front_facing_selected_scalp_projection_pixels':n,'hair_coverage_fraction_of_projection':coverage,'method':'CPU orthographic per-pixel barycentric zbuffer with alpha masking; not GPU/PBR/groom acceptance','hair_screen_bounds_px':visible.getbbox()});draw.text((20,15),f'Licensed MakeHuman short04 / actual prepared adult{age} / {view}',fill='black');draw.text((20,35),'Reconstructed appearance. CPU alpha-mask diagnostic; no photographic acceptance.',fill='black');im.save(P/f'short04-adult{age}-{view}.png')
(P/'short04-cpu-validation.json').write_text(json.dumps(reports,indent=2)+'\n');print(reports)
