"""Original source-preserving draft; no application changes or source overwrite."""
import pathlib,json,hashlib,math,random
from PIL import Image
P=pathlib.Path(__file__).parent
src=P/'selected/hair/short04/short04_diffuse.png'
assert hashlib.sha256(src.read_bytes()).hexdigest()=='0bef7fc0e403db5a40fabb2111ebfa6f7e8158e204c6e56b8da98e9ef527846e'
im=Image.open(src).convert('RGBA');w,h=im.size;top,bottom=8,1;hp=h+top+bottom
padded=Image.new('RGBA',(w,hp));padded.paste(im,(0,top));padded.paste(im.crop((0,h-top,w,h)),(0,0));padded.paste(im.crop((0,0,w,bottom)),(0,top+h))
out=P/'short04_diffuse_periodic_pad_draft.png';padded.save(out)
def bilinear(img,u,v,repeat):
 x=u*img.width-.5;y=(1-v)*img.height-.5;ix=math.floor(x);iy=math.floor(y);fx=x-ix;fy=y-iy
 def at(a,b):
  if repeat:a%=img.width;b%=img.height
  else:a=max(0,min(img.width-1,a));b=max(0,min(img.height-1,b))
  return img.getpixel((a,b))
 a,b,c,d=at(ix,iy),at(ix+1,iy),at(ix,iy+1),at(ix+1,iy+1)
 return [(1-fy)*((1-fx)*a[k]+fx*b[k])+fy*((1-fx)*c[k]+fx*d[k]) for k in range(4)]
reports=[];rng=random.Random(418)
for age in (25,35):
 data=json.loads((P/f'short04_fitted_adult{age}.json').read_text());uv=data['mesh']['uvs'];new=[[u,(h*v+bottom)/hp] for u,v in uv]
 samples=uv+[[rng.uniform(.0104,.9832),rng.uniform(.018,1.0031)] for _ in range(5000)]
 err=max(abs(a-b) for u,v in samples for a,b in zip(bilinear(im,u,v,True),bilinear(padded,u,(h*v+bottom)/hp,False)))
 assert max(max(row) for row in new)<=1 and min(min(row) for row in new)>=0 and err<1e-8
 reports.append({'age':age,'vertices':len(uv),'remapped_uv_bounds':[[min(t[k] for t in new),max(t[k] for t in new)] for k in (0,1)],'sample_count':len(samples),'max_RGBA_bilinear_error_0_255':err})
(P/'uv-padding-validation.json').write_text(json.dumps({'status':'outside-app draft; no integration','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'padded_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_size_px':[w,h],'padded_size_px':[w,hp],'top_periodic_rows':top,'bottom_periodic_rows':bottom,'transform':'u unchanged; v_new=(2048*v+1)/2057','sampling':'pixel-center bilinear RGBA, source REPEAT versus padded CLAMP; no mip/filter/export claim','reports':reports},indent=2)+'\n')
print(json.dumps(reports))
