"""Original elementary hm08 hair proxy adaptation; imports no MakeHuman code.

Geometry retains signed proxy barycentric extrapolation; only sums are normalized
for affine invariance at the source file's 5-decimal precision. This is an assessed
engineering derivative, not a reference-matched resident appearance.
"""
import pathlib,json,math,hashlib
P=pathlib.Path(__file__).parent;ROOT=pathlib.Path('/workspace/chicago/chicago/4d');asset=P/'selected/hair/short04';binding=json.loads((P/'short04-bindings.json').read_text());uvs=[];faces=[]
for line in (asset/'short04.obj').read_text().splitlines():
 f=line.split()
 if not f:continue
 if f[0]=='vt':uvs.append(list(map(float,f[1:3])))
 elif f[0]=='f':
  corners=[tuple(int(i)-1 for i in s.split('/')[:2]) for s in f[1:]]
  for k in range(1,len(corners)-1):faces.append([corners[0],corners[k],corners[k+1]])
reports=[]
for age in [25,35]:
 path=ROOT/f'assets/authored/humans/makehuman_hm08/prepared_adult_{age}.json';body=json.loads(path.read_text());m=body['meshes'][0];points={};skin={}
 for source,p,w in zip(m['source_vertex_indices'],m['positions_m'],m['weights']):
  if source in points:assert math.dist(points[source],p)<1e-10
  points[source]=p;skin[source]=w
 factors=[abs(points[binding['scales'][axis]['indices'][0]][a]-points[binding['scales'][axis]['indices'][1]][a])/binding['scales'][axis]['distance'] for a,axis in enumerate(['x','y','z'])]
 coords=[];weights=[];negative_weights=0;max_removed=0;rounding_delta=0;max_influences=0
 for row in binding['rows']:
  total=sum(row['barycentric']);bary=[w/total for w in row['barycentric']];p=[sum(w*points[i][a] for w,i in zip(bary,row['indices']))+row['offset_source'][a]*factors[a] for a in range(3)];literal=[sum(w*points[i][a] for w,i in zip(row['barycentric'],row['indices']))+row['offset_source'][a]*factors[a] for a in range(3)];rounding_delta=max(rounding_delta,math.dist(p,literal));coords.append(p);bone_weights={}
  for w,index in zip(bary,row['indices']):
   for bone,value in skin[index].items():bone_weights[bone]=bone_weights.get(bone,0)+w*value
  negative_weights+=any(w< -1e-9 for w in bone_weights.values());clamped={b:max(0,w) for b,w in bone_weights.items() if w>0};ordered=sorted(clamped.items(),key=lambda x:(-x[1],x[0]));max_influences=max(max_influences,len(ordered));max_removed=max(max_removed,sum(w for b,w in ordered[4:]));keep=dict(ordered[:4]);s=sum(keep.values());assert s>0;weights.append({b:w/s for b,w in keep.items()})
 split={};out=[];outuv=[];outweights=[];tris=[]
 for face in faces:
  ids=[]
  for v,t in face:
   if (v,t) not in split:split[v,t]=len(out);out.append(coords[v]);outuv.append(uvs[t]);outweights.append(weights[v])
   ids.append(split[v,t])
  tris.append(ids)
 data={'license':'CC0-1.0','source_asset':'MakeHuman system short04','source_uuid':'e09bfd91-f83f-4f9a-ba8c-4635cd1ae0d8','age_parameter':age,'status':'licensed source component fitted with original arithmetic; no groom/period/likeness/export acceptance','material':{'name':'hair__makehuman_short04','texture':'selected/hair/short04/short04_diffuse.png','base_color':[1,1,1,1],'roughness':.65,'alpha_mode':'MASK','alpha_cutoff':.4,'double_sided':True,'adaptation':'Original PBR approximation; source litsphere/aniso shader not ported or copied'},'mesh':{'name':'makehuman_short04_fitted','material':'hair__makehuman_short04','positions_m':out,'uvs':outuv,'weights':outweights,'triangles':tris},'body_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 (P/f'short04_fitted_adult{age}.json').write_text(json.dumps(data,separators=(',',':'))+'\n');reports.append({'age_parameter':age,'source_vertices':len(coords),'uv_split_vertices':len(out),'triangles':len(tris),'source_uv_bounds':[[min(v[a] for v in outuv),max(v[a] for v in outuv)] for a in [0,1]],'bounds_m':[[min(v[a] for v in out),max(v[a] for v in out)] for a in range(3)],'scale_m_per_source_unit':factors,'max_literal_vs_normalized_binding_displacement_m':rounding_delta,'negative_interpolated_skin_weight_rows':negative_weights,'max_interpolated_influences':max_influences,'max_weight_discarded_after_four_influences':max_removed,'skin_bones':sorted({b for w in outweights for b in w}),'unverified':['surface/ear collision','source shader to PBR response','all LODs','canonical Blender/glTF export','mobile/desktop hair-alpha behavior','photographic/period/individual appearance']})
(P/'fitting-validation.json').write_text(json.dumps(reports,indent=2)+'\n');print(json.dumps(reports,indent=2))
