# MakeHuman short04: licensed-source fitting study

Source-only assessment, 2026-10-18. No application assets changed; no Blender or MakeHuman program executed. This is a candidate for reconstructed resident appearance, not evidence of any resident's hair or an accepted 1835 hairstyle.

## Source and rights

Official website repository: makehumancommunity/makehuman-static-website, pinned commit `883f19ca188e1cb458f2907d6f0c81187b9cf7da`. Downloaded pages and thumbnails have exact URLs and SHA-256 in `page-receipts.json` and `thumbnail-receipts.json`. Official system-asset listing identifies short04's author as `makehuman_system` and its license as CC0.

Actual archive: https://files2.makehumancommunity.org/asset_packs/makehuman_system_assets/makehuman_system_assets_cc0.zip , 280,737,770 bytes, ETag `"10bbb7ea-6160e7c0d7996"`. Only central-directory metadata and selected entry ranges were downloaded, not the full archive. Each response must be HTTP206 with exact range, total size and ETag; decompressed bytes must match ZIP CRC and size. `selected-receipts.json` and `short04-texture-receipt.json` retain hashes.

The actual short04 OBJ, mhclo and mhmat EACH explicitly say this asset was released as CC0 in September2020. They list copyright holders Data Collection AB (https://www.datacollection.se), Joel Palmius and Jonas Hauquier; primary legal contact Data Collection AB. No specific original individual creator is supplied. Preserve those credits and original files on ingestion. Asset UUID `e09bfd91-f83f-4f9a-ba8c-4635cd1ae0d8`, basemesh `hm08`. The referenced CC0 text is not a separate entry in this archive; do not claim it was extracted. The explicit asset headers and official per-asset license entry are retained.

The material directly references `short04_diffuse.png`; the PNG has no separate license declaration or discovered exception. Its use is supported by the explicitly CC0 asset material that names it and official CC0 system asset listing. Actual selected texture: 2048x2048 RGBA, 2,308,132 PNG bytes, SHA-256 `0bef7fc0e403db5a40fabb2111ebfa6f7e8158e204c6e56b8da98e9ef527846e`. Decoded cost 16,777,216 bytes before mipmaps. Texture depicts authored shaded strands, not measured period hair or proof of photographic quality.

Original source material uses legacy litsphere shader/reflectance behavior. No MakeHuman AGPL shader/program code is copied or required by these original parsers. Proposed PBR roughness .65, alpha MASK cutoff .4 and double-sided rendering are explicit reconstruction choices, not a faithful verified shader conversion.

## Actual compatibility and fit

`reference-coverage.json`: all 865 mhclo binding rows, all 613 distinct referenced body vertices and all six scale anchors resolve through BOTH adult25 and adult35 prepared bodies' source_vertex_indices. Zero missing references; zero disagreement among UV-seam duplicates. No invented helper coordinates are needed.

`fit_short04.py` is an original format parser/fitter. Each vertex is the signed barycentric sum of actual prepared body positions plus source offsets scaled by the actual x/y/z anchor distances divided by source declared lengths. Forty rows use legal negative geometric coefficients; these are retained, not clamped. Tiny source rounding sum errors are normalized for affine invariance (maximum position change versus literal sum .017501mm). Source head/torso coordinates were retained through limb A-to-T preparation.

Existing body skinweights are interpolated separately, negative weights clamped and normalized; one row needs this treatment. Up to four influences remain, zero additional weight mass dropped by the four-weight limit. Neck/clavicle/spine/jaw influences are retained rather than assigning the whole nape rigidly to head. Animated deformation has NOT been exercised.

Source mesh has865 positions,991 UV coordinates,525 quads. Original triangulation and UV-seam splitting produce991 vertices/1050triangles per fitted component, one proposed material/draw. `short04_fitted_adult25.json` and `short04_fitted_adult35.json` contain the actual geometry, UVs and weights; `fitting-validation.json` contains dimensions and body hashes. The adult25 fitted bounds are X[-.077061,.078310], Y[1.543358,1.753516], Z[-.074317,.123516] metres.

IMPORTANT integration issue: source UV V reaches1.0031. These drafts preserve repeat sampling. Do not silently clamp or claim the existing 0..1 human UV contract passes. A future explicitly validated periodic padded-atlas remap or a justified contract-compatible solution is required. No texture/UV alteration has been applied here.

## Viewed CPU diagnostics

`render_short04_cpu.py` renders real fitted hair and actual prepared head with the licensed skin atlas. It uses original CPU triangle z-buffer, source texture repeat and alpha MASK. The separate unapplied original eye proposal is shown only for context. These are not canonical Blender/glTF or renderer acceptance screenshots.

Viewed adult25 front and profile: substantially more coherent coverage and strand flow than the rejected original ribbon groom; ear is exposed, sideburn and swept hairline are legible. Profile shows polygonal crown outline and several long nape strands. Actual skin/head topology remains visibly faceted. No numeric scalp coverage percentage is invented; no independently authored target scalp mask exists for this source style. Adult35 images are supplied but do not establish a distinct individual appearance.

## Open gates before integration/acceptance

- Parent's first canonical human CI artifact review; no source/app integration yet.
- Resolve UV overflow without changing source appearance silently.
- Real ear/scalp/collar triangle collision and nape fit; CPU images alone are insufficient.
- Head/neck/jaw deformation and all facial morphs, especially eyelids; interpolated weights are a prototype.
- Actual Blender packing/export, normal/tangent handling, glTF material/alpha, mobile/desktop behavior and lighting.
- LODs, aggregate person budgets, source attribution ledger and deterministic ingestion.
- Historical hairstyle and grooming acceptance, photographic quality and distinct reconstructed resident faces remain open. Hair fitting does not close these.

Candidate files are frozen for parent review. Retrieval scripts are bounded range fetchers; transient503 was resolved by smaller validated chunks, never by skipping validation or downloading the full archive.
