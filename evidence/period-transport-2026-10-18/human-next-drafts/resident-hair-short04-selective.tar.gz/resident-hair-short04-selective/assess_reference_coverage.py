"""Original parser/coverage audit; no MakeHuman program code imported/copied."""
import json,pathlib,math,hashlib
P=pathlib.Path(__file__).parent;ROOT=pathlib.Path('/workspace/chicago/chicago/4d');reports=[]
for name in ['short01','short02','short04']:
 folder=P/'selected/hair'/name;path=folder/(name+'.mhclo');rows=[];scales={};uuid=None;basemesh=None;active=False
 for line in path.read_text().splitlines():
  fields=line.split()
  if not fields or fields[0].startswith('#'):continue
  if fields[0]=='uuid':uuid=fields[1]
  elif fields[0]=='basemesh':basemesh=fields[1]
  elif fields[0] in ['x_scale','y_scale','z_scale']:scales[fields[0][0]]={'indices':list(map(int,fields[1:3])),'distance':float(fields[3])}
  elif fields[0]=='verts':active=True
  elif active and len(fields)==9:
   try:rows.append({'indices':list(map(int,fields[:3])),'barycentric':list(map(float,fields[3:6])),'offset_source':list(map(float,fields[6:]))})
   except ValueError:active=False
 refs={i for row in rows for i in row['indices']};scale_refs={i for cfg in scales.values() for i in cfg['indices']};obj=(folder/(name+'.obj')).read_text();vertex_count=sum(line.startswith('v ') for line in obj.splitlines());assert len(rows)==vertex_count
 for age in [25,35]:
  bodypath=ROOT/f'assets/authored/humans/makehuman_hm08/prepared_adult_{age}.json';d=json.loads(bodypath.read_text());m=d['meshes'][0];mp={};weights={};error=0
  for source,p,w in zip(m['source_vertex_indices'],m['positions_m'],m['weights']):
   if source in mp:error=max(error,math.dist(p,mp[source]))
   else:mp[source]=p;weights[source]=w
  scales_metric={axis:abs(mp[cfg['indices'][0]][i]-mp[cfg['indices'][1]][i])/cfg['distance'] for i,axis in enumerate(['x','y','z']) for cfg in [scales[axis]]}
  reports.append({'asset':name,'uuid':uuid,'basemesh':basemesh,'age_parameter':age,'proxy_vertex_bindings':len(rows),'distinct_geometry_reference_indices':len(refs),'missing_geometry_references':sorted(refs-set(mp)),'scale_reference_indices':sorted(scale_refs),'missing_scale_references':sorted(scale_refs-set(mp)),'uv_duplicate_position_disagreement_max_m':error,'negative_barycentric_binding_rows':sum(min(r['barycentric'])<0 for r in rows),'barycentric_sum_error_max':max(abs(sum(r['barycentric'])-1) for r in rows),'offset_metric_scale_m_per_source_unit':scales_metric,'source_head_weight_range_at_refs':[min(weights[i].get('head',0) for i in refs),max(weights[i].get('head',0) for i in refs)],'body_sha256':hashlib.sha256(bodypath.read_bytes()).hexdigest(),'feasibility':'all body and scale references available; no missing helper coordinates invented; offsets/pose/weight adaptation still requires quantitative validation'})
 (P/(name+'-bindings.json')).write_text(json.dumps({'rows':rows,'scales':scales},separators=(',',':'))+'\n')
(P/'reference-coverage.json').write_text(json.dumps(reports,indent=2)+'\n');print(json.dumps([r for r in reports if r['asset']=='short04'],indent=2))
