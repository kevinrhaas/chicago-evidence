# SPDX-License-Identifier: GPL-3.0-or-later
"""Original, provisional source-weight-localized blink study; never edits app data."""
import collections,json,math,pathlib,statistics
ROOT=pathlib.Path('/workspace/chicago/chicago/4d/assets/authored/humans/makehuman_hm08');OUT=pathlib.Path(__file__).parent
RADIUS=.012;MAX_DISPLACEMENT=.008

def add(a,b):return [x+y for x,y in zip(a,b)]
def sub(a,b):return [x-y for x,y in zip(a,b)]
def mul(a,s):return [x*s for x in a]
def dot(a,b):return math.fsum(x*y for x,y in zip(a,b))
def length(a):return math.sqrt(dot(a,a))
def unit(a):return mul(a,1/length(a))
def cross(a,b):return[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def clamp(x):return max(0,min(1,x))
def smooth(x):x=clamp(x);return x*x*(3-2*x)

def triangle_distance(point,a,b,c):
 # Closest point over face plane and all three segments; projection is accepted
 # only for barycentric coordinates inside the triangle.
 ab,ac=sub(b,a),sub(c,a);n=cross(ab,ac);n2=dot(n,n);best=min(length(sub(point,v))for v in[a,b,c])
 for x,y in[(a,b),(b,c),(c,a)]:
  edge=sub(y,x);den=dot(edge,edge)
  if den:best=min(best,length(sub(point,add(x,mul(edge,clamp(dot(sub(point,x),edge)/den))))))
 if n2>1e-24:
  projected=sub(point,mul(n,dot(sub(point,a),n)/n2));ap=sub(projected,a);d00,d01,d11=dot(ab,ab),dot(ab,ac),dot(ac,ac);den=d00*d11-d01*d01
  if abs(den)>1e-24:
   v=(d11*dot(ap,ab)-d01*dot(ap,ac))/den;w=(d00*dot(ap,ac)-d01*dot(ap,ab))/den
   if v>=0 and w>=0 and v+w<=1:best=min(best,length(sub(point,projected)))
 return best

def triangle_diagnostics(mesh,deltas,center):
 touched={i for i,d in enumerate(deltas)if length(d)>1e-8};before=[];after=[];inversions=0;max_turn=0;minimum_area_ratio=1
 for face in mesh['triangles']:
  if not any(i in touched for i in face):continue
  a,b,c=[mesh['positions_m'][i]for i in face];aa,bb,cc=[add(mesh['positions_m'][i],deltas[i])for i in face];n=cross(sub(b,a),sub(c,a));nn=cross(sub(bb,aa),sub(cc,aa));area,area_new=length(n),length(nn)
  if dot(n,nn)<0:inversions+=1
  if area>1e-15:minimum_area_ratio=min(minimum_area_ratio,area_new/area)
  if area*area_new>1e-20:max_turn=max(max_turn,math.degrees(math.acos(max(-1,min(1,dot(n,nn)/(area*area_new))))))
  before.append(triangle_distance(center,a,b,c)-RADIUS);after.append(triangle_distance(center,aa,bb,cc)-RADIUS)
 return{'affected_triangles':len(before),'orientation_reversals':inversions,'maximum_normal_turn_deg':max_turn,'minimum_area_ratio':minimum_area_ratio,'minimum_triangle_globe_margin_before_m':min(before),'minimum_triangle_globe_margin_after_m':min(after),'triangle_globe_intersection_count_before':sum(x<0 for x in before),'triangle_globe_intersection_count_after':sum(x<0 for x in after),'scope':'static bodytriangles touching modifiedvertices versus reconstructed12mm sphere; not cornea geometry, blinkclosure or posedskin contact acceptance'}

def propose(body,source_weights,side):
 mesh=body['meshes'][0];eye=next(b for b in body['skeleton']if b['name']=='eye_'+side);center=eye['head_m'];forward=unit(sub(eye['tail_m'],center));right=unit(cross([0,1,0],forward));up=unit(cross(forward,right));upper=dict(source_weights['orbicularis03.'+side.upper()]);lower=dict(source_weights['orbicularis04.'+side.upper()]);deltas=[];affected=[];old=[];rows=[]
 for out_index,(p,source_index)in enumerate(zip(mesh['positions_m'],mesh['source_vertex_indices'])):
  relative=sub(p,center);u,v,w=dot(relative,right),dot(relative,up),dot(relative,forward);source_strength=max(upper.get(source_index,0),lower.get(source_index,0));d=[0,0,0]
  if abs(p[0]-center[0])<.035 and abs(p[1]-center[1])<.023 and abs(p[2]-center[2])<.045:old.append(out_index)
  # Weighted facial region excludes broad oculi/forehead muscles. Envelope follows
  # the reconstructed globe dimensions, not a fabricated source eye-hole loop.
  if source_strength>.04 and abs(u)<RADIUS*1.8 and abs(v)<RADIUS*1.25 and .001<w<RADIUS*2.1:
   muscle=smooth((source_strength-.04)/.66);lateral=1-smooth((abs(u)-RADIUS*.55)/(RADIUS*1.25));vertical=1-smooth((abs(v)-RADIUS*.8)/(RADIUS*.45));influence=muscle*lateral*vertical
   destination=add(p,mul(up,-v*influence))
   # Avoid creating a new point penetration at the globe-facing surface where
   # the vertex is within the central globe disk; this is only a vertex check.
   du,dv=dot(sub(destination,center),right),dot(sub(destination,center),up)
   if du*du+dv*dv<RADIUS*RADIUS:
    min_depth=math.sqrt(RADIUS*RADIUS-du*du-dv*dv)+.0006
    if w<min_depth:destination=add(destination,mul(forward,(min_depth-w)*influence))
   d=sub(destination,p);n=length(d)
   if n>MAX_DISPLACEMENT:d=mul(d,MAX_DISPLACEMENT/n)
   if length(d)>1e-8:
    affected.append(out_index);rows.append({'output_index':out_index,'source_index':source_index,'muscle_weight':source_strength,'eye_frame_m':[u,v,w],'displacement_m':length(d),'globe_margin_before_m':length(relative)-RADIUS,'globe_margin_after_m':length(sub(add(p,d),center))-RADIUS})
  deltas.append(d)
 unique={mesh['source_vertex_indices'][i]for i in affected};seams=collections.defaultdict(list)
 for i in affected:seams[mesh['source_vertex_indices'][i]].append(deltas[i])
 seam_error=max((length(sub(v,values[0]))for values in seams.values()for v in values),default=0)
 return deltas,{'triangle_diagnostics':triangle_diagnostics(mesh,deltas,center),'affected_uv_split_vertices':len(affected),'affected_unique_source_vertices':len(unique),'original_box_mask_vertices':len(old),'old_box_mask_max_displacement_m':max((abs(mesh['positions_m'][i][1]-center[1])*.92 for i in old),default=0),'max_displacement_m':max((r['displacement_m']for r in rows),default=0),'mean_displacement_m':statistics.mean(r['displacement_m']for r in rows)if rows else 0,'minimum_selected_vertex_globe_margin_before_m':min((r['globe_margin_before_m']for r in rows),default=0),'minimum_selected_vertex_globe_margin_after_m':min((r['globe_margin_after_m']for r in rows),default=0),'uv_seam_delta_error_m':seam_error,'affected_rows':rows,'frame':{'center_m':center,'forward':forward,'up':up,'right':right},'gates_open':['eyelid closure and canthus preservation','lid/globe triangle clearance and corneal contact','temporal shape quality and skinning interaction','actual Blender and exported GLB renders','photographic or anatomical acceptance']}

def topology(body):
 m=body['meshes'][0];edge=collections.Counter();adj=collections.defaultdict(set)
 for tri in m['triangles']:
  a,b,c=[m['source_vertex_indices'][i]for i in tri]
  for x,y in[(a,b),(b,c),(c,a)]:edge[tuple(sorted((x,y)))]+=1;adj[x].add(y);adj[y].add(x)
 visited=set();components=[]
 for seed in adj:
  if seed in visited:continue
  todo=[seed];visited.add(seed);count=0
  while todo:
   x=todo.pop();count+=1
   for y in adj[x]-visited:visited.add(y);todo.append(y)
  components.append(count)
 return{'method':'UV-seam split vertices welded by exact original hm08 source vertex index; triangle edge incidence counted','vertices':len(adj),'edges':len(edge),'triangles':len(m['triangles']),'boundary_edges':sum(n==1 for n in edge.values()),'nonmanifold_edges':sum(n>2 for n in edge.values()),'connected_component_vertex_counts':components,'eye_aperture_boundary_loops':'none: the actual source body is a single closed surface; a visible aperture/cavity must not be called an open mesh boundary'}

if __name__=='__main__':
 weights=json.loads((ROOT/'makehuman/data/rigs/default_weights.mhw').read_text())['weights'];report={'status':'outside-app CPU proposal; not applied, exported, or accepted','globe_radius_m':RADIUS,'globe_center':'actual prepared eye head','globe_axis':'actual normalized eye tail-head','maximum_allowed_displacement_m':MAX_DISPLACEMENT,'source_weight_basis':'Actual CC0 default_weights.mhw orbicularis03/04 left/right muscle groups; broad oculi groups deliberately excluded','ages':{}}
 for age in[25,35]:
  body=json.loads((ROOT/f'prepared_adult_{age}.json').read_text());result={'topology':topology(body),'eyes':{}};morphs={}
  for side,label in [('l','eyeBlinkLeft'),('r','eyeBlinkRight')]:morphs[label],result['eyes'][side]=propose(body,weights,side)
  (OUT/f'blink-deltas-adult{age}.json').write_text(json.dumps({'status':'engineering proposal only','units':'m','mesh':'body','source_vertex_indices':body['meshes'][0]['source_vertex_indices'],'morph_deltas':morphs},separators=(',',':'))+'\n');report['ages'][str(age)]=result
 (OUT/'diagnostics.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({age:{'topology':v['topology'],'eyes':{s:{k:r[k]for k in['affected_uv_split_vertices','affected_unique_source_vertices','original_box_mask_vertices','max_displacement_m','minimum_selected_vertex_globe_margin_after_m','uv_seam_delta_error_m']}for s,r in v['eyes'].items()}}for age,v in report['ages'].items()},indent=2))
