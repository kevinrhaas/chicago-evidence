# Source-weight-localized partial blink study — not applied

Original CPU-only code and engineering proposals. No MakeHuman program code is imported or copied, no Blender executes, and no application files change. Inputs are the actual prepared adult25/adult35 body topology, source vertex correspondence and verified CC0 default rig/weights.

The actual body, after welding UV splits by their original source vertex index, is one closed13,380-vertex/26,756-triangle manifold with40,134edges and **zero boundary edges**. There are no open eye-hole boundary loops to extract. A visible eye aperture/cavity does not imply a topological hole. Any loop extracted from muscle-weight thresholds is a semantic region border, not an actual mesh boundary.

Source `orbicularis03.L/R` and `orbicularis04.L/R` weights identify a tighter upper/lower eye region. Broad `oculi01` weights extend into forehead/side-head and are excluded. A smooth bounded spatial envelope uses the actual eye-head/eye-tail frame and the eye draft's reconstructed12mm **radius** (24mm diameter) globe. No radius is presented as a helper measurement. Source UV duplicates receive exactly equal deltas.

The existing box mask affects754–756 UV-split vertices per eye, with approximately21mm movement. The muscle-localized proposal affects285 UV-split/264 original vertices per eye. Initial8mm-capped displacement still reverses12 triangle orientations, so it is **not recommended for application**. See `diagnostics.json` and `strength-diagnostics.json`, which preserve this failed proposal rather than hiding it.

A half-strength **partial** study is saved in `partial-blink-adult25.json` and `partial-blink-adult35.json`: max movement4mm. CPU tests at ten weights0.1–1.0 on each eye/age find no orientation reversal or reconstructed-globe sphere intersection in modified triangles. Minimum triangle-to-sphere margin is approximately0.20mm; minimum triangle-area ratio is approximately0.21. These are narrow static-mesh diagnostics, not anatomical, posed-skin or photorealistic acceptance. The separate cornealcap is untested; globe-sphere clearance does not cover its extra anterior projection.

For comparison, applying the current builder's exact box formula to the same prepared body against the reconstructed12mm globe causes7–8 orientation reversals and251–255 sphere-intersecting triangles per eye. This does not replace actual exported-renders evidence, but it demonstrates why an amplitude-only morph gate is insufficient.

Next work requires actual CI close renders and inspecting upper/lower lid contour, canthi, lashes, cornea and blink timing through skinned poses. Full closure is **not established** by this partial proposal. A true closed-lid target needs anatomical lid-surface authoring, volume preservation and contact validation. Do not claim photographic eyelids or reinterpret source face-muscle weights as a source-authenticated blink clip.
