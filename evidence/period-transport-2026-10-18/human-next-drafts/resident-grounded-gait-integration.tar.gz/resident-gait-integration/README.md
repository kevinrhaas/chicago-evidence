# Grounded gait integration patch — review only

Prepared2026-10-18 against **human commit `0577792dc5b4107fcf4aeab0014d0b9fb3f44ab6`**. Current checkout was on the transport merge and did not contain this builder; source was read with `git show`, not recreated from memory. All work stays outside app. No local Blender/bpy import, app edit, actual export, browser or publication.

`grounded-gait-integration.patch` changes four paths when deliberately applied to the human branch:

- `tools/human_teamster_blend.py`: motion integration only;
- new `tools/human_grounded_gait.py`: pure mechanical source-frame solver and explicit Action interpolation helper;
- new `tools/measure_grounded_sampling.py`: actual prepared-source sole/skin contact evaluator;
- new `tools/test_human_grounded_gait.py`: portable unittest with actual prepared25/35 fixtures selected from project paths or `C4D_GAIT_BODY_DIRECTORY`.

Patch dry-run succeeded against an isolated temporary copy of the exact frozen source; see `patch-dry-run.txt`. No attempt was made to apply it blindly onto the different current app checkout. This patch does not modify check.sh/workflows; root can add the focused unittest to the gate after review.

## Authored motion change

Walk becomes **37inclusive keys**, frames1through37 at30fps, **1.2s**, speed metadata**0.6m/s**. Explicit original engineering values:62%stance,65mmswing lift, pelvis lowering40±5mm. All lower-limb angles come from actual prepared hip/knee/ankle heads and lengths. Reach failures are rejected; no scale/stretch is introduced. Forward knee branch and ankle counter-rotation produce a flat supported sole. It remains a slow flat-foot mechanical study, not biological/photographic gait or a resident's measured walk.

Original upper-body behavior is preserved: upperarm lowering±78° about original authoring worldY, and spine_02 sway0.6°×sin(phase). Idle retains its original13keys over2s. Every pose location is zeroed before each key; walking pelvis receives its converted translation. Locations are keyed in both idle/walk, so an idle crossfade clears walking pelvis displacement. After authoring, action is detached and **all pose locations plus rotations are reset** before saving rest master.

Rotation conversion follows actual original builder: `rest_basis.inverted() @ world_axis_increment @ rest_basis`. The helper's lower-limb increments are source+X rotations (unchanged by sourceY-up→BlenderZ-up conversion). Pelvis delta is already in **scaled metres**, so it is converted to Blender `(dx,-dz,dy)` then into the actual pelvis rest basis using inverse quaternion. Calling the builder's `xyz()` would apply height_scale again and is deliberately avoided. Parent root has identity pose; this is an incremental pelvis translation under that authored setup, not a universal rule for arbitrary constrained rigs.

`linearize_action` sets every authored keypoint to **LINEAR**, handling both legacy Actionfcurves and Blender4.5layer/strip/channelbag collections. It raises if no curves are accessible, rather than silently leaving BEZIER defaults. This traversal matches the actual frozen exporter's existing layered-curve inspection pattern. A duck-typed test exercises both collections, but **actual4.5BPyexecution remains pendingCI**.

##1001-phase measurements including actual37-key sampling

`sampling-comparison.json` contains both dense solver evaluation and a separate**30fpskey sampling model**: quaternion shortest-pathSLERP for each channel and LINEARpelvis translation. Because every lower-limb quaternion is a conjugate of a rotation about the same fixed axis and adjacent angles differ by<π, its SLERP is mathematically equivalent to interpolating that incremental angle. This invariant is checked. Forward kinematics and LBS are then recomputed from the actual prepared source rig and exact shoe-sole vertices/weights at1001phases. Root travel is0.6×time, and planted drift is grouped by unwrapped supportcycle, not across different footsteps.

|37key model,1001phases|Otis prepared25|Joseph prepared35|
|---|---:|---:|
|Maximum planted sole world drift|**0.3362mm**|**0.3356mm**|
|Maximum supported sole height error|**0.2639mm**|**0.2630mm**|
|Minimum sole height|**−0.2211mm**|**−0.2219mm**|
|Maximum ankle trajectory residual(all phases)|2.8467mm|2.8538mm|
|Phases with no designated support|0|0|
|In-place sole loop closure|0m|0m|
|Minimum forward knee-pole deviation|54.16mm|53.98mm|

Dense solver contacts are near floating-point zero. **They are not used as a substitute for sampled-key results** above. Thirty-fpsinterpolation produces measurable small contact/trajectory error and that error remains disclosed. Phase sampling is not a continuous-extrema proof.

Prototype source-test thresholds are explicitly engineering choices:≤1mmsupport drift,≤0.5mmsupported sole height/penetration, positive forward knee branch and exact loop closure within1e−12m. These thresholds test mechanical source behavior, not production gait quality. Tests preserve the existing prepared skeleton and refuse unreachable targets or an unreviewed nonvertical restleg.

## Executed tests and frozen inputs

From this outside-app directory:

```
C4D_GAIT_BODY_DIRECTORY=/workspace/shared/resident-gait-integration python -m unittest test_human_grounded_gait -v
```

**6tests passed**, including actual25/35dense+sampledcontact, trajectory/root compensation, loop/no-source-length change, unreviewed rig/unreachable/invalid input refusals, and explicit interpolation handling. Python compilation passed. The outside-app `prepared_adult_25.json` and35copy are byte-for-byte from frozen commit, not generated substitutes:

-25 SHA256 `e7b088b88ea18bb309ca990ef6c0cafea9420ac152d42d1351c1a9795daa9269`;
-35 SHA256 `ef5eb3ca282b29c482a67af4e3e50d1ed29a8055eed0230ee2a58ec36dddbba9`.

These source fixtures are CC0derived prepared body inputs; their existing provenance/license stays with the application. Copies are review inputs only and **not included in the patch**. Tests write no repo artifacts. Default integrated fixture path is `Path(__file__).parents[1]/assets/authored/humans/makehuman_hm08`.

## Integration still requires actual execution

Root should review/apply only after its current gate/checkpoint and on the right human source base. Actual Blender quaternion-componentFCurve evaluation, action slots, source rest-local translation, exported sampling, frame/skin canonicalizers, Khronos checks, LOD/modifier output and browser skin deformation are **unverified**. An exporter may bake/reduce keys differently; actualGLBworldsole tests must use its real animation channel interpolators, inverse binds and positions after export. No production photographic or biological claim follows from this source checker.

Re-run actual idle/walk exports and master/web pose/contact parity, mobile/desktop animation checks, knee/hip/clothing/shoe visual inspection, transitions and clip metadata. Current fixture pipeline stays separate. This patch introduces no gait for1812/1904people, no new identity, no portrait attribution and no new historical motion source. Existing Otis/Joseph IDs and reconstructed appearance/action grades are unchanged.
