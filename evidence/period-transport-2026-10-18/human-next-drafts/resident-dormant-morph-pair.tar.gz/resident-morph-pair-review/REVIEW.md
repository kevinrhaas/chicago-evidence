# Dormant morph pair sampling follow-up

Outside-application proposal only. Patch against the current application:
`dormant-morph-sampling.patch`, changing only `tools/human_frame_compare.js` and
`tools/test_human_inspection.mjs`. `git apply --check` passed; not applied.

The raw/cleaned comparison now additionally samples each matching named morph
independently at weight 1 on its matching mesh. Samples use rest and the walk clip
midpoint when available, otherwise another positive-duration clip midpoint. Every
other morph retains the actual loaded default, even at the sampled skeletal pose;
facial animation tracks do not confound the isolated morph test.

Receipts identify mesh index/name, target name/index, weight, pose, clip, phase and
maximum actual world-space CPU-skinned vertex delta. Their maximum contributes to
the existing strict pair tolerance/pass decision. Each sample and the function's
finally block restore the original loaded defaults and rest pose. If no named
morphs exist, receipts are empty; no facial vocabulary is claimed from that case.

The comparison remains narrow: supplied clip times plus named weight-1 morph basis
samples at two poses. It does not establish arbitrary combinations, continuous
time, unskinned accessories, rendered appearance, anatomical facial correctness or
photographic quality. The fallback clip midpoint is a sampled pose, not proof that
the clip moves or represents biologically meaningful motion.

Run outside-only regression:

`node /workspace/shared/resident-morph-pair-review/tools/test_human_inspection.mjs`

Passed using the actual vendored Three.js CPU implementation via the local vendor
symlink. New regression constructs matching real SkinnedMeshes with a dormant,
zero-default relative morph, changes its displacement from 10 mm to 20 mm, and uses
a bone-only walk. Default-rest surfaces match exactly, while the new rest/midpoint
target receipts detect the expected 10 mm difference. It verifies reset to zero
defaults afterward. Additional two-target models instrument actual vertex
evaluation to assert the untargeted morph stays at its nonzero default (.35 or .4),
and verifies both defaults are restored after sampling.

Existing default-morph, terminal clamp/reset, metric-scale, empty-surface and
duplicate-clip tests still pass. Syntax checks passed. No browser, Blender, CI or
actual resident raw/cleaned pair was run. These are comparison-correctness tests,
not model acceptance or evidence that a particular resident export is damaged.
