import pathlib,sys,json,math,hashlib
P=pathlib.Path(__file__).parent;sys.path.insert(0,str(P/'proposal/tools'));import human_hair_short04 as hair
config=json.loads((P/'hair_component.recipe.json').read_text());reports=[]
for age in [25,35]:
 path=pathlib.Path(f'/workspace/chicago/chicago/4d/assets/authored/humans/makehuman_hm08/prepared_adult_{age}.json');body=json.loads(path.read_text());mesh,tex,report=hair.fit(body,config,P/'proposal');old=json.loads(pathlib.Path(f'/workspace/shared/resident-hair-source/short04_fitted_adult{age}.json').read_text())['mesh'];error=max(math.dist(a,b)for a,b in zip(mesh['positions_m'],old['positions_m']));assert error<1e-12;assert mesh['triangles']==old['triangles'];assert hair.fit(body,config,P/'proposal')[0]==mesh
 names={b['name']for b in body['skeleton']}
 for row in mesh['weights']:assert set(row)<=names and len(row)<=4 and min(row.values())>0 and abs(math.fsum(row.values())-1)<1e-12
 assert all(0<=v<=1 for pair in mesh['uvs']for v in pair)
 reports.append({'age':age,'body_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'original_fitter_max_position_delta_m':error,**{k:v for k,v in report.items()if k!='source'}})
 bad={**config,'source_manifest_sha256':'0'*64}
 try:hair.fit(body,bad,P/'proposal');raise AssertionError('bad manifest accepted')
 except ValueError as e:assert 'manifest hash mismatch'in str(e)
 del body['meshes'][0]['source_vertex_indices']
 try:hair.fit(body,config,P/'proposal');raise AssertionError('missing source map accepted')
 except KeyError:pass
(P/'fitting-audit.json').write_text(json.dumps({'body_fits':reports,'bad_manifest_rejected':True,'missing_body_source_map_rejected':True},indent=2)+'\n');print('PASS two body fits, normalized <=4 weights, source topology, unit UVs, repeatability and two negative checks; no Blender validation')
