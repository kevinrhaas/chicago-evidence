# Proposed short04 integration — unapplied

2026-10-18. Outside-app ONLY. No Blender, application edits, browser, blocked network requests, CI, publication or acceptance. Existing resident references Otis Bardwell (`rc_bardwell_otis`), Joseph Dufresne (`rc_dufresne_joseph`) and Martin Flynn (`rc_flynn_martin`) are retained unchanged. Shared hairstyle is reconstructed appearance, not a documentary likeness or period-attested groom.

## Reviewable artifacts

`short04-builder.proposed.patch` adds original GPL project fitting helper and narrowly changes canonical builder plus recipe. `proposal/assets/authored/humans/hair_short04/` contains the exact four acquired originalCC0files, clearly named derivative paddedPNG, and hash-pinnedSOURCE.json. Binary assets are NOT embedded in textual patch. Root must explicitly ingest that one folder if accepting, then apply reviewed patch. Do not copy the whole proposed builder over concurrent QA/gait edits; apply contextual patch. `git apply --check` passed against current tree; source Python syntax compiles. Blender never executed.

Original source provenance/headers/legalcontacts retained: MakeHuman system short04 UUIDe09bfd91-f83f-4f9a-ba8c-4635cd1ae0d8; actualOBJ/mhclo/mhmat explicitly CC0 September2020; DataCollectionAB,JoelPalmius,JonasHauquier. Original texture referenced by per-assetCC0material, SHA0bef7fc0e403db5a40fabb2111ebfa6f7e8158e204c6e56b8da98e9ef527846e. SOURCE.json pins every exact original/derivative byte and archiveETag; recipe pins SOURCE.jsonSHA. Existing selective archive includes original license headers, official listing and exact acquisitionreceipts; located `/workspace/shared/resident-hair-short04-selective.tar.gz`. Root owns assets/LICENSES.md/source/liberty registry additions; this proposal does NOT secretly supply or claim those required integration steps complete.

## Fitting/UV proof

Helper reads actual unmodifiedOBJ+mhclo with original code, actual prepared source_vertex_indices and weights, and actual scaleanchors. All865proxyrows and613distinctbodyrefs plus6anchors resolve on25/35. Legal signed geometric barycentric coefficients retained/normalized only for5decimal rounding. UV-seams split to991vertices/1050triangles, original source topology; position delta vsprevious independently reviewed fitter0m. Skin interpolation clamps one tiny negativeweightrow (maxnegative mass.0000127), keeps≤4normalizedpositiveweights; zero additionalprune. Actual bones retained, including neck/clavicle/nape rather than rigidly assigning everythinghead. These are adaptation choices, not animated correctness proof.

OriginalVmax1.0031 resolved only in proposed derivative:2048x2057image with8periodicrowsabove,1below; affineVnew=(2048V+1)/2057,Uunchanged. All remappedUVwithin0..1,Vrange.0184073894–.9991972776. Sourcebytes untouched. `/workspace/shared/resident-hair-source/uv-padding-validation.json` measures original REPEAT vsderivativeCLAMP unminifiedpixel-centerbilinear on991UV+5000seededsamples/body, maxRGBAerror5.8e-11/255. This does NOT prove mip/trilinear/aniso equivalence; those filters can span gutter or build differentmips. Cannot silently call source preservation complete until actualrenderer/export tested.

## Builder/material/LOD choices

Packs hashverifiedderivedsRGBatlas withwhitebasefactor, reconstructedroughness.65,double-sided,clampedLinearimagesampling. Source legacyMakeHumanlitsphere/anisoshader NOT copied. BinaryalphaGREATER_THAN.4node wired toPrincipledAlpha. Blender4.5surface_render_method=DITHERED provisionally supportsalpha; actualglTFalphaModeMASK/cutoff andGPUedges MUST be inspected. This code cannot honestly guarantee exporter infersMASK until actualCI; ifit emitsBLEND/OPAQUE, fixexportpathrather thanclaimingdone. Material shader/render behavior unverified.

AllfourLODs retain1050sourcehairtriangles/991UVverts and1extradraw each. This avoids untestedalpha-carddecimation destroyingnearappearance. LowerLODoptimization remainsopen; no tinyarbitrarygroom budget claimed. Packedatlasdecoded16,850,944bytes (~16.07MiB) peruniqueimage beforemips; sourceingestionfolder4,862,305bytes incloriginalPNGandderivative. EachGLBmayembeditsownatlas;4LODs cancost4timesmemory if separatelydecoded,3residents similarly need actualruntimecachemeasurements. Do not assumecrossassetdedup. ExactGLBcompressedbytes/totalpersonbudgetrequireCI.

## Required review before acceptance

RunexistingcanonicalhumanCI forresidentvariantids withoutchangingidentity: currentworkflow suppliesoutput `assets/authored/humans/teamsters/<variant>/canonical.blend`, thenexistinghuman_export.py. This proposaldidnotrunthatcommand. Validatehairprimitiveexists/all4LODs/same56joints; compareactualpositions/UVs/weights/boundsandmaterialhash; Khronos/contract/decodedtextures. Inspectfront/profile/closeedgesandcrown; scalp/ear/collar/deformationcollisions; neck/head/jaw/faceposes; groundedidle/walkplusseat/reins. CheckPBRalpha/bilaterallighting/mobileedges/mipmapminificationandmemory. Historicalhair/groom/photoskin/personlikenessremainunaccepted.

`python /workspace/shared/resident-hair-integration/audit.py` passedactual25/35fits, zerogeometrydrift, sourcefaceindices,unitUVs, normalizedpositive≤4weights, rebuildrepeatability, badmanifestrejectionandmissingsourcemaprejection. Audit is CPUarithmetic, notcanonicalBlenderorglTFrenderacceptance.
