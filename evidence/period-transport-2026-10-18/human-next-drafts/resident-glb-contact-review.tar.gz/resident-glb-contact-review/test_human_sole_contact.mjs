// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';
import test from 'node:test';
import * as T from '../renderers/web/vendor/three-0.185.1/three.module.js';
import {sampleSoleContact} from './human_sole_contact.mjs';
function fixture(){
  const scene=new T.Group(),root=new T.Bone(),left=new T.Bone(),right=new T.Bone();root.name='pelvis';left.name='foot_l';right.name='foot_r';root.add(left,right);scene.add(root);
  const positions=[],indices=[],weights=[];
  for(const x of [.15,-.15])for(const [dx,z]of [[-.05,-.1],[.05,-.1],[0,.15]]){positions.push(x+dx,0,z);indices.push(x>0?1:2,0,0,0);weights.push(1,0,0,0);}
  const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(positions,3));g.setAttribute('skinIndex',new T.Uint16BufferAttribute(indices,4));g.setAttribute('skinWeight',new T.Float32BufferAttribute(weights,4));
  const mesh=new T.SkinnedMesh(g,new T.MeshBasicMaterial());mesh.name='synthetic_two_shoes';mesh.material.name='footwear__test';scene.add(mesh);scene.updateMatrixWorld(true);mesh.bind(new T.Skeleton([root,left,right]));
  const times=[],values=[[],[]];
  for(let k=0;k<=36;k++){const phase=k/36;times.push(phase*1.2);for(let s=0;s<2;s++){const q=(phase+s*.5)%1,duty=.62;let z,y=0;if(q<duty)z=.2232-.72*q;else{const u=(q-duty)/(1-duty),smooth=u**3*(10-15*u+6*u*u),m=-.72*(1-duty);z=-.2232+m*u+(.4464-m)*smooth;y=.065*Math.sin(Math.PI*u)**2;}values[s].push(0,y,z);}}
  const tracks=['foot_l','foot_r'].map((n,i)=>new T.VectorKeyframeTrack(n+'.position',times,values[i],T.InterpolateLinear));
  const clip=new T.AnimationClip('walk',1.2,tracks);clip.userData={speed_m_s:.6,stance_fraction:.62};
  return {scene,animations:[clip],mesh,left,right};
}
test('actual Three CPU skinned synthetic planted soles; not exported-resident evidence',()=>{const f=fixture();const r=sampleSoleContact(T,f,{raw:true});assert.equal(r.passed,true);assert.equal(r.selection.left.length,3);assert.equal(r.raw_samples.length,1001);assert.ok(r.metrics.maximum_stance_horizontal_drift_m<.001);assert.ok(r.metrics.local_loop_closure_m<1e-6);assert.equal(f.left.position.z,0);});
test('limb identity follows named skin weights through actor yaw',()=>{const f=fixture();f.scene.rotation.y=Math.PI;const r=sampleSoleContact(T,f,{forward_world:[0,0,-1],raw:false});assert.equal(r.passed,true);assert.ok(r.selection.left.every(v=>v.rest_world[0]<0));});
test('stationary sliding animation fails compensated stance drift',()=>{const f=fixture();for(const tr of f.animations[0].tracks)tr.values.fill(0);const r=sampleSoleContact(T,f);assert.equal(r.passed,false);assert.ok(r.metrics.maximum_stance_horizontal_drift_m>.4);});
test('encoded root translation is not cancelled away',()=>{const f=fixture();f.animations[0].tracks.push(new T.VectorKeyframeTrack('pelvis.position',[0,1.2],[0,0,0,0,0,.72]));const r=sampleSoleContact(T,f);assert.equal(r.passed,false);assert.ok(r.metrics.local_loop_closure_m>.7);});
test('ambiguous limb identity refuses',()=>{const f=fixture();f.left.name='unknown';assert.throws(()=>sampleSoleContact(T,f),/ambiguous/);});
test('missing footwear and duplicate walk refuse',()=>{const f=fixture();f.mesh.material.name='skin';assert.throws(()=>sampleSoleContact(T,f),/missing named/);const g=fixture();g.animations.push(g.animations[0]);assert.throws(()=>sampleSoleContact(T,g),/unique walk/);});
test('bad speed and duration refuse',()=>{assert.throws(()=>sampleSoleContact(T,fixture(),{speed_m_s:NaN}),/nonfinite/);assert.throws(()=>sampleSoleContact(T,fixture(),{expected_duration_s:2}),/duration/);});

test('contact model refuses disagreement with loaded actor speed/support metadata',()=>{const f=fixture();f.animations[0].userData.speed_m_s=.8;assert.throws(()=>sampleSoleContact(T,f),/speed metadata/);const g=fixture();g.animations[0].userData.stance_fraction=.7;assert.throws(()=>sampleSoleContact(T,g),/stance metadata/);});
