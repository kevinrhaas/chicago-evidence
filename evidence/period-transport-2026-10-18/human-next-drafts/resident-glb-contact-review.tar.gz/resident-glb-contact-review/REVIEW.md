# Independent source review: loaded sole contact draft

Read-only application review. No tests, browser, Blender or CI were run while
derivation was active. Corrections here are proposals against the outside draft,
not applied application changes or validated resident contact evidence.

## Correction before runtime gait acceptance: metadata agreement

The sampler adds assumed actor motion at 0.6m/s and assumes duty0.62, but does not
check loaded animation extras. The browser actor uses loaded `speed_m_s`. A clip
with the correct in-place foot trajectory but speed metadata0.8 could therefore
pass this sampler at0.6 while the actual actor skates at0.8. The ordinary inspector
checks only that speed is positive. Before calling the result runtime-fit evidence,
require finite loaded speed/stance metadata matching the explicit measurement
model, or report unavailable/incompatible instead of a contact pass.

`proposed-corrections.patch` adds these checks and an explicit finite duration
check. The builder currently authors `speed_m_s` and `stance_fraction`; the exporter
documents action extras export. Still verify those extras survive actual output.
Missing metadata should be a diagnostic, not silently invented from sampler defaults.

## Fixed sole identity and support drift

The foot/ball weight classification correctly follows named left/right bones,
not world X. It checks four-lane finite normalized weights and refuses ambiguous
footwear. Fixed rest-selected vertex IDs avoid selecting a convenient new point
every frame. Both feet need at least three sole-band vertices.

Support wrapping is coherent for the observed one-cycle interval: right stance
starts as a partial stance at phase0, ends near0.12, starts a new stance near0.5,
and continues through1. Left begins a new stance at1 after its swing, so its
reference has already been cleared. References reset only outside support, and
drift compares the same vertices against the first observed support sample of
that contiguous interval. Partial boundary stances and discrete sampling remain
explicit limitations; the result is not a continuous-time bound.

World compensation adds `forward_world * speed * time` without deleting encoded
root motion. That correctly exposes accidental double travel. Default +Z matches
the glTF convention; rotated actors must provide their rotated forward as the
README says. Horizontal normalized forward is required. Ground is a flat world-Y
plane, not terrain or a generalized slope contact test.

## Actual Three pose/reset path

The disposable GLTFLoader scene is independent of the currently displayed actor.
Each sample stops actions, restores all loaded node transforms and actual morph
defaults, resets the walk action, plays LoopOnce/clamped at the requested time,
then updates world and skeleton matrices. getVertexPosition plus matrixWorld is
the actual loaded CPU skin/morph path. Finally restores the disposable scene and
uncaches the mixer. This is an appropriate sequence from source review; no new
runtime execution was performed here.

## Draw-range/material detail

The helper intersects index counts, draw ranges and groups and rejects partial
triangle boundaries, which is appropriate for an array of materials. One issue:
Three ignores geometry groups for a **single material**, whereas the draft always
honors nonempty groups. That can omit actually rendered footwear vertices when a
single-material geometry retains groups. Proposed correction uses groups only
for a material array. GLTFLoader often creates separate primitive meshes without
such groups, so this is not evidence of a defect in the current resident output.

Object/ancestor/material visibility is not filtered. Either label the sampler as
candidate footwear triangles regardless of visibility, or handle that distinction
before calling them actual rendered triangles. Selecting hidden footwear as an
engineering contact surface can be deliberate, but it must be stated. No GLTFLoader
material association is required to follow the actual loaded material object/name;
using name prefix `footwear` relies on the enforced human material contract.

## Runner and test integration

Opt-in `--sole-contact` preserves default invocations and samples once on desktop
because CPU contact does not depend on viewport. Separate master/web modes and
SHA256 receipts are appropriate. The wrapper does not claim the displayed actor
itself was measured. Failure exceptions currently abort the run; that is a clear
failure, though a partial failure receipt would improve diagnosis.

The draft patch paths are `a/tools/...`, so application from the repository root
requires `--directory=chicago/4d` or regeneration with repository-root paths. Its
new helper route must be served alongside the inspection HTML; the draft runner
adds that explicit route.

The patch omits the supplied synthetic test, and that test imports an absolute
workspace vendor path. Include a portable test in the application using
`../renderers/web/vendor/three-0.185.1/three.module.js`, then wire it to the focused
checks. The proposed test copy corrects that path, supplies realistic speed/duty
extras and adds disagreement refusals. **It has not been run** during derivation.
The original seven synthetic tests are the author's earlier evidence, not a test
result from this independent review.

## Scope to keep open

This flat-foot sole-band model intentionally does not support heel/toe rolling.
It does not prove upper-body contacts, garment fit, intermediate-time penetration,
physiology, appearance, historical clothing, or photographic quality. Lowest
rest footwear vertices may be unsuitable for future shoe geometry or non-flat
soles; refuse/instrument that case rather than relaxing tolerances. Actual resident
GLBs still need to be sampled and visually inspected before any gait acceptance.
