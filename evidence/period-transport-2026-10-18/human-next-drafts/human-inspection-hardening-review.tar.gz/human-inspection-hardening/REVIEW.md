# Resident inspection QA proposal

Unapplied six-file patch: `/workspace/shared/human-inspection-hardening.patch`, based on exact human commit `0577792dc5b4107fcf4aeab0014d0b9fb3f44ab6`. Source files were read with git show into an outside-app shadow. No app edits, Blender runs, WebGL/browser runs, dispatches or model acceptance were performed while preparing it.

## Final proposed behavior

- Require actual decoded color textures associated with every loaded skin material. Record glTF material/texture/image associations and decoded dimensions; an empty texture list cannot pass. This does not prove correct UV anatomy, useful texture detail or photographic quality.
- Record projected indexed geometry for each LOD0 standing/head screenshot, finite depth/viewport bounds, 2% margins, header overlap and at least20% head-detail viewport-height coverage. The existing camera heuristic stays, exposing cropping. Enumeration currently includes hidden/drawRange-excluded vertices, so it is conservative and can falsely fail generic hidden geometry; it does not establish pixel segmentation or landmark correctness.
- Require actual temporal surface and bone variation relative to clip phase0 at phases0/.25/.5/.75. A static pose displaced from bind rest no longer passes as animation. Face morph response is required on actual head/jaw/eye-weighted face geometry; correct expression, eyelid closure and biomechanics remain open.
- Preserve and restore actual loaded morph defaults instead of zeroing authored defaults. Technical inspector title and labels identify the loaded existing resident reference by name/ID/scene/grade and explicitly retain reconstructed depiction and no factual likeness scope. Metadata does not upgrade source grade.
- Keep grounding labeled precisely: idle phase0, footwear minimumY by world-X sign,20mm tolerance. This is not walk contact or limb identity qualification.

## Raw/source skin comparison

New `tools/human_frame_compare.js` compares actual CPU-skinned world vertices from retained raw and cleaned/consolidated source GLBs. It checks nonempty metric surfaces, exact vertex/index/material/morph/group/draw-range correspondence and valid unique clip names/durations before comparison. Bind snapshots preserve actual default morphs. Animation uses LoopOnce with terminal clamping, reset between samples. It samples rest and21 evenly spaced phases per clip including the terminal time, with an explicit provisional0.1mm maximum delta criterion. Inputs are whitelisted and SHA256 recorded.

Workflow wiring invokes the pair for EACH of the three residents: `/tmp/teamster-studies/export-evidence/NAME.lod0.raw.glb` versus `assets/humans/NAME.lod0.glb`. Raw filename follows actual exporter `path.stem + '.raw.glb'`; accepted source is after bounded frame repair and exact skin consolidation. Desktop-only comparison is viewport-independent CPU evaluation. This is not Meshopt/web pointwise comparison, continuous-time surface equivalence, unskinned-accessory validation or visual acceptance.

Khronos workflow logging adds only actual reported severity/code occurrence counts, info/hint totals and truncation state, retaining original error/warning totals. No guessed interpretation of the current seven warnings and no artifact bytes/screenshots enter logs.

## Verification and integration

The patch adds `tools/test_human_inspection.mjs` plus a check.sh step. The regression uses actual pinned vendored Three SkinnedMesh/AnimationMixer, detects4mm difference from nonzero .4/.8 default morphs, verifies restoration and terminal/midpoint reset, and rejects empty/tiny/duplicate inputs. Its app-relative vendor imports require no npm installation; outside review uses a vendor symlink only, absent from the patch. CPU regression, source syntax and frozen057 patch applicability PASS. Root must measure/add isolation metadata; none is fabricated.

Actual resident asset/WebGL execution, texture binding, framing and raw/source pair remain pending the next CI invocation. Photographic anatomy, likeness, skin/hair/cloth, period wardrobe, gait, driver/riding poses and continuous collision are not established. No gait integration is included in this QA patch.
