// SPDX-License-Identifier: GPL-3.0-or-later
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
// Uses the pinned application vendor directly: no npm dependency or WebGL.
import * as T from '../renderers/web/vendor/three-0.185.1/three.module.js';
const source=await readFile(new URL('./human_frame_compare.js',import.meta.url),'utf8');
const pure=source.slice(source.indexOf('export function maximumPointDisplacement'),source.indexOf('export async function compareFrameRepair')).replace('export function','function');
const ctx=vm.createContext({T,console});vm.runInContext(pure,ctx);
function model(defaultWeight=.4,scale=1){
 const geo=new T.BufferGeometry();
 geo.setAttribute('position',new T.Float32BufferAttribute([0,0,0,.1,1.7,0,-.1,1.7,0],3));
 geo.setAttribute('skinIndex',new T.Uint16BufferAttribute(new Array(12).fill(0),4));
 geo.setAttribute('skinWeight',new T.Float32BufferAttribute([1,0,0,0,1,0,0,0,1,0,0,0],4));
 geo.morphTargetsRelative=true;
 geo.morphAttributes.position=[new T.Float32BufferAttribute([0,.01,0,0,.01,0,0,.01,0],3)];
 const mesh=new T.SkinnedMesh(geo,new T.MeshBasicMaterial());mesh.name='adult';
 const bone=new T.Bone();bone.name='root';mesh.add(bone);mesh.bind(new T.Skeleton([bone]));
 mesh.morphTargetInfluences[0]=defaultWeight;
 const scene=new T.Scene();scene.add(mesh);scene.scale.setScalar(scale);scene.updateMatrixWorld(true);
 return{scene,meshes:[mesh],bind:[],animations:[new T.AnimationClip('expression',1,[new T.NumberKeyframeTrack('adult.morphTargetInfluences[0]',[0,1],[.2,.8])])]};
}
const a=model(.4),b=model(.8);ctx.bind(a);ctx.bind(b);a.meshes[0].morphTargetInfluences[0]=.9;ctx.pose(a,null,0);ctx.pose(b,null,0);
assert.equal(a.meshes[0].morphTargetInfluences[0],.4);
assert.equal(b.meshes[0].morphTargetInfluences[0],.8);
assert.ok(Math.abs(ctx.maximumPointDisplacement(ctx.surface(a),ctx.surface(b))-.004)<1e-8,'default morph difference survives actual CPU skinning');
ctx.pose(a,'expression',1);assert.ok(Math.abs(a.meshes[0].morphTargetInfluences[0]-.8)<1e-6,'terminal clamped sample reaches final value');
ctx.pose(a,'expression',.5);assert.ok(Math.abs(a.meshes[0].morphTargetInfluences[0]-.5)<1e-6,'next sample resets action time');
ctx.pose(a,null,0);assert.equal(a.meshes[0].morphTargetInfluences[0],.4,'post-animation default restored');
assert.throws(()=>ctx.maximumPointDisplacement([],[]),/layout/);
const tiny=model(.4,.001);ctx.bind(tiny);ctx.pose(tiny,null,0);assert.throws(()=>ctx.metricSpan(ctx.surface(tiny)),/metric/);
assert.ok(ctx.metricSpan(ctx.surface(a)).maximum_axis_span_m>1.6);
const duplicate=model();duplicate.animations.push(duplicate.animations[0]);assert.throws(()=>ctx.clipFacts(duplicate),/ambiguous/);
console.log('PASS: actual vendored Three.js CPU skin/morph regression: defaults, sampled surface difference, terminal clamp/reset, empty surface, metric scale and duplicate clips; no resident/WebGL acceptance');
