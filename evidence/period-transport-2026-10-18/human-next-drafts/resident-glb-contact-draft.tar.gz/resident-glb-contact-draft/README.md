# Actual loaded footwear contact draft (outside app)

`loaded-sole-contact.patch` applies cleanly against the current human branch files read on 2026-10-18. No app changes were made. It adds an opt-in `--sole-contact` mode to the existing inspection runner. Existing invocations remain unchanged. Root can apply after the active gate and run next canonical actual exports, separately for masters and web derivatives, for example:

```
node tools/human_teamster.mjs --masters --sole-contact --output /tmp/master-contact
node tools/human_teamster.mjs --sole-contact --output /tmp/web-contact
```

The existing runner launches a browser; **neither command was executed here**. No Blender or browser was run. Current local masters remain the legacy fixture rather than the pending resident exports. There is no resident gait acceptance receipt yet.

## What the added measurement actually observes

Each actual GLB is independently fetched/decoded using GLTFLoader, with the existing Meshopt decoder when required. It is not the rendered actor and cannot be contaminated by display pose changes. Three `SkinnedMesh.getVertexPosition` evaluates loaded morphs and skinning, then mesh `matrixWorld` maps the points into world space, following the frame-compare infrastructure. Each sample resets the loaded bind/default-morph state, clamps a fresh walk action and updates world/skeleton matrices. The disposable loaded asset is released after the measurement.

Foot identity follows foot_l/ball_l and foot_r/ball_r weights (over .9 for its side and under .01 opposite), never deformed world X. Only actual footwear material triangles within draw ranges participate; indices/material groups are honored. Fixed vertex IDs are chosen once from the default-rest sole band (0.1mm above each named foot's minimum). At least three are required per side. There is no per-frame reselection of the lowest point, no bone/socket proxy, no source-only shoe reconstruction and no automatic floor correction.

The sampler checks 1001 uniformly spaced samples of the actual 1.2s walk. Declared engineering support is left phase<.62 and right (phase+.5)%1<.62. Declared world motion adds +Z*.6m/s*time. For an explicitly rotated actor callers must supply the matching world forward; yaw tests cover this. Encoded root travel is deliberately not subtracted, so an accidental double-motion clip fails drift/loop measurements instead of being hidden. General sloped ground is unsupported.

For each contiguous sampled stance it tracks the displacement of each same sole vertex in world XZ from its first sampled support position. It reports maximum stance absolute floor distance, minimum sole height through swing/stance, unsupported samples and uncompensated local loop closure. Raw receipts include every sole vertex reference/rest world point and all sampled compensated positions, phases, support flags and heights. Host adds SHA256 of the actual served master/derivative and writes a separate receipt JSON for each asset/LOD. Source and web measurements remain distinct; viewport duplication is avoided. Loaded walk userData MUST declare finite numeric speed_m_s=.6, stance_fraction=.62 and cycle_duration_s=1.2 (agreement tolerance1e-6), and loaded duration must be finite/1.2 within1e-5. Missing/mismatched metadata refuses before sampling. Every successful receipt records each declared/expected/tolerance/matched comparison, including loaded duration.

The draft's 2mm drift/height/penetration and 2mm loop limits are explicit engineering gates, **not historical, physiological or photographic claims**. Source37-key metrics (~0.336mm skid, ~0.264mm stance error) remain a different result. Inter-sample penetration, other body contacts, garment fit, toe rollover, footwear thickness, visible gait realism, slope contact and correctness of declared stance/speed remain unproven. Fixed sole sampling is appropriate only to this currently authored flat-foot mechanical gait; a later heel/toe roll needs a different support-surface model rather than relaxing this gate.

## Verification actually run

- `node --test staging/tools/test_human_sole_contact.mjs`: 12 tests pass using the vendored actual Three185 CPU skin machinery with explicitly synthetic skin/animation. Tests cover planted animation, rotated identity, sliding failure, encoded-root-motion failure, ambiguous identity, absent footwear, duplicate clips and invalid settings.
- JS syntax checks pass for helper and proposed runner.
- `git apply --check loaded-sole-contact.patch`: passes against current app files.

Synthetic tests establish sampler behavior only. No pending exported-resident motion is described as measured or accepted. The test uses a portable app-relative vendor import. Outside-app execution uses staging/renderers symlink to this repo vendor; patch includes test and a focused tools/check.sh step.
