from pathlib import Path
import difflib
root=Path('/workspace/chicago/chicago/4d'); out=Path('/workspace/shared/resident-glb-contact-draft')
html=(root/'tools/human_teamster.html').read_text()
addition="""const { sampleSoleContact } = await import('./human_sole_contact.mjs');
async function measureSoleContact(file) {
  const response=await fetch('/runtime/'+file);if(!response.ok)throw Error('sole contact asset fetch '+response.status);
  const buffer=await response.arrayBuffer(),dv=new DataView(buffer),header=JSON.parse(new TextDecoder().decode(new Uint8Array(buffer,20,dv.getUint32(12,true))));
  const contactLoader=new GLTFLoader();if(header.extensionsRequired?.includes('EXT_meshopt_compression'))contactLoader.setMeshoptDecoder(await loadMeshoptDecoder());
  const model=await contactLoader.parseAsync(buffer,'/runtime/'+file.slice(0,file.lastIndexOf('/')+1));
  try{return sampleSoleContact(T,model,{provenance:{file,declared_scene_metadata:header.scenes?.[0]?.extras?.chicago4d_human??null}});}
  finally{const gs=new Set(),ms=new Set(),ts=new Set();model.scene.traverse(o=>{if(o.isMesh){gs.add(o.geometry);for(const m of [].concat(o.material)){ms.add(m);for(const x of Object.values(m))if(x?.isTexture)ts.add(x);}}});for(const g of gs)g.dispose();for(const t of ts){t.image?.close?.();t.dispose();}for(const m of ms)m.dispose();}
}
"""
html=html.replace('window.teamsterInspection={ready:true',addition+'window.teamsterInspection={measureSoleContact,ready:true')
js=(root/'tools/human_teamster.mjs').read_text()
js=js.replace('let framePairs=[]','let soleContact=false,framePairs=[]')
js=js.replace("if(a==='--published')","if(a==='--sole-contact')soleContact=true;else if(a==='--published')")
js=js.replace("'/tools/human_frame_compare.js'","'/tools/human_frame_compare.js','/tools/human_sole_contact.mjs'")
needle="const captures=[],captureFraming=[];"
replacement="""if(soleContact&&label==='desktop'){const contact=await page.evaluate(file=>teamsterInspection.measureSoleContact(file),file);contact.provenance={...contact.provenance,sha256:result.sha256,served_path:result.served_path,asset_kind:masters?'master':'web_derivative'};const receipt=path.basename(file,'.glb')+'-sole-contact.json';await writeFile(path.join(output,receipt),JSON.stringify(contact)+'\\n');result.walk_sole_contact={receipt,metadata_comparisons:contact.metadata_comparisons,metrics:contact.metrics,passed:contact.passed,scope:contact.scope};if(!contact.passed)failures.push(`${file}: sampled loaded walk sole-contact failed ${JSON.stringify(contact.metrics)}`);}const captures=[],captureFraming=[];"""
assert needle in js;js=js.replace(needle,replacement)
check=(root/'tools/check.sh').read_text()
anchor='step "Portable human contract holds; every human GLB and instance is held to it (T-1786)"'
assert anchor in check
check=check.replace(anchor,'step "Loaded human sole contacts preserve named limb identity and require gait metadata" \\'+"\n"+'  node --test tools/test_human_sole_contact.mjs'+"\n\n"+anchor)
patch=[]
for name,new in [('tools/human_teamster.html',html),('tools/human_teamster.mjs',js),('tools/human_sole_contact.mjs',(out/'human_sole_contact.mjs').read_text()),('tools/test_human_sole_contact.mjs',(out/'test_human_sole_contact.mjs').read_text()),('tools/check.sh',check)]:
 old=(root/name).read_text() if (root/name).exists() else ''
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+name if old else '/dev/null',tofile='b/'+name))
 (out/Path(name).name).write_text(new)
(out/'loaded-sole-contact.patch').write_text(''.join(patch))
