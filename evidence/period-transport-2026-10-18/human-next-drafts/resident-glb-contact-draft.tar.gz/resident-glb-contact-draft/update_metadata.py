from pathlib import Path
p=Path('/workspace/shared/resident-glb-contact-draft')
s=(p/'human_sole_contact.mjs').read_text()
s=s.replace("if(clips.length!==1||Math.abs(clips[0].duration-expected_duration_s)>1e-5)","if(clips.length!==1||!Number.isFinite(clips[0].duration)||Math.abs(clips[0].duration-expected_duration_s)>1e-5)")
needle="const scene=gltf.scene, clip=clips[0], bind=[], meshes=[];"
replacement="""const clip=clips[0], declared=clip.userData??{};
  const metadata_comparisons={};
  for(const [key,expected]of [['speed_m_s',speed_m_s],['stance_fraction',duty],['cycle_duration_s',expected_duration_s]]){
    const actual=declared[key], matched=typeof actual==='number'&&Number.isFinite(actual)&&Math.abs(actual-expected)<=1e-6;
    metadata_comparisons[key]={declared:actual??null,expected,tolerance:1e-6,matched};
    if(!matched)throw Error('walk metadata '+key+' must be finite and match expected '+expected);
  }
  metadata_comparisons.loaded_clip_duration_s={declared:clip.duration,expected:expected_duration_s,tolerance:1e-5,matched:true};
  const scene=gltf.scene, bind=[], meshes=[];"""
assert needle in s;s=s.replace(needle,replacement).replace('provenance,clip:clip.name','provenance,metadata_comparisons,clip:clip.name')
(p/'human_sole_contact.mjs').write_text(s)
s=(p/'test_human_sole_contact.mjs').read_text().replace("'/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/three.module.js'","'../renderers/web/vendor/three-0.185.1/three.module.js'")
s=s.replace("return {scene,animations:[new T.AnimationClip('walk',1.2,tracks)],mesh,left,right};","const clip=new T.AnimationClip('walk',1.2,tracks);clip.userData={speed_m_s:.6,stance_fraction:.62,cycle_duration_s:1.2};\n  return {scene,animations:[clip],mesh,left,right};")
s+="""
test('actual loaded metadata comparisons are recorded',()=>{const r=sampleSoleContact(T,fixture());for(const entry of Object.values(r.metadata_comparisons))assert.equal(entry.matched,true);assert.equal(r.metadata_comparisons.speed_m_s.declared,.6);});
test('missing, nonfinite, string or different speed/duty/cycle metadata refuse',()=>{for(const key of ['speed_m_s','stance_fraction','cycle_duration_s'])for(const value of [undefined,NaN,Infinity,'0.6',.1]){const f=fixture();f.animations[0].userData[key]=value;assert.throws(()=>sampleSoleContact(T,f),new RegExp('walk metadata '+key));}const f=fixture();delete f.animations[0].userData;assert.throws(()=>sampleSoleContact(T,f),/walk metadata/);});
test('nonfinite loaded duration refuses explicitly',()=>{const f=fixture();f.animations[0].duration=NaN;assert.throws(()=>sampleSoleContact(T,f),/duration/);});
"""
(p/'test_human_sole_contact.mjs').write_text(s)
