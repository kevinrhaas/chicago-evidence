# Desktop restoration-red investigation — no rerun or application edits

Run39164186323, source log `/tmp/transport-desktop-full-cancelled-39164186323.log`.

Observed:

- Stage1 yard fence: effect mean3.809/worst79 passes the visibility floor; restoration mean0.017/worst35 fails the unchanged worst≤1 limit (mean≤0.02 passes).
- Stage2 confidence off: restoration mean0.24/worst13 fails unchanged limits0.1/3.
- Later grade-look restoration and explicit ghost-layer/material/renderer-state cleanup checks pass in the same log. This narrows what was observed but does not establish the cause of the earlier off/restored difference.
- The full desktop job exceeded90minutes; there is no completed desktop verdict. Mobile passing these checks does not establish desktop equivalence.

Read standing records before any rerun: desktopstage1 latestPASS2026-10-18T20:30:04.212Z,433s, dirtytree hash74891ba53af4638d, commit6b51f65ca019, dev7d5daca7d827; desktopstage2 latestPASS2026-10-16T04:21:03.308Z,410s, clean tree30f879e99c308e87, commit61e8dc043c28, devac7c81ed9605. These are different recorded conditions/trees, not proof this CI failure was inherited. Current relevant tree hash returned by the query was5c588b7d3e58b835.

## Proven instrument limitation, unproven CI cause

`tools/smoke_renderer.mjs:2705` and `:7429` hold animation time before their capture trios, but wait only350ms/250ms after a camera jump. `renderers/web/js/main.js:4571` makesdt0 when held. However the same tick still runs `flora.update(dt,camera,4ms)` at4610 and `residency.tick(camera.position)` at4617. The hold therefore freezes visual time, **not all state that influences the rendered image**.

Actual flora code `flora.js:3052` continues GPU-field residency and rebuild work atdt0. Its T2683 jump-pass path (`:2418–2445`) deliberately draws the old lattice until a multi-frame replacement lands. `flora.inFlight()` and spread landings/pass counters expose this state; `flora.settle()` and `api.step()` (main.js:4886, infinite flora budget by default) provide existing diagnostic tools.

Texture residency `texture-residency.js:392` similarly evaluates the new eye, pumps ready texture uploads and tallies state every frame. It may change a sampled material between held-time captures; `textureResidency.state.pending/uploads/evictions/redecodes` exposes useful evidence. `everything()` would change the test configuration and is not proposed as a silent fix.

`capture()` does read pixels inside the exact next rendered frame (`main.js:4832`, `:4636`), so there is no evidence here of the older cleared-buffer/readback bug. Governor rest is explicitly forced during captures and animation hold (`:4704`), avoiding its moving-shadow optimization. Camera/near-plane and async placement counters still need to be compared across the actual failed trio.

No CI snapshots of these counters or changed-cell coordinates were recorded. Mean/worst residuals alone cannot identify whether the change was flora, texture residency, camera, renderer state, or another effect. Therefore neither a deterministic render regression nor an inherited instrumentation failure is proven. The far-merge agent's one bounded current-tree natural/forced-step trio had zero residual and stable per-layer counts; it did not reproduce the CI cause.

## Next bounded diagnostic, preserving assertions

`probe.js` is an outside-app proposal to capture the exact original trio with before/after camera, geometry versions, flora-pass and texture-residency counters. Repeat at the same two original views, once naturally and once after the existing synchronous step/settle call, under matching desktop/published conditions. Compare changed-cell locations with layers only if a residual reproduces. This is not another full smoke or a new production mode.

If a pending async transaction lands between baseline and restored snapshots, establish an explicit pose-readiness barrier before the baseline: actual flora completion and stable texture readiness, then verify those state fingerprints remain fixed through the trio. Keep all current pixel thresholds. A remaining residual after identical fingerprints needs further renderer/geometry/material evidence; it must not be waved away as noise or repaired by loosening limits. No application patch is justified by the presently missing attribution alone.


## Authorized bounded follow-up

One actual published desktop probe subsequently completed the original yard trio after106s cold boot/entry. Yard effect mean3.804/worst79 and restored mean0/worst0 pass the original thresholds. Camera, geometry/layer, flora-pass and texture-residency fingerprints match baseline/restored; no async change was observed. This does not reproduce the CI yard red or establish its cause. The confidence trio did not complete before the175s deadline. Browser-close cleanup stalled and overran the requested budget; the owned11-process probe tree was forcibly stopped. There is no confidence verdict and no new readiness-code recommendation from this run. See `actual-summary.json` and full `actual-published-desktop.json`. No full stage/smoke verdict is claimed.
