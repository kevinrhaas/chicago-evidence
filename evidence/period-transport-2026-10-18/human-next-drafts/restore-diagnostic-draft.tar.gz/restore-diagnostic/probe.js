// SPDX-License-Identifier: GPL-3.0-or-later
// Diagnostic proposal only. Not run, imported by the app, or a replacement gate.
export function captureState(a){
 const spread=a.flora?.stats?.spread,texture=a.textureResidency?.state;const camera=a.camera;const geometry=[];a.scene3d.traverse(o=>{if(!o.isMesh)return;geometry.push({id:o.id,name:o.name,visible:o.visible,layers:o.layers.mask,geometry:o.geometry.id,count:o.geometry.drawRange.count,attributes:Object.fromEntries(Object.entries(o.geometry.attributes).map(([n,v])=>[n,{count:v.count,version:v.version}]))});});return{camera:camera?{position:camera.position.toArray(),quaternion:camera.quaternion.toArray(),projection:camera.projectionMatrix.toArray()}:null,flora:{inFlight:a.flora?.inFlight?.(),landings:spread?.landings,drained:spread?.drained,abandoned:spread?.abandoned,passes:spread?{...spread.passes}:null},textures:texture?{pending:texture.pending,uploads:texture.uploads,evictions:texture.evictions,redecodes:texture.redecodes,resident:texture.resident,residentBytes:texture.residentBytes}:null,geometry};
}
function distance(a,b){let sum=0,worst=0;for(let i=0;i<a.cells.length;i++){const d=Math.abs(a.cells[i]-b.cells[i]);sum+=d;worst=Math.max(worst,d);}return{mean:sum/a.cells.length,worst};}
export async function restoreTrio(a,{kind='yard',settle=false}={}){
 const snapshots=[],signatures=[];a.setAnimationHold(true);try{
  // This is a proposed experiment, not an assertion that settling fixes CI.
  // Infinity step finishes the current pose's flora work; texture residency
  // readiness must still be measured, not forced into another configuration.
  if(settle){a.step();a.flora?.settle?.();}
  const capture=async()=>{const before=captureState(a);const image=await a.capture(kind==='yard'?96:12);const after=captureState(a);snapshots.push({before,after});signatures.push(image);};
  await capture();if(kind==='yard')a.enclosures.group.visible=false;else a.setConfidenceView(true);await capture();if(kind==='yard')a.enclosures.group.visible=true;else a.setConfidenceView(false);await capture();return{kind,settle,snapshots,signatures,effect:distance(signatures[0],signatures[1]),restoration:distance(signatures[0],signatures[2]),thresholds:kind==='yard'?{effect_mean_min:.3,effect_worst_min:6,restored_mean_max:.02,restored_worst_max:1}:{effect_mean_min:.6,effect_worst_min:6,restored_mean_max:.1,restored_worst_max:3}};
 }finally{if(kind==='yard')a.enclosures.group.visible=true;else a.setConfidenceView(false);a.setAnimationHold(false);}
}
