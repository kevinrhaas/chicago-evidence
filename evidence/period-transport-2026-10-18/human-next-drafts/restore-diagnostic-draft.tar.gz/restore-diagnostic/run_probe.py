import json,pathlib,time,signal,hashlib
from playwright.sync_api import sync_playwright
P=pathlib.Path(__file__).parent;out=P/'actual-published-desktop.json';start=time.monotonic();report={'status':'running','scope':'ONE bounded desktop published restoration diagnostic; not full smoke or PR attribution','url':'http://127.0.0.1:8782/chicago/site/4d/walk/?year=1835&keep-geometry=1','viewport':[1280,800],'trios':[],'page_errors':[]}
def save():report['wall_seconds']=time.monotonic()-start;out.write_text(json.dumps(report,indent=2)+'\n')
def limit(signum,frame):raise TimeoutError('175s diagnostic time budget reached')
signal.signal(signal.SIGALRM,limit);signal.alarm(175)
try:
 with sync_playwright()as pw:
  browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
  try:
   page=browser.new_page(viewport={'width':1280,'height':800},device_scale_factor=1,has_touch=False);page.on('pageerror',lambda e:report['page_errors'].append(str(e)));page.set_default_timeout(45000);page.goto(report['url'],wait_until='domcontentloaded');page.wait_for_function('window.__chicago4d?.ready===true',timeout=90000);print('ready',time.monotonic()-start,flush=True)
   page.wait_for_function("window.__chicago4d.welcome?.state==='welcome'||window.__chicago4d.welcome?.state==='world'",timeout=30000)
   page.evaluate("""()=>{const a=window.__chicago4d;if(a.welcome.state==='welcome')a.welcome.enter('spawn');document.exitPointerLock?.();const help=document.getElementById('control-help');if(help&&!help.hasAttribute('hidden'))document.getElementById('control-help-gotit')?.click();}""")
   page.wait_for_function("window.__chicago4d.welcome.state==='world'",timeout=20000);page.evaluate("async()=>{window.restoreDiagnostic=await import('/shared/transport-restore-diagnostic/probe.js');}")
   report['boot_seconds']=time.monotonic()-start;report['build']=page.evaluate("()=>window.__chicago4d.build??null");save()
   for kind in['yard','confidence']:
    if kind=='yard':page.evaluate("()=>window.__chicago4d.goToTarget({kind:'intersection',local_e:-127.7,local_n:-292})");page.wait_for_timeout(350)
    else:page.evaluate("()=>window.__chicago4d.frame('sauganash_hotel',26)");page.wait_for_timeout(250)
    result=page.evaluate('(kind)=>window.restoreDiagnostic.restoreTrio(window.__chicago4d,{kind,settle:false})',kind);report['trios'].append(result);save();print(kind,result['effect'],result['restoration'],'elapsed',time.monotonic()-start,flush=True)
   report['status']='completed bounded original-trio diagnostic';save()
  finally:browser.close()
except Exception as error:report['status']='bounded diagnostic incomplete';report['error']=str(error);save();print(type(error).__name__,str(error),flush=True)
finally:signal.alarm(0)
