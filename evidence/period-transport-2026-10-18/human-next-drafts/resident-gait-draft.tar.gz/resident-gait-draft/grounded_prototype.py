#!/usr/bin/env python3
"""Original mechanical motion study from actual prepared limbs/shoe soles. No bpy."""
import copy,json,math,pathlib,hashlib
import diagnose as source
R=source.R;P=pathlib.Path(__file__).parent
SPEED=.6;DURATION=1.2;DUTY=.62;LIFT=.065;DROP=.04;BOB=.005;SAMPLES=1001
recipe=json.loads((R/'data/humans/recipes/worker_1835.json').read_text());scale=float(recipe.get('height_scale',1))
def translation(v):
 m=source.ident()
 for i in range(3):m[i][3]=v[i]
 return m
def trajectory(phase,offset):
 q=(phase+offset)%1;h=SPEED*DURATION*DUTY/2
 if q<DUTY:return [0,h-SPEED*DURATION*q],True,q
 u=(q-DUTY)/(1-DUTY);smooth=u*u*u*(10+u*(-15+6*u));m=-SPEED*DURATION*(1-DUTY)
 return [LIFT*math.sin(math.pi*u)**2,-h+m*u+(2*h-m)*smooth],False,q
report={'status':'outside-app mechanical grounded gait prototype; not human biomechanics or actual exported motion','engineering_parameters':{'speed_m_s':SPEED,'cycle_duration_s':DURATION,'stance_fraction':DUTY,'swing_lift_m':LIFT,'mean_pelvis_lowering_m':DROP,'pelvis_lowering_cosine_amplitude_m':BOB,'samples_per_cycle':SAMPLES,'provenance':'original engineering choices, not motion-capture or historical measurements'},'builder_sha256':hashlib.sha256((R/'tools/human_teamster_blend.py').read_bytes()).hexdigest(),'variants':{}}
for variant in recipe['proof_variants'][:2]:
 bodypath=R/variant['body_input'];body=json.loads(bodypath.read_text());bones={b['name']:b for b in body['skeleton']};soles={};joints={}
 for side in ['l','r']:
  pts=[p for mesh in body['meshes']for p,w in zip(mesh['positions_m'],mesh['weights'])if sum(v for b,v in w.items()if b in('foot_'+side,'ball_'+side))>.35 and p[1]<.16]
  xmin,xmax=min(p[0]for p in pts),max(p[0]for p in pts);zmin,zmax=min(p[2]for p in pts),max(p[2]for p in pts);cx=(xmin+xmax)/2;cz=(zmin+zmax)/2;rx=(xmax-xmin)/2+recipe['shoe_offset_m']/scale;rz=(zmax-zmin)/2+recipe['shoe_offset_m']/scale
  sole=[]
  for k in range(20):
   ang=2*math.pi*k/20;z=cz+rz*math.sin(ang);blend=max(0,min(1,(z-bones['ball_'+side]['head_m'][2]+.04)/.08));sole.append(([v*scale for v in [cx+rx*math.cos(ang),0,z]],{'foot_'+side:1-blend,'ball_'+side:blend}))
  sole.append(([cx*scale,0,cz*scale],{'foot_'+side:1}));soles[side]=sole
  h,k,a=([v*scale for v in bones[n+'_'+side]['head_m']]for n in['thigh','calf','foot']);joints[side]=(h,k,a,math.dist(h,k),math.dist(k,a))
  # Solver below is deliberately sagittal. Refuse another rig's lateral/bent rest frame.
  if max(abs(h[0]-k[0]),abs(h[0]-a[0]),abs(h[2]-k[2]),abs(h[2]-a[2]))>1e-6:raise ValueError('actual leg is not sagittal/vertical as assumed; generalize solver')
 frames=[];groups={};maxheight=0;maxdrift=0;minimum=math.inf;maxankleerror=0;unreachable=[];airgaps=0;kneedirections=[];anglemax=0;cyclepoints=[]
 for sample in range(SAMPLES):
  phase=sample/(SAMPLES-1);time=phase*DURATION;lowering=DROP+BOB*math.cos(4*math.pi*phase);Dpelvis=translation([0,-lowering,0]);frame={'phase':phase,'time_s':time,'pelvis_translation_world_m':[0,-lowering,0],'legs':{}};outpoints={};support=0
  for side,offset in [('l',0),('r',.5)]:
   (lift,z),stance,q=trajectory(phase,offset);h,k,a,L1,L2=joints[side];hp=[h[0],h[1]-lowering,h[2]];target=[a[0],a[1]+lift,a[2]+z];dy=target[1]-hp[1];dz=target[2]-hp[2];distance=math.hypot(dy,dz);cosbend=(distance*distance-L1*L1-L2*L2)/(2*L1*L2)
   if not -1<=cosbend<=1:unreachable.append({'phase':phase,'side':side,'distance_m':distance,'limb_length_m':L1+L2});continue
   knee=math.acos(cosbend);hip=math.atan2(-dz,-dy)-math.atan2(L2*math.sin(knee),L1+L2*math.cos(knee));ankle=-hip-knee;anglemax=max(anglemax,knee)
   Dthigh=source.mm(Dpelvis,source.pivot_x(h,hip));Dcalf=source.mm(Dthigh,source.pivot_x(k,knee));Dfoot=source.mm(Dcalf,source.pivot_x(a,ankle));deform={'foot_'+side:Dfoot,'ball_'+side:Dfoot}
   computed=source.transform(Dfoot,a);maxankleerror=max(maxankleerror,math.dist(computed,target));knee_world=source.transform(Dthigh,k);v=[target[i]-hp[i]for i in range(3)];t=sum((knee_world[i]-hp[i])*v[i]for i in range(3))/sum(x*x for x in v);kneedirections.append(knee_world[2]-(hp[2]+t*v[2]))
   local=[source.skin(p,w,deform)for p,w in soles[side]];world=[[p[0],p[1],p[2]+SPEED*time]for p in local];outpoints[side]=local;minimum=min(minimum,min(p[1]for p in world))
   if stance:
    support+=1;maxheight=max(maxheight,max(abs(p[1])for p in world));cycle=math.floor(phase+offset);key=(side,cycle)
    if key not in groups:groups[key]=world
    for old,new in zip(groups[key],world):maxdrift=max(maxdrift,math.dist(old,new))
   frame['legs'][side]={'support':stance,'local_phase':q,'hip_world_x_increment_rad':hip,'knee_world_x_increment_rad':knee,'ankle_world_x_increment_rad':ankle,'ball_world_x_increment_rad':0,'ankle_target_local_m':target,'lowest_sole_world_y_m':min(p[1]for p in world),'knee_forward_pole_deviation_m':kneedirections[-1]}
  if not support:airgaps+=1
  frames.append(frame);cyclepoints.append(outpoints)
 if unreachable:raise ValueError('unreachable targets: '+str(unreachable[:2]))
 closure=max(math.dist(a,b)for side in['l','r']for a,b in zip(cyclepoints[0][side],cyclepoints[-1][side]));pelvisclosure=math.dist(frames[0]['pelvis_translation_world_m'],frames[-1]['pelvis_translation_world_m'])
 motion={'format':'original source-frame incremental pose recipe v0.1','person_reference_id':variant['person_reference_id'],'body_input':variant['body_input'],'body_sha256':hashlib.sha256(bodypath.read_bytes()).hexdigest(),'frame':{'units':'metres','up':'+Y','forward':'+Z'},'clip':'walk_grounded_mechanical_study','root_motion':'in place; actor advances +Z at speed_m_s','speed_m_s':SPEED,'duration_s':DURATION,'engineering_parameters':report['engineering_parameters'],'support_definition':'left q=phase mod1; right q=(phase+.5)mod1; supported iff q<.62. Group by unwrapped floor(phase+offset) before measuring planted drift.','retargeting':'For original rigid authoring, convert each world-X incremental rotation into the actual rest-bone basis as current builder does. Pelvis world translation must be converted into its actual rest-local basis. Do not insert these world vectors directly as arbitrary bone-local translations.','interpolation':'dense sampled recipe; bake explicit interpolation then remeasure exported skin. No BEZIER fidelity assumed.','frames':frames}
 (P/(variant['id']+'.grounded-motion.json')).write_text(json.dumps(motion,separators=(',',':'))+'\n')
 metrics={'person_id':variant['person_reference_id'],'body_sha256':motion['body_sha256'],'actual_source_sole_points_per_side':21,'phase_samples':SAMPLES,'support_frames':{'left':sum(f['legs']['l']['support']for f in frames),'right':sum(f['legs']['r']['support']for f in frames)},'unreachable_targets':len(unreachable),'max_ankle_target_error_m':maxankleerror,'max_planted_sole_vertex_world_drift_m':maxdrift,'max_supported_sole_height_error_m':maxheight,'minimum_sole_height_all_phases_m':minimum,'phases_without_support':airgaps,'in_place_sole_loop_closure_m':closure,'pelvis_loop_closure_m':pelvisclosure,'minimum_knee_forward_pole_deviation_m':min(kneedirections),'maximum_knee_flexion_rad':anglemax,'scale_or_stretch_applied':False,'metrics_are':'actual prepared source LBS+original shoe sole reconstruction, NOT actual exported GLB skin'}
 assert maxankleerror<1e-10 and maxdrift<1e-9 and maxheight<1e-9 and minimum> -1e-9 and airgaps==0 and closure<1e-10 and min(kneedirections)>0
 report['variants'][variant['id']]=metrics
(P/'grounded-contact-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['variants'],indent=2))
