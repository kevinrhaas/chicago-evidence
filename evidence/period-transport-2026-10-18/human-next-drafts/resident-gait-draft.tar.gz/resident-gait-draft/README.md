# Resident idle/walk: actual prepared-rig contact diagnostic

Outside-app study,2026-10-18. No Blender/bpy import, browser, publication or app mutation. `diagnose.py` reads the actual current builder and prepared bodies, hashes inputs, reconstructs exact authored shoe sole vertices/weights, and evaluates source-authored key poses by linear blend skinning. Run `python diagnose.py`; writes only this directory's JSON/report log. It refuses if the source thigh/calf/key-loop/speed formulas change. Existing residents remain OtisBardwell `rc_bardwell_otis` (engineering age25 within reconstructed20–29 band) and JosephDufresne `rc_dufresne_joseph` (engineering age35 within30–39 band). Neither body parameter is a documentary exact age or likeness.

## What was actually evaluated

Source: `/workspace/chicago/chicago/4d/tools/human_teamster_blend.py`, actual recipe `data/humans/recipes/worker_1835.json`, and actual recipe-selected `assets/authored/humans/makehuman_hm08/prepared_adult_25.json` / `prepared_adult_35.json`. Input hashes and exact source paths are in `source-keyed-contact-report.json`.

Actual source motion is an original synthetic fixture:

- Walk length30frames at30fps, speed metadata1.0m/s, keys frames1,6,11,16,21,26,31.
- Thigh world-X angle18°×sin(phase), right side phase offsetπ.
- Calf world-X angle−25°×max(0,sin(phase)), same offsets.
- Feet/balls have no counter-rotation, root/pelvis have no travel/contact compensation. Small spine motion does not propagate into thigh descendants (they branch at pelvis).
- Builder converts these world rotations into each actual rest-bone basis by conjugation. For the relevant lower-limb linear skinning deformation, the rest orientation cancels: child deformation equals parent deformation times `T(actual_head) × R_worldX(angle) × T(-actual_head)`. The diagnostic uses that exact identity and actual parent graph, rather than inventing bone lengths or guessing bone roll. Source-to-Blender axis conversion is a rotation about X, so the lower-limb world-X rotations commute with it.

Actual shoe sole construction is reproduced, not replaced by an ankle/socket proxy: source candidate predicate is foot/ball influence sum>0.35 and source vertexy<0.16m; source bounds plus recipe shoe offset define the elliptical sole.20 rim points and original center vertex per side are evaluated with the original source's longitudinal foot/ball blending. The builder also duplicates the rim for a separate sole UV island; positions and weights are identical, so duplicates do not change extrema. Prepared foot-body vertices with the corresponding source weight/height filter are separately sampled. No triangle, weight or body source was edited.

## Measured keyed-pose results

| Resident body | Actual hip→knee / knee→ankle | Maximum authored sole height at keys | Both feet unsupported |
|---|---|---|---|
|Otis, prepared25|0.420784m /0.439549m|88.658mm|Frames6,11,21,26: minimum sole point11.11–15.91mm above ground on each side|
|Joseph, prepared35|0.415276m /0.444140m|88.991mm|Frames6,11,21,26: minimum sole point11.06–16.17mm above ground on each side|

At frames1,16,31 both soles return to y≈0. Numerical negative residue is under1e-14m; no sampled key has penetration below−5mm. Each sole center is>10mm airborne at4of7keys. **Lack of penetration is not grounded walking:** both feet being wholly clear of ground together at the intermediate authored keys is the substantive defect in the nominal walking pose.

Idle lower-limb pose leaves the authored shoe soles at y0 under the same assumptions. This establishes a source-math rest-ground plane, not actualGLB modifier/skin/render qualification. Body mesh foot samples are recorded separately; footwear surface is the appropriate outer contact geometry.

The JSON records root-compensated centerz using declared1m/s. Full-cycle range is explicitly **not called stance drift** because the clip defines no planted intervals. At frames6and11 the sinusoidal angles are equal and the foot's local pose repeats while the actor's assumed world root advances0.1667m. If that phase were designated planted, it would slide by that amount; without a declared stance phase, a blanket “foot-slip mm” score would be misleading. Introduce an explicit contact trajectory before setting such a gate.

## Quantified reach constraint: rotations alone cannot fix this

In both actual prepared rigs the hip and ankle rest centers are vertically aligned and hip-to-ankle distance is effectively the **sum of segment lengths**: a fully straight rest leg. Any nonzero horizontal ankle excursion at fixed hip/restankle height therefore exceeds reach.

For a **proposed engineering**1m/s,1s-cycle walk with62%stance, a planted foot travels0.62m relative to the moving root, i.e.±0.31m around midstance. Keeping current fixed hip height would overreach by about **54.15mm(Otis)** / **54.20mm(Joseph)** at endpoints. To keep endpoint reach≤99.5%of actual limb length, the calculated pelvis lowering is recorded in JSON (about62mm). This is a feasibility calculation, not a measured biological gait or a recommended constant crouch. It demonstrates why simply increasing calf amplitude, stretching bones or renaming the existing sinusoid “grounded” is inadequate.

## Concrete correction proposal

1. **Declare a contact cycle and actor speed together.** Use a reconstructive1s/1mps/62%stance study only as an explicit engineering prototype, or select shorter/slower initial travel. Preserve a single `speed_m_s`, cycle duration and stride-distance relation; no independent arbitrary root speed.
2. **Define a sole-frame trajectory, not a calf-angle sinusoid.** During stance, hold the same chosen contact point's **world** position fixed: its source-localz decreases at actor speed. During swing, return with smooth lift and continuous endpoint velocity. Record heel/toe support intervals; a flat-foot first study is acceptable as a labeled simplification, not photoreal heel-strike/toe-off.
3. **Solve reach with actual rig lengths and a pelvis trajectory.** The above reach deficit must be resolved by coordinated pelvis lowering/translation and a shorter step/duty cycle, not hidden nonuniform scale. Use actual hip/knee/ankle heads and a source-informed knee pole direction; clamp/reject unreachable targets and report that failure rather than stretch. If source knee anatomy/pole direction is ambiguous, inspect it before pinning an IK branch.
4. **Counter-rotate ankle/foot for a supported sole.** After hip/knee rotations, restore the desired foot-frame orientation in stance, then implement a bounded toe roll later. Driving the calf without ankle compensation tilts/raises the entire sole. Preserve ball weights and validate the **outer footwear vertices**, not only bone centers.
5. **Bake explicit interpolation.** Current builder does not set FCurve interpolation; default quaternion-componentBEZIER and exporter sampling cannot be reproduced by assuming a continuous analytic sine between keys. Author/bake a dense trajectory with an explicit interpolation policy and validate the resultant exported pose. Keep loops exact at boundaries and transitions.
6. **Measure on actual exported skin onceCIproduces it.** Sample world-space sole vertices over at least1001times, compensate using actual actor travel, and group drift by declared support interval/foot/consistent vertex. Check ground penetration, all-foot air gaps, contact drift, knee extension/pole flips, loop closure and cross-fades. Suggested prototype contact targets may be20mm drift and5mm penetration, but these are engineering acceptance choices requiring justification, not historical measurements or already passed gates.

## What this can and cannot establish

This diagnostic identifies a real source-keyed contact defect using actual prepared hierarchy and weights, with exact original shoe geometry. It can guide a better original motion study before spending a Blender/CIbake. It does **not** verify actual exported adultGLBs, inverse-bind canonicalization, Blender FCurve interpolation, mesh modifiers/LODdecimation, morphs, skin deformation in browser or photographic gait quality. No localBlenderimport/runtime was used. Actualcanonicalbodyexport is still pendingCIqualification; do not attach these receipts to a claim that adult25/35exportedskins passed contacts.

No new external biomechanical source was read. Existing historical sources discussed before concern equine motion, not human gait, and must not be cited as evidence for the62%human stance choice. The correction is transparent mechanical reconstruction until a reusable licensed human motion/reference source is acquired. Photographic human gait remains open.
