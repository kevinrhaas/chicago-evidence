# Executed grounded mechanical gait prototype

Outside-app prototype,2026-10-18. This follows the source-keyed diagnostic in README.md with an **actual numerical motion generator and1001-phase contact checks**, not another future-work proposal. No Blender/bpy, actualGLB export, browser, CI, app edit or publication. Existing residents remain OtisBardwell `rc_bardwell_otis` and JosephDufresne `rc_dufresne_joseph`; prepared age25/35 parameters remain reconstructed body choices, not documentary exact ages.

Run:

```
python grounded_prototype.py
python verify_prepared_foot_skin.py
```

The first command uses Python stdlib and the existing outside-app source diagnostic helpers. The second independent prepared-foot-body evaluator additionally uses installed NumPy. Both write only this directory. No runtime package installation or source-body mutation is needed.

## Motion actually generated

`bardwell_otis_1835.grounded-motion.json` and `dufresne_joseph_1835.grounded-motion.json` each contain1001dense poses, actual input hash/path/personID, metre/Y-up/+Z frame, pelvis translation and per-leg hip/knee/ankle/ball incremental world-X rotation values. These are source-frame instructions intended to be conjugated into each actual rest-bone basis, as the current builder already does. Pelvis world translation must also be converted to its actual rest-local basis when authored; copying these values into arbitrary bone-local channels is **not** equivalent.

Engineering choices, explicitly **not sourced human biomechanics/motion capture**:

- Speed0.6m/s; cycle1.2s; stance fraction0.62; left/right phase offset0.5.
- Actor supplies world+Z travel at that speed; the clip stays in place.
- Mean pelvis lowering40mm, with±5mm cosine variation twice percycle.
- Foot swing lift65mm; stance soles held flat; ball incremental rotation0.
- During each support interval, local contactz decreases linearly with actor speed. Swingz uses a quintic return with matching−speed endpoint velocity and zero endpoint acceleration; swingheight uses sin² lift. This is an original slow mechanical walk, not a claimed natural heel-toe gait.
- Actual sagittal two-link lengths and hip/knee/ankle positions are read from each prepared rig. The solver refuses a rest leg with lateral/bent offsets outside its documented assumptions. It solves the forward-knee branch, rejects unreachable targets, and **never scales/stretches a limb**. Ankle counter-rotation cancels accumulated hip/knee rotation so the foot/ball skin frame stays level.

Support is explicitly defined by leftq=`phase mod1`, rightq=`(phase+.5)mod1`; stance iffq<.62. In the displayedcycle this is left[0,.62), right[0,.12)and[.5,1], with wraparound. Samples at the cycle endpoint duplicate the nextcycle start. World drift is grouped by side and **unwrapped support-cycle index**, so it never compares the end of one step with the planted point of another.

## Actual source-geometry checks

The exact existing shoe generator's20rim vertices plus central sole vertex are reproduced for each foot with its original foot/ball skin weights. Geometry is derived from actual prepared-source foot bounds and current shoeoffset; all1001poses are evaluated by LBS after hip/knee/ankle transforms and actor travel. This checks outer footwear surface, not only ankle targets.

`grounded-contact-report.json` records:

| Measurement | Otis25 | Joseph35 |
|---|---:|---:|
|Sampled phases|1001|1001|
|Unreachable targets|0|0|
|Maximum ankle target residual|2.92e−16m|2.64e−16m|
|Maximum planted sole-vertex world drift|3.36e−16m|3.54e−16m|
|Maximum supported sole-height error|2.45e−16m|2.38e−16m|
|Phases with no support foot|0|0|
|In-place sole/pelvis loop closure|0m|0m|
|Minimum forward-knee deviation from hip→ankle line|53.40mm|53.22mm|
|Maximum knee flexion|0.9811rad(~56.2°)|0.9820rad(~56.3°)|

The near-zero contact errors are the expected floating-point residual of deliberately solved flat-foot constraints. They demonstrate this source-frame mechanical assembly, **not photographic motion quality**. There is no hypothesis that exact floating-point contact proves realistic weight transfer, balance, footwear deformation or body motion.

A second independent evaluator (`verify_prepared_foot_skin.py`) samples **1243actual prepared body-foot vertices per side**, retaining their actual calf/foot/ball influences, across the same1001poses. It found no point below−5mm; minimum y is only floating-point residue around−2.4e−16m. It discovered one selected vertex per foot carries a0.002weight on the opposite ball joint; the evaluator includes the opposite-foot transform rather than ignoring or repairing that existing weight. This observation is not an authorization to rewrite source weights. Results are in `prepared-foot-skin-contact-report.json`.

No thigh/knee/head position was invented. Actual Otis lengths are0.420784/0.439549m; Joseph0.415276/0.444140m. All rotations/translations use these source heads and actual hierarchy. No scale channel or inverse-bind adjustment is emitted by the motion generator.

## Integration and unpassed gates

This is a **reusable dense pose recipe**, not an exportedanimationGLB. The current source action uses different cadence and default FCurve interpolation; these receipts do not validate that older clip. A future integration should author explicit pose keys/interpolation at the selected duration (1.2s=36frames at30fps), ensure the full1001-phase ground/contact behavior survives baking/resampling, then rerun contacts on **actual exported skinned vertices** after all frame/skin repairs, mesh modifiers and LODs.

Remaining open:

- Actual canonicalBlender rest-basis/pose-channel construction and sampling; no bpy objects have been evaluated here.
- ActualGLB inverse-bind/weight deformation, exporter interpolation and browser motion; sourceLBS is not their substitute.
- Knee visual anatomy, pelvis/torso balance, weight shifts, arm swing, foot roll/heel-strike/toe-off, transitions, curved paths and variable speeds.
- Body/shoe collisions or foot skin outside the shoe; checking foot ground penetration does not qualify all clothing fitting.
- Motion/photographic reference acquisition and visual comparison. No new source is cited for the engineering dutycycle, pelvisdrop or knee-anglechoices.
- Continuous extrema between1001samples and different rigproportions; the generator refuses its specific rest-frame assumptions rather than pretending universal retargeting.

Original flat-foot/slow-cadence simplifications and exact chosenparameters must be recorded as reconstruction when integrated. No resident's actual walk is attested by this fixture. Passing its sourcecontactchecks must never close photographic gait acceptance or replace a reviewed published/mobile animation test.
