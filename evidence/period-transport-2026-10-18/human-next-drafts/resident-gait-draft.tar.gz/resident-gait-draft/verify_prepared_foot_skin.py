#!/usr/bin/env python3
"""Independent source foot-body skin sampling; actual GLB and Blender remain untested."""
import json,pathlib,math
import numpy as np
import diagnose as source
P=pathlib.Path(__file__).parent;R=source.R;recipe=json.loads((R/'data/humans/recipes/worker_1835.json').read_text());scale=recipe.get('height_scale',1);report={}
for variant in recipe['proof_variants'][:2]:
 body=json.loads((R/variant['body_input']).read_text());bones={b['name']:b for b in body['skeleton']};motion=json.loads((P/(variant['id']+'.grounded-motion.json')).read_text());samples={}
 for side in ['l','r']:
  selected=[([x*scale for x in p],w)for m in body['meshes']for p,w in zip(m['positions_m'],m['weights'])if sum(v for b,v in w.items()if b in('foot_'+side,'ball_'+side))>.35 and p[1]<.17]
  positions=np.array([p+[1.]for p,w in selected]);names=sorted(set(b for p,w in selected for b in w));weights={b:np.array([w.get(b,0)for p,w in selected])[:,None]for b in names};minimum=math.inf;supportminimum=math.inf;outofsupport=0
  allowed={'root','pelvis'}|{n+'_'+s for n in ['thigh','calf','foot','ball']for s in ['l','r']}
  if set(names)-allowed:raise ValueError('unexpected lower-foot weights; include true ancestor transforms '+str(set(names)-allowed))
  h,k,a=([v*scale for v in bones[n+'_'+side]['head_m']]for n in['thigh','calf','foot'])
  for frame in motion['frames']:
   leg=frame['legs'][side];pel=source.ident();pel[1][3]=frame['pelvis_translation_world_m'][1];thigh=source.mm(pel,source.pivot_x(h,leg['hip_world_x_increment_rad']));calf=source.mm(thigh,source.pivot_x(k,leg['knee_world_x_increment_rad']));foot=source.mm(calf,source.pivot_x(a,leg['ankle_world_x_increment_rad']));D={'root':source.ident(),'pelvis':pel,'thigh_'+side:thigh,'calf_'+side:calf,'foot_'+side:foot,'ball_'+side:foot};skin=np.zeros((len(selected),3))
   other='r'if side=='l'else'l';ol=frame['legs'][other];oh,ok,oa=([v*scale for v in bones[n+'_'+other]['head_m']]for n in ['thigh','calf','foot']);ot=source.mm(pel,source.pivot_x(oh,ol['hip_world_x_increment_rad']));oc=source.mm(ot,source.pivot_x(ok,ol['knee_world_x_increment_rad']));of=source.mm(oc,source.pivot_x(oa,ol['ankle_world_x_increment_rad']));D.update({'thigh_'+other:ot,'calf_'+other:oc,'foot_'+other:of,'ball_'+other:of})
   for n in names:skin+=(positions@np.asarray(D[n]).T)[:,:3]*weights[n]
   low=float(skin[:,1].min());minimum=min(minimum,low)
   if leg['support']:supportminimum=min(supportminimum,low)
   if low<-.005:outofsupport+=1
  samples[side]={'prepared_foot_body_vertices':len(selected),'actual_influencing_bones':names,'minimum_vertex_y_all_phases_m':minimum,'minimum_vertex_y_supported_phases_m':supportminimum,'sampled_phases_below_minus_5mm':outofsupport,'sample_count':len(motion['frames']),'note':'source mesh and prepared LBS weights; no exported GLB/LOD proof'}
 report[variant['id']]=samples
(P/'prepared-foot-skin-contact-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
