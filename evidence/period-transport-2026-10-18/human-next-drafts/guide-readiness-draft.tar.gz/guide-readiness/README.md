# Desktop stage6 controls-help diagnosis

Read-only app assessment, 2026-10-18. No app modifications or full/staged smoke rerun.

Standing record queried first: `node tools/dev-smoke-state.mjs ask --viewport desktop --stage 6`. Latest stored FAIL Oct8 has piles/frontage failures on a different smoke tree; last stored pass Oct3. This neither attributes nor clears the current failure.

Cancelled CI log `/tmp/transport-desktop-full-cancelled-39164186323.log` at21:51:21 reports Guide selected/open, pointerlock backend correct, but no sheet/scheme/rows/keys. Neighboring trusted clicks cost36.9s and15.8s. Those costs show a slow environment, not proof of import timing. No captured guide import exception/network timing distinguishes delayed module from swallowed import/mount error.

Concrete implementation mismatch:

- tools/smoke_renderer.mjs:10659 selects Guide;10660 waits only10s for #guide-controls, silently catches timeout, then reads missing DOM.
- renderers/web/js/apps/guide.js:load returns screen immediately. mount launches dynamic import without returning it; select awaits outer mount only. Thus an awaited navigator.select does not mean controls sheet is ready.
- guide.js comment already states first lazy load exceeded10s on a starved runner (T2620).
- SAME T2661 stage12 check tools/smoke_renderer.mjs:13584 already waits60s, explicitly explaining that old10s budget was insufficient. Stage6 retained old budget.
- guide.js catches import/mount exceptions silently; therefore current CI failure is not conclusively diagnosed as delay without additional telemetry.

ONE bounded browser helper `probe.cjs` serves unchanged actual modules and mounts Guide in real Chromium DOM without town/WebGL rendering. Network route deliberately delays only guide-view.js12s. Result `probe.log`: mount1.1ms returns no Promise; at10s sheetabsent; at12.117s keyboard sheet has14rows/19keys, zero pageerrors. Browser/serverclose in finally. This proves an exact false failure is possible from known async lifecycle, not that CI delay was12s. An initial helper startup failed before any browser because old Playwright dependency path was absent; changed outsidehelper to existing shared installation, no dependency installation.

Proposed bounded repair for root review: bring stage6 sheet-readiness wait to existing stage12's60s, retain every current backend/scheme/rows/keys/inView/overflow/snake assertion. Capture timeout message and module/request errors rather than throwing them away. Do not claim renderer UI fixed from this. User-facing load failure reporting is separate optional app work; no source edits authorized here.
