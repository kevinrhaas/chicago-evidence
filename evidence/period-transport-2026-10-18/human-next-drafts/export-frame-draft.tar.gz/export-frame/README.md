# Authored rigid-rig joint-frame residue repair — review draft

Outside-app Python-stdlib draft only. No independent canonical authored-bpy verification has happened in this draft. Root must implement and execute that premise verification before production use; CI execution is outstanding. No Blender installation, production source rewrite, contract-tolerance change or fixture-pipeline change. This module handles **tiny exported joint TRS scale residue only**; skin/inverse-bind canonicalization belongs to the separate skin draft and is not performed here.

## Why this narrowly scoped operation can be reviewed

Root reports the authored Blender4.5.3 rig's objects/pose bones are unit scale and have no constraints, drivers or authored scale FCurves. Exported relative-matrix inversion/decomposition can still emit a thigh scale `[1,0.9999999404,0.9999979734]`. This helper can remove that representational residue only when the caller independently verifies the authored rigid-rig premise and supplies an input-hash-bound proof. It is **not** a way to infer rigid authoring from an arbitrary GLB or repair source-asset nonuniform scaling.

`human_frame_residue.repair(raw_glb_bytes, proof_dict)` returns `(output_bytes, receipt_dict)`; CLI requires input, separate output, `--proof`, `--receipt`. Proof must carry exact `input_sha256`, nonempty `verified_by` and `verification_reference`, plus explicit true booleans for `rig_object_scales_unit`, `pose_bone_scales_unit`, `no_constraints`, `no_drivers`, `no_scale_fcurves`, `authored_rigid_rig`. It cannot verify a Blender authoring claim itself. Test proofs are explicitly test-harness attestations, **not independent Blender verification**.

Joint scales are removable only if every finite component differs from1 by at most **32×2^-23 = 0.000003814697265625**. A scale1.01 fails. All joint matrix transforms fail: the helper will not decompose them. Nonjoint TRS scales are **never modified**: they may remain within the existing **1e-6** frame-node guard, including real fixture sockets `[1.0000001192,1,1]`; larger/nonfinite nonjoint scales fail. This clarification preserves lawful existing sockets without widening the contract.

Scale-animation channels may be removed only for skin-joint targets with LINEAR/STEP interpolation, nonsparse unextended embedded-buffer0 FLOAT VEC3 outputs and every decoded sample unit-near under the same cap. CUBICSPLINE, sparse, extended/compressed accessor/view encodings, nonjoint animation scales and nonfinite/large sample values fail. Empty-after-removal clips fail rather than silently creating invalid animations. Non-scale channels remain; sampler indexes are remapped only where required by removing unused scale samplers. Existing fixture actually has unit-near exported scale channels on56joints in each clip, so these are exercised, not an invented nonexistent feature.

## Preservation and quantified limits

All non-JSON chunks, including the **complete BIN chunk**, are preserved byte-for-byte, with hashes in the receipt. Meshes, skin objects (including inverse-bind accessor identity), accessors, buffer views and buffer descriptors are asserted unchanged. No weight, index, inverse-bind or mesh-position byte changes. Nonjoint nodes remain JSON-equivalent. Changes are enumerated by joint/node or clip/channel/sample/accessor. The1e-6 production frame guard is unchanged and must run again on repaired output.

`worlds` computes rest-world node matrices from the actual graph. Receipt lists every joint's translation delta and linear-matrix Frobenius delta. For any point within1m of that joint's local origin, displacement is bounded by `translation_delta + ||linear_delta||_F × 1m` (triangle/Cauchy-Schwarz bound). That is a **joint-frame point bound**, not a bound on arbitrary skinned vertices, whose inverse-bind offsets/weights matter. Keeping inverse binds unchanged while changing tiny joint scales intentionally introduces tiny rest-pose mismatch; exact skin deformation equivalence is **not claimed**. Root should compare deformed skin/browser output and use its separate validated skin handling as needed. The explicit premise/cap plus measured tiny changes make this a narrowly bounded numerical cleanup, not a general normalization theorem.

## Actual test results

Portable integration files are `human_frame_residue.py` and `test_human_frame_residue.py`. Run `C4D_HUMAN_FRAME_FIXTURE=/path/to/assets/humans/c4d_fixture.lod0.glb python -m unittest test_human_frame_residue -v` from this draft directory. When copied under project `tools/`, the default fixture path is `Path(__file__).resolve().parents[1]/assets/humans/c4d_fixture.lod0.glb`; the environment override supports outside-app review. The unittest suite performs all mutations and checks in memory and writes no receipts/artifacts. `measure_clips.py` is a separate outside-app experiment, not the portable test, and regenerates the outside-app sample receipt when run. Actual input `/workspace/chicago/chicago/4d/assets/humans/c4d_fixture.lod0.glb` SHA256 `7890438683e54b989835960012a704f90a4253f5df51c8d4d41e7aec8cfda874`; original source file remains byte-identical. Tests operate on memory/copies in this outside-app directory.

- Actual baseline fixture: rest max joint-origin delta **0.0495µm**, max1m joint-frame point bound **0.3168µm**; nonjoint sockets preserved.
- Same actual fixture with exact reportedCIscale injected into actual `thigh_l` node52: rest max joint-origin delta **0.2494µm**, max1m joint-frame point bound **2.3364µm**. Input/repaired GLB copies and detailed receipt saved.
- Idle/walk sampled101frames each with independent TRS animation evaluator: max joint-origin delta **0.0495µm / 0.0604µm**, max1m point bound **0.2030µm / 0.3506µm**. Actual existing scale channels override the injected static rest scale during these clips; therefore the smaller animated results must not be represented as a worst-case bound for the staticCIperturbation. Continuous extrema, deformed skin and render equivalence are not tested.
- Missing or mismatched proof,1.01, just-over-cap, nonfinite scale, joint matrices, nonjoint over1e-6, nonjoint scale animation, cubic/sparse animation and1.01animated samples all rejected. Legal LINEAR/STEP unit-near samples accepted. Full binary equality confirmed after each accepted repair. Python compilation clean.

Receipts: `actual-fixture.receipt.json`, `ci-scale-perturbation.receipt.json`, `animation-scale.receipt.json`, `test-results.json`, `clip-comparison.json`. These are actual executed test measurements, not productionCI receipts. No claim to have the unavailable failingCIartifact; the exact reported scale was injected into a real local fixture as requested.

## Integration requirements

1. Independently inspect actual authored bpy state before proof; never auto-assert booleans from output scale size.
2. Apply only to the new authored-body source-export path after export; do not alter the existing fixture pipeline or arbitrary licensed-source import path.
3. Keep a separate source/export hash and repair receipt; rerun unchanged contract guard, deformation/browser and Khronos validation.
4. Coordinate skin canonicalizer ordering explicitly. This helper deliberately never edits skins/IBMs/buffers, so do not claim it supplies their canonicalization.
5. Reject unsupported inputs rather than widening thresholds or silently erasing genuine animation scaling.

## Portable integration hardening follow-up

Twelve unittest cases (with per-case rejection subtests) pass on the real fixture using an environment-selected path. Added strict nonsparse/nonextended accessor, bufferView and buffer checks for scale outputs **and sample-time inputs**, embedded-only storage, nonnegative nonboolean index/count/offset/length bounds, aligned/limited strides, strictly increasing finite nonnegative times, nonjoint matrix column-scale checks at the unchanged1e-6 threshold, and preserved lawful nonjoint matrices. No nonjoint transform is rewritten. `repair` rejects unsupported transforms rather than decomposing matrices. The tests never modify the source fixture or write in-repository generated output. Older JSON test receipts are historical outside-app experiment receipts; they do not assert independent bpy verification or a production CI pass.
