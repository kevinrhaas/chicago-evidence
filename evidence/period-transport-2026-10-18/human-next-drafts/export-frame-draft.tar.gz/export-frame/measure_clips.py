#!/usr/bin/env python3
"""Independent fixture-only sampled comparison, including original unit-near scale channels."""
import copy,json,math,pathlib,struct
from human_frame_residue import parse,worlds
P=pathlib.Path(__file__).parent
before,chunks=parse((P/'ci-scale-perturbation.input.glb').read_bytes());after,chunks_after=parse((P/'ci-scale-perturbation.repaired.glb').read_bytes());joints=set(before['skins'][0]['joints'])
def accessor(d,c,i):
 a=d['accessors'][i];assert a['componentType']==5126 and 'sparse'not in a
 width={'SCALAR':1,'VEC3':3,'VEC4':4}[a['type']];v=d['bufferViews'][a['bufferView']];blob=c[1][1];start=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',width*4)
 rows=[list(struct.unpack_from('<'+'f'*width,blob,start+j*stride))for j in range(a['count'])];return [x[0]for x in rows]if width==1 else rows
def slerp(a,b,t):
 dot=sum(x*y for x,y in zip(a,b))
 if dot<0:b=[-x for x in b];dot=-dot
 if dot>.9995:q=[x+(y-x)*t for x,y in zip(a,b)]
 else:
  theta=math.acos(min(1,dot));den=math.sin(theta);q=[(x*math.sin((1-t)*theta)+y*math.sin(t*theta))/den for x,y in zip(a,b)]
 n=math.sqrt(sum(x*x for x in q));return [x/n for x in q]
def pose(d,c,ai,t):
 out=copy.deepcopy(d);a=d['animations'][ai]
 for ch in a['channels']:
  s=a['samplers'][ch['sampler']];times=accessor(d,c,s['input']);vals=accessor(d,c,s['output']);assert s.get('interpolation','LINEAR')in('LINEAR','STEP')
  j=0
  while j+1<len(times)and times[j+1]<=t:j+=1
  v=vals[j]
  if j+1<len(times)and s.get('interpolation','LINEAR')=='LINEAR':
   w=max(0,min(1,(t-times[j])/(times[j+1]-times[j])));v=slerp(v,vals[j+1],w)if ch['target']['path']=='rotation'else [x+(y-x)*w for x,y in zip(v,vals[j+1])]
  out['nodes'][ch['target']['node']][ch['target']['path']]=v
 return worlds(out)
results={}
for ai,a in enumerate(before['animations']):
 duration=max(max(accessor(before,chunks,s['input']))for s in a['samplers']);translation=0;bound=0
 for sample in range(101):
  t=duration*sample/100;b=pose(before,chunks,ai,t);r=pose(after,chunks_after,ai,t)
  for j in joints:
   tr=math.sqrt(sum((b[j][k][3]-r[j][k][3])**2 for k in range(3)));linear=math.sqrt(sum((b[j][k][l]-r[j][k][l])**2 for k in range(3)for l in range(3)));translation=max(translation,tr);bound=max(bound,tr+linear)
 results[a['name']]={'samples':101,'duration_s':duration,'max_joint_translation_delta_m':translation,'max_1m_joint_frame_point_bound_m':bound,'rotation_interpolation':'shortest normalized quaternion slerp; LINEAR translations/scales; STEP held','not_measured':['deformed skin vertices','continuous extrema between samples','render equivalence']}
(P/'clip-comparison.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
