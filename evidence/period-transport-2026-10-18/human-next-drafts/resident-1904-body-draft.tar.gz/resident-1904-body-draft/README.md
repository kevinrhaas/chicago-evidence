# John J. Glessner1904 mature body draft

Outside-app preparation only, 2026-10-18. No new downloads, source edits, Blender, browser, publication or CI. Uses existing verified CC0 graphical target assets through the project's original GPL preparer; its code is referenced, not recopied/relicensed. Generated body data retains CC0 asset provenance. No portrait/photographic or production acceptance.

## Identity and depiction contract

Resident `glessner_john_j`, household `hh_glessner_john_j`, scene1904-07-01. Existing attested identity, born1843, occupation **farm machinery executive**, residenceGlessnerHouse. Actual household record and `/workspace/shared/resident-1904-candidate.md` read. Sources retained: `habs_glessner_house_il_1015_data_pages`, `glessner_house_family_page`; residence context additionally cites text-only `glessner_story_of_a_house_1923`. Do not derive portrait/clothing assets from rights-pending1923typescripts or museum material.

Chronological age on scene date is60or61 given birthyear-only record. Chosen engineering61 is1904-1843, explicitly not an attested exact birthday. Height1.75m is the unmeasured default, not his known stature. Shared macrotargets alter mature anatomy but do not supply individual likeness, mature skin texture, gray hair, facial hair or wrinkles. Attested identity grade remains separate from reconstructed depiction/action grade.

## Actual recipe and repeatability

`glessner_john_j_1904_age61.recipe.json` uses the existing source convention younganchor25/oldanchor90. Youngfraction `(90-61)/65=29/65`; oldfraction `(61-25)/65=36/65`. Each is divided equally among the three technical source shape categories: each young29/195, each old36/195. These category labels are not resident ethnicity or ancestry. TargetSHA values remain the vendored verified receipts. All sparse deltas applied before helper averaging/metric registration/A-to-T deformation.

`build_and_audit.py` executes unchanged `tools/human_base_prepare.py` with explicit outside-app recipe/output. Two independent preparations produce identical2,344,492bytes, SHA256 `8e2723075f021fd3390236e0929389bcea16a17d0058dcc6819e5dd46d30e16c`. The report pins generatorSHA and target/recipe hashes. CPU audits:14,517UV-splitvertices,26,756triangles,56nondegeneratebones; every UV/sourcecorner matches original topology; UV/triangles/sourceindices/weights exactly match existingadult25. Every positive normalized weight row has≤4existing joints. Actualheight1.75m/minY0. All1,117helpervertices change; independently recomputed upper/lowerarm helper separation matches exportedsourceanchors within5.56e-17m. Maxpositiondifference vsadult25=44.2443mm. That numerical difference is not visual maturity acceptance.

Rebuild: `python /workspace/shared/resident-1904-body-draft/build_and_audit.py`. Requires existing repo/vendored sources at the declared paths. `validation.json` records exact assertions and preparation gaps.

## Proposed resident profile requirements (not integrated)

Suggested future asset/profile ID `glessner_john_j_1904`; personreference `glessner_john_j`, scene1904, identity attested; appearance/clothing/pose reconstructed. Bodyinput should explicitly select this mature preparation, not rename the1835youngworker mesh. Preserve occupation farm machinery executive in cards and provenance.

Start standing/idle/walking, then carriage passenger with measuredseat/feet/clothing clearance. Owner-driver is permitted only as an explicitly reconstructed action; retain the attested executive occupation.1886horse/buggy ownership and1887carriageouting provide context, not proof of a1904vehicle, route, horse, reins operator or observed event. Rig may share the56bone contract, but seat/rein/contact variants need actual animation checks. Do not substitute a generic invented coachman for this existing identity to sidestep depiction decisions.

Wardrobe requirements: civilian executive clothingappropriate1904, separately sourced garment cuts/layers/closures/shoes/headwear. Do not inherit1835shirt/waistcoat/high-waistworker uniform or professional coachman livery automatically. No actual1904clothing plate or clearedGlessnerportrait was newly consulted here; coat type, collar/tie, fabric, color, fit, hat and season are currently unverified requirements, not established facts. Need source research and fitted canonical garment meshes before any wardrobe claim. Riding requires separately fitted period riding gear and is a reconstructed pose, not evidence he rode a specifichorse.

## Open quality gates

Mature body/head silhouette, palms/roll/shoulder/hip corrective review; individual likeness inputs and rights; mature skin/material and hair; eyes/teeth/morphs; actual wardrobe references/patterns/fit; canonical.blend and glTF export; LODs; standing/walk/seated/rein hand-foot contact; actual renders and photographic acceptance. Body prep supplies none of these merely by passing topology/bytes assertions.
