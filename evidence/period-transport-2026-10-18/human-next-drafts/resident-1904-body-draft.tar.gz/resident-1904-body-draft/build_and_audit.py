"""Outside-app mature body study. Uses existing original project preparer; no Blender."""
import pathlib,json,hashlib,importlib.util,math
P=pathlib.Path(__file__).parent;ROOT=pathlib.Path('/workspace/chicago/chicago/4d');S=ROOT/'assets/authored/humans/makehuman_hm08'
spec=importlib.util.spec_from_file_location('prep',ROOT/'tools/human_base_prepare.py');prep=importlib.util.module_from_spec(spec);spec.loader.exec_module(prep)
house=json.loads((ROOT/'data/residents_1904/households/hh_glessner_john_j.json').read_text());person=next(p for p in house['persons']if p['id']=='glessner_john_j');assert person['born']['value']=='1843'and person['occupation']['value']=='farm machinery executive'and person['grade']=='attested'
recipe=json.loads((S/'adult_35.recipe.json').read_text())
for row in recipe['targets']:row['coefficient']=(29 if '-young.'in row['path']else 36)/195
recipe['phenotype'].update({'chosen_age_years':61,'age_band_years':[60,61],'age_status':'Engineering age61 from1904 minus recorded birthyear1843; birthday unknown in record, chronological age60or61. Not portrait matching.','likeness_status':'mature shared-topology engineering study, no individual likeness or production acceptance'})
recipe['resident_reference']={'id':person['id'],'scene':'1904','identity_grade':'attested','depiction_grade':'reconstructed','household_id':house['id'],'sources':person['sources']}
recipe['age_blend_basis']='Existing verified source age anchors young25/old90; young=(90-61)/65=29/65, old=(61-25)/65=36/65. Each equally divided by3 software shape categories, no ancestry assertion.'
r=P/'glessner_john_j_1904_age61.recipe.json';r.write_text(json.dumps(recipe,indent=2)+'\n')
a=prep.prepare(S,1.75,r);b=prep.prepare(S,1.75,r);enc=lambda d:(json.dumps(d,separators=(',',':'))+'\n').encode();payload=enc(a);assert payload==enc(b);(P/'prepared_glessner_john_j_age61.json').write_bytes(payload)
m=a['meshes'][0];base=json.loads((S/'prepared_adult_25.json').read_text());bm=base['meshes'][0];names={x['name']for x in a['skeleton']};assert len(names)==56
for field in ['triangles','uvs','weights','source_vertex_indices']:assert m[field]==bm[field]
assert min(v[1]for v in m['positions_m'])==0 and abs(max(v[1]for v in m['positions_m'])-1.75)<1e-12
for w in m['weights']:assert 1<=len(w)<=4 and set(w)<=names and all(v>0 for v in w.values())and abs(math.fsum(w.values())-1)<1e-12
for bone in a['skeleton']:assert prep.norm(prep.sub(bone['head_m'],bone['tail_m']))>1e-6
# Independent sparse graphical addition and helper averaging before pose.
raw,uv,faces,groups=prep.read_obj(S/'makehuman/data/3dobjs/base.obj');neutral=[v[:]for v in raw]
for row in recipe['targets']:
 for line in (S/row['path']).read_text().splitlines():
  if not line.strip()or line.startswith('#'):continue
  f=line.split();i=int(f[0]);raw[i]=[raw[i][k]+float(f[k+1])*row['coefficient']for k in range(3)]
rig=json.loads((S/'makehuman/data/rigs/default.mhskel').read_text());helper_ids={i for ids in rig['joints'].values()for i in ids};changed=sum(prep.norm(prep.sub(raw[i],neutral[i]))>1e-12 for i in helper_ids)
def head(n):return [math.fsum(raw[i][k]for i in rig['joints'][rig['bones'][n]['head']])/len(rig['joints'][rig['bones'][n]['head']])for k in range(3)]
expected=prep.sub(head('lowerarm01.L'),head('upperarm01.L'));bones={b['name']:b for b in a['skeleton']};actual=prep.sub(bones['lowerarm_l']['source_head_m'],bones['upperarm_l']['source_head_m']);scale=a['report']['initial_source_scale']*a['report']['final_registration_scale'];anchor_error=max(abs(x-y*scale)for x,y in zip(actual,expected));assert anchor_error<1e-10
# Exact per-corner UV/source topology audit.
cursor=0
for face in faces:
 for j in range(1,len(face)-1):
  tri=m['triangles'][cursor];cursor+=1
  for oi,(vi,ti)in zip(tri,[face[0],face[j],face[j+1]]):assert m['source_vertex_indices'][oi]==vi and m['uvs'][oi]==uv[ti]
report={'status':'outside-app engineering draft, not visual/export/likeness acceptance','chosen_age':61,'young_total':29/65,'old_total':36/65,'coefficient_sum':math.fsum(t['coefficient']for t in recipe['targets']),'height_m':1.75,'height_status':'unmeasured engineering default, not Glessner stature','recipe_sha256':hashlib.sha256(r.read_bytes()).hexdigest(),'prepared_sha256':hashlib.sha256(payload).hexdigest(),'prepared_bytes':len(payload),'two_independent_rebuilds_byte_equal':True,'vertices':len(m['positions_m']),'triangles':len(m['triangles']),'bones':len(names),'helper_vertices':len(helper_ids),'changed_helpers':changed,'independent_arm_anchor_delta_error_m':anchor_error,'UV_topology_source_indices_weights_equal_age25':True,'max_age25_to61_vertex_displacement_m':max(prep.norm(prep.sub(x,y))for x,y in zip(m['positions_m'],bm['positions_m'])),'prep_generator_sha256':hashlib.sha256((ROOT/'tools/human_base_prepare.py').read_bytes()).hexdigest(),'prep_report':a['report']}
(P/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='prep_report'},indent=2))
