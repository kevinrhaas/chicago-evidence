import unittest,json,math
from solve import *
class PoseStudy(unittest.TestCase):
 def test_source_lengths_and_rotation_rigidity(self):
  for age in (25,35):
   d=json.loads((R/f'assets/authored/humans/makehuman_hm08/prepared_adult_{age}.json').read_text());points,T,chains=solve(d,1.669)
   self.assertEqual(len(points),len(d['meshes'][0]['positions_m']))
   for rot,head in T.values():
    for i in range(3):
     for j in range(3):self.assertAlmostEqual(dot(rot[i],rot[j]),float(i==j),places=12)
    self.assertAlmostEqual(dot(rot[0],cross(rot[1],rot[2])),1,places=12)
   for c in chains:
    self.assertLess(c['endpoint_error_m'],1e-12)
    a,b=c['bones'];self.assertAlmostEqual(math.dist(T[a][1],c['joint_m']),c['lengths_m'][0],places=12)
    self.assertAlmostEqual(math.dist(c['joint_m'],c['target_m']),c['lengths_m'][1],places=12)
 def test_unreachable_rejected(self):
  with self.assertRaises(AssertionError):ik([0,0,0],[3,0,0],1,1,[0,1,0])
 def test_collision_cost_sensitivity(self):
  clear=cost([[2,0,0]],[-1,-1,-1],[1,1,1]);bad=cost([[0,0,0]],[-1,-1,-1],[1,1,1])
  self.assertEqual(clear['inside_vertices'],0);self.assertEqual(bad['inside_vertices'],1);self.assertEqual(bad['squared_depth_cost_m2'],1)
 def test_actual_contact_report_and_reference_bound(self):
  rows=json.loads((O/'report.json').read_text())['residents'];self.assertEqual({x['asset_id'] for x in rows},{'bardwell_otis_1835','dufresne_joseph_1835','flynn_martin_1835'})
  for row in rows:
   self.assertLess(abs(row['seat_gap_m']),1e-8)
   for foot in row['feet'].values():self.assertLess(abs(foot['sole_gap_m']),1e-12);self.assertEqual(foot['projection_outside_board_vertices'],0)
if __name__=='__main__':unittest.main()
