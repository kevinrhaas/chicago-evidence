# W01 resident driving study — outside application, unaccepted

Run `python solve.py`, then `python -m unittest -v test_pose`. Original stdlib implementation, GPL-3.0-or-later. Source body remains CC0 under its original source manifest. Outputs are engineering experiments, not game-ready people or photographic likenesses.

This uses ONLY recipe references Otis Bardwell, Joseph Dufresne and Martin Flynn, each an existing reconstructed 1835 person. Dufresne/Flynn currently share the adult35 source anatomy; two names do not prove independently researched anatomies. No fallback person. Current source hashes and W01 exported parameters are in report.json.

Actual W01 export and generator agree: box3.05×1.07×.55, bedTOP.95, railTOP1.53. Empty socket(0,1.15,1.10) is not seating. The proposed removable bench from ../human-transport-draft is NOT implemented: top1.58, footprint x±.59,z.50..80, footboardtop1.12,x±.425,z1.12..1.42. Cleats, fastenings, supports and historical construction evidence remain dependencies. Do not silently change parked wagons. C01 is1904 and deliberately unused.

## Numerical implementation

solve.py loads real prepared source positions, skin weights and56bone rest joints. It computes original analytic two-link IK with declared knee-forward/elbow-out/back pole directions, rigid shortest-arc global bone rotations, hierarchical child transforms and actual four-influence source linear-blend skinning. Feet retain global rest orientation. No bone stretch/nonuniform scale. Pelvis height is iteratively registered using236 actual deformed rear-pelvis-region vertices over the proposed bench, replacing the former guessed .10m clearance. Original source LBS OBJ and global matrices are emitted per person for later independent review; these are not canonical Blender exports.

Measured pelvisY1.668829992 (adult25) /1.669513811(adult35). Seat minimum gaps5.34/5.69nanometres; four chain endpoint errors≤2.3e-16m. Each side's1163 strongly foot/ball-weighted vertices has sole minimum on1.12 and complete x/z projection on proposed board. Do not interpret a minimum-gap constraint as a load-bearing contact patch. Zero source vertices strictly inside the five tested box solids (bench, front wall, floor, sidewalls). These are vertex/AABB costs only: NOT triangle-box collision proof, garment/skin contact, self-collision, nails/rails/steering clearance or support strength acceptance.

## Next small source change proposal

1. Add an explicitly opt-in `driver_bench_reconstructed` W01 generator variant, driven by dimensions above and complete support/cleat/fastening geometry; export its real seat/footboard bounds. Keep current baseline unchanged.
2. Move this pure constraint solver behind function arguments for prepared body, exported furniture, resident recipe reference. In canonical Blender builder convert these GLOBAL rest-to-pose transforms to actual BPy rest-basis local matrices (do not paste as bone-local quaternions). Author `sit_drive` static pose, root registration and explicit driver hands sockets. Validate Blender-evaluated skinned vertices independently against the source-LBS predictions before claiming equivalence.
3. Existing hand heads target(±.20,1.92,1.04); these are wrist datums, NOT clenched rein grips. Add palm-local grip datums and finger curl only after inspecting actual hand axes. Later live reins should terminate at those grips, then bridle endpoints, with explicit geometric slack and no force claim. No horses/traffic are coupled by this draft.
4. Add full triangle-solid contact, garment/shoe thickness, self-collision, attachment and steering-sweep tests using actual final evaluated meshes; render all three people front/side/rear before runtime integration. Skin/cloth deformation, elbow/hip corrective anatomy, historical bench/clothing fit, photographed likeness, realism and final rider usability remain OPEN.

Four tests pass: actual-body rigid rotation determinant/orthogonality and preserved chain lengths; unreachable-target rejection; adversarial collision-cost sensitivity; contact/reference report bounds. Source geometry tests are not canonical Blender acceptance.
