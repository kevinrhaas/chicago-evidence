#!/usr/bin/env python3
"""Original stdlib source-LBS constraint experiment. Not Blender pose acceptance."""
import json,math,hashlib
from pathlib import Path
R=Path('/workspace/chicago/chicago/4d'); O=Path(__file__).parent
add=lambda a,b:[x+y for x,y in zip(a,b)]
sub=lambda a,b:[x-y for x,y in zip(a,b)]
scale=lambda a,s:[x*s for x in a]
dot=lambda a,b:math.fsum(x*y for x,y in zip(a,b))
norm=lambda a:math.sqrt(dot(a,a))
unit=lambda a:scale(a,1/norm(a))
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
I=[[1,0,0],[0,1,0],[0,0,1]]
def mv(m,v):return [dot(row,v) for row in m]
def align(a,b):
 a,b=unit(a),unit(b);v=cross(a,b);c=dot(a,b)
 assert c>-.999999,'antiparallel requires explicit roll choice'
 K=[[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]]
 return [[I[i][j]+K[i][j]+math.fsum(K[i][k]*K[k][j] for k in range(3))/(1+c) for j in range(3)] for i in range(3)]
def ik(a,t,l1,l2,pole):
 d=math.dist(a,t);assert abs(l1-l2)<d<l1+l2,(d,l1,l2)
 u=unit(sub(t,a));q=unit(sub(pole,scale(u,dot(pole,u))));x=(l1*l1-l2*l2+d*d)/(2*d)
 return add(a,add(scale(u,x),scale(q,math.sqrt(max(0,l1*l1-x*x)))))
def cost(points,lo,hi):
 depths=[min(min(p[k]-lo[k],hi[k]-p[k]) for k in range(3)) for p in points if all(lo[k]<p[k]<hi[k] for k in range(3))]
 return {'inside_vertices':len(depths),'max_interior_depth_m':max(depths,default=0),'squared_depth_cost_m2':math.fsum(x*x for x in depths)}
def solve(data,py):
 B={b['name']:b for b in data['skeleton']}; shift=sub([0,py,.65],B['pelvis']['head_m']);T={}; overrides={};chains=[]
 def update():
  T.clear()
  for n,b in B.items():
   if n in overrides:T[n]=overrides[n];continue
   p=b['parent']
   if p is None:T[n]=(I,add(b['head_m'],shift))
   else:
    rot,head=T[p];T[n]=(rot,add(head,mv(rot,sub(b['head_m'],B[p]['head_m']))))
 update();m=data['meshes'][0]
 for side,sign in [('l',1),('r',-1)]:
  foot='foot_'+side
  fv=[v for v,w in zip(m['positions_m'],m['weights']) if w.get(foot,0)+w.get('ball_'+side,0)>=.9]
  ankle=[sign*.18,1.12+B[foot]['head_m'][1]-min(v[1] for v in fv),1.19]
  for a,b,target,pole in [('thigh_'+side,'calf_'+side,ankle,[0,0,1]),('upperarm_'+side,'lowerarm_'+side,[sign*.20,1.92,1.04],[sign,-.5,-.5])]:
   origin=T[a][1];l1=math.dist(B[a]['head_m'],B[a]['tail_m']);l2=math.dist(B[b]['head_m'],B[b]['tail_m']);k=ik(origin,target,l1,l2,pole)
   overrides[a]=(align(sub(B[a]['tail_m'],B[a]['head_m']),sub(k,origin)),origin)
   overrides[b]=(align(sub(B[b]['tail_m'],B[b]['head_m']),sub(target,k)),k)
   update(); end='foot_'+side if a.startswith('thigh') else 'hand_'+side
   if a.startswith('thigh'):overrides[end]=(I,target);update()
   chains.append({'bones':[a,b],'joint_m':k,'target_m':target,'endpoint_error_m':math.dist(add(T[b][1],mv(T[b][0],sub(B[b]['tail_m'],B[b]['head_m']))),target),'lengths_m':[l1,l2]})
 points=[]
 for v,w in zip(m['positions_m'],m['weights']):
  p=[0.,0.,0.]
  for n,weight in w.items():p=add(p,scale(add(T[n][1],mv(T[n][0],sub(v,B[n]['head_m']))),weight))
  points.append(p)
 return points,T,chains

def main():
 wagon=R/'renderers/web/transport/wagon/wagon-w01.json';W=json.loads(wagon.read_text())['parameters'];L,width,h=W['body_m'];bed=W['bed_top_m'];seat=bed+h+.03+.05
 assert abs(seat-1.58)<1e-9
 recipe=json.loads((R/'data/humans/recipes/worker_1835.json').read_text());rows=[]
 for variant in recipe['proof_variants']:
  path=R/variant['body_input'];d=json.loads(path.read_text());m=d['meshes'][0]
  # Register actual deformed source-body rear-pelvis region to bench top; target pelvis clearance is not guessed.
  pelvis=next(b for b in d['skeleton'] if b['name']=='pelvis')['head_m']
  selected=[i for i,(v,w) in enumerate(zip(m['positions_m'],m['weights'])) if abs(v[0])<.18 and pelvis[1]-.18<v[1]<pelvis[1]+.04 and v[2]<pelvis[2] and w.get('pelvis',0)+w.get('thigh_l',0)+w.get('thigh_r',0)>.5]
  py=seat+.10
  for _ in range(12):
   pts,T,chains=solve(d,py);valid=[i for i in selected if .50<=pts[i][2]<=.80];assert valid
   gap=min(pts[i][1] for i in valid)-seat
   if abs(gap)<1e-8:break
   py-=gap
  pts,T,chains=solve(d,py)
  solids={'bench':([-.59,seat-.05,.50],[.59,seat,.80]),'front_wall':([-width/2,bed,L/2-.0175],[width/2,bed+h,L/2+.0175]),'floor':([-width/2,bed-.07,-L/2],[width/2,bed,L/2]),'side_l':([width/2-.0175,bed,-L/2],[width/2+.0175,bed+h,L/2]),'side_r':([-width/2-.0175,bed,-L/2],[-width/2+.0175,bed+h,L/2])}
  feet={}
  for side in ['l','r']:
   idx=[i for i,w in enumerate(m['weights']) if w.get('foot_'+side,0)+w.get('ball_'+side,0)>=.9];fp=[pts[i] for i in idx]
   feet[side]={'vertices':len(idx),'sole_gap_m':min(p[1] for p in fp)-1.12,'projection_outside_board_vertices':sum(not(-.425<=p[0]<=.425 and 1.12<=p[2]<=1.42) for p in fp)}
  row={'asset_id':variant['id'],'person_reference_id':variant['person_reference_id'],'body_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'pelvis_head_m':T['pelvis'][1],'seat_candidate_vertices':len(valid),'seat_gap_m':min(pts[i][1] for i in valid)-seat,'chains':chains,'feet':feet,'vertex_inside_solid_costs':{n:cost(pts,*box) for n,box in solids.items()},'socket_targets':{'seat_surface':[0,seat,.65],'reins_grips':{s:T['hand_'+s][1] for s in ['l','r']}}}
  rows.append(row)
  (O/(variant['id']+'-pose.json')).write_text(json.dumps({'frame':'metres +Yup +Zforward','bone_global_head_rotation':{n:{'head_m':t,'rotation_3x3':rot} for n,(rot,t) in T.items()}},indent=2)+'\n')
  with (O/(variant['id']+'-source-lbs.obj')).open('w') as f:
   f.write('# Source body only; original reconstructed sitting experiment\n')
   for p in pts:f.write('v '+' '.join(format(x,'.10g') for x in p)+'\n')
   for tri in m['triangles']:f.write('f '+' '.join(str(i+1) for i in tri)+'\n')
 report={'status':'outside-app unaccepted source-body LBS study; no garments/Blender/browser','wagon_export_sha256':hashlib.sha256(wagon.read_bytes()).hexdigest(),'wagon_parameters':W,'furniture_implemented':False,'furniture':{'bench_top_y_m':seat,'footboard_top_y_m':1.12},'residents':rows}
 (O/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(rows,indent=2))
if __name__=='__main__':main()
