from pathlib import Path
import numpy as np,json
p=Path(__file__).parent;m=json.loads((p/'horse-63-poses.json').read_text());poses=np.fromfile(p/'horse-63-poses.f32',dtype='<f4').reshape(63,m['triangleCount'],3,3).astype(float)
def top(x,z):
 mx=-np.inf
 for ts in poses:
  a=ts[:,0];u=ts[:,1]-a;v=ts[:,2]-a;det=u[:,0]*v[:,2]-u[:,2]*v[:,0];valid=np.abs(det)>1e-12;b=np.zeros(len(ts));c=b.copy();b[valid]=((x-a[valid,0])*v[valid,2]-(z-a[valid,2])*v[valid,0])/det[valid];c[valid]=(u[valid,0]*(z-a[valid,2])-u[valid,2]*(x-a[valid,0]))/det[valid];mask=valid&(b>=-1e-9)&(c>=-1e-9)&(b+c<=1+1e-9);y=(a[:,1]+u[:,1]*b+v[:,1]*c)[mask]
  if len(y):mx=max(mx,float(y.max()))
 return mx
for x,z in [(.31,.22),(.3,.08),(.25,-.04),(.15,-.08),(0,-.08)]:print(x,z,top(x,z))
