from pathlib import Path
import numpy as np,json,struct,ast,hashlib,sys,time,collections
P=Path(__file__).parent;variant=sys.argv[1] if len(sys.argv)>1 else 'trial-v1';M=json.loads((P/'horse-63-poses.json').read_text());poses=np.fromfile(P/'horse-63-poses.f32',dtype='<f4').reshape(63,M['triangleCount'],3,3).astype(float);names=np.array([m['name'] for m in M['meshes'] for _ in range(m['count'])]);raw=(P/variant/'light_breastcollar_harness_reconstructed_01.glb').read_bytes();ln=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+ln]);binary=raw[28+ln:];parts=[]
for mesh in g['meshes']:
 if mesh['name'] not in ['breastcollar','breastcollar_support_l','breastcollar_support_r','harness_saddle_pad']:continue
 q=mesh['primitives'][0];a=g['accessors'][q['attributes']['POSITION']];v=g['bufferViews'][a['bufferView']];xyz=np.array(struct.unpack_from('<%sf'%(a['count']*3),binary,v.get('byteOffset',0))).reshape(-1,3);parts.append((mesh['name'],xyz.reshape(-1,3,3)))
t=ast.parse((P.parent/'carriage-c02-door-mechanics/check.py').read_text());node=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='intersects');env={'np':np};exec(compile(ast.Module(body=[node],type_ignores=[]),'actual-SAT','exec'),env);sat=env['intersects']
def proper(a,b):
 for source,target in [(a,b),(b,a)]:
  normal=np.cross(target[1]-target[0],target[2]-target[0]);l=np.linalg.norm(normal)
  if l<1e-15:continue
  normal/=l;distance=(source-target[0])@normal
  for i in range(3):
   j=(i+1)%3;da,db=distance[i],distance[j]
   if not ((da>1e-8 and db< -1e-8)or(da< -1e-8 and db>1e-8)):continue
   u=da/(da-db);pt=source[i]*(1-u)+source[j]*u;v0=target[1]-target[0];v1=target[2]-target[0];v2=pt-target[0];d00=v0@v0;d01=v0@v1;d11=v1@v1;d20=v2@v0;d21=v2@v1;den=d00*d11-d01*d01
   if abs(den)<1e-20:continue
   v=(d11*d20-d01*d21)/den;w=(d00*d21-d01*d20)/den
   if min(1-v-w,v,w)>1e-8:return {'point_m':pt.tolist(),'edge_distances_m':[float(da),float(db)],'face_barycentric':[1-v-w,v,w]}
 return None
rows=[];start=time.time()
for info,horse in zip(M['rows'],poses):
 lo=horse.min(1);hi=horse.max(1);hits=[];near=[]
 for name,ts in parts:
  for j,a in enumerate(ts):
   ix=np.flatnonzero(np.all(hi>=a.min(0)-1e-8,axis=1)&np.all(lo<=a.max(0)+1e-8,axis=1))
   for k in ix:
    if sat(a,horse[k]):hits.append({'gear':name,'gear_triangle':j,'horse_mesh':str(names[k]),'horse_triangle_global':int(k),'proper':proper(a,horse[k])})
 rows.append({**info,'SAT_intersections':len(hits),'proper_crossings':sum(h['proper']is not None for h in hits),'pairs':hits});print(info,len(hits),flush=True)
report={'variant':variant,'scope':'Wholechangedgear actualGLBtriangles vsALL14172activehorse triangles over63 actualGLTFLoaderLBSidle/walk/trot poses; discrete only, no solidcontainment/pressure proof','parts':[(n,len(t))for n,t in parts],'glb_sha256':hashlib.sha256(raw).hexdigest(),'horse_pose_sha256':hashlib.sha256((P/'horse-63-poses.f32').read_bytes()).hexdigest(),'rows':rows,'SAT_intersections':sum(r['SAT_intersections']for r in rows),'proper_crossings':sum(r['proper_crossings']for r in rows),'elapsed_s':time.time()-start};(P/(variant+'-whole-horse.json')).write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items()if k not in ['rows']})
