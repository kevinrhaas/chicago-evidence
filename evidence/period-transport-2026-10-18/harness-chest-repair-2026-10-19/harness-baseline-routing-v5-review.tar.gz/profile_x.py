exec(open('/workspace/shared/harness-baseline-routing-next/support_profile.py').read().split('for x,z in [')[0])
def right(y,z):
 mx=-np.inf
 for ts in poses:
  a=ts[:,0];u=ts[:,1]-a;v=ts[:,2]-a;det=u[:,1]*v[:,2]-u[:,2]*v[:,1];valid=np.abs(det)>1e-12;b=np.zeros(len(ts));c=b.copy();b[valid]=((y-a[valid,1])*v[valid,2]-(z-a[valid,2])*v[valid,1])/det[valid];c[valid]=(u[valid,1]*(z-a[valid,2])-u[valid,2]*(y-a[valid,1]))/det[valid];mask=valid&(b>=-1e-9)&(c>=-1e-9)&(b+c<=1+1e-9);xx=(a[:,0]+u[:,0]*b+v[:,0]*c)[mask]
  if len(xx):mx=max(mx,float(xx.max()))
 return mx
for y,z in [(1.34,.23),(1.35,.15),(1.365,.07),(1.375,-.005)]:print(y,z,right(y,z),max(right(y+dy,z+dz) for dy in [-.003,0,.003] for dz in [-.014,0,.014]))
