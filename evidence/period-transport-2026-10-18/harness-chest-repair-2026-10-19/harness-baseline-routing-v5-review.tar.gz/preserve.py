from pathlib import Path
import struct,json,hashlib
p=Path(__file__).parent
def load(f):
 raw=f.read_bytes();n=struct.unpack_from('<I',raw,12)[0];return json.loads(raw[20:20+n]),raw[28+n:]
a,ab=load(p/'input/harness.glb');b,bb=load(p/'trial-v5/light_breastcollar_harness_reconstructed_01.glb');changed=['breastcollar','breastcollar_support_l','breastcollar_support_r','harness_saddle_pad'];rows=[]
def attributes(g,raw,mesh):
 out=[]
 for prim in mesh['primitives']:
  for name,i in prim['attributes'].items():
   acc=g['accessors'][i];v=g['bufferViews'][acc['bufferView']];off=v.get('byteOffset',0);out.append((name,raw[off:off+v['byteLength']]))
 return out
for old,new in zip(a['meshes'],b['meshes']):
 assert old['name']==new['name']
 if old['name']not in changed:assert attributes(a,ab,old)==attributes(b,bb,new),old['name'];rows.append(old['name'])
assert a['nodes']==b['nodes'];assert a['materials']==b['materials'];r={'other32meshes_attribute_buffers_exact':rows,'all_nodes_sockets_bindings_exact':True,'all_materials_exact':True,'unchanged_horse_sha256':hashlib.sha256((p/'input/horse.glb').read_bytes()).hexdigest(),'original_gear_sha256':hashlib.sha256((p/'input/harness.glb').read_bytes()).hexdigest()};(p/'preservation.json').write_text(json.dumps(r,indent=2)+'\n');print('PASS',len(rows),'other mesh buffers nodes/materials')
