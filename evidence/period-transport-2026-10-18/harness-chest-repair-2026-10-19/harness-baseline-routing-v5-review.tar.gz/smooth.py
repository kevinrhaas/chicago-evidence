from pathlib import Path
import json,math
p=Path(__file__).parent;d=json.loads((p/'parameters.json').read_text());knots=d['breastcollar_route_m'][::4];norm=d['breastcollar_surface_normals'][::4]
def smooth(points):
 out=[]
 for i in range(len(points)-1):
  a=points[max(0,i-1)];b=points[i];c=points[i+1];e=points[min(len(points)-1,i+2)]
  for j in range(4):
   t=j/4;out.append([.5*((2*b[k])+(-a[k]+c[k])*t+(2*a[k]-5*b[k]+4*c[k]-e[k])*t*t+(-a[k]+3*b[k]-3*c[k]+e[k])*t*t*t) for k in range(3)])
 out.append(points[-1]);return out
rr=smooth(knots);nn=[]
for i in range(len(knots)-1):
 for j in range(4):
  t=j/4;n=[norm[i][k]*(1-t)+norm[i+1][k]*t for k in range(3)];l=math.sqrt(sum(v*v for v in n));nn.append([v/l for v in n])
nn.append(norm[-1]);d['breastcollar_route_m']=rr;d['breastcollar_surface_normals']=nn;(p/'parameters.json').write_text(json.dumps(d,indent=2)+'\n')
s=(p/'generate_harness.py').read_text();helper='\ndef smooth_route(points):\n out=[]\n for i in range(len(points)-1):\n  a=points[max(0,i-1)];b=points[i];c=points[i+1];e=points[min(len(points)-1,i+2)]\n  for j in range(4):\n   t=j/4;out.append([.5*((2*b[k])+(-a[k]+c[k])*t+(2*a[k]-5*b[k]+4*c[k]-e[k])*t*t+(-a[k]+3*b[k]-3*c[k]+e[k])*t*t*t) for k in range(3)])\n out.append(points[-1]);return out\n'
s=s.replace("# Rounded front breast collar",helper+"# Rounded front breast collar")
s=s.replace("strap('breastcollar_support_'+side,[[s*", "strap('breastcollar_support_'+side,smooth_route([[s*").replace("[0,1.67,.0]],.023,.004,width_axis=(0,0,1))","[0,1.67,.0]]),.023,.004,width_axis=(0,0,1))")
(p/'generate_harness.py').write_text(s)
