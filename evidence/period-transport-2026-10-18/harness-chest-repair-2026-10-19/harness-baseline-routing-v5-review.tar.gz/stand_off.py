from pathlib import Path
import numpy as np,json,sys,time
P=Path(__file__).parent;src=(P/'measure_distance.py').read_text();exec(compile(src[:src.rindex('rows=[];start=time.time()')],'actual-distance-load','exec'))
rows=[];start=time.time()
for info,horse in zip(M['rows'],poses):
 lo=horse.min(1);hi=horse.max(1)
 for name,ts in parts:
  points=np.unique(ts.reshape(-1,3),axis=0);ds=[];tail=[]
  for point in points:
   gap=np.maximum(0,np.maximum(lo-point,point-hi));lower=np.sqrt((gap*gap).sum(1));ix=np.flatnonzero(lower<.2);squared=pts_tri(np.broadcast_to(point,(len(ix),3)),horse[ix]);d=float(np.sqrt(squared.min()));assert d<.2;ds.append(d);tail.append(bool('support' in name and point[2]<.04))
  values=np.array(ds);free=np.array(tail);rows.append({**info,'part':name,'unique_surface_vertices':len(points),'minimum_vertex_distance_m':float(values.min()),'median_vertex_distance_m':float(np.median(values)),'maximum_vertex_distance_m':float(values.max()),'pad_connection_region_z_lt_04_maximum_m':float(values[free].max()) if free.any()else None,'other_route_maximum_m':float(values[~free].max())if (~free).any()else None});print(info,name,values.max(),flush=True)
report={'scope':'Actualchangedstrap unique surfacevertex distances toALLactivehorse triangles at63poses; stand-offdistribution only, minsurface-triangle clearance measuredseparately','rows':rows,'elapsed_s':time.time()-start,'pad_connection_free_span':'Only support pointsz<.04 near existingunchangedpadfront/lateraledge areclassified padconnector; noexcludedcollisionpairs. Existingpaditself hasbodygap and isunchanged; no fittedpressureclaim.'};(P/(variant+'-stand-off.json')).write_text(json.dumps(report,indent=2)+'\n')
