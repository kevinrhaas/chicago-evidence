from pathlib import Path
import json,math
p=Path(__file__).parent;d=json.loads((p/'input/parameters.json').read_text());route=d['breastcollar_route_m'];norm=d['breastcollar_surface_normals'];new=[]
for i,a in enumerate(route):
 u=math.sin(math.pi*i/(len(route)-1));x,y,z=a;new.append([x+(.024*u if x>0 else -.024*u if x<0 else 0),y,z+.028*u])
# Piecewise linear sampling keeps exact authored endpoints; original normal interpolation.
rr=[];nn=[]
for i in range(len(new)-1):
 for j in range(4):
  t=j/4;rr.append([new[i][k]*(1-t)+new[i+1][k]*t for k in range(3)]);n=[norm[i][k]*(1-t)+norm[i+1][k]*t for k in range(3)];l=math.sqrt(sum(x*x for x in n));nn.append([x/l for x in n])
rr.append(new[-1]);nn.append(norm[-1]);d['breastcollar_route_m']=rr;d['breastcollar_surface_normals']=nn
# Legacytrace+socket depend on firstpoint, unchanged. Supportfirstpoint must reference originalsecondcurveknot index4.
s=(p/'input/generate_harness.py').read_text();s=s.replace("strap('breastcollar_support_'+side,[[s*p['breastcollar_route_m'][1][0],*p['breastcollar_route_m'][1][1:]],[s*.20,1.44,.38],[s*.09,1.57,.32],[0,1.585,.27]],.023,.004)","strap('breastcollar_support_'+side,[[s*p['breastcollar_route_m'][4][0],*p['breastcollar_route_m'][4][1:]],[s*.31,1.42,.29],[s*.30,1.52,.19],[s*.22,1.62,.09],[s*.10,1.66,.02],[0,1.67,.0]],.023,.004,width_axis=(0,0,1))")
assert s!=(p/'input/generate_harness.py').read_text();(p/'generate_harness.py').write_text(s);(p/'parameters.json').write_text(json.dumps(d,indent=2)+'\n')
