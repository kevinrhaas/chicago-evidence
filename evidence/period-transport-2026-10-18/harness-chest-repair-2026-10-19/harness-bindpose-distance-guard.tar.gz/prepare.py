from pathlib import Path
import difflib
p=Path(__file__).parent;b=p.parent/'harness-baseline-routing-next/files/chicago/4d/tools/transport/test_harness_body_fit.py';old=b.read_text();s=old
functions='''
def point_segment(p,a,b):
 u=sub(b,a);d=dot(u,u);t=max(0,min(1,dot(sub(p,a),u)/d))if d>1e-30 else 0
 return math.sqrt(dot(sub(p,tuple(a[k]+t*u[k]for k in range(3))),sub(p,tuple(a[k]+t*u[k]for k in range(3)))))
def point_triangle(p,t):
 a,b,c=t;u=sub(b,a);v=sub(c,a);n=cross(u,v);nn=dot(n,n)
 if nn>1e-30:
  signed=dot(sub(p,a),n);q=tuple(p[k]-signed*n[k]/nn for k in range(3));w=sub(q,a);uu=dot(u,u);uv=dot(u,v);vv=dot(v,v);den=uu*vv-uv*uv
  if den>1e-30:
   y=(vv*dot(w,u)-uv*dot(w,v))/den;z=(uu*dot(w,v)-uv*dot(w,u))/den
   if y>=0 and z>=0 and y+z<=1:return abs(signed)/math.sqrt(nn)
 return min(point_segment(p,t[k],t[(k+1)%3])for k in range(3))
def segment_distance(a,b,c,d):
 u=sub(b,a);v=sub(d,c);w=sub(a,c);A=dot(u,u);B=dot(u,v);C=dot(v,v);D=dot(u,w);E=dot(v,w);den=A*C-B*B
 best=min(point_segment(a,c,d),point_segment(b,c,d),point_segment(c,a,b),point_segment(d,a,b))
 if den>1e-24:
  s=(B*E-C*D)/den;t=(A*E-B*D)/den
  if 0<=s<=1 and 0<=t<=1:
   q=tuple(w[k]+s*u[k]-t*v[k]for k in range(3));best=min(best,math.sqrt(dot(q,q)))
 return best
def triangle_distance(a,b):
 if sat(a,b):return 0.0
 return min([point_triangle(p,b)for p in a]+[point_triangle(p,a)for p in b]+[segment_distance(a[i],a[(i+1)%3],b[j],b[(j+1)%3])for i in range(3)for j in range(3)])
def predicate_controls():
 a=((0.,0.,0.),(2.,0.,0.),(0.,2.,0.));b=((.2,.2,1.),(.5,.2,1.),(.2,.5,1.));assert abs(triangle_distance(a,b)-1)<1e-12
 assert triangle_distance(a,((.2,.2,0.),(.5,.2,0.),(.2,.5,0.)))==0
 crossface=((.5,.5,-1.),(.5,.5,1.),(1.,.5,1.));assert proper(a,crossface)is not None and triangle_distance(a,crossface)==0
 disjoint=((1.8,1.8,0.),(2.,1.8,0.),(1.8,2.,0.));assert not sat(a,disjoint) and triangle_distance(a,disjoint)>0
 assert abs(segment_distance((0,0,0),(1,0,0),(.5,-1,.3),(.5,1,.3))-.3)<1e-12
 assert abs(segment_distance((0,0,0),(1,0,0),(0,1,0),(1,1,0))-1)<1e-12
 assert abs(segment_distance((0,0,0),(0,0,0),(1,0,0),(2,0,0))-1)<1e-12
'''
s=s.replace('\ndef bounds(t):','\n'+functions+'\ndef bounds(t):');s=s.replace('def measure(gear,horse):','def measure(gear,horse,required_clearance=0):').replace(' hits=[];proper_count=0',' hits=[];proper_count=0;violations=[];near_pairs=0')
s=s.replace('box=bounds(a);candidates={i for cell in cells(box)for i in grid.get(cell,[])}','box=bounds(a);search=[tuple(v-required_clearance-1e-8 for v in box[0]),tuple(v+required_clearance+1e-8 for v in box[1])];candidates={i for cell in cells(search)for i in grid.get(cell,[])}')
s=s.replace("   if any(box[1][k]<bb[0][k]-1e-8 or bb[1][k]<box[0][k]-1e-8 for k in range(3)):continue\n   if sat(a,horse[i][2]):", "   lower=math.sqrt(sum(max(0,box[0][k]-bb[1][k],bb[0][k]-box[1][k])**2 for k in range(3)))\n   if required_clearance and lower<required_clearance:\n    near_pairs+=1;distance=triangle_distance(a,horse[i][2])\n    if distance<required_clearance:violations.append({'part':name,'gear_triangle':fi,'horse_triangle':horse[i][1],'distance_m':distance})\n   if lower>1e-8:continue\n   if sat(a,horse[i][2]):")
s=s.replace("return {'surface_pairs':len(hits),'proper_crossings':proper_count,'pairs':hits}","return {'surface_pairs':len(hits),'proper_crossings':proper_count,'pairs':hits,'required_clearance_m':required_clearance,'exact_distance_candidates':near_pairs,'clearance_violations':violations}")
s=s.replace('def main():\n','def main():\n predicate_controls()\n').replace('after=measure(load(gear_path),horse);','after=measure(load(gear_path),horse,required_clearance=.005);').replace("assert after['surface_pairs']==0,'Repairedbindpose surface interference'","assert after['surface_pairs']==0,'Repairedbindpose surface interference';assert not after['clearance_violations'],'Repairedbindpose belowdeclared5mm clearance'")
(p/'test_harness_body_fit.py').write_text(s);(p/'declared-clearance-context.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/tools/transport/test_harness_body_fit.py',tofile='b/tools/transport/test_harness_body_fit.py')))
