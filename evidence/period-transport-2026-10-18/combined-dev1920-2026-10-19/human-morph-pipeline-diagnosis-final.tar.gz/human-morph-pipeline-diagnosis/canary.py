import sys,pathlib,json,hashlib,subprocess
sys.dont_write_bytecode=True
root=pathlib.Path('/workspace/chicago/chicago/4d');sys.path.insert(0,str(root/'tools'))
import human_frame_residue as f,human_skin_canonicalize as s
p=root/'assets/humans/c4d_fixture.lod0.glb';raw=p.read_bytes();before,tail=f.parse(raw);proof=dict(input_sha256=f.sha(raw),verified_by='read-only existing fixture canary, NOT authored BPy proof',verification_reference='outside-app morph-preservation canary',**{k:True for k in ['rig_object_scales_unit','pose_bone_scales_unit','no_constraints','no_drivers','no_scale_fcurves','authored_rigid_rig']})
a,receipt=f.repair(raw,proof);b,skin=s.consolidate(a);out=pathlib.Path('/workspace/shared/human-morph-pipeline-diagnosis');(out/'scratch.glb').write_bytes(b)
proc=subprocess.run(['/workspace/shared/chicago-venv/bin/python',str(root/'tools/human_web_texture_inputs.py'),str(out/'scratch.glb'),str(out/'labeled.glb')],capture_output=True,text=True);assert proc.returncode==0,proc.stderr
stages={}
for name,blob in [('fixture',raw),('frame_residue',a),('skin_canonicalize',b),('texture_label',(out/'labeled.glb').read_bytes())]:
 d,c=f.parse(blob);stages[name]={'meshes_identical':d['meshes']==before['meshes'],'binary_chunks_identical':c[1:]==tail[1:],'morph_names':[m.get('extras',{}).get('targetNames',[])for m in d['meshes']],'target_counts':[[len(pr.get('targets',[]))for pr in m['primitives']]for m in d['meshes']]}
assert all(x['meshes_identical']and x['binary_chunks_identical']for x in stages.values());assert p.read_bytes()==raw
report={'fixture_sha256':hashlib.sha256(raw).hexdigest(),'stages':stages,'source_fixture_unchanged':True,'scope':'Existing generic fixture canary shows JSON mesh targets/names and binary data preserved through authored postprocessors; NOT proof of actual resident raw GLB contents. Web resize/JPEG/meshopt not executed; sourceGLB failure already excludes web-only operations as sole cause.'};(out/'postprocessor-canary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
