import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import * as THREE from '/workspace/chicago/chicago/4d/renderers/web/vendor/three-0.185.1/three.module.js';
const source=fs.readFileSync('/workspace/chicago/chicago/4d/tools/human_fixture.html','utf8');
const positionsSource=source.slice(source.indexOf('function positions(body)'),source.indexOf('function boxOf(p)'));
const maxSource=source.slice(source.indexOf('function maxMove(a, b)'),source.indexOf('const angle ='));
const actual=source.slice(source.indexOf('  r.morphs = Object.keys(mesh.morphTargetDictionary'),source.indexOf('  // Clips:'));
assert.ok(actual.startsWith('  r.morphs = Object.keys(mesh.morphTargetDictionary || {});'));
const replacement='r.morphs = [...new Set(skinned.flatMap((o) => Object.keys(o.morphTargetDictionary || {})))];';
const fixed=actual.replace('r.morphs = Object.keys(mesh.morphTargetDictionary || {});',replacement);
const names=['eyeBlinkLeft','eyeBlinkRight','jawOpen'];
function mesh(name,morphs,zero=false){
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute([0,0,0,.1,1,0,0,1.5,0],3));g.setAttribute('skinIndex',new THREE.Uint16BufferAttribute(new Array(12).fill(0),4));g.setAttribute('skinWeight',new THREE.Float32BufferAttribute([1,0,0,0,1,0,0,0,1,0,0,0],4));
 if(morphs){g.morphTargetsRelative=true;g.morphAttributes.position=names.map((n,i)=>{const a=new THREE.Float32BufferAttribute([0,0,0,0,0,0,0,zero?0:.005+i*.001,0],3);a.name=n;return a;});}
 const m=new THREE.SkinnedMesh(g,new THREE.MeshBasicMaterial());m.name=name;const b=new THREE.Bone();b.name='root';m.add(b);m.bind(new THREE.Skeleton([b]));return m;
}
function run(order,script,zero=false){const scene=new THREE.Scene(),hair=mesh('hair',false),body=mesh('body',true,zero);for(const n of order)scene.add(n==='hair'?hair:body);scene.updateMatrixWorld(true);for(const m of [hair,body])m.skeleton.update();const skinned=[];scene.traverse(o=>{if(o.isSkinnedMesh)skinned.push(o);});const ctx=vm.createContext({THREE,skinned,mesh:skinned[0],r:{}});vm.runInContext(positionsSource+maxSource+'const rest=positions(skinned);'+script,ctx);return JSON.parse(JSON.stringify(ctx.r));}
const oldHairFirst=run(['hair','body'],actual),fixedHairFirst=run(['hair','body'],fixed),fixedBodyFirst=run(['body','hair'],fixed),hairOnly=run(['hair'],fixed);
assert.deepEqual(oldHairFirst.morphs,[],'actual firstmesh-only reader misses body targets');
for(const r of [fixedHairFirst,fixedBodyFirst]){assert.deepEqual(r.morphs,names);for(const n of names)assert.ok(r.morph_max_mm[n]>1,'actualCPUskin/morph surface exceeds unchanged1mm');}
assert.deepEqual(hairOnly.morphs,[],'does not invent missing targets');
const noMovement=run(['hair','body'],fixed,true);
function requiredAcceptance(r){return names.every(n=>r.morphs.includes(n)&&(r.morph_max_mm[n]||0)>1);}
assert.equal(requiredAcceptance(oldHairFirst),false);assert.equal(requiredAcceptance(hairOnly),false);assert.equal(requiredAcceptance(noMovement),false);assert.equal(requiredAcceptance(fixedHairFirst),true);assert.equal(requiredAcceptance(fixedBodyFirst),true);for(const n of names)assert.equal(noMovement.morph_max_mm[n],0);
const report={three_revision:THREE.REVISION,actual_source_excerpt:actual,proposed_one_line:replacement,old_hair_first:oldHairFirst,fixed_hair_first:fixedHairFirst,fixed_body_first:fixedBodyFirst,missing_targets_negative:hairOnly,no_movement_negative:noMovement,unchanged_required_names:names,unchanged_threshold_mm:1,scope:'Actual installed fixture reader excerpt + vendoredThree CPU SkinnedMesh/getVertexPosition; no browser/BPy/resident artifact/export acceptance.'};fs.writeFileSync('/workspace/shared/human-morph-pipeline-diagnosis/hair-first-canary.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:true,oldHairFirst,fixedHairFirst,fixedBodyFirst,hairOnly,noMovement}));
