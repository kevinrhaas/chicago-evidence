Run39184480142, exacthead2679d6c98fce2219a3c930cbf4eb03898079b4ae, terminal failure. Terminal full workflow log fetched once with configured gh; no artifact request/download or redispatch.

Legacy humans job passed: all8fixture master/web files reproduce byte-for-byte (log312–314);8GLBs opened at1280x800 and390x780 pass (log560); fixture actor desktop/mobile checks pass. This is legacy fixture evidence, not new resident acceptance.

Teamster original body preparation passed. Pinned Blender4.5.3 then failed first resident body object_mesh at builder274, called build364 (log1037–1046): LOD0 custom normal readback exceeds1e-3 vector tolerance. Actual numerical max/mean and bad corners were not printed before the guard, so UNKNOWN. No canonical master/export completed. Hair24container checks, hierarchy clone/validator/surface comparisons, timing audit and actual loaded resident gait/frame/camera checks were skipped. No resident photographic/period/biological claim follows.

Source-grounded diagnostic and codec analysis are separately saved under /workspace/shared/human-normal-readback-2679; the cause remains unproven and guard unchanged.
