# Original head/neck shared-boundary trial — unapplied

2026-10-19. Original CC0 generator edits derived from original horse V2; no traced anatomy or source-image geometry. GPL fit helper methodology remains separately identified in preview/head-fit.js. No app checkout changes or Blender execution.

`generate_horse.py --parameters parameters.json --output-dir output` creates candidate. `horse_geometry.py` creates the intermediate geometry. Existing V2 is retained in `baseline/`; historical V1 in `trial/`. Preview's model key `v2` means **this new join trial**, not the archived V2. `v2/output/` is a byte-identical candidate copy for the existing preview API. All other V2/V3 evidence stays untouched in ../horse-head-next.

## Geometry/deformation change

Remove internal posterior skull and upper-neck caps and replace their separate intersections with matching 24-vertex uncapped interface rings. First skull ring equals the last neck ring in model space; snap float32 boundary positions exactly. Each duplicate pair has identical root/head joint IDs and 0.5/0.5 weights and identical oriented area-weighted incident-face normals. Adjacent final neck ring has .25 head weight; adjacent second cranial ring .8 head. All other weights preserved. First two former posterior cranial rings are replaced, and skull tessellation uses24 rather than32 segments. The explicit neck region is rings8/9 (192..239); body/chest positions unchanged. This is an engineered visual/deformation boundary, not an attested anatomical landmark or globally certified watertight horse.

`check_join.py` verifies exact boundary POSITION/NORMAL/JOINTS/WEIGHTS, exact undeclared semantic buffers, skeleton table, sockets, locomotion metadata and actual animation outputs. Candidate654848bytes,14172triangles,6draws,15joints. `pure-join-validation.json` all checks passed. Repeat generation matches bytes. `khronos-v2-validation.json` reports0errors/0warnings. Source unit normals are exact across the paired boundary; emitted posed normals were not independently decoded/tested and no cross-LOD claim is made.

`preview/join-21phases.json`: actual GLTFLoader SkinnedMesh.getVertexPosition,21walk phases0..1 by.05, all24pair gaps exactly0m. Idle uses the same head bone/identical boundary weights but was not separately sampled. Rest screenshot and walk phase0/.25 images retained. Cameras/light/material identical between baseline and new candidate.

## Actual visual review

Viewed baseline rest profile, candidate rest profile/three-quarter and candidate phase.25 three-quarter through view_image. Posterior poll/neck notch is visibly removed and the join no longer exposes the old intersecting cap edge. Lower jaw transition still has a visible angular throat shape; forehead, ears, eyelid torus and muzzle remain primitive. No photographic acceptance. Saved8controlled images; no image editing.

## Actual paired gear check

Existing gearV3 bytes/route unchanged. `preview/head-fit-v2-headstrap-v3-distances.json` actual5headstrap meshes564triangles1692vertices versus actual deformed whole horse over21walk phases: zero SAT crossings, unsigned triangle minimum2.4064311693536523mm. Original SAT projection tolerance1e-8 retained; touch not reclassified away. Nearest-face sign is not containment in the overlapping/noncertified-watertight whole horse. Bit/rings/reins excluded by existing intentional mouth/attachment scope. No continuous-time, outside-volume, pressure/load or historical fit acceptance. Earlier gear failures remain in previous immutable archive.

## Reproduce after root resource release

- `python generate_horse.py --parameters parameters.json --output-dir output`
- `python check_join.py`
- `node khronos-v2.cjs`
- `node preview/run-v3-coupled.cjs` (despite inherited name, captures8beforeafter rest/walk images and boundary test; one owned browser closes in finally)
- `node preview/run-fit-v2-straps-v3.cjs` (21phase actual SAT+unsigneddistance; one owned browser closes in finally)

Runtime paths for existing Three/Playwright/Chromium are explicit in scripts. No local server/browser remained after receipt; root subsequently started its full preflight, so further renders are on hold.
