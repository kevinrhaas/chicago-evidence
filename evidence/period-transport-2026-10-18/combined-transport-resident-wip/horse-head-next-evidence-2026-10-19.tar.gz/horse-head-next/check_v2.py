import pathlib,json,struct,hashlib,subprocess,sys
import numpy as np
P=pathlib.Path(__file__).parent
NC={'SCALAR':1,'VEC3':3,'VEC4':4,'MAT4':16}
def load(path):
 raw=path.read_bytes();n=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+n]);binary=raw[28+n:]
 def acc(i):
  a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];return np.frombuffer(binary,dtype={5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']],offset=v.get('byteOffset',0)+a.get('byteOffset',0),count=a['count']*NC[a['type']]).reshape(a['count'],NC[a['type']]).copy()
 return raw,g,acc
base,b,ba=load(P/'baseline/output/equine_light_harness_skinned_prototype_01.glb');trial,t,ta=load(P/'v2/output/equine_light_harness_skinned_prototype_01.glb')
bm=json.loads((P/'baseline/output/manifest.json').read_text());tm=json.loads((P/'v2/output/manifest.json').read_text())
for key in ['sockets','frame','locomotion']:assert bm[key]==tm[key],key
joint=lambda d:{r['name']:{k:v for k,v in r.items()if k not in ['node','index']}for r in d['joint_table']}
assert joint(bm)==joint(tm)
def clips(g,acc):return{(a['name'],g['nodes'][c['target']['node']]['name'],c['target']['path']):(acc(a['samplers'][c['sampler']]['input']).tolist(),acc(a['samplers'][c['sampler']]['output']).tolist())for a in g['animations']for c in a['channels']}
assert clips(b,ba)==clips(t,ta)
def material(g,acc,name):
 for m in g['meshes']:
  for p in m['primitives']:
   if g['materials'][p['material']]['name']==name:return{key:acc(value)for key,value in p['attributes'].items()}
hooves_b=material(b,ba,'equine_hooves');hooves_t=material(t,ta,'equine_hooves');assert all(np.array_equal(hooves_b[k],hooves_t[k])for k in hooves_b)
# Root coat semantic block contains the complete untouched torso/neck/limbs.
# Compare each matching original source range, not global offsets after head edits.
unchanged_names=[]
for br in bm['vertex_ranges']:
 name=br['original_node']
 if name in ['head_material_equine_coat','head_material_equine_eyes']:continue
 tr=next(r for r in tm['vertex_ranges']if r['original_node']==name)
 assert br['vertex_count']==tr['vertex_count'],name
 bv=material(b,ba,b['materials'][br['material']]['name']);tv=material(t,ta,t['materials'][tr['material']]['name'])
 for key in bv:assert np.array_equal(bv[key][br['vertex_start']:br['vertex_start']+br['vertex_count']],tv[key][tr['vertex_start']:tr['vertex_start']+tr['vertex_count']]),(name,key)
 unchanged_names.append(name)
assert 'continuous_body_neck' in unchanged_names
subprocess.run([sys.executable,str(P/'v2/generate_horse.py'),'--parameters',str(P/'parameters.json'),'--output-dir',str(P/'v2/rebuild')],check=True,capture_output=True)
assert trial==(P/'v2/rebuild/equine_light_harness_skinned_prototype_01.glb').read_bytes()
report={'frozen_base':'9a84aae03','baseline_sha256':hashlib.sha256(base).hexdigest(),'trial_sha256':hashlib.sha256(trial).hexdigest(),'baseline':{k:bm[k]for k in ['bytes','triangles','mesh_draws','skin_joints']},'v2':{k:tm[k]for k in ['bytes','triangles','mesh_draws','skin_joints']},'checks':{'socket_records_exact':True,'joint_rest_semantics_exact':True,'all_animation_times_outputs_exact_by_named_target':True,'hoof_position_normal_joint_weight_arrays_exact':True,'all_matching_nonrefined_semantic_ranges_all_attributes_exact':unchanged_names,'two_trial_rebuilds_byte_equal':True},'limits':['Head surface changed; existing gear clearances NOT assumed unchanged','Actual swept sole test remains required before integration though all limb/sole/track data are exact','Original contour trial, no measured anatomy/photo acceptance','Browser render held for root gate coordination']}
(P/'pure-v2-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
