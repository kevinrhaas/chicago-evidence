"""Bounded head-local side-cheekpiece lateral-envelope check; NOT full gear fit."""
import pathlib,json,struct
import numpy as np
P=pathlib.Path(__file__).parent

def triangles(which):
 folder=P/which/'output';raw=(folder/'equine_light_harness_skinned_prototype_01.glb').read_bytes();jl=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+jl]);b=raw[28+jl:];manifest=json.loads((folder/'manifest.json').read_text());r=next(r for r in manifest['vertex_ranges']if r['original_node']=='head_material_equine_coat');p=next(m['primitives'][0]for m in g['meshes']if g['materials'][m['primitives'][0]['material']]['name']=='equine_coat')
 def acc(i,cols):
  a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];return np.frombuffer(b,dtype='<f4'if a['componentType']==5126 else'<u4',offset=v.get('byteOffset',0),count=a['count']*cols).reshape(-1,cols)
 verts=acc(p['attributes']['POSITION'],3).astype(float)-np.array([0,1.88,.80]);faces=acc(p['indices'],1).reshape(-1,3);faces=faces[np.all((faces>=r['vertex_start'])&(faces<r['vertex_start']+r['vertex_count']),axis=1)];return verts[faces]
def margin(tris,point,side):
 yz=tris[:,:,1:];a=yz[:,0];u=yz[:,1]-a;v=yz[:,2]-a;q=point[1:]-a;den=u[:,0]*v[:,1]-u[:,1]*v[:,0];valid=abs(den)>1e-12;b=np.zeros(len(den));c=b.copy();b[valid]=(q[valid,0]*v[valid,1]-q[valid,1]*v[valid,0])/den[valid];c[valid]=(u[valid,0]*q[valid,1]-u[valid,1]*q[valid,0])/den[valid];valid&=(b>=-1e-8)&(c>=-1e-8)&(b+c<=1+1e-8);x=side*((1-b-c)*tris[:,0,0]+b*tris[:,1,0]+c*tris[:,2,0]);valid&=x>=0
 return None if not valid.any()else float(side*point[0]-x[valid].max())
report={'scope':'63 samples per side (segment endpoints repeated) on UNCHANGED frozen generator cheekpiece centerline only; lateral coat-envelope margin (not Euclidean triangle distance), excludes straps thickness/width, muzzle/ear-inner surfaces, eyes, other routes and animated fit. Negative means centerline inside lateral coat envelope. No full gear-fit pass claim.','routes_source':'9a84aae03 tools/transport/generate_harness.py cheekpiece four authored points','cases':[]}
for side in [-1,1]:
 route=np.array([[side*.105,.13,.02],[side*.13,.015,.14],[side*.115,-.11,.28],[side*.095,-.20,.39]]);points=[a+(b-a)*q for a,b in zip(route[:-1],route[1:])for q in np.linspace(0,1,21)];points=np.array(points)
 result={'side':side}
 for which in ['baseline','trial']:
  tr=triangles(which);values=[margin(tr,p,side)for p in points];actual=[v for v in values if v is not None];result[which]={'queries':len(points),'projected_surface_hits':len(actual),'minimum_lateral_centerline_margin_m':min(actual),'inside_count':sum(v<0 for v in actual)}
 report['cases'].append(result)
(P/'gear-envelope-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
