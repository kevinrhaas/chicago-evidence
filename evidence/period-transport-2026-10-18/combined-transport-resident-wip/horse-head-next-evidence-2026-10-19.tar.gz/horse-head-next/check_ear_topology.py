import pathlib,ast,math,collections,json
P=pathlib.Path(__file__).parent

def ears(which):
 tree=ast.parse((P/which/'horse_geometry.py').read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='pinna');rows=[]
 def mesh(name,vertices,faces,material):return{'name':name,'vertices':vertices,'faces':faces,'material':material}
 def node(name,parent,mesh):rows.append(mesh)
 context={'math':math,'mesh':mesh,'node':node,'head':0,'coat':0,'inner':1};exec(compile(ast.Module(body=[fn],type_ignores=[]),str(P/which/'horse_geometry.py'),'exec'),context)
 for side in [-1,1]:context['pinna'](side)
 return rows
v1=ears('trial');v2=ears('v2');reports=[]
for side in [-1,1]:
 pieces=[p for p in v2 if p['name'].endswith('_'+str(side))];vertices={};faces=[]
 for p in pieces:
  for f in p['faces']:
   ids=[]
   for i in f:
    point=tuple(p['vertices'][i]);vertices.setdefault(point,len(vertices));ids.append(vertices[point])
   faces.append(ids)
 points=list(vertices);edges=collections.Counter();directed=collections.Counter();areas=[]
 for f in faces:
  a,b,c=[points[i]for i in f];u=[b[i]-a[i]for i in range(3)];v=[c[i]-a[i]for i in range(3)];areas.append(math.hypot(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])/2)
  for a,b in zip(f,f[1:]+f[:1]):edges[tuple(sorted((a,b)))]+=1;directed[a,b]+=1
 assert min(areas)>1e-12;assert all(n==2 for n in edges.values());assert all(n==directed[b,a]for(a,b),n in directed.items())
 def base(rows):return sorted(tuple(v)for p in rows if p['name'].endswith('_'+str(side))for v in p['vertices']if abs(v[1]-.12)<1e-12)
 assert base(v1)==base(v2)
 assert max(v[1]for p in v1 if p['name'].endswith('_'+str(side))for v in p['vertices'])==max(v[1]for p in pieces for v in p['vertices'])
 reports.append({'side':side,'welded_vertices':len(vertices),'triangles':len(faces),'minimum_triangle_area_m2':min(areas),'all_edges_two_oriented_faces':True,'base_ring_positions_exact_vsV1':True,'maximum_height_exact_vsV1':True})
(P/'ear-v2-topology.json').write_text(json.dumps(reports,indent=2)+'\n');print(json.dumps(reports,indent=2))
