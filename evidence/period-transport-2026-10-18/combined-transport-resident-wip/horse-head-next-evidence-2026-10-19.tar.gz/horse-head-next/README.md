# Original horse head and separate headstrap fitting trial

Outside-app work only. Frozen baseline9a84aae03, original CC0 generators and parameter bytes retained under baseline/. Regenerated baseline equals the actual committed horse GLB byte-for-byte. No app writes, Blender, external model, photographic tracing or historically attested anatomy claim.

## Head trial

trial/horse_geometry.py replaces separate cranium/cheek balls with one original cranio-facial loft; original muzzle and torso/neck remain. It adds curved two-surface pinnae with inner surfaces/rims, modest asymmetry, and smaller eyes with coat eyelid rims. Ears use a220mm modeled rise instead of baseline200mm; neither dimension is source-measured. Head/neck surfaces remain separate and are NOT claimed watertight or anatomically continuous.

Actual trial14,496triangles/6material draws/15joints/665,520bytes versus baseline14,544/5/15/661,624. Trial SHA468ca330a4bde4bb84b47d976264cd6c1d6e8caf2826a744285a6fd45f0b120b. Initial ear meshes left unused vertices with zero normals; that rejected iteration was fixed by compacting ONLY ear primitives before final export. Final baseline and trial Khronos both0errors/0warnings. pure-validation.json proves repeatable bytes; exact named joint rest/socket/animation-time/output semantics; actual unchanged torso/neck/muzzle/mane/tail/limb/hoof POSITION/NORMAL/JOINTS/WEIGHTS ranges. No gait or sole geometry was altered. This does not substitute for the normal loaded gait/contact gate before integration.

## Actual controlled visual review

preview/ contains12captured frames: baseline/trial × material/clay × front/profile/three-quarter; same neutral light, orthographic camera, dimensions and rest pose. Browser/server closed after each owned run, no page errors. Actually inspected with view_image: both material three-quarter/profile, trial material front, both clay three-quarter and trial clay profile. Other captured angles are available, not falsely called independently reviewed.

Trial removes visible cheek balls and the upper skull/face overlap break. Eye protrusion is smaller. Front ear concavity reads better than original thin solid posts. Remaining defects are explicit: broad planar skull/jaw silhouette, a conspicuous ring-like eyelid, thick flat ear side profiles and flattened tips, a remaining rear head/neck notch/seam, unchanged primitive muzzle/nostril/mouth forms. It still reads a procedural study, not a photographic horse. Do not claim the anatomical or period research gate passed.

## Gear failure retained, then separate route trial

The first centerline-only lateral check is gear-envelope-validation.json:63samples per side on the existing cheekpiece line, trial minimum8.81/19.02mm versus baseline16.40mm. This did NOT establish full fit.

Actual full check adapted existing project AABB/SAT plus nearest-face method from docs/RESEARCH/.../harness-fit/measure_forelimbs.py. All548actual triangles and1644vertices of5headstraps tested against actual deformed whole-horse surfaces at21walk phases, for each baseline and trial. Bit/ring hardware and reins excluded (intentional mouth/connection roles). Failures retained in preview/head-fit-21phases.json:

- Baseline118triangle pairs/phase: browband38,noseband80; nearest-face signed minimum−34.45mm.
- Head trial with old gear50pairs/phase: NEW crownpiece12,noseband38; nearest-face signed minimum−36.12mm.

Fewer crossings is not a pass. This exposed an existing headstrap fitting gap as well as the new crownpiece regression. No failure receipt was overwritten or routed around.

headstrap-trial/ is a SEPARATE original reconstruction proposal: cheekpiece upper points[±.125,.105,−.060], crownpiece Z−.060behind ears; noseband centerY−.125 and ellipse radii.084/.090m. Bit/rein endpoints, frame nodes, materials, widths/thicknesses, all body collar/trace/shaft routes remain original. Actual buffer comparison verifies all32other meshes' positions/normals and every node frame unchanged; repeatability and Khronos0/0 pass. Dimensions are engineering fit choices on this conjectural horse, not an1891plate or historical anatomy measurement.

preview/head-fit-headstrap-v1.json:21walk phases, zero AABB/SAT triangle pairs, no sampled vertex below−1mm; minimum signed nearest-face sample+2.474mm. This is a narrow **sampled criterion pass**, NOT proven true physical clearance: whole horse is not a single certified watertight surface, nearest-face sign does not prove inside/outside, and positive sampled vertex gaps do not give the minimum edge/face separation. No continuous-time, strap pressure, historic load, animal suitability or photographic acceptance.

Subsequent V2 ear and tighter route V2/V3 evidence is complete in FINAL-REVIEW.md and fit-evidence-provenance.json. All earlier fit receipts remain unchanged. Source-only hold was respected until parent released it; each later owned browser/server was closed after its bounded run.

## License and reproducibility

Original shape generators remain CC0-1.0. Existing project triangle-fit methodology and new measurement helpers are GPL-3.0-or-later code, kept separate from graphical-asset provenance. No third-party mesh, skin atlas or anatomical plate used. Baseline parameter JSON preserved; headstrap trial adds one explicitly labeled reconstruction settings block. Rebuild with generate_horse.py --parameters ../parameters.json --output-dir output; checker scripts declare their paths. No commits or publication performed.
