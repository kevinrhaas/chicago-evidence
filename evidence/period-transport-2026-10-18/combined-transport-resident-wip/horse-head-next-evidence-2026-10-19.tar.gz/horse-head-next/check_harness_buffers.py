import pathlib,json,struct,hashlib,subprocess,sys
import numpy as np
P=pathlib.Path(__file__).parent

def read(path):
 raw=path.read_bytes();jl=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+jl]);binary=raw[28+jl:]
 def acc(i):
  a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];cols={'SCALAR':1,'VEC3':3}[a['type']];return np.frombuffer(binary,dtype='<f4'if a['componentType']==5126 else'<u4',offset=v.get('byteOffset',0),count=a['count']*cols).copy()
 return raw,g,acc
raw,b,ba=read(P/'harness.glb');new,t,ta=read(P/'headstrap-trial/output/light_breastcollar_harness_reconstructed_01.glb');assert b['materials']==t['materials'];assert b['nodes']==t['nodes'];unchanged=[];changed=[]
for bm,tm in zip(b['meshes'],t['meshes']):
 assert bm['name']==tm['name'];bp,tp=bm['primitives'][0],tm['primitives'][0];same=all(np.array_equal(ba(bp['attributes'][k]),ta(tp['attributes'][k]))for k in bp['attributes'])
 if bm['name']in ['cheekpiece_l','cheekpiece_r','crownpiece','noseband']:changed.append(bm['name'])
 else:assert same,bm['name'];unchanged.append(bm['name'])
subprocess.run([sys.executable,str(P/'headstrap-trial/generate_harness.py'),'--parameters',str(P/'headstrap-trial/parameters.json'),'--output-dir',str(P/'headstrap-trial/rebuild')],check=True,capture_output=True);assert new==(P/'headstrap-trial/rebuild/light_breastcollar_harness_reconstructed_01.glb').read_bytes()
report={'actual_original_harness_sha256':hashlib.sha256(raw).hexdigest(),'actual_trial_harness_sha256':hashlib.sha256(new).hexdigest(),'materials_and_all_node_frames_exact':True,'actual_unchanged_mesh_position_normal_arrays':unchanged,'only_changed_meshes':changed,'rebuild_byte_equal':True,'width_thickness_parameter_status':'original parameter values retained, only separate headstrap_reconstruction_trial key added','limits':'actual saved21phase triangle criterion, not continuous-time/contact pressure/historical fit; paired horse remains original unaccepted anatomytrial'}
(P/'harness-buffer-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
