# V2 head / V3 headstrap bounded result — unapplied

No application edits, Blender, publication or historical-anatomy/photographic acceptance. All owned browsers and servers closed. Baseline source and all failed/pass fit iterations retained.

## Concrete head change and remaining visible defects

V2 horse GLB:14,428triangles,6draws,15joints,662,304bytes; SHA256 `1f19929753bd93777c56f18acb8c7e446630b8bc36f675f507cb7e05b5f48e05`. Original baseline14,544triangles,5draws,15joints. The extra draw is the inner-ear material; no claim this fits a town actor budget or Light-tier headroom.

Actual V2 front/profile/three-quarter material views and coupled V3 views opened using view_image, along with coupled clay three-quarter. Ear tips now taper to closed points rather than flat paddle ends. Each ear has289weldedvertices/574triangles and two oppositely oriented faces per welded edge; minimum triangle area1.806e-5m². Ear base and maximumheight remain exactlyV1. V2/root semantic checks preserve named skeleton/rest/socket tables, exact animation times/outputs, and unchanged torso/neck/muzzle/mane/tail/limb/hoof attribute ranges. Two builds byte-identical; Khronos0errors/0warnings.

Cheek balls and the upper skull overlap break are removed, and the eye protrudes less. Still unresolved: thick ear sideprofiles, broad faceted head/jaw shape, ring/grommet eyelid, sharp rear head/neck notch/seam, primitive muzzle/nostrils/mouth, missing anatomical/PBR detail. Continuous physical head/neck topology and consistent boundary skinning are not supplied. This is useful original reconstruction work, **not visually ready photographic anatomy**.

## Retained fitting history

`fit-evidence-provenance.json` pins every actual fit JSON and horse/harness GLB SHA. Earlier failures were not overwritten:

| Head / gear | Phases | SAT triangle pairs per phase | Result |
|---|---:|---:|---|
| Baseline / original gear |21|118(brow38,nose80)|FAIL|
| V1head / original gear |21|50(newcrown12,nose38)|FAIL|
| V1head / separate routeV1 |21|0|narrow sampled pass|
| V2ear / routeV1 |21|0|unsigned minimum2.467405mm|
| V2ear / tighter routeV2 |21|58(cheek22+24,brow12)|FAIL despite positive sampled vertex signs|
| V2ear / routeV3 |21|0|unsigned minimum2.146834mm|

Tighter routeV2's failure is important evidence: vertices remained outside by nearest-face sign, but long flat strap faces crossed the skull bulge and brow edge. RouteV3 adds a poll-side contour point and raises the brow3–5mm while keeping attachment endpoints coherent. This addresses actual full-triangle crossings rather than weakening the test.

## Final paired routeV3 evidence and exact scope

RouteV3 actual21phase check uses all564headstraptriangles/1692duplicatedflatmeshvertices (5strapmeshes), against actual deformed whole-horse geometry. Zero AABB+SAT overlap pairs at each discrete phase; nearest sampled vertex signed minimum+2.473926mm. Independently computed **unsigned full triangle minimum2.146834mm**, at phase.85, browband→coat. Safe AABB distance lower bounds prune remote pairs; remaining pairs use vertex/face, finite edge/edge and edge/face piercing distance tests. Seven independent analytic fixtures pass.

The whole horse is not one certified watertight volume. Unsigned distance says surfaces are separated at those sampled poses; it does NOT establish containment, animal comfort, pressure, tension, continuous-time clearance or historical load suitability. Nearest-face sign remains a separate local diagnostic. SAT uses the existing project1e-8projection tolerance, counting contact as overlap; zero pairs is stronger than simply reclassifying contacts as harmless. No collision threshold was weakened.

V3 gear:7,548triangles/36meshes/569,564bytes, SHA256 `b4a7318053e8508617a24fff64f02beb7eee77684db689dc04771d209a54fa8b`. Original gear7,532triangles;16extra triangles come from the added cheek control segments. All materials/nodeframes and31other mesh POSITION/NORMAL arrays exactly unchanged, including bits, rings, reins, body collar, traces and shaft fittings. All original parameter values retain exact values; only a declared head trial block added. Strap width/thickness parameters unchanged. Rebuild byte-equal; Khronos0/0.

Route controls are a reconstruction toile, not primary-source dimensions. Brow/crown endpoints now meet cheek vertices and visually follow the forehead better than routeV1. Straps still look angular; check-rein passes near the eye and remains a separate unresolved original route; noseband/cheek attachment hardware and leather flexibility need development. This is NOT complete harness assembly or a fitted historic bridle claim. **V3 was measured with V2horse only; do not apply it independently to the baseline horse without its own fit check.**

## Delivery and next review

- `v2/` holds the candidate horse generators/output; `headstrap-trial-v3/` holds the separate paired gear source/parameters/output.
- Original baseline, V1geometry and routeV1/V2 failures/pass receipts remain in their named folders.
- `preview/` holds same-camera before/after material/clay and paired renders, actual fit/distance JSON and browser scripts. No source image was edited.
- `pure-v2-validation.json`, `ear-v2-topology.json`, `harness-v3-buffer-validation.json`, Khronos receipts and fit provenance state actual assertions/limits.

Review actual images before any integration. Head/neck continuous geometry, eyelids, ear thickness, proper skin/material response and anatomy references remain next quality work. Re-run the existing full loaded gait/contact and coupled integration tests if adopted; no claim these scratch experiments complete T2800/T2801/T2803 or photographic acceptance.
