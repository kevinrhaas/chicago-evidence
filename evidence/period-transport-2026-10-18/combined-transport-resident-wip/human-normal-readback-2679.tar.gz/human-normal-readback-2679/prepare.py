from pathlib import Path
import difflib
base=Path('/workspace/shared/human-ci-watch-2679d6c98/human_teamster_blend.frozen.py');out=Path('/workspace/shared/human-normal-readback-2679');old=base.read_text()
start=old.index('                if not deltas or max(deltas)>1e-3:')
end=old.index('        obj = bpy.data.objects.new(name,mesh)',start)
newblock='''                source_groups={}
                for i,loop in enumerate(mesh.loops):
                    sid=source_vertex_indices[loop.vertex_index]
                    group=source_groups.setdefault(sid,{'vertices':set(),'normals':set()})
                    group['vertices'].add(loop.vertex_index)
                    group['normals'].add(tuple(actual[i].vector))
                seam_deltas=[]
                for sid,group in source_groups.items():
                    if len(group['vertices'])<2:continue
                    vectors=list(group['normals'])
                    spread=max((math.dist(a,b) for j,a in enumerate(vectors) for b in vectors[j+1:]),default=0.0)
                    seam_deltas.append({'source_vertex_id':sid,'duplicate_vertices':len(group['vertices']),
                        'actual_normal_variants':len(vectors),'maximum_pair_vector_delta':spread})
                seam_deltas.sort(key=lambda x:(-x['maximum_pair_vector_delta'],x['source_vertex_id']))
                top=sorted(range(len(deltas)),key=lambda i:deltas[i],reverse=True)[:5]
                audit={'asset_id':asset,'mesh':name,'corners':len(deltas),
                    'max_vector_delta':max(deltas) if deltas else None,
                    'mean_vector_delta':math.fsum(deltas)/len(deltas) if deltas else None,
                    'bad_corner_count':sum(delta>1e-3 for delta in deltas),
                    'tolerance':1e-3,'status':'passed' if deltas and max(deltas)<=1e-3 else 'failed',
                    'source_uv_seam_disagreement':{'scope':'actual corner normal pair spread across distinct UV-split vertices sharing source ID; diagnostic only',
                        'duplicate_source_groups':len(seam_deltas),
                        'max_pair_vector_delta':max((x['maximum_pair_vector_delta'] for x in seam_deltas),default=0.0),
                        'groups_over_1e_3':sum(x['maximum_pair_vector_delta']>1e-3 for x in seam_deltas),
                        'top_groups':seam_deltas[:5]},
                    'top_corners':[{'loop_index':i,'vertex_index':mesh.loops[i].vertex_index,
                        'source_vertex_id':source_vertex_indices[mesh.loops[i].vertex_index],
                        'vector_delta':deltas[i],
                        'expected_normal':converted[mesh.loops[i].vertex_index],
                        'actual_normal':tuple(actual[i].vector)} for i in top],
                    'scope':'local LOD0 BPy readback before modifiers/export; bounded diagnostics only, not emitted GLB/morph/decimated normal acceptance'}
                print(json.dumps({'body_normal_preexport_audit':audit}),flush=True)
                if not deltas or max(deltas)>1e-3:
                    raise ValueError('LOD0 body custom normal readback exceeds 1e-3 vector tolerance')
'''
new=old[:start]+newblock+old[end:]
(out/'human_teamster_blend.diagnostics.py').write_text(new)
(out/'normal-diagnostics-only-4D-ROOT.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/tools/human_teamster_blend.py',tofile='b/tools/human_teamster_blend.py')))
# Separate explicitly defensive experiment; not a proven repair.
marker='''        if source_vertex_indices is not None:
            # Body UV duplicates'''
experiment=new.replace(marker,'''        if source_vertex_indices is not None:
            # Defensive cache synchronization before custom-normal encoding.
            # RNA smooth setters already dirty normal caches; not a proven fix.
            mesh.update()
            # Body UV duplicates''')
assert experiment!=new
(out/'normal-diagnostics-and-presync-EXPERIMENT-4D-ROOT.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),experiment.splitlines(True),fromfile='a/tools/human_teamster_blend.py',tofile='b/tools/human_teamster_blend.py')))
