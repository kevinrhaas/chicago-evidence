"""Source-based counterexample and CONDITIONAL angular bound, not BPy execution."""
import json,math,struct
from pathlib import Path
f=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
T=f(f(1)-f(1e-4));S=32767;E=4.51803e-5
# Orthogonal right-triangle fan: lnor=Z, ref=X, ortho=Y;
# ref_alpha=ref_beta=pi/2. All vectors are valid unit vectors.
beta=.01;target=(math.cos(beta),math.sin(beta),0.0);decoded=(1.0,0.0,0.0)
assert math.cos(beta)>=T and abs(math.hypot(*target)-1)<1e-15
Q=math.pi/S;theta=math.acos(T);noop=math.sqrt(3)*1e-4
regular=2*math.sin((2*E+2*Q)/2);snap=2*math.sin((E+Q+theta)/2)
report={'scope':'source-level mathematical codec analysis; not actual failed CIcorner or complete floating-point/BPy bound','threshold_float32':T,'source_acos_stated_max_error_rad':E,'ideal_rounding_max_angle_rad':Q,'componentwise_noop_vector_bound':noop,'ideal_regular_branch_vector_bound_with_source_acos_error':regular,'ideal_snap_branch_vector_bound_with_source_acos_error':snap,'counterexample':{'basis':{'auto_normal':[0,0,1],'reference':[1,0,0],'orthogonal':[0,1,0],'ref_alpha_rad':math.pi/2,'ref_beta_rad':math.pi/2},'target_unit_normal':target,'beta_rad':beta,'cos_beta':math.cos(beta),'cos_beta_snap_branch':True,'decoded_ideal_normal':decoded,'vector_delta':math.dist(target,decoded)},'not_proven':'Source acos error plus ideal integer quantization does not bound dot/projection conditioning, short conversion float arithmetic, basis errors, invalid/missing fan fallbacks or final runtime normalization. Do not substitute these conditional numbers for production tolerance.'}
if __name__=='__main__':
 Path(__file__).with_name('codec-conditional-analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
