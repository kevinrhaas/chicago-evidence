import ast,contextlib,io,json,math,sys,types,unittest
from pathlib import Path
HERE=Path(__file__).parent
module=types.ModuleType('human_source_normals');exec(Path('/workspace/shared/human-ci-watch-2679d6c98/human_source_normals.frozen.py').read_text(),module.__dict__);sys.modules['human_source_normals']=module
class V(tuple):
 def normalized(self):
  n=math.hypot(*self);return V(x/n for x in self)
class Tests(unittest.TestCase):
 def execute(self,error,seam_flip=False):
  tree=ast.parse((HERE/'human_teamster_blend.diagnostics.py').read_text());fn=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='object_mesh');block=next(n for n in fn.body if isinstance(n,ast.If)and ast.unparse(n.test)=='source_vertex_indices is not None')
  loops=[types.SimpleNamespace(vertex_index=i)for i in range(6)]
  mesh=types.SimpleNamespace(loops=loops,has_custom_normals=True,update=lambda:None)
  def setter(normals):
   mesh.corner_normals=[]
   for i,normal in enumerate(normals):
    actual=list(normal);actual[0]+=error*(-1 if seam_flip and i>=3 else 1);n=math.hypot(*actual);mesh.corner_normals.append(types.SimpleNamespace(vector=tuple(x/n for x in actual)))
  mesh.normals_split_custom_set=setter
  ns={'mesh':mesh,'source_vertex_indices':[10,11,12,10,11,12],'points':[(0,0,0),(1,0,0),(0,1,0)]*2,'faces':[(0,1,2),(3,4,5)],'xyz':lambda p:V((p[0],-p[2],p[1])),'ratio':1,'asset':'EXPLICIT MOCK','name':'EXPLICIT MOCK BODY','math':math,'json':json}
  output=io.StringIO();raised=None
  with contextlib.redirect_stdout(output):
   try:exec(compile(ast.fix_missing_locations(ast.Module(body=[block],type_ignores=[])),'actual diagnostic block','exec'),ns)
   except ValueError as exc:raised=str(exc)
  return json.loads(output.getvalue())['body_normal_preexport_audit'],raised
 def test_fail_prints_bounded_metrics_before_same_guard(self):
  r,error=self.execute(.01);self.assertIn('1e-3',error);self.assertEqual(r['status'],'failed');self.assertEqual(r['bad_corner_count'],6);self.assertEqual(len(r['top_corners']),5);self.assertGreater(r['max_vector_delta'],1e-3);self.assertEqual(r['tolerance'],1e-3)
  for p in r['top_corners']:self.assertEqual(len(p['actual_normal']),3);self.assertIn(p['source_vertex_id'],[10,11,12])
 def test_pass_keeps_same_tolerance(self):
  r,error=self.execute(1e-5);self.assertIsNone(error);self.assertEqual(r['status'],'passed');self.assertEqual(r['bad_corner_count'],0);self.assertLess(r['max_vector_delta'],1e-3)
 def test_seam_disagreement_is_measured_before_rejection(self):
  r,error=self.execute(.01,seam_flip=True);self.assertIsNotNone(error);seam=r['source_uv_seam_disagreement'];self.assertEqual(seam['duplicate_source_groups'],3);self.assertEqual(seam['groups_over_1e_3'],3);self.assertGreater(seam['max_pair_vector_delta'],.019);self.assertLessEqual(len(seam['top_groups']),5)
if __name__=='__main__':unittest.main()
