# Blender4.5.3 custom-normal codec: proven counterexample and limits of a total bound

The actual failed CI corner values remain unknown: run39184480142 threw before printing max/mean. This report does not identify that failure's cause. It does show that1e-3 is **not a universal bound for all otherwise valid unit custom normals** under the pinned codec. No guard is changed here.

## Official pinned source actually read

Full official-source URLs, local paths and SHA256 are in pinned-source-receipts.json. All sources are Blender/blender tagv4.5.3, retrieved read-only with configured gh's official contents API. The key locations:

- mesh_normals.cc578: `LNOR_SPACE_TRIGO_THRESHOLD (1.0f - 1e-4f)`.
- mesh_normals.cc585–640: corner frame construction; normalized reference/orthogonal vectors; ref_alpha/ref_beta. Near-aligned edge/auto-normal inputs invalidate the space at592–598.
- mesh_normals.cc685–694: `float(short)/SHRT_MAX` and `short(floorf(value*SHRT_MAX+0.5f))`.
- mesh_normals.cc698–733: decode returns vec_lnor for alpha-code0 or zero reference angles; otherwise spherical reconstruction in the corner frame.
- mesh_normals.cc750–795: encode compares requested unit normal with default at component tolerance1e-4; computes alpha and projected beta; **if cos_beta>=threshold it writes beta-code0**, which decodes along vec_ref instead of preserving the small azimuth.
- mesh_normals.cc1508–1532: fan normals are averaged before encoding;1500 can skip missing corner space. These are additional preconditions beyond an isolated ideal codec pair.
- BLI_math_base.hh218–233: safe_acos_approx's documented maximum error4.51803e-5rad, with source's stated float-domain examination. We did not independently repeat that examination.
- math_vector_inline.cc1003–1006: compare_v3v3 is three componentwise comparisons.

Cache evidence relevant to the separate stale-smooth hypothesis: rna_mesh.cc586–602 calls tag_sharpness_changed when polygon.use_smooth changes; mesh_runtime.cc370–375 dirties vertex/face/corner normal caches. rna_mesh_api.cc180–201 mesh.update also dirties them. Therefore an extra pre-set update is a defensive experiment, **not a demonstrated repair**. RNA setter already requests invalidation.

## Valid-unit-normal analytical counterexample

Use an ordinary valid orthonormal corner frame:

```
auto normal = (0,0,1)
reference   = (1,0,0)
orthogonal  = (0,1,0)
ref_alpha = ref_beta = pi/2
requested unit normal = (cos(.01), sin(.01), 0)
```

The frame passes the source's nonalignment checks (reference/other edge dot auto-normal=0); perpendicular in-plane edges realize the reference-angle geometry of a nondegenerate right-triangle corner. The requested normal is a valid unit normal; custom normals need not equal the geometric face normal.

Alpha is pi/2 and encoded at the reference endpoint. Projected cos_beta=cos(.01)=0.9999500004167. The actual float32 threshold is0.9998999834060669, so the source takes the beta-zero branch. Decode yields reference=(1,0,0), apart from small float trigonometric residue. The ideal vector error is `2*sin(.01/2)=0.0099999583334`, nearly10times1e-3. This branch margin (~5e-5 in cos, ~.009 in vector over the guard) is far larger than a last-bit alpha effect. It does not rely on a degenerate fan, invalid unit normal, nonexistent API or a guessed rounding overflow. It is a source-level counterexample, not local Blender execution or the actual resident corner.

## Conditional complete branch bound for the ideal angular codec

Let S=32767; assume exact orthonormal fan axes, nonzero valid reference angles, identical requested normal for every corner averaged into that fan, ideal arithmetic in short conversion/reconstruction, and independently supplied wrapped angular input-error budgets e_alpha/e_beta. Alpha/beta represent angles modulo2pi when the negative code branch is used. Each encoded angular range is at most2pi, so round-to-nearest integer contributes at most `Q=pi/S=9.58767251683e-5rad` per angle.

Let T be the float32 threshold above. A measured cosine could itself have error; call its absolute error budget k_beta. The beta-snap angular error is bounded by `acos(clamp(T-k_beta,-1,1))`. For the ordinary non-snap branch it is e_beta+Q. Therefore, with `A=e_alpha+Q` and `B=max(e_beta+Q,acos(T-k_beta))`, a spherical path gives geodesic error<=min(pi,A+B) and unit-vector chord error<=`2*sin(min(pi,A+B)/2)`. This uses the triangle inequality through equal-alpha/equal-beta arcs; near-pole azimuth is overbounded, not ignored.

The remaining ordinary no-op branches are also covered explicitly:

- componentwise default comparison: vector error<=sqrt(3)*1e-4=0.000173205081;
- alpha-code rounds to0: angular distance to default<=e_alpha+Q (Q is conservative since positive ref_alpha is at mostpi);
- beta-code rounds to0 near0/2pi: wrapped azimuth error<=e_beta+Q, already covered above;
- all-zero requested input is outside the stated unit-input premise and must not be counted as a successful unit-normal encoding.

Using ONLY the source's acos approximation error as each angular budget and k_beta=0, the ideal regular branch bound is0.0002821140494; the beta-snap branch bound is0.0142843624061. These numbers include ideal alpha/beta integer rounding and the documented acos error, and explain why a1e-3 universal codec claim is invalid. **They are not yet a total float32/BPy bound.**

## Why the total implementation bound is not0.0143

The complete implementation also normalizes/averages vectors, builds the fan basis, forms dot products and a projected direction, divides by reference angles, rounds floating products before floorf, and evaluates trigonometric reconstruction. Source acos's advertised error does not cover dot-input errors or projection conditioning. Invalid/missing fan-space branches can bypass the intended custom normal entirely. For example the frame constructor's early invalid return leaves its zero-initialized vector/angles, so its decoder fallback can return zero, with unit-input error1. A missing corner-space index can skip encoding. An automatic fallback unit vector can in principle differ from the requested unit vector by up to2.

Thus the only unconditional ideal-unit-vector statement without additional fan/error premises is the trivial diameter bound2; for nonunit computed outputs the universally valid statement is merely `||actual-expected|| <= ||actual||+||expected||`. These bounds cannot serve as useful smoothing-quality acceptance. We do **not** recommend replacing1e-3 with2,0.015,0.02 or any other number to force this CI green.

A defensible narrower criterion needs either a proven full floating-point bound under verified nondegenerate fan premises, or a source-matched per-corner codec/reconstruction audit with invalid/fallback detection, followed by the actual logged max/mean/top-corner values and actual UV-seam disagreement. The supplied diagnostics now report all of those observable error metrics before the unchanged guard rejects. A future source-supported acceptance decision must also preserve topology/UV/weights and check actual emitted GLB normals/rendered seams; passing local BPy readback alone does not establish these.

## Files and verification

codec_analysis.py reproduces the analytical counterexample/conditional numbers; codec-conditional-analysis.json records them. It is not presented as Blender execution or an exhaustive IEEE754 proof. normal-diagnostics-only-4D-ROOT.patch emits bounded max/mean/badcount/top5 corner/source-ID/intended/actual normal records and UV-seam pair spreads before the existing unchanged1e-3 guard. Three tests execute the actual proposed source block under explicit mock data, proving failed metrics are printed before rejection, passing case uses the same guard, and seam disagreements are measured. Outside frozen2679 apply-check passes. The separate presync EXPERIMENT patch is not a proven fix. No app writes, local BPy/browser runs, artifact downloads or redispatch occurred.
