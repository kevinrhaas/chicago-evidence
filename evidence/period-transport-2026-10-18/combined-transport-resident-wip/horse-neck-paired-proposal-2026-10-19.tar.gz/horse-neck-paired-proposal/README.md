# Paired horse+headstrap proposal — outside checkout, unapplied

Snapshot contextual replacements against current combined working tree; baseline HEAD+every old/new SHA256 listed in replacement-manifest.json. Apply only after all old hashes still match, or root manually resolves. **Pair horse and harness; never apply horse alone.** Source+JSON contextual patch is source-sidecars.patch; exact GLBs included under files/. Do not apply the earlier frozen9a84 patch blindly over current source.

Full replacement tree includes three generators, harness parameter JSON, horse GLB+manifest and harness GLB+manifest+geometry-stats. Horse parameters unchanged. This deliberately includes original V1head/V2ear refinement + latest shared join + V3gear routes. Pure source generated outputs deterministic previously; no app output regenerated during current fullgate.

## Verified here against current bytes

- check_join.py actual current horse versus proposed: named skeleton/rest/parent tables exact, socket tables exact, locomotion exact, all animation time/value arrays exact by named target/path. Numeric glTF node indices differ due removed/added source geometry nodes; they are not stable semantic IDs. Initial copied check falsely compared raw node indices and included intentionally changed eyes; that failed, then corrected named semantic scope, not weakened geometry protection.
- Every retained unchanged semantic range's POSITION/NORMAL/JOINTS/WEIGHTS exact; explicit changed head coat+eyes excluded. Torso POSITION first240 vertices exact, torso normal/weight first192 exact, last2neck rings declared deformation/normal edit. Hoof rest/skin arrays and limb buffers exact.
- Whole bounds are NOT unchanged: bounds-proof.json exact actual extrema show Ymax2.200799942→2.220000029m (+19.200087mm), other minima/maxima unchanged. Ear reconstruction accounts for change; no dishonest unchanged-bounds claim.
- Candidate GLB6e9b37b755ae3eda7b5cf2f492d1781b0e507664a99c88a2e6dee086f77c2296,654848bytes14172tris6materialdraws15joints. Gear b4a7318053e8508617a24fff64f02beb7eee77684db689dc04771d209a54fa8b,569564bytes7548tris36meshdraws. Khronos0/0. Source/output sidecar keys remain compatible.
- Actual Three loaded walk21phases interface gap0m. Actual existing V3gear564triangles versus new whole-horse surface21phases:0SATcrossings, unsigned minimum2.406431169mm. Retained full evidence and controlled actual-viewed PNGs in evidence/. Actual screenshots remove posterior notch, but angular jaw/primitive ears/eye/muzzle remain. No photo acceptance.
- Protected hashes include harness/horse demos, hitch/carriage logic, wagon generator and horse parameter data. Proposed patch touches none.

## Required post-integration verification (not covered by old outputs)

1. Rebuild both GLBs from integrated source/data into scratch; compare exact committed GLB/manifest/stats; validate both Khronos0/0. Existing unchanged outputs do not cover new geometry.
2. Run `tools/transport/smoke_skin.cjs`: loaded skinned/Skeleton/AnimationMixer and ACTUAL sole-vertex idle/walk contact drift, rotation/inversebind checks. Rest unchanged does not imply pass; retain actual result.
3. Run `tools/transport/smoke_studies.cjs`: all isolated horse/harness affected views, browser errors, draw/triangle evidence, controls, bounds/framing.
4. Run current existing hitch checks (`tools/transport/smoke_hitch.py` and actual associated browser flow per AGENTS/source): walk/rootdistance, start-stop/turn profiles, authored shaft/tug fit, reins/trace endpoints. Mesh arrays/routes protected but new wholehorse still needs actual coupled review.
5. Rerun actual torso/forelimb triangle checks from docs/RESEARCH/period-transport-2026-10-18/harness-fit/measure.py and measure_forelimbs.py; do not reuse old JSON as new pass. Head check outside contains precise new head geometry and V3strap evidence, but application helper integration/reproduction remains root-owned.
6. Actual controlled rest+animated coupled render review plus full required publish/check gate. Browser hold respected during root fullgate; no extra browser run performed for this proposal.

License/liberty text is proposed append-only in LICENSE-APPENDS.md; no new invented biography, animal identity or source license is asserted. Existing anatomy/Blender master/UV/PBR/LOD/rig/photo/period proof tickets remain open.
