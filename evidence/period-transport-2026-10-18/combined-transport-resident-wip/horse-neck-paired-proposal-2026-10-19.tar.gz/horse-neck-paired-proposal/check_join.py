# SPDX-License-Identifier: CC0-1.0
import json,struct,pathlib,hashlib,numpy as np
P=pathlib.Path(__file__).parent

def load(path):
 b=path.read_bytes();n=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+n]);blob=b[28+n:]
 def read(i):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];return np.frombuffer(blob,dtype={5126:'<f4',5123:'<u2',5125:'<u4'}[a['componentType']],count=a['count']*{'VEC3':3,'VEC4':4,'SCALAR':1,'MAT4':16}[a['type']],offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(a['count'],-1)
 return d,read
base,br=load(P/'baseline/output/equine_light_harness_skinned_prototype_01.glb');d,r=load(P/'output/equine_light_harness_skinned_prototype_01.glb');bm=json.loads((P/'baseline/output/manifest.json').read_text());m=json.loads((P/'output/manifest.json').read_text());a=d['meshes'][0]['primitives'][0]['attributes'];rec=m['join_trial']['records'];ni=rec['neck']['interface'];hi=rec['head']['interface'];checks={}
for attr in ('POSITION','NORMAL','JOINTS_0','WEIGHTS_0'):checks['boundary_'+attr]=bool(np.array_equal(r(a[attr])[ni],r(a[attr])[hi]))
checks['joint_table_named_rest']= [{k:v for k,v in x.items() if k not in ('index','node')} for x in bm['joint_table']]==[{k:v for k,v in x.items() if k not in ('index','node')} for x in m['joint_table']];checks['sockets']=bm['sockets']==m['sockets'];checks['locomotion']=bm['locomotion']==m['locomotion']
# All unchanged semantic ranges compare independently, despite material offsets changing.
for old in bm['vertex_ranges']:
 new=next(x for x in m['vertex_ranges'] if x['original_node']==old['original_node'])
 for attr in ('POSITION','NORMAL','JOINTS_0','WEIGHTS_0'):
  ba=base['meshes'][old['material']]['primitives'][0]['attributes'][attr];na=d['meshes'][new['material']]['primitives'][0]['attributes'][attr]
  count=old['vertex_count']
  if old['original_node'] in ('head_material_equine_coat','head_material_equine_eyes'):continue # explicit changed head loft/tessellation
  if old['original_node']=='continuous_body_neck':count=192 if attr in ('NORMAL','JOINTS_0','WEIGHTS_0') else 240
  checks[old['original_node']+'_'+attr]=bool(np.array_equal(br(ba)[old['vertex_start']:old['vertex_start']+count],r(na)[new['vertex_start']:new['vertex_start']+count]))
# Independent animation accessor equality, including semantic channels.
def tracks(doc,read):
 return {(anim['name'],doc['nodes'][channel['target']['node']]['name'],channel['target']['path']): [read(anim['samplers'][channel['sampler']][key]) for key in ('input','output')] for anim in doc['animations'] for channel in anim['channels']}
oldtracks,newtracks=tracks(base,br),tracks(d,r)
checks['animations_named_tracks']=oldtracks.keys()==newtracks.keys() and all(all(np.array_equal(x,y) for x,y in zip(oldtracks[k],newtracks[k])) for k in oldtracks)

receipt={'passed':all(checks.values()),'checks':checks,'sha256':hashlib.sha256((P/'output/equine_light_harness_skinned_prototype_01.glb').read_bytes()).hexdigest(),'bytes':(P/'output/equine_light_harness_skinned_prototype_01.glb').stat().st_size,'triangles':m['triangles']}
(P/'pure-join-validation.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'passed':receipt['passed'],'failures':[k for k,v in checks.items() if not v]}));assert receipt['passed']
