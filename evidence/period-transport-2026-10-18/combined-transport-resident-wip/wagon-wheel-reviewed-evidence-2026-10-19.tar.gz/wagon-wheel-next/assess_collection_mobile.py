"""Read-only static projection of current real fixture CSS/camera and GLB."""
import json,struct,math,hashlib
from pathlib import Path
R=Path('/workspace/chicago/chicago/4d');O=Path(__file__).parent
b=(R/'renderers/web/transport/wagon/wagon-w01.glb').read_bytes();n=struct.unpack_from('<I',b,12)[0];g=json.loads(b[20:20+n]);raw=b[28+n:];parent={c:i for i,node in enumerate(g['nodes']) for c in node.get('children',[])}
points=[]
for i,node in enumerate(g['nodes']):
 if 'mesh' not in node:continue
 for p in g['meshes'][node['mesh']]['primitives']:
  a=g['accessors'][p['attributes']['POSITION']];v=g['bufferViews'][a['bufferView']];off=v.get('byteOffset',0)+a.get('byteOffset',0)
  for j in range(a['count']):
   point=list(struct.unpack_from('<3f',raw,off+j*12));index=i
   while True:
    point=[x+y for x,y in zip(point,g['nodes'][index].get('translation',[0,0,0]))]
    if index not in parent:break
    index=parent[index]
   points.append(point)
sub=lambda a,b:[x-y for x,y in zip(a,b)]
dot=lambda a,b:sum(x*y for x,y in zip(a,b))
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def unit(a):return [x/math.sqrt(dot(a,a)) for x in a]
target=[0,.65,1];theta=.95;phi=1.05;distance=10.8;camera=[target[0]+distance*math.sin(phi)*math.sin(theta),target[1]+distance*math.cos(phi),target[2]+distance*math.sin(phi)*math.cos(theta)];forward=unit(sub(target,camera));right=unit(cross(forward,[0,1,0]));up=cross(right,forward)
rows=[]
for viewport in [(390,780),(390,844),(1280,800)]:
 width,height=viewport;canvasheight=height*.57 if width<500 else height;aspect=width/canvasheight;tan=math.tan(math.radians(20));ndc=[]
 for p in points:
  d=sub(p,camera);depth=dot(d,forward);ndc.append([dot(d,right)/(depth*tan*aspect),dot(d,up)/(depth*tan)])
 lo=[min(p[k] for p in ndc) for k in range(2)];hi=[max(p[k] for p in ndc) for k in range(2)]
 rows.append({'viewport':viewport,'canvas_css_width_height':[width,canvasheight],'ndc_min':lo,'ndc_max':hi,'all_model_vertices_inside':all(abs(x)<=1 for x in lo+hi),'note':'Static default rest scene, original raisedtongue/zero steering/travel. Does not prove fit after controls, sidebar layout, animation or browser pixel rounding.'})
report={'status':'read-only source/actualGLB projection; not live published-page validation','fixture_sha256':hashlib.sha256((R/'renderers/web/transport/wagon/fixture.js').read_bytes()).hexdigest(),'index_sha256':hashlib.sha256((R/'renderers/web/transport/wagon/index.html').read_bytes()).hexdigest(),'camera':{'position':camera,'target':target,'fov':40},'results':rows,'assessment':'Actual wagon page mobilecanvas is57vh; old outside comparison mobilecanvas was100vh, so its croppedreceipt is not evidence currentcollectionpage is cropped. Current code keeps fixed distance10.8 onresize and has no modelbounds fit; orientation/travel can still exceedframe and needs separate livepage review. Collection index itself is responsive links/cards and owns no3Dcamera. No camera patch proposed in this parcel.'}
(O/'current-collection-mobile-assessment.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(rows,indent=2))
