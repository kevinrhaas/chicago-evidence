# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import json,hashlib,subprocess,shutil,difflib,math,struct
O=Path(__file__).parent;R=Path('/workspace/chicago/chicago/4d');B=O/'integration-bundle';B.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(rel,text):
 p=B/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text);return p
protected={str(p.relative_to(R)):sha(p) for name in ['carriage','horse','harness'] for p in sorted((R/'renderers/web/transport'/name).rglob('*')) if p.is_file()}
source_rows={str(p.relative_to(R)):sha(p) for p in [R/'tools/transport/generate_wagon.py',R/'tools/transport/generate_studies.py',R/'data/transport/studies/wagon.json',R/'renderers/web/transport/wagon/wagon-w01.glb',R/'renderers/web/transport/wagon/wagon-w01.json',R/'renderers/web/transport/LICENSES.md',R/'docs/LIBERTIES.md']}
put('tools/transport/generate_wagon.py',(O/'generate_wagon_trial.py').read_text());put('tools/transport/generate_studies.py',(R/'tools/transport/generate_studies.py').read_text());put('data/transport/studies/wagon.json',(O/'refined.json').read_text())
# Repository wrapper selection is --only wagon, not --onlywagon.
command=['python',str(B/'tools/transport/generate_studies.py'),'--only','wagon','--output-dir',str(B/'renderers/web/transport')]
subprocess.run(command,check=True)
assert (B/'renderers/web/transport/wagon/wagon-w01.glb').read_bytes()==(O/'after/wagon-w01.glb').read_bytes()
license_old=(R/'renderers/web/transport/LICENSES.md').read_text()
license_new=license_old+'\n## W01 wheel refinement: original reconstruction (2026-10-19)\n\nThe enabled W01 study uses original tapered octagonal spokes (hub section35×32mm, felloe22×22mm), retained radial endpoints and1.2mm board/stave chamfers. These dimensions and reduced board-color contrast are engineering choices, not source-attested1835 joinery, wear, paint or photographic measurements. GPL-3.0-or-later remains unchanged; no third-party material is introduced.\n\n| Generated/reproducible file | SHA-256 |\n| --- | --- |\n'
for rel in ['tools/transport/generate_wagon.py','data/transport/studies/wagon.json','renderers/web/transport/wagon/wagon-w01.glb','renderers/web/transport/wagon/wagon-w01.json']:
 license_new+=f'| `{rel}` | `{sha(B/rel)}` |\n'
put('renderers/web/transport/LICENSES.md',license_new)
liberty='''\n\n## T-2793 — W01 original wheel/edge refinement (2026-10-19)\n\nThe development study now uses independently authored octagonal spokes tapering from35×32mm at the hub to22×22mm at the felloe. These are reconstructed engineering dimensions, not measured or source-attested1835 wagon construction. Original spoke radial endpoints, wheel diameters, axle positions, wheel/steering/tongue pivots and existing proposed hitch/driver frames remain unchanged. Board/stave1.2mm edge chamfers and restrained two-board color variation are look-development inventions, not evidence for historic wear, timber species, paint or photographic grain. Felloe segments, joinery, fastener strength, historical dimensions and photographic quality remain unaccepted. No driver furniture, new people, harness coupling or scene traffic is supplied by this parcel.\n\nThe authored model increases9000 to10792 triangles(+1792,19.9%) while retaining22 material-batched meshes. Controlled close/clay views show a lighter taper and less broad striping; full-view gain is modest and does not itself justify using the refinement for distant wagons without an LOD decision. Original materials and surfaces remain covered by GPL-3.0-or-later; no external pixels, texture or rights-pending image geometry was introduced.\n'''
put('docs/LIBERTIES.md',(R/'docs/LIBERTIES.md').read_text()+liberty)
changed=['tools/transport/generate_wagon.py','data/transport/studies/wagon.json','renderers/web/transport/wagon/wagon-w01.json','renderers/web/transport/LICENSES.md','docs/LIBERTIES.md']
patch=''
for rel in changed:patch+=''.join(difflib.unified_diff((R/rel).read_text().splitlines(True),(B/rel).read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(O/'integration-source.patch').write_text(patch)
for rel,digest in protected.items():assert sha(R/rel)==digest
receipt={'status':'outside-app review bundle only; not applied/published','source_head':subprocess.check_output(['git','-C','/workspace/chicago','rev-parse','HEAD'],text=True).strip(),'source_hashes':source_rows,'command':command,'correct_selection_flag':'--only wagon','changed_paths':changed+['renderers/web/transport/wagon/wagon-w01.glb'],'outputs':{rel:sha(B/rel) for rel in changed+['renderers/web/transport/wagon/wagon-w01.glb']},'protected_carriage_horse_harness':{'all_current_files_hash_unchanged':True,'hashes':protected},'unchanged_helper_copy':'tools/transport/generate_studies.py is a validation wrapper copy, NOT an integration change','validation':'Generated through copied unmodified repository --only wagon wrapper;GLB bytes match validated/actuallyviewed after asset','triangles_before':9000,'triangles_after':10792,'added_triangles':1792,'mesh_batches':22,'draw_receipts':['render-receipt.json','mobile-fitted-receipt.json'],'license_scope':'project-original GPL-3.0-or-later; transport/LICENSES.md carries proposed exact SHA table; assets/LICENSES.md has no existing W01 row because outputs live outside assets/'}
(O/'integration-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'bundle':str(B),'glb_sha256':receipt['outputs']['renderers/web/transport/wagon/wagon-w01.glb'],'protected_files':len(protected),'source_head':receipt['source_head']},indent=2))
