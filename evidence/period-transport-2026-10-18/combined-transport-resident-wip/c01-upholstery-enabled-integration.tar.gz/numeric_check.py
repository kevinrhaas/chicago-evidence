import json,struct,hashlib,subprocess
from pathlib import Path
O=Path(__file__).parent
def glb(path):
 b=path.read_bytes();n=struct.unpack_from('<I',b,12)[0];g=json.loads(b[20:20+n]);return b,g,b[28+n:]
before,gb,bb=glb(O/'before/carriage-c01.glb');after,ga,ba=glb(O/'after/carriage-c01.glb')
assert gb['nodes']==ga['nodes'],'sockets, axles, wheel/hitch frames or mesh grouping changed'
assert len(gb['meshes'])==len(ga['meshes'])==27
rows=[]
for i,node in enumerate(ga['nodes']):
 if not node['name'].startswith('vehicle_wheel_') or 'mesh' in node:continue
 bounds=[]
 for g,b in [(gb,bb),(ga,ba)]:
  values=[]
  for child in g['nodes'][i]['children']:
   if 'mesh' not in g['nodes'][child]:continue
   mesh=g['meshes'][g['nodes'][child]['mesh']]
   for primitive in mesh['primitives']:
    a=g['accessors'][primitive['attributes']['POSITION']];v=g['bufferViews'][a['bufferView']];off=v.get('byteOffset',0)+a.get('byteOffset',0)
    values.extend(struct.unpack_from('<3f',b,off+j*12) for j in range(a['count']))
  bounds.append({'min':[min(v[k] for v in values) for k in range(3)],'max':[max(v[k] for v in values) for k in range(3)]})
 assert bounds[0]==bounds[1]
 rows.append({'wheel':node['name'],'bounds':bounds[0]})
subprocess.run(['python',str(O/'generate_carriage_trial.py'),'--parameters',str(O/'refined.json'),'--output-dir',str(O/'determinism')],check=True,capture_output=True)
assert after==(O/'determinism/carriage-c01.glb').read_bytes()
receipt={'status':'original reconstruction, not photographic or period joinery acceptance','baseline_byte_identical':before==Path('/workspace/chicago/chicago/4d/renderers/web/transport/carriage/carriage-c01.glb').read_bytes(),'all_nodes_and_sockets_unchanged':True,'wheel_bounds_exactly_unchanged':rows,'same_two_run_bytes':True,'before':{'sha256':hashlib.sha256(before).hexdigest(),'bytes':len(before),'triangles':gb['extras']['statistics']['triangles'],'meshes':len(gb['meshes'])},'after':{'sha256':hashlib.sha256(after).hexdigest(),'bytes':len(after),'triangles':ga['extras']['statistics']['triangles'],'meshes':len(ga['meshes'])},'khronos':{n:json.loads((O/n/'khronos.json').read_text())['issues'] for n in ['before','after']},'render_status':'HOLD for root sharedgate scheduling; drawcalls/screenshots not yet measured'}
(O/'numeric-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in ['khronos','wheel_bounds_exactly_unchanged']},indent=2))
