# SPDX-License-Identifier: GPL-3.0-or-later
"""Actualexport closed-surface and seating-center support receipts."""
import json,struct,collections,math,hashlib
from pathlib import Path
O=Path(__file__).parent;rows=[]
for name in ['before','after']:
 b=(O/name/'carriage-c01.glb').read_bytes();n=struct.unpack_from('<I',b,12)[0];g=json.loads(b[20:20+n]);raw=b[28+n:];positions=[]
 for mesh in g['meshes']:
  for p in mesh['primitives']:
   if p['material']!=2:continue
   a=g['accessors'][p['attributes']['POSITION']];v=g['bufferViews'][a['bufferView']];off=v['byteOffset']+a.get('byteOffset',0);positions.extend(struct.unpack_from('<3f',raw,off+12*j) for j in range(a['count']))
 ids={};tri=[]
 for i in range(0,len(positions),3):
  face=[]
  for v in positions[i:i+3]:
   if v not in ids:ids[v]=len(ids)
   face.append(ids[v])
  tri.append(face)
 edges=collections.Counter(tuple(sorted((t[k],t[(k+1)%3]))) for t in tri for k in range(3));assert all(n==2 for n in edges.values()),collections.Counter(edges.values())
 areas=[]
 for i in range(0,len(positions),3):
  a,b,c=positions[i:i+3];u=[b[k]-a[k] for k in range(3)];v=[c[k]-a[k] for k in range(3)];cross=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];areas.append(math.sqrt(sum(x*x for x in cross))/2)
 assert min(areas)>1e-8
 support={}
 for label,top,z,halfw,halfd in [('driver',1.305,.60,.44,.18),('passenger',1.065,-.52,.48,.205)]:
  supported=[]
  for j in range(0,len(positions),3):
   a,b,c=positions[j:j+3]
   if not all(abs(v[1]-top)<1e-7 for v in [a,b,c]):continue
   ax,az=a[0],a[2];ux,uz=b[0]-ax,b[2]-az;vx,vz=c[0]-ax,c[2]-az;det=ux*vz-uz*vx
   if abs(det)<1e-14:continue
   u=((-ax)*vz-(z-az)*vx)/det;v=(ux*(z-az)-uz*(-ax))/det
   if u>=-1e-9 and v>=-1e-9 and u+v<=1+1e-9:supported.append(a[1])
  assert supported
  support[label]={'top_y_m':max(supported),'triangles_containing_seat_center':len(supported)}
 rows.append({'variant':name,'upholstery_triangles':len(tri),'welded_vertices':len(ids),'all_welded_edges_incidence_two':True,'minimum_triangle_area_m2':min(areas),'seat_flat_supports':support})
assert rows[0]['seat_flat_supports']['driver']['top_y_m']==rows[1]['seat_flat_supports']['driver']['top_y_m'];assert rows[0]['seat_flat_supports']['passenger']['top_y_m']==rows[1]['seat_flat_supports']['passenger']['top_y_m']
(O/'cushion-contact-receipt.json').write_text(json.dumps({'status':'Closed actualsource geometry and unchanged central seat surfaces; no upholstery deformation/occupant contact acceptance','results':rows},indent=2)+'\n');print(rows)
