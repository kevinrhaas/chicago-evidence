# SPDX-License-Identifier: GPL-3.0-or-later
import json,difflib,hashlib
from pathlib import Path
R=Path('/workspace/chicago/chicago/4d');O=Path(__file__).parent
old=(R/'tools/transport/generate_carriage.py').read_text()
helper='''# Original rounded cushion shell, same axis extrema and seat-center height.
# Minkowski sum of an inset box and20mm sphere, four samples per quarter edge.
def rounded_cushion(name,parent,size,t,mat,rx):
 radius=.020;ext=[v/2 for v in size];core=[e-radius for e in ext];N=4;vs=[];fs=[]
 if min(core)<=0:raise ValueError('cushion radius exceeds fixed envelope')
 def face(points):
  start=len(vs);vs.extend(points);fs.append(list(range(start,start+len(points))))
 def corner_point(signs,direction):
  length=math.sqrt(sum(x*x for x in direction));return [signs[k]*(core[k]+radius*direction[k]/length) for k in range(3)]
 for axis in range(3):
  other=[k for k in range(3) if k!=axis]
  for sign in [-1,1]:
   points=[]
   for a,b in [(-1,-1),(1,-1),(1,1),(-1,1)]:
    p=[0,0,0];p[axis]=sign*ext[axis];p[other[0]]=a*core[other[0]];p[other[1]]=b*core[other[1]];points.append(p)
   face(points)
 for axis in range(3):
  for other in range(axis+1,3):
   free=3-axis-other
   for sa in [-1,1]:
    for sb in [-1,1]:
     for j in range(N):
      points=[]
      for q,sf in [(j,-1),(j,1),(j+1,1),(j+1,-1)]:
       length=math.hypot(N-q,q);p=[0,0,0];p[axis]=sa*(core[axis]+radius*(N-q)/length);p[other]=sb*(core[other]+radius*q/length);p[free]=sf*core[free];points.append(p)
      face(points)
 for sx in [-1,1]:
  for sy in [-1,1]:
   for sz in [-1,1]:
    signs=[sx,sy,sz]
    def p(i,j):return corner_point(signs,[i,j,N-i-j])
    for i in range(N):
     for j in range(N-i):
      face([p(i,j),p(i+1,j),p(i,j+1)])
      if i+j<N-1:face([p(i+1,j),p(i+1,j+1),p(i,j+1)])
 for face_indices in fs:
  p,q,r=[vs[i] for i in face_indices[:3]];u=[q[k]-p[k] for k in range(3)];v=[r[k]-p[k] for k in range(3)];normal=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];center=[sum(vs[i][k] for i in face_indices)/len(face_indices) for k in range(3)]
  if sum(a*b for a,b in zip(normal,center))<0:face_indices.reverse()
 return geom(name,parent,vs,fs,mat,t,[math.sin(rx/2),0,0,math.cos(rx/2)] if rx else None)

'''
new=old.replace('nodes=[]; meshes=[];',"rounded=params.get('rounded_upholstery_study',False)\nif not isinstance(rounded,bool):raise ValueError('rounded_upholstery_study must be boolean')\nnodes=[]; meshes=[];")
new=new.replace('def box(name,parent,size,t,mat=0,rx=0):',helper+"def box(name,parent,size,t,mat=0,rx=0):\n if rounded and name in ('passenger_cushion','passenger_back_cushion','driver_seat'):return rounded_cushion(name,parent,size,t,mat,rx)")
new=new.replace('for exported_node in nodes:',"if rounded:\n sidecar['upholstery_refinement']={'grade':'reconstructed','radius_m':.020,'quarter_edge_samples':4,'note':'Original three-cushion edge rounding; same axis envelope and seat datums; not source-attested interior, measured compression or photographic cloth/leather'}\n\nfor exported_node in nodes:")
(O/'generate_carriage_trial.py').write_text(new);(O/'generate_carriage_baseline.py').write_text(old)
p=json.loads((R/'data/transport/studies/carriage.json').read_text());(O/'baseline.json').write_text(json.dumps(p,indent=2)+'\n');p['rounded_upholstery_study']=True;(O/'refined.json').write_text(json.dumps(p,indent=2)+'\n')
(O/'upholstery.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/tools/transport/generate_carriage.py',tofile='b/tools/transport/generate_carriage.py')))
(O/'source-receipt.json').write_text(json.dumps({'source_generator_sha256':hashlib.sha256((R/'tools/transport/generate_carriage.py').read_bytes()).hexdigest(),'parameters_sha256':hashlib.sha256((R/'data/transport/studies/carriage.json').read_bytes()).hexdigest(),'historical_match':False,'baseline_image_actually_viewed':'docs/RESEARCH/period-transport-2026-10-18/carriage/integrated-desktop.png'},indent=2)+'\n')
