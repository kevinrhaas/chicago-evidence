#!/usr/bin/env python3
"""Root-authorized single delivery after reviewed old1-3/fresh4 native coverage."""
from pathlib import Path
import datetime, fcntl, hashlib, importlib.util, json, os, re, shutil, subprocess, sys

HERE=Path(__file__).resolve().parent
B=Path('/workspace/.cloud-setup/transport-driver-motion-20261103')
R=Path('/workspace/chicago-driver-pace-rendezvous-20261104'); APP=R/'chicago/4d'
ROOT=Path('/workspace/chicago-transport-current-20261103')
SUP=Path('/workspace/.cloud-setup/transport-supervise.py')
LOCK=Path('/workspace/.cloud-setup/transport-8cec-generated-lap-20261030/ROOT-SOLE-CANONICAL-OWNER.lock')
GATE=B/'actual-next-motion-cold-find-format-bridge-part4-01'
PROOF=B/'next-format-fix-targeted-proof-01/CLOSED.json'
MESSAGE=B/'next-actual-pace-find-implementation-20261104/delivery-prepared/COMMIT-MESSAGE.txt'
BRANCH='steward/t1790-driver-pace-rendezvous-20261104'
PARENT='b5ba5e39611bf76512966ea98a89b89c5b4188cd'
SOURCE=dict(HEAD=PARENT,TREE='8058a804fc431e5063df063b7cd637bff9bfcee9',APP='813b70293ad74315e3a6e41d125cd6fbe0ea39ac',semantic_index_sha256='7a6b4c2dbc327ca20958c32bfe9f4fcc02bb06b8b723c2a3bc09f076c11fdd5c')
PASS='FULL_NATIVE_COVERAGE_PASS_WITH_REVIEWED_FORMAT_AND_EXTRACTOR_SOURCE_BRIDGE'
TITLE='Drivers wait for you and keep their pace'
ANSI=re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def save(p,d):Path(p).write_text(json.dumps(d,indent=2)+'\n')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()

def main():
    assert __debug__ and sys.version_info[:2]==(3,11)
    auth=load(HERE/'ROOT-UPDATED-DELIVERY-GO.json');auth_sha=sha(HERE/'ROOT-UPDATED-DELIVERY-GO.json')
    assert auth['ROOT_EXPLICIT_UPDATED_DELIVERY_GO'] is True and auth['source']==SOURCE
    assert auth['runner_sha256']==sha(__file__) and auth['commit_message_sha256']==sha(MESSAGE)
    assert auth['normal_commit_budget']==auth['normal_push_budget']==auth['ready_PR_create_budget']==auth['own_lap_attempt_budget']==1
    assert auth['merge_budget']==auth['CI_dispatch_budget']==auth['ticket_state_write_budget']==0
    for p,h in auth['execution_pins'].items():assert sha(p)==h,p
    out=HERE/'actual-delivery-01';assert not out.exists(),'Preserve previous outcomes; never repeat uncertain mutations'
    gate=load(GATE/'CLOSED.json');gate_sha=sha(GATE/'CLOSED.json')
    assert gate['status']==PASS and gate['error'] is None and gate['source_error'] is None
    assert gate['source_before']==gate['source_after']==SOURCE and gate['all_four_same_TREE'] is False
    assert gate['resources']['accepted'] and gate['owned_TMPDIR_cleanup_complete'] and not(GATE/'native-tmp').exists()
    assert gate['native_distinct_steps']==1160 and gate['native_selftests']==402 and gate['every_part_execution_overlap']==9
    assert gate['original_cap_per_part_seconds']==600 and gate['native_GIT_NO_LAZY_FETCH_absent'] and gate['metadata_git_GIT_NO_LAZY_FETCH']=='1'
    assert gate['runner_sha256']=='8955e1a1670b0763c104aa43c5bb08bdedc892fedef968810dcb9c8e8e7b24cb'
    assert gate['binding_sha256']=='8b0ab017fba9f88abeeed70bc125a154fda6ade2372dc7f024734984c4609596'
    assert gate['required_environment']==dict(CHECK_JOBS='4',C4D_GATE_REQUIRE_READERS='1',C4D_GATE_REQUIRE_BASE='1',C4D_RULINGS_BASE=PARENT)
    assert [x['part']for x in gate['ledger']]==[1,2,3,4]
    bridge=gate['reviewed_format_extractor_source_bridge'];old=load(bridge['prior_failed_fourpart']['path'])
    assert sha(bridge['prior_failed_fourpart']['path'])==bridge['prior_failed_fourpart']['sha256']
    assert gate['ledger'][:3]==old['ledger'][:3] and old['status']=='NONPASS_NO_AUTOMATIC_RETRY' and old['ledger'][3]['result']['returncode']==1
    assert bridge['all_four_same_TREE'] is False and bridge['current_source']==SOURCE
    for row in gate['ledger']:
        n=row['part'];result=row['result'];cleanup=row['cleanup']
        assert row['source_before']==row['source_after']==(SOURCE if n==4 else old['source_before']) and row['source_error'] is None
        assert result['returncode']==0 and not result['timed_out'] and result['requested_timeout_seconds']==result['effective_timeout_seconds']==600 and result['timeout_override_reason'] is None
        assert cleanup['cleanup_complete'] and not cleanup['remaining_owned_children'] and row['resources']['accepted']
        assert sha(row['log'])==row['log_sha256'];body=ANSI.sub('',Path(row['log']).read_text(errors='replace'))
        expected=gate['expected_parts'][str(n)];assert row['native_footer_counts']==expected
        assert len(re.findall(r'^CHECK PASS[^\n]*part '+str(n)+r'/4:\s*'+str(expected['selected_steps'])+r' steps, none red\.$',body,re.M))==1
        assert not re.search(r'^CHECK FAIL|^\s*\^ .* failed$',body,re.M)
    assert sha(PROOF)=='cdd2e23fc2ceaf110847d63a18cbeecb154d7eda9b7e12b9344de8ea3b2e942f'
    lock=LOCK.open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',CHECK_JOBS='4',C4D_GATE_REQUIRE_READERS='1',C4D_GATE_REQUIRE_BASE='1',C4D_RULINGS_BASE=PARENT)
    for k in ['GIT_NO_LAZY_FETCH','CHICAGO_TICKETS_DIR','CHECK_PART','BASE','CHECK_TIMINGS']:env.pop(k,None)
    for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:assert env.get(k)=='1'
    meta=env|{'GIT_NO_LAZY_FETCH':'1'}
    def git(repo,*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(repo),*args],env=meta,timeout=45)
    def val(*args):return git(R,*args).decode().strip()
    def api(path):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago/'+path],env=env,timeout=45))
    def rootprofile():
        idx=Path(git(ROOT,'rev-parse','--git-path','index').decode().strip());idx=idx if idx.is_absolute()else ROOT/idx
        return dict(HEAD=git(ROOT,'rev-parse','HEAD').decode().strip(),index_sha256=sha(idx),semantic_index_sha256=hashlib.sha256(git(ROOT,'ls-files','--stage','-z')).hexdigest(),status=git(ROOT,'status','--porcelain=v1','--untracked-files=all').decode())
    def source(head,staged):
        assert sha(HERE/'ROOT-UPDATED-DELIVERY-GO.json')==auth_sha and sha(MESSAGE)==auth['commit_message_sha256']
        assert sha(__file__)==auth['runner_sha256'] and sha(GATE/'CLOSED.json')==gate_sha
        for p,h in auth['execution_pins'].items():assert sha(p)==h,p
        assert val('branch','--show-current')==BRANCH and not git(R,'ls-files','-u').strip()
        assert not git(R,'diff','--name-only').strip() and not git(R,'ls-files','--others','--exclude-standard').strip()
        tree=val('write-tree');actual=dict(HEAD=val('rev-parse','HEAD'),TREE=tree,APP=val('rev-parse',tree+':chicago/4d'),semantic_index_sha256=hashlib.sha256(git(R,'ls-files','--stage','-z')).hexdigest())
        assert actual==dict(SOURCE,HEAD=head)
        assert sorted(val('diff','--cached','--name-only').splitlines())==(sorted(auth['owned_files'])if staged else[])
        for f,h in auth['owned_files'].items():assert sha(R/f)==h,f
        mh=Path(val('rev-parse','--git-path','MERGE_HEAD'));mh=mh if mh.is_absolute()else R/mh;assert not mh.exists()
        return actual
    assert val('remote','get-url','origin')=='https://github.com/kevinrhaas/chicago.git'
    assert source(PARENT,True)==SOURCE
    hooks=subprocess.run(['git','-C',str(R),'config','--get','core.hooksPath'],env=meta,capture_output=True);assert hooks.returncode==1,'Custom hooks require review'
    hp=Path(val('rev-parse','--git-path','hooks'));hp=hp if hp.is_absolute()else R/hp
    assert not any(p.is_file()and not p.name.endswith('.sample')for p in hp.iterdir()),'No active hooks permitted'
    assert not val('ls-remote','--heads','origin','refs/heads/'+BRANCH),'New remote feature branch already exists; reconcile before mutation'
    parent_pr=api('pulls/1693');assert parent_pr['merged']and parent_pr['head']['sha']==PARENT
    dev=api('git/ref/heads/dev')['object']['sha']
    root_before=rootprofile();assert root_before['HEAD']=='27d52718290a2708f70ca536c6b796a83a936601'and root_before['status']==''
    config=Path(val('rev-parse','--git-common-dir'))/'config';config=config if config.is_absolute()else R/config;config_sha=sha(config)
    spec=importlib.util.spec_from_file_location('delivery_guard','/workspace/.cloud-setup/transport-current-20261103/resource_guard.py');guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
    before=guard.snapshot();assert guard.check(before)['accepted'];out.mkdir();scratch=out/'native-tmp';scratch.mkdir();env['TMPDIR']=str(scratch)
    save(out/'ADMISSION.json',dict(source=SOURCE,gate_path=str(GATE/'CLOSED.json'),gate_sha256=gate_sha,root_before=root_before,public_dev_observed=dev,all_four_same_TREE=False,original_negative=bridge['prior_failed_fourpart'],ROOT_GO=auth))
    rows=[];head=None;pr=None;error=None;inflight=False;lap_acquired=False
    def run(label,command,cap=120,cwd=APP,allow_nonzero=False):
        nonlocal inflight
        snap=guard.snapshot();assert guard.check(snap)['accepted'];prefix=out/label;save(out/'STATE.json',dict(status='RUNNING_NOT_PASS',active=label,HEAD=head,PR=pr['number']if pr else None))
        inflight=True
        with Path(str(prefix)+'.stdout').open('xb')as log:q=subprocess.run([sys.executable,str(SUP),'--prefix',str(prefix),'--cwd',str(cwd),'--timeout',str(cap),'--',*command],env=env,stdout=log,stderr=subprocess.STDOUT)
        result=load(str(prefix)+'.result.json');cleanup=load(str(prefix)+'.cleanup.json');resources=guard.pair(snap,guard.snapshot());inflight=not(cleanup['cleanup_complete']and not cleanup['remaining_owned_children'])
        row=dict(label=label,result=result,cleanup=cleanup,resources=resources,log_sha256=sha(str(prefix)+'.log'));rows.append(row);save(out/'LEDGER.json',rows)
        assert q.returncode==result['returncode']and result['requested_timeout_seconds']==result['effective_timeout_seconds']==cap and result['timeout_override_reason']is None
        assert not result['timed_out']and not inflight and resources['accepted']
        if not allow_nonzero:assert result['returncode']==0,row
        return row
    try:
        save(out/'COMMIT-INTENT.json',dict(utc=utc(),tree=SOURCE['TREE'],parent=PARENT,message_sha256=sha(MESSAGE),mutation_budget=1))
        run('ordinary-commit-ONCE',['git','commit','-F',str(MESSAGE)],cwd=R)
        head=val('rev-parse','HEAD');assert head!=PARENT;source(head,False)
        commit=git(R,'cat-file','-p',head).decode().splitlines();assert commit[0]=='tree '+SOURCE['TREE']and[x[7:]for x in commit if x.startswith('parent ')]==[PARENT]
        save(out/'COMMIT-VERIFIED.json',dict(HEAD=head,TREE=SOURCE['TREE'],parents=[PARENT],gate_sha256=gate_sha,all_four_same_TREE=False))
        # The exact public base is read-only; no tracking ref or source refresh is needed.
        for label,command in [('entry',['node','tools/check-changelog-entry.mjs',PARENT,'HEAD']),('identifiers',['node','tools/resolve_id_collisions.mjs','--base',PARENT,'--check']),('changelog',['node','tools/check-changelog.mjs']),('pending-entry',['node','tools/changelog-entries.mjs','--check']),('history',['node','tools/changelog-history.mjs','--base',PARENT])]:
            run('actual-HEAD-'+label,command);source(head,False)
        run('actual-HEAD-whitespace',['git','show','--check','--format=oneline','HEAD'],cwd=R);source(head,False)
        run('actual-HEAD-base-diff-whitespace',['git','diff','--check',PARENT,'HEAD'],cwd=R);source(head,False)
        run('actual-HEAD-native-publish',['bash','tools/publish.sh'],180);source(head,False)
        run('actual-HEAD-published-check',['node','tools/check_published.mjs'],120);source(head,False)
        assert load(R/'site/4d/build.json')['version']==head[:10]
        save(out/'PUSH-INTENT.json',dict(utc=utc(),HEAD=head,branch=BRANCH,mutation_budget=1,force=False))
        run('normal-new-feature-push-ONCE',['git','push','origin','HEAD:refs/heads/'+BRANCH],cwd=R,allow_nonzero=True)
        assert val('ls-remote','--heads','origin','refs/heads/'+BRANCH).split()==[head,'refs/heads/'+BRANCH]
        ref=api('git/ref/heads/'+BRANCH);save(out/'PUBLIC-REF.json',ref);assert ref['object']['sha']==head
        public=api('git/commits/'+head);save(out/'PUBLIC-COMMIT.json',public);assert public['tree']['sha']==SOURCE['TREE']and[x['sha']for x in public['parents']]==[PARENT]
        times=[r['result']['seconds']for r in gate['ledger']]
        body=f"Selecting a named driver with Find now makes that same driver wait through lazy vehicle loading. Transport keeps its configured pace on slow frames, using the existing swept collision checks and a 0.25 m maximum advance per frame. Stop, Continue and inactive transitions reset without catch-up movement.\n\nValidation:\n\n- Local native coverage uses a reviewed source bridge: parts 1–3 passed on bf515d in {times[0]:.3f}/{times[1]:.3f}/{times[2]:.3f} seconds; fresh part 4 passed on committed tree 8058a8 in {times[3]:.3f} seconds. All original 600-second caps, 1,160 distinct steps and 402 self-tests are retained. The original part-4 T-2633 formatting-assertion failure is preserved. Only callback closing-brace whitespace and our new unit extractor changed; callback bytes/runtime tokens are equivalent, with fresh original Go to, transport-loop and driven-assembly units passing.\n- The committed HEAD passes five QA checks, both whitespace checks and native publish/check, with the published build stamped {head[:10]}. Original test assertions remain intact.\n- Fresh eight-part/core CI and moving/frame checks are pending. Root will dispatch the original complete published smokes as separate mobile/desktop jobs on this frozen feature HEAD: all 15 stages, unchanged 150-minute remote caps. The experimental low-FPS observer remains NOT READY and UNRUN.\n\nDriver identity, route ownership, speed, gait bounds and assets are preserved. These are reconstructed actions and journeys; photographic/natural-stride acceptance remains outside this increment. Broad transport tickets remain claimed with pr:null; this partial increment does not settle them.\n"
        bodyfile=out/'PR-BODY.md';bodyfile.write_text(body)
        existing=json.loads(subprocess.check_output(['gh','pr','list','--repo','kevinrhaas/chicago','--head',BRANCH,'--base','dev','--state','open','--json','number'],env=env,timeout=45));assert existing==[]
        save(out/'PR-CREATE-INTENT.json',dict(utc=utc(),HEAD=head,title=TITLE,body_sha256=sha(bodyfile),mutation_budget=1))
        run('ready-PR-create-ONCE',['gh','pr','create','--repo','kevinrhaas/chicago','--base','dev','--head',BRANCH,'--title',TITLE,'--body-file',str(bodyfile)],cwd=R,allow_nonzero=True)
        listed=json.loads(subprocess.check_output(['gh','pr','list','--repo','kevinrhaas/chicago','--head',BRANCH,'--base','dev','--state','open','--json','number,url,headRefOid,isDraft'],env=env,timeout=45));assert len(listed)==1
        pr=api('pulls/'+str(listed[0]['number']));save(out/'READY-PR-VERIFIED.json',pr)
        assert not pr['draft']and pr['state']=='open'and not pr['merged']and pr['title']==TITLE and pr['base']['ref']=='dev'and pr['head']['sha']==head
        print(json.dumps(dict(event='READY_PR_PUBLISHED',HEAD=head,PR=pr['number'],url=pr['html_url'])),flush=True)
        lap=run('own-lap-ONCE',['node','tools/ticket.mjs','lap',str(pr['number']),'--by','transport visible increment'],allow_nonzero=True);source(head,False)
        laptext=(out/'own-lap-ONCE.log').read_text(errors='replace');lap_acquired=lap['result']['returncode']==0 and f"lap/pr-{pr['number']} taken"in laptext
        if lap_acquired:
            marker=val('ls-remote','--heads','origin','refs/heads/lap/pr-'+str(pr['number'])).split();assert len(marker)==2;save(out/'OWN-LAP-VERIFIED.json',dict(marker=marker,PR=pr['number']))
        else:save(out/'OWN-LAP-NOT-ACQUIRED.json',dict(returncode=lap['result']['returncode'],text=laptext,automatic_retry=False))
    except BaseException as exc:error=repr(exc)
    finally:
        source_error=None
        try:actual=source(val('rev-parse','HEAD'),val('rev-parse','HEAD')==PARENT)
        except BaseException as exc:actual=None;source_error=repr(exc)
        root_after=rootprofile();resources=guard.pair(before,guard.snapshot());config_unchanged=sha(config)==config_sha
        if not inflight and all(r['cleanup']['cleanup_complete']and not r['cleanup']['remaining_owned_children']for r in rows):shutil.rmtree(scratch)
        ok=error is None and source_error is None and bool(pr)and resources['accepted']and not scratch.exists()and root_before==root_after and config_unchanged
        closed=dict(status='REVIEWED_BRIDGED_NATIVE_COMMIT_QA_PUBLICATION_NORMAL_PUSH_READY_PR_PASS_CI_PENDING'if ok else'DELIVERY_NONPASS_OR_UNCERTAIN_NO_AUTOMATIC_MUTATION_RETRY',error=error,source_error=source_error,source=actual,ROOT_before=root_before,ROOT_after=root_after,ROOT_unchanged=root_before==root_after,common_Git_config_unchanged=config_unchanged,gate_path=str(GATE/'CLOSED.json'),gate_sha256=gate_sha,reviewed_source_bridge=bridge,all_four_same_TREE=False,HEAD=head,PR_number=pr['number']if pr else None,PR_url=pr['html_url']if pr else None,own_lap_acquired=lap_acquired,ledger=rows,resources=resources,owned_TMPDIR_cleanup_complete=not scratch.exists(),commit_push_PR_budget_each=1,CI_dispatches=0,merged=False,ticket_state_changes=False,closed_utc=utc())
        save(out/'CLOSED.json',closed);print(json.dumps(dict(status=closed['status'],HEAD=head,PR=closed['PR_number'],error=error,receipt=str(out/'CLOSED.json'))),flush=True)
    return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
