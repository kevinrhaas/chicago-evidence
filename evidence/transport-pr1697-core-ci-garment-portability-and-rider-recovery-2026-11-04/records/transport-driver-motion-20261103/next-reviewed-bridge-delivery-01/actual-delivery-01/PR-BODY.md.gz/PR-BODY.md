Selecting a named driver with Find now makes that same driver wait through lazy vehicle loading. Transport keeps its configured pace on slow frames, using the existing swept collision checks and a 0.25 m maximum advance per frame. Stop, Continue and inactive transitions reset without catch-up movement.

Validation:

- Local native coverage uses a reviewed source bridge: parts 1–3 passed on bf515d in 411.003/388.933/347.483 seconds; fresh part 4 passed on committed tree 8058a8 in 508.454 seconds. All original 600-second caps, 1,160 distinct steps and 402 self-tests are retained. The original part-4 T-2633 formatting-assertion failure is preserved. Only callback closing-brace whitespace and our new unit extractor changed; callback bytes/runtime tokens are equivalent, with fresh original Go to, transport-loop and driven-assembly units passing.
- The committed HEAD passes five QA checks, both whitespace checks and native publish/check, with the published build stamped b83f60edd8. Original test assertions remain intact.
- Fresh eight-part/core CI and moving/frame checks are pending. Root will dispatch the original complete published smokes as separate mobile/desktop jobs on this frozen feature HEAD: all 15 stages, unchanged 150-minute remote caps. The experimental low-FPS observer remains NOT READY and UNRUN.

Driver identity, route ownership, speed, gait bounds and assets are preserved. These are reconstructed actions and journeys; photographic/natural-stride acceptance remains outside this increment. Broad transport tickets remain claimed with pr:null; this partial increment does not settle them.
