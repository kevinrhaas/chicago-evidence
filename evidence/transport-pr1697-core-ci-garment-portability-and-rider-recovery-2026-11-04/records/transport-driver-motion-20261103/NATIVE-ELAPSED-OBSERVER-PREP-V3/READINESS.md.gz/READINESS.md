# Prepared V2 — static READY, browser UNRUN, GO false

This repairs the existing V1 observer outside APP. V1 remains unchanged. No app,
index, mirror, native control, browser or actual runtime has been executed here.
Python AST and Node syntax parsing only passed.

Scope is the requested 1 and 2FPS native timer windows at configured .084375m/s,
plus direct fresh admission, Stop/Continue with and without a stopped tick, and
animation hold/resume. Each scene gets two seconds per requested cadence. The
1835 Full desktop and 1904 Balanced narrow cases retain the original 120-second
COMPLETE viewport cap and existing 600-second outer supervisor. This makes no
4FPS, reduced-motion, hidden-tab, confidence-toggle or range-reentry claim.
It does not qualify default phone Light, consumer FPS, gait or photo quality.

The observer stops the normal loop using the existing renderer API, then calls
real api.step against native performance.now and browser timers. It replaces no
clock, runtime module, loader, support/clearance reader, asset or renderer method.
All real ground, team, horse phases, wheel bounds, driver bones and budgets stay.
Requested cadence unavailable due to render cost remains NONPASS; actual elapsed
intervals are retained instead of reporting fixed deltas or equal-origin motion.

Fresh admission now requires no existing actor. The native global clock is
primed before asynchronous actual model loading. After ready() and a real wait,
the first actual frame must keep the fresh journey and driver clocks at zero,
without an intervening Stop, hold or resume masking admission. The next real
interval must advance at the configured rate. Existing actor/late actor admission
fails; the helper never disposes/reset/replaces an actor to manufacture freshness.

V1's unbounded finally awaits are removed. Ten seconds INSIDE the 120-second
viewport cap are reserved for owned native disposal/context/browser closure.
Every await is bounded, including final server closure. Timeout is NONPASS; this
Node wrapper exits so the existing supervisor/subreaper closes ONLY its owned
browser descendants. Outer cleanup0 is still mandatory, never assumed. Late page
errors and final closure failures invalidate both case and overall results.

Use the publisher's real site/4d year doors and module/base routing. The new false
GO template requires an external full published census array with exact objects
`{ "path": "relative/file", "size": 123, "sha256": "64hex" }`, no duplicates,
sorted by path. File census, every size/hash, build.json version and clean source
are checked before and after. The committed HEAD must begin with build.version;
root must bind the actual next committed source/publisher result. It must release
the canonical lane and explicitly authorize the observer before launching run.py.
No pending-merge source or old world PASS is silently retargeted.

Pictures: before/after pair per cadence/case, eight PNGs. Actual image review is
mandatory to confirm visible team/motion; numerical PASS does not supply it.
No pixel-ROI threshold or arbitrary changed-pixel claim is used.

This supplemental observer must not delay the checked source PR. Actual readiness
and timing remain unproved until a separate root-authorized run. If full native
boot/assembly/pictures cannot fit 110 seconds of work plus 10 seconds cleanup,
retain NONPASS and report the bounded limitation; do not extend any budget.
