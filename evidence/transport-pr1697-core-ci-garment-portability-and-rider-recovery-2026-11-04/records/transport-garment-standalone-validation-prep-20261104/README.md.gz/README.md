# Garment terminal V2: isolated standalone validation prepared

Owned sparse Git checkout: `/workspace/chicago-driver-garment-validation-20261104`,
detached at public DEV `59ec08a37e269eba6f4fc22a7697453e6f453fe5`. Its Git
configuration, index and refs are separate from R/N/W; cached historical objects
are read through a one-way alternate. No R/N/W configuration or source changed.

Only the reviewed eight-file source/recipe parcel is staged. The sole difference
from that reviewed parcel is recipe `installed:false→true` for validation only.
All nine original source/runtime pins match; all sixteen historical parent blobs
are cached without lazy fetching. No active GLB was checked out or installed.
No generator, decoder, test, browser, native workload, commit or push ran.

Source profile: HEAD59ec, staged TREE316b9fc754be3033b4768e47c2fa1610a5062bf4,
APP010729449a709baab36f62e39c15bde59ca13231,
index12d2897940d6da86079b353296f8f969cbdcea2a61509f8df024ea5f2491cd29.
This sparse checkout is for standalone output validation, not a full world/gate.

ROOT-EXECUTION-FALSE.json remains unapproved. After ROOT separately authorizes
execution and the canonical slot is free, create a separate true binding with
only `approved:true` changed and run:

```
source /workspace/.cloud-setup/transport-activate.sh
PYTHONDONTWRITEBYTECODE=1 python3 /workspace/.cloud-setup/transport-garment-standalone-validation-prep-20261104/run_prepared_output.py --binding /absolute/path/to/ROOT-EXECUTION-TRUE.json --out /workspace/.cloud-setup/transport-current-20261103/actual-garment-terminal-v2-standalone-regeneration-01
```

The existing supervisor receives the original120-second command:
`python3 tools/human_garment_retention.py --output <fresh-output>/generated`.
The wrapper uses the existing canonical lock, restored resource guard and owned
cleanup. It compares all eight generated hashes and all four changed payloads
byte-for-byte against the actual admitted prototype files. A mismatch fails;
expected digests are never retargeted. Outputs stay outside APP. No full-world,
contact, photographic acceptance or installation is implied by regeneration.
