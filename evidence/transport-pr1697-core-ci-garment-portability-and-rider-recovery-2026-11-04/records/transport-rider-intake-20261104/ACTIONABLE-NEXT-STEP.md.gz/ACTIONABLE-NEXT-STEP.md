# Mounted rider: resume preserved tack before a new pose

T-2804 remains the existing claimed broad ticket. Its driver increment is shipped;
its mounted-rider half is unfinished. T-2802 remains the existing open riding-gear
dependency. No new ticket, claim or source change was made in this intake.

The smallest actual continuation is the already reviewed footplate/arch repair,
not a new saddle, unrelated rider engine, or another generic pose specification.
Two exact public archives were recovered through the normal GitHub API at evidence
commit 68c9443e3c7f7cbd9f8353216544ac0dc82ac488. Both Git blob identities, byte sizes
and SHA256s match. Selected text only was extracted; no candidate was run.

- Terminal capsule: first-tread-contact-failure.tar.gz, 1,363,914 bytes,
  SHA256 271cb78d08c727bf0400fe5dd52c64b10fea1e2a7651a2fdcca36b11259e3f33.
- Last reviewed proposal: reviewed-footplate-proposal.tar.gz, 26,910 bytes,
  SHA256 37e1cd1c15c256d0b9c1ff5bba5aecf069bdb7ae9ac6a188302f26830b639f45.
- Preserved standalone source inventory 497b89f994130d0bc68d5cd94679f154dc98677cbdf57bec10fc2f3b682870f9,
  79 files; caller 1a080c296a5df76f755b2934b79b2ca1255e8a27296165b59c42ab37e3af8afa.
  The archive contains the source; its old /workspace/shared paths are historical.
  The eleven older pinned input bodies are NOT all included: recover those exact
  archived inputs before a trial; the terminal capsule contains only the final
  cf148d48 candidate GLB, source and proofs, not a self-contained input chain.

Actual candidate cf148d48 failed at pair330/351 after329 pairs and all29 self
classifications. The original 6mm bottom iron tube passes through the separate
100x35x9mm tread: stored independent diagnosis proves44 proper crossings per side.
Eight negative stages, readback, Khronos and capture passed; later pair scopes and
all18 versus the whole horse did not run. No alias or widened contact tolerance
can repair this inherited crossing.

Implement the preserved FOOTPLATE-JOIN-PROPOSAL-v2: remove redundant bottom segment3;
replace only lower segments2/4 by source-owned lofts ending on the unchanged plate
TOP. Partition that top into two exact ten-sided contact disks and their complement.
Keep upper iron0/1/5/6, successful central fold, complete leather streams, saddle
layers/girth/billets, reins, rig/material/frame and previous contact domains exact.
This is20 affected/9 protected parts,370 interpart pairs,20 versus all14,172 old
horse faces,18 closed obligations plus two explicitly inherited-open irons,22
interfaces. Preserve all88 old crossing witnesses as a new negative stage. Do not
reuse a historical one-trial authorization; root owns the new source assignment,
review and bounded qualification under current normal ownership/resource rules.

Period evidence is already recovered: Lebeaud1833 and Adams1805 primary OCR,
with publication-date public-domain rationale. Page images were blocked and never
viewed. Text supports construction categories, not exact iron profile, 6mm radius,
10.5mm inset, plate dimensions, Chicago provenance or load/rider safety. Preserve
GPL3+ predicate/helper notices and CC0 original geometry declarations. Photographic
and actual animal/boot fit remain open even after a technical contact pass.

For the subsequent first mounted increment, use an existing named1835 reconstructed
resident on the existing portable rig. Joseph Dufresne is present, reconstructed,
a livery-stable keeper and an existing worker_1835 proof variant; no riding event,
portrait likeness or horse ownership is attested. Otis is already the1835 driver:
do not duplicate him simultaneously as a rider. Dufresne source recipe/CC0 prepared
adult35 body already exists, but his canonical runtime GLBs were not found among
this checkout's installed assets, so a fresh canonical export is still necessary.
Coordinate any shared-builder changes with the clothing worker.

Reuse human_seated_study's pure source-to-Blender/rest-basis math and native shared
rig/export machinery, but preserve its strict W01 loader. A mounted profile must
bind actual recovered saddle seat, stirrups, palm/rein endpoints and pelvis/leg
geometry; sit_drive is not a mounted pose. The current26 driven runtime horse has
no actual saddle/seat/stirrup socket nodes; older horse-master-spec sockets are
explicitly provisional_unfitted. Old saddle fit targets a different prototype horse
(6e9b37b7...), so it cannot be relabeled current26 fit.

The next visible deliverable should therefore be the repaired preserved saddle
and one isolated, explicitly reconstructed mounted-IDLE fitting study, with real
canonical output and close/profile/three-quarter images before any town addition.
Walking/trotting, rein slack/tension, boarding, scene interaction and photographic
acceptance remain later T-2804 scopes. Existing current26 careful walk (.135m/1.6s)
is not a natural mounted gait qualification.
