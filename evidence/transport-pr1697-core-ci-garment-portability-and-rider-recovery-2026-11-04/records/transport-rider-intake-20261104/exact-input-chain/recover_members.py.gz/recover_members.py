"""Read-only archived-byte recovery. Never imports generators or decodes a model."""
from pathlib import Path
import json,hashlib,tarfile
D=Path(__file__).resolve().parent
S=D.parent/'recovered-tack/selected-text/riding-saddle-stirrup-central-fold-owned-FROZEN-REVIEW-PARCEL.json'
plan=json.loads((D/'VERIFIED-SIZE-AND-PUBLIC-BLOB-PLAN.json').read_text())
pins=json.loads(S.read_text())['eleven_inputs_and_validator'];pins={path:sha for path,sha in pins.items() if not path.endswith('.cjs')}
assert len(pins)==11 and len(set(pins.values()))==11
found={};archives=[];candidates=[]
for row in plan:
 path=D/row['name'];raw=path.read_bytes();oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
 assert oid==row['git_blob_sha1'] and len(raw)==row['size'],row['name']
 ar={**row,'sha256':hashlib.sha256(raw).hexdigest(),'members':[]};archives.append(ar)
 with tarfile.open(path,'r:gz') as archive:
  for member in archive:
   if not member.isfile():continue
   ar['members'].append({'path':member.name,'size':member.size})
   if not(member.name.endswith('.glb') or Path(member.name).name=='manifest.json'):continue
   assert member.size<=32*1024*1024
   content=archive.extractfile(member).read();sha=hashlib.sha256(content).hexdigest();candidates.append({'archive':row['name'],'member':member.name,'size':len(content),'sha256':sha})
   if sha not in pins.values():continue
   destination=D/'bodies'/sha/Path(member.name).name;destination.parent.mkdir(parents=True,exist_ok=True)
   if destination.exists():assert destination.read_bytes()==content
   else:destination.write_bytes(content)
   record={'path':str(destination),'size':len(content),'sha256':sha,'original_paths':[path for path,want in pins.items() if want==sha],'public_evidence_commit':'68c9443e3c7f7cbd9f8353216544ac0dc82ac488','source_archive':row['name'],'source_member':member.name,'source_archive_git_blob_sha1':oid,'source_archive_sha256':ar['sha256']}
   if sha in found:found[sha].setdefault('additional_occurrences',[]).append(record)
   else:found[sha]=record
(D/'VERIFIED-ARCHIVES-AND-CATALOG.json').write_text(json.dumps(archives,indent=2)+'\n')
(D/'GLB-AND-MANIFEST-HASH-CANDIDATES.json').write_text(json.dumps(candidates,indent=2)+'\n')
missing=[{'original_path':p,'expected_sha256':sha} for p,sha in pins.items() if sha not in found]
result={'status':'ALL_ELEVEN_INPUT_BYTES_RECOVERED_EXACT' if not missing else 'PARTIAL_EXACT_RECOVERY_MISSING_INPUTS','restored_count':len(found),'expected_count':11,'restored':list(found.values()),'missing':missing,'model_decode_native_bake_or_source_execution':False,'app_index_shared_alternate_or_ticket_writes':False,'historical_horse_only_no_current26_fit_transfer':True}
(D/'INPUT-RECOVERY.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'restored':len(found),'missing':missing,'total_downloaded_archive_bytes':sum(a['size'] for a in archives),'restored_body_bytes':sum(a['size'] for a in found.values())},indent=2))
