# Exact historical tack input recovery — no execution

All eleven input bodies declared by central-fold caller1a080c29 were recovered
from ten selective public archive blobs at evidence commit68c9443e3c7f7cbd9f8353216544ac0dc82ac488.
Each archive's Git blob SHA1 and declared byte size matched; each selected member's
SHA256 matched its original caller pin. No input was regenerated or substituted.

INPUT-RECOVERY.json maps each historical absolute path to an isolated restored
body, the exact public archive path/commit/Git blob identity and member name.
Bodies total9,241,137B. Ten downloaded archives total19,069,835B. The separate
684B pinned validator source584230a2 is also restored without being executed.

The11 inputs are A457 rein skin, old horse6e9b and its manifestf2b, plus candidates
50463(shared layers),8ce779(periodic girth),83f7b0(bisector),ae0b84(notch),f644710(frame),
8f32793(stations),6cb6add(paired lower),ff905fe(root peel). None is a newly qualified
model. Failed current historicalcf148d48 remains failed. The old horse is historical;
no current26 horse fit, gait, socket or scene acceptance is transferred.

No model geometry was decoded, no builder/check/capture/browser/bake was run, and
APP/index/tickets/claims/shared alternates were not changed. Archive decompression
and byte hashing only were used. Public member bodies are kept outside APP under
bodies/<declaredSHA256>/<basename>. The failed caller is not launch-ready: native
Python/Node/vendor dependencies and deliberate path relocation still need review.

Checkpoint only the small inventories, this README and optional pinned validator
source. Do not duplicate the already-public archives or GLB bodies into evidence.
Keep this recovery separate from any later20-part footplate repair implementation,
its fresh physical tests, eventual current-horse bridge, and a mounted human pose.
