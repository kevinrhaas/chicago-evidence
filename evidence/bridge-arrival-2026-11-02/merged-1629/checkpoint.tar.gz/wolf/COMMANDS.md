# Wolf metadata increment: finite native owners

After the bridge reader closes and the28 authored additions are installed, run from `chicago/4d`:

```sh
python3 tools/compile_scene.py --all
python3 tools/compile_source_use.py
python3 tools/compile_scene.py --all --check
python3 tools/compile_source_use.py --check
python3 tools/compile_pictures.py --check
python3 tools/grade_structures.py --check
node tools/image_gate.mjs --structure wolf_point_tavern
python3 tools/validate.py --all
bash tools/publish.sh
```

Then run the existing four source-gate parts and native PR questions. No bake, Liberty writer, population/seating pass or whole204 rederive is needed. Publish already writes the ignored per-scene picture index. `OWNER-PLAN.json` lists the narrow expected tracked generated outputs and actual current budget measurements. Let native `compile_source_use` add its five exact manifest-owned source outputs; do not manually compose its generated JSON.

Current catalog539sources/220732raw bytes leaves3268 of224000. Pure packed-row pricing of five new zero-edge sources predicts223021raw (979left); confirm with the real compiler. Current published first-open default-level6 gzip is58614 of120000. No budget increase is presently indicated.

This increment records the completed comparisons and credits. Keep T-2386 in progress until remaining app acceptance is done. Formal source-use backlinks do not read cameras; new picture/source joins are compiled by compile_pictures.
