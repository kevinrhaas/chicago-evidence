from pathlib import Path
import os, subprocess, json, time, shutil
ROOT=Path('/workspace/chicago-bridge-increment-20261102')
APP=ROOT/'chicago/4d';OUT=Path('/workspace/nov2-visible-progress-root/gates')
E=dict(os.environ,PATH=str(OUT/'bin')+os.pathsep+os.environ['PATH'],TMPDIR='/workspace/bg1102',TMP='/workspace/bg1102',TEMP='/workspace/bg1102',CHECK_JOBS='4',C4D_GATE_REQUIRE_READERS='1',C4D_GATE_REQUIRE_BASE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
rows=[]
for part in range(1,5):
    assert shutil.disk_usage('/workspace').free>536870912
    tag=f'checked-part{part}'
    log=OUT/(tag+'.log');reaper=OUT/(tag+'.REAPER.json')
    assert not log.exists() and not reaper.exists()
    env=dict(E,CHECK_TIMINGS=str(OUT/(tag+'.timings')))
    cmd=['python3','/workspace/shared/run-with-reaping.py',str(reaper),'--','timeout','--signal=TERM','--kill-after=15s','600s','nice','-n','19','taskset','-c','0,1,3,4','bash','tools/check.sh','--part',f'{part}/4']
    started=time.monotonic()
    with log.open('xb') as stream: ret=subprocess.run(cmd,cwd=APP,env=env,stdout=stream,stderr=subprocess.STDOUT)
    receipt=json.loads(reaper.read_bytes())
    row={'part':part,'exit':ret.returncode,'seconds':time.monotonic()-started,'log':str(log),'reaper':receipt}
    rows.append(row);(OUT/'PROGRESS.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps({k:row[k] for k in ['part','exit','seconds','log']}),flush=True)
    assert ret.returncode==receipt['command_exit']==0 and receipt['all_children_reaped'] and not receipt['leftover_cleanup'],row
    assert 'CHECK PASS' in log.read_text(errors='replace')
(OUT/'ALL-FOUR-PASS.json').write_text(json.dumps({'status':'ALL_FOUR_NATIVE_SOURCE_CHECK_PARTS_PASS','parts':rows},indent=2)+'\n')
