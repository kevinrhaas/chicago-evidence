from pathlib import Path
import concurrent.futures, hashlib, json, os, shutil, subprocess, urllib.request, time
R=Path('/workspace/chicago-bridge-increment-20261102');OLD=Path('/workspace/t2372-parallel-native-20261030')
OUT=Path('/workspace/nov2-visible-progress-root')
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
rev=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],env=env).decode().strip()
assert rev=='609edb67aa3610aa6ab081ebd5833cefa6681135'
rows=[]
for row in subprocess.check_output(['git','-C',str(R),'ls-tree','-r','-z','HEAD'],env=env).split(b'\0'):
    if not row:continue
    fields,name=row.split(b'\t',1);mode,kind,oid=fields.decode().split()
    assert kind=='blob'
    rows.append((os.fsdecode(name),mode,oid))
def blob(raw):return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
binaries={'.glb','.bin','.webp','.jpg','.jpeg','.png','.ktx2','.tif','.tiff','.pdf','.wav'}
def one(row):
    rel,mode,oid=row;src=OLD/rel;dst=R/rel
    assert not dst.exists() and not dst.is_symlink(),rel
    raw=None;source='remote';linked=False
    if src.is_file() and not src.is_symlink():
        data=src.read_bytes()
        if blob(data)==oid:raw=data;source='existing_exact_blob'
    elif src.is_symlink():
        data=os.fsencode(os.readlink(src))
        if blob(data)==oid:raw=data;source='existing_exact_symlink'
    if raw is None:
        url='https://raw.githubusercontent.com/kevinrhaas/chicago/'+rev+'/'+urllib.parse.quote(rel)
        with urllib.request.urlopen(url,timeout=90) as response:raw=response.read()
        assert blob(raw)==oid,(rel,'canonical blob mismatch')
    dst.parent.mkdir(parents=True,exist_ok=True)
    if mode=='120000':dst.symlink_to(os.fsdecode(raw))
    elif source=='existing_exact_blob' and dst.suffix.lower() in binaries and len(raw)>1048576:
        os.link(src,dst);linked=True
        assert bool(dst.stat().st_mode&0o111)==(mode=='100755')
    else:
        dst.write_bytes(raw);dst.chmod(0o755 if mode=='100755' else 0o644)
    return dict(path=rel,mode=mode,blob=oid,bytes=len(raw),source=source,immutable_binary_hardlink=linked)
started=time.monotonic();results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
    for result in pool.map(one,rows):
        results.append(result)
        if len(results)%2000==0:print('materialized',len(results),'/',len(rows),flush=True)
assert shutil.disk_usage('/workspace').free>536870912
(OUT/'MATERIALIZED.json').write_text(json.dumps({'head':rev,'seconds':time.monotonic()-started,'files':results,'source_code_and_data_copied_independently':True,'only_large_unchanged_binary_inputs_hardlinked':True},indent=2)+'\n')
print(json.dumps({'complete':len(results),'remote':sum(r['source']=='remote' for r in results),'hardlinked':sum(r['immutable_binary_hardlink'] for r in results),'free':shutil.disk_usage('/workspace').free,'seconds':time.monotonic()-started}),flush=True)
