// Outside-APP native observer. Original120s COMPLETE viewport /600s outer caps.
const fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const assert=require('node:assert/strict'),crypto=require('node:crypto');
const [published,out,configFile]=process.argv.slice(2),config=JSON.parse(fs.readFileSync(configFile));
assert.equal(config.approved,true);fs.mkdirSync(out,{recursive:false});
const report={passed:false,runs:[],visual_review_required:true,original_per_viewport_seconds:120,original_outer_seconds:600,
 scope:'Actual published native1/2FPS configured pace, direct fresh admission, Stop/Continue and animation-held clocks; no mocks, natural gait, photographic, trusted-UI or consumer-FPS claim',
 unclaimed:['4FPS','reduced-motion','hidden-tab','confidence-toggle','range-reentry']};
const save=()=>fs.writeFileSync(path.join(out,'REPORT.json'),JSON.stringify(report,null,2)+'\n');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const mime={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.json':'application/json','.glb':'model/gltf-binary','.bin':'application/octet-stream','.wasm':'application/wasm','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.svg':'image/svg+xml','.woff2':'font/woff2','.ktx2':'image/ktx2'};
let server,browser,cleanupAbandoned=false;
const within=async(deadline,label,operation)=>{assert(Date.now()<deadline,`Deadline exhausted before ${label}`);let timer;
 try{return await Promise.race([Promise.resolve().then(operation),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error(`Bounded deadline: ${label}`)),deadline-Date.now());})]);}
 finally{clearTimeout(timer);}};
async function main(){
 const pw=require('/workspace/.cloud-setup/npm/node_modules/playwright');
 server=http.createServer((request,response)=>{let file;try{file=path.resolve(published,'.'+decodeURIComponent(new URL(request.url,'http://native').pathname));}catch{return response.writeHead(400).end();}
  if(!file.startsWith(path.resolve(published)+path.sep))return response.writeHead(403).end();
  if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');
  fs.readFile(file,(error,bytes)=>{if(error){(report.missing??=[]).push(request.url);return response.writeHead(404).end();}
   response.setHeader('Content-Type',mime[path.extname(file)]??'application/octet-stream');response.setHeader('Cache-Control','no-store');response.end(bytes);});});
 await within(Date.now()+5000,'owned server listen',()=>new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);}));
 const origin=`http://127.0.0.1:${server.address().port}`;
 for(const testCase of config.cases){
  const started=Date.now(),deadline=started+120000,workDeadline=deadline-10000;
  const row={...testCase,passed:false,PNG_pairs:[],cleanup_steps:[]};report.runs.push(row);save();
  const bounded=(operation,label)=>within(workDeadline,label,operation);
  let context,page,functional=false;const errors=[];
  try{
   // Retain a late-resolving launch handle too: any deadline failure stays NONPASS.
   browser=await bounded(()=>pw.chromium.launch({executablePath:config.browser,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']}).then(value=>(browser=value)),'browser launch');
   context=await bounded(()=>browser.newContext({viewport:testCase.viewport,deviceScaleFactor:1,hasTouch:testCase.viewport.width===390,isMobile:false,reducedMotion:'no-preference'}),'context');
   page=await bounded(()=>context.newPage(),'page');
   page.on('pageerror',error=>errors.push({kind:'pageerror',message:error.message}));
   page.on('requestfailed',request=>errors.push({kind:'requestfailed',url:request.url(),failure:request.failure()}));
   page.on('response',response=>{if(response.status()>=400)errors.push({kind:'HTTP',url:response.url(),status:response.status()});});
   await bounded(()=>page.route('**/*',route=>{const url=route.request().url();if(url.startsWith(origin+'/')||url.startsWith('blob:')||url.startsWith('data:'))return route.continue();errors.push({kind:'unexpected_remote',url});return route.abort();}),'network boundary');
   // Serve the publisher's real year door and module/base routing unchanged.
   await bounded(()=>page.goto(`${origin}/${testCase.scene}/?debug=1`,{waitUntil:'domcontentloaded',timeout:Math.max(1,workDeadline-Date.now())}),'published native year door');
   await bounded(()=>page.waitForFunction(()=>window.__chicago4d?.ready===true,null,{timeout:Math.max(1,workDeadline-Date.now()),polling:250}),'native ready');
   await bounded(()=>page.addScriptTag({path:path.join(__dirname,'observer.js')}),'observer injection');
   await bounded(()=>page.evaluate(options=>window.nativeElapsedObserver.initialize(options),{scene:testCase.scene,tier:testCase.tier,remaining_viewport_ms:Math.max(1,workDeadline-Date.now())}),'direct fresh native admission');
   row.boot_and_admission_seconds=(Date.now()-started)/1000;
   const screenshot=async name=>{const file=`${testCase.scene}-${testCase.viewport.width}-${name}.png`;await bounded(()=>page.screenshot({path:path.join(out,file),timeout:Math.min(30000,Math.max(1,workDeadline-Date.now()))}),name);const bytes=fs.readFileSync(path.join(out,file));return{file,bytes:bytes.length,sha256:sha(bytes)};};
   for(const fps of[1,2]){
    await bounded(()=>page.evaluate(()=>window.nativeElapsedObserver.prepareWindow()),'native held before frame');
    const before=await screenshot(`${fps}fps-before`),actual=await bounded(()=>page.evaluate(fps=>window.nativeElapsedObserver.runWindow(fps,2),fps),`${fps}FPS native real timer window`),after=await screenshot(`${fps}fps-after`);
    row.PNG_pairs.push({requested_fps:fps,before,after,actual_native_wall_seconds:actual.actual_native_wall_seconds,distance_m:actual.distance_m,identical_camera_recipe:true,pixel_ROI_threshold_used:false});save();
   }
   await bounded(()=>page.evaluate(()=>window.nativeElapsedObserver.beginControls()),'control setup');
   for(const stoppedTick of[false,true])await bounded(()=>page.evaluate(value=>window.nativeElapsedObserver.stopContinue(value),stoppedTick),'native Stop/Continue');
   await bounded(()=>page.evaluate(()=>window.nativeElapsedObserver.hold()),'native held/resumed clock');
   row.actual=await bounded(()=>page.evaluate(()=>window.nativeElapsedObserver.finish()),'final native report');assert(row.actual.passed);assert.deepEqual(errors,[]);functional=true;
  }catch(error){row.error=String(error.stack??error);}
  finally{
   const close=async(label,operation,maxMs)=>{const until=Math.min(deadline,Date.now()+maxMs);try{const value=await within(until,label,operation);row.cleanup_steps.push({label,passed:true});return value;}catch(error){row.cleanup_steps.push({label,passed:false,error:String(error)});cleanupAbandoned=true;return null;}};
   if(page&&!page.isClosed())row.cleanup=await close('native owned asset disposal',()=>page.evaluate(()=>window.nativeElapsedObserver?.cleanup()),2000);
   if(context)await close('owned context close',()=>context.close(),3000);
   if(browser)await close('owned browser close',()=>browser.close(),5000);
   row.browser_closed=!!browser&&!browser.isConnected();browser=null;
   row.viewport_elapsed_seconds=(Date.now()-started)/1000;row.page_errors=errors;
   row.passed=functional&&row.cleanup?.passed===true&&row.browser_closed&&row.cleanup_steps.every(s=>s.passed)&&row.viewport_elapsed_seconds<=120&&errors.length===0;
   save();
  }
  assert(row.passed,row.error??'Native result/owned cleanup/late errors failed');
 }
 assert.equal(report.runs.length,2);assert(report.runs.every(row=>row.passed));assert.deepEqual(report.missing??[],[]);report.passed=true;
}
main().catch(error=>{report.passed=false;report.error=String(error.stack??error);process.exitCode=1;}).finally(async()=>{
 if(browser){try{await within(Date.now()+3000,'final owned browser close',()=>browser.close());}catch(error){report.final_browser_cleanup_error=String(error);cleanupAbandoned=true;}report.browser_closed=!browser.isConnected();}
 else report.browser_closed=report.runs.length>0&&report.runs.every(row=>row.browser_closed);
 try{if(server){server.closeIdleConnections?.();server.closeAllConnections?.();await within(Date.now()+3000,'owned server close',()=>new Promise((resolve,reject)=>server.close(error=>error?reject(error):resolve())));}report.server_closed=!server?.listening;}catch(error){report.server_closed=false;report.server_cleanup_error=String(error);cleanupAbandoned=true;}
 // Late errors and cleanup are part of the final verdict, never an earlier PASS.
 for(const row of report.runs)if(row.page_errors?.length)row.passed=false;
 if(cleanupAbandoned||!report.browser_closed||!report.server_closed||report.runs.some(row=>!row.passed||row.page_errors.length))report.passed=false;
 report.cleanup_delegated_to_outer_supervisor=cleanupAbandoned;save();console.log(JSON.stringify({passed:report.passed,runs:report.runs.length,error:report.error}));
 if(!report.passed)process.exitCode=1;
 // An abandoned Playwright operation may retain Node handles. Stop THIS wrapper;
 // its existing outer subreaper exclusively kills/reaps owned descendants.
 if(cleanupAbandoned)process.exit(1);
});
