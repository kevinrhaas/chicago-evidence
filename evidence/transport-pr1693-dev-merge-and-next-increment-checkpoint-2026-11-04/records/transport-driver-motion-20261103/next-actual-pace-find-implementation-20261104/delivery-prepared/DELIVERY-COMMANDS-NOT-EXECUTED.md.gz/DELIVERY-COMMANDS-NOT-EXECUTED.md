Prepared commands only. Root owns final authorization, canonical lock, commit, publication, PR and merge. Do not execute these until the actual four-part receipt is terminal PASS with unchanged source, accepted resources, complete owned-child/TMP cleanup, and the exact six files remain staged. Do not add gate outputs or ignored mirror files.

1. Read `/workspace/.cloud-setup/transport-driver-motion-20261103/actual-next-motion-cold-find-fourpart-01/CLOSED.json`; require `PASS_ALL_FOUR_NATIVE_CHECK_PARTS_SAME_STAGED_SOURCE`, all four genuine terminal footers, TREE `bf515d57561e8f77e66d7d4a5128a8cfa61c6be6`, and complete cleanup. Review the six-file staged diff once more.

2. With Root GO, normal commit and ordinary push (no force, no shared Git config changes):

```sh
git -C /workspace/chicago-driver-pace-rendezvous-20261104 diff --cached --stat
git -C /workspace/chicago-driver-pace-rendezvous-20261104 commit --file /workspace/.cloud-setup/transport-driver-motion-20261103/next-actual-pace-find-implementation-20261104/delivery-prepared/COMMIT-MESSAGE.txt
git -C /workspace/chicago-driver-pace-rendezvous-20261104 push -u origin steward/t1790-driver-pace-rendezvous-20261104
```

Verify the new commit TREE equals the actual gate TREE; the gate receipt remains the precommit receipt with its original HEAD recorded. Never rewrite its evidence. If hooks change source or the TREE differs, stop for Root review.

3. Before the PR, require parent PR1693 merged into public dev, then read/fetch the exact public dev SHA without moving ROOT HEAD/index/worktree. If public dev advanced beyond the reviewed parent and requires a source refresh, Root reviews that change and requalifies affected checks. Run the two PR-only questions against the actual merge base in NEXT (the full four-part gate is already recorded):

```sh
# Fill these with the exact reviewed public dev and resulting merge-base SHAs.
# Run from /workspace/chicago-driver-pace-rendezvous-20261104/chicago/4d.
node tools/check-changelog-entry.mjs <exact-merge-base-sha> HEAD
node tools/resolve_id_collisions.mjs --base <exact-public-dev-sha> --check
```

4. Root owns any post-commit publish and published checks. Native gate already invokes the original publish path; a post-commit publish may be needed to stamp the committed build metadata. Preserve the original bounded supervisor/cleanup controls and do not stage generated mirrors. No unbounded standalone helper or browser observer is introduced here.

5. Replace the draft's native-result placeholder with the actual receipt, parts/timings and relevant published/render/frame results or precise remaining requirements. Then normal PR command, only after Root GO:

```sh
gh pr create --repo kevinrhaas/chicago --base dev --head steward/t1790-driver-pace-rendezvous-20261104 --title 'T-1790, T-2804: Drivers wait for you and keep their pace' --body-file /workspace/.cloud-setup/transport-driver-motion-20261103/next-actual-pace-find-implementation-20261104/delivery-prepared/PR-BODY-DRAFT.md
```

No ticket state, limits, asset/data/LIBERTIES/STATUS records or public merge actions are changed by this preparation. Root handles existing claims and final delivery.
