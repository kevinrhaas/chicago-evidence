#!/usr/bin/env python3
"""Capture a fresh reviewed staged NEXT source after base advancement; always FALSE GO."""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess
HERE=Path(__file__).resolve().parent
REPO=Path('/workspace/chicago-driver-pace-rendezvous-20261104')
APP=REPO/'chicago/4d'
RUNTIME=Path('/workspace/.cloud-setup/transport-current-20261103')
SUP=Path('/workspace/.cloud-setup/transport-supervise.py')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--reviewed-base',required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 assert re.fullmatch('[0-9a-f]{40}',a.reviewed_base) and not a.out.exists()
 env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1')
 def git(*args):return subprocess.check_output(['git','-c','gc.auto=0','-c','maintenance.auto=false','-C',str(REPO),*args],env=env,timeout=60)
 def val(*args):return git(*args).decode().strip()
 assert val('branch','--show-current')=='steward/t1790-driver-pace-rendezvous-20261104'
 assert not git('ls-files','-u').strip() and not git('diff','--name-only').strip() and not git('ls-files','--others','--exclude-standard').strip()
 expected=json.loads((HERE.parent/'IMPLEMENTED-FILES.json').read_text())
 assert set(git('diff','--cached','--name-only').decode().splitlines())==set(expected),'Stage only the six owned files'
 for f,h in expected.items():assert sha(REPO/f)==h,('Owned implementation changed; review instead of rebinding',f)
 assert val('rev-parse',a.reviewed_base+'^{commit}')==a.reviewed_base
 assert subprocess.run(['git','-C',str(REPO),'merge-base','--is-ancestor',a.reviewed_base,'HEAD'],env=env,timeout=30).returncode==0
 mh=Path(val('rev-parse','--git-path','MERGE_HEAD'));mh=mh if mh.is_absolute() else REPO/mh;assert not mh.exists()
 tree=val('write-tree');source=dict(HEAD=val('rev-parse','HEAD'),TREE=tree,APP=val('rev-parse',tree+':chicago/4d'),semantic_index_sha256=hashlib.sha256(git('ls-files','--stage','-z')).hexdigest())
 declarations=re.findall(r'(?m)^[ \t]*(?:(every_part)\s+)?(step|selftest)\s+',(APP/'tools/check.sh').read_text());assert declarations
 parts={str(k):dict(selected_steps=0,selftests=0,elsewhere_steps=0)for k in range(1,5)}
 for ordinal,(every,kind)in enumerate(declarations,1):
  for k in range(1,5):
   row=parts[str(k)]
   if every or (ordinal-1)%4+1==k:row['selected_steps']+=1;row['selftests']+=int(kind=='selftest')
   else:row['elsewhere_steps']+=1
 pins=[SUP,RUNTIME/'resource_guard.py',Path('/workspace/.cloud-setup/transport-activate.sh'),APP/'tools/check.sh',APP/'tools/check_harness.sh']
 binding=dict(status='PREPARED_EXACT_STAGED_NATIVE_FOURPART_NOT_EXECUTED',template_only=True,ROOT_EXPLICIT_CURRENT_FOURPART_GO=False,repo=str(REPO),branch=val('branch','--show-current'),reviewed_base_SHA=a.reviewed_base,source=source,runner_sha256=sha(HERE/'run_exact_next_fourpart.py'),execution_pins={str(x):sha(x)for x in pins},native_distinct_steps=len(declarations),native_selftests=sum(kind=='selftest'for _,kind in declarations),every_part_steps=sum(bool(every)for every,_ in declarations),expected_parts=parts,original_cap_per_part_seconds=600,prepared_not_executed=True)
 a.out.write_text(json.dumps(binding,indent=2)+'\n');print(json.dumps(dict(binding=str(a.out),GO=False,source=source)))
if __name__=='__main__':main()
