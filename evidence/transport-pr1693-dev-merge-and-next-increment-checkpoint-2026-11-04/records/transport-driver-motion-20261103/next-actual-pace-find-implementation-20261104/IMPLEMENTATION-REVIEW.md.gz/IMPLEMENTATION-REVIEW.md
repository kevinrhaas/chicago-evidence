Implemented only in NEXT isolated worktree; staged and uncommitted.

Visitor behavior: a named driver's Find request can wait through native lazy loading, then stops that same protected driver before publication. Intent cancellation is token-owned and never resumes a fulfilled stop. Terminal failed targets reject transactionally without canceling an older valid request. Light generations, deferred admission, disposal and existing route/identity ownership are retained.

Production transport opts into reset-aware elapsed travel, bounded to 0.25 m rear-axle advance per frame using the unchanged <=0.05 s swept collision/ground substeps. Horse phase remains distance-driven once; speed, gait/physical bounds, driver/horse/vehicle assets and scene data are unchanged. First actual admission/Continue/held/range/Light return frames reset without charging prior inactive time; synthetic replays cannot prime the opted-in visual clock. Legacy direct dt callers keep their existing assertions and behavior.

Validation at the actual NEXT source path: five syntax checks PASS; native Node transport-loop PASS 0.215 s; driven-assembly PASS 0.716 s; changelog contract PASS 0.266 s. Each focused command retained its 30 s supervisor ceiling and complete owned-child/TMP cleanup; resource guard accepted. Both original test files remain exact prefixes, with new cases appended. Staged whitespace check PASS.

Exactly six staged files, 571 insertions/19 deletions; no asset/data/LIBERTIES/STATUS/ticket edits, no commit/push/PR. ROOT and all previously registered worktrees' HEAD/index/status/diffs matched their before snapshot after worktree creation, patching and focused checks. No browser/GPU/heavy gate or canonical lock acquisition.

The future-fourpart-prepared folder remains false GO and unexecuted. Root must advance the NEXT base to the published parent refresh first, then prepare/review a fresh binding; its actual HEAD/TREE is captured after that advance. Full four-part native and real-moving/render/frame checks remain required. The separate low-FPS browser observer stays NOT READY and UNRUN.
