import json,subprocess,pathlib,datetime
O=pathlib.Path(__file__).parent
HEAD="b5ba5e39611bf76512966ea98a89b89c5b4188cd"
BASE="63fabaae622be82eb114344aa087ac6e5c325da9"
def save(n,v): (O/n).write_text(json.dumps(v,indent=2)+"\n")
def api(p,method="GET",body=None):
 c=["gh","api","repos/kevinrhaas/chicago/"+p,"--method",method]
 if body is not None:c += ["--input","-"]
 r=subprocess.run(c,input=json.dumps(body) if body is not None else None,text=True,capture_output=True,timeout=45)
 if r.returncode: raise RuntimeError(r.stderr)
 return json.loads(r.stdout)
p=api("pulls/1693");save("PR-BEFORE.json",p)
if p["merged"]: save("RECONCILED-ALREADY-MERGED.json",p);raise SystemExit(0)
assert p["state"]=="open" and not p["draft"] and p["head"]["sha"]==HEAD
assert "hold" not in {x["name"] for x in p["labels"]}
assert p["base"]["ref"]=="dev"
dev=api("git/ref/heads/dev");save("DEV-REF-BEFORE.json",dev)
assert dev["object"]["sha"]==BASE
assert p["mergeable"] is True and p["mergeable_state"]=="clean"
checks=api("commits/"+HEAD+"/check-runs?per_page=100");save("CHECKS-BEFORE.json",checks)
required={"gate", "humans", "moving-frames", "upload-release"}|{"gate part %s/8"%i for i in range(1,9)}
rows=checks["check_runs"]
assert required <= {x["name"] for x in rows}
assert all(x["status"]=="completed" and x["conclusion"] in ("success","skipped","neutral") for x in rows)
assert all(any(x["name"]==n and x["conclusion"]=="success" for x in rows) for n in required)
f=api("actions/runs/41783095171");save("FRAME-RUN.json",f)
assert f["head_sha"]=="db938eee7b58fb17dbecabd55dacc1815d9b1b87" and f["conclusion"]=="success"
j=api("actions/runs/41783095171/jobs?per_page=100");save("FRAME-JOBS.json",j)
assert len(j["jobs"])==9 and all(x["conclusion"]=="success" for x in j["jobs"])
r=subprocess.run(["git","-C","/workspace/chicago-transport-current-20261103","ls-remote","origin","refs/heads/lap/pr-1693"],capture_output=True,text=True,timeout=45)
assert r.returncode==0 and r.stdout.split()==["1dae219754262c83379113cf512bd13a3602df05","refs/heads/lap/pr-1693"]
intent={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"head":HEAD,"reviewed_dev":BASE,"ordinary_merge_method":"merge"}
assert not (O/"MERGE-INTENT.json").exists(),"Already attempted; reconcile GET, never repeat mutation blindly"
save("MERGE-INTENT.json",intent)
error=None
try: save("MERGE-RESPONSE.json",api("pulls/1693/merge","PUT",{"sha":HEAD,"merge_method":"merge"}))
except Exception as e: error=repr(e);save("MERGE-ERROR.json",{"error":error})
after=api("pulls/1693");save("PR-AFTER.json",after)
if after["merged"]:
 commit=api("git/commits/"+after["merge_commit_sha"]);save("MERGE-COMMIT.json",commit)
save("CLOSED.json",{"status":"ORDINARY_DEV_MERGE_VERIFIED" if after["merged"] else "NOT_MERGED_REVIEW_REQUIRED","merged":after["merged"],"merge_commit_sha":after["merge_commit_sha"],"head":after["head"]["sha"],"merged_at":after["merged_at"],"error":error,"production_promotion":False,"frame_scope":"db938 synthetic merge; later DEV causal review recorded separately"})
assert after["merged"] and after["head"]["sha"]==HEAD
print(json.dumps({"merged":True,"merge_sha":after["merge_commit_sha"],"merged_at":after["merged_at"]}))
