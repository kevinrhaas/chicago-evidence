256-face generic-adult photo library — T-3761, extends T-3746

Unzip this folder. In the extracted folder run:
  python3 -m http.server 3000
Then open:
  http://localhost:3000/tools/photo_face_review.html

The page selector and Previous/Next cover 256 faces in sixteen pages. Light uses one
512-square face page; Full one 1024-square face page. The optional photographed-scalp
trial adds a hair page of the same size. Changing pages reloads the viewer and releases
old renderer/geometry/texture caches. Existing hairstyles are the default; scalp-trial
hairlines still need work. Front, three-quarter and profile compare actual fitted heads.

A 256-entry catalog is not a crowd of 256 simultaneously drawn people. The app preview
(photoFaces=pilot in the project) uses a 1024-square crowd face sheet plus ONE resident-
or-loading nearby detail page: at most 10.67 MiB added RGBA8/mipmapped face textures.
Existing body/clothing assets and whole-scene overhead are outside that figure.

All source people are fictional generated adults; these are not historical likenesses.
Existing historical portraits, visitor choices and children are protected. A registered
single-photo import command is documented in docs/PHOTO-FACE-PILOT.md. Specific people
come next, using actual historical photographs when available.

Measure on this PC exports an isolated 16-head page timing and labels software renderers.
No real low-power GPU or whole-town performance qualification is claimed by this package.
The available task browser uses SwiftShader software. Default population rollout is pending.

Source/before/after, phone, actual residents and all 256 rendered-head images accompany
this viewer in the evidence repository. Original generated sheets and full offline fitting
code/landmarks/recipes are in chicago PR #2355.
