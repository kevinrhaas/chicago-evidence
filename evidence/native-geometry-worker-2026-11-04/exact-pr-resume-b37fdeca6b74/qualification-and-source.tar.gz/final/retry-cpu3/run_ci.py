from pathlib import Path
import json,os,subprocess,time,hashlib
import yaml
R=Path('/workspace/polecat-platform');O=Path(__file__).resolve().parent
w=yaml.safe_load((R/'.github/workflows/ci.yml').read_bytes());steps=[s for s in w['jobs']['check']['steps']if 'run'in s]
frozen=json.loads((O/'FROZEN-CANDIDATE.json').read_bytes())
def guard():
 assert {name:hashlib.sha256((R/name).read_bytes()).hexdigest()for name in frozen['source']}==frozen['source'],'Tracked source drift'
guard()
rows=[]
for i,s in enumerate(steps):
 slug=f'{i+1:02d}';log=O/f'CI-{slug}.log';receipt=O/f'CI-{slug}-REAPER.json';start=time.monotonic()
 with log.open('xb')as f:
  q=subprocess.run(['python','/workspace/shared/run-with-reaping.py',str(receipt),'--','timeout','--signal=TERM','--kill-after=10s','600','nice','-n','19','taskset','-c','3' if i==2 else '2','bash','-c',s['run']],cwd=R,stdout=f,stderr=subprocess.STDOUT)
 guard()
 rr=json.loads(receipt.read_bytes());row={'step':s['name'],'command':s['run'],'exit':q.returncode,'seconds':time.monotonic()-start,'reaper':rr,'log':log.name};rows.append(row)
 (O/'CI-PROGRESS.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'step':row['step'],'exit':row['exit'],'seconds':row['seconds']}),flush=True)
 if q.returncode or not rr['all_children_reaped']or rr['leftover_cleanup']:raise SystemExit(1)
(O/'CI-RESULT.json').write_text(json.dumps({'status':'NATIVE_FULL_PLATFORM_CI_PASS','steps':rows,'required_steps':len(steps),'scope':'Actual exact currentci.yml checkjob run commands; no hostedCI claim'},indent=2)+'\n')
