from pathlib import Path
import subprocess,json,hashlib,os
os.environ.update(GIT_CONFIG_COUNT='2',GIT_CONFIG_KEY_0='gc.auto',GIT_CONFIG_VALUE_0='0',GIT_CONFIG_KEY_1='maintenance.auto',GIT_CONFIG_VALUE_1='false')
R=Path('/workspace/polecat-platform');O=Path(__file__).resolve().parent
expected=['.github/steward/improve.md','.github/steward/test-lanes.mjs','.github/steward/validate-run.mjs','.github/workflows/steward-improve.yml']
def run(*a):return subprocess.check_output(a,cwd=R,text=True).strip()
frozen=json.loads((O/'FROZEN-CANDIDATE.json').read_bytes())
assert {n:hashlib.sha256((R/n).read_bytes()).hexdigest()for n in frozen['source']}==frozen['source']
ci=json.loads((O/'retry-cpu3/CI-RESULT.json').read_bytes());assert ci['status']=='NATIVE_FULL_PLATFORM_CI_PASS' and ci['required_steps']==11
smoke=json.loads((O/'SMOKE-RESULT.json').read_bytes());assert smoke['status']=='ACTUAL_OFFICIAL_PLATFORM_SMOKE_PASS' and smoke['check_count']==15
assert run('git','rev-parse','HEAD')=='aa9d7d2322d3abbc78d72526146c018a241c643e'
assert run('git','branch','--show-current')=='steward/chicago-native-exact-ticket-20261103'
assert run('git','diff','--cached','--name-only')==''
assert run('git','diff','--name-only').splitlines()==expected
run('git','diff','--check')
blobs={}
for name in expected:
 oid=run('git','hash-object',name)
 exists=subprocess.run(['git','cat-file','-e',oid],cwd=R,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
 if not exists:assert run('git','hash-object','-w',name)==oid
 subprocess.run(['git','update-index','--cacheinfo','100644,'+oid+','+name],cwd=R,check=True)
 blobs[name]=oid
assert run('git','diff','--cached','--name-only').splitlines()==expected
subprocess.run(['git','commit','-m','Allow exact native workers to resume their saved Chicago PR'],cwd=R,check=True)
head=run('git','rev-parse','HEAD');assert run('git','diff','--name-only')==''
assert {n:hashlib.sha256((R/n).read_bytes()).hexdigest()for n in frozen['source']}==frozen['source']
(O/'COMMIT.json').write_text(json.dumps({'head':head,'parent':frozen['head'],'blobs':blobs,'guarded_source_count':len(frozen['source'])},indent=2)+'\n')
subprocess.run(['git','push','origin','HEAD:refs/heads/steward/chicago-native-exact-ticket-20261103'],cwd=R,check=True)
print(json.dumps({'head':head,'normal_feature_push':True}),flush=True)
