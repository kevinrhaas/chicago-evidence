/** Combined fresh default world, Wolf7picture credited Images and Green Tree curated exterior. Historical qualified proofs stay immutable and separate. */
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {inspectWolfBody} from './wolf-body.mjs';
import { createRequire } from 'node:module';
const require = createRequire('/workspace/shared/node/node_modules/playwright/package.json');
const { chromium } = require('playwright');
const plan = JSON.parse(fs.readFileSync(process.env.GT_PROBE_PLAN));
const out = process.env.GT_PROBE_OUT, viewport = process.env.GT_PROBE_VIEWPORT;
assert(['desktop', 'mobile'].includes(viewport)); assert(out); fs.mkdirSync(out);
const mobile = viewport === 'mobile', root = plan.site_parent;
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const save = (name, value) => fs.writeFileSync(path.join(out, name), JSON.stringify(value, null, 2) + '\n');
const errors = [], network = [], cancelled = [], consoleErrors = [], serverErrors = [];
const guard = () => { for (const [name, binding] of Object.entries(plan.input_bindings)) assert.equal(sha(fs.readFileSync(name)), binding.sha256, name); };
const types = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.json': 'application/json', '.css': 'text/css', '.wasm': 'application/wasm', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.webp': 'image/webp', '.glb': 'model/gltf-binary', '.ktx2': 'image/ktx2', '.ico': 'image/x-icon', '.woff2': 'font/woff2' };
const server = http.createServer((req, res) => {
  try {
    let file = path.resolve(root, '.' + decodeURIComponent(new URL(req.url, 'http://localhost').pathname));
    if (!file.startsWith(root + path.sep)) { res.writeHead(403).end(); return; }
    if (fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file, 'index.html');
    if (!fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404).end(); return; }
    res.setHeader('Content-Type', types[path.extname(file)] || 'application/octet-stream');
    fs.createReadStream(file).on('error', e => { serverErrors.push(e.message); res.destroy(e); }).pipe(res);
  } catch (e) { serverErrors.push(e.message); res.writeHead(500).end(); }
});
let browser, context, page, cobwebCard=null, wolfBody=null, failure=null;
const started = performance.now();
try {
  guard();
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const proxyUrl = process.env.HTTPS_PROXY ?? process.env.HTTP_PROXY;
  const proxy = proxyUrl ? (() => { const p = new URL(proxyUrl); return { server: p.origin, bypass: '127.0.0.1,localhost', username: decodeURIComponent(p.username) || undefined, password: decodeURIComponent(p.password) || undefined }; })() : undefined;
  process.env.PLAYWRIGHT_DISABLE_FORCED_CHROMIUM_PROXIED_LOOPBACK = '1';
  browser = await chromium.launch({ executablePath: '/usr/bin/chromium', proxy, args: ['--no-sandbox', '--enable-unsafe-swiftshader', '--use-gl=angle', '--use-angle=swiftshader'] });
  context = await browser.newContext({ viewport: { width: mobile ? 390 : 1280, height: mobile ? 780 : 800 }, hasTouch: mobile, isMobile: false, deviceScaleFactor: mobile ? 2 : 1 });
  page = await context.newPage(); page.setDefaultTimeout(90000);
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') consoleErrors.push(m.text()); });
  page.on('requestfailed', r => (r.failure()?.errorText === 'net::ERR_ABORTED' ? cancelled : network).push({ url: r.url(), failure: r.failure() }));
  page.on('response', r => { if (r.status() >= 400) network.push({ url: r.url(), status: r.status() }); });
  await context.addInitScript(() => { localStorage.setItem('chicago4d.researcher', 'on'); localStorage.setItem('chicago4d.settings', JSON.stringify({ detail: 'full' })); });
  assert.equal((await page.goto(`http://127.0.0.1:${server.address().port}/4d/walk/index.html?year=1835`)).status(), 200);
  await page.waitForFunction(() => window.__chicago4d?.ready === true, null, { timeout: 240000, polling: 1000 });
  await page.evaluate(async () => {
    const a = window.__chicago4d, end = Date.now() + 90000;
    while (a.welcome?.state !== 'world' && Date.now() < end) {
      if (a.welcome?.state === 'welcome') a.welcome.enter('spawn');
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    if (a.welcome?.state !== 'world') throw Error('Welcome did not enter world');
    document.exitPointerLock?.(); document.getElementById('control-help-gotit')?.click();
    a.setAnimationHold(true); a.setFloraSpread(true); a.popup.close(); a.navigator.dock();
  });
  const baseline = await page.evaluate(() => { const a = window.__chicago4d; return { frame: a.renderer.info.render.frame, ready: a.ready, welcome: a.welcome.state, visible: document.visibilityState, contextLost: a.renderer.getContext().isContextLost(), detail: a.detail }; });
  save('WORLD-SETTLE.json', { status: 'WAITING', baseline, native_counter_advances_required: 3, bound_ms: 180000 });
  assert(baseline.ready && baseline.welcome === 'world' && baseline.visible === 'visible' && !baseline.contextLost && Number.isSafeInteger(baseline.frame));
  await page.waitForFunction(start => {
    const a = window.__chicago4d;
    if (a.renderer.getContext().isContextLost()) throw Error('Native WebGL context lost');
    if (!a.ready || a.welcome.state !== 'world' || document.visibilityState !== 'visible') throw Error('World readiness changed');
    return Number.isSafeInteger(a.renderer.info.render.frame) && a.renderer.info.render.frame >= start + 3;
  }, baseline.frame, { timeout: 180000, polling: 500 });
  const settled = await page.evaluate(() => window.__chicago4d.renderer.info.render.frame);
  assert(settled >= baseline.frame + 3);
  save('WORLD-SETTLE.json', { status: 'PASS', baseline, settled, native_counter_advances_required: 3, bound_ms: 180000, scope: 'Renderer counter only; no FPS or GPU-readback timing claim' });

  cobwebCard=await page.evaluate(async expected=>{
    const a=window.__chicago4d,id='cobweb_castle';
    a.popup.close();a.navigator.dock();a.travel.stop('Cobweb original panorama credit review');a.setFly(false);a.confidence.resetGrades();a.setConfidenceView(false);
    a.pick(id);document.querySelector('#popup [data-pop-tab="evidence"]')?.click();
    const pane=()=>document.querySelector('#popup [data-pop-pane="images"]');
    const deadline=Date.now()+20000;
    while(Date.now()<deadline&&!(a.popup.picturesDoc?.by_structure?.[id]??[]).some(r=>r.id===expected.id))await new Promise(r=>setTimeout(r,100));
    const srcBefore=pane()?.querySelectorAll('img[src]').length??-1;
    document.querySelector('#popup [data-pop-tab="images"]')?.click();
    const p=pane(),rows=a.popup.picturesDoc?.by_structure?.[id]??[];
    const items=[...(p?.querySelectorAll('.pop-pic-list li,.pop-pic-tile')??[])];
    const cards=items.map(el=>({text:el.textContent.trim(),credit:el.querySelector('.pop-pic-meta,.pop-pic-tile-credit')?.textContent.trim()??'',href:el.querySelector('a')?.href??null}));
    const grade=[...document.querySelectorAll('#popup .pop-facts dt')].find(el=>el.textContent.trim().toLowerCase()==='grade')?.nextElementSibling?.textContent.trim()??'';
    const before=a.renderer.info.render.frame,pending=a.capture(12);a.step();const signature=await pending;
    return {id,openId:a.popup.openId,shown:!!p&&!p.hidden,rows,cards,items:items.length,srcBefore,grade,tabCount:document.querySelector('#popup [data-pop-tab="images"] .pop-count')?.textContent.trim()??'',before,after:a.renderer.info.render.frame,signature,ready:a.ready,welcome:a.welcome.state,detail:a.detail,contextLost:a.renderer.getContext().isContextLost()};
  },plan.expected_cobweb_picture);
  save('COBWEB-CARD.json',cobwebCard);
  assert(cobwebCard.openId==='cobweb_castle'&&cobwebCard.shown,'Actual Cobweb card selected');
  assert(cobwebCard.items===1&&cobwebCard.rows.length===1&&cobwebCard.tabCount==='1'&&cobwebCard.srcBefore===0,'One actual link and no pre-open thumbnail');
  assert(cobwebCard.rows[0].id===plan.expected_cobweb_picture.id&&cobwebCard.rows[0].url===plan.expected_cobweb_picture.url&&!cobwebCard.rows[0].held&&!cobwebCard.rows[0].spot,'Credited contextual picture, no invented held image or spot');
  assert(cobwebCard.grade.toLowerCase().startsWith('inferred'),'Actual card retains inferred grade');
  assert(cobwebCard.cards[0].credit&&cobwebCard.cards[0].credit.includes('Kinzie'),'Actual picture credit');
  assert(cobwebCard.after>cobwebCard.before&&cobwebCard.signature.litFraction>0.05&&Number.isFinite(cobwebCard.signature.mean),'Native card world readback');
  const tab=page.locator('#popup [data-pop-tab="images"]');await tab.scrollIntoViewIfNeeded();await tab.click();
  const link=page.locator('#popup [data-pop-pane="images"] a').filter({hasText:'Fort Dearborn'});
  assert.equal(await link.count(),1);await link.scrollIntoViewIfNeeded();
  await link.evaluate(el=>el.closest('li,.pop-pic-tile').scrollIntoView({block:'center'}));
  const visible=await link.evaluate(el=>{const r=el.getBoundingClientRect(),c=el.closest('li,.pop-pic-tile')?.querySelector('.pop-pic-meta,.pop-pic-tile-credit'),cr=c?.getBoundingClientRect();return {href:el.href,text:el.textContent,credit:c?.textContent,linkVisible:r.width>0&&r.height>0&&r.top>=0&&r.bottom<=innerHeight,creditVisible:!!cr&&cr.width>0&&cr.height>0&&cr.top>=0&&cr.bottom<=innerHeight};});
  assert(visible.linkVisible&&visible.creditVisible&&visible.href===plan.expected_cobweb_picture.url,'Physical link and publication credit visible');
  save('COBWEB-VISIBLE-CREDIT.json',visible);
  const cardShot=path.join(out,'cobweb-images.jpg');await page.screenshot({path:cardShot,type:'jpeg',quality:92});
  save('COBWEB-SCREENSHOT.json',{path:cardShot,sha256:sha(fs.readFileSync(cardShot)),bytes:fs.statSync(cardShot).size});
  wolfBody=await inspectWolfBody(page,plan.wolf_reference_camera);
  const wolfShot=path.join(out,'wolf-body.jpg');await page.screenshot({path:wolfShot,type:'jpeg',quality:92});
  wolfBody.screenshot={path:wolfShot,sha256:sha(fs.readFileSync(wolfShot)),bytes:fs.statSync(wolfShot).size};save('WOLF-BODY.json',wolfBody);
  for(const list of [errors,network,consoleErrors,serverErrors])assert.equal(list.length,0,JSON.stringify(list));
  guard();
  save('RESULT.json',{status:'ACTUAL_PUBLISHED_COBWEB_CARD_AND_WOLF_BODY_PASS',viewport,head:plan.expected_head,qualified_source_scope_sha256:plan.source_scope_sha256,cobwebCard,wolfBody,errors,network,cancelled,consoleErrors,serverErrors,wall_ms:performance.now()-started,no_retry:true,scope:'Fresh default1835 world, actual Cobweb Images1 contextual credit/inferred grade and curated actual Wolf full-asset body inspection. Exact finalhead only. No calibrated geographic source camera, normal arrival guarantee, whole original ticket closure or all-features-unobstructed acceptance without direct images.'});
} catch(e) {
  failure={message:e.message,stack:e.stack};
  if(page){try{await page.screenshot({path:path.join(out,'FAIL.jpg'),type:'jpeg',quality:90});}catch(x){failure.screenshot_error=x.message;}}
  save('FAILURE.json',{failure,errors,network,cancelled,consoleErrors,serverErrors});
} finally {
  if(context)try{await context.close();}catch(e){failure??={message:e.message};}
  if(browser)try{await browser.close();}catch(e){failure??={message:e.message};}
  if(server.listening)await new Promise(resolve=>server.close(resolve));
  save('CLOSURE.json',{failure,errors,network,cancelled,consoleErrors,serverErrors,no_retry:true});
}
if(failure)process.exitCode=1;
