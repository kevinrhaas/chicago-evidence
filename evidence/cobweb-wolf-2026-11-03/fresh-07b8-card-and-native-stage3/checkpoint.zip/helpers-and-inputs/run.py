"""Fresh frozen07b8 actual Cobweb-card/Wolf-body and official stage3 checks."""
from pathlib import Path
import hashlib,json,os,re,shutil,stat,subprocess,tempfile,time
P=Path(__file__).resolve().parent
N=Path('/tmp/cobweb-active-20261103');A=N/'chicago/4d';S=N/'site/4d'
H='07b8ece7c807352ee56ba59d76f76fa54b3691c8';TREE='3f9f1a8566f41745d54ee429db3dd28356d521a1'
O=Path('/tmp/cobweb-wolf-actual-07b8-20261103');K=Path('/tmp/cobweb-wolf-native3-07b8-20261103')
FREEZE=Path('/workspace/cobweb-resume-recovery-20261103/WRITER-FREEZE.json')
FSHA='b462450d40404b97a01c1e99e806f57f93364ac229630f162c3f7058310b8976'
sha=lambda b:hashlib.sha256(b).hexdigest()
pf=lambda p:sha(Path(p).read_bytes())
canonical=lambda d:(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode()
E=os.environ.copy()
for k in ['GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','CHICAGO_TICKETS_DIR']:
 E.pop(k,None)
for k in list(E):
 if k.startswith('SMOKE_'):E.pop(k)
E.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PLAYWRIGHT_DISABLE_FORCED_CHROMIUM_PROXIED_LOOPBACK='1')
def git(*args):return subprocess.check_output(['/usr/bin/git','-C',str(N),*args],env=E)
def dump(path,value):Path(path).write_text(json.dumps(value,indent=2)+'\n')
def floor():
 d={p:shutil.disk_usage(p).free for p in ['/workspace','/tmp']}
 assert d['/workspace']>=536870912 and d['/tmp']>=1800000000,d
 return d
def metadata():
 d={n:sha(git(*args))for n,args in {'index_stage':['ls-files','--stage','-z'],'index_flags':['ls-files','-v','-z'],'refs':['for-each-ref','--format=%(refname) %(objectname)'],'config':['config','--local','--list','--null'],'untracked':['ls-files','--others','--exclude-standard','-z']}.items()}
 d['head']=git('rev-parse','HEAD').decode().strip();d['tree']=git('rev-parse','HEAD^{tree}').decode().strip()
 for name in ['index','HEAD','MERGE_HEAD','MERGE_MSG','ORIG_HEAD','packed-refs','shallow','objects/info/alternates']:
  p=Path(git('rev-parse','--path-format=absolute','--git-path',name).decode().strip())
  d[name]={'sha256':pf(p),'mode':stat.S_IMODE(p.stat().st_mode),'mtime_ns':p.stat().st_mtime_ns,'ctime_ns':p.stat().st_ctime_ns}if p.exists()else None
 return d
def pubmap():
 d={}
 for p in sorted(S.rglob('*')):
  if p.is_file():d[p.relative_to(S).as_posix()]={'bytes':p.stat().st_size,'sha256':pf(p),'mode':stat.S_IMODE(p.stat().st_mode),'symlink':os.readlink(p)if p.is_symlink()else None}
 assert len(d)==5815,len(d)
 return d
def bindings():
 files=set()
 for root in [A/'renderers/web',S/'walk']:
  for ext in ['*.js','*.mjs','*.css','*.html']:files.update(root.rglob(ext))
 files.update([FREEZE,A/'tools/smoke_renderer.mjs',A/'tools/compile_pictures.py',A/'tools/grade_structures.py',A/'data/structure_grades.json',A/'data/pictures/1835.json',S/'data/pictures/1835.json',A/'assets/manifest.json',A/'assets/manifest.web.json',A/'assets/manifest.versions.json'])
 for id in ['cobweb_castle','wolf_point_tavern']:
  source=A/f'data/sidecars/1835/{id}.json';published=S/f'data/sidecars/1835/{id}.json';doc=json.loads(source.read_bytes());shipped=json.loads(published.read_bytes())
  files.update([source,published,A/f'data/structures/{id}.json'])
  if doc.get('residents'):
   house=S/f'data/sidecars/1835/households/{id}.json';held=json.loads(house.read_bytes());assert held=={'id':doc['id'],'residents':doc['residents']};assert dict(shipped,residents=held['residents'])==doc;files.add(house)
  else:assert doc==shipped
  asset=Path(doc['asset']);assert not asset.is_absolute()and'..'not in asset.parts
  files.update([A/'assets'/asset,A/'assets/web'/asset.name,S/'data'/asset]);assert(A/'assets/web'/asset.name).read_bytes()==(S/'data'/asset).read_bytes()
 files.add(A/'data/sources/kinzie_1857_chicago_1831_panorama.json')
 files.add(A/'data/sources/blanchard_davis_c1893_wolfs_point_poster.json')
 views=A/'data/reference_views/wolf_point_tavern'
 for p in views.glob('*.json'):
  files.add(p)
  if not p.name.endswith('.match.json'):
   c=json.loads(p.read_bytes());m=json.loads(p.with_suffix('.match.json').read_bytes());photo=(p.parent/c['photo']).resolve();model=A/m['glb'];sideby=A/m['side_by_side'];assert pf(p)==m['camera_sha256']and pf(photo)==m['photo_sha256']and pf(model)==m['glb_sha256']and m['verdict']=='matches';files.update([photo,model,sideby,A/'data/sources'/f"{c['source_id']}.json"])
 assert pf(A/'assets/gltf/wolf_point_tavern__log_frame_1828.glb')=='225f3e1041d02cdaa627d3d73c5f6448aff9b12c66f4a545462db45bbf8e0d59'
 assert pf(A/'assets/web/wolf_point_tavern__log_frame_1828.glb')=='fdc5ef22a440636e35e4cec15818661f4351f0f4d0c9e506ef36b00422a45210'
 return {str(p):{'bytes':p.stat().st_size,'sha256':pf(p),'mode':stat.S_IMODE(p.stat().st_mode)}for p in sorted(files)}

assert not O.exists()and not K.exists()
assert pf(FREEZE)==FSHA
assert git('rev-parse','HEAD').decode().strip()==H and git('rev-parse','HEAD^{tree}').decode().strip()==TREE
assert not git('status','--porcelain','--untracked-files=normal')
before_meta=metadata();before_inputs=bindings();before_pub=pubmap();helpers={n:pf(P/n)for n in ['run.py','probe.mjs','wolf-body.mjs']};reaper_sha=pf('/workspace/shared/run-with-reaping.py')
pics=json.loads((S/'data/pictures/1835.json').read_bytes());rows=pics['by_structure']['cobweb_castle'];assert len(rows)==1 and rows[0]['id']=='kinzie_1857_chicago_1831_panorama'and not rows[0].get('held')and not rows[0].get('spot')
assert json.loads((S/'data/sidecars/1835/cobweb_castle.json').read_bytes())['grade']['value']=='inferred'
assert json.loads((A/'data/sources/kinzie_1857_chicago_1831_panorama.json').read_bytes())['url']==rows[0]['url']
scratch=Path(tempfile.mkdtemp(prefix='cwq-'))
plan={'expected_head':H,'expected_tree':TREE,'source_root':str(N),'site_parent':str(N/'site'),'expected_cobweb_picture':rows[0],'expected_cobweb_grade':'inferred','wolf_reference_camera':json.loads((A/'data/reference_views/wolf_point_tavern/nypl-1867.json').read_bytes()),'input_bindings':before_inputs,'source_scope_sha256':sha(canonical(before_inputs)),'metadata':before_meta,'helpers':helpers,'reaper_sha256':reaper_sha,'full_published_members':len(before_pub),'full_published_map_sha256':sha(canonical(before_pub)),'writer_freeze_sha256':FSHA,'authorization':'Root exact07b8 read-only source/Git/publication+exclusiveGPU lease; all source writers closed.','TMP':str(scratch),'scope':'Actual default1835 world, CobwebImages1 contextualcredit/inferredgrade and curated actualWolfBODY at desktop1280x800/phone390x780. Separate fresh officialnativeStage3both. No source/geometry mutations, fabricated camera spot, original-ticket completion or all-features-clear claim until direct screenshots.'}
dump(P/'PLAN.json',plan);dump(P/'BEFORE-PUBMAP.json',before_pub);plan_sha=pf(P/'PLAN.json')
def guard():
 assert metadata()==before_meta,'Git metadata changed'
 assert bindings()==before_inputs,'Selected source/published inputs changed'
 assert pubmap()==before_pub,'Complete5815published member map changed'
 assert {n:pf(P/n)for n in helpers}==helpers and pf('/workspace/shared/run-with-reaping.py')==reaper_sha
 assert pf(P/'PLAN.json')==plan_sha
 floor()
def command(cmd,cwd,env,receipt,log):
 with log.open('xb')as f:r=subprocess.run(['python','/workspace/shared/run-with-reaping.py',str(receipt),'--','timeout','--signal=TERM','--kill-after=15s','600s','nice','-n','19','taskset','-c','0-4',*cmd],cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rr=json.loads(receipt.read_bytes());assert r.returncode==rr['command_exit']==0 and rr['all_children_reaped']and not rr['leftover_cleanup']and rr['interrupted_signal']is None,(r.returncode,rr,str(log))
 return rr
O.mkdir();K.mkdir();env=dict(E,TMPDIR=str(scratch),TMP=str(scratch),TEMP=str(scratch),NODE_COMPILE_CACHE=str(scratch/'node-cache'))
steps=[];error=None;native=[];started=time.monotonic()
dump(O/'OWNER.json',{'pid':os.getpid(),'head':H,'plan_sha256':plan_sha,'input_count':len(before_inputs),'pub_members':len(before_pub),'resources':floor()})
try:
 for viewport in ['desktop','mobile']:
  guard();t=time.monotonic();ve=dict(env,GT_PROBE_PLAN=str(P/'PLAN.json'),GT_PROBE_OUT=str(O/viewport),GT_PROBE_VIEWPORT=viewport)
  rr=command(['node',str(P/'probe.mjs')],A,ve,O/(viewport+'-REAPER.json'),O/(viewport+'.log'))
  result=json.loads((O/viewport/'RESULT.json').read_bytes());assert result['status']=='ACTUAL_PUBLISHED_COBWEB_CARD_AND_WOLF_BODY_PASS'
  guard();steps.append({'viewport':viewport,'seconds':time.monotonic()-t,'reaper':rr,'status':result['status']});dump(O/'STEPS.json',steps);print(json.dumps({'custom_closed':viewport,'seconds':steps[-1]['seconds'],'output':str(O/viewport)}),flush=True)
 dump(O/'RESULT.json',{'status':'FRESH_COBWEB_CARD_WOLF_BODY_BOTH_PASS','head':H,'steps':steps,'input_count':len(before_inputs),'full_published_members':len(before_pub),'all_guards_exact':True,'scope':plan['scope']})
 for viewport in ['mobile','desktop']:
  guard();t=time.monotonic();ve=dict(env,SMOKE_VIEWPORT=viewport,SMOKE_STAGE='3',SMOKE_ROOT=str(S),SMOKE_SHOTS=str(K/(viewport+'-shots')))
  rr=command(['node','tools/smoke_renderer.mjs','--published'],A,ve,K/(viewport+'-REAPER.json'),K/(viewport+'.log'))
  text=(K/(viewport+'.log')).read_text(errors='replace');counts=re.findall(r'(\d+) passed, (\d+) failed',text);assert counts and counts[-1]==('107','0')and'SMOKE PASS'in text
  guard();native.append({'viewport':viewport,'seconds':time.monotonic()-t,'passed':107,'failed':0,'reaper':rr});dump(K/'PROGRESS.json',native);print(json.dumps({'native_closed':viewport,'seconds':native[-1]['seconds'],'passed':107,'failed':0}),flush=True)
 dump(K/'RESULT.json',{'status':'NATIVE_PUBLISHED_STAGE3_BOTH_107_PASS','head':H,'rows':native,'scope':'Fresh current07b8officialnativepublishedStage3both after actualCobwebcard/WolfbodyBOTH. No other14parts/FPS/alloriginalclosure claim.'})
except BaseException as e:
 error=repr(e);dump(O/'FAILURE.json',{'error':error,'steps':steps,'native':native});print(error,flush=True)
finally:
 try:guard();exact=True
 except BaseException as e:exact=False;error=(error+'; 'if error else'')+'Final closure: '+repr(e)
 closure={'status':'FRESH_07B8_CUSTOM_AND_NATIVE3_ALL_READERS_CLOSED_PASS'if error is None and len(steps)==len(native)==2 else'NOT_QUALIFIED','head':H,'tree':TREE,'custom_viewports':steps,'native_viewports':native,'selected_input_count':len(before_inputs),'full_published_members':len(before_pub),'full_published_map_sha256':sha(canonical(before_pub)),'source_publication_Git_helpers_plan_exact':exact,'all_owned_process_groups_reaped':all(x['reaper']['all_children_reaped']and not x['reaper']['leftover_cleanup']for x in steps+native),'error':error,'seconds':time.monotonic()-started,'resources':floor()}
 dump(K/'FINAL-CLOSURE.json',closure);print(json.dumps({'final_status':closure['status'],'error':error}),flush=True)
raise SystemExit(1 if error else 0)
