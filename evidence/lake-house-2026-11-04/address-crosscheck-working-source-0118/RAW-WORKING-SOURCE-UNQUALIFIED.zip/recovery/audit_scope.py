from pathlib import Path
import json,sys,hashlib,subprocess,os
P=Path(__file__).parent;R=Path('/tmp/cobweb-active-20261103');A=R/'chicago/4d';BASE='96d0612d940e3652af24875674a2e17feeb38184'
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(*a):return subprocess.check_output(['/usr/local/bin/git','-C',str(R),*a],env=E)
def prior(p):return git('show',BASE+':chicago/4d/'+p)
sys.path[:0]=[str(A/'generators'),str(A/'tools')]
import mesh_inputs,compile_pictures,grade_structures
sid='lake_house_construction';rel='data/structures/'+sid+'.json'
before=json.loads(prior(rel));after=json.loads((A/rel).read_bytes())
docs=[]
for pb,pa in zip(before['phases'],after['phases']):
    b=mesh_inputs.structure_inputs_doc(before,pb);a=mesh_inputs.structure_inputs_doc(after,pa)
    hb=mesh_inputs.structure_inputs_sha(before,pb);ha=mesh_inputs.structure_inputs_sha(after,pa)
    assert b==a and hb==ha
    docs.append({'phase':pa['id'],'full_recipe':ha,'input_document_exact':True,'resolved_params_exact':True})
(P/'NATIVE-INPUT-DOCUMENT.json').write_text(json.dumps(mesh_inputs.structure_inputs_doc(after,after['phases'][0]),indent=2)+'\n')
images,tsv,sources,structures,scenes,views=compile_pictures.read_tree()
current=compile_pictures.derive(images,tsv,sources,structures,scenes,views)
sources_before=dict(sources);sources_before['fergus_chicago_directory_1839']=json.loads(prior('data/sources/fergus_chicago_directory_1839.json'))
structures_before=dict(structures);structures_before[sid]=prior(rel).decode()
previous=compile_pictures.derive(images,tsv,sources_before,structures_before,scenes,views)
assert previous==current
rows=current['1835']['by_structure'][sid];assert len(rows)==1 and not rows[0].get('held') and not rows[0].get('spot')
registries={}
for rel in ['assets/manifest.json','assets/manifest.web.json','assets/manifest.versions.json']:
    assert (A/rel).read_bytes()==prior(rel);registries[rel]=hashlib.sha256(prior(rel)).hexdigest()
assets={}
for rel in ['assets/gltf/lake_house_construction__shell_1835.glb','assets/web/lake_house_construction__shell_1835.glb']:
    current_asset=(A/rel).read_bytes();assert current_asset==prior(rel);assets[rel]={'sha256':hashlib.sha256(current_asset).hexdigest(),'bytes':len(current_asset)}
out={'base':BASE,'state':'APPLIED_METADATA_ONLY_NATIVE_SCOPE_PASS_FULL_SOURCE_AND_UI_PENDING','changed_structure_root_fields':sorted(k for k in before if before[k]!=after[k]),'changed_function_fields':sorted(k for k in before['function'] if before['function'][k]!=after['function'][k]),'native_phases':docs,'all_compiled_picture_scenes_semantically_exact':True,'Lake_Images_rows':rows,'registries_exact':registries,'actual_master_and_web_exact':assets,'original_ticket_partial_open':True,'no_native_build_needed':'All complete native input documents, parameters, code and actual asset bytes remain exact; no geometry-affecting field changed.'}
(P/'FIELD-AND-NATIVE-OWNER-AUDIT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
