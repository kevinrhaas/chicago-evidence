from pathlib import Path
import os,json,subprocess,time,shutil
P=Path(__file__).parent;R=Path('/tmp/cobweb-active-20261103');A=R/'chicago/4d'
E=dict(os.environ)
for k in ['CHICAGO_TICKETS_DIR','GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES']:E.pop(k,None)
E.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
checks=[('pictures',['python','tools/compile_pictures.py']),('scene-all',['python','tools/compile_scene.py','--all']),('source-use',['python','tools/compile_source_use.py']),('grade',['python','tools/grade_structures.py','--check']),('changelog',['node','tools/changelog-entries.mjs','--check']),('derived',['node','tools/rederive.mjs','--check']),('validate-all',['python','tools/validate.py','--all'])]
rows=[]
for label,cmd in checks:
    assert shutil.disk_usage('/workspace').free>536870912 and shutil.disk_usage('/tmp').free>1800000000
    t=time.monotonic();rec=P/('owner-'+label+'-REAPER.json')
    with (P/('owner-'+label+'.log')).open('xb') as f:
        result=subprocess.run(['python','/workspace/shared/run-with-reaping.py',str(rec),'--','timeout','--signal=TERM','--kill-after=15s','600s','nice','-n','19','taskset','-c','2',*cmd],cwd=A,env=E,stdout=f,stderr=subprocess.STDOUT)
    rr=json.loads(rec.read_bytes());row={'label':label,'command':cmd,'exit':result.returncode,'seconds':time.monotonic()-t,'reaper':rr};rows.append(row)
    (P/'OWNERS-PROGRESS.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert result.returncode==rr['command_exit']==0 and rr['all_children_reaped'] and not rr['leftover_cleanup'] and rr['interrupted_signal'] is None,label
(P/'OWNERS-PASS.json').write_text(json.dumps({'all_green':True,'rows':rows},indent=2)+'\n')
