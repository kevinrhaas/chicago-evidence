from pathlib import Path
import hashlib,json,subprocess,os
P=Path(__file__).parent
R=Path('/tmp/cobweb-active-20261103');A=R/'chicago/4d'
C=Path('/tmp/lake-house-primary-research-20261104/APP-CANDIDATE')
BASE='96d0612d940e3652af24875674a2e17feeb38184'
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(*args):return subprocess.check_output(['/usr/local/bin/git','-C',str(R),*args],env=E)
assert git('rev-parse','HEAD').decode().strip()==BASE
assert not git('status','--porcelain')
def original(rel):return git('show',BASE+':chicago/4d/'+rel)
def sha(b):return hashlib.sha256(b).hexdigest()
def replace_root_fields(raw,updates):
    text=raw.decode();dec=json.JSONDecoder();i=text.index('{')+1;spans={}
    while True:
        while text[i].isspace() or text[i]==',':i+=1
        if text[i]=='}':break
        key,end=dec.raw_decode(text,i);i=end
        while text[i].isspace() or text[i]==':':i+=1
        start=i;value,end=dec.raw_decode(text,i);spans[key]=(start,end);i=end
    for key in sorted((k for k in updates if k in spans),key=lambda k:spans[k][0],reverse=True):
        start,end=spans[key];v=json.dumps(updates[key],ensure_ascii=False,indent=2)
        v=v.replace('\n','\n  ');text=text[:start]+v+text[end:]
    missing={k:v for k,v in updates.items() if k not in spans}
    if missing:
        end=text.rindex('}');prefix=text[:end].rstrip()
        text=prefix+',\n'+',\n'.join('  '+json.dumps(k)+': '+json.dumps(v,ensure_ascii=False,indent=2).replace('\n','\n  ') for k,v in missing.items())+'\n'+text[end:]
    return text.encode()
payloads={}
src='data/sources/fergus_chicago_directory_1839.json'
source=json.loads((C/'postimages'/src).read_bytes())
source['access_notes']=source['access_notes'].replace('leaf49/page37','leaf 49 / page 37').replace(' or a licence claim about unrelated assets','')
payloads[src]=replace_root_fields(original(src),{k:source[k] for k in ['note','access_notes']})
st='data/structures/lake_house_construction.json'
structure=json.loads((C/'postimages'/st).read_bytes())
payloads[st]=replace_root_fields(original(st),{k:structure[k] for k in ['function','research_note']})
research='''

## T2379 — a directly checked later address, 2026-11-04

Fergus, *Directory of the City of Chicago, 1839* (Chicago: Fergus Printing Company, 1876), Hotels section, printed p. 37, gives “Lake House, cor. Rush and North Water sts”. This line was read directly in the Allen County Public Library Genealogy Center scan on Internet Archive: https://archive.org/download/fergusdirectoryo00ferg/page/n48.jpg . The check verifies this entry's printing; it does not verify the historical accuracy of Fergus's recollection or the rest of the directory's OCR. The existing source `fergus_chicago_directory_1839` retains tier 2, text-only use, publication in 1876 and described date of 1839.

The later Rush/North Water address differs from Andreas's Rush/Kinzie/Michigan account. That disagreement remains available for a future period-map or conveyance reading. The west-half-block description from the 1843 canvass, published in an 1896 edition, remains a transcription-mediated lead rather than a metric plan. Neither later account locates the July 1835 construction shell. North Water and Michigan are not silently equated, and the record is not moved to a modern Wrigley Building gloss.

The bounded full-text search covered 28 primary transcriptions: 15 Chicago Democrat and 13 Chicago American issues, totaling 3,215,983 characters, with corpus hashes verified. Only the already admitted June 10 project notice appeared under the named and OCR search patterns. Twelve broader candidate contexts were checked and concerned other buildings or places. These newspaper readings remain transcription-mediated: no original June 10 facsimile was read, and damaged OCR may miss notices. This search does not prove absence. The existing one-storey, four-metre, roofless 24 × 15 m shell, its placement, phase and confidence, and the later 1856 picture's date limit remain unchanged. Original image acceptance is still incomplete.

[Primary coverage, direct page image, holding and publication metadata, access failures and limits](https://github.com/kevinrhaas/chicago-evidence/blob/7dc233d052373ee03feecd7bf8b01f11e1287408/evidence/lake-house-2026-11-04/primary-search28-issues-and-fergus-direct-line/RECOVERY.md). This increment adds a source reading and visitor Record explanation; it claims no new geometric match or original-ticket completion.
'''
status='''

### Lake House source reading — 2026-11-04

The Record now distinguishes a directly checked line in Fergus's 1876 recollection of the 1839 Rush/North Water address from Andreas's differing street account. The July 1835 construction stage, position and dimensions remain uncertain. This increment changes source and Record metadata; it claims no new geometry or image-match completion.
'''
roadmap='''

### T2379 — later-address source cross-check, 2026-11-04

The existing Fergus source now identifies a directly checked Lake House Hotels entry from his 1876 recollection of 1839. Record and Sources state its date and the conflicting street accounts. Construction-state picture matching remains OPEN; coordinates, phases, dimensions, grades and meshes are unchanged.
'''
for rel,tail in [('docs/RESEARCH/lake_house_construction.md',research),('docs/STATUS.md',status),('docs/ROADMAP.md',roadmap)]:
    payloads[rel]=original(rel)+tail.encode()
payloads['changelog.d/T-2379.json']=(C/'postimages/changelog.d/T-2379.json').read_bytes()
records=[]
for rel,data in payloads.items():
    dest=A/rel;before=dest.read_bytes() if dest.exists() else None
    assert before==original(rel) if rel!='changelog.d/T-2379.json' else before is None
    saved=P/'postimages'/rel;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(data)
    saved=P/'preimages'/rel;saved.parent.mkdir(parents=True,exist_ok=True)
    if before is not None:saved.write_bytes(before)
    dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    records.append({'path':'chicago/4d/'+rel,'before_sha256':sha(before) if before is not None else None,'after_sha256':sha(data),'bytes':len(data)})
before=json.loads(original(st));after=json.loads(payloads[st])
assert {k:v for k,v in before.items() if k not in ['function','research_note']}=={k:v for k,v in after.items() if k not in ['function','research_note']}
assert {k:v for k,v in before['function'].items() if k not in ['sources','note']}=={k:v for k,v in after['function'].items() if k not in ['sources','note']}
bs=json.loads(original(src));as_=json.loads(payloads[src]);assert {k:v for k,v in bs.items() if k not in ['note','access_notes']}=={k:v for k,v in as_.items() if k not in ['note','access_notes']}
(P/'APPLIED.json').write_text(json.dumps({'base':BASE,'qualified':False,'paths':records,'all_other_structure_fields_exact':True,'function_value_confidence_exact':True,'all_other_source_fields_exact':True,'STATUS_actual_prefix_bytes':len(original('docs/STATUS.md'))},indent=2)+'\n')
(P/'AUTHORED.diff').write_bytes(git('diff','--binary'))
print(json.dumps({'applied':len(records),'STATUS_prefix_preserved':len(original('docs/STATUS.md')),'qualified':False}))
