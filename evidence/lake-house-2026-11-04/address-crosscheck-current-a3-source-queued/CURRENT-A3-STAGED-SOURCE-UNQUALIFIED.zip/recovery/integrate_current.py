"""Ordinary FF of the unpublished branch, then guarded reapply of owned metadata."""
from pathlib import Path
import os,subprocess,json,hashlib,shutil,time
P=Path(__file__).parent;R=Path('/tmp/cobweb-active-20261103');A=R/'chicago/4d';Q=P/'quiet-cards-2'
C=Path('/tmp/first-fort-finish-1685-20261104/current-dev-aa4-cache');BASE='96d0612d940e3652af24875674a2e17feeb38184'
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def g(*a):return subprocess.check_output(['/usr/local/bin/git','-C',str(R),*a],env=E)
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(name,d):(P/name).write_text(json.dumps(d,indent=2)+'\n')
def replace_fields(raw,updates):
    text=raw.decode();dec=json.JSONDecoder();i=text.index('{')+1;spans={}
    while True:
        while text[i].isspace()or text[i]==',':i+=1
        if text[i]=='}':break
        key,end=dec.raw_decode(text,i);i=end
        while text[i].isspace()or text[i]==':':i+=1
        start=i;_,end=dec.raw_decode(text,i);spans[key]=(start,end);i=end
    for key in sorted((k for k in updates if k in spans),key=lambda k:spans[k][0],reverse=True):
        start,end=spans[key];value=json.dumps(updates[key],ensure_ascii=False,indent=2).replace('\n','\n  ');text=text[:start]+value+text[end:]
    missing={k:v for k,v in updates.items()if k not in spans}
    if missing:
        end=text.rindex('}');text=text[:end].rstrip()+',\n'+',\n'.join('  '+json.dumps(k)+': '+json.dumps(v,ensure_ascii=False,indent=2).replace('\n','\n  ')for k,v in missing.items())+'\n'+text[end:]
    return text.encode()
ui=json.loads((Q/'UI-CLOSURE.json').read_bytes());assert ui['status']=='LAKE_ADDRESS_WORKING_SOURCE_CUSTOM_BOTH_PASS_NATIVE3_PENDING'
outer=json.loads((Q/'UI-OUTER-REAPER.json').read_bytes());assert outer['command_exit']==0 and outer['all_children_reaped']and not outer['leftover_cleanup']
repair=json.loads((C/'graph-repair/READY.json').read_bytes());tip=repair['current_dev'];delta=json.loads((C/'a3a-delta/READY.json').read_bytes());assert delta['tip']==tip and repair['actual_merge_base']==BASE and repair['merge_base_exit0_no_stderr']
assert g('rev-parse','HEAD').decode().strip()==BASE and not g('diff','--cached','--name-only')
assert sha(g('diff','--binary'))==ui['source']['diff_sha256']
for rel,h in ui['source']['working_paths'].items():assert sha((R/rel).read_bytes())==h
ancestry=subprocess.run(['/usr/local/bin/git','-C',str(R),'merge-base','--is-ancestor',BASE,tip],env=E,capture_output=True);assert ancestry.returncode==0 and not ancestry.stderr
expected_tree=g('rev-parse',tip+'^{tree}').decode().strip();assert expected_tree==delta['tip_tree']
assert shutil.disk_usage('/workspace').free>536870912 and shutil.disk_usage('/tmp').free>1800000000
owned=json.loads((P/'OWNED-DELTAS.json').read_bytes())
# Guard every owned JSON preimage before even restoring our working patch.
for rel,d in owned['json_fields'].items():assert json.loads(g('show',tip+':chicago/4d/'+rel))==d['before_entire'],('incoming changed owned JSON; inspect before overwriting',rel)
assert subprocess.run(['/usr/local/bin/git','-C',str(R),'cat-file','-e',tip+':chicago/4d/changelog.d/T-2379.json'],env=E,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0
dump('CURRENT-FF-BEFORE.json',{'head':BASE,'target':tip,'target_tree':expected_tree,'old_qualified_UI_source':ui['source'],'borrowed_cache':str(C),'graph_repair_receipt':repair,'ordinary_FF_no_force':True})
g('update-ref','refs/recovery/lake-address-own-source-before-currentdev-20261104',BASE)
tracked=[p for p in ui['source']['working_paths']if p!='chicago/4d/changelog.d/T-2379.json']
g('restore','--source=HEAD','--worktree','--',*tracked)
(A/'changelog.d/T-2379.json').unlink()
assert not g('status','--porcelain')
g('update-ref','refs/remotes/origin/dev',tip)
t=time.monotonic();result=subprocess.run(['/usr/local/bin/git','-C',str(R),'merge','--ff-only','--no-edit',tip],env=E,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(P/'CURRENT-FF-native.log').write_bytes(result.stdout+result.stderr)
assert result.returncode==0
assert g('rev-parse','HEAD').decode().strip()==tip and g('write-tree').decode().strip()==expected_tree,'Do not trust exit0/Already up to date with missing graph metadata'
assert not g('status','--porcelain')
assert subprocess.run(['/usr/local/bin/git','-C',str(R),'rev-parse','--verify','MERGE_HEAD'],env=E,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0
# Re-read every incoming changed worktree blob against its authenticated TIP object.
changed=g('diff','--name-only',BASE,tip).decode().splitlines();verified=[]
tree={}
for line in g('ls-tree','-r',tip).splitlines():
    head,path=line.split(b'\t',1);mode,typ,oid=head.decode().split();tree[path.decode()]=(mode,typ,oid)
for rel in changed:
    p=R/rel
    if rel not in tree:assert not p.exists();continue
    mode,typ,oid=tree[rel];assert typ=='blob'and p.is_file(),rel
    assert blob(p.read_bytes())==oid,rel
    verified.append({'path':rel,'git_blob':oid,'bytes':p.stat().st_size})
dump('CURRENT-FF-CLOSED.json',{'status':'ACTUAL_ORDINARY_FF_EXACT_HEAD_TREE_AND_ALL_FOREIGN_POSTIMAGES_VERIFIED','from':BASE,'target':tip,'tree':expected_tree,'seconds':time.monotonic()-t,'foreign_changed_blobs':verified,'no_source_delta_lost':'Owned9postimages/UIproof already preserved before native restore/FF.'})
rows=[]
for rel,d in owned['json_fields'].items():
    before=(A/rel).read_bytes();assert json.loads(before)==d['before_entire'];after=replace_fields(before,d['after_owned_fields']);(A/rel).write_bytes(after)
    rows.append({'path':rel,'parent_sha256':sha(before),'post_sha256':sha(after),'semantic_owned_fields':d['allowed_changed_root_fields']})
for rel,d in owned['raw_document_appends'].items():
    before=(A/rel).read_bytes();tail=d['tail'].encode();assert tail not in before
    (A/rel).write_bytes(before+tail)
    assert (A/rel).read_bytes().startswith(before)
    rows.append({'path':rel,'parent_prefix_bytes':len(before),'parent_prefix_sha256':sha(before),'owned_tail_sha256':sha(tail),'raw_prefix_exact':True})
chlog=A/'changelog.d/T-2379.json';assert not chlog.exists();chlog.write_bytes((P/'postimages/changelog.d/T-2379.json').read_bytes())
assert json.loads(chlog.read_bytes())==owned['changelog']
rows.append({'path':'changelog.d/T-2379.json','post_sha256':sha(chlog.read_bytes()),'new_owned_file':True})
dump('CURRENT-REAPPLIED.json',{'status':'OWNED6_METADATA_POSTIMAGES_REAPPLIED_OVER_VERIFIED_CURRENT_DEV','parent':tip,'parent_tree':expected_tree,'paths':rows,'unrelated_JSON_fields_exact':True,'all_foreign_raw_doc_prefixes_preserved':True,'source4':'PENDING','nativeStage3_currentboth':'PENDING','custom_cards_old96':'PASS_WITH_ROOT_APPROVED_SCOPED_REUSE_BINDING_PENDING'})
print('OrdinaryFF verified allforeignpostimages; owned6 reapplication closed',tip,flush=True)
