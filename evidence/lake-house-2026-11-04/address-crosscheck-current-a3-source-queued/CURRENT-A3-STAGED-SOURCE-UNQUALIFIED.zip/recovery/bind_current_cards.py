"""Scoped reuse of actual card QA after a qualified foreign dev integration."""
from pathlib import Path
import os,subprocess,json,hashlib
P=Path(__file__).parent;R=Path('/tmp/cobweb-active-20261103');A=R/'chicago/4d';BASE='96d0612d940e3652af24875674a2e17feeb38184';TIP='a3a87cafe9321a2970a390cac77ae45be82680f5'
E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def g(*a):return subprocess.check_output(['/usr/local/bin/git','-C',str(R),*a],env=E)
sha=lambda b:hashlib.sha256(b).hexdigest()
def prior(c,rel):return g('show',c+':'+rel)
ui=json.loads((P/'quiet-cards-2/UI-CLOSURE.json').read_bytes());assert ui['status']=='LAKE_ADDRESS_WORKING_SOURCE_CUSTOM_BOTH_PASS_NATIVE3_PENDING'
assert g('rev-parse','HEAD').decode().strip()==TIP
assert json.loads((P/'current-owners/OWNERS-PASS.json').read_bytes())['all_green']
owned=json.loads((P/'OWNED-DELTAS.json').read_bytes());paths=[]
for rel,h in ui['source']['working_paths'].items():
    current=(R/rel).read_bytes();exact=sha(current)==h
    if not exact:
        short=rel.removeprefix('chicago/4d/');assert short in ['docs/STATUS.md','docs/ROADMAP.md']
        tail=owned['raw_document_appends'][short]['tail'].encode();parent=prior(TIP,rel)
        assert current==parent+tail
        paths.append({'path':rel,'whole_bytes_exact':False,'own_tail_exact':True,'new_foreign_parent_prefix_preserved':True,'new_prefix_bytes':len(parent),'current_sha256':sha(current)})
    else:paths.append({'path':rel,'whole_bytes_exact':True,'current_sha256':h})
modules=['popup.js','reader-text.js','citations.js','pictures.js','fallback-summary.js','claim-value.js','display-name.js','strings/terms.js']
modules_verified=[]
for name in modules:
    rel='chicago/4d/renderers/web/js/'+name;b=prior(BASE,rel);a=prior(TIP,rel);assert a==b== (R/rel).read_bytes(),rel
    modules_verified.append({'path':rel,'sha256':sha(a),'byte_exact_old_UI_to_current':True})
css=g('diff','--name-only',BASE,TIP,'--','chicago/4d/renderers/web/css').decode().splitlines();assert not css
mainrel='chicago/4d/renderers/web/js/main.js';old=prior(BASE,mainrel).decode();new=prior(TIP,mainrel).decode()
spans=[('typed_structure_pick','  function pick(target) {','\n  /** Water-anchored'),('popup_onShow_and_onShown','  const popup = createPopup(popupRoot, {','\n  let cardTookPointer'),('reader_lazy_load','  let readerPromise = null;','\n  // The pictures of each building'),('pictures_lazy_load','  let picturesPromise = null;','\n  // T-2638. The building summaries')]
api=[]
for name,start,end in spans:
    def take(text):
        a=text.index(start);b=text.index(end,a);return text[a:b]
    a=take(old);b=take(new);assert a==b,name
    api.append({'name':name,'byte_exact':True,'sha256':sha(a.encode())})
native=json.loads((P/'FIELD-AND-NATIVE-OWNER-AUDIT.json').read_bytes());assert native['base']==TIP and native['all_compiled_picture_scenes_semantically_exact']
assert native['native_phases'][0]['full_recipe']=='9ff0b1db8bc3101df763f4f1448df60d305188a23e7ff45a3490ed0e98ee53e1'
out={'status':'SCOPED_OLD_CARD_QA_REUSABLE_CURRENT_NATIVE_STAGE3_BOTH_STILL_REQUIRED','old_tested_base':BASE,'current_parent':TIP,'all9_own_paths_scoped_exact':paths,'card_modules_byte_exact':modules_verified,'card_css_changes':css,'main_js_actual_review':'Read every147added/35removed line. Changes add town transport/driver person routes, shared interaction engine and visible-time animation clock. Main typed string structure pick, popup onShow/Shown, Pictures and Reader lazy-load paths remain byte-exact. This is not a claim that the global runtime or incoming transport was browser-tested here.','main_card_API_spans_byte_exact':api,'main_before_sha256':sha(old.encode()),'main_current_sha256':sha(new.encode()),'own_native_inputs_and_actual_MASTER_WEB_exact':native,'actual_old_both_cards':'PASS/proper706.2seconds; Root direct review accepted newaddresslead/fullcredit with stickyheader and partialRecordcapture limits','root_review_receipt':'/workspace/lake-house-source-card-root-review-20261104/ROOT-CARDS-BOTH-REVIEW.json','current_published_nativeStage3_both107':'PENDING_NOT_RUN','full_source4':'PENDING_NOT_RUN','no_old_runtime_or_final_commit_UI_claim':True}
(P/'CURRENT-CARD-INPUT-BINDING.json').write_text(json.dumps(out,indent=2)+'\n')
print('Scopedcardreuse:7wholepaths+2exactowntails,8cardmodules+CSS+4mainAPIspans unchanged; CURRENTnativeStage3bothPENDING',flush=True)
