from pathlib import Path
import json,hashlib,subprocess,os
P=Path(__file__).parent;R=Path('/tmp/cobweb-active-20261103');E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def g(*args):return subprocess.check_output(['/usr/local/bin/git','-C',str(R),*args],env=E)
binding=json.loads((P/'CURRENT-CARD-INPUT-BINDING.json').read_bytes());assert binding['current_parent']==g('rev-parse','HEAD').decode().strip()
assert json.loads((P/'current-owners/OWNERS-PASS.json').read_bytes())['all_green']
assert not g('diff','--cached','--name-only')
paths=g('diff','--name-only').decode().splitlines()+['chicago/4d/changelog.d/T-2379.json'];assert len(paths)==9
expected={x['path'] for x in binding['all9_own_paths_scoped_exact']};assert set(paths)==expected
rows=[]
for rel in paths:
    body=(R/rel).read_bytes();sha=hashlib.sha256(body).hexdigest();oid=g('hash-object',rel).decode().strip()
    existing=subprocess.run(['/usr/local/bin/git','-C',str(R),'cat-file','-e',oid],env=E,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
    if not existing:assert g('hash-object','-w',rel).decode().strip()==oid
    g('update-index','--add','--cacheinfo','100644',oid,rel);rows.append({'path':rel,'blob':oid,'sha256':sha,'bytes':len(body),'existing_object':existing})
g('update-index','--refresh','--',*paths);assert not g('diff','--name-only')
data={'status':'EXACT9_STAGED_NOT_QUALIFIED_COMMIT','parent':binding['current_parent'],'tree':g('write-tree').decode().strip(),'paths':rows,'cards_both':'PASS/scopedbindingcurrent','source4':'PENDING','current_nativeStage3both':'PENDING','no_broad_add_or_existing_pack_freshening':True}
(P/'CURRENT-EXACT-INDEX-STAGED.json').write_text(json.dumps(data,indent=2)+'\n');print('Staged exact9/currentparent; source4 andcurrentnative3pending, noappcommit',flush=True)
