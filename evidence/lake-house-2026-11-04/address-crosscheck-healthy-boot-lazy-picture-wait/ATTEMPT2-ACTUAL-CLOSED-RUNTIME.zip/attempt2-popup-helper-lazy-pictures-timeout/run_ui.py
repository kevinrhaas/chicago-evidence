"""Actual immutable working-source UI; bind these tested bytes to the later commit."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,time,stat
P=Path(__file__).parent;R=Path('/tmp/cobweb-active-20261103');A=R/'chicago/4d';S=R/'site/4d';O=P/'custom';K=P/'native3';E=dict(os.environ)
for key in ['GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','CHICAGO_TICKETS_DIR']:E.pop(key,None)
for key in list(E):
    if key.startswith('SMOKE_'):E.pop(key)
E.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PLAYWRIGHT_DISABLE_FORCED_CHROMIUM_PROXIED_LOOPBACK='1')
sha=lambda b:hashlib.sha256(b).hexdigest()
pf=lambda p:sha(Path(p).read_bytes())
canonical=lambda d:(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n').encode()
def g(*args):return subprocess.check_output(['/usr/local/bin/git','-C',str(R),*args],env=E)
def dump(p,d):Path(p).write_text(json.dumps(d,indent=2)+'\n')
def floor():
    d={p:shutil.disk_usage(p).free for p in ['/workspace','/tmp']};assert d['/workspace']>=536870912 and d['/tmp']>=1800000000,d;return d
def sourceguard():
    paths=g('diff','--name-only').decode().splitlines()+['chicago/4d/changelog.d/T-2379.json']
    return {'head':g('rev-parse','HEAD').decode().strip(),'index_tree':g('write-tree').decode().strip(),'diff_sha256':sha(g('diff','--binary')),'cached_sha256':sha(g('diff','--cached','--binary')),'working_paths':{r:pf(R/r)for r in paths},'untracked':g('ls-files','--others','--exclude-standard').decode()}
def pubmap():return {p.relative_to(S).as_posix():{'bytes':p.stat().st_size,'sha256':pf(p)}for p in sorted(S.rglob('*'))if p.is_file()}
def bindings():
    files=set()
    for root in [A/'renderers/web',S/'walk']:
        for ext in ['*.js','*.mjs','*.css','*.html']:files.update(root.rglob(ext))
    files.update([S/'data/reader/structures_1835.json',A/'tools/smoke_renderer.mjs',A/'tools/compile_pictures.py',A/'tools/grade_structures.py',A/'data/structure_grades.json',A/'data/pictures/1835.json',S/'data/pictures/1835.json',A/'assets/manifest.json',A/'assets/manifest.web.json',A/'assets/manifest.versions.json',A/'assets/gltf/lake_house_construction__shell_1835.glb',A/'assets/web/lake_house_construction__shell_1835.glb',S/'data/gltf/lake_house_construction__shell_1835.glb'])
    for rel in ['data/sidecars/1835/lake_house_construction.json','data/sources/fergus_chicago_directory_1839.json','data/structures/lake_house_construction.json','docs/RESEARCH/lake_house_construction.md','data/sources/kellogg_blanchard_1856_old_fort_lake_house.json']:files.add(A/rel)
    files.update([S/'data/sidecars/1835/lake_house_construction.json',P/'probe.mjs'])
    return {str(p):{'bytes':p.stat().st_size,'sha256':pf(p)}for p in sorted(files)}
assert json.loads((P/'PUBLISH-MIRROR-REAPER.json').read_bytes())['command_exit']==0
assert json.loads((P/'FIELD-AND-NATIVE-OWNER-AUDIT.json').read_bytes())['all_compiled_picture_scenes_semantically_exact']
before_source=sourceguard();assert len(before_source['working_paths'])==9
before_pub=pubmap();assert len(before_pub)>5000
before_inputs=bindings();helpers={x:pf(P/x)for x in ['run_ui.py','probe.mjs']}
rows=json.loads((S/'data/pictures/1835.json').read_bytes())['by_structure']['lake_house_construction'];assert len(rows)==1 and not rows[0].get('spot')and not rows[0].get('held')
sc=json.loads((S/'data/sidecars/1835/lake_house_construction.json').read_bytes());assert sc['grade']['value']=='inferred'and sc['phase']=='shell_1835'and sc['target_date']=='1835-07-01'
assert sc==json.loads((A/'data/sidecars/1835/lake_house_construction.json').read_bytes())
reader=json.loads(subprocess.check_output(['node','--input-type=module','-e',"import fs from'node:fs';import{pathToFileURL}from'node:url';const r=process.argv[1];const{readerCopy}=await import(pathToFileURL(r+'/walk/js/reader-text.js'));console.log(JSON.stringify(readerCopy(JSON.parse(fs.readFileSync(r+'/data/sidecars/1835/lake_house_construction.json')),JSON.parse(fs.readFileSync(r+'/data/reader/structures_1835.json'))).research_note));",str(S)],env=E))
assert 'LATER ADDRESS CHECK:'in reader
scratch=P/'ui-scratch';scratch.mkdir(exist_ok=True)
plan={'expected_head':before_source['head'],'tested_state':'FROZEN_UNCOMMITTED_WORKING_SOURCE_NOT_FINAL_COMMIT','expected_lake_pictures':rows,'picture_source_id':rows[0]['id'],'expected_research_note':reader,'expected_function_value':sc['attributes']['function']['value'],'expected_phase':sc['phase'],'expected_target':sc['target_date'],'input_bindings':before_inputs,'source_scope_sha256':sha(canonical(before_inputs)),'source_guard':before_source,'site_parent':str(R/'site'),'full_publication_map_sha256':sha(canonical(before_pub)),'full_publication_members':len(before_pub),'scope':'Actual later-address Record, joined1876/1839Source and originalImages1link/0held/0Spot/inferred; officialnativeStage3both107; originalOPENpartial. No geometryororiginalmatch claim.'}
dump(P/'UI-PLAN.json',plan);dump(P/'UI-BEFORE-PUBMAP.json',before_pub);plan_sha=pf(P/'UI-PLAN.json')
def guard():
    assert sourceguard()==before_source,'source drift';assert bindings()==before_inputs,'input drift';assert pubmap()==before_pub,'publication drift';assert{n:pf(P/n)for n in helpers}==helpers and pf(P/'UI-PLAN.json')==plan_sha;floor()
def command(cmd,env,rec,log):
    with log.open('xb')as f:r=subprocess.run(['python','/workspace/shared/run-with-reaping.py',str(rec),'--','timeout','--signal=TERM','--kill-after=15s','600s','nice','-n','19','taskset','-c','0-4',*cmd],cwd=A,env=env,stdout=f,stderr=subprocess.STDOUT)
    rr=json.loads(rec.read_bytes());assert r.returncode==rr['command_exit']==0 and rr['all_children_reaped']and not rr['leftover_cleanup']and rr['interrupted_signal']is None,(r.returncode,rr,str(log));return rr
O.mkdir();K.mkdir();steps=[];native=[];error=None;started=time.monotonic()
env=dict(E,TMPDIR=str(scratch),TMP=str(scratch),TEMP=str(scratch),NODE_COMPILE_CACHE=str(scratch/'node-cache'))
try:
    for viewport in ['desktop','mobile']:
        guard();t=time.monotonic();ve=dict(env,GT_PROBE_PLAN=str(P/'UI-PLAN.json'),GT_PROBE_OUT=str(O/viewport),GT_PROBE_VIEWPORT=viewport)
        rr=command(['node',str(P/'probe.mjs')],ve,O/(viewport+'-REAPER.json'),O/(viewport+'.log'))
        result=json.loads((O/viewport/'RESULT.json').read_bytes());assert result['status']=='ACTUAL_LAKE_ADDRESS_SOURCES_RECORD_IMAGES_PASS';guard()
        steps.append({'viewport':viewport,'seconds':time.monotonic()-t,'reaper':rr,'status':result['status']});dump(O/'STEPS.json',steps);print(json.dumps({'custom_closed':viewport,'seconds':steps[-1]['seconds']}),flush=True)
    for viewport in ['mobile','desktop']:
        guard();t=time.monotonic();ve=dict(env,SMOKE_VIEWPORT=viewport,SMOKE_STAGE='3',SMOKE_ROOT=str(S),SMOKE_SHOTS=str(K/(viewport+'-shots')))
        rr=command(['node','tools/smoke_renderer.mjs','--published'],ve,K/(viewport+'-REAPER.json'),K/(viewport+'.log'))
        text=(K/(viewport+'.log')).read_text(errors='replace');counts=re.findall(r'(\d+) passed, (\d+) failed',text);assert counts and counts[-1]==('107','0')and'SMOKE PASS'in text;guard()
        native.append({'viewport':viewport,'seconds':time.monotonic()-t,'passed':107,'failed':0,'reaper':rr});dump(K/'PROGRESS.json',native);print(json.dumps({'native_closed':viewport,'seconds':native[-1]['seconds']}),flush=True)
except BaseException as exc:error=repr(exc);dump(P/'UI-FAILURE.json',{'error':error,'custom':steps,'native':native});print(error,flush=True)
finally:
    try:guard();exact=True
    except BaseException as exc:exact=False;error=(error+'; 'if error else'')+'Finalguard:'+repr(exc)
    closure={'status':'LAKE_ADDRESS_WORKING_SOURCE_CUSTOM_NATIVE3_BOTH_PASS'if error is None and len(steps)==len(native)==2 else'NOT_QUALIFIED','source':before_source,'custom':steps,'native':native,'all_source_publication_helpers_exact':exact,'tested_inputs_sha256':sha(canonical(before_inputs)),'full_publication_map_sha256':sha(canonical(before_pub)),'full_publication_members':len(before_pub),'error':error,'seconds':time.monotonic()-started,'resources':floor()}
    dump(P/'UI-CLOSURE.json',closure);print(json.dumps({'final_status':closure['status'],'error':error}),flush=True)
raise SystemExit(1 if error else 0)
