from pathlib import Path
import subprocess,json,os,hashlib,time
Q=Path(__file__).parent;P=Q.parent;R=Path('/tmp/cobweb-active-20261103');A=R/'chicago/4d';E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1');O='73d4d727002f14eaa3263f4c4d3fcfdd099fbad6';D='19910ff1701093c0c1eb8d4407fa3b8ad34ad32d'
def g(*a):return subprocess.check_output(['git','-C',str(R),*a],env=E)
def run(label,cmd,cwd=A):
 rec=Q/(label+'-REAPER.json')
 with(Q/(label+'.log')).open('xb')as f:r=subprocess.run(['python','/workspace/shared/run-with-reaping.py',str(rec),'--','timeout','--signal=TERM','--kill-after=15s','600s',*cmd],cwd=cwd,env=E,stdout=f,stderr=subprocess.STDOUT)
 rr=json.loads(rec.read_bytes());assert r.returncode==rr['command_exit']==0 and rr['all_children_reaped'] and not rr['leftover_cleanup'] and rr['interrupted_signal']is None,label
assert json.loads((Q/'OWNERS-OUTER-REAPER.json').read_bytes())['command_exit']==0
assert json.loads((Q/'OWN-AND-FOREIGN-AUDIT.json').read_bytes())['status']=='OWN10_AND_FULL_FOREIGN1991_PRESERVATION_WITH_EXPLICIT_PEER_INTEGRATION_LIMITS'
assert g('rev-parse','HEAD').decode().strip()==O and g('rev-parse','MERGE_HEAD').decode().strip()==D
for rel in ['chicago/4d/data/sidecars/1835/sources/index.json','chicago/4d/docs/STATUS.md']:
 oid=g('hash-object',rel).decode().strip()
 r=subprocess.run(['git','-C',str(R),'cat-file','-e',oid],env=E,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 if r.returncode:assert g('hash-object','-w',rel).decode().strip()==oid
 g('update-index','--add','--cacheinfo','100644',oid,rel);g('update-index','--refresh','--',rel)
assert not g('ls-files','-u') and not g('diff','--name-only')
paths=g('diff','--cached','--name-only',D).decode().splitlines();expected=json.loads((P/'integrate22/COMMIT.json').read_bytes())['paths'];assert paths==expected and len(paths)==10
T=g('write-tree').decode().strip()
qualification={'tree':T,'head_before_commit':O,'incoming':D,'source_gate_sequence':'Actual previous73 wholeeight+aggregate PASS. Current normal merge1991 with fresh native scene/SourceUse/Pictures/grade/lot/trade/validation/changelog/derived owners and own10/foreignpostimage exactscope proof. Root explicitly authorizes bounded foreign integration with honest peer runtime/geometry limits; final current head wholeeight required before merge.','all4_executed_on_newtree':False,'native107both_actual_head':'c6474f511c4e76db329d9bc4c3bf373e5104b08d','native_foreign_integration_limit':'See OWN-AND-FOREIGN-AUDIT.json; no byteexactfullruntime/world claim across1991','final_exact_head_whole8':'PENDING'}
(Q/'PRECOMMIT-QUALIFICATION.json').write_text(json.dumps(qualification,indent=2)+'\n')
(Q/'MESSAGE.txt').write_text('Merge current dev into T-2379 later-address cross-check\n\nPreserve peer runtime, Sauganash cornice and source accounting; regenerate the combined source index.\nLake House inputs, geometry and visitor card content remain exact.\n')
run('COMMIT',['git','commit','-F',str(Q/'MESSAGE.txt')],R)
H=g('rev-parse','HEAD').decode().strip();assert g('rev-parse','HEAD^{tree}').decode().strip()==T and g('show','-s','--format=%P',H).decode().split()==[O,D] and not g('status','--porcelain')
(Q/'COMMIT.json').write_text(json.dumps({'head':H,'tree':T,'parents':[O,D],'incoming':D,'paths':paths,'whole8_required_before_merge':True,'native_actual_at':'c6474f511c4e76db329d9bc4c3bf373e5104b08d','foreign_runtime_geometry_limits_explicit':True},indent=2)+'\n')
run('PR-CHANGELOG',['node','tools/check-changelog-entry.mjs',D,H]);run('PR-IDS',['node','tools/resolve_id_collisions.mjs','--check','--base',D])
(Q/'PR-QUESTIONS-PASS.json').write_text(json.dumps({'head':H,'tree':T,'base':D,'actual_commit_changelog_and_ID_questions':'PASS'},indent=2)+'\n');print(H,T,flush=True)
