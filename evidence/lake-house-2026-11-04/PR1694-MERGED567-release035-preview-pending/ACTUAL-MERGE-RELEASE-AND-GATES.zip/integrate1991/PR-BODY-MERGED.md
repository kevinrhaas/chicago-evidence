Merged to dev as **5673cb959526cd6080c7ecfceb039fcb1b2c5e73**, with exact qualified tree4efd0688 delivered and parent1991 verified.

The Lake House Record now quotes a directly checked Hotels entry in Fergus's 1876 recollection of 1839: Rush and North Water. The credited source and the Record retain Andreas's conflicting address and state that this later listing does not establish the July 1835 construction stage or position. T-2379 remains open for its original image match.

Validation:

- Actual published native Stage 3: 107 passed, zero failed at both viewports on c647 (mobile 167.1 s; desktop 340.4 s), zero errors, proper process closure. Actual Record, Sources and Images review passed at both viewports, with the reviewer's documented capture limits.
- Lake House recipe, geometry, grades, Images and own card/source fields remain unchanged through the normal integrations. The old native execution has an exact scope binding through 73d4; it is not reported as an execution on later heads.
- Complete hosted eight-part gate plus named aggregate passed on 73d4. Normal integration of dev1991 produced current1cc. Eleven current native/source owners, actual PR changelog and ticket-ID questions pass. The complete current-head gate **41769800573 passed all eight named parts and the aggregate gate before merge**. Local four-part checks were not all re-executed on this final integration tree.
- Peer tree-instancing/blended-cell renderer work and the Sauganash cornice/1835 source accounting differ from the old native world. No byte-exact full-runtime/all-1835-geometry claim is made across those peer changes. Their complete postimages are preserved, alongside this ten-path documentary increment; own Lake House card, SourceUse and asset bindings are exact.

[Actual cards and capture limits](https://github.com/kevinrhaas/chicago-evidence/blob/b3fed6c3d26c724285af01916632853cec998a37/evidence/lake-house-2026-11-04/address-crosscheck-actual-cards-both-0200/RECOVERY.md) · [Actual native both and earlier integration audit](https://github.com/kevinrhaas/chicago-evidence/blob/1c689a7b889216ed37c48ec35f3d1b71cf878758/evidence/lake-house-2026-11-04/PR1694-native-both-integrated73d4/RECOVERY.md).
