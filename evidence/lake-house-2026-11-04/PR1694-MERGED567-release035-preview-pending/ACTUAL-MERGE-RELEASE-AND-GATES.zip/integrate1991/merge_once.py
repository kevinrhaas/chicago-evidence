"""Ordinary SHA-guarded squash merge only after exact named whole eight-part gate."""
from pathlib import Path
import subprocess,json,time
Q=Path(__file__).parent;H='1ccfc5d26e447605ed688edd6bcff9f9781bdd83';D='19910ff1701093c0c1eb8d4407fa3b8ad34ad32d';T='4efd06882c2abb364e810dd6b542eaf47c995a36'
def api(p,body=None,method=None):
 cmd=['gh','api','-H','Cache-Control: no-cache','repos/kevinrhaas/chicago/'+p]
 if body is not None:cmd+=['--method',method or'POST','--input','-']
 r=subprocess.run(cmd,input=None if body is None else json.dumps(body).encode(),capture_output=True,timeout=45);assert r.returncode==0,(p,r.stderr.decode());return json.loads(r.stdout)
p=api('pulls/1694?_='+str(time.time_ns()));assert p['state']=='open'and not p['draft']and p['head']['sha']==H and p['base']['ref']=='dev'and p['mergeable']is True and p['mergeable_state']=='clean',p
assert api('git/ref/heads/dev?_='+str(time.time_ns()))['object']['sha']==D,'Dev advanced; inspect and integrate before retry'
run=api('actions/runs/41769800573');assert run['head_sha']==H and run['status']=='completed'and run['conclusion']=='success',('Exact fullgate not green',run['status'],run['conclusion'])
jobs=api('actions/runs/41769800573/jobs?per_page=100')['jobs'];names={f'gate part {i}/8'for i in range(1,9)}|{'gate'}
assert names<={j['name']for j in jobs if j['status']=='completed'and j['conclusion']=='success'},[(j['name'],j['status'],j['conclusion'])for j in jobs]
checks=api('commits/'+H+'/check-runs?per_page=100')['check_runs'];assert names<={j['name']for j in checks if j['head_sha']==H and j['status']=='completed'and j['conclusion']=='success'}
assert not any(j['status']!='completed'or j['conclusion']not in ['success','neutral','skipped']for j in checks),[(j['name'],j['status'],j['conclusion'])for j in checks]
binding=json.loads((Q/'OWN-AND-FOREIGN-AUDIT.json').read_bytes());assert binding['incoming']==D and binding['status']=='OWN10_AND_FULL_FOREIGN1991_PRESERVATION_WITH_EXPLICIT_PEER_INTEGRATION_LIMITS'
(Q/'PREMERGE-EXACT-CHECKS.json').write_text(json.dumps({'head':H,'base':D,'run':run,'jobs':jobs,'checks':checks},indent=2)+'\n')
m=api('pulls/1694/merge',{'sha':H,'merge_method':'squash','commit_title':'T-2379: Surface a checked later Lake House address'},'PUT');assert m['merged']is True,m;(Q/'MERGE.json').write_text(json.dumps(m,indent=2)+'\n')
c=api('git/commits/'+m['sha']);assert c['tree']['sha']==T and[c['sha']for c in c['parents']]==[D],c
p=api('pulls/1694');assert p['merged']and p['merge_commit_sha']==m['sha']and p['state']=='closed'
(Q/'MERGED-DELIVERY.json').write_text(json.dumps({'merge':m,'commit':c,'PR':p,'exact_feature_tree_delivered_to_dev':T,'normal_protected_merge':True,'original_ticket_must_remain_OPEN_PARTIAL':True},indent=2)+'\n');print(json.dumps({'merged':m['sha'],'tree':T,'exact_whole8':run['id']}),flush=True)
