"""Publish the exact qualified native commit on its new feature branch only."""
from pathlib import Path
import subprocess,json,hashlib,base64,datetime,re,os
P=Path(__file__).parent;R=Path('/tmp/cobweb-active-20261103');E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
C=json.loads((P/'COMMIT.json').read_bytes());H=C['head'];T=C['tree'];B='steward/t2379-later-address-crosscheck-20261104'
assert json.loads((P/'PR-QUESTIONS-PASS.json').read_bytes())['head']==H
def g(*args):return subprocess.check_output(['/usr/local/bin/git','-C',str(R),*args],env=E)
def api(path,data=None,method=None):
    cmd=['gh','api','repos/kevinrhaas/chicago/'+path]
    if data is not None:cmd+=['--method',method or'POST','--input','-']
    r=subprocess.run(cmd,input=None if data is None else json.dumps(data).encode(),capture_output=True,timeout=45)
    if r.returncode:raise RuntimeError((path,r.stderr.decode()[:1000]))
    return json.loads(r.stdout)
raw=g('cat-file','commit',H);assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==H
headers,message=raw.split(b'\n\n',1);lines=headers.decode().splitlines();fields=dict(l.split(' ',1)for l in lines if not l.startswith('parent '));parents=[l.split(' ',1)[1]for l in lines if l.startswith('parent ')];assert fields['tree']==T and parents==C['parents']and set(fields)=={'tree','author','committer'}
def ident(text):
    m=re.fullmatch(r'(.*) <([^<>]+)> (\d+) ([+-])(\d{2})(\d{2})',text);assert m
    minutes=(int(m[5])*60+int(m[6]))*(1 if m[4]=='+'else-1);date=datetime.datetime.fromtimestamp(int(m[3]),datetime.timezone(datetime.timedelta(minutes=minutes))).isoformat()
    return{'name':m[1],'email':m[2],'date':date}
entries=[];blobs=[]
for path in C['paths']:
    body=g('show',H+':'+path);oid=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest();assert g('rev-parse',H+':'+path).decode().strip()==oid
    row=api('git/blobs',{'encoding':'base64','content':base64.b64encode(body).decode()});assert row['sha']==oid and base64.b64decode(api('git/blobs/'+oid)['content'])==body
    entries.append({'path':path,'mode':'100644','type':'blob','sha':oid});blobs.append({'path':path,'oid':oid,'sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body)})
tree=api('git/trees',{'base_tree':g('rev-parse',C['incoming']+'^{tree}').decode().strip(),'tree':entries});assert tree['sha']==T
commit=api('git/commits',{'tree':T,'parents':parents,'message':message.decode(),'author':ident(fields['author']),'committer':ident(fields['committer'])});assert commit['sha']==H
read=subprocess.run(['gh','api','repos/kevinrhaas/chicago/git/ref/heads/'+B],capture_output=True,timeout=45)
if read.returncode==0:
    existing=json.loads(read.stdout)['object']['sha'];assert existing==parents[0],'Unexpected existing branch owner; never force/overwrite'; row=api('git/refs/heads/'+B,{'sha':H,'force':False},'PATCH'); assert row['object']['sha']==H
else:
    assert '404'in read.stderr.decode(),read.stderr.decode();row=api('git/refs',{'ref':'refs/heads/'+B,'sha':H});assert row['object']['sha']==H
assert api('git/ref/heads/'+B)['object']['sha']==H
(P/'PUSH.json').write_text(json.dumps({'head':H,'tree':T,'parents':parents,'branch':B,'exact_native_commit_tree_and_server_blobs':True,'normal_new_feature_ref_only':True,'no_force_no_appdev_main_write':True,'blobs':blobs},indent=2)+'\n')
print(json.dumps({'pushed_exact_head':H,'branch':B,'readbacks':'PASS'}),flush=True)
