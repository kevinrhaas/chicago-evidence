from pathlib import Path
import subprocess,json,os,base64,concurrent.futures,hashlib,shutil
P=Path(__file__).parent;O=P/'objects';O.mkdir(exist_ok=True);R=Path('/tmp/cobweb-active-20261103');B='22d624f3e5061dfaf54af0e3429e6278be60abe3';H='19910ff1701093c0c1eb8d4407fa3b8ad34ad32d';E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',GIT_ALTERNATE_OBJECT_DIRECTORIES=str(O))
def api(path):
 r=subprocess.run(['gh','api','-H','Cache-Control: no-cache','repos/kevinrhaas/chicago/'+path],capture_output=True,timeout=45);assert r.returncode==0,r.stderr;return json.loads(r.stdout)
ns={'__file__':'/workspace/cobweb-resume-recovery-20261103/adopt_latest.py'};exec(Path(ns['__file__']).read_text().split('comparison =')[0],ns);ns.update(P=P,O=O,api=api)
comp=api('compare/'+B+'...'+H);assert comp['ahead_by']==5 and comp['behind_by']==0 and len(comp['commits'])==5;(P/'COMPARE.json').write_text(json.dumps(comp))
commits=[];files={}
for row in comp['commits']:
 d=ns['commit'](row['sha']);commits.append(d);print('commit',row['sha'],flush=True)
 root=d['tree']['sha'];tree=api('git/trees/'+root+'?recursive=1');assert not tree['truncated'];dirs={'':{}};ids={'':root};fs={}
 for e in tree['tree']:
  parent,_,name=e['path'].rpartition('/');dirs.setdefault(parent,{})[name]=e
  if e['type']=='tree':dirs.setdefault(e['path'],{});ids[e['path']]=e['sha']
  else:fs[e['path']]=e
 for p,children in dirs.items():
  raw=b''.join(e['mode'].lstrip('0').encode()+b' '+name.encode()+b'\0'+bytes.fromhex(e['sha'])for name,e in sorted(children.items(),key=lambda x:(x[0]+('/'if x[1]['type']=='tree'else'')).encode()));ns['put']('tree',raw,ids[p])
 files[d['sha']]=fs
fs=files[H];(P/'FILES.json').write_text(json.dumps(fs));ids=sorted({r['sha']for r in fs.values()});rows=subprocess.check_output(['git','-C',str(R),'cat-file','--batch-check'],input=('\n'.join(ids)+'\n').encode(),env=E).decode().splitlines();missing={line.split()[0]for line in rows if line.endswith(' missing')};by={r['sha']:r for r in fs.values()};assert len(missing)<100 and sum(by[s]['size']for s in missing)<128*1024**2 and all(by[s]['size']<32*1024**2 for s in missing)
assert shutil.disk_usage('/workspace').free>536870912 and shutil.disk_usage('/tmp').free>1800000000
print('Missing tip blobs',len(missing),sum(by[s]['size']for s in missing),flush=True)
def fetch(s):
 d=api('git/blobs/'+s);raw=base64.b64decode(d['content']);assert len(raw)==by[s]['size'];ns['put']('blob',raw,s);return dict(path=by[s]['path'],sha=s,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
blobrows=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=6)as pool:
 for r in pool.map(fetch,sorted(missing)):blobrows.append(r);print('blob',len(blobrows),r['path'],flush=True)
# Own N metadata only; never touch the borrowed R store or delete objects.
al=R/'.git/objects/info/alternates';before=al.read_bytes();line=(str(O)+'\n').encode();assert line not in before;al.write_bytes(before+line)
assert subprocess.check_output(['git','-C',str(R),'merge-base','73d4d727002f14eaa3263f4c4d3fcfdd099fbad6',H],env=E).decode().strip()==B
(P/'READY.json').write_text(json.dumps({'base':B,'tip':H,'tip_tree':commits[-1]['tree']['sha'],'all5commits_and_trees_rawIDs_verified':True,'all_tip_blobs_available':True,'fetched_blobs':blobrows,'no_source_or_ref_mutations':True,'N_only_alternates_append':str(O),'noGC_repack_delete':True},indent=2)+'\n');print('READY',H,flush=True)
