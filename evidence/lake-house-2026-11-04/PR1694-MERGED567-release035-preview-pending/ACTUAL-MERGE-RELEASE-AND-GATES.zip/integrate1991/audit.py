from pathlib import Path
import subprocess,os,json,hashlib,sys
Q=Path(__file__).parent;P=Q.parent;R=Path('/tmp/cobweb-active-20261103');A=R/'chicago/4d';O='73d4d727002f14eaa3263f4c4d3fcfdd099fbad6';D='19910ff1701093c0c1eb8d4407fa3b8ad34ad32d';B='22d624f3e5061dfaf54af0e3429e6278be60abe3';E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def g(*a):return subprocess.check_output(['git','-C',str(R),*a],env=E)
def b(h,p):return g('show',h+':'+p)
def j(h,p):return json.loads(b(h,p))
assert json.loads((P/'integrate22/hosted-watch/CLOSED.json').read_bytes())['latest']['whole8_green']
assert g('rev-parse','HEAD').decode().strip()==O and g('rev-parse','MERGE_HEAD').decode().strip()==D
own=json.loads((P/'integrate22/COMMIT.json').read_bytes())['paths'];incoming=g('diff','--name-only',B,D).decode().splitlines();shared=set(incoming)&set(own);assert shared=={'chicago/4d/data/sidecars/1835/sources/index.json','chicago/4d/docs/STATUS.md'}
foreign=[]
for p in incoming:
 if p in shared:continue
 try:raw=b(D,p)
 except subprocess.CalledProcessError:assert not(R/p).exists();continue
 assert (R/p).read_bytes()==raw,('Foreign postimage lost',p);foreign.append(p)
for p in own:
 if p in shared:continue
 assert (R/p).read_bytes()==b(O,p),('Own postimage changed',p)
owned=json.loads((P/'OWNED-DELTAS.json').read_bytes())
for rel in ['docs/STATUS.md','docs/ROADMAP.md']:
 before=b(D,'chicago/4d/'+rel);tail=owned['raw_document_appends'][rel]['tail'].encode();assert (A/rel).read_bytes()==before+tail,rel
by=lambda x:{r['source_id']:r for r in x['sources']}
p='chicago/4d/data/sidecars/1835/sources/index.json';c=by(json.loads((R/p).read_bytes()));o=by(j(O,p));d=by(j(D,p));assert c.keys()==o.keys()==d.keys()
for k,v in c.items():assert v==(o[k]if k=='fergus_chicago_directory_1839'else d[k]),k
for p in ['assets/gltf/lake_house_construction__shell_1835.glb','assets/web/lake_house_construction__shell_1835.glb','assets/manifest.versions.json']:
 if p.endswith('versions.json'):assert j(O,'chicago/4d/'+p)['assets'].get('lake_house_construction')==json.loads((A/p).read_bytes())['assets'].get('lake_house_construction')
 else:assert(A/p).read_bytes()==b(O,'chicago/4d/'+p)
for p in g('ls-tree','-r','--name-only',O,'chicago/4d/data/pictures').decode().splitlines():assert(R/p).read_bytes()==b(O,p),p
sys.path[:0]=[str(A/'generators'),str(A/'tools')];import mesh_inputs
s=json.loads((A/'data/structures/lake_house_construction.json').read_bytes());recipes=[mesh_inputs.structure_inputs_sha(s,p)for p in s['phases']];assert recipes==['9ff0b1db8bc3101df763f4f1448df60d305188a23e7ff45a3490ed0e98ee53e1']
rt=[p for p in incoming if'/renderers/web/'in p];active=[p for p in incoming if'/assets/web/'in p or'/sidecars/1835/'in p]
out={'status':'OWN10_AND_FULL_FOREIGN1991_PRESERVATION_WITH_EXPLICIT_PEER_INTEGRATION_LIMITS','actual_old_whole8_execution_head':O,'actual_native107both_execution_head':'c6474f511c4e76db329d9bc4c3bf373e5104b08d','native_execution_on_newtree':False,'incoming':D,'all_foreign_nonshared_postimages_exact':foreign,'all_own_nonshared_postimages_exact':True,'raw_incoming_doc_prefixes_plus_owned_tails_exact':True,'Sourceindex_ownFergus_row_and_all_foreignrows_exact':True,'Lake_recipe':recipes,'Lake_MASTER_WEB_and_Pictures_byte_exact':True,'foreign_runtime_paths':rt,'foreign_asset_and1835_sidecar_paths':active,'limits':'PeerT3363 grown-tree instancing/blended-cell ordering and peerSauganash1835cornice/SourceUse differ from old runtime/activeworld. Do NOT claim full runtime/all1835byteexact or nativeexecution onnewhead. OwnLakeSourceUse/card/assetbindings exact. Root explicitly accepts ordinary bounded foreignintegration with freshowners and currentexactheadwhole8 mandatory, without repeatingfullUI solelyfor peer changes.','new_final_actual_whole8':'PENDING'}
(Q/'OWN-AND-FOREIGN-AUDIT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'own10':'PASS','foreign_exact':len(foreign),'peer_runtime_paths':len(rt),'native_recipe':recipes}),flush=True)
