from pathlib import Path
import subprocess,os,json,time
Q=Path(__file__).parent;A=Path('/tmp/cobweb-active-20261103/chicago/4d');E=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
commands=[('SCENE',['python','tools/compile_scene.py','--all']),('SOURCES',['python','tools/compile_source_use.py']),('SOURCES-CHECK',['python','tools/compile_source_use.py','--check']),('PICTURES',['python','tools/compile_pictures.py','--check']),('GRADE',['python','tools/grade_structures.py','--check']),('LOT',['python','tools/generate_lot_building_material.py','--check']),('TRADE',['python','tools/generate_trade_yards.py','--check']),('VALIDATE',['python','tools/validate.py','--all']),('CHANGELOG',['node','tools/check-changelog.mjs']),('ENTRIES',['node','tools/changelog-entries.mjs','--check']),('DERIVED',['node','tools/rederive.mjs','--check'])]
rows=[]
for label,cmd in commands:
 t=time.monotonic();rec=Q/(label+'-REAPER.json')
 with (Q/(label+'.log')).open('xb') as f:r=subprocess.run(['python','/workspace/shared/run-with-reaping.py',str(rec),'--','timeout','--signal=TERM','--kill-after=15s','600s','nice','-n','19','taskset','-c','2',*cmd],cwd=A,env=E,stdout=f,stderr=subprocess.STDOUT)
 rr=json.loads(rec.read_bytes());rows.append(dict(label=label,command=cmd,seconds=time.monotonic()-t,reaper=rr));(Q/'PROGRESS.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,r.returncode,flush=True)
 assert r.returncode==rr['command_exit']==0 and rr['all_children_reaped'] and not rr['leftover_cleanup'] and rr['interrupted_signal']is None,label
(Q/'OWNERS-PASS.json').write_text(json.dumps(rows,indent=2)+'\n')
