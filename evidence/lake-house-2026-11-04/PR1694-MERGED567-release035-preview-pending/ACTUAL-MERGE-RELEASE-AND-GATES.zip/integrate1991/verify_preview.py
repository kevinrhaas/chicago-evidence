from pathlib import Path
import urllib.request,json,time,hashlib,subprocess
Q=Path(__file__).parent;A=Path('/tmp/cobweb-active-20261103/chicago/4d');M='5673cb959526cd6080c7ecfceb039fcb1b2c5e73';checks=['data/sidecars/1835/lake_house_construction.json','data/sidecars/1835/sources/fergus_chicago_directory_1839.json'];expected={p:json.loads((A/p).read_bytes())for p in checks};history=[];t=time.monotonic()
def get(p):
 url='https://chicago.polecat.live/4d/dev/'+p+'?_='+str(time.time_ns());req=urllib.request.Request(url,headers={'Cache-Control':'no-cache','User-Agent':'Chicago-source-delivery-check'})
 with urllib.request.urlopen(req,timeout=15)as r:b=r.read();return json.loads(b),hashlib.sha256(b).hexdigest()
while time.monotonic()-t<300:
 row={'unix':time.time(),'own_merged':M}
 try:
  b,bsha=get('build.json');row['build']=b;rows=[]
  for p in checks:
   d,h=get(p);rows.append({'path':p,'exact_expected_JSON':d==expected[p],'sha256':h})
  row['paths']=rows;row['both_exact']=all(r['exact_expected_JSON']for r in rows)
  if row['both_exact']:
   r=subprocess.run(['gh','api','repos/kevinrhaas/chicago/compare/'+M+'...'+b['sha']],capture_output=True,timeout=45);assert r.returncode==0,r.stderr;d=json.loads(r.stdout);assert d['behind_by']==0;row['preview_at_merge_or_descendant']=True;row['comparison_status']=d['status'];(Q/'PREVIEW-DELIVERY-PASS.json').write_text(json.dumps(row,indent=2)+'\n')
 except Exception as e:row['read_error']=repr(e)
 history.append(row);(Q/'PREVIEW-DELIVERY-HISTORY.json').write_text(json.dumps(history,indent=2)+'\n');print(json.dumps(row),flush=True)
 if row.get('preview_at_merge_or_descendant'):break
 time.sleep(15)
(Q/'PREVIEW-DELIVERY-CLOSED.json').write_text(json.dumps({'status':'PASS'if history[-1].get('preview_at_merge_or_descendant')else'PREVIEW_PENDING','source_dev_merge_verified':True,'samples':len(history),'latest':history[-1]},indent=2)+'\n')
