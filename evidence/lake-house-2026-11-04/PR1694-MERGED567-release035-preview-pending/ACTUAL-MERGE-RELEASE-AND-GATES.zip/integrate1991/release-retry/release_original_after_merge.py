from pathlib import Path
import subprocess,json,os,base64,time
Q=Path(__file__).parent;N=Path('/tmp/cobweb-active-20261103/chicago/4d');K=Path('/tmp/lake-release-tickets-complete-20261104');rel='T-2250-2499/T-2379-match-the-lake-house-under-construction-to-its-p.md';E=dict(os.environ,CHICAGO_TICKETS_DIR=str(K),GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1')
for k in ['GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES']:E.pop(k,None)
def api(repo,path):
 r=subprocess.run(['gh','api','-H','Cache-Control: no-cache','repos/kevinrhaas/'+repo+'/'+path+('&'if'?'in path else'?')+'_='+str(time.time_ns())],capture_output=True,timeout=45);assert r.returncode==0,r.stderr;return json.loads(r.stdout)
def ticket():
 d=api('chicago-tickets','contents/'+rel+'?ref=main');b=base64.b64decode(d['content']);fields=dict(l.split(': ',1)for l in b.decode().split('---',2)[1].strip().splitlines());return d,b,fields
m=json.loads((Q.parent/'MERGED-DELIVERY.json').read_bytes());p=api('chicago','pulls/1694');assert p['merged']and p['merge_commit_sha']==m['merge']['sha']
d,b,f=ticket();assert f['state']=='claimed'and f['claimed_by']=='Codex Lake House bounded primary-source research 11/3/2026, 6:29:29 PM CT'and f['claimed_run']=='null'and f['pr']=='null',f
assert not subprocess.check_output(['git','-C',str(K),'status','--porcelain'],env=E)
(Q/'ORIGINAL-RELEASE-BEFORE.json').write_text(json.dumps({'git_blob':d['sha'],'frontmatter':f},indent=2)+'\n')
why='PR #1694 merged the directly checked later Lake House address and credited source as a documentary increment. The July 1835 construction-state image match remains OPEN/PARTIAL: later hotel imagery and the 1839 listing recalled in 1876 do not establish that construction stage or position. Native both-viewport and exact source/merge evidence: https://github.com/kevinrhaas/chicago-evidence/tree/main/evidence/lake-house-2026-11-04/PR1694-native-both-integrated73d4 . No completion or new follow-up ticket is claimed.'
rec=Q/'ORIGINAL-RELEASE-REAPER.json'
with(Q/'ORIGINAL-RELEASE.log').open('xb')as log:r=subprocess.run(['python','/workspace/shared/run-with-reaping.py',str(rec),'--','timeout','--signal=TERM','--kill-after=15s','600s','nice','-n','19','taskset','-c','2','node','tools/ticket.mjs','release','T-2379','--why',why],cwd=N,env=E,stdout=log,stderr=subprocess.STDOUT)
rr=json.loads(rec.read_bytes());assert r.returncode==rr['command_exit']==0 and rr['all_children_reaped']and not rr['leftover_cleanup']and rr['interrupted_signal']is None
_,b,f=ticket();assert f['state']=='open'and f['claimed_by']=='null'and f['claimed_run']=='null'and f['claimed_at']=='null'and f['pr']=='null'and f['closed_at']=='null'and why.encode()in b;assert not subprocess.check_output(['git','-C',str(K),'status','--porcelain'],env=E)
(Q/'ORIGINAL-RELEASE-READBACK.md').write_bytes(b);(Q/'ORIGINAL-RELEASE-CLOSED.json').write_text(json.dumps({'frontmatter':f,'native_release_proper0':True,'remote_exact_body_reason':why,'original_OPEN_PARTIAL':True,'no_new_ticket':True},indent=2)+'\n');print('OriginalT2379 natively released OPEN/PARTIAL, remote main verified',flush=True)
