from pathlib import Path
import json,time,subprocess
Q=Path(__file__).parent;t=time.monotonic()
while True:
 r=json.loads((Q/'OWNERS-OUTER-REAPER.json').read_bytes())
 if r['command_exit']is not None:assert r['command_exit']==0 and r['all_children_reaped']and not r['leftover_cleanup'];break
 assert time.monotonic()-t<1200;time.sleep(5)
for name in ['audit.py','commit.py','push.py']:
 p=subprocess.run(['python',str(Q/name)]);assert p.returncode==0,name
print('Qualified current integration committed and pushed; final exactheadwhole8 still required',flush=True)
