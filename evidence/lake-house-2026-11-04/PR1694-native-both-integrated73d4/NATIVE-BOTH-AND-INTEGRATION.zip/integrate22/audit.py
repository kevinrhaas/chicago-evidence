from pathlib import Path
import subprocess,os,json,hashlib,sys
Q=Path(__file__).parent;P=Q.parent;R=Path('/tmp/cobweb-active-20261103');A=R/'chicago/4d';O='c6474f511c4e76db329d9bc4c3bf373e5104b08d';D='22d624f3e5061dfaf54af0e3429e6278be60abe3';B='a3a87cafe9321a2970a390cac77ae45be82680f5';E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def g(*a):return subprocess.check_output(['git','-C',str(R),*a],env=E)
def old(h,p):return g('show',h+':'+p)
def sha(b):return hashlib.sha256(b).hexdigest()
def js(h,p):return json.loads(old(h,'chicago/4d/'+p))
def diff(a,b,p=''):
 if type(a)!=type(b):return [p]
 if isinstance(a,dict):return [v for k in a.keys()|b.keys() for v in diff(a.get(k),b.get(k),p+'/'+k)]
 if isinstance(a,list):return [p] if a!=b else []
 return [p] if a!=b else []
assert json.loads((P/'current-native3/CLOSURE.json').read_bytes())['status']=='CURRENT_PUBLISHED_NATIVE_STAGE3_BOTH_107_PASS'
assert g('rev-parse','HEAD').decode().strip()==O and g('rev-parse','MERGE_HEAD').decode().strip()==D
incoming=g('diff','--name-only',B,D).decode().splitlines();own=g('diff','--name-only',B,O).decode().splitlines();shared=set(incoming)&set(own);assert shared=={'chicago/4d/data/sidecars/1835/sources/index.json','chicago/4d/docs/ROADMAP.md','chicago/4d/docs/STATUS.md'}
exact=[]
for p in incoming:
 if p in shared:continue
 assert (R/p).read_bytes()==old(D,p),('Foreign postimage lost',p);exact.append(p)
for p in own:
 if p in shared:continue
 assert (R/p).read_bytes()==old(O,p),('Own postimage lost',p)
owned=json.loads((P/'OWNED-DELTAS.json').read_bytes())
for p in ['docs/ROADMAP.md','docs/STATUS.md']:
 raw=(A/p).read_bytes();parent=old(D,'chicago/4d/'+p);tail=owned['raw_document_appends'][p]['tail'].encode();assert raw==parent+tail,('Raw parent prefix/tail drift',p)
idx=json.loads((A/'data/sidecars/1835/sources/index.json').read_bytes());oi=js(O,'data/sidecars/1835/sources/index.json');di=js(D,'data/sidecars/1835/sources/index.json');assert idx.keys()==oi.keys()==di.keys()
by=lambda x:{r['source_id']:r for r in x['sources']}
c,o,d=by(idx),by(oi),by(di);assert c.keys()==o.keys()==d.keys()
for k,v in c.items():assert v==(o[k] if k=='fergus_chicago_directory_1839'else d[k]),k
# The complete runtime and smoke code has identical bytes to the immutable actual run.
runtime=g('ls-tree','-r','--name-only',O,'chicago/4d/renderers/web').decode().splitlines()
for p in runtime:assert (R/p).read_bytes()==old(O,p),p
for p in ['tools/smoke_renderer.mjs','tools/publish.sh','tools/prebuild_layers.mjs']:assert (A/p).read_bytes()==old(O,'chicago/4d/'+p)
# No active1835 structure/ground/registry sidecar changed. Only archival source-use accounting differs.
sidecars=g('ls-tree','-r','--name-only',O,'chicago/4d/data/sidecars/1835').decode().splitlines();sc=[]
allowed={'chicago/4d/data/sidecars/1835/sources/index.json','chicago/4d/data/sidecars/1835/sources/currey_1912_first_fort_birdseye.json','chicago/4d/data/sidecars/1835/sources/whistler_1808_fort_dearborn_draught.json'}
for p in sidecars:
 if (R/p).read_bytes()!=old(O,p):assert p in allowed,p;sc.append(p)
assert set(sc)==allowed
# All web assets except an1812-only north-east house are byte-identical; no1835/Stage3 geometry moves.
web=g('ls-tree','-r','--name-only',O,'chicago/4d/assets/web').decode().splitlines();changedweb=[]
for p in web:
 if (R/p).read_bytes()!=old(O,p):changedweb.append(p)
assert changedweb==['chicago/4d/assets/web/first_fort_dearborn_small_house_ne__first_fort_1803.glb']
assert js(D,'data/sidecars/1812/first_fort_dearborn_small_house_ne.json')['id']=='first_fort_dearborn_small_house_ne'
active=json.loads((A/'data/sidecars/1835/index.json').read_bytes());assert 'first_fort_dearborn_small_house_ne' not in json.dumps(active['structures']) and 'first_fort_dearborn_small_house_ne' in active['excluded_by_date']
for p in g('ls-tree','-r','--name-only',O,'chicago/4d/data/pictures').decode().splitlines():assert (R/p).read_bytes()==old(O,p),p
for p in ['data/structures/lake_house_construction.json','data/sidecars/1835/lake_house_construction.json','data/sources/fergus_chicago_directory_1839.json','data/sidecars/1835/sources/fergus_chicago_directory_1839.json','assets/gltf/lake_house_construction__shell_1835.glb','assets/web/lake_house_construction__shell_1835.glb','data/yard/lot_building_material.json']:
 assert (A/p).read_bytes()==old(O,'chicago/4d/'+p),p
sys.path[:0]=[str(A/'generators'),str(A/'tools')];import mesh_inputs
s=json.loads((A/'data/structures/lake_house_construction.json').read_bytes());recipes=[mesh_inputs.structure_inputs_sha(s,p)for p in s['phases']];assert recipes==['9ff0b1db8bc3101df763f4f1448df60d305188a23e7ff45a3490ed0e98ee53e1']
sourcechanges=[]
for p in sorted(allowed-{'chicago/4d/data/sidecars/1835/sources/index.json'}):
 a=json.loads(old(O,p));b=json.loads((R/p).read_bytes());sourcechanges.append({'path':p,'changed_root_fields':[k for k in a.keys()|b.keys() if a.get(k)!=b.get(k)],'leaf_paths':diff(a,b)})
out={'status':'EXACT_SCOPED_CARRY_OF_ACTUAL_C647_NATIVE_STAGE3_AND_ROOT_REVIEWED_CARDS','actual_execution_head':O,'integrated_incoming':D,'actual_execution_on_new_head':False,'all_foreign_nonshared_postimages_exact':exact,'shared_paths_native_merged_or_compiled':sorted(shared),'all_own_nonshared_postimages_exact':True,'raw_docs_exact_incoming_prefix_plus_owned_tail':True,'runtime_files_exact_count':len(runtime),'all_active1835_nonarchival_sidecars_exact_count':len(sidecars)-3,'only1835_source_accounting_deltas':sourcechanges,'changed_WEB_only1812_not_loaded_in1835':changedweb,'Lake_recipe':recipes,'Lake_geometry_sidecars_and_Pictures_byte_exact':True,'scope':'NativeStage3 107/0 BOTH actually ran c647; source bibliography metadata union does not alter checked source fields, world1835 geometry/runtime or card content. This carries that evidence through exact scope; no execution on future head claimed. Final whole eight-part hosted gate mandatory.'}
(Q/'SCOPED-NATIVE-AND-CARD-CARRY.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'incoming_exact':len(exact),'runtime_exact':len(runtime),'active_sidecars_exact':len(sidecars)-3,'Lake_recipe':recipes,'carry':'PASS'}))
