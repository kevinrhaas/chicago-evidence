from pathlib import Path
import subprocess,json,os,hashlib,time
Q=Path(__file__).parent;P=Q.parent;R=Path('/tmp/cobweb-active-20261103');A=R/'chicago/4d';E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1');O='c6474f511c4e76db329d9bc4c3bf373e5104b08d';D='22d624f3e5061dfaf54af0e3429e6278be60abe3'
def g(*a):return subprocess.check_output(['git','-C',str(R),*a],env=E)
def run(label,cmd,cwd=A):
 rec=Q/(label+'-REAPER.json')
 with(Q/(label+'.log')).open('xb')as f:r=subprocess.run(['python','/workspace/shared/run-with-reaping.py',str(rec),'--','timeout','--signal=TERM','--kill-after=15s','600s',*cmd],cwd=cwd,env=E,stdout=f,stderr=subprocess.STDOUT)
 rr=json.loads(rec.read_bytes());assert r.returncode==rr['command_exit']==0 and rr['all_children_reaped'] and not rr['leftover_cleanup'] and rr['interrupted_signal']is None,label
assert json.loads((Q/'OUTER-REAPER.json').read_bytes())['command_exit']==0
assert json.loads((Q/'SCOPED-NATIVE-AND-CARD-CARRY.json').read_bytes())['status']=='EXACT_SCOPED_CARRY_OF_ACTUAL_C647_NATIVE_STAGE3_AND_ROOT_REVIEWED_CARDS'
assert g('rev-parse','HEAD').decode().strip()==O and g('rev-parse','MERGE_HEAD').decode().strip()==D
rel='chicago/4d/data/sidecars/1835/sources/index.json';oid=g('hash-object',rel).decode().strip()
r=subprocess.run(['git','-C',str(R),'cat-file','-e',oid],env=E,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
if r.returncode:assert g('hash-object','-w',rel).decode().strip()==oid
g('update-index','--add','--cacheinfo','100644',oid,rel);g('update-index','--refresh','--',rel)
assert not g('ls-files','-u') and not g('diff','--name-only')
paths=g('diff','--cached','--name-only',D).decode().splitlines();expected=g('diff','--name-only','a3a87cafe9321a2970a390cac77ae45be82680f5',O).decode().splitlines();assert paths==expected and len(paths)==10
T=g('write-tree').decode().strip()
qualification={'tree':T,'head_before_commit':O,'incoming':D,'source_gate_sequence':'Original sourceparts1-3 at41a; native lineage repair+freshowners+part4 at281; incoming22d actual8+aggregate green; ordinary merge generated one conflict; current scene/sourceUse/Pictures/grade/lot/trade/validate/changelog/derived owners fresh PASS and exact scope audit. Parent explicitly authorized bounded adoption; final exact-head whole8 mandatory before merge.','all4_executed_on_newtree':False,'native107both_actual_head':O,'native_carry_audit':'SCOPED-NATIVE-AND-CARD-CARRY.json','final_exact_head_whole8':'PENDING'}
(Q/'PRECOMMIT-QUALIFICATION.json').write_text(json.dumps(qualification,indent=2)+'\n')
(Q/'MESSAGE.txt').write_text('Merge dev into T-2379 later-address cross-check\n\nPreserve the first-fort native bake and regenerate the combined source index.\nLake House inputs, geometry, active1835 assets and visitor card content remain exact.\n')
run('COMMIT',['git','commit','-F',str(Q/'MESSAGE.txt')],R)
H=g('rev-parse','HEAD').decode().strip();assert g('rev-parse','HEAD^{tree}').decode().strip()==T and g('show','-s','--format=%P',H).decode().split()==[O,D] and not g('status','--porcelain')
(Q/'COMMIT.json').write_text(json.dumps({'head':H,'tree':T,'parents':[O,D],'incoming':D,'paths':paths,'whole8_required_before_merge':True,'native_carry_actual_at':O},indent=2)+'\n')
run('PR-CHANGELOG',['node','tools/check-changelog-entry.mjs',D,H]);run('PR-IDS',['node','tools/resolve_id_collisions.mjs','--check','--base',D])
(Q/'PR-QUESTIONS-PASS.json').write_text(json.dumps({'head':H,'tree':T,'base':D,'actual_commit_changelog_and_ID_questions':'PASS'},indent=2)+'\n');print(H,T,flush=True)
