from pathlib import Path
import json,subprocess,time,datetime
P=Path(__file__).parent.parent;Q=Path(__file__).parent
n=1694;h='73d4d727002f14eaa3263f4c4d3fcfdd099fbad6';history=[]
for i in range(100):
    now=datetime.datetime.now(datetime.timezone.utc).isoformat();row={'utc':now,'PR':n,'expected_head':h,'read_only':True}
    try:
        def api(path):return json.loads(subprocess.check_output(['gh','api','-H','Cache-Control: no-cache','repos/kevinrhaas/chicago/'+path+('&'if'?'in path else'?')+'_='+str(time.time_ns())],stderr=subprocess.STDOUT,timeout=45))
        p=api('pulls/'+str(n));c=api('commits/'+h+'/check-runs?per_page=100')['check_runs'];r=api('actions/runs?head_sha='+h+'&per_page=20')['workflow_runs']
        row.update(actual_head=p['head']['sha'],state=p['state'],draft=p['draft'],mergeable=p.get('mergeable'),mergeable_state=p.get('mergeable_state'),checks=[{k:x[k]for k in ['id','name','status','conclusion','head_sha']}for x in c],runs=[{k:x[k]for k in ['id','name','status','conclusion','head_sha']}for x in r])
        good=[x for x in c if x['name']=='gate'and x['head_sha']==h and x['status']=='completed'and x['conclusion']=='success'];parts=[x for x in c if x['name'].startswith('gate part ')];row['whole8_green']=bool(good)and len({x['name']for x in parts if x['status']=='completed'and x['conclusion']=='success'})==8
    except BaseException as e:row['read_error']=repr(e)
    history.append(row);(Q/'LATEST.json').write_text(json.dumps(row,indent=2)+'\n');(Q/'HISTORY.json').write_text(json.dumps(history,indent=2)+'\n')
    print(json.dumps({'sample':i,'PR':n,'whole8_green':row.get('whole8_green'),'read_error':row.get('read_error')}),flush=True)
    if row.get('actual_head') and row['actual_head']!=h:break
    if row.get('whole8_green')or row.get('state')=='closed':break
    if any(x['name']=='gate'and x['status']=='completed'and x['conclusion']not in ['success','skipped']for x in row.get('checks',[])):break
    time.sleep(30)
(Q/'CLOSED.json').write_text(json.dumps({'read_only':True,'samples':len(history),'latest':history[-1]},indent=2)+'\n')
