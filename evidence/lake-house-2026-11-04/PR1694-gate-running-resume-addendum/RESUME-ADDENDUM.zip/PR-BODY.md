The Lake House Record now quotes a directly checked Hotels entry in Fergus's 1876 recollection of 1839: Rush and North Water. The credited source and the Record retain Andreas's conflicting address and state that this later listing does not establish the July 1835 construction stage or position. T-2379 remains open for its original image match.

Validation:

- Actual published native Stage 3: 107 passed, zero failed at both viewports (mobile 167.1 s; desktop 340.4 s), with zero errors and proper process closure on c647.
- Actual Record, Sources and Images review passed at both viewports. The reviewer accepted the documented capture limits. Lake House recipe, geometry, grades and Images remain unchanged.
- Normal dev integration produced 73d4. Fresh scene, SourceUse, Pictures, grade, lot/trade, validation and changelog owners pass. Exact scope audit preserves the earlier native/card evidence: runtime, active 1835 geometry and own card data are unchanged. The incoming web mesh change belongs to an excluded 1812 building. No native execution on 73d4 is claimed.
- Local source qualification used parts 1–3 on the earlier tree, fresh generated-lineage owners, and repaired part 4. All four were not re-executed on the final tree. The complete current-head eight-part CI run **41767413487 remains required before merge**. Actual PR changelog and ticket-ID questions pass.

[Actual cards and capture limits](https://github.com/kevinrhaas/chicago-evidence/blob/b3fed6c3d26c724285af01916632853cec998a37/evidence/lake-house-2026-11-04/address-crosscheck-actual-cards-both-0200/RECOVERY.md) · [Actual native both, source postimages and integration audit](https://github.com/kevinrhaas/chicago-evidence/blob/1c689a7b889216ed37c48ec35f3d1b71cf878758/evidence/lake-house-2026-11-04/PR1694-native-both-integrated73d4/RECOVERY.md).
