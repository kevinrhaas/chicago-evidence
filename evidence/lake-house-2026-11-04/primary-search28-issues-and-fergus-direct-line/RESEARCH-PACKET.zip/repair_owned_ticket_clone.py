from pathlib import Path
import base64,datetime,hashlib,json,os,subprocess
O=Path('/tmp/lake-house-primary-research-20261104/TICKET-RECOVERY');O.mkdir(exist_ok=True)
T=Path('/tmp/lake-house-source-20261103/chicago/4d/tickets');E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def git(*args,input=None):
 r=subprocess.run(['/usr/local/bin/git','-c','protocol.allow=never','-C',str(T),*args],input=input,env=E,capture_output=True);assert r.returncode==0,(args,r.stderr.decode(errors='replace')[:1000]);return r.stdout
def api(path):return json.loads(subprocess.check_output(['gh','api','repos/kevinrhaas/chicago-tickets/'+path]))
assert not(O/'RECOVERY-CLOSED.json').exists();head=git('rev-parse','HEAD').decode().strip();base=git('rev-parse','HEAD^').decode().strip();assert head.startswith('fe8adf95')and base=='a2ff509b6e99fbd40ed928bc11d7bb143f515a45';assert not git('status','--porcelain','--untracked-files=normal')
paths=git('diff','--name-only',base,head).decode().splitlines();assert 1<=len(paths)<=2 and all(x=='QUEUE.md' or '/T-2379-'in x for x in paths);ticket=next(x for x in paths if x!='QUEUE.md');assert'/T-2379-'in ticket
for name in ['HEAD','index','config']:(O/('BEFORE-'+name)).write_bytes((T/'.git'/name).read_bytes())
(O/'LOCAL-CLAIM-COMMIT.raw').write_bytes(git('cat-file','commit',head));(O/'LOCAL-CLAIM-DIFF.patch').write_bytes(git('diff','--binary',base,head));git('update-ref','refs/recovery/lake-research-unpublished-claim-20261104',head)
tip=api('git/ref/heads/main')['object']['sha'];remote_ticket=api('contents/'+ticket+'?ref='+tip);body=base64.b64decode(remote_ticket['content']).decode();front=body.split('---',2)[1];assert'state: open'in front and'claimed_by: null'in front and'pr: null'in front;assert remote_ticket['sha']==git('rev-parse',base+':'+ticket).decode().strip()
commit=api('git/commits/'+tip);tree=api('git/trees/'+commit['tree']['sha']+'?recursive=1');assert not tree['truncated'];(O/'REMOTE-AUDIT.json').write_text(json.dumps({'tip':tip,'remote_target_blob':remote_ticket['sha'],'target_exact_preclaim_parent':True,'tip_commit':commit},indent=2)+'\n')
blobs={r['sha']:r for r in tree['tree']if r['type']=='blob'};lines=git('cat-file','--batch-check',input=('\n'.join(blobs)+'\n').encode()).decode().splitlines();missing=[r.split()[0]for r in lines if r.endswith(' missing')];assert len(missing)<100 and sum(blobs[k]['size']for k in missing)<16*1024**2
imports=[]
for oid in missing:
 d=api('git/blobs/'+oid);b=base64.b64decode(d['content']);assert len(b)==blobs[oid]['size'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;assert git('hash-object','-w','--stdin',input=b).decode().strip()==oid;imports.append({'path':blobs[oid]['path'],'oid':oid,'bytes':len(b)})
trees={'':commit['tree']['sha']};trees.update({r['path']:r['sha']for r in tree['tree']if r['type']=='tree'})
for directory,oid in sorted(trees.items(),key=lambda pair:pair[0].count('/'),reverse=True):
 if subprocess.run(['/usr/local/bin/git','-C',str(T),'cat-file','-e',oid],env=E,capture_output=True).returncode==0:continue
 prefix=directory+'/'if directory else'';entries=[]
 for row in tree['tree']:
  if row['path'].startswith(prefix)and'/'not in row['path'][len(prefix):]:entries.append(f"{row['mode']} {row['type']} {row['sha']}\t{row['path'][len(prefix):]}")
 assert git('mktree','--missing',input=('\n'.join(entries)+'\n').encode()).decode().strip()==oid
if subprocess.run(['/usr/local/bin/git','-C',str(T),'cat-file','-e',tip],env=E,capture_output=True).returncode:
 v=commit['verification'];payload=v.get('payload')
 if payload:
  raw=payload.encode()
  if v.get('signature'):
   headers,message=raw.split(b'\n\n',1);raw=headers+b'\ngpgsig '+v['signature'].encode().rstrip(b'\n').replace(b'\n',b'\n ')+b'\n\n'+message
 else:
  def identity(d):
   timestamp=int(datetime.datetime.fromisoformat(d['date'].replace('Z','+00:00')).timestamp());return f"{d['name']} <{d['email']}> {timestamp} +0000"
  raw=('tree '+commit['tree']['sha']+'\n'+''.join('parent '+p['sha']+'\n'for p in commit['parents'])+'author '+identity(commit['author'])+'\ncommitter '+identity(commit['committer'])+'\n\n'+commit['message'].rstrip('\n')+'\n').encode()
 assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==tip,'Refuse unverified reconstructed commit'
 assert git('hash-object','-w','-t','commit','--stdin',input=raw).decode().strip()==tip
git('reset','--hard',tip);assert git('rev-parse','HEAD').decode().strip()==tip;assert not git('status','--porcelain','--untracked-files=normal');assert git('rev-parse','HEAD:'+ticket).decode().strip()==remote_ticket['sha']

git('update-ref','refs/remotes/origin/main',tip)
receipt={'status':'OWN_UNPUBLISHED_CLAIM_PRESERVED_AND_CLONE_RESTORED_TO_VERIFIED_REMOTE','old_local_head':head,'parent':base,'restored_tip':tip,'ticket':ticket,'remote_target_open_free_prnull':True,'remote_ticket_exact_old_parent':True,'imported_blobs':imports,'no_remote_push_force_or_source_change':True,'recovery_ref':'refs/recovery/lake-research-unpublished-claim-20261104'}
(O/'RECOVERY-CLOSED.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
