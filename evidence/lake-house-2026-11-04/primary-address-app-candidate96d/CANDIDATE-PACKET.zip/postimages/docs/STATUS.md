

### Lake House source reading — 2026-11-04
The Record now distinguishes a directly checked1876Fergus recollection of the1839Rush/NorthWater address from Andreas's differingstreetaccount. The underlyingJuly1835construction stage, position and dimensions remain uncertain; source/Record metadata only, no geometry or image-match completion.
