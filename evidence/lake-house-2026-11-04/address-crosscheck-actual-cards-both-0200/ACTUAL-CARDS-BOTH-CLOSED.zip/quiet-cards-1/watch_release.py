from pathlib import Path
import time,json
P=Path(__file__).parent
G=Path('/tmp/first-fort-finish-1685-20261104/source4-final-corrected/QUIET-WINDOW-GRANTED.json')
g=json.loads(G.read_bytes());deadline=g['automatic_resume_deadline_unix']
while time.time()<deadline:
    q=P/'UI-OUTER-REAPER.json'
    if q.exists():
        r=json.loads(q.read_bytes())
        if r['command_exit'] is not None and r['all_children_reaped']:
            children=[]
            for path in sorted((P/'custom').glob('*-REAPER.json')):
                row=json.loads(path.read_bytes());children.append({'receipt':str(path),'exit':row['command_exit'],'reaped':row['all_children_reaped']})
            assert all(x['exit'] is not None and x['reaped']for x in children)
            closure=P/'UI-CLOSURE.json'
            value={'all_owned_browser_children_reaped':True,'scope':'Lake scoped customcards both; nativeStage3 remains pending','quiet_output':str(P),'outer_command_exit':r['command_exit'],'actual_card_closure':json.loads(closure.read_bytes())if closure.exists()else None,'children':children,'released_unix':time.time()}
            done=Path(g['Lake_done_signal_path']);assert not done.exists();done.write_text(json.dumps(value,indent=2)+'\n')
            (P/'QUIET-EARLY-RELEASE.json').write_text(json.dumps(value,indent=2)+'\n')
            print('Lake browsers reaped; quiet source controller may resume',flush=True);break
    time.sleep(1)
else:print('Owner automatic deadline reached; no false early-release written',flush=True)
