from pathlib import Path
import os,subprocess,json,hashlib
P=Path(__file__).parent;R=Path('/tmp/cobweb-active-20261103');E=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
def g(*args):return subprocess.check_output(['/usr/local/bin/git','-C',str(R),*args],env=E)
ui=json.loads((P/'UI-CLOSURE.json').read_bytes());assert ui['status']=='LAKE_ADDRESS_WORKING_SOURCE_CUSTOM_NATIVE3_BOTH_PASS'
paths=ui['source']['working_paths'];assert len(paths)==9
assert hashlib.sha256(g('diff','--binary')).hexdigest()==ui['source']['diff_sha256']
assert not g('diff','--cached','--name-only')
rows=[]
for rel,sha in paths.items():
    assert hashlib.sha256((R/rel).read_bytes()).hexdigest()==sha
    oid=g('hash-object',rel).decode().strip()
    exists=subprocess.run(['/usr/local/bin/git','-C',str(R),'cat-file','-e',oid],env=E,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
    if not exists:assert g('hash-object','-w',rel).decode().strip()==oid
    g('update-index','--add','--cacheinfo','100644',oid,rel)
    rows.append({'path':rel,'blob':oid,'sha256':sha,'existing_object':exists})
g('update-index','--refresh','--',*paths)
assert not g('diff','--name-only')
(P/'EXACT-INDEX-STAGED.json').write_text(json.dumps({'paths':rows,'tree':g('write-tree').decode().strip(),'qualified_commit':'PENDING_ALL4_SOURCE','source_UI_bytes_exact':True},indent=2)+'\n')
print('Staged exact9paths; no broadadd/objectfreshening')
