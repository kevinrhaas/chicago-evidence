The Lake House Record now quotes a directly checked Hotels entry in Fergus's 1876 recollection of 1839, at Rush and North Water, alongside Andreas's conflicting street account. It joins the existing credited source and keeps the July 1835 construction-stage uncertainty explicit. T-2379 remains OPEN for its original image match.

Validation:

- Source qualification: parts1–3 passed on the exact prior nine-path tree41a; a native generated documentary-lineage repair then passed fresh rule/SourceUse/schema/geometry/published/prebuilt owner checks and repaired part4 on the final ten-path tree (1/4 350.6s, 2/4 287.7s, 3/4 366.9s, 4/4 312.1s). Consumed-field audit supports scoped reuse of the earlier parts; all four were not re-executed on the final tree. Actual PR changelog and ticket-ID questions passed. The complete current-head eight-part CI remains mandatory before merge.
- Seven native owners passed; complete native inputs, actual MASTER/WEB bytes, phases, coordinates, grades and every existing Images row remain unchanged.
- Actual Record, Sources and Images passed at both release viewports with zero errors and proper process closure. Root reviewed the images and accepted the documented capture limits; exact own data/card modules and main's relevant card APIs remain unchanged after current-dev integration.
- Current published native Stage3 at both viewports and the named hosted whole gate are **PENDING**. This PR stays draft until those actual checks pass.

[Actual both-viewport card evidence and capture limits](https://github.com/kevinrhaas/chicago-evidence/blob/b3fed6c3d26c724285af01916632853cec998a37/evidence/lake-house-2026-11-04/address-crosscheck-actual-cards-both-0200/RECOVERY.md). [Current source and scoped reuse binding](https://github.com/kevinrhaas/chicago-evidence/blob/846d70e9d10c565bd27f5700d83c0eb469ff6f41/evidence/lake-house-2026-11-04/address-crosscheck-current-a3-source-queued/RECOVERY.md).
