# T-3055 / T-3056 final root SHA: prepared smoke plan, UNDISPATCHED

This package is light preparation only. The root commit and PR are literal **PENDING_FINAL_ROOT_COMMIT / PENDING_ROOT_PR**. No GitHub API, dispatch, push, root write, workflow edit, browser, Blender, gate, claim or merge was executed while preparing it. No prior sourceS/Hogan CI verdict is counted as rootM PASS. The earlier completed12-card/actualflagGPU QA is a separate acceptance scope, not full15part renderer smoke.

The actual current workflow `chicago-4d-smoke.yml` accepts `viewport` and `stage`, publishes the mirror, and invokes the unmodified `node tools/smoke_renderer.mjs --published`. Its150minute job timeout remains unchanged. The actual smoke source defines mobile390x780 and desktop1280x800. `contracts.json` pins both source SHA256s; a future final commit with different workflow/smoke source deliberately refuses initialization until reviewed.

The ten jobs cover all15parts exactly once for each viewport: **1–4,5–8,9–12,13,14–15**. Long desktop13 then mobile13 start first. No wall-time or guaranteed completion claim is made. A failure/timeout is retained; there is no automatic retry, cancellation, relaxation or stage redistribution.

## Parent execution after the actual final commit

1. Finish and review the root integration, required local strict preflight/changelog/IDs and actual cardQA/tree equivalence. Commit/push the real final source branch and create/update its PR. Obtain the actual new40hexSHA and PR number; do not substitute an older sourceS/Hogan head.
2. Initialize a NEW plan using that explicit SHA, PR and source branch:

   `python3 /tmp/chicago-next-model/T-3055-T-3056-final-head-smokes/smokes.py initialize --sha ACTUAL_NEW_40_HEX_SHA --pr ACTUAL_PR_NUMBER --branch steward/t3055-t3056-picture-controls-and-source-credits --checkout /workspace/chicago --out /tmp/root-final-head-smokes.json`

   Initialization is local/read-only except its new `/tmp` plan. It requires that checkout HEAD equal the supplied SHA, the worktree/index be clean and the committed workflow/smoke contracts match the reviewed hashes. Known historical sourceS/Hogan SHAs are refused. It never infers SHA from a volatile pending merge.
3. Inspect the plan. `dispatch --plan /tmp/root-final-head-smokes.json` is a dry run without network or dispatch. Parent may explicitly authorize the actual ten requests by adding `--execute-root-authorized`. This is the helper's ONLY API-writing action, and this agent has not run it.

   Before every request it verifies the PR remains open against dev, belongs to this repository/source branch and has the exact planned SHA, and verifies the pushed branch ref. Each exact viewport/stage request and all prior IDs are durably saved before POST. It accepts only one new workflow_dispatch run on the exact head/branch/workflow. Ambiguous receipt or API error leaves `pending_dispatch` and refuses further dispatch; inspect manually, never rerun the POST blindly. Earlier successful receipts are skipped on safe resume. Branch movement stops mixed-head coverage. No merge/cancel/rerun/ticket action exists.
4. Collect a read-only snapshot into a NEW path:

   `python3 /tmp/chicago-next-model/T-3055-T-3056-final-head-smokes/smokes.py collect --plan /tmp/root-final-head-smokes.json --out /tmp/root-final-head-smoke-snapshot-UNIQUE_UTC`

   Optional `--download-completed-logs` preserves exact completed-attempt ZIPs without changing any run; these may be large. Collection queries only the ten recorded IDs and the planned SHA's checks/statuses, then saves exact run/attempt/job/PR/dev ancestry/API snapshots plus per-file hashes. Pending or failed results remain pending/failed; use a fresh snapshot directory for later observations. It does not overwrite failure history or execute polling loops. More than100checks/jobs/statuses refuses readiness until pagination is reviewed.
5. `ci_coverage_ready` can become true only after ALL ten exact-head workflows complete success, a successful required `gate` check is present, latest checks/statuses are acceptable, source PR/ref remain exact, current dev is an ancestor and GitHub reports a clean mergeable PR. **`merge_authorized` is always false.** Parent must separately re-read the real live owned lap/expiry, current dev/head and latest required checks immediately before any SHA-guarded merge, and review exact-final-root local gate/CL/IDs and bounded acceptance receipts. This helper intentionally has NO merge code. A later source commit requires a new plan and fresh exact-head coverage.

Original picture tickets remain open/differs. Completing these renderer smokes does not promote provisional cameras, historical confidence, whole image matches or production deployment. A full strict gate is independent from the10rendererjobs.

## Prepared artifacts / checks

- `plan.template.json`: literal pending SHA/PR and all10jobs.
- `smokes.py`: explicit initialization, opt-in dispatch, read-only collection/readiness; Python stdlib + installed git/gh and authenticated GitHub access are runtime dependencies.
- `contracts/chicago-4d-smoke.yml`, `contracts.json`: exact current workflow bytes and workflow/smoke source hashes.
- `references.json`: hashes of the Hogan example plan/dispatch/readiness sources reviewed for contracts; they are reference history, not dependencies or inherited acceptance.
- `light-check.json`: Python AST parse and exact30part-view pairing coverage; actual helper initialization/dispatch/network/collection are UNRUN. Syntax/coverage checks do not establish real CI acceptance.

Do not blindly run this package during root's live producer/browser/gate work. Parent owns scheduling and the final-head/lap/merge decision. No artifact from a live output was archived here.
