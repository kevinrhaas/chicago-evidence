#!/usr/bin/env python3
"""Prepare, explicitly dispatch, and read-only collect exact-root-head smoke receipts.
No merge/ticket/claim action exists. The committed root SHA must be passed explicitly.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,re,subprocess,time
ROOT=Path(__file__).resolve().parent
REPO='kevinrhaas/chicago'
WORKFLOW='chicago-4d-smoke.yml'
WORKFLOW_PATH='.github/workflows/'+WORKFLOW
SMOKE_PATH='chicago/4d/tools/smoke_renderer.mjs'
RANGES={'1-4':[1,2,3,4],'5-8':[5,6,7,8],'9-12':[9,10,11,12],'13':[13],'14-15':[14,15]}
JOBS=[('desktop','13'),('mobile','13')]+[(v,s) for s in ['1-4','5-8','9-12','14-15'] for v in ['mobile','desktop']]
HISTORICAL={'a5cae2adc766425103151debd8ef57b152d70022','e41ae248f6eaad1ead26c93537a7d1c7b438d3c0','50b6b0fe0ce661d513988ef913f296391d1c2bea','05f6b886e5a31f17ec21e743f945cc4a89abc745'}
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,obj):
 path=Path(path);tmp=path.with_name(path.name+'.tmp');tmp.write_text(json.dumps(obj,indent=2)+'\n');tmp.replace(path)
def api(endpoint,method='GET',payload=None):
 args=['gh','api',endpoint]
 if method!='GET':args+=['-X',method]
 if payload is not None:args+=['--input','-']
 out=subprocess.check_output(args,input=None if payload is None else json.dumps(payload).encode())
 return json.loads(out) if out.strip() else None

def check_plan(p,complete=False):
 assert p['repository']==REPO and re.fullmatch('[0-9a-f]{40}',p['head']) and p['head'] not in HISTORICAL
 assert p['timeout_minutes']==150 and p['workflow_file']==WORKFLOW and p['pr']>0
 assert len(p['jobs'])==10
 for v in ['mobile','desktop']:
  assert sorted(n for j in p['jobs'] if j['viewport']==v for n in j['parts'])==list(range(1,16))
 for j in p['jobs']:assert j['parts']==RANGES[j['stage']]
 assert len({(j['viewport'],j['stage']) for j in p['jobs']})==10
 runs=p.get('runs',[]);assert len({r['id'] for r in runs})==len(runs)
 assert len({(r['viewport'],r['stage']) for r in runs})==len(runs)
 for r in runs:
  assert (r['viewport'],r['stage']) in JOBS and r['head']==p['head']
 if complete:assert len(runs)==10 and p.get('dispatch_complete') and not p.get('pending_dispatch')

def remote_guard(p):
 pr=api(f'repos/{REPO}/pulls/{p["pr"]}')
 assert pr['state']=='open' and not pr['merged'] and pr['head']['sha']==p['head']
 assert pr['head']['ref']==p['branch'] and pr['head']['repo']['full_name']==REPO and pr['base']['ref']=='dev'
 ref=api(f'repos/{REPO}/git/ref/heads/{p["branch"]}')
 assert ref['object']['sha']==p['head'],'Source branch advanced; stop mixed-head coverage.'
 return pr

def initialize(a):
 assert re.fullmatch('[0-9a-f]{40}',a.sha) and a.sha not in HISTORICAL,'Pass the actual NEW final root commit, not a prior sourceS/Hogan head.'
 assert a.pr>0 and a.branch and not a.out.exists()
 checkout=Path(a.checkout)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=checkout,text=True).strip()==a.sha
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=checkout,text=True).strip(),'Commit and review root work first; final plan requires clean exact HEAD.'
 contracts=json.loads((ROOT/'contracts.json').read_text())
 for rel,digest in contracts['frozen_source_sha256'].items():
  b=subprocess.check_output(['git','show',a.sha+':'+rel],cwd=checkout)
  assert hashlib.sha256(b).hexdigest()==digest,('Workflow/smoke contract changed; re-review and regenerate plan',rel)
 p={'status':'PENDING_DISPATCH','created_at':utc(),'repository':REPO,'pr':a.pr,'branch':a.branch,'head':a.sha,'workflow_file':WORKFLOW,'workflow_id':None,'timeout_minutes':150,'viewports':{'mobile':[390,780],'desktop':[1280,800]},'jobs':[{'viewport':v,'stage':s,'parts':RANGES[s]} for v,s in JOBS],'runs':[],'dispatch_complete':False,'final_root_local_gate':'PENDING_ROOT_EXACT_HEAD_RECEIPT_REVIEW','scope':'Fresh exact-final-root-head full15parts at bothviews; no inherited Hogan/cardQA acceptance. Parent owns lap/dev/SHA/merge checks.','contract_sha256':contracts['frozen_source_sha256']}
 check_plan(p);write(a.out,p);print(json.dumps(p,indent=2))

def listing(p):
 return api(f'repos/{REPO}/actions/workflows/{WORKFLOW}/runs?branch={p["branch"]}&event=workflow_dispatch&per_page=100')['workflow_runs']
def dispatch(a):
 p=json.loads(a.plan.read_text());check_plan(p)
 if not a.execute_root_authorized:
  print(json.dumps({'status':'DRY_RUN_NO_NETWORK_NO_DISPATCH','head':p['head'],'jobs':p['jobs'],'required_opt_in':'--execute-root-authorized'},indent=2));return
 assert not p.get('pending_dispatch'),'Unresolved receipt: inspect before_ids/new runs; NEVER redispatch blindly.'
 remote_guard(p)
 wf=api(f'repos/{REPO}/actions/workflows/{WORKFLOW}')
 assert wf['path']==WORKFLOW_PATH and wf['state']=='active'
 if p['workflow_id'] is None:p['workflow_id']=wf['id'];write(a.plan,p)
 assert p['workflow_id']==wf['id']
 for v,s in JOBS:
  if any(r['viewport']==v and r['stage']==s for r in p['runs']):continue
  remote_guard(p);before={r['id'] for r in listing(p)}
  request={'ref':p['branch'],'inputs':{'viewport':v,'stage':s}}
  p['pending_dispatch']={'viewport':v,'stage':s,'before_ids':sorted(before),'started_at':utc(),'expected_sha':p['head'],'request':request};write(a.plan,p)
  api(f'repos/{REPO}/actions/workflows/{WORKFLOW}/dispatches','POST',request)
  candidates=[]
  for _ in range(20):
   candidates=[r for r in listing(p) if r['id'] not in before and r['head_sha']==p['head'] and r['workflow_id']==p['workflow_id'] and r['event']=='workflow_dispatch']
   if candidates:break
   time.sleep(2)
  assert len(candidates)==1,'Ambiguous/missing receipt. Pending request retained. Inspect manually; do not retry POST.'
  run=candidates[0];assert run['head_branch']==p['branch'];remote_guard(p)
  row={'viewport':v,'stage':s,'parts':RANGES[s],'id':run['id'],'url':run['html_url'],'head':run['head_sha'],'observed_at':utc(),'request':request}
  p['runs'].append(row);p.pop('pending_dispatch');write(a.plan,p);print(json.dumps(row),flush=True)
 check_plan({**p,'dispatch_complete':True},complete=True);p['dispatch_complete']=True;p['status']='PENDING_RESULTS';write(a.plan,p)
 print('All10 exact-head jobs dispatched; await read-only collection and root review. No merge action exists.')

def collect(a):
 p=json.loads(a.plan.read_text());check_plan(p,complete=True)
 assert not a.out.exists(),'Use a NEW snapshot path; preserve old failures/pending results.'
 a.out.mkdir(parents=True);pr=api(f'repos/{REPO}/pulls/{p["pr"]}');write(a.out/'pr.json',pr)
 branch=api(f'repos/{REPO}/git/ref/heads/{p["branch"]}');dev=api(f'repos/{REPO}/branches/dev');comparison=api(f'repos/{REPO}/compare/{dev["commit"]["sha"]}...{p["head"]}')
 write(a.out/'branch.json',branch);write(a.out/'dev.json',dev);write(a.out/'dev-ancestry.json',comparison)
 observed=[]
 for row in p['runs']:
  run=api(f'repos/{REPO}/actions/runs/{row["id"]}');assert run['head_sha']==p['head'] and run['workflow_id']==p['workflow_id'] and run['event']=='workflow_dispatch' and run['head_branch']==p['branch']
  write(a.out/f'run-{row["id"]}.json',run)
  # Exact attempt jobs; preserve all pages and conclusions (no rerun or cancellation).
  jobs=api(f'repos/{REPO}/actions/runs/{row["id"]}/attempts/{run["run_attempt"]}/jobs?per_page=100');assert jobs['total_count']<=100
  write(a.out/f'run-{row["id"]}-attempt-{run["run_attempt"]}-jobs.json',jobs)
  if a.download_completed_logs and run['status']=='completed':
   b=subprocess.check_output(['gh','api',f'repos/{REPO}/actions/runs/{row["id"]}/attempts/{run["run_attempt"]}/logs']);(a.out/f'run-{row["id"]}-attempt-{run["run_attempt"]}-logs.zip').write_bytes(b)
  observed.append({**row,'status':run['status'],'conclusion':run['conclusion'],'run_attempt':run['run_attempt']})
 checks=api(f'repos/{REPO}/commits/{p["head"]}/check-runs?filter=latest&per_page=100');assert checks['total_count']<=100,'Paginate before declaring readiness.'
 status=api(f'repos/{REPO}/commits/{p["head"]}/status?per_page=100');assert status['total_count']<=100,'Paginate before declaring readiness.'
 write(a.out/'check-runs.json',checks);write(a.out/'commit-statuses.json',status)
 all_smokes=all(r['status']=='completed' and r['conclusion']=='success' for r in observed)
 all_checks=any(c['name']=='gate' and c['status']=='completed' and c['conclusion']=='success' for c in checks['check_runs']) and all(c['status']=='completed' and c['conclusion'] in ['success','skipped','neutral'] for c in checks['check_runs']) and all(s['state']=='success' for s in status['statuses'])
 fresh=pr['state']=='open' and not pr['merged'] and pr['head']['sha']==p['head'] and branch['object']['sha']==p['head'] and pr['base']['ref']=='dev' and comparison['status'] in ['ahead','identical']
 ready=bool(all_smokes and all_checks and fresh and pr.get('mergeable') is True and pr.get('mergeable_state')=='clean')
 result={'observed_at':utc(),'head':p['head'],'pr':p['pr'],'smokes':'PASS10/10_exacthead_all15_bothviews' if all_smokes else 'PENDING_OR_FAILED','runs':observed,'all_latest_checks_acceptable_with_gate_success':bool(all_checks),'head_and_dev_ancestry_current':bool(fresh),'ci_coverage_ready':ready,'merge_authorized':False,'root_required_manual_checks':['Own current live lap and ensure it is held/unexpired immediately before any merge','Review exact final-root-head official local strict preflight/changelog/IDs receipts (Hogan verdict is NOT rootM proof)','Review completed12card/actualflagGPUQA and final-tree content equivalence; it is NOT full15part smoke','Re-fetch latest dev/head/checks and confirm still fresh and SHA before parent uses any guarded merge','Preserve actual failures; no blind retries/cancels/assertion/timeout relaxation','Original image-match tickets remain OPEN/differs; no fullmatches or production promotion inferred']}
 write(a.out/'readiness.json',result);write(a.out/'plan-used.json',p)
 hashes={str(q.relative_to(a.out)):hashlib.sha256(q.read_bytes()).hexdigest() for q in a.out.rglob('*') if q.is_file()};write(a.out/'SHA256.json',hashes)
 print(json.dumps(result,indent=2))

def offline():
 p=json.loads((ROOT/'plan.template.json').read_text());assert p['head']=='PENDING_FINAL_ROOT_COMMIT' and p['pr']=='PENDING_ROOT_PR'
 jobs=p['jobs'];assert len(jobs)==10
 for v in ('mobile','desktop'):assert sorted(n for j in jobs if j['viewport']==v for n in j['parts'])==list(range(1,16))
 print('PASS:10jobs, each15parts once at bothviews; template SHA/PR remain literalPENDING; no APIs/dispatch/rootwrites.')

def main():
 parser=argparse.ArgumentParser();sub=parser.add_subparsers(dest='command',required=True)
 i=sub.add_parser('initialize');i.add_argument('--sha',required=True);i.add_argument('--pr',type=int,required=True);i.add_argument('--branch',required=True);i.add_argument('--checkout',default='/workspace/chicago');i.add_argument('--out',type=Path,required=True);i.set_defaults(run=initialize)
 d=sub.add_parser('dispatch');d.add_argument('--plan',type=Path,required=True);d.add_argument('--execute-root-authorized',action='store_true');d.set_defaults(run=dispatch)
 c=sub.add_parser('collect');c.add_argument('--plan',type=Path,required=True);c.add_argument('--out',type=Path,required=True);c.add_argument('--download-completed-logs',action='store_true');c.set_defaults(run=collect)
 o=sub.add_parser('offline-check');o.set_defaults(run=lambda _:offline())
 a=parser.parse_args();a.run(a)
if __name__=='__main__':main()
