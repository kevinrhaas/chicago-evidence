
## Completed published card checkpoint — 2026-10-23

This supersedes the earlier pending card/derived-data labels above. The actual
published grouped run passes12/12 at390×780 and1280×800, with source credits,
identity/date limits and visible grades checked, zero page/network/server or
unexpected-loader errors, and real Tremont flag drawing/GPU uniforms verified in
normal and confidence modes. Native Photos tests pass11 checks. The refreshed
ordered55-step producer tail reaches a fixed point.

The direct original-e41 builder/params and unchanged original-record comparison
against final code passes for all23 producer-selected frame phases, with canonical
names/seeds, exact old parameters and geometry/material/confidence streams.
Sauganash's unselected1829 stored phase passes separately; there are0 original
frame versions. This is distinct from the earlier executed-proposal/KW-only proof
and does not claim24 canonical exports or byte-exact UV packing.

[Closed12-case recovery](https://github.com/kevinrhaas/chicago-tickets/blob/4083c66910fdd088d2118f2a20127b190b017693/evidence/image-match-2026-10-22/closed-complete12QA-bridge-fort-20261023T120430Z/RECOVERY.md)
preserves actual receipts; failed earlier runs remain historical failures. Current
M strict preflight and all15-part published smokes at both viewports remain
pending. Original picture comparisons still differ and no original image case is
closed. Shared-control/source completion remains subject to those final gates.
