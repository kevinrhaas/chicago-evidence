# Actual lighthouse profile review — 2026-10-23

**Verdict: DIFFERS. Heavy slot CLEAR.** The two pinned exports and same-camera renders completed with exit0. Actual source/baseline/proposed images were inspected; no accepted match or canonical adoption is claimed.

Gallery/rail placement is visibly closer and three small shaft apertures now appear. The lantern still reads as a tall opaque dark drum; source cage/light openings, dome/finial, rail details, masonry tone and aperture treatment remain visibly different. Camera/40ft datum uncertainty and every other original reference remain open. Both generated match records remain unreviewed; this explicit research receipt records the actual differing verdict.

Geometry contracts passed:930→1062triangles,0zero-area, all finite streams, valid material/index ranges, max unit-normal error1.061112682165799e-7. Physical glTF bounds are identical `[1.2799999714,0,-4.3200001717]..[4.3200001717,12.8496799469,-1.2799999714]`. No app foundation or surveyed placement change.

Exact artifact SHA256 values:

- `a30e15521423f6b6cfa05925963e287634fcf8bd5377497e14ba104e06c5b0b8` — `baseline/assets/gltf/chicago_lighthouse_1832__tower_1832.glb`
- `3934500d1ff4a94ef975de8d234395834acd22a619f574cdcbecf0cda0928ad2` — `baseline/docs/RESEARCH/profile-trial/camera.json`
- `bbec2c0dae8742ef13859f924f3f942e1e7bf808bc8cc472e6b58d903cb39a57` — `baseline/docs/RESEARCH/profile-trial/camera.match.json`
- `6db98a8dc196525c353e0520012a451c14ea4480a6aa173eb4f11bb2a1a178bd` — `baseline/data/sources/assets/chicago_harbor_lighthouse_1838.jpg`
- `7aa1058f17e247d64217707bacffb38dfa093546c6271c7dd3a3af2955ea03d2` — `reviews/baseline/camera-render.png`
- `3b5a40e429aefed141a062ae6744062c5fa8ebd5d059f16503651d80974ca9ad` — `reviews/baseline/camera-side-by-side.jpg`
- `38aced7ae5a99be374834c45b125995f5a7dec3a0df8e54226713c09957d477a` — `proposed/assets/gltf/chicago_lighthouse_1832__tower_1832.glb`
- `3934500d1ff4a94ef975de8d234395834acd22a619f574cdcbecf0cda0928ad2` — `proposed/docs/RESEARCH/profile-trial/camera.json`
- `7419fbdb29a8d2178e8ea62f1e64205993cd715663eca6632206effdfc6ab77f` — `proposed/docs/RESEARCH/profile-trial/camera.match.json`
- `6db98a8dc196525c353e0520012a451c14ea4480a6aa173eb4f11bb2a1a178bd` — `proposed/data/sources/assets/chicago_harbor_lighthouse_1838.jpg`
- `40678a9ce2e0736354274f72c1f0313dce74a99d3d7903f266999a1f25829581` — `reviews/proposed/camera-render.png`
- `991aa14dd2fbd390f57a4ba82fb39503ab02d52e81864ef33834ca63909b4f32` — `reviews/proposed/camera-side-by-side.jpg`

No source variants or input/camera tweaks were made. Original frozen package unchanged; clean a5cae2adc worktree supplied runtime readers only. No other structure record was built, and no fort/Lake House opt-in adoption is included. Reconstructed profile/apertures do not establish historical metric precision or July1835 continuity.
