from pathlib import Path
import json,hashlib,datetime
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shared=[
 {'what':'The 1867 sheet depicts1833 retrospectively; no exact1835 appearance, metric gauge or station is established.','status':'open'},
 {'what':'Inherited pole/sign is too far screen-right, too low/small, upright rather than source-left-leaning; crossbar, hanging board and lettering/animal depiction differ.','status':'open'},
 {'what':'Source shows horizontal log courses on both facing gable walls and triangles; after has a plain/clapboard left face and blank gable triangles, while its logs/roof finish remain smooth schematic proxies.','status':'open'},
 {'what':'Source doorways read dark/open; after has closed panel/plank details. Right small light is about9source pixels low in prior approximate point projection; exact lintels/sash/fabric remain unresolved.','status':'open'},
 {'what':'Roof overhangs, edge thickness, valley/eave junction and surface fabrication remain schematic; broad stack head and slender pipe have approximate form/station but no attested dimensions/material.','status':'open'},
 {'what':'Hidden orthogonalL plan,5m spans and exact dimensions are reconstructed; other retrospective Wolf Point views and date continuity remain unresolved.','status':'open'},
 {'what':'Building-only neutral-plane render excludes context/terrain/stale tradeprops and ignores world origin. Canonical entrances, props, collision/contact/terrain/full81refresh and appQA remain owed; solid-footprint walker has no interior passage.','status':'not shown'}]
changes=[
 {'what':'Actual after export replaces the prior long inline facade/roof with two opposing gable faces and the connected L roof topology in much closer source-screen layout.','status':'fixed'},
 {'what':'Actual after export supplies the second +X facing entry and retains the other facing entry, instead of the prior extra-front-window layout; detailed openings still differ.','status':'fixed'},
 {'what':'Actual after export adds a separate slender roof projection beside the broad roof head, corresponding to the two source silhouettes; exact fabric and scale remain reconstructed.','status':'fixed'}]
for label in ['before','after']:
 p=R/label/'docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.match.json';m=json.loads(p.read_text());assert m['verdict']=='unreviewed';m['verdict']='differs'
 m['differences']=([{'what':'Long inline baseline model does not reproduce the source pair of differently directed gable ends, their inside corner or two facing entry stations.','status':'open'},{'what':'Separate slender roof projection is absent from this first-chimney proposed baseline.','status':'open'}]+shared) if label=='before' else changes+shared
 p.write_text(json.dumps(m,indent=2)+'\n')
review={'status':'ACTUAL_VISUAL_REVIEW_COMPLETE_DIFFERS','recorded':'2026-10-23','reviewed_by':'school_lighthouse_castle_bridge; root independently viewed detail and agreed clear L improvement, differs','source_id':'blanchard_shober_1867_wolf_point','source_sha256':sha(R/'after/data/sources/assets/nypl-full.jpg'),'camera_sha256':sha(R/'after/docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.json'),'directly_opened':['copied full 1867 source sheet','reviews/before/nypl-1867-L-provisional-side-by-side.jpg','reviews/after/nypl-1867-L-provisional-side-by-side.jpg','reviews/source-before-after-detail.png'],'source_image_gate_verdict':'differs; original T-2386 stays open; no accepted reference view','conclusion':'Actual opposing-gable/connectedL form and second entry are a material visible improvement. Suitable to review as an incremental source-driven geometry step, subject to normal canonical integration checks, not a full picture match. Large cladding and pole differences remain.','improvements':changes,'remaining':shared,'actual_exports':{},'comparison_images':{},'runner_recovery':'First invocation returned Blender exit0 but resolved a relative --python path against/workspace; produced no GLB and failed contract. Original frozen runner and failed run retained. Separate run_absolute_recovery.py changed only script path to absolute frozen path. Successful run produced exactly two intended exports/captures; no geometry/camera variant.','canonical_writes':False,'processes':'Both Blender commands and both node/browser/server captures closed. Heavy slot CLEAR; later root full gate owns heavy.'}
for label in ['before','after']:
 p=R/label/'assets/gltf/wolf_point_tavern__log_frame_1828.glb';review['actual_exports'][label]={'path':str(p.relative_to(R)),'sha256':sha(p),'decoded_contract':json.loads((R/label/'export-contract.json').read_text())}
 for name in ['nypl-1867-L-provisional-side-by-side.jpg','render.png']:
  p=R/'reviews'/label/name;review['comparison_images'][str(p.relative_to(R))]=sha(p)
p=R/'reviews/source-before-after-detail.png';review['comparison_images'][str(p.relative_to(R))]=sha(p)
(R/'visual-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'verdict':review['source_image_gate_verdict'],'after_glb_sha256':review['actual_exports']['after']['sha256'],'detail_sha256':sha(p),'review_sha256':sha(R/'visual-review.json')},indent=2))
