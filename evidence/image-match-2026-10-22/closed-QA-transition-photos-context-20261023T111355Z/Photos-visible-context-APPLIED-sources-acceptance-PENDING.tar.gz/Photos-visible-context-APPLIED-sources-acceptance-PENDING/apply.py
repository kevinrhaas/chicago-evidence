"""Guard three reviewed Photos context files; default read-only, --apply writes source only."""
from pathlib import Path
import argparse,json,hashlib,os
H=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def atomic(p,data):
 t=p.with_name('.'+p.name+'.photos-context.tmp');t.write_bytes(data);os.replace(t,p)
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--apply',action='store_true');a=ap.parse_args();A=a.repo.resolve()/'chicago/4d';r=json.loads((H/'receipt.json').read_text());assert r['exit_code']==0 and r['checks']==11
 for rel,digest in r['base_sha256'].items():assert sha(A/rel)==digest,rel+': reviewed base drift';assert sha(H/'fixture'/rel)==r['proposal_sha256'][rel],rel+': proposal drift'
 if not a.apply:
  print('REVIEW ONLY:3 exact guarded files; inspect proposal.patch +receipt.json; then --apply. Real source/compiler/published/card/full checks remain owed.');return
 written=[]
 try:
  for rel in r['base_sha256']:
   p=A/rel;backup=H/'apply-backup'/rel;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(p.read_bytes());atomic(p,(H/'fixture'/rel).read_bytes());written.append(rel)
 except BaseException:
  for rel in reversed(written):atomic(A/rel,(H/'apply-backup'/rel).read_bytes())
  raise
 (H/'apply-receipt.json').write_text(json.dumps({'repo':str(a.repo.resolve()),'applied_source_files':written,'copied_generated_artifacts':False,'actual_browser_acceptance':False,'source_receipt':r},indent=2)+'\n');print('APPLIED3sourcefiles only; regenerate producers/publisher and rerun actual card/full gates; no baked assets touched.')
if __name__=='__main__':main()
