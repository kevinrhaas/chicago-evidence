## Current integration checkpoint — 2026-10-23

The final shared frame API adds eleven keyword-only/default-off fields; the
roof-tone choice extends an existing enum. All23 affected canonical masters and
web derivatives have actually been regenerated. Three named hotel opt-ins change
visibly;19 other masters are byte-exact and one differs only in unused trim UV
packing. Actual Sauganash roof/attic, Tremont known-name strokes and darker roof
comparisons were reviewed as bounded progress, all still differs. The retained
material below describes earlier prototypes and checkpoints, including their
then-current counts and outstanding work.

Current dev e474 is integrated in the pending working tree. Focused feature/flag
tests pass; final derived-data refresh, corrected complete12-card published QA,
grouped full preflight and all15-part published smokes at both viewports remain
pending. No original image-match case is closed.

# T-3055 — Green Tree, Sauganash and first Tremont picture increments

All archived picture comparisons remain **differs**; no original ticket is closed,
no provisional camera is accepted and no research camera is placed in reference_views.
The old first-increment README and receipts remain under first-increment/ and the
per-target folders. They describe their own earlier frozen proposal, including its
then-bare roof spar. The new third-tremont/ archive adds opaque arch/plain entry
outlines and a separately labelled actual proposed app-flag diagnostic, held time0.

The source, previous and proposed standard captures use identical numeric/byte
cameras, source pictures, intrinsics/light and helpers. The fourth diagnostic
imports the actual proposed flags.js runtime layer rather than baking cloth. Its
explicit roof-spar mount draws one24-star flag with reconstructed confidence1 and
no runtime problems. The existing shared breeze presents it nearly edge-on; the
source flag projects left, so pose remains unresolved. All captures are isolated
prototypes, not an official bake/freshness acceptance or full app/mobile proof.

GreenTree gains seven pictured-side upper bays and main-gable wall cladding;
Sauganash gains two upper plus one attic main-end sash in white gable clapboard;
Tremont gains three shuttered storeys, raised entries, bounded opaque arch, four
stacks and a roof spar. Metric controls, hidden repeats, colour/finish choices
and chronology/camera/wing/context details stay explicit reconstruction or open.
The current footprints, geographic controls and building phase dates are retained.
The flag anchor's1836-07-03 limit bounds its24-star pattern and does not end the
building phase. Whole-building grade differs from per-attribute evidence.

Sources: public-domain US1884 Andreas/Braunhold retrospective plates for GreenTree
and Sauganash; N.Roswell Gifford first Tremont drawing reproduced by Chicagology,
https://chicagology.com/prefire/prefire021/. Owner-approved attributed project use
2026-10-22; original publication/collection/copyright unresolved, no public-domain
claim for Gifford. Source records and assets/LICENSES.md retain the limitations.

All ten new dataclass fields are keyword-only to preserve the original forty
positional parameters/defaults. The API follow-up proof records exact equality
of resolved params and accumulated geometry/material/confidence across24phases
against the executed preview proposal. Parameter source bytes changed: this
requires fresh recipes, never restamping the earlier GLBs or manifests.

The final source still requires a fresh canonical pinned23-family build, current
web derivatives/manifests/licences/grades/compiled sidecars and full local/remote
app/mobile/card checks. No old canonical GLBs, manifests or sidecars are restored
from a stash or copied from prototype outputs by this integration package.
