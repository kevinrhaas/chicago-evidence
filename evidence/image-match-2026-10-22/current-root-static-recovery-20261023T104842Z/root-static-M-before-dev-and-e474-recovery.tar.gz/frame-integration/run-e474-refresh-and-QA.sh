#!/usr/bin/env bash
set -euo pipefail
frame_logs=/tmp/frame-integration/e474-integration
mkdir -p "$frame_logs/tmp"
export PYTHONPATH=/workspace/shared/python
export PATH="/workspace/shared/tools/usr/bin:$PATH"
export npm_config_cache=/workspace/shared/npm-cache
export CHECK_JOBS=4 C4D_GATE_REQUIRE_READERS=1 C4D_GATE_REQUIRE_BASE=1
# Keep fixture temp roots outside every git worktree.
export TMPDIR="$frame_logs/tmp"
trap 'frame_exit=$?; printf "%s\n" "$frame_exit" > "$frame_logs/refresh-and-QA.exit"' EXIT
cd /workspace/chicago/chicago/4d
date -u +%FT%TZ > "$frame_logs/started.txt"
python tools/compile_liberties.py > "$frame_logs/liberties.log" 2>&1
python tools/generate_entrances.py > "$frame_logs/entrances.log" 2>&1
node tools/rederive.mjs --tail tools/compile_scene.py > "$frame_logs/tail.log" 2>&1
python /tmp/frame-integration/restore-workbook-parity-reference.py --repo /workspace/chicago --reference e4745b3c5714185079215d06d8072a4791c6de4a --receipt "$frame_logs/workbook-parity.json" > "$frame_logs/workbook-parity.log" 2>&1
bash tools/publish.sh > "$frame_logs/publish.log" 2>&1
QA_OUT="$frame_logs/group-card-QA" node /tmp/frame-integration/group-card-check.mjs > "$frame_logs/group-card-QA.log" 2>&1
date -u +%FT%TZ > "$frame_logs/finished.txt"
