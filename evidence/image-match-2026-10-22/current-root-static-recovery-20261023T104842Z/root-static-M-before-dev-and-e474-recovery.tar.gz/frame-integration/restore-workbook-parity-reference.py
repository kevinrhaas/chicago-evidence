import argparse
import io
import json
import subprocess
from pathlib import Path

import openpyxl

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--receipt', type=Path, required=True)
parser.add_argument('--reference', default='HEAD')
args = parser.parse_args()
names = subprocess.check_output(
    ['git', 'diff', '--name-only', args.reference, '--', '*.xlsx'],
    cwd=args.repo, text=True).splitlines()
receipts = []
for name in names:
    target = args.repo / name
    old = subprocess.check_output(['git', 'show', f'{args.reference}:{name}'], cwd=args.repo)
    current = target.read_bytes()
    a = openpyxl.load_workbook(io.BytesIO(old), read_only=True, data_only=False)
    b = openpyxl.load_workbook(io.BytesIO(current), read_only=True, data_only=False)
    try:
        same = a.sheetnames == b.sheetnames and all(
            list(a[s].values) == list(b[s].values) for s in a.sheetnames)
    finally:
        a.close()
        b.close()
    row = {'path': name, 'reference': args.reference, 'all_sheet_values_equal': same,
           'restored_original_zip_bytes': False}
    if not same:
        receipts.append(row)
        args.receipt.write_text(json.dumps(receipts, indent=2) + '\n')
        raise SystemExit(f'REFUSED workbook restore: actual sheet values changed: {name}')
    target.write_bytes(old)
    row['restored_original_zip_bytes'] = True
    receipts.append(row)
args.receipt.write_text(json.dumps(receipts, indent=2) + '\n')
print(json.dumps(receipts))
