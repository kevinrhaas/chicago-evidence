#!/usr/bin/env bash
set -uo pipefail
source_logs=/tmp/source-prerequisite/post-label-gate
mkdir -p "$source_logs/tmp"
export PYTHONPATH="/workspace/shared/python${PYTHONPATH:+:$PYTHONPATH}"
export PATH="/workspace/shared/tools/usr/bin:$PATH"
export npm_config_cache=/workspace/shared/npm-cache
export CHECK_JOBS=4 C4D_GATE_REQUIRE_READERS=1
export CHECK_TIMINGS="$source_logs/check-timings.tsv"
export TMPDIR="$source_logs/tmp"
cd /workspace/chicago/chicago/4d || exit 2
date -u +%FT%TZ > "$source_logs/started.txt"
./tools/preflight.sh > "$source_logs/preflight.log" 2>&1
source_exit=$?
printf '%s\n' "$source_exit" > "$source_logs/preflight.exit"
for source_item in preflight-check.log preflight-cl.log preflight-ids.log; do
  if [ -f "/tmp/$source_item" ]; then cp "/tmp/$source_item" "$source_logs/$source_item"; fi
done
date -u +%FT%TZ > "$source_logs/finished.txt"
exit "$source_exit"
