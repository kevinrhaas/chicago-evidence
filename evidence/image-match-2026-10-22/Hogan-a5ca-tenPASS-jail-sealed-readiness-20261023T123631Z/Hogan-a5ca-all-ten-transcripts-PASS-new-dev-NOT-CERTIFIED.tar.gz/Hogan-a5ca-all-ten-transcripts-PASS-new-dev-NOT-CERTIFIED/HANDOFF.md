# Exact a5ca complete published-smoke evidence

All ten actual workflow/job transcripts PASS at a5cae2adc766425103151debd8ef57b152d70022. Actual logs verify published mirror, correct viewport and requested range, positive assertion counts, zero failed assertions and zero page errors. Parts1–15 tile exactly once per viewport. See a5ca-smoke-final-logs/ALL-TEN-ACTUAL-TRANSCRIPTS.json plus complete ZIPs/run/job metadata. The final desktop part13 passes160 assertions; earlier baseline/ORB failures remain separately archived, not reclassified.

Local strict preflight1053 and exact-head CI1053/changelog PASS are already preserved in tickets9d57fe28 and5d25948a; this bundle complements them. No image match is accepted; originalT-2377 remains open and comparison differs.

A fresh dev-ref guard caught advancement to519b1a74e04551a2fdf2272fd771b78a03c0c950 (PR1232/T-3059 Kimball geometry, K01/K08 and recipe changes), while a simultaneous PR response still named old basee474. Readiness certification stopped rather than accepting that mixed snapshot. Incoming commit/compare and explicit NOT-CERTIFIED summary are retained. These completed results apply to exacta5ca and cannot be called validation of a new integrated head.

Root subsequently authorized a new isolated no-commit merge of actual latest dev. Child will preserve incoming source/master/recipe lineage, resolve authored material before native rederive, then wait for an exclusive heavy slot and official local check before any merge commit/push. Root owns final merge/lease/next full-smoke dispatch. No source/workflow/assertion/time-limit change or PR merge is hidden in this evidence packet.

Resume isolated app worktree /tmp/hogan-pr1229-integration; local branch steward/t2377-hogan-current-dev; PR1229 source steward/t2377-hogan-picture-match. Root-owned lap renewed10:46:35UTC, live to about13:46 (verify actual remote lease before merge). Earlier frozen packets stay immutable.
