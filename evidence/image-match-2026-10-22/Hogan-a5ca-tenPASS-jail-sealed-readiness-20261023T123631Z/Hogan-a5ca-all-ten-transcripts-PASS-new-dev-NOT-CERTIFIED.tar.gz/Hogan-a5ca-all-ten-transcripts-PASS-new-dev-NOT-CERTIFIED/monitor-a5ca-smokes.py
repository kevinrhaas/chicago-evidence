from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,subprocess,time,datetime,sys
r=Path(__file__).resolve().parent;plan=json.loads((r/'e474-smoke-runs-new-head.json').read_text());rows=plan['runs'];out=r/'live-a5ca-smokes';out.mkdir(exist_ok=True);errors=0
assert plan['dispatch_complete'] and len(rows)==10
prior=sorted(out.glob('20*.json'))
if prior:
 cached=json.loads(prior[-1].read_text())
 if cached.get('head')==plan['head']:rows=cached['runs']
def api(p):return json.loads(subprocess.check_output(['gh','api',p],text=True,timeout=45))
def get(row):
 if row.get('status')=='completed' and row.get('conclusion')=='success':return row
 x=api(f"repos/{plan['repository']}/actions/runs/{row['id']}");assert x['head_sha']==plan['head'];return {**row,'status':x['status'],'conclusion':x['conclusion'],'attempt':x['run_attempt']}
while True:
 stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
 try:
  with ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(get,rows))
  pr=api(f"repos/{plan['repository']}/pulls/1229");snap={'head':plan['head'],'observed_at':stamp,'pr_head':pr['head']['sha'],'required_gate_first_attempt_failed_separate_record':39941322173,'runs':rows,'merge_performed':False};p=out/f'{stamp}.json';p.write_text(json.dumps(snap,indent=2)+'\n');errors=0
  if pr['head']['sha']!=plan['head']:print(json.dumps({'event':'HEAD_CHANGED','snapshot':str(p)}),flush=True);sys.exit(2)
  bad=[x for x in rows if x['status']=='completed' and x['conclusion']!='success']
  if bad:(out/'ACTUAL_FAILURE.json').write_text(json.dumps(snap,indent=2)+'\n');print(json.dumps({'event':'ACTUAL_SMOKE_FAILURE','failed':bad,'snapshot':str(p)}),flush=True);sys.exit(1)
  if all(x['status']=='completed' and x['conclusion']=='success'for x in rows):(out/'ALL_TEN_SUCCESS.json').write_text(json.dumps(snap,indent=2)+'\n');print(json.dumps({'event':'ALL_TEN_SMOKES_SUCCESS','snapshot':str(out/'ALL_TEN_SUCCESS.json'),'required_gate_review_separate':True}),flush=True);sys.exit(0)
 except Exception as e:
  errors+=1;(out/f'{stamp}-API-error.txt').write_text(str(e)+'\n')
  if errors>=5:print(json.dumps({'event':'MONITOR_API_ERROR','detail':str(e)}),flush=True);sys.exit(3)
 time.sleep(60)
