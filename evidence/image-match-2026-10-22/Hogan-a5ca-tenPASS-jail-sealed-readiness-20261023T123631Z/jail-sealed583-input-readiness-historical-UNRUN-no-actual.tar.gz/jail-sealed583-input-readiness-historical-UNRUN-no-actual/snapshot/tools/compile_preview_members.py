"""Use the native nested sidecar compiler for the exact3 genuine preview records."""
from pathlib import Path
import ast,datetime as dt,json,sys
sys.dont_write_bytecode=True
D=Path.cwd();sys.path[:0]=[str(D/'tools'),str(D/'generators')]
import compile_scene as cs
J=lambda p:json.loads(p.read_text())
records={s:J(D/'data/structures'/f'{s}.json') for s in ['log_jail','log_jail_keeper_house','log_jail_palisade']}
scene=J(D/'data/scenes/1835.json');datum=J(D/'data/datum.json');sources={}
def collect(n):
 if isinstance(n,dict):
  for s in n.get('sources',[]) or []:sources[s]=J(D/'data/sources'/f'{s}.json')
  for v in n.values():collect(v)
 elif isinstance(n,list):
  for v in n:collect(v)
for r in records.values():collect(r)
t=ast.parse((D/'tools/compile_scene.py').read_text());outer=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='compile_scene')
node=next(n for n in outer.body if isinstance(n,ast.FunctionDef) and n.name=='build_sidecar')
ns=dict(vars(cs));ns.update(scene_id='1835',scene=scene,target=dt.date(1835,7,1),datum=datum,sources=sources,residents={},lodging={},trade_roofs_unseatable={},structure_names={s:r['name'] for s,r in records.items()})
exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(D/'tools/compile_scene.py'),'exec'),ns)
for s,r in records.items():
 sc=ns['build_sidecar'](r,r['phases'][0]);p=D/'data/sidecars/1835'/f'{s}.json'
 assert not p.is_symlink(),'preview member output must be an owned regular destination'
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(sc,indent=2,ensure_ascii=False)+'\n')
print('3 complete native producer sidecars; no GLBs implied by metadata. Group renderer must require actual assets.')
