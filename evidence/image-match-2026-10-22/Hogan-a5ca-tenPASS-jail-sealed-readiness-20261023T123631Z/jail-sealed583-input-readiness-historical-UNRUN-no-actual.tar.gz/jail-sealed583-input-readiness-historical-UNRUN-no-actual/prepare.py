"""Light-only sealed jail preview snapshot. No canonical writes or heavy processes."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;D=Path('/workspace/chicago/chicago/4d');O=Path('/tmp/chicago-next-model/T-2380-adoption-composer');S=B/'snapshot'
J=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def cp(src,rel):
 dest=S/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
assert not S.exists(),'sealed snapshot exists; prepare a new package instead of overwriting it'
old=J(O/'proposal.json')
# Narrow preview preparation: unrelated live ledger output may drift; model/source
# inputs may not. No old ledger or global frame files are adopted into the snapshot.
selected=['data/structures/log_jail.json','generators/archetypes/palisade.py','generators/archetypes/palisade_params.py']
for rel in selected:assert sha(D/rel)==old['before'][rel],'model base drift: '+rel
for rel in ['data/sources/trowbridge_first_jail_gale_1902.json','data/sources/calisphere_ucr_first_jail_catalogue_1930.json']:
 assert sha(D/rel)==old['source_and_frame_guards'][rel],'sourceS drift: '+rel
for sid in ['log_jail_keeper_house','log_jail_palisade']:assert not (D/'data/structures'/f'{sid}.json').exists(),'already integrated context'
S.mkdir()
for p in (D/'generators').rglob('*'):
 if p.is_file() and '__pycache__' not in p.parts and p.suffix in ['.py','.pin']:cp(p,p.relative_to(D))
tools=['compile_scene.py','review_constraint.py','tiers.py','exclusion_scope.py','associations.py','grade_structures.py','readable_text.py','compile_summaries.py','compile_pictures.py','flag_form_contract.py','photo_match.mjs','photo_match_group.mjs']
for name in tools:cp(D/'tools'/name,'tools/'+name)
for p in (D/'renderers/web/vendor/three-0.185.1').rglob('*'):
 if p.is_file():cp(p,p.relative_to(D))
for rel in ['renderers/web/js/keith-stone.js','renderers/web/js/flag-anchors.js','data/scenes/1835.json','data/datum.json','data/source.schema.json','data/structures.schema.json','data/structure_grades.json','data/exclusions.json','assets/LICENSES.md']:
 cp(D/rel,rel)
# All root-level source records are only1MB and preserve the native picture join;
# no image stores, residents, whole scene, site, or other structure data is copied.
for p in (D/'data/sources').glob('*.json'):cp(p,p.relative_to(D))
for rel in ['data/sources/gale_1902_jail_walk_text.json','data/structures/log_jail.json','data/structures/log_jail_keeper_house.json','data/structures/log_jail_palisade.json','generators/archetypes/palisade.py','generators/archetypes/palisade_params.py']:
 assert sha(O/'candidate'/rel)==old['after'][rel],rel;cp(O/'candidate'/rel,rel)
cp(D/'data/structures/log_jail.json','baseline-records/log_jail.json')
cp(D/'data/sidecars/1835/log_jail.json','baseline-records/log_jail.sidecar.json')
cp(D/'assets/gltf/log_jail__log_1833.glb','assets/gltf/log_jail__log_1833.glb')
base=J(D/'assets/manifest.json')['assets']['log_jail__log_1833.glb'];assert sha(D/'assets/gltf/log_jail__log_1833.glb')==old['preview_input_guards']['assets/gltf/log_jail__log_1833.glb']
dump(S/'assets/manifest.json',{'assets':{'log_jail__log_1833.glb':base}})
cp(O/'compile_preview_members.py','tools/compile_preview_members.py')
(S/'data/sidecars/1835').mkdir(parents=True)
# Compile true producer sidecars before installing the unsolved diagnostic camera:
# adding it cannot masquerade as a new canonical whole-building grade.
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':'/workspace/shared/python'}
with (B/'native-sidecars.log').open('w') as log:subprocess.run([sys.executable,str(S/'tools/compile_preview_members.py')],cwd=S,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
for sid in ['log_jail','log_jail_keeper_house','log_jail_palisade']:
 sc=J(S/'data/sidecars/1835'/f'{sid}.json');prior=J(O/'light-fixture/chicago/4d/data/sidecars/1835'/f'{sid}.json')
 for key in ['id','phase','archetype','target_date','placement','footprint','attributes','citations','grade']:assert sc[key]==prior[key],(sid,key)
cp(O/'gale-plate-upright-analysis.png','data/sources/assets/jail-gale1902/upright.png')
camera=J(O/'camera-gale-group.json');camera['photo']='../../sources/assets/jail-gale1902/upright.png'
assert camera['also_render']==['log_jail_keeper_house','log_jail_palisade']
dump(S/'data/reference_views/log_jail/gale-compound-pilot.json',camera)
probe="""import json,sys
from pathlib import Path
sys.path.insert(0,'generators');import mesh_inputs
out={}
for sid in ['log_jail','log_jail_keeper_house','log_jail_palisade']:
 r=json.loads(Path('data/structures/'+sid+'.json').read_text());out[sid+'__'+r['phases'][0]['id']+'.glb']=mesh_inputs.structure_inputs_sha(r,r['phases'][0])
print(json.dumps(out))
"""
r=subprocess.run([sys.executable,'-c',probe],cwd=S,env=env,text=True,capture_output=True,check=True);recipes=json.loads(r.stdout)
prior={r['asset']:r['after'] for r in J(O/'recipe-scope.json')['recipes']};assert all(prior[k]==h for k,h in recipes.items())
paths=[p for p in S.rglob('*') if p.is_file()];assert not any(p.is_symlink() for p in S.rglob('*'))
assert set(p.stem for p in (S/'data/structures').glob('*.json'))=={'log_jail','log_jail_keeper_house','log_jail_palisade'}
manifest={str(p.relative_to(S)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in paths};dump(B/'snapshot-manifest.json',manifest)
blender=Path('/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender');want='5e15447670804c855fef6033ac9b8fd82696b762095becf0df79b1c2f8034397';assert sha(blender)==want
chrome=Path('/usr/bin/chromium');chrome_binary=Path('/usr/lib/chromium/chromium');assert chrome_binary.is_file()
dump(B/'snapshot.json',{'status':'sealed light snapshot; exports/browser UNRUN','input_repo_head':subprocess.run(['git','rev-parse','HEAD'],cwd=D,text=True,capture_output=True,check=True).stdout.strip(),'sourceS_gale_sha256':sha(S/'data/sources/trowbridge_first_jail_gale_1902.json'),'sourceS_ucr_sha256':sha(S/'data/sources/calisphere_ucr_first_jail_catalogue_1930.json'),'baseline_entry':base,'recipes':recipes,'group':['log_jail','log_jail_keeper_house','log_jail_palisade'],'snapshot_files':len(paths),'snapshot_bytes':sum(p.stat().st_size for p in paths),'blender':str(blender),'blender_binary_sha256':want,'chromium':str(chrome),'chromium_launcher_sha256':sha(chrome),'chromium_binary':str(chrome_binary),'chromium_binary_sha256':sha(chrome_binary),'allowed_runtime_dependencies':{'NODE_PATH':'/workspace/node_modules','PYTHONPATH':'/workspace/shared/python'},'project_input_symlinks':0,'metadata_compilation':'unmodified native nested compiler;3 sidecars equal prior reviewed metadata in all relevant fields','expected_counts':{'candidate_master_builds':3,'baseline_master_builds':0,'browser_captures':2,'candidate_rendered_members':3,'production_master_unit_separate':18}})
print('Sealed',len(paths),'files /',sum(p.stat().st_size for p in paths),'bytes.3 actual native sidecars; no source symlinks, exports or browser.')
