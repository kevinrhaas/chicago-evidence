"""Light-only static/native checks; never invokes Blender export or a browser."""
from pathlib import Path
import ast,hashlib,json,os,py_compile,subprocess,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;S=B/'snapshot';J=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=J(B/'snapshot.json');m['runner_sha256']=sha(B/'run_preview.py');(B/'snapshot.json').write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
for name in ['prepare.py','run_preview.py','check_readiness.py']:py_compile.compile(str(B/name),cfile='/tmp/jail-readiness-'+name+'.pyc',doraise=True)
tree=ast.parse((B/'run_preview.py').read_text());func=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='commands');ns={};exec(compile(ast.fix_missing_locations(ast.Module(body=[func],type_ignores=[])),str(B/'run_preview.py'),'exec'),ns)
root=(B/'runs/PLAN/candidate').resolve();cmds=ns['commands'](root,m['blender'],True);build=cmds[0]
assert Path(build[build.index('--python')+1])==root/'generators/build.py'
for flag in ['--out','--wrote']:assert Path(build[build.index(flag)+1]).is_absolute()
assert build[build.index('--only')+1].split(',')==m['group'] and build[build.index('--scene')+1]=='1835'
assert len(ns['commands'](root,m['blender'],False))==1
for sid in m['group']:
 sc=J(S/'data/sidecars/1835'/f'{sid}.json');assert sc['id']==sid and sc['scene']=='1835' and sc['target_date']=='1835-07-01'
 assert sc['asset']=='gltf/'+sid+'__'+sc['phase']+'.glb'
 assert sc['grade']['value']=='inferred','diagnostic camera must not create a canonical grade claim'
house=J(S/'data/structures/log_jail_keeper_house.json');assert house['phases'][0]['form']['stories']['value']==1 and not any(k in house for k in ['occupants','person_id','residents'])
assert 'shut' in J(S/'data/structures/log_jail_palisade.json')['phases'][0]['form']['wickets']['note']
cam=J(S/'data/reference_views/log_jail/gale-compound-pilot.json');assert [cam['structure_id'],*cam['also_render']]==m['group']
gale=J(S/'data/sources/trowbridge_first_jail_gale_1902.json');ucr=J(S/'data/sources/calisphere_ucr_first_jail_catalogue_1930.json');assert gale['rights_status']=='public_domain' and ucr['rights_status']=='check_required' and 'text_only' in json.dumps(ucr)
probe="""import sys,json
from pathlib import Path
S=Path(sys.argv[1])
def audit(event,args):
 if event=='open' and isinstance(args[0],(str,bytes)):
  p=str(args[0]);assert not p.startswith('/workspace/chicago'), 'LIVE ROOT READ: '+p
sys.addaudithook(audit)
sys.path.insert(0,str(S/'generators'));import mesh_inputs
out={}
for sid in ['log_jail','log_jail_keeper_house','log_jail_palisade']:
 r=json.loads((S/'data/structures'/f'{sid}.json').read_text());out[sid+'__'+r['phases'][0]['id']+'.glb']=mesh_inputs.structure_inputs_sha(r,r['phases'][0])
print(json.dumps(out))
"""
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':'/workspace/shared/python','NODE_PATH':'/workspace/node_modules'}
r=subprocess.run([sys.executable,'-c',probe,str(S)],cwd='/workspace',env=env,text=True,capture_output=True,check=True);assert json.loads(r.stdout)==m['recipes'];(B/'recipe-no-live-root.log').write_text('PASS recipes resolve from the sealed runtime despite cwd=/workspace; audit rejects any /workspace/chicago read.\n'+r.stdout)
node="""import {createRequire} from 'node:module';import fs from 'node:fs';const b=process.argv[1];const require=createRequire(b+'/tools/qa.mjs');console.log('Playwright resolves:',require.resolve('playwright'));const {renderGroup}=await import(b+'/tools/photo_match_group.mjs');const cam=JSON.parse(fs.readFileSync(b+'/data/reference_views/log_jail/gale-compound-pilot.json'));try{renderGroup(b,cam,{glb:'assets/gltf/log_jail__log_1833.glb'});throw Error('incomplete group accepted')}catch(e){if(!e.message.includes('log_jail_keeper_house: missing GLB'))throw e;console.log('PASS actual group resolver refuses missing real keeper GLB:',e.message)}"""
r=subprocess.run(['node','--input-type=module','-e',node,str(S)],cwd='/workspace',env=env,text=True,capture_output=True,check=True);(B/'node-and-group-light.log').write_text(r.stdout)
r=subprocess.run([sys.executable,str(B/'run_preview.py')],cwd='/workspace',env=env,text=True,capture_output=True,check=True);(B/'dry-run.log').write_text(r.stdout)
(B/'commands.json').write_text(json.dumps({'candidate':cmds,'baseline':ns['commands']((B/'runs/PLAN/baseline').resolve(),m['blender'],False)},indent=2)+'\n')
print('PASS absolute isolated build/out/wrote paths; native3-sidecar/grade/source/date limits; sealed same recipes from unrelated cwd with live-ROOT reads refused; shared Playwright resolves; missing real group member refused. No export/browser.')
