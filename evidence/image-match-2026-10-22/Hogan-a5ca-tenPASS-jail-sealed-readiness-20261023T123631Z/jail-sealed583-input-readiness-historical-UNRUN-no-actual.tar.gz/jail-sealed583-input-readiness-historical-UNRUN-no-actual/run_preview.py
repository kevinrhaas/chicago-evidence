"""Execute only the sealed local snapshot, after the parent's explicit heavy slot."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,subprocess,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;S=B/'snapshot';J=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def commands(root,blender,candidate):
 cam=root/'data/reference_views/log_jail/gale-compound-pilot.json'
 out=[]
 if candidate:out.append([blender,'-b','-noaudio','--factory-startup','--threads','2','--python',str(root/'generators/build.py'),'--','--only','log_jail,log_jail_keeper_house,log_jail_palisade','--scene','1835','--no-bake','--out',str(root/'assets/gltf'),'--wrote',str(root/'wrote.txt')])
 out.append(['node',str(root/'tools/photo_match.mjs'),str(cam),'--glb','assets/gltf/log_jail__log_1833.glb','--out',str(root/'reviews')]);return out
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute',action='store_true');a=ap.parse_args();m=J(B/'snapshot.json');manifest=J(B/'snapshot-manifest.json')
 assert sha(Path(__file__))==m['runner_sha256'],'reviewed runner drift'
 assert {str(p.relative_to(S)) for p in S.rglob('*') if p.is_file()}==set(manifest),'sealed snapshot file set changed'
 for rel,v in manifest.items():assert sha(S/rel)==v['sha256'],'sealed file drift: '+rel
 assert not any(p.is_symlink() for p in S.rglob('*')),'unexpected source symlink'
 plan={label:commands((B/'runs/PLAN'/label).resolve(),m['blender'],label=='candidate') for label in ['baseline','candidate']}
 for cmds in plan.values():
  for cmd in cmds:
   if '--python' in cmd:assert Path(cmd[cmd.index('--python')+1]).is_absolute()
 if not a.execute:
  print('NOT EXECUTED. Verified sealed snapshot;0 live ROOT reads. Planned0 baseline builds,3 candidate masters,2 same-optics captures.');print(json.dumps(plan,indent=2));return
 assert sha(Path(m['blender']))==m['blender_binary_sha256'],'pinned Blender drift'
 assert sha(Path(m['chromium']))==m['chromium_launcher_sha256'] and sha(Path(m['chromium_binary']))==m['chromium_binary_sha256'],'Chromium runtime drift'
 v=subprocess.run([m['blender'],'--version'],text=True,capture_output=True,check=True).stdout;assert v.startswith('Blender 4.5.3')
 # Shared installed tools are the parent's explicit permitted runtime dependency;
 # no project data/module is resolved from /workspace/chicago or another ROOT.
 env={**os.environ,**m['allowed_runtime_dependencies'],'PYTHONDONTWRITEBYTECODE':'1','PW_EXECUTABLE':m['chromium']}
 env.pop('NODE_OPTIONS',None)
 stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S-%f');run=B/'runs'/stamp
 for label in ['baseline','candidate']:
  root=run/label;shutil.copytree(S,root,symlinks=False)
  camfile=root/'data/reference_views/log_jail/gale-compound-pilot.json';cam=J(camfile)
  if label=='baseline':
   cam.pop('also_render');cam['solve']+=' BASELINE: genuinely committed bare core, missing pictured context; same optics.'
   shutil.copyfile(root/'baseline-records/log_jail.json',root/'data/structures/log_jail.json')
   shutil.copyfile(root/'baseline-records/log_jail.sidecar.json',root/'data/sidecars/1835/log_jail.json')
   for sid in ['log_jail_keeper_house','log_jail_palisade']:
    (root/'data/structures'/f'{sid}.json').unlink();(root/'data/sidecars/1835'/f'{sid}.json').unlink()
   dump(camfile,cam)
  cmds=commands(root.resolve(),m['blender'],label=='candidate')
  dump(root/'commands.json',cmds)
  for n,cmd in enumerate(cmds):
   with (root/f'command-{n}.log').open('w') as log:subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
   if '--python' in cmd:
    wrote=(root/'wrote.txt').read_text().splitlines();assert set(wrote)==set(m['recipes']) and len(wrote)==3,'unexpected build scope'
    actual=J(root/'assets/manifest.json')['assets']
    for asset,want in m['recipes'].items():assert actual[asset]['inputs_sha256']==want,'actual recipe mismatch: '+asset
  match=J(camfile.with_suffix('.match.json'))
  if label=='candidate':assert [r['structure_id'] for r in match['rendered_members']]==m['group'],'incomplete actual rendered group'
  assert match['verdict']=='unreviewed'
  print(label,'finished:',root/'reviews',flush=True)
 print('All subprocesses exited. No live ROOT reads after snapshot, promotion, app/ticket writes or match verdict. Inspect actual images before deciding next changes.')
if __name__=='__main__':main()
