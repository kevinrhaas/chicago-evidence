# T-2380 complete-group preview readiness

**Exports and browser captures remain UNRUN. No canonical changes or ticket verdict.** The archived adoption composer is untouched. This separate follow-up fixes two real runner defects: its relative Blender `--python` argument, and its shadow/symlink dependence on live project inputs.

The exact future command, only after the parent grants the heavy slot, is:

```bash
python3 /tmp/chicago-next-model/T-2380-preview-readiness/run_preview.py --execute
```

It works from an unrelated working directory. The runner passes an **absolute** owned `generators/build.py`, output directory and wrote-file path to Blender; matcher script/camera/output paths are also absolute, while native GLB URL paths stay relative as the renderer expects. Its subprocess working directories are explicit.

The fixed count is **one Blender invocation building3 candidate masters, zero baseline builds, and2 Chromium captures**. Baseline is the actual committed79,736-byte bare-core GLB, honestly missing the pictured context; candidate renders actual `log_jail`, `log_jail_keeper_house` and `log_jail_palisade` together. No additional variant, diagnostic, refit or silent context omission is available. Elapsed time is unmeasured because this run has not executed. The existing18-master production family refresh is a different unit and is not satisfied by this3-master preview.

## Isolation and evidence

`snapshot/` contains583 ordinary files totalling14,099,294 bytes; `snapshot-manifest.json` pins every byte and the exact file set. There are no project-input symlinks, root assets stores, whole-scene copies, resident trees, site mirrors or other structure records. The445 small source JSON records total about1MB and preserve the native picture/citation join. All generator source modules, the necessary native compiler/render tools,3 records/actual native sidecars, current sourceS records, required scene/schema/datum, Three vendor files, source PNG and actual baseline GLB/license are materialized locally. Runtime fixtures are copied solely from this sealed snapshot.

**After snapshot the runner reads no live project ROOT.** Its only external dependencies are the parent's explicitly permitted installed toolchain: Blender, Chromium, `/workspace/node_modules` via `NODE_PATH`, and `/workspace/shared/python` via `PYTHONPATH`. There is no live project code/data lookup through them. It verifies its own hash and the sealed snapshot before execution, then the pinned Blender and Chromium launcher/binary hashes. It neither reopens the old composer nor reads `/workspace/chicago` to refresh inputs during a capture.

Verified existing Blender:

```text
/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender
SHA256 5e15447670804c855fef6033ac9b8fd82696b762095becf0df79b1c2f8034397
```

The parent's archive pin remains975c58fcb244273838534bba771e64ad87739216b0f9b39a888531a49a72d845. Chromium is `/usr/bin/chromium`, backed by `/usr/lib/chromium/chromium`; current154.0.8037.57 runtime hashes are in `snapshot.json`. No binary was installed, and no Blender export or browser process was started.

`check.log` records light checks:

- Absolute build/out/wrote path and exact3-ID/1835 selection checks.
- Actual complete3-member sidecars compiled by the unmodified native nested compiler; relevant metadata equals the prior reviewed3 sidecars, including their **inferred** grades. The provisional camera was installed afterward and does not manufacture a canonical grade promotion.
- Native recipes resolve to the prior reviewed hashes from `cwd=/workspace`, under a Python audit that rejects any `/workspace/chicago` read.
- Shared installed Playwright resolves without launching Chromium.
- The native group resolver refuses the missing actual keeper GLB. There are no fake/blank assets or placeholder sidecars. The future runner asserts all3 actual wrote names/recipe hashes and all3 actual rendered members.
- Default invocation verifies the sealed inputs, prints the absolute command plan and exits **NOT EXECUTED**.

The earlier composer's apply guard now notices a live derived-liberty JSON change from the parent's work. This preview does not relax or apply that composer, copy its old global ledger, or overwrite current frame work. Geometry and sourceS inputs were checked unchanged when the new snapshot was prepared; any future canonical adoption still needs its own current reviewed guards/producers/gates.

## Actual source and acceptance scope

One actual whole-plate Gale1902 camera is used, with exactly the previous principal point/focal length/eye/yaw/sun and2741×1853 pixels. Its provisional fit used four manually selected core-roof points with roughly14.37px residual; it is **not a solved metric whole-compound camera**. The source is the independently published1902 W.E.S.Trowbridge plate, service page/n79, captioned1836. The local PNG is the previously verified lossless quarter-turn, with identical bytes; it is not cropped, resampled or retouched. SourceS's1902 public-domain art and UCR's1930 uncertain-publication/check-required/text-only catalogue/copy remain distinct and unaltered.

Gale's actual printedp51 retrospective1835 walk supports the small jail, high palisade and partly enclosed Randolph-facing keeper house. It does not prove all illustrated details existed on1July1835. Andreas's separate later oaken cell, fall1835 courthouse and contrasting rear-cap picture remain unresolved. This single preview cannot settle those other-image/date/identity questions.

The candidate is the same22° core/2.66m eave and reviewed reconstructed context/clearance proposal. It adds no invented upper light/floor, John Beach person/household link or walker passage. House attic/second gable lights and other source details still differ or need actual review. The low wicket is closed as a reconstructed static instant. Walker collision still uses the full palisade envelope, with documented inside-spawn/core-access limits; this isolated common-grade renderer is not app walker/terrain QA.

All future captures remain `unreviewed` until a human/agent inspects the actual full-group images. Nothing here closes T-2380 or assigns `matches`.

## Original-case claim

At the parent's request, the original open/unclaimed T-2380 was normally claimed as `jail-picture-match-agent` with the exact canonical ticket tool in its352KB isolated context. No force, no-lock or rival override was used. [Commit0b36e038383c71fb5fe36c6b50d3c8421d2ea6d4](https://github.com/kevinrhaas/chicago-tickets/commit/0b36e038383c71fb5fe36c6b50d3c8421d2ea6d4) is confirmed at remote main. Only3 claim front-matter fields changed; original scope, pictures and acceptance remain intact. The tickets clone is clean and the archivist push window was released. `ticket-claim-proof.json` records the receipt. App/worktree writes and heavy execution remain unperformed.
