Hogan’s generic store now follows the pictured door/window arrangement, gable-light proxy and ridge chimney in Edgar S. Cameron’s first-post-office drawing. The documented footprint, position, bearing and phase dates are retained. Numeric opening dimensions and stations remain reconstructed; the card credits Cameron and the Chicago Historical Society.

**T-2377 remains open.** This is a first model increment. Its provisional comparison still differs in perspective, door and gable treatment, stack detail, materials and context. No accepted image match or original-ticket closure is claimed. [Source, camera and before/after comparison](https://github.com/kevinrhaas/chicago/tree/50b6b0fe0ce661d513988ef913f296391d1c2bea/chicago/4d/docs/RESEARCH/hogan-picture-match-T-2377) retain the original-publication verification limits.

Current head `50b6b0fe0ce661d513988ef913f296391d1c2bea` merges current dev `29785b404` into the existing Hogan branch. Both append-only Hogan and Kimball liberties are preserved and their compiled index is regenerated. The smoke renderer is taken verbatim from current dev, including T-3057’s existing correction for the 27 Indiana Avenue records. The final diff against dev changes no smoke assertion, timeout, workflow or error handling.

Validation:

- **Current head: official strict local preflight PASS, 1049/1049 checks**, including required raster readers, plus changelog and ticket-ID checks. The ordered producer tail settled in two laps. The first local attempt’s sole failure was the external tickets queue’s stale T-3056 title; central repair `e92ad0fc` and the successful full rerun are preserved in the receipts.
- Published targeted Hogan app/card QA passed at `6156a0367a2379f0d986b88c7c8236c4ebec0e55` for mobile 390×780 and desktop 1280×800, including visible source credit and no unexpected page/loader errors. Hogan’s record, source and master GLB are byte-identical through this head. This is content-equivalent evidence for Hogan’s unchanged content; it does not claim a new full-app browser run at this head.
- At former head `05f6b886e`, nine of ten full-smoke runs passed. [Desktop 14–15, run 39909852234](https://github.com/kevinrhaas/chicago/actions/runs/39909852234), remains **historically failed** on an external Glessner thumbnail request (`net::ERR_BLOCKED_BY_ORB`; 160 assertions passed, one failed). That result has not been erased or reclassified.

Full local logs, qualified prior app/card QA, exact dispatch receipts and preserved historical failures are checkpointed in [the immutable GitHub evidence archive](https://github.com/kevinrhaas/chicago-tickets/blob/125283a1b2f82500908d880aec521a92fb04681d/evidence/image-match-2026-10-22/hogan-pr1229-50b6-checkpoint-20261023T094744Z/README.md).

The separate content-build `warranted` check’s first attempt hit its existing five-minute limit during full-history checkout. [Failed-job-only attempt 2](https://github.com/kevinrhaas/chicago/actions/runs/39933426147) **passed** at unchanged `50b6`: the normal warrant decision found no branch-owned generator/build-workflow changes against dev and skipped the dependent bake jobs. No geometry bake ran. The first timeout remains preserved; no workflow limit or assertion changed.

All ten fresh published-smoke workflows below are pinned to `50b6b0fe0ce661d513988ef913f296391d1c2bea` and cover every part 1–15 once at each viewport. At snapshot `20261023T094154Z`, all ten are running; **full browser coverage and merge readiness are pending**. Part 13 runs separately.

| Parts | Mobile | Desktop |
|---|---|---|
| 1-4 | [39933473814](https://github.com/kevinrhaas/chicago/actions/runs/39933473814) | [39933487479](https://github.com/kevinrhaas/chicago/actions/runs/39933487479) |
| 5-8 | [39933499576](https://github.com/kevinrhaas/chicago/actions/runs/39933499576) | [39933514468](https://github.com/kevinrhaas/chicago/actions/runs/39933514468) |
| 9-12 | [39933529139](https://github.com/kevinrhaas/chicago/actions/runs/39933529139) | [39933544634](https://github.com/kevinrhaas/chicago/actions/runs/39933544634) |
| 13 | [39933460897](https://github.com/kevinrhaas/chicago/actions/runs/39933460897) | [39933446616](https://github.com/kevinrhaas/chicago/actions/runs/39933446616) |
| 14-15 | [39933561818](https://github.com/kevinrhaas/chicago/actions/runs/39933561818) | [39933576662](https://github.com/kevinrhaas/chicago/actions/runs/39933576662) |

Merge target is `dev`. Merge waits for all ten exact-head runs to complete successfully, current-head CI to be green, and the root agent’s held-lap review. Original picture-match work continues after this bounded increment.
