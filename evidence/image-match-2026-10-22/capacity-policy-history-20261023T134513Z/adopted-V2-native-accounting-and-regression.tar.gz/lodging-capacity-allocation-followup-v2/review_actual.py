#!/usr/bin/env python3
"""Read-only actual postbuild review; use a NEW --out path each time."""
from pathlib import Path
import sys,os,json,hashlib,argparse,datetime
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,default=Path('/workspace/chicago/chicago/4d'));ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();assert a.out.resolve().is_relative_to(Path('/tmp')), 'Review output must stay under /tmp';assert not a.out.exists();a.out.mkdir(parents=True);root=a.repo.resolve();reads={}
def read(path):
 p=Path(path);b=p.read_bytes();reads[str(p)]=b;return b
def load(path):return json.loads(read(path))
def sha(b):return hashlib.sha256(b).hexdigest()
expected=load(P/'proposed-cards.json');wanted=load(P/'proposed-ledger.json');proof=load(P/'proof.json');actual={p.stem:load(p) for p in (root/'data/residents/lodgers').glob('hh_*.json')};ledger=load(root/'data/reconstruction/1835_lodgers_seated.json');model=load(root/'data/reconstruction/1835_lodging_model.json')
def identity(cards):
 return {cid:{'head':c['head'],'division':c['division'],'place':c['lodging_household']['place'],'seated':c['lodging_household']['seated_from_the_layer'],'persons':[{k:({kk:vv for kk,vv in v.items() if kk!='note'} if k=='basis' else v) for k,v in p.items() if k!='note'} for p in c['persons']]} for cid,c in cards.items()}
assert identity(actual)==identity(expected) and len(actual)==22
assert ledger['seats']==wanted['seats'] and len(ledger['seats'])==52
for k in ('quota_basis','fills','child_fills','top_up_fills','youth_top_up_fills','working_fills','household_fills','capacity_allocation_basis','capacity_re_cut_since'):assert ledger[k]==wanted[k],k
m={p['id']:p for p in model['places']}
for h in ledger['houses']:assert h['beds_ordinary']==m[h['id']]['beds_ordinary'] and h['beds_crowded']==m[h['id']]['beds_crowded']
for c in actual.values():assert c['lodging_household']['beds_ordinary']==m[c['lodging_household']['place']]['beds_ordinary']
# Inventory all native writer output roots; baseline hashes came from the actual
# read-only prebuild proof, not a fresh guess after the write.
roots={'lodger_cards':root/'data/residents/lodgers','lodger_ledger':root/'data/reconstruction/1835_lodgers_seated.json','order_book':root/'data/reconstruction/1835_reconstruction_order_book.json','business_ledger':root/'data/reconstruction/1835_business_reconstruction.json','authored_businesses':root/'data/businesses/authored','staffing_order':root/'data/reconstruction/1835_staffing_mint_order.json'}
inventory=[]
for kind,path in roots.items():
 for p in sorted(path.rglob('*.json')) if path.is_dir() else [path]:
  b=read(p);before=proof['canonical_inputs_sha256'].get(str(p));inventory.append({'kind':kind,'path':str(p.relative_to(root)),'bytes':len(b),'before_sha256':before,'after_sha256':sha(b),'state':'exact' if before==sha(b) else 'changed' if before else 'baseline_not_captured'})
business=load(root/'data/reconstruction/1835_business_reconstruction.json');oldbusiness=json.loads((P.parent/'M-lodging-readonly-analysis/report.json').read_text())['business_ledger_leaf_changes']
for d in oldbusiness:
 x=business
 for key in d['path'].strip('/').split('/'):x=x[int(key)] if isinstance(x,list) else x[key]
 assert x==d['after']
guards=load(P/'guards.json');source_rows=[]
for item in guards['sources']:
 digest=sha(read(root/item['path']));assert digest==item['after'],item['path'];source_rows.append({'path':item['path'],'actual_sha256':digest,'matches_V2':True})
source_sha=source_rows[0]['actual_sha256'];basis_sha=guards['sources'][0]['after']
# Independent arithmetic makes any net/positive vacancy discrepancy explicit.
positive=sum(max(0,h['beds_ordinary']-h['occupancy_after']) for h in ledger['houses']);above=sum(max(0,h['occupancy_after']-h['beds_ordinary']) for h in ledger['houses']);net=sum(h['beds_ordinary']-h['occupancy_after'] for h in ledger['houses'])
measurement=ledger['measurement'];assert [measurement[k] for k in ('ordinary_night_beds_still_empty','ordinary_night_beds_slept_in','occupied_after_this_stage','occupants_above_ordinary_night_figure','ordinary_night_net_balance','allocation_authorized_empty_beds')]==[37,215,220,5,32,32]
assert ledger['capacity_allocation_basis']['initial_allocation_authorized_empty_beds']==32
staffing=load(root/'data/reconstruction/1835_staffing_mint_order.json');expected_staffing=load(P/'proposed-staffing-order.json');assert staffing==expected_staffing
assert actual==expected and ledger==wanted, 'Actual derived object differs from reviewed V2 proposal'
for p,b in reads.items():assert Path(p).read_bytes()==b,('Input moved while reviewing; retry a new snapshot',p)
result={'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'canonical_writes':False,'status':'PASS_IDENTITIES_CAPACITIES_COUNTERS_OUTPUT_INVENTORY_ONLY','households_exact':22,'person_identity_fields_exact':sum(len(c['persons']) for c in actual.values()),'seat_records_exact':52,'quota_basis_and_fill_counters_exact':True,'adopted_sources_exact_V2':source_rows,'full_card_semantics_exact_V2_proposal':actual==expected,'full_ledger_semantics_exact_V2_proposal':ledger==wanted,'positive_current_vacancies':positive,'above_ordinary_occupants':above,'net_current_bed_balance':net,'reported_empty_field':ledger['measurement']['ordinary_night_beds_still_empty'],'measurement_warning':'Accounting mismatch; this V2 review must refuse' if ledger['measurement']['ordinary_night_beds_still_empty']!=positive else None,'order_book_delta':next(x for x in inventory if x['kind']=='order_book'),'business_ledger_expected_six_capacities_confirmed':True,'full_staffing_order_semantics_exact_V2_proposal':True,'ordinary_beds_slept_in':measurement['ordinary_night_beds_slept_in'],'remaining_allocation_authorization':measurement['allocation_authorized_empty_beds'],'initial_allocation_authorization':32,'inventory':inventory,'all_inputs_stable_double_read':True,'boundary':'Read-only actual output identity/counter/capacity review, not fullgate/newsmoke/imageacceptance. Group-only business-check failure is a subset-vs-whole command boundary; unfiltered48records6groupsPASS is separate root log.'}
(a.out/'review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='inventory'},indent=2))
