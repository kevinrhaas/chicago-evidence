from pathlib import Path
import sys,os,json,hashlib,copy,types,contextlib,io,tempfile,ast
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;ROOT=Path('/workspace/chicago/chicago/4d');sys.path.insert(0,str(ROOT/'tools'));reads=set()
def audit(event,args):
 if event=='open':
  p,mode,flags=args
  if isinstance(p,(str,bytes,os.PathLike)):
   q=Path(p).resolve();write=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
   if write and not q.is_relative_to(P):raise RuntimeError('Forbidden write '+str(q))
   if not write and q.is_relative_to(ROOT):reads.add(str(q))
 if event in ('os.mkdir','os.remove','os.rmdir','os.rename'):
  q=Path(args[0]);fd=args[1] if event in ('os.remove','os.rmdir') and len(args)>1 else -1
  if not q.is_absolute() and isinstance(fd,int) and fd>=0:q=Path(os.readlink('/proc/self/fd/'+str(fd)))/q
  if not q.resolve().is_relative_to(P):raise RuntimeError('Forbidden mutation '+str(q))
 if event in ('subprocess.Popen','socket.connect'):raise RuntimeError('Forbidden effect '+event)
sys.addaudithook(audit)
def module(name):
 m=types.ModuleType(name);m.__file__=str(ROOT/'tools'/name);exec(compile((P/'candidate'/name).read_text(),str(P/'candidate'/name),'exec'),m.__dict__);return m
seat=module('seat_lodgers_1835.py');staff=module('staffing_mint_order_1835.py');cards,ledger=seat.fill();seat.refuse(cards,ledger);ledger['measurement']=seat.measurement(cards,ledger)
actual={p.stem:json.loads(p.read_text()) for p in (ROOT/'data/residents/lodgers').glob('hh_*.json')};old=json.loads((ROOT/'data/reconstruction/1835_lodgers_seated.json').read_text())
def signature(cs):return {i:(c['head'],c['division'],c['lodging_household']['place'],[{k:({kk:vv for kk,vv in v.items() if kk!='note'} if k=='basis' else v) for k,v in p.items() if k!='note'} for p in c['persons']]) for i,c in cs.items()}
assert signature(actual)==signature(cards) and ledger['seats']==old['seats'] and len(ledger['seats'])==52
for k in ('quota_basis','fills','child_fills','top_up_fills','youth_top_up_fills','working_fills','household_fills'):assert ledger[k]==old[k],k
m=ledger['measurement'];assert [m[k] for k in ('ordinary_night_beds_still_empty','ordinary_night_beds_slept_in','occupants_above_ordinary_night_figure','ordinary_night_net_balance','allocation_authorized_empty_beds')]==[37,215,5,32,32]
assert ledger['measurement']['the_two_counts_reconciled']['ordinary_night_beds_slept_in']==215
read=staff._load;staff._load=lambda path:copy.deepcopy(ledger) if Path(path)==staff.LODGERS_SEATED else read(path)
bound=staff.the_bed_bound(ledger);assert bound['ordinary_night_beds_slept_in']==215 and bound['occupied_after_this_stage']==220 and bound['allocation_authorized_empty_beds']==32
assert staff.lodging_mint_ceiling(bound)==32
order=staff.order(staff.build_data());before_mint=json.loads((ROOT/'data/reconstruction/1835_staffing_mint_order.json').read_text())['the_owner_s_ruling']['mintable_today'];assert order['the_owner_s_ruling']['mintable_today']==before_mint
# All original quota/crowded refusal functions remain exact; mathematical9d is
# deliberately replaced by a real opposing vacancy/overflow plus child test.
base=ast.parse((P/'baseline/seat_lodgers_1835.py').read_text());new=ast.parse((P/'candidate/seat_lodgers_1835.py').read_text())
for name in ('refuse','refuse_a_recut_under_the_draw'):
 assert ast.dump(next(x for x in base.body if isinstance(x,ast.FunctionDef) and x.name==name))==ast.dump(next(x for x in new.body if isinstance(x,ast.FunctionDef) and x.name==name))
# Every other original self-test statement is byte/AST unchanged except9d.
bself=next(x for x in base.body if isinstance(x,ast.FunctionDef) and x.name=='self_test');nself=next(x for x in new.body if isinstance(x,ast.FunctionDef) and x.name=='self_test')
oldstmt=next(x for x in bself.body if isinstance(x,ast.Expr) and isinstance(x.value,ast.Call) and x.value.args and isinstance(x.value.args[0],ast.Constant) and x.value.args[0].value=='drawing the children moves no bed')
filtered_b=[x for x in bself.body if x is not oldstmt]
filtered_n=[x for x in nself.body if not (isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('mixed','totals','no_children') for t in x.targets)) and not (isinstance(x,ast.Expr) and isinstance(x.value,ast.Call) and x.value.args and isinstance(x.value.args[0],ast.Constant) and x.value.args[0].value=='children take no ordinary bed; physical vacancies do not cancel overflow')]
assert [ast.dump(x) for x in filtered_b]==[ast.dump(x) for x in filtered_n]
tempfile.tempdir=str(P);logs={}
for name,func in [('lodger-selftest',seat.self_test),('allocation-regression',seat.capacity_preservation_self_test),('staffing-selftest',staff.cmd_self_test)]:
 out=io.StringIO()
 with contextlib.redirect_stdout(out):code=func()
 (P/(name+'.log')).write_text(out.getvalue());assert code==0,(name,out.getvalue());logs[name]='PASS'
# Persisted metadata must be a fixed point, including authorization provenance.
original_load=seat.load;seat.load=lambda path:copy.deepcopy(ledger) if Path(path)==seat.LEDGER else original_load(path)
c2,l2=seat.fill();seat.refuse(c2,l2);l2['measurement']=seat.measurement(c2,l2);assert c2==cards and l2==ledger
(P/'proposed-cards.json').write_text(json.dumps(cards,indent=2,ensure_ascii=False)+'\n');(P/'proposed-ledger.json').write_text(json.dumps(ledger,indent=2,ensure_ascii=False)+'\n');(P/'proposed-staffing-order.json').write_text(json.dumps(order,indent=2,ensure_ascii=False)+'\n')
inputs={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sorted(reads) if Path(p).is_file()}
result={'status':'PASS_LIGHT_UNAPPLIED_FOLLOWUP','canonical_writes':False,'people':157,'households':22,'seats_exact':52,'original_quota_crowded_refusal_AST_exact':True,'original_other_selftest_statements_AST_exact_except_corrected9d':True,'selftests':logs,'fixed_point':True,'accounting':{k:m[k] for k in ('ordinary_night_beds_still_empty','ordinary_night_beds_slept_in','occupied_after_this_stage','occupants_above_ordinary_night_figure','ordinary_night_net_balance','allocation_authorized_empty_beds')},'old_physical_vacancies':33,'historical_net_authorization':32,'staffing_actual_slept_in':215,'staffing_mint_ceiling':32,'staffing_mintable_today_unchanged':before_mint,'new_durable_tests':'Actual same-total recut preserves identities/seats/livecapacities/fixedpoint and persisteddate/crowded/classrefusals; opposingvacancy/overflow+child exclusion counterexample;37/99 physicalvacancy cannot enlarge32authorization;zero physical orzero authorization stopsceiling.','canonical_inputs_sha256':inputs}
(P/'proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='canonical_inputs_sha256'},indent=2))
