from pathlib import Path
import json,hashlib,difflib,ast
P=Path(__file__).resolve().parent;ROOT=Path('/workspace/chicago/chicago/4d');adopted=Path('/tmp/frame-integration/lodging-capacity-allocation-freeze/candidate/seat_lodgers_1835.py').read_text();assert (ROOT/'tools/seat_lodgers_1835.py').read_text()==adopted
s=adopted
start=s.index('        explanation = (',s.index('def publish_capacity_truth'))
end=s.index('        block["beds_ordinary"]',start)
s=s[:start]+'''        explanation = (
            f"This group was reconstructed using an earlier estimate of {before} "
            f"ordinary-night beds. The current estimate is {now}, or "
            f"{current[key]['beds_crowded']} when crowded. Revising that estimate "
            f"does not identify different residents. Their lodging here remains "
            f"reconstructed; dated evidence can replace this allocation.")
'''+s[end:]
start=s.index('        block["withdrawn_if"]',s.index('def publish_capacity_truth'));end=s.index('        for link ',start)
s=s[:start]+'''        block["withdrawn_if"] = (
            "Dated evidence identifying who lodged here, or reviewed changes to the "
            "building's availability, crowding limit or town population model. "
            "A revised ordinary-night estimate alone does not name new residents.")
'''+s[end:]
needle='    ledger["capacity_allocation_basis"] = basis\n';assert needle in s
s=s.replace(needle,'''    if "allocation_authorized_empty_beds" not in basis:
        # Preserve the historical staffing ceiling, which was NET room, not the
        # old positive per-house physical vacancy count (33 on this migration).
        basis["allocation_authorized_empty_beds"] = max(0,
            sum(h["beds_ordinary"] for h in allocated.values())
            - sum(h["occupancy_after"] for h in ledger["houses"]))
        basis["authorization_note"] = (
            "Carried historical planning authorization, formerly the net bed balance; "
            "not a claim that this many positive physical vacancies existed. "
            "Reweighting current capacities does not increase this authorization.")
    ledger["capacity_allocation_basis"] = basis
''',1)
helper='''def ordinary_bed_accounting(houses: list) -> dict:
    """Physical ordinary beds and overflow are distinct; keeper children take no bed."""
    return {
        "ordinary_night_beds_slept_in": sum(min(h["beds_ordinary"], h["occupancy_after"]) for h in houses),
        "ordinary_night_beds_still_empty": sum(max(0, h["beds_ordinary"] - h["occupancy_after"]) for h in houses),
        "occupants_above_ordinary_night_figure": sum(max(0, h["occupancy_after"] - h["beds_ordinary"]) for h in houses),
        "ordinary_night_net_balance": sum(h["beds_ordinary"] - h["occupancy_after"] for h in houses),
    }


'''
s=s.replace('def the_two_counts_reconciled(ledger: dict) -> dict:',helper+'def the_two_counts_reconciled(ledger: dict) -> dict:',1)
s=s.replace('        "ordinary_night_beds_slept_in": slept_in,','        **ordinary_bed_accounting(houses),',1)
s=s.replace('if slept_in >= beds and not _short else','if ordinary_bed_accounting(houses)["ordinary_night_beds_still_empty"] == 0 and not _short else',1)
s=s.replace('        "ordinary_night_beds_still_empty": beds - after,','''        **ordinary_bed_accounting(houses),
        "allocation_authorized_empty_beds": ledger["capacity_allocation_basis"]["allocation_authorized_empty_beds"],''',1)
start=s.index('    # 9d. A child takes no ordinary-night bed:');end=s.index('    # 9e.',start)
s=s[:start]+'''    # 9d. Children take no ordinary bed. Opposing ordinary overflow and a
    # vacancy cannot be cancelled into the physical vacancy count.
    mixed = [{"beds_ordinary": 3, "occupancy_after": 5, "minted_children": 2},
             {"beds_ordinary": 7, "occupancy_after": 2, "minted_children": 0}]
    totals = ordinary_bed_accounting(mixed)
    no_children = [dict(h, minted_children=0) for h in mixed]
    case("children take no ordinary bed; physical vacancies do not cancel overflow",
         totals == {"ordinary_night_beds_slept_in": 5,
                    "ordinary_night_beds_still_empty": 5,
                    "occupants_above_ordinary_night_figure": 2,
                    "ordinary_night_net_balance": 3}
         and ordinary_bed_accounting(no_children) == totals)

'''+s[end:]
s=s.replace('def main(argv) -> int:',(P/'regression.txt').read_text()+'def main(argv) -> int:',1)
s=s.replace('    if args.self_test:\n        return self_test()','    if args.self_test:\n        return self_test() or capacity_preservation_self_test()',1)
assert 'def ordinary_bed_accounting' in s
staff=(ROOT/'tools/staffing_mint_order_1835.py').read_text();t=staff
needle='    return {\n        "read_from": "data/reconstruction/1835_lodgers_seated.json",';assert needle in t
t=t.replace(needle,'''    for field in ("ordinary_night_beds_slept_in", "allocation_authorized_empty_beds"):
        if field not in measurement:
            raise Fault("lodging accounting lacks current occupancy and carried authorization")
    return {
        "read_from": "data/reconstruction/1835_lodgers_seated.json",''',1)
t=t.replace('"ordinary_night_beds_slept_in": measurement.get("occupied_after_this_stage"),','''"ordinary_night_beds_slept_in": measurement["ordinary_night_beds_slept_in"],
        "occupied_after_this_stage": measurement.get("occupied_after_this_stage"),
        "occupants_above_ordinary_night_figure": measurement.get("occupants_above_ordinary_night_figure"),
        "ordinary_night_net_balance": measurement.get("ordinary_night_net_balance"),
        "allocation_authorized_empty_beds": int(measurement["allocation_authorized_empty_beds"]),''',1)
t=t.replace('mintable_today = min(needing_a_bed, beds["ordinary_night_beds_still_empty"])','mintable_today = min(needing_a_bed, lodging_mint_ceiling(beds))',1)
helper='''def lodging_mint_ceiling(beds: dict) -> int:
    """Physical room alone does not enlarge the carried permission to mint."""
    return min(beds["ordinary_night_beds_still_empty"], beds["allocation_authorized_empty_beds"])


'''
t=t.replace('def the_bed_bound(lodgers: dict) -> dict:',helper+'def the_bed_bound(lodgers: dict) -> dict:',1)
t=t.replace('f"stand empty in the "','f"stand physically empty, with {beds[\'allocation_authorized_empty_beds\']} "\n                    f"remaining under the carried allocation authorization, in the "',1)
t=t.replace('f"against {beds[\'ordinary_night_beds_still_empty\']} empty. So "','f"against {beds[\'ordinary_night_beds_still_empty\']} physically empty and "\n                f"{beds[\'allocation_authorized_empty_beds\']} under the carried authorization. So "',1)
marker='    # 12. THE HOUSEHOLD AXIS IS THE STAFFING MODEL';assert marker in t
t=t.replace(marker,'''    # Physical vacancies may rise after a weight recut, but permission must not.
    if not (lodging_mint_ceiling({"ordinary_night_beds_still_empty": 37,
                                 "allocation_authorized_empty_beds": 32}) == 32
            and lodging_mint_ceiling({"ordinary_night_beds_still_empty": 99,
                                      "allocation_authorized_empty_beds": 32}) == 32
            and lodging_mint_ceiling({"ordinary_night_beds_still_empty": 0,
                                      "allocation_authorized_empty_beds": 32}) == 0
            and lodging_mint_ceiling({"ordinary_night_beds_still_empty": 37,
                                      "allocation_authorized_empty_beds": 0}) == 0):
        failures.append("physical vacancy recut changed carried mint authorization")

'''+marker,1)
for name,old,new in [('seat_lodgers_1835.py',adopted,s),('staffing_mint_order_1835.py',staff,t)]:
 ast.parse(new);(P/'baseline'/name).write_text(old);(P/'candidate'/name).write_text(new)
patch=''.join(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/chicago/4d/tools/'+name,tofile='b/chicago/4d/tools/'+name)) for name,old,new in [('seat_lodgers_1835.py',adopted,s),('staffing_mint_order_1835.py',staff,t)])
(P/'followup.patch').write_text(patch);(P/'guards.json').write_text(json.dumps({'adopted_baseline_sha256':hashlib.sha256(adopted.encode()).hexdigest(),'sources':[{'path':'tools/'+name,'before':hashlib.sha256(old.encode()).hexdigest(),'after':hashlib.sha256(new.encode()).hexdigest()} for name,old,new in [('seat_lodgers_1835.py',adopted,s),('staffing_mint_order_1835.py',staff,t)]]},indent=2)+'\n')
print('Prepared two-file follow-up only; no canonical writes')
