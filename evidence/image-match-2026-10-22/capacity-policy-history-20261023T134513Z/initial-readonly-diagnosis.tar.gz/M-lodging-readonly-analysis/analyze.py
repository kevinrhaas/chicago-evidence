from pathlib import Path
import sys,os,json,hashlib,copy,importlib,collections,difflib
sys.dont_write_bytecode=True
OUT=Path('/tmp/frame-integration/M-lodging-readonly-analysis');ROOT=Path('/workspace/chicago/chicago/4d');TOOLS=ROOT/'tools';reads=set()
def audit(event,args):
 if event=='open':
  path,mode,flags=args
  if isinstance(path,(str,bytes,os.PathLike)):
   p=Path(path).resolve()
   writing=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
   if writing and not p.is_relative_to(OUT):raise RuntimeError('FORBIDDEN WRITE '+str(p))
   if not writing and p.is_relative_to(ROOT):reads.add(str(p))
 if event in ('os.remove','os.rename','os.mkdir','subprocess.Popen','socket.connect'):raise RuntimeError('FORBIDDEN EFFECT '+event)
sys.addaudithook(audit);sys.path.insert(0,str(TOOLS));seat=importlib.import_module('seat_lodgers_1835');biz=importlib.import_module('reconstruct_businesses_1835')
load=lambda p:json.loads(Path(p).read_text())
old_model=load('/tmp/frame-integration/closed-M-focused-repairs-20261023/focused-proofs/before/data/reconstruction/1835_lodging_model.json');new_model=seat.lodging_model();old_places={x['id']:x for x in old_model['places']};new_places={x['id']:x for x in new_model['places']}
capacity=[{'id':i,'ordinary':[old_places[i]['beds_ordinary'],r['beds_ordinary']],'crowded':[old_places[i]['beds_crowded'],r['beds_crowded']],'storeys':[old_places[i]['storeys'],r['storeys']],'floor':[old_places[i]['enclosed_floor_m2'],r['enclosed_floor_m2']]} for i,r in new_places.items() if r!=old_places[i]]
current_cards,current_ledger=seat.fill();seat.refuse(current_cards,current_ledger);current_ledger['measurement']=seat.measurement(current_cards,current_ledger)
original_model_reader=seat.lodging_model
seat.lodging_model=lambda:copy.deepcopy(old_model)
try:old_cards,old_ledger=seat.fill();seat.refuse(old_cards,old_ledger);old_ledger['measurement']=seat.measurement(old_cards,old_ledger)
finally:seat.lodging_model=original_model_reader
ondisk={p.stem:load(p) for p in seat.MINTED.glob('hh_*.json')};diskledger=load(seat.LEDGER)
def persons(cards):return {p['id']:{'household':cid,'place':c.get('lodging_household',{}).get('place'),'name':p.get('name'),'person':p} for cid,c in cards.items() for p in c['persons']}
def delta(a,b):
 aa=persons(a);bb=persons(b)
 return {'households_removed':sorted(set(a)-set(b)),'households_added':sorted(set(b)-set(a)),'households_changed':sorted(i for i in set(a)&set(b) if a[i]!=b[i]),'persons_removed':[aa[i] for i in sorted(set(aa)-set(bb))],'persons_added':[bb[i] for i in sorted(set(bb)-set(aa))],'persons_changed':[{ 'id':i,'before':aa[i],'after':bb[i]} for i in sorted(set(aa)&set(bb)) if aa[i]!=bb[i]]}
card_delta=delta(ondisk,current_cards);old_delta=delta(ondisk,old_cards)
# Actual native record/ledger derivation: reads disk but writes nothing.
groups=biz.built_groups();built={g:biz.build_group(g) for g in groups};want_business_ledger=biz.ledger(built);business_disk=load(biz.LEDGER)
record_changes=[]
for g,rows in built.items():
 for row in rows:
  p=biz.AUTHORED/(row['id']+'.json')
  if not p.exists() or load(p)!=row:record_changes.append({'group':g,'id':row['id'],'exists':p.exists(),'before':load(p) if p.exists() else None,'after':row})
def leafdiff(a,b,path=''):
 if isinstance(a,dict) and isinstance(b,dict):
  out=[]
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b:out.append({'path':path+'/'+k,'before':a.get(k),'after':b.get(k)})
   else:out+=leafdiff(a[k],b[k],path+'/'+k)
  return out
 if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):
  return [d for i,(x,y) in enumerate(zip(a,b)) for d in leafdiff(x,y,path+'/'+str(i))]
 return [] if a==b else [{'path':path,'before':a,'after':b}]
all_delta=leafdiff(diskledger,current_ledger)
report={'status':'READ_ONLY_NATIVE_SIMULATION','canonical_write_guard':'Audit hook forbids writes outside reportfolder plus remove/rename/mkdir/subprocess/network; Python bytecode disabled','capacity_changes':capacity,'capacity_totals':{'old_ordinary':sum(x['beds_ordinary'] for x in old_places.values()),'new_ordinary':sum(x['beds_ordinary'] for x in new_places.values()),'old_crowded':sum(x['beds_crowded'] for x in old_places.values()),'new_crowded':sum(x['beds_crowded'] for x in new_places.values())},'native_new_refuse':'PASS','disk_vs_new_cards':card_delta,'disk_vs_old_model_cards':old_delta,'seats_before':diskledger['seats'],'seats_after':current_ledger['seats'],'all_lodging_ledger_leaf_changes':all_delta,'native_old_measurement':old_ledger['measurement'],'native_new_measurement':current_ledger['measurement'],'business_groups':groups,'business_record_changes':record_changes,'business_ledger_leaf_changes':leafdiff(business_disk,want_business_ledger),'quota_basis_current_vs_disk_changes':leafdiff(diskledger['quota_basis'],current_ledger['quota_basis']),'canonical_inputs_sha256':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sorted(reads) if Path(p).is_file()}}
(OUT/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
summary={'capacity_changes':capacity,'new_cards':{k:(len(v) if isinstance(v,list) else v) for k,v in card_delta.items()},'old_model_cards':{k:len(v) for k,v in old_delta.items()},'seat_changes':leafdiff(diskledger['seats'],current_ledger['seats']),'business_record_changes':len(record_changes),'business_ledger_leaf_changes':report['business_ledger_leaf_changes'],'lodging_ledger_change_count':len(all_delta),'quota_basis_leaf_change_count':len(report['quota_basis_current_vs_disk_changes'])}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n');print(json.dumps(summary,indent=2,ensure_ascii=False))
