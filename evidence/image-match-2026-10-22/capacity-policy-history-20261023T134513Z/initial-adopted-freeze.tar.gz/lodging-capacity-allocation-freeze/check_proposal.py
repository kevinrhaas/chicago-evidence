from pathlib import Path
import sys,os,json,hashlib,types,copy,ast,contextlib,io,tempfile
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;ROOT=Path('/workspace/chicago/chicago/4d');sys.path.insert(0,str(ROOT/'tools'));writes=[];reads=set()
def audit(event,args):
 if event=='open':
  path,mode,flags=args
  if isinstance(path,(str,bytes,os.PathLike)):
   q=Path(path).resolve();write=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
   if write:
    if not q.is_relative_to(P):raise RuntimeError('Forbidden write '+str(q))
    writes.append(str(q))
   elif q.is_relative_to(ROOT):reads.add(str(q))
 if event in ('os.mkdir','os.remove','os.rmdir','os.rename'):
  q=Path(args[0])
  fd=args[1] if event in ('os.remove','os.rmdir') and len(args)>1 else -1
  if not q.is_absolute() and isinstance(fd,int) and fd>=0:q=Path(os.readlink('/proc/self/fd/'+str(fd)))/q
  q=q.resolve()
  if not q.is_relative_to(P):raise RuntimeError('Forbidden mutation '+str(q))
 if event in ('subprocess.Popen','socket.connect'):raise RuntimeError('Forbidden effect '+event)
sys.addaudithook(audit)
import seat_lodgers_1835 as original
source=(P/'candidate/seat_lodgers_1835.py').read_text();candidate=types.ModuleType('candidate_lodgers');candidate.__file__=str(ROOT/'tools/seat_lodgers_1835.py');exec(compile(source,str(P/'candidate/seat_lodgers_1835.py'),'exec'),candidate.__dict__)
oldcards={q.stem:json.loads(q.read_text()) for q in original.MINTED.glob('hh_*.json')};oldledger=json.loads(original.LEDGER.read_text());livemodel=original.lodging_model();read_model=candidate.lodging_model
cards,ledger=candidate.fill();candidate.refuse(cards,ledger);ledger['measurement']=candidate.measurement(cards,ledger)
def identities(cards):
 return {cid:{'head':c['head'],'division':c['division'],'place':c['lodging_household']['place'],'seated':c['lodging_household']['seated_from_the_layer'],'persons':[{k:({kk:vv for kk,vv in v.items() if kk!='note'} if k=='basis' else v) for k,v in p.items() if k!='note'} for p in c['persons']]} for cid,c in cards.items()}
assert identities(cards)==identities(oldcards),'Person/card identity, sex/band/trade/seed/association/employment changed'
assert ledger['seats']==oldledger['seats'];assert ledger['quota_basis']==oldledger['quota_basis']
for k in ('fills','child_fills','top_up_fills','youth_top_up_fills','working_fills','household_fills'):assert ledger[k]==oldledger[k],k
for h in ledger['houses']:
 live=next(x for x in livemodel['places'] if x['id']==h['id']);assert h['beds_ordinary']==live['beds_ordinary'] and h['beds_crowded']==live['beds_crowded']
for c in cards.values():
 live=next(x for x in livemodel['places'] if x['id']==c['lodging_household']['place']);assert c['lodging_household']['beds_ordinary']==live['beds_ordinary']
 for person in c['persons']:
  assert "from the lodging model's ordinary-night figure" not in (person.get('basis') or {}).get('note','')
  assert 'the town model says ' not in person.get('note','') or 'ordinary night' not in person.get('note','')
# Commit the proposed ledger only in memory: second fill is an actual fixed point.
real_load=candidate.load
candidate.load=lambda path:copy.deepcopy(ledger) if Path(path)==candidate.LEDGER else real_load(path)
c2,l2=candidate.fill();candidate.refuse(c2,l2);l2['measurement']=candidate.measurement(c2,l2)
assert c2==cards and l2==ledger,'Not a fixed point after persisted capacity basis'
candidate.load=real_load
# Fifteen genuinely changed bed-only re-cuts from the old committed allocation,
# not unchanged fixtures or regenerated quota. A control uses the unchanged native writer.
basis={h['id']:h['beds_ordinary'] for h in oldledger['houses']};fixtures=[]
if '--reuse-passed-recut-proof' in sys.argv:
 assert hashlib.sha256(source.encode()).hexdigest()==json.loads((P/'source-guards.json').read_text())['candidate_sha256']
 fixtures=json.loads((P/'recut-fixtures.json').read_text())
 assert len(fixtures)==15 and all(x['native_unfrozen_redeal'] and x['frozen_identity_seats_exact'] and x['live_capacity_metadata_exact'] for x in fixtures)
else:
 for index,place in enumerate(livemodel['places']):
  if len(fixtures)==15:break
  donors=[x for x in livemodel['places'] if x['class']==place['class'] and x['id']!=place['id'] and basis[x['id']]>1]
  donor=max(donors,key=lambda x:(basis[x['id']],x['id']))
  model=copy.deepcopy(livemodel)
  for row in model['places']:row['beds_ordinary']=basis[row['id']]
  for row in model['places']:
   if row['id']==place['id']:row['beds_ordinary']+=1
   if row['id']==donor['id']:row['beds_ordinary']-=1
  old_reader=original.lodging_model;original.lodging_model=lambda:copy.deepcopy(model)
  try:control,cl=original.fill()
  finally:original.lodging_model=old_reader
  assert identities(control)!=identities(oldcards) or cl['seats']!=oldledger['seats'],'Fixture did not cause an actual native redeal'
  candidate.lodging_model=lambda:copy.deepcopy(model)
  frozen,fl=candidate.fill();candidate.refuse(frozen,fl)
  assert identities(frozen)==identities(oldcards) and fl['seats']==oldledger['seats']
  assert all(h['beds_ordinary']==next(x['beds_ordinary'] for x in model['places'] if x['id']==h['id']) for h in fl['houses'])
  fixtures.append({'plus_one':place['id'],'minus_one':donor['id'],'native_unfrozen_redeal':True,'frozen_identity_seats_exact':True,'live_capacity_metadata_exact':True})
assert len(fixtures)==15;candidate.lodging_model=read_model
(P/'recut-fixtures.json').write_text(json.dumps(fixtures,indent=2)+'\n')
# Fail closed on changed eligibility, dates, class total and a single overcrowded roof.
refusals=[]
for kind in ('eligible_house_removed','live_crowded_below_occupancy','ordinary_class_total_changed','dated_availability_changed'):
 model=copy.deepcopy(livemodel);dates_reader=candidate.capacity_availability
 if kind=='eligible_house_removed':model['places'].pop()
 if kind=='live_crowded_below_occupancy':
  target=next(h for h in oldledger['houses'] if h['occupancy_after']>0);next(x for x in model['places'] if x['id']==target['id'])['beds_crowded']=target['occupancy_after']-1
 if kind=='ordinary_class_total_changed':model['places'][0]['beds_ordinary']+=1
 if kind=='dated_availability_changed':
  candidate.load=lambda path:copy.deepcopy(ledger) if Path(path)==candidate.LEDGER else real_load(path)
  def dates(m):
   value=dates_reader(m);value['target_date']='1835-07-02';return value
  candidate.capacity_availability=dates
 candidate.lodging_model=lambda:copy.deepcopy(model)
 try:candidate.fill()
 except SystemExit as ex:refusals.append({'case':kind,'refusal':str(ex)})
 else:raise AssertionError('Did not refuse '+kind)
 finally:candidate.lodging_model=read_model;candidate.capacity_availability=dates_reader;candidate.load=real_load
# All original assertions and self-test code remain exact. Run its actual self-tests.
base_ast=ast.parse((P/'baseline/seat_lodgers_1835.py').read_text());new_ast=ast.parse(source)
for name in ('refuse','refuse_a_recut_under_the_draw','self_test'):
 assert ast.dump(next(n for n in base_ast.body if isinstance(n,ast.FunctionDef) and n.name==name))==ast.dump(next(n for n in new_ast.body if isinstance(n,ast.FunctionDef) and n.name==name))
tempfile.tempdir=str(P);log=io.StringIO()
with contextlib.redirect_stdout(log):result=candidate.self_test()
(P/'original-selftest.log').write_text(log.getvalue());assert result==0,log.getvalue()
(P/'proposed-ledger.json').write_text(json.dumps(ledger,indent=2,ensure_ascii=False)+'\n')
(P/'proposed-cards.json').write_text(json.dumps(cards,indent=2,ensure_ascii=False)+'\n')
inputs={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sorted(reads) if Path(p).is_file()}
summary={'status':'PASS_LIGHT_ACTUAL_NATIVE_PROPOSAL_ONLY','canonical_writes':False,'identical_household_ids':len(cards),'identical_person_ids_names_fields_except_explicit_capacity_prose':sum(len(c['persons']) for c in cards.values()),'seats_exact':len(ledger['seats']),'quota_basis_and_all_fill_counters_exact':True,'live_capacity_recut':ledger['capacity_re_cut_since']['houses'],'actual_fixed_point_after_persisted_basis':True,'genuine_recut_fixtures':fixtures,'fail_closed_fixtures':refusals,'original_quota_refusal_and_selftest_AST_exact':True,'original_selftest_return':result,'current_measurement':ledger['measurement'],'canonical_inputs_sha256':inputs,'runtime_boundary':'Python read-only native derivation, no browser/Blender/fullgate/canonicalbuild; all writes audited under proposalfolder only.'}
(P/'proof.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('canonical_inputs_sha256','current_measurement','genuine_recut_fixtures')},indent=2))
