# Carried ordinary-capacity allocation basis — proposed, canonical UNAPPLIED

This is the root-authorized bounded downstream T-3055 proposal. A three-storey Tremont changes its enclosed floor from278.59 to417.88m². The unchanged lodging model reallocates the inn class's fixed90ordinary beds: Exchange11→10, Mansion5→4, Steamboat11→10, Tremont12→17, Western15→14, Wolf4→3. Every crowded figure stays35. Current model totals remain252ordinary/728crowded beds across28places.

Without this extension, actual native `fill()` passes quota refusal but changes11cards, removesWolf's lodging card, retires30invented IDs, adds29, changes18retained people and moves7existing solitary seats. Those moves include AlexanderN.Fullerton and MajorHandy. Eight retired IDs are already in the held refamily roster; an employment seat also adopts AlexisLaframboise. Repeating the current quota freeze does not fix this: its buckets, ceilings and house order are already unchanged. The separate read-only diagnosis is `/tmp/frame-integration/M-lodging-readonly-analysis/`.

## One-file proposed change

`capacity-allocation-freeze.patch` changes ONLY `chicago/4d/tools/seat_lodgers_1835.py`. It imports copy, extracts the existing fill body into `_fill_from_allocation(model)`, and wraps it with a carried ordinary-bed allocation basis plus truthful current-capacity reporting. The existing fill body has no allocation/threshold rewrite; only its model is passed explicitly. Original quota/crowded refusal and self-test code is AST-identical.

On first migration, `capacity_allocation_basis` bootstraps ordinary figures from this writer's committed ledger `houses`; it records their exact source-ledger SHA, current eligible-house/dates contract and household/keeper/occupancy identity contract. Subsequent builds carry this explicit block. The first migration records current date signatures; the old ledger did not hold them, so it does NOT pretend to recover an older unpublished date snapshot. Parent must review that current bootstrap is the intended ordinary-only reweighting. No person is frozen by copying arbitrary stale cards: the actual existing native deterministic writer re-derives them using its original room/ceiling/house order and the carried ordinary weights.

Only allocation/mint/free-bed seat ordering sees those carried ordinary values. Ledger house fields, household bed metadata, ordinary-filled flags and measurement use CURRENT live capacities. `allocation_beds_ordinary` and `capacity_re_cut_since` state old/current figures explicitly. Person basis prose identifies the committed allocation value; current house/association prose reports both figures. The historical nested quota/top-up bed counts are explicitly identified as allocation-basis accounting, not a report of current live room. No stale current-capacity label is retained and no person/household/seat is newly minted by a weight recut.

This is a deliberate extension of the preservation policy: a smaller ordinary weight alone no longer retires people; source replacement and reviewed retirement remain possible, with availability/house identity, quota and crowded-capacity checks kept. Eligible-house/date/keeper/occupancy changes or a changed class total require review and refuse. A changed crowded cap refuses; a live cap below held occupancy has a specific refusal. Existing `refuse()` still checks quota floors, household fills, crowded ceilings including keeper children, uniqueness, real-name collisions and kin. No assertion or threshold is weakened.

## Actually executed light proof

`proof.json`, `recut-fixtures.json`, `original-selftest.log` and exact proposed derived outputs preserve:

- All22household IDs,157person identities/names/fields except explicitly qualified capacity prose, geographical divisions/house IDs and all52existing seat records exact versus committed.
- Entire original quota basis and all person/child/top-up/working/household fill counters exact. Eight previously held people are not retired; all existing people remain.
- Six truthful current capacities and a stable explicitly stored old allocation basis. A second actual native fill reading the proposed ledger in memory is byte-identical for cards/ledger: fixed point.
- Fifteen distinct same-total ordinary-only weight fixtures. Each actually causes an unfrozen native re-deal; with the candidate each preserves identities/seats and reports the changed live capacities correctly.
- Fail-closed removed eligible house, changed class total, changed dated availability after basis persistence, and one crowded ceiling below existing occupancy.
- All28 ORIGINAL self-test cases pass; original refusal/self-test AST exact. Python audit denies writes outside this proposal directory, subprocesses and network; no canonical build/write, fullgate, browser or Blender ran.

Two checker-only issues were resolved without modifying production assertions: the date-change fixture initially tested an unpersisted bootstrap rather than a persisted basis, and the write audit initially misresolved relative `dir_fd` tempfile cleanup as a canonical path. The corrected fixture checks persisted dates; the corrected audit resolves the actual directory descriptor. All15re-cut comparisons had already passed on the same candidate twice before cleanup; the final targeted audit/self-test run reused that recorded15fixture proof after checking the unchanged candidate hash. `validation-history.json` records this boundary. No failure is represented as an app PASS.

## Parent review and conditional native sequence

Do not auto-apply this package. Review source guards, patch and proof first. `git -C /workspace/chicago apply --check .../capacity-allocation-freeze.patch` actually passed; no apply was performed.

If parent adopts the policy and guarded one-file change, run the NATIVE `seat_lodgers_1835.py --build` before the ordered tail. Expect the same22cards, zero retirement/newIDs, explicit capacity prose/metadata and ledger-basis updates; its native order-book fill writer still runs, so inspect the resulting book delta and checks. Verify exact identity/seat/counter preservation against this receipt. Then use native `reconstruct_businesses_1835.py --group lodging_river_and_transport --build` for the six business-ledger capacity cells, followed by its `--check`. Actual read-only derivation shows all19authored records in that group and every authored group unchanged and its fill counts already exact; no new firm/proprietor/name is needed. The native build still invokes the order-book rederive, so inspect that result rather than assume no outputs can move.

Then parent runs the existing ordered derivation/compile tail from its appropriate earliest changed input, publishers, lodging/business readers and strict preflight; do not assume a55-step suffix alone owns these two currently unplaced writers. No whole-family/person re-freeze, held-roster reset or manual person deletion is proposed. Original image cases stayopen/differs, and prior card/flag QA is not a new full smoke/fullgate result. Parent owns all canonical execution, scope review and final-head checks.

`proposed-cards.json` and `proposed-ledger.json` are REVIEW OUTPUTS ONLY. Never copy them wholesale over current research; the supported writer must create actual current outputs after source adoption. No ticket/claim/PR/merge action was performed.
