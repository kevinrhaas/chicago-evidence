# T-2385 — actual isolated three-storey proposal preview

Status: exported/rendered proposal, visually reviewed as **differs**. No tracked file, manifest, publisher, accepted reference view, ticket state or branch was changed by this preview. This is neither the official content bake nor freshness/image-match acceptance. The parent may integrate the implementation after review; T-2385 remains open.

## Actual results

Pinned `/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender` ran successfully as **Blender 4.5.3 LTS**. `../export_preview.py` imported copied proposed generator/parameter/data inputs, reused the project's actual UV and GLB export functions, and wrote only this /tmp workspace. It did not call the manifest-producing `build.py`.

- Proposal GLB: `assets/gltf/tremont_house_1__frame_1833.proposal.glb`, 345,716 bytes, SHA256 `31a869a3b31062846b6f0bde37401e33b4ac09900682419801d8670a40868b6d`.
- Source Blender mesh: 8,634 vertices, 2,159 polygons, zero zero-area polygons, confidence range 0.5–1.0. Material colours/roughnesses and bounds are in `blender-preview-report.json`.
- The actual Blender mesh/material/confidence signature of the old Tremont record was identical when built by baseline and proposed modules with this new option disabled. Baseline inputs are snapshotted under `../baseline/`.
- Exported GLB inspection: version 2, eight primitives; every primitive carries `_CONFIDENCE`, normals and UVs; structure/phase extras retained. `glb-inspection.json` records materials and contract details. No AO was baked.
- `tools/photo_match.mjs` exited 0 using installed Chromium from this isolated root and an explicit `--glb` path, bypassing manifests. Its browser/server closed. Logs: `blender-preview.log`, `photo-match-preview.log`.

The Blender log contains failed optional extension-cache writes to the read-only home directory; the export and final receipt succeeded. No package installation or system Blender was used.

## Actual comparison

`review/gifford-provisional-side-by-side.jpg` and `review/gifford-provisional-render.png` were opened and inspected. The proposal visibly replaces the former two-storey blank-gable block with three floors, a three-bay shuttered short gable, five-bay shuttered long elevation and centred ground entries. Those broad count/occurrence differences are fixed in the /tmp review record.

It still **differs**. The gable lunette is absent. Both doors start at grade instead of the picture's raised landings/steps. The flagstaff and flag are absent. Only two simple roof stacks remain, and source-specific stack details are unresolved. The near roof ridge is roughly y=260 against the drawing's y=277 in this framing; its retained 38-degree pitch needs refinement. Opening vertical stations, sash/shutter details and material tones still require work. Surrounding storefronts/walk/road/people are omitted context. Colour and hidden elevations remain reconstructed because the monochrome view cannot establish them.

The new provisional camera uses the previous six manual source picks and the actual proposed **15.24 × 9.14 × 7.8 m** envelope. Point RMS is **3.546 px**, maximum **6.866 px**; no bound was reached. This is a framing fit to a reconstructed envelope, not a solved historical camera or evidence for geographic/metric/date changes. `review/camera-fit.json` preserves all picks, predictions and residuals. The roof/lunette/stacks were not fitted by those six wall-corner points.

## Attribution and recovery

Source: N. Roswell Gifford, reproduced by Chicagology as “Tremont House No. 1”, https://chicagology.com/prefire/prefire021/, `gifford_tremont_house_no_1`. Owner-approved attributed project reference use on 2026-10-22; no public-domain determination is asserted. The image is undated within the first house's 1833-1839 life, so using every feature at 1835 remains an explicit inference.

`../run_preview.sh` reproduces export plus comparison only after coordination with the parent (guard `T2385_PARENT_RELEASED=1`); the vendor-JS and Playwright symlinks read the existing shared workspace. Restore their targets or update the fixture paths in another workspace. `../T-2385.patch` remains unapplied, with focused tests and build-scope notes outside this preview root. All 23 frame_tavern recipes still require refresh if integrating the edited geometry module; this preview did not restamp any recipe.
