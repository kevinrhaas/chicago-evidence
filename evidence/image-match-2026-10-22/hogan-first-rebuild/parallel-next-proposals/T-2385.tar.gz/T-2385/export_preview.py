"""Isolated T-2385 preview fixture. Run only when parent releases local CPU gate.
Writes exclusively under /tmp/chicago-next-model/T-2385/preview-root.
This is not a manifest-producing content bake or an accepted image match.
"""
from __future__ import annotations
import hashlib, importlib.util, json, math, pathlib, sys
import bpy
assert bpy.app.version[:3] == (4,5,3), f'Use pinned Blender 4.5.3, got {bpy.app.version_string}'
ROOT=pathlib.Path('/workspace/chicago/chicago/4d')
OUT=pathlib.Path('/tmp/chicago-next-model/T-2385')
PROPOSED=OUT/'proposed'
PREVIEW=OUT/'preview-root'
sys.path[:0]=[str(PROPOSED/'generators'),str(ROOT/'generators')]
import archetypes
archetypes.__path__.append(str(ROOT/'generators/archetypes'))
from archetypes import frame_tavern as proposed
from archetypes import frame_tavern_params as params
from common.mesh import reset_scene
# Reuse actual project UV/export functions, but bypass build.py and every manifest.
import emit
assert pathlib.Path(proposed.__file__).resolve()==PROPOSED/'generators/archetypes/frame_tavern.py'
assert pathlib.Path(params.__file__).resolve()==PROPOSED/'generators/archetypes/frame_tavern_params.py'

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod;spec.loader.exec_module(mod);return mod
original=load('original_frame_tavern_preview',OUT/'baseline/generators/archetypes/frame_tavern.py')
original_params=load('original_frame_tavern_params_preview',OUT/'baseline/generators/archetypes/frame_tavern_params.py')

def material_spec(mat):
    bsdf=mat.node_tree.nodes.get('Principled BSDF') if mat.node_tree else None
    return {'name':mat.name,'base_color':list(bsdf.inputs['Base Color'].default_value) if bsdf else None,'roughness':bsdf.inputs['Roughness'].default_value if bsdf else None}

def signature(ob):
    me=ob.data
    return {'vertices':[[float(c) for c in v.co] for v in me.vertices],
            'faces':[list(p.vertices) for p in me.polygons],
            'material_indices':[p.material_index for p in me.polygons],
            'confidence':[v.value for v in me.attributes['_CONFIDENCE'].data],
            'materials':[material_spec(m) for m in me.materials]}

# Actual Blender-level default treatment must stay unchanged with opt-in disabled.
legacy=json.loads((OUT/'baseline/data/structures/tremont_house_1.json').read_text())
reset_scene();before=signature(original.build(original_params.from_phase(legacy['phases'][0],legacy),'tremont_default'))
reset_scene();after=signature(proposed.build(params.from_phase(legacy['phases'][0],legacy),'tremont_default'))
assert before==after, 'Disabled option changed legacy Tremont mesh/material/confidence'
default_hash=hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest()

rec=json.loads((PROPOSED/'data/structures/tremont_house_1.json').read_text());phase=rec['phases'][0]
reset_scene();ob=proposed.build(params.from_phase(phase,rec),rec['id']);me=ob.data
assert len(me.vertices)>0 and len(me.polygons)>0
assert all(math.isfinite(c) for v in me.vertices for c in v.co)
confidence=[v.value for v in me.attributes['_CONFIDENCE'].data]
assert all(0<=c<=1 for c in confidence)
zero_area=sum(p.area<1e-12 for p in me.polygons)
assert zero_area==0, f'{zero_area} degenerate Blender polygons'
report={'state':'proposal-only isolated Blender preview, not official bake/freshness or match acceptance','blender_version':bpy.app.version_string,'generator':str(pathlib.Path(proposed.__file__).resolve()),'parameters':str(pathlib.Path(params.__file__).resolve()),'legacy_default_unchanged':True,'legacy_geometry_material_confidence_sha256':default_hash,'vertices':len(me.vertices),'polygons':len(me.polygons),'zero_area_polygons':zero_area,'bounds_xyz':[[min(v.co[i] for v in me.vertices) for i in range(3)],[max(v.co[i] for v in me.vertices) for i in range(3)]],'confidence_min_max':[min(confidence),max(confidence)],'materials':[material_spec(m) for m in me.materials],'source_id':'gifford_tremont_house_no_1','asset_use':'owner-approved project reference with attribution; no public-domain assertion','source_credit':'N. Roswell Gifford; reproduced by Chicagology as Tremont House No. 1','source_url':'https://chicagology.com/prefire/prefire021/','manifest_written':False,'ao_baked':False}
emit.unwrap(ob)
out=PREVIEW/'assets/gltf/tremont_house_1__frame_1833.proposal.glb'
emit.export_glb(ob,rec['id'],phase['id'],out)
report['glb']=str(out);report['glb_bytes']=out.stat().st_size;report['glb_sha256']=hashlib.sha256(out.read_bytes()).hexdigest()
(PREVIEW/'blender-preview-report.json').write_text(json.dumps(report,indent=2)+'\n')
print('T2385_PREVIEW_OK '+json.dumps({k:report[k] for k in ['blender_version','vertices','polygons','zero_area_polygons','legacy_default_unchanged','glb_bytes','glb_sha256']}))
