from pathlib import Path
import difflib,json
root=Path('/workspace/chicago')
out=Path('/tmp/chicago-next-model/T-2376')
paths=['chicago/4d/generators/archetypes/frame_tavern_params.py','chicago/4d/generators/archetypes/frame_tavern.py','chicago/4d/data/structures/green_tree_tavern.json']
old={p:(root/p).read_text() for p in paths}
new=dict(old)
p=paths[0]
s=new[p]
def once(text,before,after):
 assert text.count(before)==1,(before,text.count(before))
 return text.replace(before,after,1)
s=once(s,'    "upper_windows", "stovepipes", "rear_ell_door",','    "upper_windows", "stovepipes", "rear_ell_door", "eaves_bays",')
s=once(s,'    upper_windows: int | None = None\n','''    upper_windows: int | None = None

    # A pictured gable-front eaves wall may state its own bay count (T-2376).
    # Sparse overrides: x_min/x_max only; a face not named retains the existing
    # footprint-derived count. This does not transfer one pictured elevation's
    # evidence to the unpictured opposite wall. A ground-floor side entrance
    # still replaces one of that face's bays, as before.
    eaves_bays: dict[str, int] = field(default_factory=dict)
''')
anchor='''        if (not isinstance(self.stovepipes, int) or isinstance(self.stovepipes, bool)
'''
block='''        if not isinstance(self.eaves_bays, dict):
            raise ParamError("eaves_bays must map x_min/x_max faces to whole bay counts")
        if self.eaves_bays and self.elevation_scheme != "gable_front":
            raise ParamError("eaves_bays is read by the gable_front scheme only")
        for face, bays in self.eaves_bays.items():
            if face not in ("x_min", "x_max"):
                raise ParamError(f"eaves_bays face {face!r} is not x_min or x_max")
            if (not isinstance(bays, int) or isinstance(bays, bool)
                    or not 3 <= bays <= 12):
                raise ParamError(f"eaves_bays[{face!r}] {bays!r} is not a count in 3..12")
            if self.depth_m / bays < UPPER_BAY_MIN_M:
                raise ParamError(
                    f"eaves_bays[{face!r}] {bays} on a {self.depth_m} m wall "
                    f"leaves {self.depth_m / bays:.2f} m a bay, under "
                    f"the {UPPER_BAY_MIN_M} m a sash and its pier need")
'''
s=once(s,anchor,block+anchor)
s=once(s,'        stovepipes=int(val("stovepipes", 0)),','        eaves_bays=val("eaves_bays", {}),\n        stovepipes=int(val("stovepipes", 0)),')
new[p]=s
p=paths[1];s=new[p]
s=once(s,'''    the one John Gray attests. The BAY COUNT is the archetype's arithmetic on
    the footprint, not a record's; docs/LIBERTIES.md L149 owns the arrangement.
''','''    the one John Gray attests. The default bay count is the archetype's
    footprint arithmetic; a sparse eaves_bays override changes only the pictured
    face named by the record (T-2376). Unnamed faces keep their existing layout.
''')
s=once(s,'''    bays = max(3, min(7, round(d / 2.2)))
    for face, x_wall, sgn in (("x_min", 0.0, -1.0), ("x_max", w, 1.0)):
        for story in range(params.stories):
''','''    default_bays = max(3, min(7, round(d / 2.2)))
    for face, x_wall, sgn in (("x_min", 0.0, -1.0), ("x_max", w, 1.0)):
        bays = params.eaves_bays.get(face, default_bays)
        side_conf = max(conf, params.conf("eaves_bays")) if face in params.eaves_bays else conf
        for story in range(params.stories):
''')
start=s.index('    # ---- even bays along the two eaves elevations')
end=s.index('    # ---- the front gable:',start)
part=s[start:end]
part=once(part,'2.1, conf)','2.1, side_conf)')
part=once(part,'z0, z0 + win_h, conf)','z0, z0 + win_h, side_conf)')
s=s[:start]+part+s[end:]
new[p]=s
p=paths[2];d=json.loads(new[p]);form=d['phases'][0]['form']
source='andreas_1884_green_tree_hotel_plate'
eaves={
'value':{'x_min':7},'confidence':'inferred','sources':[source],
'note':"Seven opening stations are drawn on the visible long elevation in the public-domain Andreas/Braunhold plate, held locally as chicago/reference/images/chicago/chicago_green_tree_inn_1838.jpg; the seven upper sash centres are approximately x 822, 928, 1041, 1146, 1243, 1347 and 1443 in its 1600-pixel-wide reproduction. This is tier-5 retrospective form evidence, not a dimension, coordinate or demonstrated 1835 elevation. The existing west-facing gable and Lake Street south-side reading assign that pictured long wall to local x_min; no position or footprint changes. The opposite x_max face is not overridden and retains its six-bay reconstruction. Seven bays fit the existing 12.19 m length at about 1.74 m per bay, keeping the archetype's existing 0.85 m sash and 1.35 m height. Their equal spacing, vertical bands and hidden treatment remain reconstructed. The attested south-side entrance still replaces the middle ground-floor bay; this patch does not resolve its apparent disagreement with the plate's lower openings or any gable, wing or attic-light discrepancy."
}
f={}
for k,v in form.items():
 f[k]=v
 if k=='elevation_scheme':f['eaves_bays']=eaves
d['phases'][0]['form']=f
note=f['elevation_scheme']['note']
old_note="The BAY COUNT is the archetype's arithmetic on the footprint, not the plate's — the plate draws a longer building than the footprint's attested room-module can carry (its note admits ±20%), and the count follows the footprint: docs/LIBERTIES.md L152."
new_note="The pictured south eaves elevation's bay count is now stated separately by eaves_bays on T-2376; the opposite elevation keeps the archetype's footprint arithmetic as a reconstruction under docs/LIBERTIES.md L152. No dimension or geographic placement is taken from the plate."
f['elevation_scheme']['note']=once(note,old_note,new_note)
new[p]=json.dumps(d,ensure_ascii=False,indent=2)+'\n'
patch=[]
for p in paths:
 proposed=out/'proposed'/p
 proposed.parent.mkdir(parents=True,exist_ok=True)
 proposed.write_text(new[p])
 patch.append(f'diff --git a/{p} b/{p}\n')
 patch.extend(difflib.unified_diff(old[p].splitlines(keepends=True),new[p].splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p))
(out/'T-2376.patch').write_text(''.join(patch))
print('Saved three-file unapplied unified diff and proposed files under',out)
