#!/usr/bin/env bash
set -euo pipefail
cd /tmp/chicago-next-model/T-2375-next/preview/fixture
NODE_PATH=/workspace/shared/node/node_modules PW_EXECUTABLE=/usr/bin/chromium node tools/photo_match.mjs ../andreas-provisional.json --glb assets/gltf/dearborn-profile-preview.glb --out ../comparisons > ../photo-match.log 2>&1
