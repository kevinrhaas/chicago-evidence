"""Second isolated raw export; not official bake/accepted camera/app validation."""
from __future__ import annotations
import hashlib,json,math,pathlib,struct,sys
import bpy
HERE=pathlib.Path(__file__).resolve().parent;FIXTURE=HERE/'fixture'
assert bpy.app.version[:3]==(4,5,3)
sys.dont_write_bytecode=True;sys.path.insert(0,str(FIXTURE/'generators'))
from common.mesh import reset_scene
from archetypes.bridge_timber_params import from_phase
from archetypes import bridge_timber
reset_scene()
r=json.loads((FIXTURE/'data/structures/dearborn_street_drawbridge.json').read_text());ph=r['phases'][0];p=from_phase(ph,r)
assert p.draw_profile=='peaked' and p.draw_rise_m==1.2 and p.draw_bearing_supports
profile_snapshot={};frame_indices={};pier_indices={}
orig_profile=bridge_timber._apply_draw_profile
orig_gallows=bridge_timber._gallows
orig_pier=bridge_timber._pier
def inspected_profile(b,params):
 orig_profile(b,params)
 profile_snapshot.update(vertices=list(b.verts),faces=len(b.faces),confidence=list(b.conf))
def inspected_gallows(b,params,xc,*args):
 lo=len(b.verts);orig_gallows(b,params,xc,*args);frame_indices[str(xc)]=list(range(lo,len(b.verts)))
def inspected_pier(b,params,xp,*args):
 lo=len(b.verts);orig_pier(b,params,xp,*args);pier_indices[str(xp)]=list(range(lo,len(b.verts)))
bridge_timber._apply_draw_profile=inspected_profile;bridge_timber._gallows=inspected_gallows;bridge_timber._pier=inspected_pier
ob=bridge_timber.build(p,'dearborn_street_drawbridge__draw_1834');me=ob.data;me.update();me.calc_loop_triangles()
assert all(math.isfinite(c) for v in me.vertices for c in v.co)
assert all(poly.area>1e-12 for poly in me.polygons)
assert all(math.isfinite(c) for poly in me.polygons for c in poly.normal)
mid=p.span_m/2;lo=mid-p.draw_span_m/2;hi=mid+p.draw_span_m/2
assert any(abs(v[0]-mid)<1e-8 and abs(v[2]-(p.deck_height_m+1.2))<1e-8 for v in profile_snapshot['vertices'])
assert lo in p.pier_x and hi in p.pier_x and len(p.pier_x)==12
assert len(me.attributes['_CONFIDENCE'].data)==len(me.vertices)
def bounds(indices):
 points=[me.vertices[i].co for i in indices]
 return {'min':[min(v[j] for v in points) for j in range(3)],'max':[max(v[j] for v in points) for j in range(3)]}
frames={x:bounds(indices) for x,indices in frame_indices.items()};piers={x:bounds(indices) for x,indices in pier_indices.items()}
assert all(abs(b['max'][2]-(p.deck_height_m+p.gallows_height_m))<1e-6 for b in frames.values())
assert abs(piers[str(lo)]['max'][2]-piers[str(hi)]['max'][2])<1e-6
ob['structure_id']=r['id'];ob['phase_id']=ph['id'];ob['preview_only']=True
ob['preview_scope']='T-2375 second proposal: reconstructed1.2m central rise and aligned bearings; raw export only'
ob['draw_rise_m']=1.2
out=FIXTURE/'assets/gltf/dearborn-profile-preview.glb';out.parent.mkdir(parents=True,exist_ok=True)
bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
bpy.ops.export_scene.gltf(filepath=str(out),export_format='GLB',use_selection=True,export_yup=True,export_apply=True,export_attributes=True,export_extras=True,export_cameras=False,export_lights=False)
blob=out.read_bytes();n,t=struct.unpack_from('<II',blob,12);assert t==0x4E4F534A;doc=json.loads(blob[20:20+n])
assert all(m.get('doubleSided') is True for m in doc['materials'])
assert all('NORMAL' in prim['attributes'] and '_CONFIDENCE' in prim['attributes'] for m in doc['meshes'] for prim in m['primitives'])
report={'status':'SECOND PROPOSAL isolated raw export; no official bake/accepted image gate/app check','blender_version':bpy.app.version_string,'raw_glb':str(out.relative_to(HERE)),'sha256':hashlib.sha256(blob).hexdigest(),'bytes':len(blob),'blender_vertices':len(me.vertices),'polygons':len(me.polygons),'triangles':len(me.loop_triangles),'all_positions_and_normals_finite':True,'all_polygon_areas_positive':True,'reconstructed_rise_m':1.2,'draw_end_stations':[lo,hi],'pier_stations':p.pier_x,'gallows_bounds':frames,'draw_bearing_pier_bounds':{str(x):piers[str(x)] for x in [lo,hi]},'frame_heads_level_and_supports_grounded':True,'all_materials_double_sided':True,'normal_note':'Existing helper inward box winding is preserved; light mesh tests verify winding after clipping, and exported materials remain doubleSided. No shared normal repair or official normal bake.','custom_confidence_and_normal_attributes_exported':True,'production_manifests_written':False,'official_bake':False,'uv_unwrapped':False,'ao_baked':False,'web_derivative_created':False}
(HERE/'blender-inspection.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
