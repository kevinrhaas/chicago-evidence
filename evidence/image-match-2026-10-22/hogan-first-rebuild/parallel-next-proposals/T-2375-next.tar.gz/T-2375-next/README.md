# T-2375 second proposal: central draw rise and frame bearings

Status: UNAPPLIED and not yet Blender/browser previewed. Light pure-Python checks,
structure schema and Python syntax pass. The first board-only raw preview remains
immutable under /tmp/chicago-next-model/T-2375/preview. No tracked repository file,
ticket state, publisher output, official GLB/manifest or accepted camera changed.
Read preview/preview-state.json for any later execution state.

## Concrete model change

The source is the actual Andreas1884 p.631 engraving already inspected for the
first proposal: andreas_1884_dearborn_drawbridge_plate, public_domain by its1884
publication, https://archive.org/details/historyofchicago01andr/page/n1295/mode/1up .
It qualitatively shows the closed draw/parapets rising to a centre and bearing
beneath the gallows. The second engraving corroborates the shape, but its
check_required website record does not license this proposal. Tier5 pictorial
form is inferred, never a geographic control, metric survey or attested mechanism.

Three opt-in controls are added after the board proposal:

- draw_profile defaults to flat; peaked enables a piecewise-linear rise confined
  to the existing text-derived18.288m draw endpoints.
- draw_rise_m defaults to0; Dearborn tests1.2m, explicitly reconstructed as a visual
  trial. The provisional, bounded camera does not measure a historic rise.
- draw_bearing_supports defaults false; Dearborn stations the nearest surviving
  support on each side at the existing frame/draw bearing. It retains12surviving
  cribs and the rest of the invented support layout/type. This aligns local
  framing to the text-derived opening; no map placement or footprint changes.

Long stringer, deck, rail and leaf faces are clipped at both draw ends and centre
before folding. Moving only old endpoints would leave a flat stringer suspended
under the raised deck. No interior cap faces are inserted at the fold, and a face
already on a cut is not duplicated. Raised portions take the worst of their
previous confidence and the reconstructed rise. Approach heights remain unchanged.

Gallows and piers are emitted AFTER folding in peaked mode: frames remain
vertical with level heads; cribs stay horizontal/grounded. Chain lower endpoints
follow the raised centre. The former flat-mode emission order and every previous
mesh-list value remain unchanged when controls default off. This is a closed,
reconstructed display profile; it is not an operating or hoisted draw.

## Applying later

T-2375-next-cumulative.patch contains the three generator/record files relative to
the parent's original baseline, including the first board proposal. Its apply
check passed at preparation. T-2375-next-delta.patch contains only this second
change relative to before-board/, the frozen first proposal's code/record snapshot.
They are alternatives; never apply both. Before applying, recheck branch/claims,
current source hashes and live rival work.

LIBERTY-board-entry.md and LIBERTY-profile-entry.md must both be present before
integration. Append only missing entries at the CURRENT end of LIBERTIES; a patch
hunk based on an older end can insert ahead of newer Hogan/other liberties. No
shared-file liberty hunk is hidden in either code patch. Parent also supplies
STATUS, ROADMAP, visitor changelog, supported bake/license/scene derivation and
image-card updates in its eventual integration parcel.

## Light checks actually run

    PYTHONDONTWRITEBYTECODE=1 python3 /tmp/chicago-next-model/T-2375-next/validate_profile.py

The script uses actual generator/common mesh code with only bpy object/material
emission stubbed. It needs no Blender or browser and runs in under a second on
this workspace; no full gate was run by this agent. validation.json/log record:

- Six current bridge phases and the first board-only proposal emit exactly the
  same vertex/face/confidence/material lists when new controls default off.
- Rise is zero at both draw ends,1.2m at centre and zero on approaches; two
  supports align to bearings without changing the12surviving-support count.
- A long beam is folded across all three stations with conserved signed volume,
  retained winding, no duplicate/coplanar internal caps and no zero-area faces.
- Full generator mesh is finite/nondegenerate, without duplicate faces, and chain
  lower endpoints meet the new centre. Exact unwarped frame/crib vertices remain
  in the final output. The prototype has27,640vertices and6,846polygon faces.
- Invalid/boolean/nonfinite rise, incompatible flat/rise, missing draw, invalid
  support controls, single-frame and zero-support cases are refused.
- mutation-endpoints-only.log shows the centre-peak guard failing as intended
  when a deliberately naive endpoint-only deformation is substituted.

Schema/syntax/applicability evidence is in checkpoint.json and apply-check.log.
These are proposal-only geometry checks, not official asset freshness, glTF,
Blender-normal, rendered image, terrain/water or mobile/desktop acceptance.

## Exact defaults and blast radius

All new fields default off/zero and old geometry is exact. Nevertheless every
bridge input recipe changes because new dataclass fields enter the parameter
hash and bridge_timber.py changes. freshness-scope.json names six assets:
Dearborn, LaSalle slough, North Branch, North Water slough, slough log and South
Branch. Default geometry equivalence is not permission to leave five manifests
stale after a Dearborn-only bake. Use the supported generation/derivative path and
refresh all affected recipes; never hand-assert a fresh bake.

## Ready for the second isolated preview

Do NOT execute until parent signals its foreground gate is idle and a browser
slot is free:

    bash /tmp/chicago-next-model/T-2375-next/preview/run-export.sh
    bash /tmp/chicago-next-model/T-2375-next/preview/run-comparison.sh

The copied fixture uses only verified pinned Blender4.5.3, asserts version and
has --python-exit-code1. It writes a new proposal-only raw GLB and inspection JSON;
no AO/UV bake, web derivative or production manifest is made. The copied
photo_match starts its own ephemeral fixture server. The source camera bytes are
IDENTICAL to the first preview: apparent improvement cannot come from retuning
its poor/bounded calibration. The first camera remains unaccepted, and the
unshown shoreline, boats/buildings, support/trestle details, materials and other
source differences remain unresolved. A successful preview must be inspected and
recorded honestly as differs until the complete original image gate is satisfied.
