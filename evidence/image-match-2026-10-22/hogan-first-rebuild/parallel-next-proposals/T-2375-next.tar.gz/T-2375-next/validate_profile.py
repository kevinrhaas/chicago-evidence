#!/usr/bin/env python3
"""Light pure-Python geometry checks; no Blender, browser, publisher or repo writes."""
from __future__ import annotations
import copy,dataclasses,hashlib,importlib.util,json,math,pathlib,sys,types
sys.dont_write_bytecode=True
OUT=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path('/workspace/chicago/chicago/4d')
sys.path.insert(0,str(ROOT/'generators'));sys.modules.setdefault('bpy',types.ModuleType('bpy'))
from common import mesh

def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod);return mod
old_params=load('board_params_before_profile',OUT/'before-board/generators/archetypes/bridge_timber_params.py')
old_builder=load('board_builder_before_profile',OUT/'before-board/generators/archetypes/bridge_timber.py')
new_params=load('bridge_params_with_profile',OUT/'after/generators/archetypes/bridge_timber_params.py')
build_path=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else OUT/'after/generators/archetypes/bridge_timber.py'
new_builder=load('bridge_builder_with_profile',build_path)
class RawMesh(mesh.MeshBuilder):
 def to_object(self,mats=None):return self
for m in [old_builder,new_builder]:m.MeshBuilder=RawMesh;m.simple_material=lambda name,*a,**k:name

def digest(b):return hashlib.sha256(json.dumps({k:getattr(b,k) for k in ['verts','faces','conf','mat_index']},separators=(',',':')).encode()).hexdigest()

def area(points):return math.sqrt(sum(x*x for x in new_builder._face_area_vector(points)))/2

def inspect_mesh(b):
 assert all(math.isfinite(c) for v in b.verts for c in v)
 assert len(b.verts)==len(b.conf) and len(b.faces)==len(b.mat_index)
 assert all(area([b.verts[i] for i in f])>1e-10 for f in b.faces)
 assert all(c in [0,.5,1] for c in b.conf)
 # An accidental duplicate at a cut would produce the same planar face twice.
 keys=[]
 for f,material in zip(b.faces,b.mat_index):
  points=tuple(sorted(tuple(round(x,8) for x in b.verts[i]) for i in f))
  keys.append((points,material))
 assert len(keys)==len(set(keys)), 'Duplicate coplanar faces after clipping'

checks=[];records=[]
for path in sorted((ROOT/'data/structures').rglob('*.json')):
 r=json.loads(path.read_text())
 if r.get('archetype')!='bridge_timber':continue
 for phase in r['phases']:
  op=old_params.from_phase(phase,r);np=new_params.from_phase(phase,r)
  assert np.draw_profile=='flat' and np.draw_rise_m==0 and np.draw_bearing_supports is False
  a=old_builder.build(op,r['id']);b=new_builder.build(np,r['id'])
  assert digest(a)==digest(b),(r['id'],'new defaults changed geometry')
  records.append({'id':r['id'],'phase':phase['id'],'default_mesh_unchanged':True,'sha256':digest(a)})
assert len(records)==6
# The FIRST opt-in board proposal also remains exactly unchanged when profile
# controls are absent/defaulted; this is the direct staging baseline.
old_record=json.loads((OUT/'before-board/data/structures/dearborn_street_drawbridge.json').read_text());old_phase=old_record['phases'][0]
a=old_builder.build(old_params.from_phase(old_phase,old_record),'old-board')
b=new_builder.build(new_params.from_phase(old_phase,old_record),'flat-board')
assert digest(a)==digest(b)
checks.append('Six current default phases and the first board proposal remain exact mesh-list matches when new profile/support controls default off.')

r=json.loads((OUT/'after/data/structures/dearborn_street_drawbridge.json').read_text());phase=r['phases'][0];p=new_params.from_phase(phase,r)
assert {'draw_profile','draw_rise_m','draw_bearing_supports'}<=new_params.CONSUMED
assert p.draw_profile=='peaked' and p.draw_rise_m==1.2 and p.draw_bearing_supports
mid=p.span_m/2;lo=mid-p.draw_span_m/2;hi=mid+p.draw_span_m/2
assert new_builder._draw_rise(p,lo)==0 and new_builder._draw_rise(p,hi)==0
assert new_builder._draw_rise(p,mid)==1.2
assert new_builder._draw_rise(p,lo-1)==0 and new_builder._draw_rise(p,hi+1)==0
assert lo in p.pier_x and hi in p.pier_x
old_p=old_params.from_phase(old_phase,old_record)
assert len(p.pier_x)==len(old_p.pier_x)==12
assert all(not lo<x<hi for x in p.pier_x)
checks.append('A reconstructed1.2m rise is zero at documented draw ends, peaks at centre, leaves approaches unchanged, and snaps two nearby supports to frame bearings without changing12 surviving supports.')

# Focused long beam crossing all profile stations. It must fold, not remain
# suspended flat or gain duplicate internal cap faces at the profile cuts.
beam=RawMesh('beam');beam.add_box(lo-2,0,2,hi+2,1,2.2,.5,0)
new_builder._apply_draw_profile(beam,p);inspect_mesh(beam)
assert any(abs(x-mid)<1e-8 and abs(z-(2.2+1.2))<1e-8 for x,y,z in beam.verts)
assert all(abs(z-oldz)<1e-7 for x,y,z in beam.verts if x<lo or x>hi for oldz in [2 if z<2.1 else 2.2])
assert len(beam.faces)>6
# Piecewise shear has unit determinant, so a solid beam retains its volume.
def signed_volume(b):
 total=0.0
 for face in b.faces:
  a=b.verts[face[0]]
  for j in range(1,len(face)-1):
   q=b.verts[face[j]];r=b.verts[face[j+1]]
   cross=[q[1]*r[2]-q[2]*r[1],q[2]*r[0]-q[0]*r[2],q[0]*r[1]-q[1]*r[0]]
   total+=sum(a[i]*cross[i] for i in range(3))/6
 return total
assert abs(abs(signed_volume(beam))-(hi-lo+4)*.2)<1e-8
# Every clipped surface retains the existing box's inward winding after shear.
for face in beam.faces:
 pts=[beam.verts[i] for i in face];rawz=[z-new_builder._draw_rise(p,x) for x,y,z in pts]
 center_x=sum(v[0] for v in pts)/len(pts)
 slope=(new_builder._draw_rise(p,center_x+1e-5)-new_builder._draw_rise(p,center_x-1e-5))/2e-5
 if max(abs(v-2.2) for v in rawz)<1e-7:outward=[-slope,0,1]
 elif max(abs(v-2) for v in rawz)<1e-7:outward=[slope,0,-1]
 elif all(abs(v[1])<1e-7 for v in pts):outward=[0,-1,0]
 elif all(abs(v[1]-1)<1e-7 for v in pts):outward=[0,1,0]
 elif all(abs(v[0]-(lo-2))<1e-7 for v in pts):outward=[-1,0,0]
 elif all(abs(v[0]-(hi+2))<1e-7 for v in pts):outward=[1,0,0]
 else:raise AssertionError('Unexpected face after fold')
 assert sum(a*b for a,b in zip(new_builder._face_area_vector(pts),outward))<0
# No new interior face lying entirely at a profile cut is created by folding.
assert not any(all(abs(beam.verts[i][0]-cut)<1e-8 for i in f) for f in beam.faces for cut in [lo,mid,hi])
assert max(beam.conf)==1 and .5 in beam.conf
# An existing end cap exactly on a cut remains single; it is not duplicated.
cap=RawMesh('cut-cap');cap.add_poly([(lo,0,0),(lo,1,0),(lo,1,1),(lo,0,1)],.5,0)
new_builder._apply_draw_profile(cap,p);assert len(cap.faces)==1;inspect_mesh(cap)
checks.append('Clipping folds a long beam at all three stations, introduces the centre peak, adds no internal caps/duplicate coplanar faces, retains original winding and applies reconstructed confidence only to raised portions.')

# Gallery/frame build calls occur after deck deformation, so vertical frames
# keep level heads. Chain lower endpoints must meet the raised leaf centre.
segments=[];original_strut=new_builder._strut
def record_strut(b,p0,p1,*args):
 segments.append((p0,p1));return original_strut(b,p0,p1,*args)
new_builder._strut=record_strut
chain=RawMesh('chains');new_builder._hoist_chains(chain,p,p.gallows_x[0],p.deck_height_m,1)
assert all(abs(end[2]-(p.deck_height_m+new_builder.LEAF_PROUD_M*.5+1.2))<1e-8 for start,end in segments)
new_builder._strut=original_strut
full=new_builder.build(p,'next-profile');inspect_mesh(full)
# The exact flat frame and draw-end crib geometry survives in the full output.
from collections import Counter
def vertex_counter(b):return Counter(tuple(round(c,8) for c in v) for v in b.verts)
actual=vertex_counter(full)
for xp in p.gallows_x:
 frame=RawMesh('frame');new_builder._gallows(frame,p,xp,p.deck_height_m,p.clearance_m,1)
 assert not(vertex_counter(frame)-actual), 'Frame was warped with deck'
for xp in [lo,hi]:
 pier=RawMesh('pier');new_builder._pier(pier,p,xp,p.clearance_m,1)
 assert not(vertex_counter(pier)-actual), 'Draw-bearing crib was warped with deck'

assert digest(full)!=digest(a)
assert len(full.faces)>len(a.faces)
checks.append('Actual full generator mesh is finite/nondegenerate without duplicate faces; chains meet raised leaf centre, while frames and draw-end cribs are built after the fold and retain their exact vertical/horizontal geometry.')

bad=[{'draw_profile':'unknown'},{'draw_profile':None},{'draw_rise_m':True},{'draw_rise_m':float('nan')},{'draw_rise_m':float('inf')},{'draw_rise_m':'1.2'},{'draw_rise_m':0},{'draw_rise_m':-1},{'draw_rise_m':4},{'draw_profile':'flat'},{'draw_span_m':None},{'draw_bearing_supports':'true'},{'gallows_frames':1},{'pier_count':0}]
for overrides in bad:
 try:dataclasses.replace(p,**overrides).validate()
 except new_params.ParamError:pass
 else:raise AssertionError(('bad controls accepted',overrides))
checks.append('Invalid/nonfinite/boolean rise, incompatible flat/rise, missing draw, invalid support controls, one-frame or zero-support cases are rejected.')
report={'status':'pure-Python proposal-only checks passed; no Blender/browser run','records':records,'checks':checks,'rise_m':1.2,'old_supports':old_p.pier_x,'new_supports':p.pier_x,'full_mesh':{'vertices':len(full.verts),'faces':len(full.faces),'sha256':digest(full)},'baseline_first_board_mesh_sha256':digest(a),'blast_radius':'all six bridge recipes: three new dataclass fields plus bridge builder code; default output geometry unchanged'}
(OUT/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS:',len(records),'records;',len(checks),'groups;',len(full.verts),'vertices;',len(full.faces),'faces')
for c in checks:print('  '+c)
