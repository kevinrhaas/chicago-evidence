
### L-dearborn-draw-profile-2375 — Dearborn's closed central rise and frame bearings

**Covers:** `dearborn_street_drawbridge` form `draw_profile`, `draw_rise_m` and
`draw_bearing_supports`, in addition to the preceding boarded-parapet liberty.
**Decision:** Test the clearly raised central closed-draw/parapet profile in the
retrospective Andreas1884 p.631 engraving (`andreas_1884_dearborn_drawbridge_plate`)
in place of the model's flat run. The qualitative central rise and bearing beneath
the gallows are inferred from the actual public-domain plate; neither is a survey,
a contemporary specification, a geographic control or an attested mechanism.
**What is invented:** A1.2m central rise, piecewise-linear from zero at the existing
draw endpoints, is a reconstructed visual trial. It is not measured from the
provisional camera, whose principal point reaches a bound. Long stringer/deck/rail
faces are split at both draw ends and centre so all follow that display profile;
these timber folds/joints are reconstruction, not evidence for a historic hinge.
The nearest surviving support on each approach is stationed at its existing
frame/draw bearing; remaining support count, crib type and approach spacing stay
reconstructed. For this record12surviving supports are retained. Cribs remain
horizontal and grounded, gallows remain vertical with level heads, and chain
endpoints follow the raised centre. No leaf is animated or represented as hoisted.
**What is retained:** The text-derived18.288m draw, footprint, map placement,
abutment/deck-end heights, gallows height and the first board proposal's nominal
parapet sections. The first raw preview is preserved as the before condition.
Raised geometry takes the worst of its old confidence and the reconstructed rise;
no reconstructed rise is presented as an attested dimension.
**What remains unresolved:** The camera is not calibrated, the retrospective
perspective is inconsistent, other support/trestle and approach details remain
unmatched, and the neutral preview omits the river/shore scene. No image match,
accepted camera, supported bake or ticket closure follows from this proposal.
**How to resolve:** A reliable bridge specification or drawn profile could replace
the invented rise/support layout; every source camera and the actual full-scene
comparison must be adjudicated before the original image-gate ticket closes.
**Ticket:** T-2375.
**Recorded:** 2026-10-22.
