# T-2388-next: second-fort blockhouse cupola

Unapplied proposal. Repository remains read-only. The earlier recovery files at `/tmp/t3040-next-parcels/T-2388.patch` and `T-2388.md` are preserved.

## Review/recovery files

- `T-2388-next.patch`: valid four-file unified diff, refreshed against current files, including the now-changed LIBERTIES append context. `git apply --check` passed; the patch has NOT been applied to the repository.
- `candidate/`: proposed files only, not a Git checkout or runnable complete repository.
- `verification.json`: exact lightweight results and geometry bounds.
- `recovery.json`: input hashes, starting HEAD, source-image SHA256 and 25 potentially stale fort assets.
- `source-bounds.json`: manual picture picks and their limits.
- `prepare.py`: recreate candidate copies from current files, apply the earlier generator/record proposal only inside this temporary directory, append the liberty without overwriting any current text.
- `verify.py`: reject stale input hashes; validate parameter cases, existing fort parameter parity and extracted production cupola geometry; refresh the unified diff. It improves the old proposal by retaining new numeric field types until explicit validation, so boolean `true` cannot become one metre through `float(True)`.

Reprepare when current repository files change: run `python /tmp/chicago-next-model/T-2388-next/prepare.py`, then `python /tmp/chicago-next-model/T-2388-next/verify.py`, then `git -C /workspace/chicago apply --check /tmp/chicago-next-model/T-2388-next/T-2388-next.patch`. These steps only write in `/tmp`. Review all four changed files before choosing to apply the patch. HEAD and input hashes are observations, not an instruction to reset another checkout.

## Appearance and evidence boundary

Only `fort_dearborn_blockhouse.log_1816` opts in. The small capped drum at the right of Kurz & Allison panel 5 supplies inferred occurrence, from a retrospective public-domain picture. Dimensions and detail are reconstructed: 1.8 m square; drum head 1.2 m above the existing pyramid apex; cap pitch 35 degrees; eave projection 0.12 m; three dark bands per face represent vents whose pattern the source does not establish. The skirt intersects the existing roof.

The old reconstructed single chimney is centred exactly where the cupola belongs. The proposed record omits that separate stack because none is distinguishable on this blockhouse in panel 5. This is a silhouette choice, not proof of historical absence, lack of heating, or an attested chimney count. It avoids silently moving an invented stack to an unsupported position.

The second fort was rebuilt in 1816. The 1893 source illustrates an asserted 1835 appearance; it is not a contemporary construction record. First-fort images and Whistler's 1808 observation that cupolas were not yet built concern a different fort and an earlier date. That observation does not prohibit later inferred presence and cannot be used as evidence for this second-fort feature.

## Lightweight checks completed

The proposed modules compile and structure JSON parses. Twelve invalid direct-parameter cases and boolean values supplied through all three numeric phase fields are rejected. All 25 existing fort asset phases retain identical prior parameter values after ignoring the four new default-disabled fields. The actual proposed `_cupola`, production `_hip_roof` and `_panel`, and production `MeshBuilder.add_box` functions were extracted and executed against a recording builder without importing Blender. Output: 20 polygons, 76 face vertices, finite bounds, reconstructed confidence everywhere, upward cap orientation and a skirt below the main apex. Proposed cap apex is 10.299010724553236 m above the existing local grade.

This does not validate Blender export, emitted GLB bytes, normal recalculation, AO/material appearance, browser output or the full repository gate. No Blender, browser, bake or heavy process was started.

## Blast radius and next integration work

The fort generator module is a code input for 25 current masters (listed in recovery.json). The new resolved dataclass fields also enter parameter documents; the parameter module bytes themselves are deliberately not hashed by the existing recipe. Therefore all 25 fort assets can become stale even though only the second-fort blockhouse should emit new geometry. Do not bypass freshness or update recipe hashes without reproducing the assets through the supported build path. Verify default-disabled output parity when that path is available.

Before integrating this proposal: coordinate these two shared archetype files with lighthouse and first-fort work; add required repository tests; bake affected assets; regenerate web derivatives and manifests; regenerate sidecars, picture indexes and structure grades as required; preserve all existing source/date/grade distinctions; run required checks. The illustration citation may make its picture reachable on the blockhouse card, which must show credit on desktop/mobile.

## Photo gate remains open

T-3040's actual second-fort baseline clearly differs. The provisional 100 m eye height and roughly -21.84 degree pitch look down onto roofs and compress the compound into the right half, while the drawing is near eye level and spans the image. Its numerical landmark residual is not agreement of the rendered compound. Refine the camera without moving surveyed coordinates, retain the common-plane limitation, and render before/after comparisons.

Cupola dimensions, galleries, openings, materials, roof/chimney arrangements and all the other fort structures remain unresolved. Do not label this proposal or a future cupola-only build `matches`; T-2388 stays open until every required picture comparison satisfies its acceptance.
