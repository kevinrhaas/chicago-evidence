from pathlib import Path
import subprocess,difflib,json,hashlib
repo=Path('/workspace/chicago');out=Path('/tmp/chicago-next-model/T-2388-next');candidate=out/'candidate'
original=Path('/tmp/t3040-next-parcels/T-2388.patch').read_text()
parts=['diff --git '+p for p in original.split('diff --git ')[1:]]
lib_rel='chicago/4d/docs/LIBERTIES.md';lib_part=[p for p in parts if f'a/{lib_rel} ' in p][0]
lib_add='\n'.join(line[1:] for line in lib_part.splitlines() if line.startswith('+') and not line.startswith('+++'))+'\n'
partial=''.join(p for p in parts if p is not lib_part)
(out/'original-generator-and-record.patch').write_text(partial)
relatives=['chicago/4d/generators/archetypes/fort_structure_params.py','chicago/4d/generators/archetypes/fort_structure.py','chicago/4d/data/structures/fort_dearborn_blockhouse.json',lib_rel]
before={rel:(repo/rel).read_text() for rel in relatives}
for rel,s in before.items():
 p=candidate/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
r=subprocess.run(['patch','-p1','--batch','--forward','--input',str(out/'original-generator-and-record.patch')],cwd=candidate,text=True,capture_output=True)
assert r.returncode==0,r.stdout+r.stderr
(candidate/lib_rel).write_text(before[lib_rel]+lib_add)
after={rel:(candidate/rel).read_text() for rel in relatives}
for rel,s in after.items():
 if rel.endswith('.py'):compile(s,rel,'exec')
 if rel.endswith('.json'):json.loads(s)
patch=''.join('diff --git a/'+rel+' b/'+rel+'\n'+''.join(difflib.unified_diff(before[rel].splitlines(keepends=True),after[rel].splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel)) for rel in relatives)
(out/'T-2388-next.patch').write_text(patch)
manifest=json.loads((repo/'chicago/4d/assets/manifest.json').read_text());assets=manifest.get('assets',manifest)
blast=[{'asset':k,'structure_id':v['structure_id']} for k,v in assets.items() if isinstance(v,dict) and v.get('archetype')=='fort_structure']
meta={'base_head':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'source':'chicago/4d/data/sources/assets/prefire_views_kevin_2026_08/p3_1.png','source_sha256':hashlib.sha256((repo/'chicago/4d/data/sources/assets/prefire_views_kevin_2026_08/p3_1.png').read_bytes()).hexdigest(),'inputs_sha256':{rel:hashlib.sha256(s.encode()).hexdigest() for rel,s in before.items()},'fort_structure_asset_count':len(blast),'potentially_stale_assets':blast,'repository_files_changed':False,'proposal_applied_to_temporary_candidate_only':True}
(out/'recovery.json').write_text(json.dumps(meta,indent=2)+'\n')
print(r.stdout.strip());print('Rebased proposal:',out/'T-2388-next.patch')
