"""Lightweight proposal checks; no Blender, browser or repository mutations."""
from pathlib import Path
import ast,dataclasses,difflib,hashlib,json,math,sys,types
out=Path(__file__).resolve().parent;repo=Path('/workspace/chicago');candidate=out/'candidate'
params_rel='chicago/4d/generators/archetypes/fort_structure_params.py';gen_rel='chicago/4d/generators/archetypes/fort_structure.py'
meta=json.loads((out/'recovery.json').read_text())
for rel,want in meta['inputs_sha256'].items():
 actual=hashlib.sha256((repo/rel).read_bytes()).hexdigest()
 if actual!=want:
  raise RuntimeError(f'{rel} changed since preparation; rerun prepare.py before verification')
# Keep new numeric field types intact until their explicit validator; bool is not metres.
p=candidate/params_rel;s=p.read_text()
for field,default in [('cupola_width_m','1.8'),('cupola_height_m','1.2'),('cupola_roof_pitch_deg','35.0')]:
 s=s.replace(f'{field}=float(val("{field}", {default}))',f'{field}=val("{field}", {default})')
p.write_text(s)
def module(name,source):
 m=types.ModuleType(name);sys.modules[name]=m;exec(compile(source,name,'exec'),m.__dict__);return m
before=module('fort_params_before_t2388',(repo/params_rel).read_text());after=module('fort_params_after_t2388',s)
record=json.loads((candidate/'chicago/4d/data/structures/fort_dearborn_blockhouse.json').read_text());p=after.from_phase(record['phases'][0],record)
assert p.cupola is True and p.chimneys==0
assert (p.cupola_width_m,p.cupola_height_m,p.cupola_roof_pitch_deg)==(1.8,1.2,35.0)
assert {'cupola','cupola_width_m','cupola_height_m','cupola_roof_pitch_deg'}<=after.CONSUMED
for kwargs in [dict(cupola=1),dict(cupola='true'),dict(kind='quarters'),dict(roof_type='gable'),dict(cupola_width_m=True),dict(cupola_width_m=float('nan')),dict(cupola_width_m=float('inf')),dict(cupola_width_m=9),dict(cupola_height_m=0.1),dict(cupola_height_m=4),dict(cupola_roof_pitch_deg=0),dict(cupola_roof_pitch_deg=70)]:
 try:dataclasses.replace(p,**kwargs).validate()
 except after.ParamError:pass
 else:raise AssertionError(('invalid cupola accepted',kwargs))
for key in ['cupola_width_m','cupola_height_m','cupola_roof_pitch_deg']:
 bad=json.loads(json.dumps(record));bad['phases'][0]['form'][key]['value']=True
 try:after.from_phase(bad['phases'][0],bad)
 except after.ParamError:pass
 else:raise AssertionError(('phase boolean accepted as number',key))
# Compile production helpers from each source into an isolated namespace.
def helpers(source,names):
 tree=ast.parse(source);nodes=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0)]
 nodes += [node for node in tree.body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name in names]
 ns={'math':math,'M_WALL':0,'M_ROOF':1,'M_DARK':2,'M_TRIM':3,'M_CHIMNEY':4}
 exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'production-helper-extract','exec'),ns);return ns
ns=helpers((candidate/gen_rel).read_text(),{'_cupola','_hip_roof','_panel'})
mesh=ast.parse((repo/'chicago/4d/generators/common/mesh.py').read_text());cls=next(n for n in mesh.body if isinstance(n,ast.ClassDef) and n.name=='MeshBuilder');add_box=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='add_box');boxns={};exec(compile(ast.fix_missing_locations(ast.Module(body=[add_box],type_ignores=[])),'production-add-box','exec'),boxns)
class Builder:
 add_box=boxns['add_box']
 def __init__(self):self.name='fixture';self.faces=[];self.events=[]
 def add_poly(self,points,confidence,mat=0):self.faces.append((tuple(points),confidence,mat))
b=Builder();ridge=5.38+(9.8+0.9)/2*math.tan(math.radians(30));ns['_cupola'](b,p,ridge)
assert len(b.faces)==20
verts=[v for face,conf,mat in b.faces for v in face];assert len(verts)==76
assert all(math.isfinite(v) for xyz in verts for v in xyz)
assert all(conf==1.0 for face,conf,mat in b.faces),'reconstructed dimensions must keep cupola geometry reconstructed'
assert all(mat in [0,1,2] for face,conf,mat in b.faces)
mins=[min(v[i] for v in verts) for i in range(3)];maxs=[max(v[i] for v in verts) for i in range(3)]
expected_top=ridge+1.2+0.9*math.tan(math.radians(35));assert abs(maxs[2]-expected_top)<1e-8
assert mins[2]<ridge and all(v[2]>ridge for face,conf,mat in b.faces if mat==2 for v in face)
assert abs(mins[0]-(p.width_m/2-.9-.12))<1e-8 and abs(maxs[1]-(p.depth_m/2+.9+.12))<1e-8
for face,conf,mat in b.faces:
 if mat!=1:continue
 a,c,d=face;u=[c[i]-a[i] for i in range(3)];v=[d[i]-a[i] for i in range(3)];assert u[0]*v[1]-u[1]*v[0]>0,'cap must face upward'
# Compare unchanged default-disabled parameter resolution on every committed fort asset.
manifest=json.loads((repo/'chicago/4d/assets/manifest.json').read_text());assets=manifest.get('assets',manifest);checked=0
new_keys={'cupola','cupola_width_m','cupola_height_m','cupola_roof_pitch_deg'}
for name,item in assets.items():
 if not isinstance(item,dict) or item.get('archetype')!='fort_structure':continue
 d=json.loads((repo/f"chicago/4d/data/structures/{item['structure_id']}.json").read_text());phase=next(p for p in d['phases'] if p['id']==item['phase_id']);old=before.from_phase(phase,d);new=after.from_phase(phase,d)
 assert new.cupola is False
 assert dataclasses.asdict(old)=={k:v for k,v in dataclasses.asdict(new).items() if k not in new_keys}
 checked+=1
# Refresh a valid unified diff against current input bytes, preserving all repository files.
relatives=[params_rel,gen_rel,'chicago/4d/data/structures/fort_dearborn_blockhouse.json','chicago/4d/docs/LIBERTIES.md']
patch=''.join('diff --git a/'+rel+' b/'+rel+'\n'+''.join(difflib.unified_diff((repo/rel).read_text().splitlines(keepends=True),(candidate/rel).read_text().splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel)) for rel in relatives)
(out/'T-2388-next.patch').write_text(patch)
report={'parameter_validation':'passed','phase_boolean_rejection':'passed','existing_fort_parameter_parity_count':checked,'cupola_helper_faces':len(b.faces),'cupola_helper_face_vertices':len(verts),'cupola_bounds_m':{'min':mins,'max':maxs},'new_cap_apex_m':expected_top,'confidence':'all reconstructed=1.0','python_syntax':'passed','json_parsing':'passed','blender_bake':'not run','browser_render':'not run','repo_gate':'not run','patch_applied_to_repository':False}
(out/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
