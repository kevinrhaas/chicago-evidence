# T-2382-next: roof-piercing chimney proposal

The completed sash proposal at /tmp/chicago-next-model/T-2382 is preserved unchanged. This package is a separate further increment; repository remains untouched.

## Main proposal: existing parameters only

Apply chimney-on-sash.patch after the prior sash change. If starting from the current unchanged repository structure record, combined-from-repo.patch includes both the preserved sash increment and this chimney increment. Never apply both patch variants. `before-sash.json` is the exact prior proposed record; `after-sash-chimney.json` is the combined result.

The new consumed params are chimney_ridge_at=[0.8], ridge_stack_w_m=0.55, ridge_stack_head_m=0.65. They replace the generic full-height exterior chimney at the hotel junction with a small roof-piercing stack near the annex's exposed outer gable. The count remains one, now citing the pictured occurrence instead of only inferring a need for winter heat. The station and dimensions are reconstructed first-comparison choices. Only philo_carpenter_log_shop.log_1832 requires a rebake. Its sash refinement, footprint, placement, dates and use remain unchanged. Append proposed-liberty.md and run the appropriate compile/rederive commands; do not mark matches.

The actual Braunhold sheet was inspected. It supplies the roof-piercing disposition, relative end and small silhouette, not an exact metric station. Station0.8 is 1.2192 m inward from the exposed +x gable on the retained6.096 m ridge. A0.55 m-square section and0.65 m head are defensible provisional small masonry-stack dimensions, subject to paired-render refinement. No need for an exact historical measurement blocks building this reconstructed increment.

## Exact existing limitation

The existing generator supports the proposed geometry but hardcodes `materials.chimney_finish("exterior_gable")` for EVERY log_dwelling chimney, even when chimney_ridge_at routes it to _ridge_stack. Thus existing params cannot select the picture's brick/masonry finish. A ridge-stack edit alone retains the stick-and-clay color. It would be dishonest to describe that as a completed chimney match.

## Separate optional opt-in material change

optional-material-selector.patch proposes, without applying:
- LogDwellingParams.chimney_material=None, consumed and loaded from the form.
- Validation permits only None or brick and refuses a fabric on a zero-chimney record.
- Explicit brick selects the existing shared BRICK finish via chimney_finish("interior"); absent material retains exactly the existing exterior_gable selection, even for already-shipped ridge stacks.
- Only an explicit material participates in the stack's confidence fold. No auto-recoloring of all ridge stacks.

This code patch deliberately does NOT set the Carpenter record's material: a parent choosing to adopt it should append an inferred brick row with source/reason, explaining monochrome masonry versus the colored Petford rendition and keeping the exact shared-brick color reconstructed. The original source's existing rights are public_domain. Full brick-course/cap treatment is still unresolved.

Default output geometry/material operations are preserved by this branch, but output-byte equivalence has NOT been tested. Importantly, mesh_inputs hashes builder bytes and dataclass fields. Therefore adding even a default-None field plus this builder edit changes freshness inputs of ALL81 registered log_dwelling masters, across1812/1835. registered-log-assets.json names them. The optional change needs a real compatible-binary rebuild or explicitly supported equivalent-output verification; never blind hash restamping or weakening freshness. Avoid changing common/materials.py, which would increase the blast radius to other archetypes.

## Validation performed

`PYTHONDONTWRITEBYTECODE=1 python /tmp/chicago-next-model/T-2382-next/verify.py` passes the structure schema, consumed-param membership, ridge location/size validation, retained sash rectangles, optional module syntax/default/brick selection and unknown-material refusals. See verify.log. These are light source/parameter checks only. No Blender/browser/heavy gate run, mesh-byte comparison, actual image verdict or ticket closure occurred. Parent should run same-camera before/after and targeted in-app validation after a pinned-binary rebuild, then the normal required gates.
