from pathlib import Path
import ast,copy,importlib.util,json,sys
B=Path(__file__).resolve().parent; R=Path('/workspace/chicago/chicago/4d');sys.path.insert(0,str(R/'generators'))
from archetypes.log_dwelling_params import from_phase, CONSUMED, core_front_rects
before=json.loads((B/'before-sash.json').read_text());after=json.loads((B/'after-sash-chimney.json').read_text())
new={'chimney_ridge_at','ridge_stack_w_m','ridge_stack_head_m'}
x=copy.deepcopy(after)
for k in new:x['phases'][0]['form'].pop(k)
x['phases'][0]['form']['chimneys']=before['phases'][0]['form']['chimneys'];assert x==before
assert new<=CONSUMED
p=from_phase(after['phases'][0],after);p.validate()
assert p.chimney_ridge_at==(.8,) and p.ridge_stack_w_m==.55 and p.ridge_stack_head_m==.65
assert core_front_rects(p)==core_front_rects(from_phase(before['phases'][0],before))
import jsonschema
jsonschema.validate(after,json.loads((R/'data/structures.schema.json').read_text()))
print('Data schema, consumed params, supported ridge placement, retained sash geometry: PASS')
# No bpy import: optional module compilation and parameter validation only.
G=B/'optional-material-after/chicago/4d/generators/archetypes'
for n in ['log_dwelling.py','log_dwelling_params.py']:ast.parse((G/n).read_text())
spec=importlib.util.spec_from_file_location('carpenter_chimney_params',G/'log_dwelling_params.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
q=m.from_phase(after['phases'][0],after);q.validate();assert q.chimney_material is None
explicit=copy.deepcopy(after);explicit['phases'][0]['form']['chimney_material']={'value':'brick','confidence':'inferred','sources':['andreas_1884_sauganash_hotel_plate'],'note':'Material selector validation fixture only.'}
q=m.from_phase(explicit['phases'][0],explicit);q.validate();assert q.chimney_material=='brick'
for bad in ['stone',False,1]:
 q.chimney_material=bad
 try:q.validate()
 except m.ParamError:pass
 else:raise AssertionError('bad material accepted')
print('Optional selector syntax, default None, explicit brick, unknown-material rejection: PASS')
print('No Blender, browser, output-byte equivalence, image verdict, broad checks or closure performed.')
