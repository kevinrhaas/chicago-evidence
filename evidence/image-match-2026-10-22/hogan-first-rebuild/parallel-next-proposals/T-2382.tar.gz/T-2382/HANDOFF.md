# T-2382: proposed first visible sash correction

Proposal only. Repository read-only; files below /tmp only. The existing source picture was inspected at full available detail. Do not call this matched, tested in the browser, baked, claimed or finished.

## Apply

From /workspace/chicago: inspect change.patch, check base.sha256, then `git apply --check /tmp/chicago-next-model/T-2382/change.patch` and apply. Only data/structures/philo_carpenter_log_shop.json changes: four new consumed form rows. No shared generator/parameter/default changes. Append proposed-liberty.md to docs/LIBERTIES.md before rederivation; its three Covers entries own the new reconstructed numeric attributes.

## Actual geometry

The existing log_dwelling generator will replace the two near-square 0.62 × 0.72 m front lights with 0.70 × 1.40 m upright sash, their heads on the retained 1.95 m door head. It will remove any deterministically dealt front shutters. The frontage, footprint, placement, bearing, date range, existence uncertainty, former uses and occupants do not move. Opening centre shifts are below 0.0005 m: the new explicit set-out just preserves the previous rule while enabling head alignment.

The same shared generator applies its new vertical window band to the hidden rear light, which is explicitly reconstructed and recorded in the liberty. This is a one-structure/one-phase rebake. No other records or default outputs change because no shared module changes.

## Source bounds

Source andreas_1884_sauganash_hotel_plate resolves and is public_domain. The source file was already in tree; its local full-resolution equivalent is chicago/reference/images/chicago/chicago_sauganash_hotel_1831.jpg. The cabin identity is the existing record's drloih_beaubien caption ruling. Whole-building picture availability may change the compiled grade under rule12 when this source is directly named; preserve per-attribute reconstructed numeric dimensions. This source supplies a visible tall bare-sash arrangement, not surveyed measurements. The selected 0.70/1.40 m values need actual paired review before landing.

## Honest remaining differences

The chimney still occupies a generic exterior end position instead of the picture's roof-piercing brick stack; glazing/muntins are the generic log_dwelling proxy; open door, roof shape/proportions, log-course scale/tone, porch/hood interpretation and group contact with Sauganash remain unresolved. The absent source-backed group renderer means the existing photo_match tool cannot compare this attached pair together. Do not re-enable sauganash_hotel.log_wing: that would duplicate this building.

## Validation

`PYTHONDONTWRITEBYTECODE=1 python /tmp/chicago-next-model/T-2382/verify.py` passes schema, consumed-attribute checks, supported from_phase.validate, source rights, unchanged unrelated record data, unchanged centres and exact new window rectangles. See verify.log. No Blender/browser/heavy CPU used, as requested.

When parent allows geometry work: pinned Blender --only philo_carpenter_log_shop, its exact web derivative, compile_liberties, compile_scene/rederive and generated entrance/signage/index validation. Fit a provisional drawing camera under docs/RESEARCH rather than claiming solved data; retain original master for same-camera before/after comparison. Review actual images and mobile/desktop card/app; add changelog/status only around the validated final increment. Ticket remains open until full image gate passes.
