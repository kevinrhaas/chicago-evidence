import copy, dataclasses, importlib.util, json, pathlib, sys
BASE = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path('/workspace/chicago/chicago/4d')
sys.path.insert(0,str(ROOT/'generators'))
from archetypes.log_dwelling_params import from_phase, core_front_rects, CONSUMED
rel=pathlib.Path('chicago/4d/data/structures/philo_carpenter_log_shop.json')
a=json.loads((BASE/'before'/rel).read_text());b=json.loads((BASE/'after'/rel).read_text())
changed={'front_set_out','window_w_m','window_h_m','front_shutters'}
assert changed<=CONSUMED
stripped=copy.deepcopy(b)
for key in changed: stripped['phases'][0]['form'].pop(key)
assert stripped==a,'Unrelated fields changed'
pa=from_phase(a['phases'][0],a); pb=from_phase(b['phases'][0],b)
pa.validate();pb.validate()
ra=core_front_rects(pa);rb=core_front_rects(pb)
wa=[r for r in ra if r[0]=='window'];wb=[r for r in rb if r[0]=='window']
assert len(wa)==len(wb)==2
assert all(abs(r[4]-r[3]-.72)<1e-9 for r in wa)
assert all(abs(r[4]-r[3]-1.4)<1e-9 and abs(r[2]-r[1]-.7)<1e-9 for r in wb)
assert all(abs(r[4]-1.95)<1e-9 for r in rb)
assert max(abs((x[1]+x[2])/2-(y[1]+y[2])/2) for x,y in zip(wa,wb))<.0005
assert pb.front_shutters is False
for key in changed:
 for sid in b['phases'][0]['form'][key]['sources']:
  src=json.loads((ROOT/'data/sources'/f'{sid}.json').read_text())
  assert src['rights_status']=='public_domain'
try:
 import jsonschema
 jsonschema.validate(b,json.loads((ROOT/'data/structures.schema.json').read_text()))
 print('Structure schema: PASS')
except ImportError:
 print('Structure schema: UNRUN (jsonschema not installed in this interpreter)')
print('Narrow data diff, consumed params, validation, source rights, retained centres and new sash rectangles: PASS')
print('Before front rectangles:',ra)
print('After front rectangles:',rb)
print('No mesh bake, browser render, image verdict, full gate or closure has been run by this proposal.')
