"""Provisional picture framing of current bridge, not a historic camera solve.
The plate's perspective and the current flat deck disagree. Do not derive metric
or geographic evidence, or an accepted image-gate camera, from this fit.
"""
import json,math,pathlib,sys
import numpy as np
from scipy.optimize import least_squares
OUT=pathlib.Path(__file__).resolve().parent
FIXTURE=OUT/'fixture'
sys.path.insert(0,str(FIXTURE/'generators'))
from archetypes.bridge_timber_params import from_phase
record=json.loads((FIXTURE/'data/structures/dearborn_street_drawbridge.json').read_text())
p=from_phase(record['phases'][0],record)
# Approximate manually selected visible upright centres at deck plane and frame
# tops on 1920x1346 Andreas image. These are not surveyed image controls; board
# occlusion makes the apparent base especially uncertain.
pixels=np.array([[174,941],[174,680],[266,946],[266,702],
                 [1066,918],[1066,625],[1173,922],[1173,655]],float)
world=np.array([[x,y,z] for x in p.gallows_x for y in [-.26,p.width_m+.26]
                for z in [p.deck_height_m,p.deck_height_m+p.gallows_height_m]],float)
def project(a,points):
 eu,ev,ey,yaw,f,cx,cy=a;t=math.radians(yaw);d=points-np.array([eu,ev,ey])
 dep=d[:,0]*math.sin(t)+d[:,1]*math.cos(t)
 right=d[:,0]*math.cos(t)-d[:,1]*math.sin(t)
 return np.column_stack([cx+f*right/dep,cy-f*d[:,2]/dep])
def fun(a):return (project(a,world)-pixels).ravel()
# Positive height above design water; bank/boat-height preview is plausible, but
# not attested. Negative/below-water fits are intentionally excluded.
bounds=([48,-300,.5,-85,250,-2500,400],[300,-2,15,-1,12000,4500,1400])
fits=[]
for eu,ev,yaw,f in [(70,-35,-30,2000),(100,-60,-35,3000),(150,-150,-40,6000),(60,-30,-20,1200)]:
 fit=least_squares(fun,[eu,ev,2.0,yaw,f,1500,1000],bounds=bounds,max_nfev=2000)
 fits.append(fit)
fit=min(fits,key=lambda r:np.linalg.norm(r.fun));pred=project(fit.x,world);res=pred-pixels
at_bounds=[i for i,x in enumerate(fit.x) if min(abs(x-bounds[0][i]),abs(x-bounds[1][i]))<1e-3]
metrics={'status':'provisional framing only; not calibrated or accepted','model_dimensions_current_not_picture_derived':True,'eye':fit.x[:3].tolist(),'yaw_deg':float(fit.x[3]),'focal_px':float(fit.x[4]),'principal_px':fit.x[5:].tolist(),'point_rms_px':float(np.sqrt(np.mean(np.sum(res**2,axis=1)))),'maximum_point_residual_px':float(np.linalg.norm(res,axis=1).max()),'at_bound_parameter_indices':at_bounds,'parameter_order':['eye_u','eye_v','eye_y','yaw_deg','focal_px','principal_x','principal_y'],'bounds':bounds,'observations':[{'world_uvy':w.tolist(),'picked_xy':o.tolist(),'projected_xy':pr.tolist(),'residual_xy':rr.tolist()} for w,o,pr,rr in zip(world,pixels,pred,res)],'limitations':['Approximate/occluded upright bases; drawing has inconsistent convergence.','Current flat deck differs from the drawing central rise; not a warranted metric height change.','Eye/focal/principal estimates are reconstructed preview parameters and may reach bounds.','Bridge substructure and source setting are not matched.']}
(OUT/'camera-fit.json').write_text(json.dumps(metrics,indent=2)+'\n')
cam={'structure_id':'dearborn_street_drawbridge','source_id':'andreas_1884_dearborn_drawbridge_plate','photo':'fixture/reference/andreas-1884-dearborn.png','image_px':[1920,1346],'principal_px':metrics['principal_px'],'focal_px':metrics['focal_px'],'eye':metrics['eye'],'yaw_deg':metrics['yaw_deg'],'sky':'overcast','solve':f"PROVISIONAL PREVIEW FRAMING ONLY, NOT AN ACCEPTED CAMERA OR HISTORICAL MEASUREMENT. Eight approximate upright centres fitted to current model frame coordinates (documented draw length but reconstructed frame height, current flat deck). Point RMS {metrics['point_rms_px']:.2f}px, max {metrics['maximum_point_residual_px']:.2f}px; bounded parameter indices {at_bounds}. Exact picks and residuals in camera-fit.json. Drawing perspective and raised central profile conflict with current envelope. Pose, focal length, principal point and lighting are reconstructed preview choices only. Source is Andreas 1884 p.631, retrospective inferred form, no coordinate/footprint evidence. This comparison uses a proposal-only isolated Blender export, not a committed or officially baked mesh."}
(OUT/'andreas-provisional.json').write_text(json.dumps(cam,indent=2)+'\n')
print(json.dumps({k:metrics[k] for k in ['eye','yaw_deg','focal_px','principal_px','point_rms_px','maximum_point_residual_px','at_bound_parameter_indices']},indent=2))
