# T-2375 isolated board-parapet preview fixture

COMPLETED after the parent cleared the foreground gate. Pinned Blender4.5.3 raw
export passed, and one copied photo_match browser comparison passed. The actual
side-by-side and original render were visually reviewed and the temporary match
record is explicitly differs. Browser/server closed before Tremont took the slot.
Read preview-state.json and blender-inspection.json for exact scope and receipts.

## Reproduce after parent signals

    bash /tmp/chicago-next-model/T-2375/preview/run-export.sh
    bash /tmp/chicago-next-model/T-2375/preview/run-comparison.sh

The first command uses only the verified pinned binary:
/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender .
It asserts version4.5.3, builds from the copied proposed structure/modules, writes
fixture/assets/gltf/dearborn-board-preview.glb and blender-inspection.json, and
inspects actual Blender mesh faces, finite positions/normals, custom confidence,
material slots, board/cap joints and cap/post overlap. It uses the official
export_glb option set, but deliberately is NOT emit_structure/tools/bake.sh:
no UV unwrap, AO bake, web derivative, production manifest or provenance table is
written. The object is tagged preview_only, and no supported official bake or
accepted image match is established by this raw export.

The second command runs an unchanged copied photo_match.mjs against the temporary
GLB through its own ephemeral server rooted at the fixture. Copied Three/vendor
and loader files are served only from that fixture; Playwright and Chromium reuse
the environment's existing installation. It writes a neutral comparison and an
initial unreviewed temporary match record. Review the actual output before marking
it differs; never mark this provisional camera matches. The tool's review plane
is at the bridge's design-water datum, with no app terrain/water or neighbouring
scene. It is not a screenshot of the running published application.

All modules, reference pixels and the committed pole baseline were copied into
fixture/; fixture-inputs.json records exact byte hashes. No production source,
ticket state, publisher output, accepted camera or official asset is changed.
The recorded canonical structure/phase identity labels the preview; its filename
and preview_only extras distinguish it from the committed asset.

## Camera limitations

fit_camera.py reproduces a bounded level-pinhole framing from eight approximate
visible gallows-upright centres on the actual 1920x1346 Andreas image. Some bases
are occluded by the drawn parapets. Current draw length, bridge width and
reconstructed frame height/flat deck set the model coordinates; no dimension or
geographic position is derived from the picture. camera-fit.json records picks,
projections, residuals and bounds. Current point RMS10.75px/max20.58px are framing
residuals, not an accepted fit: principal_x reaches the lower bound at -2500px,
far outside the picture. This and the drawing's inconsistent perspective/central
rise prohibit a calibrated historical camera claim. Pose, principal point,
focal length and overcast lighting are provisional review choices.

Andreas1884 p.631 is the public-domain retrospective form source:
https://archive.org/details/historyofchicago01andr/page/n1295/mode/1up .
The fixture reference is copied from chicago_dearborn_drawbridge_1834.png; source
record and tier5 limits are preserved in the parent proposal handoff. The second
engraving corroborates boards but its website record does not license this export.

## Normals safeguard

The existing common MeshBuilder.add_box winds box faces inward. The proposal
preserves that helper and unchanged default geometry; it does not silently flip
shared bridge/world geometry. The export inspection will report the actual
Blender normal orientations and require the raw exported material doubleSided
flags, which are the helper's current material default. Finite normals alone do
not prove correct face orientation. Inspect the actual loader result and retain
this limitation; no global winding repair or official normal bake is claimed.

## Reviewed result

The generated board infill is visible, but the bridge still differs clearly: the
source has a raised/bent central deck/parapet profile and different gallows,
bracing/chain, support and approach details; current broad spans remain flat.
The eight-point framing is bounded/provisional and cannot calibrate these model
changes. Existing neutral timber, neutral grade plane and omitted river/shore
context also differ from the picture. No match is accepted or ticket closed.

Actual raw GLB:845,216bytes,13,678triangles, SHA256
8552ab10ecb1c201631a09ce1f512382000a22dea0982b076a1b73f6225bdc42 .
Blender inspected27,100vertices/6,711polygons with finite positions/normals and
positive polygon areas. All380board boxes,76cap boxes and72posts passed seam and
cap/post checks. All3,096railing-box faces retain the existing helper's inward
orientation; four exported materials are doubleSided. Custom confidence and
NORMAL attributes are present. This does not substitute for an official pinned
bake, web derivatives, production manifests, source/license/scene compilation,
accepted cameras or mobile/desktop application checks.

The export runner now includes --python-exit-code1 so future Python failures
produce a failing process status; the first export's success was independently
confirmed by its fresh inspection JSON, GLB, version log and loader comparison.
