#!/usr/bin/env bash
set -euo pipefail
cd /tmp/chicago-next-model/T-2375/preview/fixture
NODE_PATH=/workspace/shared/node/node_modules PW_EXECUTABLE=/usr/bin/chromium node tools/photo_match.mjs ../andreas-provisional.json --glb assets/gltf/dearborn-board-preview.glb --out ../comparisons > ../photo-match.log 2>&1
