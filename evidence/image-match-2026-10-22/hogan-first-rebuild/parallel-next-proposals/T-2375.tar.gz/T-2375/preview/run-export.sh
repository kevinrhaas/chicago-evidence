#!/usr/bin/env bash
set -euo pipefail
cd /tmp/chicago-next-model/T-2375/preview
/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender --background --factory-startup --threads 1 --python-exit-code 1 --python export_preview.py > blender-export.log 2>&1
