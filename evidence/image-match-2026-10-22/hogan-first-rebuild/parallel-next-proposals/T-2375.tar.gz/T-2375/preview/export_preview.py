"""Isolated proposal-only raw GLB export. NOT the supported bake pipeline.
Run only after parent signals its gate is idle, using verified pinned Blender4.5.3.
No repository module, production manifest, grade, image gate or publisher is written.
"""
from __future__ import annotations
import hashlib,json,math,pathlib,struct,sys
import bpy
HERE=pathlib.Path(__file__).resolve().parent
FIXTURE=HERE/'fixture'
assert bpy.app.version[:3]==(4,5,3), f'Requires verified pinned Blender4.5.3, got {bpy.app.version_string}'
sys.path.insert(0,str(FIXTURE/'generators'))
from common.mesh import MeshBuilder,reset_scene
from archetypes.bridge_timber_params import from_phase
from archetypes import bridge_timber
reset_scene()
record=json.loads((FIXTURE/'data/structures/dearborn_street_drawbridge.json').read_text());phase=record['phases'][0]
p=from_phase(phase,record)
assert p.railing_kind=='board'
boxes=[];railing_scope={'active':False}
class InspectionMesh(MeshBuilder):
 def add_box(self,*args,**kwargs):
  lo=len(self.faces);super().add_box(*args,**kwargs)
  if railing_scope['active']:boxes.append({'bounds':list(args[:6]),'confidence':args[6],'material':args[7] if len(args)>7 else 0,'faces':list(range(lo,len(self.faces)))})
bridge_timber.MeshBuilder=InspectionMesh
orig_railing=bridge_timber._railing
def inspected_railing(*args,**kwargs):
 railing_scope['active']=True
 try:return orig_railing(*args,**kwargs)
 finally:railing_scope['active']=False
bridge_timber._railing=inspected_railing
ob=bridge_timber.build(p,'dearborn_street_drawbridge__draw_1834')
ob['structure_id']=record['id'];ob['phase_id']=phase['id'];ob['preview_only']=True
ob['preview_scope']='T-2375 board-parapet proposal, raw export; no AO/UV bake, web derivative or official manifest'
me=ob.data;me.update();me.calc_loop_triangles()
assert all(math.isfinite(c) for v in me.vertices for c in v.co)
assert all(poly.area>1e-12 for poly in me.polygons)
assert all(math.isfinite(c) for poly in me.polygons for c in poly.normal)
assert len(me.attributes['_CONFIDENCE'].data)==len(me.vertices)
assert [m.name for m in me.materials]==['log','deck','fill','iron']
cap=[];boards=[];posts=[]
for b in boxes:
 xyz=b['bounds']
 if b['material']==bridge_timber.M_LOG: posts.append(b)
 elif abs(xyz[5]-(p.deck_height_m+.95))<1e-7:cap.append(b)
 else:boards.append(b)
assert len(boards)==5*len(cap) and len(cap)>0
for b in cap+boards:
 x0,y0,z0,x1,y1,z1=b['bounds']
 assert b['confidence']==.5
 for boundary in [p.span_m/2-p.draw_span_m/2,p.span_m/2,p.span_m/2+p.draw_span_m/2]:
  assert not x0<boundary<x1
for post in posts:
 assert abs(post['bounds'][5]-(p.deck_height_m+.95-.06))<1e-7
 for c in cap:
  assert min(post['bounds'][5],c['bounds'][5])-max(post['bounds'][2],c['bounds'][2])<1e-8
orientation={'outward':0,'inward':0,'tangent':0}
for b in cap+boards+posts:
 xyz=b['bounds'];center=[(xyz[i]+xyz[i+3])/2 for i in range(3)]
 for index in b['faces']:
  poly=me.polygons[index]
  dot=sum(float(poly.normal[i])*(float(poly.center[i])-center[i]) for i in range(3))
  orientation['outward' if dot>1e-7 else 'inward' if dot< -1e-7 else 'tangent']+=1
out=FIXTURE/'assets/gltf/dearborn-board-preview.glb';out.parent.mkdir(parents=True,exist_ok=True)
bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
bpy.ops.export_scene.gltf(filepath=str(out),export_format='GLB',use_selection=True,export_yup=True,export_apply=True,export_attributes=True,export_extras=True,export_cameras=False,export_lights=False)
blob=out.read_bytes();assert blob[:4]==b'glTF'
json_len,json_type=struct.unpack_from('<II',blob,12);assert json_type==0x4E4F534A
export=json.loads(blob[20:20+json_len])
assert all(m.get('doubleSided') is True for m in export['materials'])
assert all('_CONFIDENCE' in prim['attributes'] and 'NORMAL' in prim['attributes'] for mesh_ in export['meshes'] for prim in mesh_['primitives'])
report={'status':'proposal-only isolated raw export, not official bake/committed asset/image match','blender_version':bpy.app.version_string,'raw_glb':str(out.relative_to(HERE)),'sha256':hashlib.sha256(blob).hexdigest(),'bytes':len(blob),'vertices':len(me.vertices),'polygons':len(me.polygons),'triangles':len(me.loop_triangles),'all_positions_finite':True,'all_polygon_normals_finite':True,'all_polygon_areas_positive':True,'board_boxes':len(boards),'cap_boxes':len(cap),'post_boxes':len(posts),'cap_post_overlap':False,'draw_end_and_leaf_joints_respected':True,'railing_box_face_normal_orientation':orientation,'normal_orientation_note':'The existing common MeshBuilder.add_box winds box faces inward. This proposal preserves that shared helper and its existing default geometry; all raw exported materials are doubleSided, matching current helper defaults. No global normal repair is applied or claimed. Inspect the preview under the actual loader before any integration.','materials':[{'name':m.get('name'),'doubleSided':m.get('doubleSided'),'roughnessFactor':m.get('pbrMetallicRoughness',{}).get('roughnessFactor')} for m in export['materials']],'confidence_custom_attribute_exported':True,'official_bake':False,'ao_baked':False,'uv_unwrapped':False,'web_derivative_created':False,'production_manifests_written':False}
(HERE/'blender-inspection.json').write_text(json.dumps(report,indent=2)+'\n')
# Exact inspection inputs are already copied and hashed in fixture-inputs.json.
print(json.dumps(report,indent=2))
