#!/usr/bin/env python3
"""Exercise proposed bridge geometry as real mesh lists, without Blender/export.

Uses the repository's actual pure-Python generator helpers; only bpy object
emission and material construction are stubbed, as test_facade_board_faces.py does.
No repository file, GLB, manifest, sidecar, grade or ticket is written.
"""
from __future__ import annotations
import copy, dataclasses, hashlib, importlib.util, json, math, pathlib, sys, types
OUT = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path('/workspace/chicago/chicago/4d')
sys.path.insert(0, str(ROOT/'generators'))
sys.modules.setdefault('bpy', types.ModuleType('bpy'))
from common import mesh
from archetypes import bridge_timber as old_build
from archetypes import bridge_timber_params as old_params
import mesh_inputs

def load(name, path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod
new_params=load('proposal_bridge_timber_params',OUT/'after/chicago/4d/generators/archetypes/bridge_timber_params.py')
build_path=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else OUT/'after/chicago/4d/generators/archetypes/bridge_timber.py'
new_build=load('proposal_bridge_timber',build_path)

class RecordedMesh(mesh.MeshBuilder):
    def __init__(self,name):
        super().__init__(name); self.boxes=[]
    def add_box(self,*args,**kwargs):
        self.boxes.append((args,kwargs)); return super().add_box(*args,**kwargs)
    def to_object(self,mats=None): return self
for module in (old_build,new_build):
    module.MeshBuilder=RecordedMesh
    module.simple_material=lambda name,*args,**kwargs:name

def digest_mesh(b):
    value={k:getattr(b,k) for k in ('verts','faces','conf','mat_index')}
    return hashlib.sha256(json.dumps(value,separators=(',',':')).encode()).hexdigest()

def assert_finite_mesh(b):
    assert all(math.isfinite(c) for v in b.verts for c in v)
    assert len(b.verts)==len(b.conf)
    assert len(b.faces)==len(b.mat_index)
    assert all(len(set(f))>=3 and max(f)<len(b.verts) for f in b.faces)
    # Every quad/triangle must have a nonzero plane area (fan cross product).
    for face in b.faces:
        a=b.verts[face[0]]; q=b.verts[face[1]]; r=b.verts[face[2]]
        u=[q[i]-a[i] for i in range(3)];v=[r[i]-a[i] for i in range(3)]
        cross=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
        assert sum(c*c for c in cross)>1e-20

records=[]
for path in sorted((ROOT/'data/structures').rglob('*.json')):
    data=json.loads(path.read_text())
    if data.get('archetype')!='bridge_timber':continue
    for phase in data['phases']:
        records.append((path,data,phase))
assert len(records)==6
report={'scope':'pure-Python mesh-list validation; not Blender export/bake/app/image-match validation','records':[],'checks':[]}
for path,data,phase in records:
    old=old_params.from_phase(phase,data);new=new_params.from_phase(phase,data)
    assert new.railing_kind=='pole'
    a=old_build.build(old,data['id']);b=new_build.build(new,data['id'])
    assert_finite_mesh(a);assert_finite_mesh(b)
    assert digest_mesh(a)==digest_mesh(b),(data['id'],'default pole/default disabled geometry changed')
    old.railing=False;new.railing=False
    assert digest_mesh(old_build.build(old,'off'))==digest_mesh(new_build.build(new,'off'))
    before=mesh_inputs.structure_inputs_doc(data,phase)
    after=copy.deepcopy(before)
    after['params']=mesh_inputs._params_doc(new_params.from_phase(phase,data))
    after['code']['archetypes/bridge_timber.py']=hashlib.sha256((OUT/'after/chicago/4d/generators/archetypes/bridge_timber.py').read_bytes()).hexdigest()
    assert before!=after
    report['records'].append({'id':data['id'],'phase':phase['id'],'default_geometry_unchanged':True,'railing_disabled_geometry_unchanged':True,'default_mesh_sha256':digest_mesh(a),'before_inputs_sha256':mesh_inputs.structure_inputs_sha(data,phase),'freshness_changes':['params.fields.railing_kind default pole','code.archetypes/bridge_timber.py'],'requires_recipe_refresh_or_rebuild':True})
report['checks'].append('All six current record phases resolve; default pole and disabled rails are byte-identical mesh lists to current generator.')

new_data=json.loads((OUT/'after/chicago/4d/data/structures/dearborn_street_drawbridge.json').read_text())
phase=new_data['phases'][0];p=new_params.from_phase(phase,new_data)
assert p.railing and p.railing_kind=='board'
assert 'railing_kind' in new_params.CONSUMED
assert p.conf('railing_kind')==.5
board=new_build.build(p,'board');assert_finite_mesh(board)
old_phase=json.loads((OUT/'before/chicago/4d/data/structures/dearborn_street_drawbridge.json').read_text())['phases'][0]
old_p=old_params.from_phase(old_phase)
pole=old_build.build(old_p,'pole')
assert digest_mesh(board)!=digest_mesh(pole)
# Unchanged non-railing geometry: remove all rail geometry in both builds.
new_no_rail=dataclasses.replace(p,railing=False,railing_kind='pole');old_no_rail=dataclasses.replace(old_p,railing=False)
assert digest_mesh(new_build.build(new_no_rail,'off'))==digest_mesh(old_build.build(old_no_rail,'off'))
report['checks'].append('Only Dearborn opts into board; actual mesh differs, while all non-railing geometry remains identical.')

rail=RecordedMesh('railing');new_build._railing(rail,p,p.deck_height_m,p.conf('railing'))
board_boxes=[];cap_boxes=[];post_boxes=[]
for args,kwargs in rail.boxes:
    x0,y0,z0,x1,y1,z1,confidence,material=args
    assert x0<x1 and y0<y1 and z0<z1
    assert confidence==.5
    if material==new_build.M_LOG:post_boxes.append(args)
    elif math.isclose(z1,p.deck_height_m+.95,abs_tol=1e-8):cap_boxes.append(args)
    else:board_boxes.append(args)
assert len(cap_boxes)>0 and len(board_boxes)==5*len(cap_boxes)
for args in board_boxes+cap_boxes:
    x0,y0,z0,x1,y1,z1,confidence,material=args
    for boundary in [p.span_m/2-p.draw_span_m/2,p.span_m/2,p.span_m/2+p.draw_span_m/2]:
        assert not x0<boundary<x1,(x0,x1,boundary)
    assert -.0001<=x0<x1<=p.span_m+.0001
    assert z0>=p.deck_height_m and z1<=p.deck_height_m+.95+1e-9
    assert material==new_build.M_DECK
assert all(math.isclose(a[5],p.deck_height_m+.95-new_build.BOARD_CAP_T_M,abs_tol=1e-8) for a in post_boxes)
# No cap/post volume overlap, including the top surfaces exposed from above.
for post in post_boxes:
    for cap in cap_boxes:
        assert min(post[5],cap[5])-max(post[2],cap[2])<=1e-9
# Reflection symmetry of the two parapets across the deck midline.
left=[];right=[]
for args in board_boxes+cap_boxes+post_boxes:
    xyz=args[:6]
    if (xyz[1]+xyz[4])/2<0:
        left.append(tuple(round(v,9) for v in xyz))
    else:
        x0,y0,z0,x1,y1,z1=xyz
        right.append(tuple(round(v,9) for v in [x0,p.width_m-y1,z0,x1,p.width_m-y0,z1]))
assert sorted(left)==sorted(right)
report['checks'].append('Board/cap intervals stop at both draw ends and the two-leaf meeting line; no box crosses a moving-leaf joint; finite, positive, symmetric faces; no cap/post overlap.')

for value in ['glass','',None,False,7]:
    try:dataclasses.replace(p,railing_kind=value).validate()
    except new_params.ParamError:pass
    else:raise AssertionError(('invalid kind accepted',value))
try:dataclasses.replace(p,railing=False).validate()
except new_params.ParamError:pass
else:raise AssertionError('board without railing accepted')
for value in ['glass','',None,False,7]:
    bad=copy.deepcopy(phase);bad['form']['railing_kind']['value']=value
    try:new_params.from_phase(bad,new_data)
    except new_params.ParamError:pass
    else:raise AssertionError(('invalid phase kind accepted',value))
report['checks'].append('Unknown/empty/non-string kinds and board-without-railing are rejected by direct params and phase resolver.')
report['board_mesh']={'vertices':len(board.verts),'faces':len(board.faces),'sha256':digest_mesh(board),'board_boxes':len(board_boxes),'cap_boxes':len(cap_boxes),'post_boxes':len(post_boxes)}
(OUT/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(f"PASS: {len(records)} phases; {len(report['checks'])} grouped assertions; board mesh {len(board.verts)} vertices / {len(board.faces)} faces")
for c in report['checks']:print('  '+c)
