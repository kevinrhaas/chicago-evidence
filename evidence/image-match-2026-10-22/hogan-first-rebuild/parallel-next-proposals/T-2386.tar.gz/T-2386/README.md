# T-2386 — Wolf Point roof chimney proposal

Apply `T-2386.patch` from `/workspace/chicago` after the current gate has finished.
The patch only adds one source record and three supported form attributes to the
Wolf Point Tavern record. It changes geometry: the next bake moves its current
full-height exterior gable stack onto the roof and reduces the visible head.

## What was read

The actual `chicago/reference/images/chicago/chicago_wolf_point_1833_nypl.jpg`
was opened at original resolution. The sheet names the depicted year 1833, its
publisher Rufus Blanchard and lithographer Chas. Shober & Co.; the deposit line
states publication in 1867. The other seven T-2386 views were inspected during
the initial research pass. The 1867/1871/1892 family consistently draws a small
roof-penetrating head, while the committed generator's default grows a large
external stack against a gable. The source record states which information came
from the actual sheet and which collection metadata came from IMAGE_SOURCES.md.

## Reconstruction and scene date

A roof penetration is an inferred interpretation of a retrospective 1833 view,
not a primary observation of July 1835. Exact ridge fraction 0.58, shaft width
0.45 m and head rise 0.50 m are explicit reconstructed choices. No coordinate,
footprint, building height, roof pitch, use or proprietor is changed. The original
one-chimney count is preserved; the separate slender pipe shown in the picture is
still unresolved, not silently absorbed into that count.

Suggested append-only LIBERTIES text (parent assigns the next available id):

> Wolf Point Tavern roof stack (T-2386): the 1867 Blanchard/Shober lithograph,
> depicting 1833, draws a chimney head through the tavern roof rather than a
> full-height exterior gable stack. This correction uses that inferred disposition
> while retaining the existing reconstructed footprint and roof. The exact
> position at 0.58 along the core ridge, square shaft width 0.45 m and head rise
> 0.50 m are reconstructed within a modest single-flue envelope, not measured
> dimensions. The separate slender pipe, parallel-gable massing, second entrance
> and picture camera remain unresolved; T-2386 remains open.

## Defaults and blast radius

No generator or parameter defaults change. The existing `chimney_ridge_at`,
`ridge_stack_w_m` and `ridge_stack_head_m` consumed parameters already resolve
and build this form. Only `wolf_point_tavern__log_frame_1828.glb` needs a geometry
rebake, plus its compressed web derivative and corresponding manifest/sidecar.
The source citation also becomes reachable through the card's Images tab at
picture compilation. Re-run structure grading/scene compilation as required by
the picture-reference contract. Other houses and the separate tavern stable
are untouched.

## Light checks completed

JSON parsing, pure-Python `from_phase` and `validate` pass on the proposed target.
The only changed resolved parameter fields are the three explicit form values
and their confidence map. Chimney count, footprint and position are unchanged.
See `light-checks.json`. No Blender, browser, broad gate or application smoke was
run, per the coordinator's resource reservation.

## Integration validation still required

1. Apply patch; append the liberty; regenerate its derived ledger through the
   repository's normal command. Add an honest partial-work status/changelog entry.
2. Rebuild just the Wolf Point Tavern master and web derivative; refresh manifest
   entries and sidecars using existing tools. Do not hand-edit hashes.
3. Render identical before/after views for the geometry change and inspect that
   the new small head actually emerges from the roof, with no floating shaft.
4. Solve a reference review camera, run `photo_match.mjs`, inspect the actual
   side-by-side and retain `differs` for the still wrong twin-gable topology,
   second entrance, slender pipe and other unresolved details.
5. Verify its card Images credit and desktop/mobile app view with no page errors,
   then run the required full gate and preflight before any commit/PR.

The ticket is NOT complete and no `matches` verdict is proposed.

## T-2384 held separately

St Mary's sole ticket picture shows a belfry and an enlarged building after its
relocation. Its original-location phase explicitly excludes the undated tower
before the July 1835 target date. Copying that later belfry into the original
1835 church is not a justified visible correction. No St Mary's edit is proposed.
