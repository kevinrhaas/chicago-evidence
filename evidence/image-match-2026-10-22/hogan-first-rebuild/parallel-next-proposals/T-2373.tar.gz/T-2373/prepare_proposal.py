from pathlib import Path
import ast, difflib, hashlib, json, math, subprocess, types, sys, copy
root=Path('/workspace/chicago')
base=root/'chicago/4d'
out=Path('/tmp/chicago-next-model/T-2373')
changes={}
def replace(text,a,b):
    assert text.count(a)==1,(a,text.count(a))
    return text.replace(a,b,1)
rel='chicago/4d/generators/archetypes/fort_structure_params.py'
old=(root/rel).read_text()
new=replace(old,'PAINTS = ("unpainted", "whitewash", "white", "brick", "earth", "stone")\n','''PAINTS = ("unpainted", "whitewash", "white", "brick", "earth", "stone")
LANTERN_PROFILES = ("legacy", "birdcage_dome")
''')
new=replace(new,'    "upper_overhang_m", "lantern",\n','    "upper_overhang_m", "lantern", "lantern_profile",\n')
new=replace(new,'    lantern: bool = False\n','''    lantern: bool = False
    # T-2373: pictured dome, cage and gallery rail. The default retains the
    # previous drum/pyramid; this profile has effect only on a lit tower.
    lantern_profile: str = "legacy"
''')
new=replace(new,'    def validate(self) -> None:\n','''    def validate(self) -> None:
        if self.lantern_profile not in LANTERN_PROFILES:
            raise ParamError(
                f"lantern_profile {self.lantern_profile!r} not in {LANTERN_PROFILES}")
        if self.lantern_profile != "legacy" and (
                self.kind != "tower" or not self.lantern):
            raise ParamError("lantern_profile needs kind tower and lantern true")
''')
new=replace(new,'        lantern=bool(val("lantern", False)),\n','''        lantern=bool(val("lantern", False)),
        lantern_profile=str(val("lantern_profile", "legacy")),
''')
compile(new,rel,'exec')
changes[rel]=(old,new)
(out/'fort_structure_params.proposed.py').write_text(new)
rel='chicago/4d/generators/archetypes/fort_structure.py'
old=(root/rel).read_text()
new=replace(old,'''    Everything about the PROFILE is the archetype's. The record carries the one
    documented number — forty feet — and the lantern; no source reached says what
    shape the 1832 tower was or what it was built of. See
    docs/RESEARCH/chicago_lighthouse_1832.md and the liberty that owns it.
''','''    The shaft's dimensions remain the earlier reconstruction. T-2373's
    opt-in lantern profile reads its dome, cage and gallery rail from the
    Castelnau harbour lithograph; exact sections/counts remain reconstructed.
    See docs/LIBERTIES.md L-lighthouse-birdcage-2373.
''')
new=replace(new,'''    c_l = p.conf("lantern", "reconstructed")
    gal = ring(r1 * 1.34, shaft)
''','''    if p.lantern_profile == "birdcage_dome":
        _birdcage_lantern(b, p, cx, cy, r1, shaft, h)
        return

    c_l = p.conf("lantern", "reconstructed")
    gal = ring(r1 * 1.34, shaft)
''')
new+='''

def _birdcage_lantern(b: MeshBuilder, p: FortStructureParams,
                      cx: float, cy: float, r1: float,
                      shaft: float, h: float) -> None:
    """T-2373: a pictured lantern silhouette, with reconstructed scantlings.

    Eight cage uprights, twelve gallery posts, a rounded cap and a finial.
    All counts and sections are choices within the small retrospective view.
    No shaft, footprint, paint, coordinate or reflector is derived here.
    The old upper silhouette limit h + 0.7*r1 is retained: how Andreas's
    forty feet relates to the existing shaft/lantern split remains open.
    """
    c = p.worst_conf("lantern", "lantern_profile")
    glass = b.named_mat("lantern_glass", *openings.glass_material_spec())
    n = 12
    gal_r, lantern_r = r1 * 1.34, r1 * 0.86
    floor = shaft + 0.09

    def ring(radius, z, count=n):
        return [(cx + radius * math.cos(2 * math.pi * i / count),
                 cy + radius * math.sin(2 * math.pi * i / count), z)
                for i in range(count)]

    def band(inner, outer, bottom, top, mat):
        li, lo = ring(inner, bottom), ring(outer, bottom)
        ui, up = ring(inner, top), ring(outer, top)
        for i in range(n):
            j = (i + 1) % n
            b.add_poly([li[i], li[j], lo[j], lo[i]], c, mat)
            b.add_poly([ui[i], up[i], up[j], ui[j]], c, mat)
            b.add_poly([lo[i], lo[j], up[j], up[i]], c, mat)
            b.add_poly([li[j], li[i], ui[i], ui[j]], c, mat)

    # Full gallery floor; its underside meets the existing shaft at shaft.
    lower, upper = ring(gal_r, shaft), ring(gal_r, floor)
    b.add_poly(list(reversed(lower)), c, M_TRIM)
    b.add_poly(upper, c, M_TRIM)
    for i in range(n):
        j = (i + 1) % n
        b.add_poly([lower[i], lower[j], upper[j], upper[i]], c, M_TRIM)

    # The rail's height, 45 mm square posts and 55 by 50 mm ring are
    # reconstructed. Existing DARK is a neutral frame proxy, not known paint.
    for i in range(n):
        a = 2 * math.pi * i / n
        x, y = cx + (gal_r - 0.035) * math.cos(a), cy + (gal_r - 0.035) * math.sin(a)
        b.add_box(x - 0.0225, y - 0.0225, floor,
                  x + 0.0225, y + 0.0225, floor + 0.65, c, M_DARK)
    band(gal_r - 0.055, gal_r, floor + 0.60, floor + 0.65, M_DARK)

    # Pane surface plus visible cage members, using the town's existing
    # dark glossy GLASS row. No new optical or transparency claim.
    bottom, top = ring(lantern_r, floor), ring(lantern_r, h)
    for i in range(n):
        j = (i + 1) % n
        b.add_poly([bottom[i], bottom[j], top[j], top[i]], c, glass)
    for i in range(8):
        a = 2 * math.pi * i / 8
        x, y = cx + (lantern_r + 0.012) * math.cos(a), cy + (lantern_r + 0.012) * math.sin(a)
        b.add_box(x - 0.0275, y - 0.0275, floor,
                  x + 0.0275, y + 0.0275, h, c, M_DARK)
    band(lantern_r - 0.025, lantern_r + 0.04, floor, floor + 0.06, M_DARK)
    band(lantern_r - 0.025, lantern_r + 0.04, h - 0.06, h, M_DARK)

    # Six latitudinal bands round the cap instead of the old pointed pyramid.
    # A slight skirt covers the twelve-sided drum below this 24-sided cap.
    cap_r, rise = lantern_r * 1.06, r1 * 0.55
    last = ring(cap_r, h, 24)
    b.add_poly(list(reversed(last)), c, M_ROOF)
    for k in range(1, 6):
        angle = (math.pi / 2.0) * k / 6.0
        current = ring(cap_r * math.cos(angle), h + rise * math.sin(angle), 24)
        for i in range(24):
            j = (i + 1) % 24
            b.add_poly([last[i], last[j], current[j], current[i]], c, M_ROOF)
        last = current
    apex = (cx, cy, h + rise)
    for i in range(24):
        b.add_poly([last[i], last[(i + 1) % 24], apex], c, M_ROOF)

    # Slender finial, its top at the previous profile's maximum height.
    fin_r, fin_h = max(0.025, r1 * 0.025), r1 * 0.15
    lo = ring(fin_r, h + rise, 8)
    hi = ring(fin_r, h + rise + fin_h * 0.8, 8)
    for i in range(8):
        j = (i + 1) % 8
        b.add_poly([lo[i], lo[j], hi[j], hi[i]], c, M_DARK)
        b.add_poly([hi[i], hi[j], (cx, cy, h + rise + fin_h)], c, M_DARK)
'''
compile(new,rel,'exec')
changes[rel]=(old,new)
(out/'fort_structure.proposed.py').write_text(new)
rel='chicago/4d/data/structures/chicago_lighthouse_1832.json'
old=(root/rel).read_text()
doc=json.loads(old)
doc['phases'][0]['form']['lantern_profile']={
 'value':'birdcage_dome','confidence':'inferred',
 'sources':['castelnau_1842_chicago_harbor','lighthousefriends_chicago'],
 'note':"FIRST PICTURE-BOUNDED LANTERN REFINEMENT, T-2373. The committed Castelnau harbour lithograph (inventory: scene circa1838, published1842) depicts a rounded cap, finial, visible cage uprights and a gallery rail. The 1832 tower's bird-cage lantern room is also named by lighthousefriends_chicago. These support an inferred form choice for the earlier July1835 phase by continuity, not a claim that an1838 picture documents its1835 detail unchanged. Eight cage uprights, twelve gallery posts, 55mm cage members, a650mm rail, the dome's ellipsoidal curve and all sections are reconstructed. Glazing uses the town's existing dark-glass proxy and frame/roof finishes remain reconstructed. The existing shaft, taper, width, gallery and drum radii, position and bare-stone paint are retained; they have not been measured from this picture. The previous maximum height is retained, and whether Andreas's forty feet includes the cap remains unresolved. The lantern's reflectors are not modelled. See docs/LIBERTIES.md L-lighthouse-birdcage-2373. This increment is not an image match."
}
new=json.dumps(doc,indent=2,ensure_ascii=False)+'\n'
changes[rel]=(old,new)
source={
 'id':'castelnau_1842_chicago_harbor','type':'illustration',
 'citation':"Chicago harbour entrance, circa1838, after Francis de Castelnau; lithograph published by A. Bertrand, Paris,1842, in Vues et souvenirs de l'Amerique du Nord. Attribution/publication metadata follows the committed project image inventory.",
 'author':'After Francis de Castelnau; publisher A. Bertrand, Paris (project image-inventory attribution)',
 'date':'1842 (publication per committed image inventory; no fresh catalogue check in this increment)',
 'describes_date':'circa1838 (project image inventory); after the1835-07-01 scene',
 'repository':'Local surrogate in chicago/reference/images/chicago/, catalogued by the project as Wikimedia Commons reproduction',
 'url':'https://commons.wikimedia.org/wiki/File:Chicago1838.jpg',
 'locator':'chicago/reference/images/chicago/chicago_harbor_lighthouse_1838.jpg,640x361px; inventory entry in chicago/reference/images/IMAGE_SOURCES.md.',
 'tier':5,'rights_status':'public_domain',
 'rights_note':'The committed IMAGE_SOURCES.md inventory attributes this lithograph to1842 publication by A.Bertrand and labels it public domain by publication age. This records that existing inventory determination, not a new remote rights or catalogue verification. Retain the Castelnau/Bertrand credit and Commons source link with the reproduction.',
 'asset_use':'cross_check','verified':True,
 'access_notes':"The actual committed640x361px picture and its inventory entry were read for T-2373. Original plate/volume and remote catalogue were not independently reopened in this increment; publication attribution follows the repository's existing metadata.",
 'note':"The harbour view shows the1832 lighthouse at the right with a tapered shaft, gallery, railed platform, framed lantern, rounded cap and finial. It is evidence for the depicted circa1838 form, not direct attestation of July1835 details. Lantern-profile continuity into1835 is an explicitly inferred model choice supported also by the documented bird-cage lantern. The lower shaft edge is partly lost in foliage and the image supplies no secure base diameter, surveyed position, paint colour, optic count or historical camera.",
 'what_it_supplies':['a reasonable view of the lighthouse lantern and gallery silhouette in the later harbour composition','a rounded cap, finial, framed lantern and gallery railing'],
 'what_it_does_not_supply':['independent tower dimensions, coordinates, paint or a surveyed camera','proof that every depicted detail was present on1July1835','exact member counts, sections, original glazing tone or hidden reflectors']
}
rel='chicago/4d/data/sources/castelnau_1842_chicago_harbor.json'
assert not (root/rel).exists()
changes[rel]=('',json.dumps(source,indent=2,ensure_ascii=False)+'\n')
rel='chicago/4d/docs/LIBERTIES.md'
old=(root/rel).read_text()
new=old.rstrip()+'''

### L-lighthouse-birdcage-2373 — the lighthouse's pictured lantern silhouette

**Covers:** chicago_lighthouse_1832.tower_1832.form.lantern_profile.
**Read:** the committed Castelnau harbour lithograph, attributed in IMAGE_SOURCES.md
to a circa1838 view published by A.Bertrand in1842, shows a rounded cap, finial,
cage uprights and gallery rail. lighthousefriends_chicago names a bird-cage lantern
on the1832 tower. The later picture bounds an inferred1835 profile by continuity;
it does not attest unchanged detail on1July1835.
**Reconstructed:** eight55mm square cage uprights, twelve45mm square gallery posts,
a650mm rail with a55by50mm top ring;60mm lower/upper cage collars. The gallery
radius remains1.34times the shaft's top radius and its slab90mm thick; the lantern
radius remains0.86times that radius. The rounded cap's horizontal radius is
1.06times the lantern radius, its rise0.55times the shaft-top radius; its profile
is a six-band ellipsoid, not a measured dome. The finial is0.15times that radius
high, radius max(25mm,0.025times shaft-top radius). Member counts, exact frame
layout and hidden joints are choices within the pictured silhouette. Pane tone
uses the shared reconstructed GLASS row; roof and dark-frame finish are review
proxies, not claimed historic paint or metal colour. The reflectors remain absent.
**Not resolved:** the existing tower width, taper, shaft/lantern split and total
height interpretation. The new cap/finial keeps the previous maximum height:
nominal12.19m plus0.7times the shaft-top radius. Andreas's forty feet may include
the cap; the current reconstruction does not settle that. Bare-stone paint stays
reconstructed. A monochrome lithograph is no paint sample. No footprint,
position or surveyed camera is derived from this sheet.
**How to resolve:** fit and compare actual reference views after a pinned bake;
read remaining profile/proportion differences, and use a contemporary elevation
or specification to replace the reconstructed counts and sections.
**Ticket:** T-2373. The full picture-matching acceptance stays open.
**Recorded:** 2026-10-22.
'''
changes[rel]=(old,new)
# Keep newly written provenance prose readable without rewriting old research.
import re
def spaced(value):
 return re.sub(r'(?<=[A-Za-z])(?=\d)|(?<=\d)(?=[A-Za-z])', ' ', value)
for rel,(a,b) in list(changes.items()):
 if rel.endswith('castelnau_1842_chicago_harbor.json'):
  value=json.loads(b)
  def walk(x):
   if isinstance(x,str):return spaced(x)
   if isinstance(x,list):return [walk(v) for v in x]
   if isinstance(x,dict):return {k:walk(v) for k,v in x.items()}
   return x
  b=json.dumps(walk(value),indent=2,ensure_ascii=False)+'\n'
 elif rel.endswith('structures/chicago_lighthouse_1832.json'):
  value=json.loads(b)
  value['phases'][0]['form']['lantern_profile']['note']=spaced(value['phases'][0]['form']['lantern_profile']['note'])
  b=json.dumps(value,indent=2,ensure_ascii=False)+'\n'
 elif rel.endswith('docs/LIBERTIES.md'):
  at=b.index('### L-lighthouse-birdcage-2373')
  b=b[:at]+spaced(b[at:])
 changes[rel]=(a,b)
patch=''
for rel,(a,b) in changes.items():
 patch+=''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile=('a/'+rel if a else '/dev/null'),tofile='b/'+rel))
(out/'T-2373.patch').write_text(patch)
(out/'proposed-structure.json').write_text(changes['chicago/4d/data/structures/chicago_lighthouse_1832.json'][1])
(out/'proposed-source.json').write_text(changes['chicago/4d/data/sources/castelnau_1842_chicago_harbor.json'][1])
# Exact current manifest blast radius; no build or renderer is run.
manifest=json.loads((base/'assets/manifest.json').read_text());manifest=manifest.get('assets',manifest)
affected=[]
for name,entry in manifest.items():
 sid=entry.get('structure_id');p=base/'data/structures'/f'{sid}.json'
 if not sid or not p.exists():continue
 r=json.loads(p.read_text())
 if r.get('archetype')=='fort_structure':
  affected.append({'master':name,'structure_id':sid,'phase_id':entry.get('phase_id'),'expected_vertex_change':sid=='chicago_lighthouse_1832'})
(out/'blast-radius.json').write_text(json.dumps(affected,indent=2)+'\n')
(out/'source-snapshot.json').write_text(json.dumps({'head':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'files':{rel:hashlib.sha256((root/rel).read_bytes()).hexdigest() for rel,(a,b) in changes.items() if a}},indent=2)+'\n')
print('Generated unapplied T-2373.patch:',len(patch.encode()),'bytes; recipe blast radius',len(affected),'masters; intended changed geometry1')
