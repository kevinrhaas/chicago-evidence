"""Lightweight proposal checks. No Blender, browser, publication or tracked writes."""
from pathlib import Path
from dataclasses import asdict, replace
from types import ModuleType, SimpleNamespace
import ast, copy, hashlib, json, math, sys
root=Path('/workspace/chicago/chicago/4d')
out=Path('/tmp/chicago-next-model/T-2373')
sys.dont_write_bytecode=True
def load(name,text):
 m=ModuleType(name);sys.modules[name]=m
 exec(compile(text,name,'exec'),m.__dict__)
 return m
old=load('t2373_old_params',(root/'generators/archetypes/fort_structure_params.py').read_text())
new=load('t2373_new_params',(out/'fort_structure_params.proposed.py').read_text())
rows=[]
for p in sorted((root/'data/structures').glob('*.json')):
 try:r=json.loads(p.read_text())
 except Exception:continue
 if r.get('archetype')!='fort_structure':continue
 for ph in r.get('phases',[]):
  a=old.from_phase(ph,r);b=new.from_phase(ph,r)
  data=asdict(b);assert data.pop('lantern_profile')=='legacy'
  assert data==asdict(a),(r['id'],ph['id'])
  rows.append((r['id'],ph['id']))
record=json.loads((out/'proposed-structure.json').read_text())
selected=new.from_phase(record['phases'][0],record)
assert selected.lantern_profile=='birdcage_dome'
assert 'lantern_profile' in new.CONSUMED
for p in [replace(selected,lantern_profile='unknown'),
          replace(selected,lantern=False),
          replace(selected,kind='quarters')]:
 try:p.validate()
 except new.ParamError:pass
 else:raise AssertionError('invalid profile accepted')
class Collect:
 def __init__(self):self.faces=[];self.named={}
 def add_poly(self,points,confidence,mat=0):
  self.faces.append((tuple(tuple(float(v) for v in p) for p in points),float(confidence),mat))
  return []
 def named_mat(self,name,*spec):
  self.named.setdefault(name,(1000+len(self.named),spec))
  return self.named[name][0]
mesh_tree=ast.parse((root/'generators/common/mesh.py').read_text())
mesh_class=next(n for n in mesh_tree.body if isinstance(n,ast.ClassDef) and n.name=='MeshBuilder')
add_box=next(n for n in mesh_class.body if isinstance(n,ast.FunctionDef) and n.name=='add_box')
box_ns={}
exec(compile(ast.fix_missing_locations(ast.Module(body=[copy.deepcopy(add_box)],type_ignores=[])),'actual_add_box','exec'),box_ns)
Collect.add_box=box_ns['add_box']
def extract(text):
 tree=ast.parse(text)
 funcs=[copy.deepcopy(n) for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['_tower','_birdcage_lantern']]
 ns={'math':math,'MeshBuilder':Collect,'FortStructureParams':new.FortStructureParams,
     'M_WALL':0,'M_ROOF':1,'M_DARK':2,'M_TRIM':3,
     'openings':SimpleNamespace(glass_material_spec=lambda:((0.1134,0.1164,0.1144,1.0),0.065))}
 exec(compile(ast.fix_missing_locations(ast.Module(body=funcs,type_ignores=[])),'proposal_tower','exec'),ns)
 return ns
a=extract((root/'generators/archetypes/fort_structure.py').read_text())
b=extract((out/'fort_structure.proposed.py').read_text())
baseline=replace(selected,lantern_profile='legacy')
before,after=Collect(),Collect()
a['_tower'](before,baseline);b['_tower'](after,baseline)
assert before.faces==after.faces
# No-lantern legacy branch remains identical too.
before_off,after_off=Collect(),Collect()
a['_tower'](before_off,replace(baseline,lantern=False))
b['_tower'](after_off,replace(baseline,lantern=False))
assert before_off.faces==after_off.faces
detail=Collect();b['_tower'](detail,selected)
assert detail.named.keys()=={'lantern_glass'}
assert len(detail.faces)>len(before.faces)
def finite_nonzero(faces):
 for pts,c,mat in faces:
  assert math.isfinite(c) and all(math.isfinite(v) for p in pts for v in p)
  assert len(pts)>=3
  # Newell normal; avoids a degenerate first triangle hiding a valid n-gon.
  norm=[0.,0.,0.]
  for p,q in zip(pts,pts[1:]+pts[:1]):
   norm[0]+=(p[1]-q[1])*(p[2]+q[2])
   norm[1]+=(p[2]-q[2])*(p[0]+q[0])
   norm[2]+=(p[0]-q[0])*(p[1]+q[1])
  assert sum(x*x for x in norm)>1e-18,pts
finite_nonzero(detail.faces)
def bounds(c):
 vs=[p for face,_,_ in c.faces for p in face]
 return {'min':[min(p[i] for p in vs) for i in range(3)],
         'max':[max(p[i] for p in vs) for i in range(3)]}
assert abs(bounds(detail)['max'][2]-bounds(before)['max'][2])<1e-10
report={
 'status':'passed','checks':[
 'all25 existing fort_structure phase parameter sets preserve every old field and confidence with default legacy',
 'opt-in lighthouse record resolves and new field is CONSUMED',
 'unknown profile, non-lantern and non-tower opt-ins rejected',
 'legacy tower face stream identical to current generator',
 'legacy no-lantern tower face stream identical to current generator',
 'new dome/cage/rail/finial path produces finite nondegenerate faces',
 'one named existing-GLASS material only on opt-in path',
 'maximum silhouette height retained'],
 'resolved_default_phases':len(rows),
 'legacy_faces':len(before.faces),'detail_faces':len(detail.faces),
 'legacy_triangles_estimate':sum(len(p)-2 for p,_,_ in before.faces),
 'detail_triangles_estimate':sum(len(p)-2 for p,_,_ in detail.faces),
 'legacy_bounds_m':bounds(before),'detail_bounds_m':bounds(detail),
 'limitations':'Raw geometry/parameter checks only. No Blender, baked GLB, normal/smoothing export, material export, derivative, renderer, image match or scene-budget validation.'
}
(out/'focused-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
