# T-2373 — unapplied lighthouse lantern geometry increment

Status: READY AS AN UNAPPLIED PROPOSAL, NOT BAKED OR RENDERED.
No repository files, branch, ticket, publisher output or accepted camera changed.

## Concrete geometry change

T-2373.patch adds the consumed, validated opt-in parameter
lantern_profile=birdcage_dome and enables it on chicago_lighthouse_1832.
It replaces the legacy pyramid silhouette with a rounded six-band cap and finial,
adds eight cage uprights, twelve gallery posts and a top rail, and puts the panes
in the existing shared GLASS material. The profile is rejected on a non-tower or
a tower without a lantern. The default legacy profile retains the old geometry.

The proposal includes generator code, parameter resolution/validation, structure
provenance, a specifically identified picture source and an append-only liberty.
It is an actual proposed modeling change, not a reference-only deliverable.
It does not complete T-2373.

## Files

- T-2373.patch: apply-ready unified diff, five repository files.
- fort_structure.proposed.py / fort_structure_params.proposed.py: inspectable
  proposed full generator/parameter modules; not imported by the repository.
- proposed-structure.json / proposed-source.json: inspectable proposed metadata.
- focused_check.py / focused-check.json: lightweight checks and their result.
- blast-radius.json: exact current 25 registered fort_structure masters.
- source-snapshot.json: checkout HEAD and input hashes when proposal was generated.
- prepare_proposal.py: regenerates the proposal from current source into /tmp only.
- ARTIFACTS.json: file byte counts and SHA256 hashes.

## Source and limits

The actual pictures inspected:
chicago/reference/images/chicago/chicago_harbor_lighthouse_1838.jpg (640x361)
and chicago_dearborn_drawbridge_1834.png (1920x1346).

The new castelnau_1842_chicago_harbor source records the committed inventory's
credit: after Francis de Castelnau, A. Bertrand, Paris, 1842, Vues et souvenirs
de l'Amerique du Nord; Commons source https://commons.wikimedia.org/wiki/File:Chicago1838.jpg .
Its public-domain publication attribution is the existing IMAGE_SOURCES.md
determination, not a newly claimed remote catalogue/rights verification.

That circa 1838 view is later than July 1835. Transferring the pictured lantern
form by continuity is inferred, not attested scene-date detail. The existing
lighthousefriends_chicago record independently names a bird-cage lantern.
All sections, member counts, cap curve, post pattern and hidden joints remain
reconstructed. No position, footprint, paint, shaft taper or reflector is inferred
from this sheet.

The earlier Andreas source note says its plate lacks a beacon, yet the committed
PNG visibly includes a tower. Do not repeat that sentence as an image reading.
This patch does not depend on that disputed descriptive sentence: it uses the
closer harbour picture with explicit Castelnau/Bertrand inventory provenance.
If reusing the Andreas note later, reconcile it with the actual image.

## Exact blast radius

- Intended changed geometry: chicago_lighthouse_1832__tower_1832.glb only.
- The fort_structure.py module is hashed whole by mesh_inputs._code_shas, and the
  new dataclass field also enters resolved parameter hashing.
- Therefore ALL 25 current registered fort_structure masters are recipe-stale,
  not just the lighthouse. blast-radius.json lists every master and structure.
- The other 24 structures never enter the lantern path; their emitted vertices
  should remain identical. Their recipe metadata must still be refreshed through
  the supported build path. Do not hand-edit freshness hashes.
- Current parameter/default tests cover all 25 phases. The legacy tower face
  streams (with and without lantern) are exactly unchanged under the proposal.
- Only the opted-in lighthouse uses one extra referenced named material, the
  existing town GLASS row. Expect one additional material primitive; measure
  actual draw-call/scene impact after export rather than asserting it passed.
- Raw geometry grows from 72 faces/~132 triangles to 463 faces/~930 triangles.
  These are pre-export counts, not baked mesh or renderer performance numbers.

## Lightweight checks already run

From any directory:
python3 /tmp/chicago-next-model/T-2373/focused_check.py

Passed in about 0.1 s, no Blender/browser:
all 25 old fort parameter sets retain their previous fields/confidence under
the legacy default; new profile resolves and is CONSUMED; invalid combinations
are rejected; old/default tower face streams are identical; new geometry has
finite nondegenerate faces; max silhouette height is unchanged.

git -C /workspace/chicago apply --check /tmp/chicago-next-model/T-2373/T-2373.patch
also passed. The patch has NOT been applied.

## Parent integration and required validation

Wait until the current parent gate finishes and coordinate the next ticket
increment/claim before applying. This handoff authorizes no independent shared
checkout mutation.

Working directory for integration/build tools: /workspace/chicago/chicago/4d.

1. Recheck patch applicability against the selected branch. Apply the patch only
   when the parent chooses this increment.
2. Preserve the prior lighthouse master and render its actual source comparisons.
   A provisional camera must remain labelled provisional and in research until
   solved; no matches verdict is implied by these geometry checks.
3. Use the already verified pinned Blender build path. Batch the exact comma-list
   of 25 structure ids from blast-radius.json in one build.py --only invocation.
   Omitting --scene resolves all distinct phases across scenes; forcing only 1835
   would skip first-fort recipe refreshes that are also affected.
4. Regenerate required web derivatives from newly written masters, compile scenes
   and pictures, and refresh generated manifests/sidecars through supported tools.
   Confirm that the other 24 master bytes stay unchanged; investigate any drift.
5. Inspect exported normals, cap/frame/pane overlaps, finial and gallery rail.
   The lightweight checks do not establish Blender export or final visual quality.
6. Render before/after against actual reference views. Compare cap curvature,
   gallery overhang, cage proportions, member widths and lighting element by
   element; record the remaining differences honestly.
7. Include the picture and its credit on the structure card. Adjudicate any grade
   effect according to the reasonable-picture rule, not a provisional camera.
   Do not enroll a guessed camera merely to obtain attested grading.
8. Measure the added glazing material's actual primitive/draw-call impact and run
   relevant focused checks, desktop/mobile smoke and required full gate/preflight
   for the final diff. Add changelog/STATUS/ROADMAP and any asset-license updates
   needed by the integrating increment.

## Explicitly unresolved matching

The retained current tower is 5.6 m wide and its top-to-base silhouette does not
yet match all pictures. Gallery overhang and drum/shaft proportions are still
the previous reconstruction. The existing model's nominal 12.19 m parameter
does not include all cap height: the legacy/new maximum is 13.4052 m.
Andreas's forty feet may be a total height; this proposal deliberately documents
that unresolved interpretation rather than silently declaring the old mesh
dimension historically correct. The dome/finial keep that previous maximum.

The 1838 shaft's lower right edge is lost in foliage, so it cannot independently
supply a full base diameter or taper. Bare-stone paint is still reconstructed;
a monochrome picture does not establish whitewash or bare stone. Reflected light,
exact cage count, glass appearance, optics and hidden construction remain
unmatched. No camera is supplied as solved and no verdict is matches.
