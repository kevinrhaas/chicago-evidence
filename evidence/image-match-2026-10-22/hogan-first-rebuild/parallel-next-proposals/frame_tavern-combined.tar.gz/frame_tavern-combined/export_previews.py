"""Two isolated copied-module previews; never writes manifests or tracked files."""
from __future__ import annotations
import hashlib,importlib.util,json,math,pathlib,sys
import bpy
assert bpy.app.version[:3]==(4,5,3),bpy.app.version_string
ROOT=pathlib.Path('/workspace/chicago/chicago/4d')
OUT=pathlib.Path('/tmp/chicago-next-model/frame_tavern-combined')
PROPOSED=OUT/'proposed';PREVIEW=OUT/'preview-root'
sys.path[:0]=[str(PROPOSED/'generators'),str(ROOT/'generators')]
import archetypes
archetypes.__path__.append(str(ROOT/'generators/archetypes'))
from archetypes import frame_tavern as proposed
from archetypes import frame_tavern_params as params
from common.mesh import reset_scene
import emit
assert pathlib.Path(proposed.__file__).resolve()==PROPOSED/'generators/archetypes/frame_tavern.py'
assert pathlib.Path(params.__file__).resolve()==PROPOSED/'generators/archetypes/frame_tavern_params.py'
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
old=load('baseline_family_frame_tavern',OUT/'baseline/generators/archetypes/frame_tavern.py')
oldparams=load('baseline_family_frame_tavern_params',OUT/'baseline/generators/archetypes/frame_tavern_params.py')
def material(m):
 n=m.node_tree.nodes.get('Principled BSDF') if m.node_tree else None
 return {'name':m.name,'base_color':list(n.inputs['Base Color'].default_value) if n else None,'roughness':n.inputs['Roughness'].default_value if n else None}
def signature(ob):
 m=ob.data
 return {'vertices':[[float(c) for c in v.co] for v in m.vertices],'faces':[list(p.vertices) for p in m.polygons],'materials':[material(x) for x in m.materials],'material_indices':[p.material_index for p in m.polygons],'confidence':[v.value for v in m.attributes['_CONFIDENCE'].data]}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt={'state':'isolated family proposal previews only, not official bake/freshness or image-match acceptance','blender_version':bpy.app.version_string,'generator_sha256':sha(PROPOSED/'generators/archetypes/frame_tavern.py'),'parameters_sha256':sha(PROPOSED/'generators/archetypes/frame_tavern_params.py'),'manifest_written':False,'ao_baked':False,'models':{}}
for id in ['tremont_house_1','green_tree_tavern']:
 legacy=json.loads((OUT/f'baseline/data/structures/{id}.json').read_text());ph=legacy['phases'][0]
 reset_scene();a=signature(old.build(oldparams.from_phase(ph,legacy),id))
 reset_scene();b=signature(proposed.build(params.from_phase(ph,legacy),id))
 assert a==b,f'{id}: disabled default geometry/materials changed'
 rec=json.loads((PROPOSED/f'data/structures/{id}.json').read_text());ph=rec['phases'][0]
 reset_scene();ob=proposed.build(params.from_phase(ph,rec),id);m=ob.data
 assert all(math.isfinite(c) for v in m.vertices for c in v.co)
 conf=[v.value for v in m.attributes['_CONFIDENCE'].data];assert all(0<=c<=1 for c in conf)
 zero=sum(p.area<1e-12 for p in m.polygons);assert zero==0,f'{id}: {zero} zero-area polygons'
 report={'record_sha256':sha(PROPOSED/f'data/structures/{id}.json'),'legacy_default_unchanged':True,'legacy_geometry_material_confidence_sha256':hashlib.sha256(json.dumps(a,sort_keys=True).encode()).hexdigest(),'vertices':len(m.vertices),'polygons':len(m.polygons),'zero_area_polygons':zero,'bounds_xyz':[[min(v.co[i] for v in m.vertices) for i in range(3)],[max(v.co[i] for v in m.vertices) for i in range(3)]],'confidence_min_max':[min(conf),max(conf)],'materials':[material(x) for x in m.materials]}
 emit.unwrap(ob);out=PREVIEW/f'assets/gltf/{id}__{ph["id"]}.proposal.glb';emit.export_glb(ob,id,ph['id'],out)
 report.update(glb=str(out),glb_bytes=out.stat().st_size,glb_sha256=sha(out));receipt['models'][id]=report
 print('FAMILY_PREVIEW_MODEL_OK '+json.dumps({k:report[k] for k in ['glb','glb_bytes','glb_sha256','legacy_default_unchanged']}))
(PREVIEW/'blender-previews-report.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('FAMILY_PREVIEWS_OK')
