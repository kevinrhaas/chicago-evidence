import ast,pathlib,shutil
HERE=pathlib.Path(__file__).parent;TRE=pathlib.Path('/tmp/chicago-next-model/T-2385-next/proposed');GREEN=pathlib.Path('/tmp/chicago-next-model/T-2376/proposed/chicago/4d');OUT=HERE/'proposed'
for f in ['generators/archetypes/frame_tavern.py','generators/archetypes/frame_tavern_params.py','generators/archetypes/__init__.py','data/structures/tremont_house_1.json']:
 shutil.copy2(TRE/f,OUT/f)
shutil.copy2(GREEN/'data/structures/green_tree_tavern.json',OUT/'data/structures/green_tree_tavern.json')
p=OUT/'generators/archetypes/frame_tavern_params.py';s=p.read_text();g=(GREEN/'generators/archetypes/frame_tavern_params.py').read_text()
assert '"eaves_bays"' not in s
s=s.replace('"upper_windows", "stovepipes", "rear_ell_door",','"upper_windows", "stovepipes", "rear_ell_door", "eaves_bays",')
start=g.index('    # A pictured gable-front eaves wall');end=g.index('    # Sheet-iron stovepipes',start);field=g[start:end]
anchor='    # Sheet-iron stovepipes';assert s.count(anchor)==1;s=s.replace(anchor,field+anchor)
start=g.index('        if not isinstance(self.eaves_bays, dict):');end=g.index('        if (not isinstance(self.stovepipes',start);validation=g[start:end]
anchor='        if (not isinstance(self.stovepipes';assert s.count(anchor)==1;s=s.replace(anchor,validation+anchor)
anchor='        stovepipes=int(val("stovepipes", 0)),';assert s.count(anchor)==1;s=s.replace(anchor,'        eaves_bays=val("eaves_bays", {}),\n'+anchor)
p.write_text(s)
p=OUT/'generators/archetypes/frame_tavern.py';s=p.read_text();g=(GREEN/'generators/archetypes/frame_tavern.py').read_text()
def function_span(text,name):
 tree=ast.parse(text);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name);lines=text.splitlines(True);return lines,node.lineno-1,node.end_lineno
lines,a,b=function_span(s,'_fenestration_gable_front');glines,c,d=function_span(g,'_fenestration_gable_front');s=''.join(lines[:a]+glines[c:d]+lines[b:]);p.write_text(s)
print('Combined pure copied modules prepared; source packages untouched')
