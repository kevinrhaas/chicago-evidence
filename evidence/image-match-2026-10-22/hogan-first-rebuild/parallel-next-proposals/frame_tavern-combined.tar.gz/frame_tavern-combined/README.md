# T-2376 + T-2385 — compatible frame_tavern family proposal

State: copied-module combination only. **No tracked changes, manifests, publisher, Blender/browser or accepted match.** Parent integrates centrally after Hogan work. The first Tremont preview remains immutable.

Separate proposals are preserved:

- GreenTree: `/tmp/chicago-next-model/T-2376/` — sparse `eaves_bays` override, only pictured south/x_min=7; north remains6 and gables unchanged. Public-domain Andreas/Braunhold source and separate liberty note retained.
- Tremont: `/tmp/chicago-next-model/T-2385-next/` — three-storey corner treatment plus arched gable feature, raised entries,32° working roof, four slope-offset stacks and roof spar; all reconstructed metrics/hidden details and owner-approved Gifford attribution retained. Cloth/anchor integration remains open.

`proposed/` combines the final copied modules and both data records. The GreenTree change occupies `_fenestration_gable_front`; Tremont uses separate `corner_gable` branches/helpers. Shared parameter additions have independent empty/false/None defaults and validation. `prepare_combined.py` reproducibly combines source packages; it does not modify either source package or repository.

`T-2376-T-2385-combined.patch` is a complete standard unified diff for the chicago repository root: two generator/parameter files, two structure records and append-only liberty text. `git apply --check` passed from `/workspace/chicago`. Recheck before adoption, particularly the liberty EOF hunk. The patch includes no generated output, sidecar/grade/index, changelog, STATUS or ROADMAP; integration must provide those.

Both focused scripts pass against the combined modules:

- `test_tremont.py` / `test-tremont.log`: existing24 record-phase accumulated geometry/materials unchanged with opt-ins absent; Tremont schema/parameters, feature counts, bounds/type/finite/clearance handling and lunette winding pass.
- `test_green_tree.py` / `test-green-tree.log`: default opening calls unchanged; GreenTree south7/north6, opposite/gable calls unchanged; invalid override cases rejected and confidence applied only to its own face.

The actual current asset family is **23 frame_tavern master recipes**; one of the24 CPU-tested record phases is Sauganash's non-manifest log phase. Changed generator bytes and new resolved fields require refresh of that entire family, even when default geometry is identical elsewhere. `staleness-scope.json` names every asset/phase. No shared/common module was edited and no frame_tavern version is currently registered.

`export_previews.py` and guarded `run_exports.sh` are ready for **isolated pinned-Blender4.5.3 previews** after parent local-gate release (`C4D_FAMILY_PARENT_RELEASED=1`). They compare each old target's actual Blender geometry/material/confidence treatment with disabled combined code, then export both copied proposals using the project's actual UV/export functions. Outputs/reports stay under `preview-root/`; no `build.py` or manifest writer runs. These previews do not replace official family build/freshness acceptance.

`preview-root/review/tremont/` has the unchanged provisional six-wall-corner camera from the first7.8m envelope comparison (3.546px point RMS,6.866max). GreenTree's provisional camera and source-pick residuals are now under `preview-root/review/green-tree/`:6.11px per-coordinate RMS,12.65px maximum point residual. Its extreme principal x=-3472.8px is an unconstrained drawing-fit warning and two withheld roof points still differ; it is not a solved physical camera or accepted match. Browser use must be coordinated separately after exports; no browser starts in `run_exports.sh`. Renderer helpers are copied and vendor-JS/Playwright symlinks read the existing shared workspace.

Next: parent release; exports; one reviewed comparison per target with honest `differs` lists; then official family content build, derivatives/manifests and derived data, app/card checks, required gates and one coherent PR group into dev. Original image-match tickets stay open until every picture actually matches.
