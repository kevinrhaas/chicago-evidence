"""Light, read-only parameter and emitted-opening checks; no Blender/browser."""
import ast,copy,dataclasses,importlib.util,json,math,sys
from pathlib import Path
import jsonschema
ROOT=Path('/workspace/chicago/chicago/4d')
PROP=Path(__file__).parent/'proposed'
sys.path.insert(0,str(ROOT/'generators'))
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
old=load('old_frame_tavern_params_t2376',ROOT/'generators/archetypes/frame_tavern_params.py')
new=load('new_frame_tavern_params_t2376',PROP/'generators/archetypes/frame_tavern_params.py')
def opening_function(path):
 tree=ast.parse(path.read_text());fun=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_fenestration_gable_front')
 events=[]
 def win(*args,**kwargs):events.append(('window',args[2:],kwargs))
 def door(*args,**kwargs):events.append(('door',args[2:],kwargs))
 ns={'MeshBuilder':object,'FrameTavernParams':object,'ROOF_OVERHANG':.25,'_win':win,'_door':door}
 exec(compile(ast.Module(body=[fun],type_ignores=[]),str(path),'exec'),ns)
 def run(p):
  events.clear();ridge=p.wall_height_m+p.width_m/2*math.tan(math.radians(p.roof_pitch_deg))
  ns['_fenestration_gable_front'](object(),p,p.width_m,p.depth_m,p.wall_height_m,ridge,.5)
  return list(events)
 return run
emit_old=opening_function(ROOT/'generators/archetypes/frame_tavern.py')
emit_new=opening_function(PROP/'generators/archetypes/frame_tavern.py')
records=[];gable=0
for path in sorted((ROOT/'data/structures').glob('*.json')):
 r=json.loads(path.read_text())
 if r.get('archetype')!='frame_tavern':continue
 records.append(r['id'])
 for ph in r['phases']:
  a=old.from_phase(ph,r);b=new.from_phase(ph,r)
  aa=dataclasses.asdict(a);bb=dataclasses.asdict(b)
  assert bb.pop('eaves_bays')=={}
  assert aa=={k:v for k,v in bb.items() if k in aa},r['id']
  if a.elevation_scheme=='gable_front':
   assert emit_old(a)==emit_new(b),r['id'];gable+=1
print(f'PASS: defaults preserved across {len(records)} existing frame_tavern records; {gable} gable-front emitted opening sets identical.')
r=json.loads((PROP/'data/structures/green_tree_tavern.json').read_text());ph=r['phases'][0]
jsonschema.validate(r,json.loads((ROOT/'data/structures.schema.json').read_text()))
p=new.from_phase(ph,r);events=emit_new(p)
def count(events,x,upper):return sum(k=='window' and a[0]=='x' and a[1]==x and (a[5]>=p.wall_height_m/2)==upper for k,a,_ in events)
assert count(events,0.,True)==7
assert count(events,p.width_m,True)==6
assert count(events,0.,False)==6 # plus the existing side door
assert sum(k=='door' and a[0]=='x' and a[1]==0. for k,a,_ in events)==1
assert all(a[-1]==.5 for k,a,_ in events if a[0]=='x')
print('PASS: proposed south upper elevation emits seven sash; south ground six sash plus its existing door; opposite upper retains six.')
legacy_record=json.loads((ROOT/'data/structures/green_tree_tavern.json').read_text())
legacy=emit_old(old.from_phase(legacy_record['phases'][0],legacy_record))
assert [(k,a,kw) for k,a,kw in events if not(a[0]=='x' and a[1]==0.)]==[(k,a,kw) for k,a,kw in legacy if not(a[0]=='x' and a[1]==0.)]
print('PASS: every non-south opening call remains identical to baseline, including both gables and the north wall.')
invalid=[None,[],7,{'y_min':7},{'x_min':True},{'x_min':7.5},{'x_min':'7'},{'x_min':2},{'x_min':13},{'x_min':12}]
for value in invalid:
 q=copy.deepcopy(ph);q['form']['eaves_bays']['value']=value
 try:new.from_phase(q,r)
 except new.ParamError:pass
 else:raise AssertionError(('invalid override accepted',value))
q=copy.deepcopy(ph);q['form']['elevation_scheme']['value']='frontage';q['form'].pop('side_entrance',None)
try:new.from_phase(q,r)
except new.ParamError:pass
else:raise AssertionError('frontage scheme accepted eaves_bays')
q=copy.deepcopy(ph);q['form']['eaves_bays']['confidence']='reconstructed';p2=new.from_phase(q,r)
ev2=emit_new(p2)
assert all(a[-1]==1. for k,a,_ in ev2 if a[0]=='x' and a[1]==0.)
assert all(a[-1]==.5 for k,a,_ in ev2 if a[0]=='x' and a[1]==p.width_m)
print('PASS: eleven invalid override cases refused; reconstructed override confidence propagates to its own face only.')
manifest=json.loads((ROOT/'assets/manifest.json').read_text())['assets']
hits={k:v for k,v in manifest.items() if isinstance(v,dict) and v.get('archetype')=='frame_tavern'}
print(f'BLAST RADIUS: {len(hits)} frame_tavern master manifest entries will need refreshed input hashes/rebake because builder bytes change.')
print('NO CLAIM: real mesh bytes, bake, derivative freshness, camera, render, app/card checks, full gate or matches verdict have not been established.')
