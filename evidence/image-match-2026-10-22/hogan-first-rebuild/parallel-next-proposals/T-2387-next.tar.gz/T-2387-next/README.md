# First-fort model correction proposal — T-2387 / T-3041

The supplied patch removes the unsupported separate chimney from each of the two
first-fort blockhouses. This is a visible model correction, not a completed match.
The current compound baseline clearly shows the north-west blockhouse's invented
brick stack projecting through the pyramidal cap; neither blockhouse has that
separate stack in the public-domain Kurz & Allison panel 1.

## Evidence actually inspected

- `data/sources/assets/prefire_views_kevin_2026_08/p4_0.png`, 1538 x 859 pixels,
  source `kurz_allison_1893` (1893, public_domain, tier 5). Both blockhouses have
  small roof lanterns and no separate chimney. Barracks chimneys ARE plainly drawn,
  so this is not a blanket claim that the illustrator omits all stacks.
- Existing all-30-member comparison:
  `docs/RESEARCH/fort-reference-groups-T-3040/comparisons/first-fort-panel-1-side-by-side.jpg`.
  The NW blockhouse's invented stack is visibly separate from the roof cap.
- The Currey 1912 bird's-eye, Lossing 1869 engraving, and four Getty reference
  previews were inspected during the previous review. They agree about the
  lantern silhouette, but this patch derives its change only from the
  rights-cleared Kurz & Allison source, not from licensed agency reproduction.

The previous `chimneys: 1` was explicitly reconstructed from winter-heating
plausibility. The proposed zero is inferred from the pictured silhouette; it does
not claim the drawing proves a historical absence. The removed physical stack
cannot be defended merely because a garrison needed heat: no source specifies a
stack on either blockhouse and a flue does not have to make this invented shape.

## Scope and defaults

Only two authored records change:

- `data/structures/first_fort_dearborn_blockhouse_nw.json`
- `data/structures/first_fort_dearborn_blockhouse_se.json`

Both already have a consumed integer `chimneys` field. There is no schema,
parameter-module, builder, default, footprint, placement, wall, roof or staff
change. Only those two GLB input hashes change, so both masters and derivatives
need rebuilding; the other 23 fort_structure masters remain fresh. A shared
fort_structure.py generator edit would instead stale all 25 current masters,
including the lighthouse and Lake House shell. No such edit is included here.

The replacement JSON files are supplied for inspection. Apply the patch rather
than copying a whole JSON over newly changed work. Source, per-attribute confidence
and explanatory note are included in the change.

## Reconstructed choices retained

This patch introduces no new numeric choice. Existing inferred/reconstructed wall
heights, roof pitches and jetties are retained. The new note preserves the missing
lantern and tower-location discrepancies. Do not rewrite the measured plan or the
75 ft flagstaff to make the retrospective composition converge.

Append a liberty supersession after application: L370's historical one-stack
choice for these two blockhouses is retired by this picture-based refinement;
its roof, wall-height and jetty choices remain. Keep L370 itself unchanged.

## Lightweight checks executed

`fort_structure_params.from_phase` accepted both proposed records and resolved
`chimneys == 0`. `mesh_inputs.structure_inputs_sha` changed for each proposed
record, as expected; original and proposed hashes are in lightweight-checks.json.
No browser, Blender or broad check was run. No repository files were written.

## Parent integration and visual validation

1. Apply remove-unsupported-blockhouse-chimneys.patch after taking ownership of
   T-3041 (or an honest visible child if splitting; do not close the full match).
2. Append the liberty supersession, then regenerate the relevant derived records
   with the repository-supported commands; keep provenance and picture links.
3. Bake only the two IDs in one Blender invocation:
   `tools/bake.sh --scene 1812 --only first_fort_dearborn_blockhouse_nw,first_fort_dearborn_blockhouse_se`
   Confirm the actual bake CLI flags first; no command above was executed here.
4. Rerender the existing whole-fort camera into a NEW comparison path so the
   original before remains available. Inspect the two stacks' removal; keep
   verdict `differs` with lanterns, source/camera arrangement and staff residual open.
5. Capture in-app exterior and Images-tab evidence at desktop and 390x780, with
   zero page errors; run full preflight only after integrating all shared edits.
6. Check regenerated license/asset registries and manifest freshness. This data
   proposal alone must not be merged while its two committed meshes are stale.

## Larger next refinement

The missing cupolas are a larger visible difference and are coordinated with the
second-fort agent, which is investigating opt-in shared support. For the first
fort, Whistler's 1808 'not yet built' statement dates absence then; it is not an
assertion of continued absence in 1812. Later completion may be inferred from the
retrospective image with explicit uncertainty. An enabled cupola needs dimensions
marked reconstructed, a dated phase/provenance decision that does not imply it
stood in 1803 or 1808, and a properly regenerated asset. It is not an owner-approval
blocker. This chimney patch can be combined with that refinement when ready.
