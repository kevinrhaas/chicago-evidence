# T-2385 — second isolated Tremont form proposal

State: **unapplied, unbaked, not image-matched**. The first proposal and its actual preview at `/tmp/chicago-next-model/T-2385/preview-root` remain immutable. This directory advances that model toward the same Gifford picture using copied modules/data. No tracked repository file, ticket state, branch, publisher or manifest was changed. No second-proposal Blender/browser has run; wait for the parent's local-gate release and browser slot.

## Ready artifacts

- `T-2385-full.patch`: complete standard unified diff against current chicago checkout, including the first form step plus this detail step and both append-only liberty entries. Apply from `/workspace/chicago` only after inspecting current rival changes. `git apply --check` passed from that repository root.
- `T-2385-v2-over-v1-code.patch`: only the code/data delta over the immutable first copied proposal; append `liberty-entry-v2.md` separately when using this delta.
- `proposed/`: copied final code/data; `baseline/`: immutable original module/record snapshots for default-treatment proofs.
- `test_proposal.py`, `focused-checks.log`: light copied-module parameter/schema/accumulated-geometry checks; no Blender or publisher.
- `export_preview.py`, guarded `run_preview.sh`, `preview-root/`: ready for a second pinned-Blender isolated export/render when the parent releases resources. Uses Blender 4.5.3 and the actual project UV/export functions, no manifest writer.
- `staleness-scope.json`, `checkpoint.json`: exact 23-asset family refresh list and input/patch provenance.

## Added visible work

The envelope remains **15.24 × 9.14 m, total wall height 7.8 m**, with original position, bearing and documented range unchanged. New opt-in parameters follow the existing per-form `value/confidence/sources/note` convention and are read by `from_phase`/`CONSUMED`.

- `roof_pitch_deg=32`: working appearance fit near31.5° puts the current envelope's near apex near source pixel(953,277), versus the first preview's ridge near y260 at38°. This is reconstructed, not a historical measurement; camera/scale/paper perspective remain coupled.
- `first_story_height_m=3.1`: two upper divisions become2.35m each, retaining7.8m total. This gives headroom over the raised door; dimensions remain reconstructed.
- `entry_raise_m=0.6`: centred entries get2.2×1.2m plank platforms, four0.15m risers on0.28m treads and plain0.85m side guards. The mirrored concealed entrances remain reconstruction. Projected steps do not move the footprint polygon.
- `gable_lunette=true`: shallow arched dark gable feature, width0.40 of short gable, rise0.74m, base0.55m above eaves. The visible arch is read from the picture; **glazing/radial bars versus lettering/sign interpretation is unresolved**. Plain rim, dark pane and three bars are working reconstruction, not a verified fanlight or legible sign. Hidden gable repeats it. Corner gable end triangles now use the wall's finish/lap relief instead of roof material.
- `chimneys=4`, `chimney_placement=slope_offsets`: four distinct pictured capped silhouettes are represented by reconstructed roof-slope stations/heights, retaining the old ridge layouts for other buildings. Full numerical choices are in the form note and liberty entry.
- `flagstaff=true`, `flagstaff_height_m=4.25`: a70mm square spar at u0.37 of the long axis on the ridge. **Cloth remains open.** Existing app `flags.js` derives a standalone staff's anchor from whole-mesh bounds; applying its flag fields directly to the hotel would put cloth at the wrong roof point. This proposal adds no competing baked flag system or falsely enabled flag fields.

Source reinspection is preserved as `source-building-detail.png`. Source: N. Roswell Gifford; reproduced by Chicagology as “Tremont House No.1”, https://chicagology.com/prefire/prefire021/, `gifford_tremont_house_no_1`. Owner-approved attributed project reference use; no public-domain finding. Undated retrospective feature timing within1833–1839 remains explicit; adopting it for1835 is inferred/reconstructed as tagged.

## Validation and scope

Light checks pass:24 record-phase default parameter/geometry/material treatments unchanged (one is non-manifest Sauganash log phase); actual proposed phase resolves/schema-valid;44 windows/four reconstructed entries/88 solid shutter leaves; finite vertices/confidence; narrow/incompatible/type/nonfinite/clearance combinations rejected; new fields consumed; disabled staff-height choice emits identical geometry; arched-pane winding faces out without collapsed triangles.

Both this module's bytes and the new resolved dataclass fields stale **all23 current frame_tavern recipes**. Exact list is `staleness-scope.json`; no frame_tavern versions currently exist. No common geometry helper changes. This can combine with T-2376 GreenTree's eaves_bays override for one family refresh; see `/tmp/chicago-next-model/frame_tavern-combined/` for compatibility-tested copied modules and combined patch, while preserving separate source/liberty proposals.

Still required: pinned export and actual image review; cloth anchor/pattern layer; fine sash/shutter/rail/arch interpretation; camera acceptance/all relevant pictures; official family build, derivatives, manifests, grades/source/picture sidecars; desktop/mobile credited-card validation; required full check/preflight, changelog/STATUS/ROADMAP, PR into dev and merge green. Nothing here closes T-2385.
