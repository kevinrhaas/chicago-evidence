#!/usr/bin/env bash
set -euo pipefail
# PARENT RELEASE REQUIRED: no Blender/browser before the shared preflight finishes.
if [ "${T2385_PARENT_RELEASED:-0}" != "1" ]; then
  echo 'Wait for parent release; set T2385_PARENT_RELEASED=1 only after that signal.' >&2
  exit 2
fi
TASK_ROOT=/tmp/chicago-next-model/T-2385-next
PINNED_BLENDER=/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender
"$PINNED_BLENDER" -b -noaudio --factory-startup --python-exit-code 1 --python "$TASK_ROOT/export_preview.py" > "$TASK_ROOT/preview-root/blender-preview.log" 2>&1
cd "$TASK_ROOT/preview-root"
PW_EXECUTABLE=/usr/bin/chromium node tools/photo_match.mjs review/gifford-provisional.json --glb assets/gltf/tremont_house_1__frame_1833.proposal.glb --out review > photo-match-preview.log 2>&1
