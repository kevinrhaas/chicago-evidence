#!/usr/bin/env bash
# Exactly9 compound browser captures. No producer, compiler or Blender invocation.
set -euo pipefail
[[ "${CHICAGO_HEAVY_SLOT:-}" == T3041 ]] || { echo 'Refusing: parent must grant T3041 compound browser slot.' >&2; exit 2; }
capture_package="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONDONTWRITEBYTECODE=1
for capture_state in baseline galleries cupolas; do
  cd "$capture_package/review-roots/$capture_state"
  for capture_view in currey-seed currey-plan-seed kurz-C0; do
    python3 "$capture_package/verify_capture.py"
    PW_EXECUTABLE=/usr/bin/chromium node tools/photo_match.mjs "research-cameras/$capture_view.json" --out "$capture_package/reviews/$capture_state" > "$capture_package/$capture_state-$capture_view.log" 2>&1
  done
done
python3 "$capture_package/verify_capture.py" --completed
echo '9 actual captures completed. Must view images before judging geometry/cameras; all original matching remainsOPEN.'
