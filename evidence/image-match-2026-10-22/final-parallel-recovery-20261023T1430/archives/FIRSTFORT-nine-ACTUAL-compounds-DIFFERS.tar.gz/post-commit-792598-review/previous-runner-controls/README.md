# T-3041 captured-artifact compound continuation

PREPARED/UNRUN. Reuses the exact16 actual fresh exports from the closed build; no Blender, producer, compiler or new export is part of this continuation. The root owns current native tail/Hogan gate heavy capacity. Start only after a new explicit9-compound browser grant.

Exactly9 comparisons are queued: baseline/galleries/cupolas × Currey compromise/Currey plan-only/Kurz C0. All cameras are byte-exact to their built fixture versions; photos, frame sizes, focal/principal/eye/basis values and every30-member placement/phase/GLB hash are unchanged. The actual production group resolver from the captured tools proves all9 new review roots match the actual build group hashes exactly. No original picture, phase or30-member scope is dropped. The unchanged Kinzie household auxiliary is unrendered; its native31-sidecar compile evidence remains in the prior actual build packet.

Inputs are now minimal and frozen: the built GLBs, native1812 sidecars, scene, manifest, exact production photo_match.mjs/photo_match_group.mjs, keith-stone module, an owned frozen copy of the unchanged Three0.185.1 vendor, cameras and guarded source photos.225 actual runtime files are hashed. Playwright package identities and actual Chromium wrapper/binary hashes are guarded. Node dependencies remain the existing shared installation; no dependency installation or browser launch occurred during preparation. Rendering outputs and match records go only under this new owned directory. Canonical app files remain untouched.

## Explicit later-input hash review

The original5510-input build guard manifest is retained byte-exact. Exactly25 later root changes were reviewed: the1835lodger allocation writer, six ordinary-bed figures in the business lodging report, the capacity-basis/report fields of the1835lodgers ledger, and22lodger-household capacity/explanation files. Every prechange SHA was independently recovered from commit e41ae248f6eaad1ead26c93537a7d1c7b438d3c0. capacity-input-change-review.json records exact before/after SHA pairs, old-byte locators, full JSON leaf deltas and the reason each is never read by this captured JS renderer. The exact writer diff is retained. These exclusions are NOT a verdict that the root capacity patch is correct or that its pending full gate passed.

No path-prefix or arbitrary blanket exemption is used. The verifier still checks the other5485 original inputs unchanged, checks each of the25 exclusions against its individually reviewed current hash, verifies all closed actual-build evidence hashes, and independently checks all frozen runtime inputs. Another root change refuses this continuation until explicitly reviewed. The copied reference-render tools read no lodging writer/report/household source; they read the already built1812 sidecars and meshes. No sidecar/mesh is recompiled under the new capacity code.

## After parent grants the exclusive compound slot

```sh
CHICAGO_HEAVY_SLOT=T3041 bash /tmp/chicago-next-model/T-3041-captured-review-20261023/capture.sh
```

The script runs9 real production photo_match calls sequentially, checking guards before each, then verifies every actual match receipt has the expected camera/photo/group hashes and all30 members. Actual no-slot refusal exit2 was tested without starting a browser. No front diagnostics are scheduled here; request them only if the actual compound review identifies a material question that they can resolve.

No comparison has been captured or reviewed yet. The source cameras remain openly imperfect: Currey compromise RMS29.6px/max67.6px; plan fit RMS6.36px but independent staff endpoints disagree about73/103px. C0 Kurz is an initial curtain diagnostic. Retain surveyed positions, physical plan and75ft staff; do not move/shrink them to hide drawing conflicts. GLB-only photo_match omits app runtime flag cloth, and common flat review grade is not the actual riverbank terrain. Every remaining source, hidden part, curved magazine, gate/annex/crosswing/garden/coveredway and north-bank context still needs its appropriate actual study. Cupolas are a fixture-only1812appearance experiment preserving1808absence; no historical completion day/adoption is proposed. No Getty geometry is derived. All T-2387/T-3041 original image matching remains OPEN.

Recovery: retain this directory excluding disposable review-roots/ and shared/ when size matters; runtime-input-guards.json, frozen-runtime-source/ (exact renderer/scene/source-photo bytes), the root-pinned vendor and the fixed actual-build packet identify every copied artifact. The preparation script no longer requires the disposable original build thin roots. Reprepare only after explicit review if inputs changed. Keep prepared-capture-status.json as historical UNRUN even after later actual captures; write superseding actual receipts and image-review notes rather than editing its history.
