#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json
H=Path(__file__).resolve().parent
E=Path('/tmp/chicago-next-model/T-3041-build-resume-20261023/closed-build-evidence')
ap=argparse.ArgumentParser();ap.add_argument('--completed',action='store_true');args=ap.parse_args()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=json.loads((E/'input-guards.json').read_text())
review=json.loads((H/'capacity-input-change-review.json').read_text())
exceptions={x['path']:x for x in review['excluded_only_with_fixed_before_after_hashes']}
assert len(exceptions)==25 and len(original)==5510
for name,before in original.items():
    if name in exceptions:
        x=exceptions[name];assert x['before_sha256']==before and not x['runtime_read']
        assert sha(Path(name))==x['reviewed_current_sha256'],name+': capacity input changed again; review explicitly'
    else:
        assert sha(Path(name))==before,name+': original relevant guard changed'
for name,digest in json.loads((H/'runtime-input-guards.json').read_text()).items():
    assert sha(Path(name))==digest,name+': frozen capture input changed'
for rel,digest in json.loads((E.parent/'closed-build-evidence-sha256.json').read_text()).items():
    assert sha(E/rel)==digest,rel+': actual build evidence changed'
for rel,digest in json.loads((H/'frozen-runtime-source/SHA256.json').read_text()).items():
    assert sha(H/'frozen-runtime-source'/rel)==digest,rel+': captured runtime source changed'
for name,digest in json.loads((H/'runner-file-guards.json').read_text()).items():
    assert sha(H/name)==digest,name+': captured runner changed'
if args.completed:
    old=json.loads((E/'actual-built30-group-proof.json').read_text())
    expected={x['state']:x for x in old['states']}
    rows=[]
    for state in ['baseline','galleries','cupolas']:
        for view in ['currey-seed','currey-plan-seed','kurz-C0']:
            root=H/'review-roots'/state
            camera=root/'research-cameras'/(view+'.json')
            match=root/'research-cameras'/(view+'.match.json')
            screenshot=H/'reviews'/state/(view+'-side-by-side.jpg')
            m=json.loads(match.read_text());c=json.loads(camera.read_text())
            assert m['camera_sha256']==sha(camera)and m['photo_sha256']==sha(Path(c['photo']))
            assert m['group_sha256']==expected[state]['group_sha256']
            assert len(m['rendered_members'])==30 and m['verdict']=='unreviewed'
            assert {x['structure_id']for x in m['rendered_members']}=={x['structure_id']for x in expected[state]['rendered_members']}
            assert all(x['placement']['target_date']=='1812-08-14'and x['placement']['phase']=='first_fort_1803'for x in m['rendered_members'])
            assert screenshot.is_file()
            rows.append({'state':state,'view':view,'match':str(match),'match_sha256':sha(match),
                         'image':str(screenshot),'image_sha256':sha(screenshot),
                         'camera_sha256':sha(camera),'photo_sha256':m['photo_sha256'],
                         'group_sha256':m['group_sha256'],'members':30,'verdict':'unreviewed'})
    (H/'actual-capture-receipt.json').write_text(json.dumps({'status':'9 ACTUAL COMPOUND CAPTURES/UNREVIEWED',
        'fresh_exports':0,'original16built_masters_reused':True,'camera_numerics_unchanged':True,
        'captures':rows,'browser_review':'NOT YET VIEWED','original_matching':'OPEN','canonical_writes':False},indent=2)+'\n')
print(json.dumps({'guarded_original_inputs':5510,'explicit_capacity_only_hash_review':25,
                  'actual_frozen_runtime_inputs':len(json.loads((H/'runtime-input-guards.json').read_text())),
                  'captures_checked':9 if args.completed else 0,'new_exports':0,'canonical_writes':False}))
