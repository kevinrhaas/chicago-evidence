#!/usr/bin/env python3
"""LIGHT: freeze actual built assets and their actual reference-render inputs."""
from pathlib import Path
import difflib,hashlib,json,shutil,subprocess
H=Path(__file__).resolve().parent
E=Path('/tmp/chicago-next-model/T-3041-build-resume-20261023/closed-build-evidence')
ROOT=Path('/workspace/chicago')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (H/'review-roots').exists(),'already prepared; do not silently replace frozen inputs'
original=json.loads((E/'input-guards.json').read_text())
head=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()
changed=[]

def diff_json(a,b,path=''):
    if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
    if isinstance(a,dict):
        out=[]
        for k in sorted(a.keys()|b.keys()):out+=diff_json(a.get(k,'<MISSING>'),b.get(k,'<MISSING>'),path+'.'+k)
        return out
    if isinstance(a,list):
        assert len(a)==len(b),'unexpected list membership change: '+path
        out=[]
        for i,(x,y)in enumerate(zip(a,b)):out+=diff_json(x,y,path+f'[{i}]')
        return out
    return []if a==b else[{'path':path,'before':a,'after':b}]

for filename,before in original.items():
    p=Path(filename);now=sha(p)
    if now==before:continue
    rel=str(p.relative_to(ROOT));old=subprocess.check_output(['git','-C',str(ROOT),'show',head+':'+rel])
    assert hashlib.sha256(old).hexdigest()==before,'no verified old bytes: '+rel
    row={'path':filename,'before_sha256':before,'reviewed_current_sha256':now,'old_bytes':head+':'+rel,
         'runtime_read':False,'reason':'Actual captured reference renderer imports onlyJS photo_match/group and reads fixed1812 sidecars/GLBs/cameras/photo/vendor; this1835allocation writer/report/household is never read.'}
    if p.name=='seat_lodgers_1835.py':
        assert rel=='chicago/4d/tools/seat_lodgers_1835.py'
        patch=''.join(difflib.unified_diff(old.decode().splitlines(True),p.read_text().splitlines(True),fromfile='captured-old',tofile='current-reviewed'))
        (H/'reviewed-seat-lodgers-capacity.patch').write_text(patch)
        row['review']='Exact Python diff read: new allocation-basis helpers and fill routing plus copy import. No reference-render module imports it.'
    else:
        assert rel in ['chicago/4d/data/reconstruction/1835_business_reconstruction.json',
                       'chicago/4d/data/reconstruction/1835_lodgers_seated.json'] or rel.startswith('chicago/4d/data/residents/lodgers/hh_lodging_')
        deltas=diff_json(json.loads(old),json.loads(p.read_text()))
        if p.name=='1835_business_reconstruction.json':
            assert len(deltas)==6 and all(d['path'].startswith('.lodging.rows[')and d['path'].endswith('.beds_ordinary')for d in deltas)
        elif p.name!='1835_lodgers_seated.json':
            assert all(d['path'].endswith(('.note','.basis.note','.stands_on','.withdrawn_if','.beds_ordinary'))for d in deltas)
        row['reviewed_exact_leaf_changes']=deltas
    changed.append(row)
assert len(changed)==25,'review new differences explicitly before updating exclusions'
review={'status':'EXPLICIT25PATH HASH REVIEW, NOT a root capacity correctness verdict',
        'original_guard_count':5510,'verified_old_commit':head,'excluded_only_with_fixed_before_after_hashes':changed,
        'no_blender_or_browser_run':True,'all_meshes_sidecars_cameras_and_runtime_consumers_still_fixed':True}
(H/'capacity-input-change-review.json').write_text(json.dumps(review,indent=2)+'\n')

# Closed master/source evidence must remain exact before any copy.
frozen=json.loads((E.parent/'closed-build-evidence-sha256.json').read_text())
for rel,digest in frozen.items():assert sha(E/rel)==digest,rel
scope=json.loads((E/'scope.json').read_text());asset_names=scope['assets']
shared=H/'shared';shared.mkdir()
vendor=ROOT/'chicago/4d/renderers/web/vendor/three-0.185.1'
shutil.copytree(vendor,shared/'three-0.185.1')
runtime_guards={};camera_contracts=[]
for state in ['baseline','galleries','cupolas']:
    dst=H/'review-roots'/state
    for folder in ['assets/gltf','data/sidecars/1812','data/scenes','tools','renderers/web/js','renderers/web/vendor','research-cameras']:
        (dst/folder).mkdir(parents=True,exist_ok=True)
    for sid in scope['members']:
        name=asset_names[sid]
        fresh=E/state/'assets/gltf'/name
        if not fresh.is_file():
            # Cupola state inherits EXACT same-run range assets, not old canonical ones.
            inherited=E/'galleries/assets/gltf'/name if state=='cupolas' else E/'unchanged-context-masters'/name
            fresh=inherited if inherited.is_file()else E/'unchanged-context-masters'/name
        assert fresh.is_file(),(state,name)
        shutil.copy2(fresh,dst/'assets/gltf'/name)
        shutil.copy2(E/state/f'data/sidecars/1812/{sid}.json',dst/f'data/sidecars/1812/{sid}.json')
    shutil.copy2(E/state/'assets/manifest.json',dst/'assets/manifest.json')
    shutil.copy2(H/'frozen-runtime-source/data/scenes/1812.json',dst/'data/scenes/1812.json')
    for name in ['photo_match.mjs','photo_match_group.mjs']:
        source=H/'frozen-runtime-source/tools'/name
        assert sha(source)==original[str((ROOT/'chicago/4d/tools'/name).absolute())]
        shutil.copy2(source,dst/'tools'/name)
    source=H/'frozen-runtime-source/renderers/web/js/keith-stone.js'
    assert sha(source)==original[str(ROOT/'chicago/4d/renderers/web/js/keith-stone.js')]
    shutil.copy2(source,dst/'renderers/web/js/keith-stone.js')
    (dst/'renderers/web/vendor/three-0.185.1').symlink_to(shared/'three-0.185.1',target_is_directory=True)
    (dst/'node_modules').symlink_to(Path('/workspace/node_modules').resolve(),target_is_directory=True)
    for name in ['currey-seed','currey-plan-seed','kurz-C0']:
        source=E/state/'research-cameras'/(name+'.json');shutil.copy2(source,dst/'research-cameras'/source.name)
        cam=json.loads(source.read_text())
        # Photo path remains exact so camera bytes, hashes and framing are unchanged.
        photo=Path(cam['photo']);runtime_guards[str(photo)]=sha(photo)
        assert len(cam['also_render'])==29 and cam['structure_id']not in cam['also_render']
        camera_contracts.append({'state':state,'view':name,'camera_sha256':sha(source),
                                 'original_built_camera_exact':True,'source_photo_sha256':sha(photo)})
    for p in dst.rglob('*'):
        if p.is_file()and not p.is_symlink():runtime_guards[str(p)]=sha(p)
for p in (shared/'three-0.185.1').rglob('*'):
    if p.is_file():runtime_guards[str(p)]=sha(p)
for folder in ['playwright','playwright-core']:
    p=Path('/workspace/node_modules')/folder/'package.json';runtime_guards[str(p)]=sha(p)
for p in [Path('/usr/bin/chromium'),Path('/usr/lib/chromium/chromium')]:
    if p.is_file():runtime_guards[str(p)]=sha(p)
(H/'runtime-input-guards.json').write_text(json.dumps(runtime_guards,indent=2)+'\n')
(H/'camera-contracts.json').write_text(json.dumps(camera_contracts,indent=2)+'\n')
(H/'prepared-capture-status.json').write_text(json.dumps({'status':'PREPARED/UNRUN','fresh_exports':0,
    'reused_prior_actual_exports':16,'compound_comparisons_owed':9,'states':['baseline','galleries','cupolas'],
    'views':['currey-seed','currey-plan-seed','kurz-C0'],'members_per_group':30,'unrendered_aux_omitted':True,
    'camera_acceptance':False,'original_image_matching':'OPEN'},indent=2)+'\n')
print(json.dumps({'status':'LIGHT CAPTURE PREPARED/UNRUN','reviewed_changed_inputs':len(changed),
                  'frozen_runtime_inputs':len(runtime_guards),'same_camera_contracts':len(camera_contracts),
                  'new_exports':0,'browser_runs':0},indent=2))
