# T-2380 — actual complete-group preview, 2026-10-23

**Heavy slot CLEAR. Exact requested run PASS; full image match DIFFERS.** All subprocesses exited. There were0 baseline builds,3 actual official-name candidate exports and2 captures. No variants, root/canonical changes, asset promotion or ticket closure. The sealed snapshot's583 hashes remain unchanged.

Run: `runs/20261023-122911-699932/`.

Source, both actual side-by-sides and native match contracts were inspected directly. The two isolated match records now say `differs` with explicit differences. Their generated `unreviewed` records were preserved separately. `actual-run-contract.json` records original generated contract hashes; `actual-reviewed-match-hashes.json` records the reviewed hashes.

## What the actual pictures show

The baseline is the genuinely incomplete bare outbuilding. The candidate materializes the missing keeper house, high curtain and low gate as3 real scene members. Presence is useful progress, but the **whole composition is substantially wrong**.

The house projects far too large/close. Its roof and chimney sit substantially too high relative to the source house, and the house hides much of the jail. Both remain inside the full capture; the earlier wording claiming they extended beyond its top was incorrect (corrected after direct re-view and native-pixel projection). In the actual Gale plate the keeper house is distinctly lower in the frame and below the plainly visible core gable/roof. This is not evidence to raise the fixed jail to the held4.2m diagnostic: the camera was fitted only to four core-roof points, and the house size/depth/offset/roof remain explicitly chosen proxies. Whole-compound projection and those proxies need to be reconciled before selecting a metric correction.

The source core's barred gable opening and two stacks are not emitted, and the candidate house obstructs the core gable. The retained hewn/squared log ends differ from the drawn rounded ends. The22° roof is emitted as requested, but this group does not establish a matching core silhouette.

The palisade reads as a nearly smooth dark face with dense small heads; the source depicts a much more legible rhythm and contrast of upright timbers. The gate/house join reads as a compressed brace-filled seam. A finite, non-crossing curtain geometry test did not establish this visible shape/material match.

The house has one near-gable ground light and no attic light, against the source's two ground lights and attic light. The generic main sash/shutter/door/stack/trim/material choices also differ. The low outer street rail, full plankwalk, flagstaff and source ground/figures/animals/background context remain absent. No invented upper floor or person identity was added to conceal those omissions.

**This first complete-group proposal should not be promoted as a picture match or as ready for the18-master production refresh.** It supplies actual evidence of the principal next mismatch: whole-compound camera/house projection and relative massing, while retaining the source/date bounds. No additional variant was created or rendered under this grant.

## Actual contracts

| Candidate asset | Bytes | Triangles | Materials | GLB SHA256 |
|---|---:|---:|---:|---|
|`log_jail__log_1833.glb` |63,908 |936 |6 |`0b5db2d68c21c81e69403e29f162fd6972890861dc775161d9e157f126dcd263` |
|`log_jail_keeper_house__context_1835.glb` |43,240 |574 |8 |`bb8e89b109458335b5678879474778b5f4363c02fac82c62b1b354375af5a9b7` |
|`log_jail_palisade__context_1835.glb` |172,264 |2,126 |2 |`1e5efc53ecd4fe55b52f8ddd9f7c3567bae2c00a270b796fbe602941bef36680` |

All3 actual manifest recipe hashes equal the frozen native expected recipes. The actual after match contains all3 members and their GLB hashes/placements; group SHA256 is `f98dc0683ed255a17c5906119e63a2e210c6e215a75852a605c15c0c3ac725a6`. Exact optics equality was asserted for image dimensions, principal point, focal length, eye, yaw, sun and sky. Photo bytes are identical. The baseline retained the actual committed master; it was not re-exported or manufactured.

Blender4.5.3 emitted a nonfatal extension-cache warning about read-only `/home/agent/.config/blender/4.5`; it exited0, all3 exports/manifests and native group/recipe assertions passed. The two real capture processes also exited0. No remaining heavy job is held.

## Scope retained

The sole actual camera source is the independently public-domain1902 Gale/Trowbridge plate, captioned1836. Its full2741×1853 lossless upright page and unchanged provisional optics were used. UCR's1930 copy/catalogue facts remain separate and check-required/text-only. Gale's retrospective1835p51 text supplies the compound relationship, not exact dimensions or every1July1835 detail. Andreas's separate later cell/fall1835courthouse/contrasting cap remains unresolved. No final grade, camera solve or original acceptance is changed.

The low wicket is a reconstructed closed instant. Whole-envelope walker collision still blocks core/gate access and pushes inside spawns outward. These neutral common-grade captures are not app terrain/walker or desktop/mobile QA. T-2380 remains actively claimed under `jail-picture-match-agent`, with its original image acceptance intact.
