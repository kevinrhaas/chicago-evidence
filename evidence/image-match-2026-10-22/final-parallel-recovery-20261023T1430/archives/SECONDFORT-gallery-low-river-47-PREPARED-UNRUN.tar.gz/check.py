from pathlib import Path
import json,ast,math,sys,importlib.util,dataclasses
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('second_fort_gallery_params',P/'dependency/generators/archetypes/fort_structure_params.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
id='fort_dearborn_officers_quarters';old=json.loads((P/'baseline/data/structures'/f'{id}.json').read_text());new=json.loads((P/'candidate/data/structures'/f'{id}.json').read_text());a=m.from_phase(old['phases'][0],old);b=m.from_phase(new['phases'][0],new)
assert not a.gallery and a.gallery_storeys==1 and b.gallery and b.gallery_storeys==2
ad,bd=dataclasses.asdict(a),dataclasses.asdict(b);delta=[k for k in ad if ad[k]!=bd[k]];assert set(delta)=={'gallery','gallery_storeys','confidence'}
for k in ad['confidence']:
 if k not in ['gallery','gallery_storeys']:assert ad['confidence'][k]==bd['confidence'][k],k
assert a.worst_conf('kind','stories','construction')==b.worst_conf('kind','stories','construction')
assert old['phases'][0]['position']==new['phases'][0]['position'];assert old['phases'][0]['footprint']==new['phases'][0]['footprint'];assert old['phases'][0]['documented_range']==new['phases'][0]['documented_range']
class Recorder:
 def __init__(self):self.boxes=[];self.polys=[]
 def add_box(self,*args,**kw):
  assert all(math.isfinite(v) for v in args[:7]);assert all(args[i+3]>args[i] for i in range(3));assert args[6]==1.;self.boxes.append(args)
 def add_poly(self,*args,**kw):assert args[1]==1.;self.polys.append(args)
tree=ast.parse((P/'dependency/generators/archetypes/fort_structure.py').read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['_gallery','_gallery_two_storeys']];env={'math':math,'MeshBuilder':object,'FortStructureParams':m.FortStructureParams,'M_TRIM':3,'M_ROOF':1};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<frozen actual gallery helper>','exec'),env)
r=Recorder();env['_gallery'](r,b,b.conf('gallery','reconstructed'));assert len(r.boxes)==136 and len(r.polys)==1
assert any(q[:6]==(0.,b.depth_m,b.storey_height_m-.14,b.width_m,b.depth_m+2.1,b.storey_height_m) for q in r.boxes)
t=math.radians(new['phases'][0]['position']['rotation_deg']);front=[math.sin(t),math.cos(t)];assert front[0]>.98
report={'status':'PASS_LIGHT_READER_AND_REAL_HELPER_ONLY','parameter_delta':delta,'all_legacy_geometry_parameters_and_confidence_exact':True,'position_rotation_footprint_dates_unchanged':True,'gallery_boxes':136,'gallery_roof_faces':1,'new_geometry_confidence':1.,'local_plus_y_facade_EN_unit':front,'upper_deck_z_m':b.storey_height_m,'outer_gallery_y_m':b.depth_m+2.1,'blender_or_browser_or_GLTF_PARITY':'UNRUN','remaining':'stairs, exact post/bay geometry, roofline, source-range identification in Kurz, camera residuals and every original match'}
(P/'light-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
