from pathlib import Path
import json,hashlib,shutil,difflib,datetime,math,ast,importlib.util,sys
import numpy as np
from scipy.optimize import least_squares
sys.dont_write_bytecode=True
root=Path('/workspace/chicago/chicago/4d');old=Path('/tmp/chicago-next-model/T-2388-every-building-audit');out=Path('/tmp/chicago-next-model/T-2388-gallery-low-river-next-20261023');assert not out.exists();out.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest();captured={}
def copy(src,dst):
 b=Path(src).read_bytes();captured[str(src)]=b;dst=out/dst;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);return b
records=json.loads((old/'records-inventory.json').read_text());ids=[r['id'] for r in records]
rows=[]
for id in ids:
 src=root/'data/structures'/(id+'.json');b=copy(src,'baseline/data/structures/'+id+'.json');d=json.loads(b)
 rows.append({'id':id,'sha256':sha(b),'unchanged_since_prior21audit':sha(b)==next(x['sha256'] for x in json.loads((old/'CAPTURED-INPUTS.json').read_text())['canonical_files'] if x['path']==str(src))})
b=copy(root/'data/sources/wentworth_1881_fort_dearborn.json','source-proof/wentworth_1881_fort_dearborn.json')
for file in ['wentworth-leaf17.png','wentworth-leaf120.png','wentworth-leaf121.png','wentworth-leaf63.png','andreas-map-n242.jpg']:
 copy(old/'web'/file,'source-proof/'+file)
copy(root/'data/sources/assets/prefire_views_kevin_2026_08/p3_1.png','source-proof/kurz-panel-5.png')
copy(old/'EVERY-BUILDING.md','prior-audit/EVERY-BUILDING.md');copy(old/'every-building-coverage.json','prior-audit/every-building-coverage.json');copy(old/'ticket-image-inspection.json','prior-audit/ticket-image-inspection.json')
fort=Path('/tmp/chicago-next-model/fort-adoption-current-20261023-113917/staged/candidate/chicago/4d')
for name in ['fort_structure.py','fort_structure_params.py']:
 src=fort/'generators/archetypes'/name
 if not src.exists():src=Path('/tmp/chicago-next-model/fort-selective-integration/staged/candidate/chicago/4d/generators/archetypes')/name
 copy(src,'dependency/generators/archetypes/'+name)
id='fort_dearborn_officers_quarters';before=(out/'baseline/data/structures'/f'{id}.json').read_text();d=json.loads(before);f=d['phases'][0]['form']
f['gallery']={'value':True,'confidence':'inferred','sources':['wentworth_1881_fort_dearborn'],'note':'LATER OBSERVATION CARRIED BACK EXPLICITLY. Actual printed Wentworth1881 p92 identifies officers range B; its p93 key dates the Hesler view1855 and states wood about30x60ft. The two-level covered parade gallery is visible on B, corroborated by the1856 exterior photograph. No reached record dates the gallery construction: presence on1July1835 is a continuity inference over the dated1830-plan/1827 range, not attested by Whistler1808 (first fort). The existing shared fort helper supplies reconstructed2.1m reach, timber sections/rail spacing and roof fall. No source-derived coordinate or measured metric gallery width is claimed.'}
f['gallery_storeys']={'value':2,'confidence':'inferred','sources':['wentworth_1881_fort_dearborn'],'note':'Two covered levels are visible in the1855B plate; carrying them into1835 is inferred continuity, not a dated1835 receipt. Exact deck elevation2.4m, reach2.1m, post0.14m, deck0.14m, rail0.95m and baluster0.055m/pitch0.18m are reconstructed shared-helper choices. No external staircase is added in this bounded trial, although later views show one; it remains an explicit discrepancy.'}
# Remove the old categorical no-evidence claims without promoting numeric guesses.
f['stories']['confidence']=json.loads(before)['phases'][0]['form']['stories']['confidence'];f['stories']['sources']=['wentworth_1881_fort_dearborn'];f['stories']['note']='The existing1835 model choice of2storeys remains reconstructed. Two storeys are visibly present on officers range B in the1855 plate printed1881p92; continuation to1835 is possible but not a dated construction receipt, and exact storey/deck heights remain reconstructed. The earlier categorical claim that no picture shows two storeys is superseded by this actual later observation.'
after=json.dumps(d,indent=2,ensure_ascii=False)+'\n';p=out/'candidate/data/structures'/f'{id}.json';p.parent.mkdir(parents=True);p.write_text(after)
rel='chicago/4d/data/structures/'+id+'.json';(out/'officers-gallery-data-only.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
# A camera experiment, not an accepted solution. Source anchors deliberately
# exclude copied landmark claims for hidden/unidentified buildings.
p=np.array([[7.26,4.9,5.38],[.6405691165189598,54.83702781877735,0],[53.64056911651896,54.83702781877735,0]])
x=np.array([1037.,856.,0.]);focal=2000.;north=125.;height=6.
def project(q):
 ex,yaw,cx=q;t=math.radians(yaw);r=np.array([math.cos(t),-math.sin(t),0]);fw=np.array([math.sin(t),math.cos(t),0]);q3=p-np.array([ex,north,height]);z=q3@fw;return cx+focal*(q3@r)/z,z
sol=least_squares(lambda q:project(q)[0]-x,[-35,160,500],bounds=([-250,90,-1000],[250,270,2000]));xs,z=project(sol.x);cy=384-focal*height/z[1]
cam=json.loads((old/'group-camera.json').read_text());cam.pop('basis_right_up_forward',None);cam['photo']='../source-proof/kurz-panel-5.png';cam['principal_px']=[float(sol.x[2]),float(cy)];cam['eye']=[float(sol.x[0]),north,height];cam['yaw_deg']=float(sol.x[1]);cam['focal_px']=focal
res={'kind':'UNRENDERED_CAMERA_FRAMING_EXPERIMENT_NOT_ACCEPTED_SOLVE','fixed_reconstructed_choices':{'eye_north_m':north,'eye_height_m':height,'focal_px':focal,'roll_deg':0,'pitch_deg':0},'horizontal_correspondences':[{'model_ENU_m':point.tolist(),'source_x_px':float(target),'projected_x_px':float(got),'residual_x_px':float(got-target)} for point,target,got in zip(p,x,xs)],'horizontal_RMS_px':float(np.sqrt(np.mean((xs-x)**2))),'northwest_top_holdout':{'source_xy_px':[856,347],'projected_xy_px':[float(xs[1]),float(cy-focal*(3.7-height)/z[1])]},'limits':['Retrospective drawn north-curtain/end identity and handpicked anchors remain conditional.','The fit leaves large residuals; source and current geometry cannot be declared aligned.','No coordinate, footprint, mesh or camera-height measurement is inferred from this experiment.','All21 members remain requested, including external members outside the picture.','Use byte-identical camera for before/after; inspect actual renders before any further calibration.']}
cam['solve']='UNRENDERED LOW-RIVER FRAMING EXPERIMENT, not an accepted camera. Reconstructed six-metre eye and125m north standoff, focal2000px, horizontal roll/pitch fixed; fits only three conditional horizontal landmarks (blockhouse eave centre and both north-curtain ends). Horizontal RMS %.3fpx and NW stockade top holdout projects to[%.3f,%.3f] against[856,347], so residuals are materially open. Approximate current plan coordinates retained. Same camera bytes must govern before/after. Common grade, not actual app terrain. Hidden/unidentified members are context, not an attested per-building match.'%(res['horizontal_RMS_px'],res['northwest_top_holdout']['projected_xy_px'][0],res['northwest_top_holdout']['projected_xy_px'][1])
(out/'cameras').mkdir();(out/'cameras/kurz-low-river-experiment.json').write_text(json.dumps(cam,indent=2)+'\n');(out/'camera-calibration.json').write_text(json.dumps(res,indent=2)+'\n')
# Actual pure parameter reader and actual gallery helper, no Blender stubs that
# pretend to export a GLB. Recorder records finite nondegenerate emitted members.
spec=importlib.util.spec_from_file_location('second_fort_next_params',out/'dependency/generators/archetypes/fort_structure_params.py');params=importlib.util.module_from_spec(spec);sys.modules[spec.name]=params;spec.loader.exec_module(params)
a=params.from_phase(json.loads(before)['phases'][0],json.loads(before));b=params.from_phase(d['phases'][0],d)
assert a.gallery is False and a.gallery_storeys==1 and b.gallery is True and b.gallery_storeys==2
import dataclasses
av,bv=dataclasses.asdict(a),dataclasses.asdict(b);changed=[k for k in av if av[k]!=bv[k]];assert set(changed)<= {'gallery','gallery_storeys','confidence'}
code=ast.parse((out/'dependency/generators/archetypes/fort_structure.py').read_text());nodes=[n for n in code.body if isinstance(n,ast.FunctionDef) and n.name in ['_gallery','_gallery_two_storeys']];env={'math':math,'MeshBuilder':object,'FortStructureParams':params.FortStructureParams,'M_TRIM':3,'M_ROOF':1};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<actual frozen helper>','exec'),env)
class Recorder:
 def __init__(self):self.boxes=[];self.polys=[]
 def add_box(self,*args,**kw):
  assert all(math.isfinite(v) for v in args[:7]);assert all(args[i+3]>args[i] for i in range(3));assert args[6]==1.;self.boxes.append(args)
 def add_poly(self,*args,**kw):assert args[1]==1.;self.polys.append(args)
r=Recorder();env['_gallery'](r,b,b.conf('gallery','reconstructed'));assert r.boxes and len(r.polys)==1
# Existing native gallery is local+y; at rotation98deg that direction is east
# and slightly south in the scene, into the parade from the west range.
t=math.radians(d['phases'][0]['position']['rotation_deg']);front=[math.sin(t),math.cos(t)]
checks={'status':'PASS_LIGHT_READER_AND_REAL_HELPER_ONLY','gallery_parameter_delta':changed,'position_rotation_footprint_dates_unchanged':all(json.loads(before)['phases'][0][k]==d['phases'][0][k] for k in ['position','footprint','documented_range']),'gallery_boxes':len(r.boxes),'gallery_roof_faces':len(r.polys),'new_geometry_confidence':1.,'local_plus_y_facade_EN_unit':front,'frontpoints_into_parade_east':front[0]>.98,'upper_deck_z_m':b.storey_height_m,'outer_gallery_y_m':b.depth_m+2.1,'total_baked_geometry_PARITY_or_GLTF_contract':'NOT_RUN','browser_or_blender':'NOT_RUN','source_instance_identity':'Later1855B key only; exact Kurz range assignment unresolved'}
(out/'light-check.json').write_text(json.dumps(checks,indent=2)+'\n');(out/'record-input-guards.json').write_text(json.dumps(rows,indent=2)+'\n')
for src,b in captured.items():assert Path(src).read_bytes()==b,('Input moved',src)
(out/'INPUTS.json').write_text(json.dumps({'frozen_inputs':[{'path':src,'bytes':len(b),'sha256':sha(b)} for src,b in captured.items()],'double_read_stable':True,'claim':'9718773de306b8e695430004a7f7e139e25618b3'},indent=2)+'\n')
print(json.dumps({'out':str(out),'checks':checks,'camera_horizontal_RMS_px':res['horizontal_RMS_px'],'raw21_unchanged_since_prior_audit':sum(x['unchanged_since_prior21audit'] for x in rows)},indent=2))
