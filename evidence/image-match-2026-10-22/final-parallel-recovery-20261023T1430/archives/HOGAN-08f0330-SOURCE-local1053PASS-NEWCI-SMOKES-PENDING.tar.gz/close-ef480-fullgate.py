"""Close actual strict-gate receipts; reads source, writes recovery only."""
from pathlib import Path
import datetime,hashlib,json,re,subprocess
r=Path(__file__).resolve().parent;w=r.parent
assert (r/'ef480-full-preflight.exit').read_text().strip()=='0'
def git(*a):return subprocess.check_output(['git',*a],cwd=w)
freeze=json.loads((r/'ef480-candidate-input-freeze.json').read_text())
assert git('rev-parse','HEAD').decode().strip()==freeze['HEAD']
assert git('rev-parse','MERGE_HEAD').decode().strip()==freeze['incoming_dev']
assert not git('diff','--name-only')
assert git('write-tree').decode().strip()==freeze['staged_tree']
plain=lambda s:re.sub(r'\x1b\[[0-9;]*m','',s)
check=plain((r/'ef480-full-preflight-check.log').read_text());counts=re.findall(r'CHECK PASS[^\n]*?— (\d+) steps, none red\.',check);assert counts and int(counts[-1])==1053
pre=plain((r/'ef480-full-preflight.log').read_text());assert 'PREFLIGHT PASS'in pre
assert 'changelog entry: present'in (r/'ef480-full-preflight-cl.log').read_text()
logs={}
for name in ['ef480-full-preflight.log','ef480-full-preflight-check.log','ef480-full-preflight-cl.log','ef480-full-preflight-ids.log','ef480-full-check-timings.tsv','ef480-full-wall.json','ef480-full-preflight.exit','dev67-rederive-ordered-tail.log','dev67-tail.exit','dev67-workbook-normalization.json','ef480-post-producer-integrity.json','ef480-candidate-input-freeze.json']:
 b=(r/name).read_bytes();logs[name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
web='chicago/4d/assets/web/hogan_store__log_1831.glb';assert(w/web).read_bytes()==git('show',freeze['HEAD']+':'+web)
report={'closed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'full_gate_exit':0,'actual_steps':1053,'candidate_tree':freeze['staged_tree'],'HEAD_before_commit':freeze['HEAD'],'MERGE_HEAD_before_commit':freeze['incoming_dev'],'wall':json.loads((r/'ef480-full-wall.json').read_text()),'actual_changelog_and_IDs':'PASS from full preflight3of3','all_source_bytes_and_index_unchanged_during_gate':True,'Hogan_web_exact_own_HEAD':True,'actual_remote_refs_after_gate':git('ls-remote','origin','refs/heads/dev','refs/heads/steward/t2377-hogan-picture-match').decode(),'logs':logs,'new_head_fresh_smokes':'NOT_YET_DISPATCHED; previous complete5eae bank historical only','commit_push_approval':'ROOT_REVIEW_REQUIRED'}
(r/'ef480-full-closed-verdict.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
