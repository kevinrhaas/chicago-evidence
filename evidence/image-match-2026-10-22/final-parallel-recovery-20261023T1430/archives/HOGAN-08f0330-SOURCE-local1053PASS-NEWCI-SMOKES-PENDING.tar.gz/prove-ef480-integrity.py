import subprocess as sp, json, hashlib
from pathlib import Path
from datetime import datetime,timezone
r=Path('/tmp/hogan-pr1229-integration'); app=r/'chicago/4d'; dev='ef48077f0bb5784f91730aed78a7ddcd1875e76c'
def git(*a):return sp.check_output(['git',*a],cwd=r)
def sha(b):return hashlib.sha256(b).hexdigest()
report={'observed_at':datetime.now(timezone.utc).isoformat(),'head':git('rev-parse','HEAD').decode().strip(),'incoming_dev':dev,'hogan_guards':[],'incoming_integrity':[]}
for g in json.loads((r/'.hogan-recovery/hogan-input-preservation.json').read_text()):
 b=(app/g['path']).read_bytes();assert sha(b)==g['sha256'],g['path'];report['hogan_guards'].append({'path':g['path'],'sha256':sha(b),'exact':True})
allowed=['chicago/4d/assets/gltf/hogan_store__log_1831.glb','chicago/4d/assets/web/hogan_store__log_1831.glb','chicago/4d/data/sources/cameron_c1900_first_post_office.json','chicago/4d/data/structures/hogan_store.json']
paths=git('diff','--name-only',dev,'--','chicago/4d/generators','chicago/4d/assets/gltf','chicago/4d/assets/web','chicago/4d/data/structures','chicago/4d/data/sources').decode().splitlines();assert sorted(paths)==sorted(allowed),paths;report['all_generators_and_nonhogan_master_web_source_structure_files_exact_dev']=True
for name,key in [('manifest.json','assets'),('manifest.web.json','masters')]:
 path='chicago/4d/assets/'+name;current=json.loads((r/path).read_text());incoming=json.loads(git('show',dev+':'+path));own=json.loads(git('show','HEAD:'+path));assert set(current)==set(incoming)
 for k in current:
  if k==key:
   assert set(current[k])==set(incoming[k]);
   for n,v in current[k].items():assert v==(own[k][n] if n=='hogan_store__log_1831.glb' else incoming[k][n]),(name,n)
  else:assert current[k]==incoming[k],(name,k)
 report['incoming_integrity'].append({'path':path,'all_incoming_entries_exact_except_own_hogan':True,'own_hogan_entry_exact_HEAD':True,'sha256':sha((r/path).read_bytes())})
raw=(app/'docs/LIBERTIES.md').read_bytes();incoming=git('show',dev+':chicago/4d/docs/LIBERTIES.md');assert raw.startswith(incoming);suffix=raw[len(incoming):];assert sha(suffix)=='69bf8a4f6044b20f49f1fc5a4812ed04b7e62e48105867de4fd3067d52e5b24a';report['raw_liberties_exact_incoming_prefix_plus_exact_own_suffix']=True
report['sourceS_Gale_not_imported']=all(not(app/'data/sources'/n).exists() for n in ['trowbridge_first_jail_gale_1902.json','andreas_1884_st_marys_engraving.json']);assert report['sourceS_Gale_not_imported']
(r/'.hogan-recovery/ef480-post-producer-integrity.json').write_text(json.dumps(report,indent=2)+'\n');print('ef480 integrity PASS: exact incoming modules/non-Hogan assets, registry entries, raw append and Hogan guards')
