"""Restore exact incoming ZIP bytes only after full semantic-member equality."""
from pathlib import Path
from io import BytesIO
import hashlib,json,subprocess,xml.etree.ElementTree as ET,zipfile
r=Path(__file__).resolve().parent;w=r.parent
name='chicago/reference/resident-research/final/audit/resident_audit_master.xlsx'
dev='67a630fc1ca8231a1d9149ab03d194dbdaa34e82'
old=subprocess.check_output(['git','show',dev+':'+name],cwd=w);new=(w/name).read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
def xml(e):return(e.tag,sorted(e.attrib.items()),e.text,e.tail,[xml(c)for c in e])
semantic=[];lexical=[]
with zipfile.ZipFile(BytesIO(old))as a,zipfile.ZipFile(BytesIO(new))as b:
 assert sorted(a.namelist())==sorted(b.namelist())
 for member in a.namelist():
  x,y=a.read(member),b.read(member)
  if x==y:continue
  lexical.append(member)
  if member.endswith(('.xml','.rels')):
   if xml(ET.fromstring(x))!=xml(ET.fromstring(y)):semantic.append(member)
  else:semantic.append(member)
report={'path':name,'incoming_dev':dev,'incoming_sha256':sha(old),'producer_sha256':sha(new),'semantic_XML_or_member_differences':semantic,'lexical_XML_member_differences':lexical,'proof':'Exact member names; namespace-expanded tags, sorted attributes, all text/tails and ordered children, including every cell value/formula/style retained; nonXML members byte-exact. ZIP headers/compression and namespace-prefix spelling excluded.','restored_exact_incoming_bytes':False}
(r/'dev67-workbook-normalization.json').write_text(json.dumps(report,indent=2)+'\n')
assert not semantic,'Actual semantic differences; preserve source unchanged and inspect'
if old!=new:(r/'dev67-workbook-producer.xlsx').write_bytes(new);(w/name).write_bytes(old)
subprocess.run(['git','add','--',name],cwd=w,check=True)
report['restored_exact_incoming_bytes']=True
(r/'dev67-workbook-normalization.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
