#!/usr/bin/env bash
set -uo pipefail
hogan_root=/tmp/hogan-pr1229-integration
hogan_logs="$hogan_root/.hogan-recovery"
export PYTHONPATH="/workspace/shared/python${PYTHONPATH:+:$PYTHONPATH}"
export PATH="/workspace/shared/tools/usr/bin:$PATH"
export npm_config_cache=/workspace/shared/npm-cache
export CHECK_JOBS=4 C4D_GATE_REQUIRE_READERS=1 C4D_GATE_REQUIRE_BASE=1
export CHECK_TIMINGS="$hogan_logs/ef480-full-check-timings.tsv"
export TMPDIR=/tmp/hogan-pr1229-tmp-ef480
mkdir -p "$TMPDIR"
cd "$hogan_root/chicago/4d" || exit 2
: > "$CHECK_TIMINGS"
hogan_gate_started=$(date +%s)
printf "%s\n" "$hogan_gate_started" > "$hogan_logs/ef480-full-start-epoch.txt"
./tools/preflight.sh > "$hogan_logs/ef480-full-preflight.log" 2>&1
hogan_exit=$?
hogan_gate_finished=$(date +%s)
printf '{"start_epoch":%s,"end_epoch":%s,"wall_seconds":%s,"exit":%s}\n' "$hogan_gate_started" "$hogan_gate_finished" "$((hogan_gate_finished-hogan_gate_started))" "$hogan_exit" > "$hogan_logs/ef480-full-wall.json"
printf '%s\n' "$hogan_exit" > "$hogan_logs/ef480-full-preflight.exit"
for hogan_item in preflight-check.log preflight-cl.log preflight-ids.log; do
 if [ -f "/tmp/$hogan_item" ]; then cp "/tmp/$hogan_item" "$hogan_logs/ef480-full-$hogan_item"; fi
done
exit "$hogan_exit"
