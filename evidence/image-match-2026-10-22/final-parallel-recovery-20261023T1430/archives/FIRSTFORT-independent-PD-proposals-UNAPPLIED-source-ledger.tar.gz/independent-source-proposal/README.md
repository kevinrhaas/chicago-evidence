# T-3041 independent first-fort publication sources — proposed only

Two new source records and eight actual page scans are prepared outside the app. No canonical source, held image, rights flag, camera, match, accepted/staleness check or geometry changed. The original 21 named records + 9 context members and every listed picture remain the task scope; no image case is accepted here.

* `andreas_1884_first_fort_engraving`: actual 1884 title, 1884 copyright and printed p79 were viewed. The book plate visibly contains the same engraving represented by Getty88810552 / CHM ICHi-021562. Full page is from the independent IA digitization, not Getty pixels.
* `earle_1902_first_fort_plate`: actual title, 1902 copyright, printed p5 creator/commission account, p10 facing narrative and p11 color plate were viewed. The plate visibly contains the same Earle artwork represented by Getty529322537 / CHM ICHi-062505, including the full decorative arch. Work on the bank mural cycle began in fall1900; this is not pre1850 artwork or a contemporary1803 view.

The age-based public-domain finding concerns these US-published1884/1902 illustrations. It is not institutional permission and does not grant blanket use of modern commercial reproductions. Both held Getty files retain check_required. Cameron/Getty529323671 and Petford/Getty529264885 still lack an independently verified publication/creation basis; museum No Known Copyright and an1803depicted-date field do not settle those questions.

`proof-manifest.json` records exact downloaded URL, byte count, SHA256 and actual view for every scan. The original IA metadata/scandata and search history are retained one directory above. Andreas service page numbers exclude deleted raw scans; printedp79 is servicen90/rawleaf103. The initially guessedn109 file is explicitly named NOT-p79 and is excluded from this proposal.

The two source records begin as cross_check; any future geometry or camera must derive explicitly from these independently obtained book pages with the original per-picture inventory cross-referenced. They are retrospective, cannot supply metric measurements, and do not reconcile their central-tower appearance with Whistler’s opposite-corner surveyed plan. Cupola dates and exact1812appearance remain inference. No camera or image metric was executed here.

Not applied. Adoption and source-card/registry producer checks are pending root scheduling after the active integration gate. This packet does not alter the frozen16-export build or prepared9-capture runner.
