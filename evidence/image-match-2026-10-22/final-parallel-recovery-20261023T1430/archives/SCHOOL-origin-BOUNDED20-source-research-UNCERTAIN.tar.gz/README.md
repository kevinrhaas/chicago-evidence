# T-2372 school drawing: bounded original-publication/identity research

2026-10-23. Light-only. No canonical edits, ticket closure, new export/browser, or modification to frozen school/Wolf proposals. The owner's T-3053 approval for attributed project use remains in force. **Original artist, publication/date and pictured-building identity remain unestablished.** No new source metadata patch is justified by these results.

## Concrete new evidence

The immediate article is now directly reachable:

https://drloihjournal.blogspot.com/2018/01/eliza-chappell-the-first-chicago-teacher-paid-by-public-funds-in-1833.html

Its actual image hyperlink serves a **910×523** copy of the same drawing, larger than the deposited 640×368 comparison image. I opened this actual image and the article's other subject image (a portrait of Chappell). The portrait is not an additional building view and no owner permission for that portrait is inferred. The larger school drawing still ends at the pictorial border, with no printed caption, original-credit line or legible artist signature. It does not identify or date itself. Exact image URL:

https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiOs1aDePw9-lkjqJeS0v7ICRGSuFvI8HCYUnojKk19BkrZxKjA2hWP0mh0Y5PW2FS4gutyxQlCLqTQ960w4Pt2pXroig4eve7N0FqqZaDvEz-eI3QX4RmTi8jK1Ax0zgxQdzFGqD_xbJc/s1600/21617595_10203558686525015_5452300313452439832_n.jpg

`blog-original.jpg`, SHA256 `8f7152e6286e00413de52a97ce9faf15f1e8a213aae5c8c8928069a30e9d935c`,99277bytes. This is another reproduction of the **same** single witness, not independent corroboration. The original approved comparison photo and its camera were not replaced or rescaled in any frozen proposal. `linked-image-fetches.json` retains both exact image links/hashes/dimensions. Credit remains **Artist unidentified; reproduced by the Digital Research Library of Illinois History Journal in its 2018 Eliza Chappell article**. Approval establishes attributed project reference/comparison/display use, not public domain, copyright-holder permission, an open licence or any date/identity ruling.

The full current article and Blogger feed agree: the caption is only “The Eliza Chappell School was roughly at Lake and Clark Streets are today.” Neither names an illustrator, original publication or collection. Its body says the first school used a former log store in 1833 and later moved to the First Presbyterian Church at Lake/Clark in 1834. The caption does not identify the pictured shore cabin's lot. Exact-caption search returned only this same article in the results obtained, not an earlier publication.

## Actual nineteenth-century page evidence, separate from the drawing

Shepherd Johnston, *Historical sketches of the public school system of the city of Chicago to the close of the school year1878–79* (Chicago: Clark & Edwards,1880), printedpp3–4, IA `historicalsketch00john`:

https://archive.org/details/historicalsketch00john/page/n9/mode/2up

I retrieved and **read the actual page images**, not only OCR. Printedp 3 (leaf 9) quotes Mr. Wells:

> “Miss Chappel's school was an Infant School, of about 20 children, kept in a log house on South Water Street, a short distance west of the grounds belonging to the Fort.”

Printedp 4 (leaf 10) distinguishes the later accommodations:

> “...was moved into the better accommodations furnished by the First Presbyterian Church, on the west side of Clark Street, between Lake and Randolph. An appropriation made to her in 1834 entitled her school to rank as the first public school in Chicago.”

The exact requests and leaves are in `johnston-actual-scans.json`; actualpage files are `historicalsketch00john-actual-p3.jpg` and `...-actual-p4.jpg`. This is an1880 retrospective account quoting Wells and, separately, Jeremiah Porter in *The Pacific*,10December1879. It is **not a contemporary1833 survey or the original publication of the drawing**. It supports keeping the initial log house distinct from the later Clark Street church, consistent with the current record's broad siting. It supplies no school dimensions, exact lot, drawing credit or visual identity. Do not identify the drawing with the Sauganash annex, move coordinates or grade the picture from this prose. Johnston's school count/about20 is not an image-derived capacity measurement; no record was changed. The original *Pacific* issue was named by Johnston but was not reached in this run.

Two initial `services/img` requests returned the item's generic thumbnail (3011bytes each), not the requested pages. Those mistaken payloads were discarded; `johnston-scans.json` explicitly records them as invalid page evidence. The later BookReaderImages requests above are the actual, directly inspected page images.

## Catalogue/publication routes and limits

Requests/URLs/statuses are preserved in numbered `*-fetches.json`; downloaded metadata/OCR are raw research support, not rewritten authoritative sources.

- Library of Congress and Explore Chicago Collections queries returned 403. No negative catalogue finding is claimed.
- Chicago History Museum's public search page now returns 200, but it is a client-loaded shell with no fetched result records. Its search JavaScript returned 403, the guessed unminified public path 404. **The catalogue was not successfully searched**; the shell is not proof of no holdings.
- Newberry returned a 200 site shell at an old saved result-route URL, not a validated current Chappell search. No result/identity inference.
- Google Books API remained 429; Google web page returned a JavaScript challenge. Bing's obtained results drifted to generic “Eliza”/“Chappell” entertainment entities and did not answer the historical query. These are inconclusive routes, not archival evidence.
- Wikimedia Commons' file search for Chicago school 1833 surfaced books/catalogue records, not an independently captioned instance of this exact drawing. It led to Johnston's 1880 scan above.
- New IA OCR checks: *Chicago public schools*1908 (`chicagopublicsch00chic`); McManis, *Ella Flagg Young and a half-century of the Chicago public schools*1916 (`ellaflaggyoungan00mcmaiala`); Clarke, *The public schools of Chicago, a sociological study*1897 (`publicschoolsch00clargoog`); Otis, *The First Presbyterian church,1833–1913* (`firstpreschurch00otis`); Moses/Kirkland, *History of Chicago, Illinois*1895vol1 (`historyofchicago01mose`). Texts/caption lists checked did not provide the drawing's original credit or a positive candidate. **These books are not conclusively eliminated on OCR alone.** The1916 book's listed illustrations concern Young and later school buildings. Clarke gives a short log-school-to-church account but no image attribution. Otis's retrieved prose gives an inconsistent marriage year relative to the established1835 chronology, so it must not silently replace current dates. No new illustration from these books was adopted.
- Prior research already inspected and rejected William Mark Young's Rumsey 1844 school print. It was not reopened merely on its similar title. Existing Andreas/Porter/Kirkland/Quaife searches are not new discoveries here; their OCR-only exclusions should not be upgraded into comprehensive page-by-page visual proofs.

## Most consequential next visual work after the queued recess capture

The actual full old combined comparison and source/before/afterdetail are preserved at:

`/tmp/chicago-next-model/log-combined/runs/20261023-050224-069556/reviews/proposed/T-2372-school-shore-side-by-side.jpg`

`/tmp/chicago-next-model/log-combined/runs/20261023-050224-069556/reviews/details/T-2372-school-shore-source-before-after.png`

1. **Entrance-gable surface:** the source visibly continues horizontal log courses into its triangular facing gable; the actual proposed mesh renders an enormous plain roof-colored triangle. This is a clear, low-ambiguity pictured category and the best bounded follow-up after the doorway. An opt-in log-gable skin must respect the school roof's explicitYaxis, keep default/all 81 behavior exact and tag chosen course/ridge sections as reconstructed. Do not claim exact log diameter, colour or cladding mechanics.
2. **Frontage/proportion:** the actual model face is much wider than the drawing under the frozen provisional camera. This dominates the silhouette even after the correct gable direction. Both dimensions of the existing 24×18 ftfootprint are reconstructed choices, not sacred survey values. A future bounded physical-width trial may be warranted; use the unchanged camera to expose trade-offs, declare all metric choices reconstructed and inspect physical polygon/collision/placement consumers. No dimension is proposed or falsely measured in this research pass. The scene's inconsistent perspective prevents a historical metric camera solution. A camera adjustment alone must not conceal the broad model front.
3. **Roof fabric:** the source has a clear staggered rectangular shake/shingle-like pattern across the visible slope; actual model is smooth. A finite geometric/relief covering proxy could improve resemblance without using source pixels as textures. Count, lengths, thickness, pattern and weathering remain reconstructed. The drawing does not establish a literal colour photograph or a unique illumination.
4. **Wall courses and joints:** source courses are darker, rounder and irregular with recessed joints; actual generic log face has regular flat bands and conspicuous pale chink strips. Reuse a bounded opt-in face/joint control only if appropriate for a simple school body; Wolf's compound-topology controls are not a licence to assign the school an Lform. Avoid global palette/default changes or claiming attested texture.
5. **Opening heads/stations, stack, context:** larger/higher framed sash already improve the baseline but still need full source alignment. The queued blind-door increment addresses the dark occupied doorway only; it introduces neither a historical interior nor 1835 schoolchildren. The visible rear stack is not established by the drawing crop, but absence in this crop is not enough evidence to remove an inferred heating stack. Full historical identity/date, camera, setting and original ticket acceptance remain open.

The queue contains `/tmp/chicago-next-model/T-2372-door-recess-next` unchanged,291files, manifest `e02f5785ed87dde7eb42a8bfa9c8edec76ee7643e4cec8f0161bef8e44defc1d`. It is UNAPPLIED/UNRENDERED. One doorway is an increment toward the full original case, not its completion. School claims/rights do not need to be repeated. CPU/browser slot remains CLEAR.

## Recovery/archiving scope

This directory is a light research notebook, not an executable generator proposal. `findings.json` and this README summarize positive/negative limits. Exact fetch responses remain local supporting evidence. If publishing a bounded evidence capsule, include this README/findings, fetch metadata, the **owner-approved school drawing** and public-domain1880actualpageimages; exclude `blog-portrait.jpg` and unrelated website/full-article payloads unless separately reviewed. Inspecting the portrait did not grant republication permission. No changes to canonical source records follow until original-publication/identity evidence actually warrants them.
