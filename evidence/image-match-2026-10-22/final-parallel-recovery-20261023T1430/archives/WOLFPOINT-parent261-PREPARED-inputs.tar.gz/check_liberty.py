from pathlib import Path
from types import ModuleType
import json,ast,sys
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;S=H/'contract-support';sys.path.insert(0,str(S))
def load(n,p):
 m=ModuleType(n);m.__file__=str(p);sys.modules[n]=m;exec(compile(p.read_text(),str(p),'exec'),m.__dict__);return m
lib=load('pole_next_liberty_compiler',S/'compile_liberties.py');names=json.loads((S/'structure-names.json').read_text());all_entries=[];counts=[]
for file in ['prior-log81-liberties.md','prior-L-liberty.md','prior-position-liberty.md','prior-surface-pole-liberty.md']:
 entries,errors=lib.parse('## Per-subject liberties\n\n'+(S/file).read_text(),names,sources={});assert not errors,errors;all_entries+=entries;counts.append(len(entries))
entries,errors=lib.parse('## Per-subject liberties\n\n'+(H/'LIBERTY-APPEND.md').read_text(),names,sources={});assert not errors and len(entries)==1 and len(entries[0]['covers'])==2,errors
assert not any(c['aspect']=='form.compound_log_profile' for c in entries[0]['covers']),'Inferred category must not be falsely claimed as a reconstructed attribute'
all_entries+=entries;ledger=json.loads((S/'liberties.json').read_text());ledger['liberties']+=all_entries
nodes=[n for n in ast.parse((S/'validate.py').read_text()).body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in {'Report','graded_values','inferred_values','unbuilt_values','check_liberties_coverage'}]
ns={'PHASE_ASPECTS':('footprint','position','documented_range'),'STRUCTURE_ASPECTS':('function','occupants','present_status','built'),'GEOMETRY_OWES_LIBERTY':('absent','simplified')};exec(compile(ast.Module(body=nodes,type_ignores=[]),'actual_liberty_contract','exec'),ns)
p=load('pole_next_liberty_params',H/'candidate/generators/archetypes/log_dwelling_params.py');r=json.loads((H/'candidate/data/structures/wolf_point_tavern.json').read_text());rep=ns['Report']();ns['check_liberties_coverage']({'wolf_point_tavern':r},ledger,rep,{'log_dwelling':p.CONSUMED},forward_only=True);assert not rep.errors,rep.errors
out={'status':'passed','prior_entries':counts,'new_entries':1,'new_precise_covers':2,'inferred_finish_category_not_falsely_claimed_reconstructed':True,'actual_forward_coverage_errors':0,'required_new_note_paths':json.loads((H/'note-reader-fragment.json').read_text())['read']['structures'],'limits':'Copied actual parser/forward coverage functions; canonical ledger/note-pool/compiler/gates remain owed.'}
(H/'liberty-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
