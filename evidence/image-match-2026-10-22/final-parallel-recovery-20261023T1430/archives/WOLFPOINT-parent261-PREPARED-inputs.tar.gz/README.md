# T-2386 next: blind doorway recesses and rounded course relief

**FROZEN / UNAPPLIED / UNRENDERED.** This is a new light-only continuation against the actual surface/pole comparison, not an overwrite or another model variant in a completed run. Original T-2386 remains claimed by `school_lighthouse_castle_bridge` (tickets claim `e7e32d34e8698ccd966a80948cea704d80fd7e2e`), with its complete all-picture acceptance unchanged. No heavy run, canonical write, source-image match or completion is claimed here.

## Exact actual baseline and source

Copied baseline is the successful actual master from `T-2386-surface-pole-next/runs/20261023-130354-476531`, SHA256 **ff14654f9c40820a0a8680ade1060daa1d19a8b3c695c9e3013376eb1b365acc**, with its exact record/modules, source/render comparison, bare render and producer contract. Root and this agent directly inspected it. Gable courses and pole/board pose improved; both doors were still pale closed leaves, and the walls/gables remained strongly regular pale-striped proxies. Its source-image verdict is `differs`.

The governing source remains the credited **1867 Blanchard/Shober NYPL sheet depicting1833**, not the metadata-conflicted Newberry poster. It supports dark/open-looking entry apertures and rounded/unevenly shaded horizontal faces with narrow dark recessed joints. The full original sheet and source metadata are copied. No measured timber section, exact door state, authentic colour/woodgrain, literal original animal device or photoreal texture is asserted. Existing source credit/rights/date limits are unchanged; the source-note append states this re-reading and its bounds.

Camera bytes remain exactly SHA256 **2a96283300029b94481286f5b246c2c9c53efb6f505ab140ddef543288a48f82**: same provisional square pixels, fixed6000px focal, principal/eye/yaw/near plane and common-grade ambiguity. Its original `solve.comparison` prose describes the first pair; this README and new receipt identify the current actual baseline. No camera is adjusted to manufacture apparent progress.

## Minimal four-file increment

`door-log-relief-next.patch` changes only two log modules, Wolf Point's record and the appended shared-source note. Two fields are new, **keyword-only and disabled by default**:

- `compound_door_state=None|"recess"`, reconstructed. For the existing stated +Y and +X door rectangles, subtract only exterior wall skins and inset joint backing, omit closed leaves and use the already established blind300mm dark back/casing/reveal/threshold kit. There is no invented room, swing, occupant, light or interior route. The existing Hogan skin cutter is generalized by axis and optional skin-back distance; its ordinary +Y wrapper keeps its original zero skin-back behavior exactly.
- `compound_log_profile=None|"rounded_relief"`, inferred appearance category, allowed only on the explicit bounded elbow's `log_courses` envelope. New face relief uses the **existing palette** and a chosen300mm rhythm,20mm gaps,15mm dark backing setback,38–48mm seeded curved relief and six panels per course. It continues into the triangular gables. Source-rounded shading motivates the category; all chosen dimensions, seeded variation and dark shadow-backing proxy emit reconstructed confidence. This does not attest black painted chinking, literal round-log construction, hidden framing, authentic colour or a new material texture.

No shared palette/material module changes. The new profile replaces only this opt-in's pale chink strips and exaggerated squared end-notch proxies. It retains the partly-frame text and does not identify hidden structural fabric. Existing roof/overhang, pole/board/device, light, doorway size/station, physical polygon, world origin, position confidence, dates, source credits and external entrance descriptor remain unchanged. New controls are refused outside the bounded elbow; rounded relief requires the explicit log-course envelope.

The actual physical L stays **solid for visitor collision**. Mesh door recesses end blindly at300mm and do not create a walk-through doorway or room. Normal exterior entrance/clearance metadata is retained; no opening is falsely projected onto another wall. Terrain/contact, pole clearance and app behavior remain separate integration obligations.

## Lightweight proof

`light-check.json` passes:

- Exact raw vertices/faces/material/confidence parity for all81 prior frozen final-log81 records, including Hogan's existing front recess, with the new controls off; exact parity again for the actual surface/pole L with them off. Existing positional constructor signature is preserved.
- Seventeen invalid/unsupported controls, actual record/source schemas, finite nondegenerate geometry and109 existing roof upper-envelope samples. Geometry remains inside the same near/far planes and common detail crop.
- Actual normal-axis doorway ray tests: the outermost centre hit is the dark blind back at Y9.8 behind wallY10.1, and X6.9 behind wallX7.2. Adjacent curved skin remains. This catches uncut inset backing that would otherwise conceal a supposed deep recess.
- No pale-chink primitives in the new rounded profile; all chosen profile/recess faces reconstructed. Proposed raw mesh3382vertices /1730triangles, versus actual baseline2077/1079. This is one structure's proposed visible cost; app/performance gates remain owed.

Raw projected bounds are [147.80,596.54]–[517.75,921.48]px, against baseline[146.70,596.54]–[519.10,921.48]. Pole/window projections, camera and crop are unchanged. These are raw numeric checks, **not a rendered appearance verdict**.

`liberty-check.json` passes the copied real parser/forward coverage: retain prior8+1+1+1 entries, append this `LIBERTY-APPEND.md` (one entry /two precise Covers). Inferred profile category is deliberately not falsely claimed as a reconstructed attribute. Merge the two new research-note reader paths in `note-reader-fragment.json` into current `name_pool_keys.json read.structures`; preserve every earlier path and independent edit.

Patch dry-run passed against exact copied app-root baseline:

```sh
cd /tmp/chicago-next-model/T-2386-door-log-relief-next/baseline
git apply --check -p3 ../door-log-relief-next.patch
```

Patch has normal repository paths `a/chicago/4d/...` for selective integration from the actual repo root. Apply only after prior final log81 + physicalL + side-entry + centre-preserving origin + surface/pole composition. Preserve independent Hogan/source-S/frame/fort edits and source credits. Do not restore an old whole tree or apply the superseded parallel-gable trial.

## Prepared future actual comparison

Dry runner (light only), already passed:

```sh
python3 /tmp/chicago-next-model/T-2386-door-log-relief-next/run_next.py
```

Only after another explicit parent heavy-slot grant:

```sh
python3 /tmp/chicago-next-model/T-2386-door-log-relief-next/run_next.py \
  --execute-after-root-grant \
  --grant-note 'Root granted the bounded Wolf Point blind-door and log-relief comparison'
```

One new actual pinned official export and one new same-camera capture will be compared against the copied exact prior actual master/render. No before re-export or old output mutation. The runner uses the absolute frozen build.py path, real `structure_id__phase_id` seed, cached archive/version verification, singleton manifest/wrote list, recomputed input hash, decoded GLB contract essentials and triangle count. Ephemeral browser/server/process group cleanup is scoped to its own commands. Outputs/receipt/full comparisons/bare renders/common source-before-after detail go only to a new `runs/<timestamp>/`.

New research `.match.json` stays `unreviewed` until actual direct inspection. No matches verdict, original acceptance closure or gate bypass is preassigned. Root owns the shared heavy slot; no execution is currently authorized by this prepared package alone.

Inputs are regular copied and self-contained: candidate, exact actual baseline, source image, viewer/producer support, copied81-record/schema/parser proof. Only existing installed Python/Pillow/Node/Chromium, `/workspace/node_modules` and pinned Blender cache are runtime dependencies. No install, fetch, root/canonical edit or live-checkout read occurs during execution. `prepare.py` is one-time documentation; do not rerun into this frozen directory. `inputs.json`, `snapshot.json`, `checkpoint.json` and `ARTIFACTS.json` bind the package.

## Full scope and integration still owed

Original T-2386 still requires every listed picture's camera, actual side-by-side and no open differences. This proposal addresses only the governing sheet's next visible door/profile differences. Literal log/joint fabrication and tone, casing/sash details, roof covering/edges/stack fabric, irregular sapling/board/device, hidden plan, common-grade/metric degeneracy, retrospective1833-to1835 continuity and other views remain unresolved.

The isolated shape fixture excludes neighbours, river/terrain, flora and stale trade props. The four known trade-goods instances inside the existing L must regenerate normally; exclusion here does not certify clearance. The reconstructed centre-preserving geographic origin remains and no parcel/river margin or passable interior is newly claimed.

Shared builder/parameter changes still owe the **one official all81 log-family refresh**, rescoping against the then-current checkout/manifest if necessary. Compose this increment before that final parent-coordinated refresh if its actual preview is accepted. Append liberties/note paths and run normal source/grade/liberty/scene/contact/entrance/prop regeneration, full gates and desktop/mobile app QA. Do not bake one canonical target, copy these research outputs into the manifest, hand-edit hashes or declare the original case complete.
