"""Actual raw/default/roof/pose checks only. No Blender/browser/export."""
from pathlib import Path
from types import ModuleType
from dataclasses import asdict,replace
import sys,json,math,inspect,hashlib,shutil,ast
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;N=H/'candidate';O=H/'baseline';F=Path('/tmp/chicago-next-model/log81-materializer/05f6-sourceS-final')
sys.path.insert(0,str(N/'generators'));sys.modules['bpy']=ModuleType('bpy')
def load(n,path):
 m=ModuleType(n);m.__file__=str(path);sys.modules[n]=m;exec(compile(path.read_text(),str(path),'exec'),m.__dict__);return m
oldp=load('surface_old_params',O/'generators/archetypes/log_dwelling_params.py');newp=load('surface_new_params',N/'generators/archetypes/log_dwelling_params.py')
sys.modules['archetypes.log_dwelling_params']=oldp;old=load('surface_old_mesh',O/'generators/archetypes/log_dwelling.py');sys.modules['archetypes.log_dwelling_params']=newp;new=load('surface_new_mesh',N/'generators/archetypes/log_dwelling.py')
from common.mesh import MeshBuilder
class Raw(MeshBuilder):
 def to_object(self,materials=None):self.materials=materials;return self
for m in [old,new]:m.MeshBuilder=Raw;m.simple_material=lambda *a,**kw:(a,kw)
def raw(o):return (o.verts,o.faces,o.conf,o.mat_index,o.named,o.materials)
assert {'compound_door_state','compound_log_profile'} <= set(newp.CONSUMED)
extra={'compound_door_state':None,'compound_log_profile':None}
a=inspect.signature(oldp.LogDwellingParams);b=inspect.signature(newp.LogDwellingParams)
assert [v for k,v in b.parameters.items() if k not in extra]==list(a.parameters.values());assert all(b.parameters[k].kind==inspect.Parameter.KEYWORD_ONLY for k in extra)
# Freeze the81 actual records used for replay; no live-checkout source dependencies.
scope=json.loads(((H/'freshness-scope.json') if (H/'freshness-scope.json').exists() else (F/'freshness-scope.json')).read_text());proof=H/'parity-inputs'
if not proof.exists():
 proof.mkdir()
 for row in scope['assets']:shutil.copyfile(F/f"review-tree/chicago/4d/data/structures/{row['structure_id']}.json",proof/f"{row['structure_id']}.json")
 shutil.copyfile(F/'freshness-scope.json',H/'freshness-scope.json')
count=0
for row in scope['assets']:
 r=json.loads((proof/f"{row['structure_id']}.json").read_text());ph=next(p for p in r['phases'] if p['id']==row['phase_id']);x=oldp.from_phase(ph,r);y=newp.from_phase(ph,r);d=asdict(y)
 for k,v in extra.items():assert d.pop(k)==v
 assert d==asdict(x)
 key=Path(row['asset']).stem;assert raw(old.build(x,key))==raw(new.build(y,key)),key;count+=1
r=json.loads((N/'data/structures/wolf_point_tavern.json').read_text());ph=r['phases'][0];p=newp.from_phase(ph,r)
br=json.loads((O/'data/structures/wolf_point_tavern.json').read_text());x=oldp.from_phase(br['phases'][0],br);off=newp.from_phase(br['phases'][0],br)
assert raw(old.build(x,'wolf_point_tavern__log_frame_1828'))==raw(new.build(off,'wolf_point_tavern__log_frame_1828'))
assert ph['footprint']==br['phases'][0]['footprint'] and ph['position']==br['phases'][0]['position'] and ph['documented_range']==br['phases'][0]['documented_range']
assert newp.side_access_faces(p)==oldp.side_access_faces(x)
# New source category is inference; all chosen new emitted face details remainc1.
assert ph['form']['compound_wall_cladding']['confidence']=='inferred'
roof=Raw('roof');new._elbow_roof(roof,p)
def inside(poly,x,y):
 yes=False
 for a,b in zip(poly,poly[1:]+poly[:1]):
  if (a[1]>y)!=(b[1]>y) and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:yes=not yes
 return yes
checked=0;cw=5.;o=.12;h=2.6;t=math.tan(math.radians(42))
for xx in [-.09,.17,.83,1.9,2.8,3.9,4.8,5.08,5.7,6.8,7.28]:
 for yy in [-.08,.23,1.13,2.1,3.3,4.7,5.08,5.9,8.1,9.8,10.18]:
  hits=[]
  for face in roof.faces:
   pts=[roof.verts[k] for k in face]
   if inside(pts,xx,yy):
    a,b,c=pts[:3];normal=((b[1]-a[1])*(c[2]-a[2])-(b[2]-a[2])*(c[1]-a[1]),(b[2]-a[2])*(c[0]-a[0])-(b[0]-a[0])*(c[2]-a[2]),(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))
    if normal[2]>1e-10:hits.append(a[2]-(normal[0]*(xx-a[0])+normal[1]*(yy-a[1]))/normal[2])
  occupied=(-o<xx<cw+o and -o<yy<10.1+o) or (cw+o<=xx<7.2+o and -o<yy<cw+o)
  assert len(hits)==int(occupied),(xx,yy,hits)
  if occupied:
   za=h+min(xx,cw-xx)*t if xx<cw+o else -math.inf;zb=h+min(yy,cw-yy)*t if xx>cw/2 and yy<cw+o else -math.inf
   assert abs(hits[0]-max(za,zb))<1e-8;checked+=1
assert set(roof.conf)=={1.}
for axis,plane in [('x',7.2),('y',10.1)]:
 cap=Raw('cap');new._rounded_compound_gable(cap,axis,plane,0,5,2.6,4.8510101107446,1)
 assert set(cap.conf)=={1.} and set(cap.mat_index)=={new.M_LOG,new.M_DARK}
 assert all(min(v[2] for v in cap.verts)<=v[2]<=4.8510101107446+1e-9 for v in cap.verts)
post=Raw('post');new._posed_sign_pole(post,p);assert set(post.conf)=={1.}
# Whole geometry and actual camera depth/bounds, with no render substitution.
built=new.build(p,'wolf_point_tavern__log_frame_1828')
for v in built.verts:assert all(math.isfinite(x) for x in v)
for face in built.faces:
 pts=[built.verts[k] for k in face];normal=[0.,0.,0.]
 for a,b in zip(pts,pts[1:]+pts[:1]):
  for k in range(3):i,j=(k+1)%3,(k+2)%3;normal[k]+=(a[i]-b[i])*(a[j]+b[j])
 assert sum(v*v for v in normal)>1e-16
assert new.M_CHINK not in built.mat_index and old.M_CHINK in old.build(x,'wolf_point_tavern__log_frame_1828').mat_index
# Normal-axis ray through each actual doorway: outermost hit must be the blind
# dark back at300mm, not uncut skin or an invented room. Also retain adjacent skin.
def ray_faces(axis,along,z):
    ni,ui=(1,0) if axis=="y" else (0,1);hits=[]
    for face,mat in zip(built.faces,built.mat_index):
        pts=[built.verts[k] for k in face];a,b,c=pts[:3]
        n=((b[1]-a[1])*(c[2]-a[2])-(b[2]-a[2])*(c[1]-a[1]),(b[2]-a[2])*(c[0]-a[0])-(b[0]-a[0])*(c[2]-a[2]),(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))
        if abs(n[ni])<1e-10:continue
        if inside([(v[ui],v[2]) for v in pts],along,z):
            plane=a[ni]-(n[ui]*(along-a[ui])+n[2]*(z-a[2]))/n[ni];hits.append((plane,mat))
    return sorted(hits)
recesses=[]
for axis,plane,u,z,near in [("y",10.1,3.55,.91,2.8),("x",7.2,3.35,.86,2.6)]:
    hits=ray_faces(axis,u,z);assert hits and abs(hits[-1][0]-(plane-.30))<1e-8 and hits[-1][1]==new.M_DARK,(axis,hits)
    wall=ray_faces(axis,near,1.04);assert wall and wall[-1][0]>plane,(axis,wall)
    recesses.append({'axis':axis,'wall_plane_m':plane,'outermost_actual_door_hit_m':hits[-1][0],'depth_m':.30,'material':'existing dark','adjacent_curved_skin_retained':True})

cam=json.loads((N/'docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.json').read_text());assert (N/'docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.json').read_bytes()==(O/'docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.json').read_bytes()
e=cam['eye'];sn=math.sin(math.radians(cam['yaw_deg']));cs=math.cos(math.radians(cam['yaw_deg']))
def project(v):
 du,dv,dz=[v[k]-e[k] for k in range(3)];d=du*sn+dv*cs;assert 150<d<500
 return [cam['principal_px'][0]+6000*(du*cs-dv*sn)/d,cam['principal_px'][1]-6000*dz/d]
old_points=[project(v) for v in old.build(x,'wolf_point_tavern__log_frame_1828').verts];old_bounds={'min':[min(v[k] for v in old_points) for k in range(2)],'max':[max(v[k] for v in old_points) for k in range(2)]}
q=[project(v) for v in built.verts];bounds={'min':[min(v[k] for v in q) for k in range(2)],'max':[max(v[k] for v in q) for k in range(2)]}
assert all(0<=bounds['min'][k]<bounds['max'][k]<=cam['image_px'][k] for k in range(2))
invalid=[replace(p,compound_door_state='open_interior'),replace(p,compound_log_profile='painted'),replace(p,compound_wall_cladding=None),replace(p,compound_door_state=True),replace(p,compound_log_profile=True),replace(p,compound_wall_cladding='brick'),replace(p,compound_joint=None),replace(p,compound_roof_overhang_m=True),replace(p,compound_roof_overhang_m=float('nan')),replace(p,compound_roof_overhang_m=.31),replace(p,sign=None),replace(p,sign_mount='bracket'),replace(p,sign_pole_set_out=()),replace(p,sign_pole_set_out=((0.,0.),)+p.sign_pole_set_out[1:]),replace(p,sign_pole_set_out=(p.sign_pole_set_out[0],(6.45,6.,15.))+p.sign_pole_set_out[2:]),replace(p,sign_pole_set_out=p.sign_pole_set_out[:2]+((0.,0.,0.),)+p.sign_pole_set_out[3:]),replace(p,sign_pole_set_out=p.sign_pole_set_out[:3]+((True,1.),)+p.sign_pole_set_out[4:])]
for v in invalid:
 try:v.validate()
 except newp.ParamError:pass
 else:raise AssertionError('unsupported pose/envelope accepted')
import jsonschema
schema_root=F/'review-tree/chicago/4d'
for rel in ['data/structures.schema.json','data/source.schema.json']:
 dest=H/Path(rel).name
 if not dest.exists():shutil.copyfile(schema_root/rel,dest)
jsonschema.validate(r,json.loads((H/'structures.schema.json').read_text()));jsonschema.validate(json.loads((N/'data/sources/blanchard_shober_1867_wolf_point.json').read_text()),json.loads((H/'source.schema.json').read_text()))
# Approximate source picks constrain appearance only. No geographic/metric solve.
base,head,arm,board,drop=p.sign_pole_set_out
features={'pole_base_at_common_grade':{'source_approx_px':[350,915],'projected_px':project((*base,0))},'pole_head':{'source_approx_px':[303,610],'projected_px':project(head)},'window_centre':{'source_approx_px':[485,859],'projected_px':project((1.45,10.1,1.7))}}
for row in features.values():row['residual_px']=[v-s for v,s in zip(row['projected_px'],row['source_approx_px'])]
report={'status':'PASSED_LIGHT_ONLY_UNRENDERED','all81_prior_raw_material_conf_defaults_exact':count,'old_actual_L_raw_material_conf_exact_with_new_controls_off':True,'new_keyword_only_fields':extra,'invalid_guards':len(invalid),'physical_polygon_world_position_dates_unchanged':True,'existing_side_access_descriptor_unchanged':True,'new_wall_category':'inferred curved relief, not attested timber section/texture/colour/metres','all_new_recess_profile_detail_faces_reconstructed':True,'roof_upper_envelope_sample_points':checked,'roof_slabs_no_duplicate_upper_surface_at_samples':True,'old_Hogan_front_recess_cutter_default_parity_covered_in81':True,'vertices':len(built.verts),'triangles':sum(len(f)-2 for f in built.faces),'actual_blind_external_door_recess_ray_checks':recesses,'pale_chink_primitives_absent_only_on_new_profile':True,'actual_raw_camera_bounds_px_before':old_bounds,'actual_raw_camera_bounds_px_after':bounds,'same_actual_baseline_camera_bytes':True,'approximate_source_feature_projections':features,'source_record_schemas':'passed','limits':'No Blender/browser/GLB or new acceptance; existing actual L baseline is preserved. Other retrospective views, door states, texture/fabric, metric station and canonical81/consumers/site/props/appQA remain open.'}
(H/'light-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
