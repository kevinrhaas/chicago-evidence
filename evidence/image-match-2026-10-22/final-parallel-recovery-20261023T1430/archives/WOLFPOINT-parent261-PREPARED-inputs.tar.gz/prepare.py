"""One-time /tmp-only proposal; no Blender/browser/canonical work."""
from pathlib import Path
import shutil,json,difflib,hashlib
H=Path(__file__).resolve().parent;P=Path('/tmp/chicago-next-model/T-2386-surface-pole-next');R=P/'runs/20261023-130354-476531';assert not (H/'candidate').exists()
shutil.copytree(P/'candidate',H/'candidate')
rels=['generators/archetypes/log_dwelling.py','generators/archetypes/log_dwelling_params.py','data/structures/wolf_point_tavern.json','data/sources/blanchard_shober_1867_wolf_point.json']
for rel in rels:
 d=H/'baseline'/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/'after'/rel,d)
for rel in ['assets/gltf/wolf_point_tavern__log_frame_1828.glb','assets/manifest.json','docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.json','export-contract.json']:
 d=H/'baseline'/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/'after'/rel,d)
for rel in ['render.png','nypl-1867-L-provisional-side-by-side.jpg']:
 d=H/'baseline/reviews'/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/'reviews/after'/rel,d)
# Two disabled-by-default, keyword-only fields. Earlier controls stay unchanged.
p=H/'candidate/generators/archetypes/log_dwelling_params.py';s=p.read_text();needle='"compound_wall_cladding", "compound_roof_overhang_m", "sign_pole_set_out",';assert s.count(needle)==1;s=s.replace(needle,needle+' "compound_door_state", "compound_log_profile",')
needle='    compound_wall_cladding: str | None = field(default=None, kw_only=True)';assert s.count(needle)==1;s=s.replace(needle,needle+'''
    # First exterior recess/profile proxies, bounded to this stated compound.
    compound_door_state: str | None = field(default=None, kw_only=True)
    compound_log_profile: str | None = field(default=None, kw_only=True)''')
needle='        if self.compound_wall_cladding not in (None, "log_courses"):';assert s.count(needle)==1;s=s.replace(needle,'''        if self.compound_door_state not in (None,"recess"):
            raise ParamError("compound_door_state is None or recess")
        if self.compound_log_profile not in (None,"rounded_relief"):
            raise ParamError("compound_log_profile is None or rounded_relief")
        if (self.compound_door_state is not None or self.compound_log_profile is not None) and self.compound_joint!="elbow":
            raise ParamError("compound opening/profile requires bounded elbow")
        if self.compound_log_profile is not None and self.compound_wall_cladding!="log_courses":
            raise ParamError("rounded compound relief requires explicit log-course envelope")
'''+needle)
needle='        compound_wall_cladding=val("compound_wall_cladding"),';assert s.count(needle)==1;s=s.replace(needle,needle+'''
        compound_door_state=val("compound_door_state"),
        compound_log_profile=val("compound_log_profile"),''');p.write_text(s)
# Generalize the existing proven Hogan skin cutter, preserving old defaults/order.
p=H/'candidate/generators/archetypes/log_dwelling.py';s=p.read_text();a=s.index('def _cut_front_door_recess(');z=s.index('\ndef _kit(',a);old=s[a:z]
body=old[old.index('    def clip('):]
body=body.replace('    doors = [r for r in core_front_rects(p) if r[0] == "door"]','    normal_axis,along_axis = (1,0) if axis == "y" else (0,1)\n    doors = [r for r in rects if r[0] == "door"]')
body=body.replace('all(v[1] >= wall_y-1e-9 for v in poly)','all(v[normal_axis] >= plane-skin_back_m-1e-9 for v in poly)').replace('min(v[0] for v in poly) < u1 and max(v[0] for v in poly) > u0','min(v[along_axis] for v in poly) < u1 and max(v[along_axis] for v in poly) > u0').replace('[(0,u0,True),(0,u1,False),(2,z0,True),(2,z1,False)]','[(along_axis,u0,True),(along_axis,u1,False),(2,z0,True),(2,z1,False)]')
head='''def _cut_front_door_recess(b: MeshBuilder, p: LogDwellingParams, wall_y: float) -> None:
    """Existing +Y Hogan skin cutter; same rectangles, order and zero skin-back."""
    _cut_door_recesses(b,"y",wall_y,core_front_rects(p))


def _cut_door_recesses(b,axis,plane,rects,skin_back_m=0.):
    """Subtract stated external doors from one outward +X/+Y wall skin only.

    Reuses the established half-plane partitions; default +Y calls retain all
    old faces/material/confidence. Compound skin-back includes its inset dark
    joint backing so the same blind300mm recess has actual cut reveals.
    """
'''
s=s[:a]+head+body+s[z:]
# The parameter name `axis` is consumed before the old inner clipping loop reuses
# a local axis index; normal_axis/along_axis are fixed for every door.
needle='''        if log_face:hewn_log_wall(b,*r,0.,p.wall_height_m,1.,M_LOG,M_CHINK,skip=("bottom","top"))''';assert s.count(needle)==1
s=s.replace(needle,'''        if p.compound_log_profile == "rounded_relief":
            _rounded_compound_wall(b,r,p.wall_height_m)
        elif log_face:hewn_log_wall(b,*r,0.,p.wall_height_m,1.,M_LOG,M_CHINK,skip=("bottom","top"))''')
needle='''        for face,kind,u0,u1,z0,z1 in openings_:
            axis_="x" if face=="+x" else "y";plane=r[2] if axis_=="x" else r[3]
            _opening(b,axis_,plane,u0,u1,z0,z1,1,1.,kind=kind,frame_wall=not log_face,relief=RELIEF_M if log_face else .026)''';assert s.count(needle)==1
s=s.replace(needle,'''        if p.compound_door_state == "recess":
            for face in {v[0] for v in openings_ if v[1]=="door"}:
                axis_="x" if face=="+x" else "y";plane=r[2] if axis_=="x" else r[3]
                _cut_door_recesses(b,axis_,plane,[(k,u0,u1,z0,z1) for f,k,u0,u1,z0,z1 in openings_ if f==face],skin_back_m=.30)
        for face,kind,u0,u1,z0,z1 in openings_:
            axis_="x" if face=="+x" else "y";plane=r[2] if axis_=="x" else r[3]
            _opening(b,axis_,plane,u0,u1,z0,z1,1,1.,kind=kind,frame_wall=not log_face,relief=RELIEF_M if log_face else .026,
                     door_state="recess" if p.compound_door_state=="recess" and kind=="door" else "closed")''')
needle='''    if p.compound_wall_cladding == "log_courses":
        _log_course_gable(b,"y",D,0,cw,h,z,+1)''';assert s.count(needle)==1
s=s.replace(needle,'''    if p.compound_log_profile == "rounded_relief":
        _rounded_compound_gable(b,"y",D,0,cw,h,z,+1)
        _rounded_compound_gable(b,"y",0,0,cw,h,z,-1)
        _rounded_compound_gable(b,"x",W,0,cw,h,z,+1)
    elif p.compound_wall_cladding == "log_courses":
        _log_course_gable(b,"y",D,0,cw,h,z,+1)''')
s+='''

def _rounded_log_face(b,axis,plane,u0,u1,z0,z1,outward,gable=None):
    """Small rounded relief and thin inset joints, not literal measured log fabric.

    Chosen300mm rhythm,20mm dark gap and38..48mm curved relief replace the pale
    strip proxy only on opt-in compounds. Six angular panels per log give normals
    for shading under the same light/palette; stable seeded relief avoids a perfect
    repeated board face. No historic colour/woodgrain or exact section is claimed.
    """
    course=.30;gap=.020
    def xyz(u,z,proud=0):return (u,plane+outward*proud,z) if axis=="y" else (plane+outward*proud,u,z)
    def widths(z):
        if gable is None:return u0,u1
        mid=(u0+u1)/2;half=(u1-u0)/2*(1-(z-z0)/(z1-z0));return mid-half,mid+half
    def emit(pts):
        clean=[]
        for v in pts:
            if not clean or sum((v[k]-clean[-1][k])**2 for k in range(3))>1e-20:clean.append(v)
        if len(clean)>1 and sum((clean[0][k]-clean[-1][k])**2 for k in range(3))<1e-20:clean.pop()
        if len(clean)<3:return
        reverse=(axis=="y") == (outward>0)
        b.add_poly(list(reversed(clean)) if reverse else clean,1.,M_LOG)
    for i in range(math.floor(z0/course),math.ceil(z1/course)):
        low=max(z0,i*course+gap/2);high=min(z1,(i+1)*course-gap/2)
        if high<=low:continue
        mid=(i+.5)*course;radius=(course-gap)/2
        # Identity uses the official asset key via b.name; all choices reconstructed.
        relief=.038+.010*openings.deal(f"{b.name}|rounded|{axis}|{plane:.3f}|{i}",101)/100
        theta0=math.asin(max(-1.,min(1.,(low-mid)/radius)));theta1=math.asin(max(-1.,min(1.,(high-mid)/radius)))
        for k in range(6):
            a=theta0+(theta1-theta0)*k/6;c=theta0+(theta1-theta0)*(k+1)/6
            za,zb=mid+radius*math.sin(a),mid+radius*math.sin(c);pa,pb=relief*math.cos(a),relief*math.cos(c)
            ua,va=widths(za);ub,vb=widths(zb)
            emit([xyz(ua,za,pa),xyz(va,za,pa),xyz(vb,zb,pb),xyz(ub,zb,pb)])


def _rounded_compound_wall(b,r,height):
    x0,y0,x1,y1=r
    # Dark backing is15mm behind the physical face, visible only in thin joints.
    # It is a shadow/recess proxy using the existing palette, not black painted clay.
    b.add_box(x0+.015,y0+.015,0.,x1-.015,y1-.015,height,1.,M_DARK,skip=("bottom","top"))
    for axis,plane,u0,u1,outward in [("y",y1,x0,x1,1),("y",y0,x0,x1,-1),("x",x1,y0,y1,1),("x",x0,y0,y1,-1)]:
        _rounded_log_face(b,axis,plane,u0,u1,0.,height,outward)


def _rounded_compound_gable(b,axis,plane,u0,u1,z0,z1,outward):
    mid=(u0+u1)/2;back=plane-outward*.015
    pts=[(u0,back,z0),(u1,back,z0),(mid,back,z1)] if axis=="y" else [(back,u0,z0),(back,u1,z0),(back,mid,z1)]
    reverse=(axis=="y") == (outward>0)
    b.add_poly(list(reversed(pts)) if reverse else pts,1.,M_DARK)
    _rounded_log_face(b,axis,plane,u0,u1,z0,z1,outward,gable=True)
'''
p.write_text(s)
p=H/'candidate/data/structures/wolf_point_tavern.json';r=json.loads(p.read_text());f=r['phases'][0]['form'];source='blanchard_shober_1867_wolf_point'
f['compound_door_state']={'value':'recess','confidence':'reconstructed','sources':[source],'note':'T-2386 next actual-render difference: both source entry rectangles read deep/dark/open, while the current actual L has pale closed planked leaves. Cut only their stated outward wall skins and put a blind dark backing300mm behind the face with casing/reveals/threshold. This is a bounded exterior depth proxy, not a room, inferred door swing, occupant or interior passage. Whole physicalL and solid-footprint walker collision remain unchanged, and the same explicit +X access descriptor remains external-clearance metadata.'}
f['compound_log_profile']={'value':'rounded_relief','confidence':'inferred','sources':[source],'note':'T-2386 source course faces read rounded/unevenly shaded with narrow dark recessed joints, unlike the current regular pale chink stripes. Use bounded curved face relief and inset existing-palette dark backing only on this explicit log-course compound.300mm rhythm,20mm gaps,15mm joint setback,38..48mm seeded relief and six profile panels are reconstructed rendering sections, not source-measured logs, original colour, exact weathering or a photoreal texture. Extend the same chosen profile through facing gable triangles; hidden structural fabric remains unproved and partly-frame textual evidence is retained.'}
f['compound_parts']['note']+=' T-2386 door/log-relief continuation keeps all room/opening rectangles, raised-window bounds, plan, pole and roof controls unchanged. External door leaves are now omitted only under explicit compound_door_state=recess and backed blindly at300mm; no interior geometry/passable collision is implied. Chosen curved log relief replaces the pale-strip proxy only under compound_log_profile.'
r['research_note']+=' T-2386 actual surface/pole comparison improved but still differs: this separate next proposal targets dark blind doorway recesses and curved course shading with narrow dark recessed joints, using the same camera and no global palette change. Full acceptance remains open.';p.write_text(json.dumps(r,indent=2)+'\n')
p=H/'candidate/data/sources/blanchard_shober_1867_wolf_point.json';src=json.loads(p.read_text());src['note']+=' T-2386 door/log-relief re-reading: the two entry apertures are dark/open-looking and the course faces show rounded/irregular shading with narrow dark recesses. These guide appearance categories only; no interior, literal measured cross-section, authentic colour/texture or original sign-device likeness is established.';p.write_text(json.dumps(src,indent=2)+'\n')
patch=''
for rel in rels:patch+=''.join(difflib.unified_diff((H/'baseline'/rel).read_text().splitlines(True),(H/'candidate'/rel).read_text().splitlines(True),fromfile='a/chicago/4d/'+rel,tofile='b/chicago/4d/'+rel))
(H/'door-log-relief-next.patch').write_text(patch)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(H/'inputs.json').write_text(json.dumps({'baseline_actual_run':str(R),'baseline_actual_glb_sha256':sha(H/'baseline/assets/gltf/wolf_point_tavern__log_frame_1828.glb'),'unchanged_camera_sha256':sha(H/'candidate/docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.json'),'files':[{'path':rel,'baseline_sha256':sha(H/'baseline'/rel),'candidate_sha256':sha(H/'candidate'/rel)} for rel in rels]},indent=2)+'\n');print('Prepared4-file next proposal; no heavy execution.')
