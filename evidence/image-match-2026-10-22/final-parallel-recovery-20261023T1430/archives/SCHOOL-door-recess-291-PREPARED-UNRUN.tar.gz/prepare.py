"""One-time light school data proposal, no root or heavy writes."""
from pathlib import Path
import shutil,json,hashlib,difflib,subprocess
H=Path(__file__).resolve().parent;F=Path('/tmp/chicago-next-model/log81-materializer/05f6-sourceS-final/review-tree/chicago/4d');A=Path('/tmp/chicago-next-model/log-combined/runs/20261023-050224-069556');W=Path('/tmp/chicago-next-model/T-2386-surface-pole-next/candidate');assert not (H/'candidate').exists()
# Full successful-producer support copied regularly, then school-only data selected.
for rel in ['generators','renderers']:
 shutil.copytree(W/rel,H/'candidate'/rel)
for rel in ['tools/photo_match.mjs','tools/photo_match_group.mjs','data/datum.json','data/scenes/1835.json']:
 dst=H/'candidate'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/rel,dst)
rels=['data/structures/chappel_infant_school.json','data/sources/eliza_chappel_school_shore_view.json']
for rel in rels:
 for label in ['baseline','candidate']:
  dst=H/label/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(F/rel,dst)
root='/workspace/chicago';head=subprocess.check_output(['git','-C',root,'rev-parse','HEAD'],text=True).strip()
for rel in rels:
 data=subprocess.check_output(['git','-C',root,'show',f'{head}:chicago/4d/{rel}']);dst=H/'committed-readonly'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
name='chappel_infant_school__log_1833.glb';asset=A/'proposed/assets/gltf'/name
for rel,src in [('assets/gltf/'+name,asset),('docs/RESEARCH/school-next/T-2372-school-shore.json',A/'proposed/docs/RESEARCH/log-combined-review/T-2372-school-shore.json')]:
 for label in ['baseline']:
  dst=H/label/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
cam=H/'baseline/docs/RESEARCH/school-next/T-2372-school-shore.json';dst=H/'candidate/docs/RESEARCH/school-next/T-2372-school-shore.json';dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(cam,dst)
# Keep camera/photo bytes exactly equal to the actual school comparison.
c=json.loads(cam.read_text());photo=(A/'proposed/docs/RESEARCH/log-combined-review'/c['photo']).resolve()
for label in ['baseline','candidate']:
 dst=(H/label/'docs/RESEARCH/school-next'/c['photo']).resolve();assert dst.is_relative_to(H/label);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(photo,dst)
for src,outname in [(A/'reviews/proposed/T-2372-school-shore-side-by-side.jpg','T-2372-school-shore-side-by-side.jpg')]:
 dst=H/'baseline/reviews'/outname;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
# Portable bare baseline render already retained by the old run; crop it from its
# exact source|render canvas if no bare original is available. This is a capture
# crop, not a new model render or image warp.
from PIL import Image
im=Image.open(H/'baseline/reviews/T-2372-school-shore-side-by-side.jpg');assert im.size==(1304,368);im.crop((664,0,1304,368)).save(H/'baseline/reviews/render-from-side-by-side.png')
(H/'candidate/assets/gltf').mkdir(parents=True);(H/'candidate/assets/manifest.json').write_text('{"assets":{}}\n')
# Existing complete official asset row is preserved only as baseline evidence.
m=json.loads((A/'proposed/assets/manifest.json').read_text());m['assets']={name:m['assets'][name]};(H/'baseline/assets/manifest.json').write_text(json.dumps(m,indent=2)+'\n')
p=H/'candidate/data/structures/chappel_infant_school.json';r=json.loads(p.read_text());f=r['phases'][0]['form']
f['front_door_state']={'value':'recess','confidence':'reconstructed','sources':['eliza_chappel_school_shore_view'],'note':'T-2372 next visible increment uses the owner-approved attributed school-shore reproduction as a provisional design reference. Its woman occupies a dark/open-looking doorway; the actual proposed model still has a closed planked leaf. Omit that leaf and use the existing blind300mm exterior recess with cut skin, casing, reveals and threshold. The depth and exact construction are reconstructed proxies, not an inferred room, passage, door swing or1835 occupant. Preserve all opening sizes/stations, gable-axis choice, physical footprint/placement/dates and the unknown former-school1835 use. The school/annex identification and original publication/date remain unresolved; no accepted camera or grade promotion follows.'}
r['research_note']+=' T-2372 next door-only increment replaces the actual closed-leaf proxy with an explicitly reconstructed blind exterior recess, guided by approved attributed project use of the journal reproduction. This does not stage the pictured teacher/children in1835 or identify the depicted building. Broad facade/gable surfaces, roof fabric, opening alignment, stack visibility, camera and identity/date differences remain open.';p.write_text(json.dumps(r,indent=2)+'\n')
p=H/'candidate/data/sources/eliza_chappel_school_shore_view.json';s=json.loads(p.read_text());s['note']+=' T-2372 blind-door continuation: after actual opening/roof comparison, the same owner-approved attributed image also guides a reconstructed blind dark front recess instead of the model closed leaf. No room,1835 occupant, measured depth, subject identity, original copyright/publication, accepted camera or match is asserted. All project-specific approval/hosting credit and historical limits remain.';p.write_text(json.dumps(s,indent=2)+'\n')
patch=''
for rel in rels:patch+=''.join(difflib.unified_diff((H/'baseline'/rel).read_text().splitlines(True),(H/'candidate'/rel).read_text().splitlines(True),fromfile='a/chicago/4d/'+rel,tofile='b/chicago/4d/'+rel))
(H/'school-door-recess-next.patch').write_text(patch)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(H/'inputs.json').write_text(json.dumps({'committed_read_head':head,'claim_commit':'22e019fd5b1e0591e9145ba1699f29f0341f258f','actual_proposed_baseline_run':str(A),'actual_baseline_glb_sha256':sha(asset),'same_camera_sha256':sha(cam),'source_sha256':sha(photo),'baseline_render':'lossless PNG crop of the actual JPEG side-by-side render panel; original bare PNG unavailable in this closed run; JPEG quality is retained, not reconstructed','files':[{'path':rel,'baseline_sha256':sha(H/'baseline'/rel),'candidate_sha256':sha(H/'candidate'/rel)} for rel in rels]},indent=2)+'\n')
print('Prepared school data-only recess proposal; source approval/credit retained. No heavy execution.')
