# T-2372 school doorway continuation — prepared, UNRUN

Original T-2372 is normally claimed by `school_lighthouse_castle_bridge` in tickets commit `22e019fd5b1e0591e9145ba1699f29f0341f258f`. Its complete original picture-match scope remains open. This package is a data-only continuation after the final log81 helper's larger/higher sash and doorway-gable roof increment. No app repository file, shared prototype, frozen Wolf package, ticket acceptance or canonical asset has been edited. No heavy execution has occurred.

## Actual evidence inspected

The ticket links **one building picture**, inventoried in `source-inventory.json`: the deposited 640×368 school/shore drawing reproduced in the Digital Research Library of Illinois History Journal's 2018 Eliza Chappell article. I inspected the full picture and the actual committed-before/proposed-after comparison, not only source text or a model description. The article's portrait or unrelated school pictures are not additional same-building witnesses. Earlier research rejected William Mark Young's Rumsey School plate as a different building/date; it is not silently reused.

Credit: **Artist unidentified; reproduced by the Digital Research Library of Illinois History Journal in its 2018 Eliza Chappell article**, https://drloihjournal.blogspot.com/2018/01/eliza-chappell-the-first-chicago-teacher-paid-by-public-funds-in-1833.html . T-3053 records the owner's 2026-10-22 approval for attributed project reference/comparison/display use. It establishes neither public domain, copyright-holder permission, nor an open redistribution licence. The candidate changes only the source's design-reading note and preserves every citation, credit, rights ruling/date and `verified: false` value.

The subject's identification remains disputed: the modern caption gives Clark/Lake (the school's 1834 destination), while the picture depicts a log house on a shore. The unknown artist/date and the possibility of a Sauganash-annex subject remain unresolved. Existing source research found a composed scene with inconsistent figure perspective; the lighthouse's foot is absent. Neither tower, horizon, figures nor drawn house yield surveyed coordinates or metres. Chappell's school left this log building in1834; its1835 occupancy/use is unknown. No pictured teacher, child or Indigenous canoe scene is newly staged here.

## Actual remaining differences and next choice

The old actual render's roof-axis and larger/higher sash are a visible first improvement. The school still differs: the modeled frontage is much broader in the provisional framing; the gable triangle is a plain roof-colored cap instead of the drawing's continuing horizontal logs; openings remain imperfect in height/spacing; roof shakes/shingles are absent; log/chink rhythms and tones differ; a rear stack is visible in the model but not established by this cropped source; source ground, people and setting are absent. Camera, historical identity and date remain unresolved. These are live original-ticket differences, not acceptance exemptions.

This next **single bounded choice** replaces the pale closed planked front leaf with the existing `front_door_state: recess` option. The picture's woman occupies a dark/open-looking doorway. A cut skin, surround/returns/threshold and dark back **0.30 m** inside provide a reconstructed exterior proxy. Depth, joinery and material are chosen model details, emitted at reconstructed confidence1.0. No unseen room, interior passage, historical door swing,1835 occupant, texture transfer or attested colour is asserted. Solid-footprint collision and walker behavior remain unchanged. No dimensions/stations, roof, physical polygon, placement, dates, grade or camera change.

`school-door-recess-next.patch` changes exactly school structure + source note. `LIBERTY-APPEND.md` adds one entry and one precise Cover, `chappel_infant_school.log_1833.form.front_door_state`. The note-reader path already exists in final log81; retain it, never hide the note. No new name, source ID or global generator field is introduced.

## Composition and blast radius

Use **selectively after** `/tmp/chicago-next-model/log81-materializer/05f6-sourceS-final` (including school opening/roof-axis, Miller visible joints, latest Hogan overlay), preserving independent root/source edits and current Hogan values. Rebase the two JSON changes by field/note append if their guarded whole-file hashes differ; do not replace a new record/source from an old snapshot. Candidate/baseline producer trees are copied execution support, **not code changes to adopt**. Their later Wolf options are disabled for this school; actual raw geometry with those options disabled is exactly equal to the earlier actual school's producer. Identical common module bytes are checked. Baseline and candidate source/structure are schema-checked. Door-back ray lands at localY5.186m, dark material, confidence1.0; adjacent skin remains. Existing footprint collision is unchanged.

As a standalone data-only change this invalidates **one** master (`chappel_infant_school__log_1833.glb`) and its web derivative. The parent's integrated shared log-family controls still require the planned official **81-asset** canonical rebake/freshness proof, correct `structure_id__phase_id` seed, provenance/Covers/namepool compilation, downstream consumers, full gates and app QA. This package does not claim to have performed those duties or to close an original match case. Keep source-specific camera/grade rulings honest; no acceptance/reference-view enrollment follows.

## Portable frozen baseline and future one-capture runner

`baseline/` preserves the prior actual proposed school's master and manifest row, full actual JPEG side-by-side, and unchanged camera. Its original bare render PNG was unavailable: `render-from-side-by-side.png` is a lossless PNG encoding of the decoded JPEG's render-panel pixels (x664..1304,y0..368), retaining JPEG quality, **not the byte-original screenshot**. Keep the original full JPEG and disclose this limitation. `committed-readonly/` records the captured committed HEAD school/source (from git show, not parent's dirty working values); it is not the after-comparison baseline. `inputs.json` binds their identities.

`candidate/` is regular copied producer/viewer support with no GLB and an empty manifest. The camera is byte-identical to the actual combined baseline, SHA `f27c15662193f6ec14948df59bd4c5deb90629d0ec6219dfed39a8dc70a95097`: eye[-10,80,2.625], yaw169.613672°, focal2050px, principal[566,215], overcast. These are reconstructed framing choices; square pixels and the distant horizon are not solved metric controls. Do not change camera to make this increment pass. Keep it in research, not accepted `data/reference_views`.

Light recheck (safe without heavy grant):

```sh
python3 /tmp/chicago-next-model/T-2372-door-recess-next/run_next.py
```

Only after parent's explicit shared heavy-slot grant:

```sh
python3 /tmp/chicago-next-model/T-2372-door-recess-next/run_next.py --execute-after-root-grant --grant-note 'Root granted the bounded school blind-door comparison'
```

The runner checks all frozen candidate/baseline hashes and focused contracts, uses cached pinned Blender4.5.3 and the actual copied **absolute** build.py path, official `chappel_infant_school__log_1833` seed, requests exactly **one** new export/capture and compares with the preserved actual baseline. It checks generated manifest/input hash, decoded GLB contracts/triangles and photo/camera/master bindings; it assembles an identical unwarped source/before/after crop. It leaves the new image gate `unreviewed`. Inspect full source and actual after comparison/detail before recording any verdict; all known differences mean `differs` is expected. No automatic match. Close browser/server/processes and notify root CLEAR promptly. Never run concurrent heavy work without coordination.

Runtime-only external dependencies: existing `/workspace/shared/blender-dl` pinned archive/binary (SHA975c58fcb244273838534bba771e64ad87739216b0f9b39a888531a49a72d845), `/workspace/node_modules`, `/usr/bin/chromium`, Python jsonschema and Pillow. No live checkout reads, install, publisher, site/terrain/props or canonical write. `prepare.py`/`finish_support.py` are one-time preparation provenance, **not portable recovery entry points**; all final required runtime inputs are in this package. `ARTIFACTS.json` covers all author files except itself and future runtime outputs; future `runs/` and `latest-run.txt` are excluded. Initial state is UNAPPLIED/UNRENDERED.
