"""Explicit grant only: one new export/capture against the frozen actual proposed school baseline."""
from pathlib import Path
import sys,json,hashlib,shutil,subprocess,datetime,os,signal,argparse
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--execute-after-root-grant',action='store_true');ap.add_argument('--grant-note');a=ap.parse_args()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
snapshot=json.loads((H/'snapshot.json').read_text())
for label in ['candidate','baseline']:
 for rel,want in snapshot[label].items():
  p=H/label/rel;assert p.is_file() and not p.is_symlink() and sha(p)==want,(label,rel,'input drift')
subprocess.run([sys.executable,str(H/'check_light.py')],check=True)
subprocess.run([sys.executable,str(H/'check_liberty.py')],check=True)
if not a.execute_after_root_grant:
 print('PREPARED ONLY. No Blender/browser launched; root heavy-slot grant required.');raise SystemExit(0)
if not a.grant_note:ap.error('--grant-note must record the explicit parent heavy-slot grant')
pin={}
for line in (H/'candidate/generators/blender.pin').read_text().splitlines():
 if line.startswith('BLENDER_'):k,v=line.split('=',1);pin[k]=v
archive=Path('/workspace/shared/blender-dl')/pin['BLENDER_URL'].split('/')[-1];binary=archive.parent/pin['BLENDER_DIR']/'blender'
assert archive.is_file() and sha(archive)==pin['BLENDER_SHA256'],'Pinned existing cache missing/drifted; no network install/fallback'
version=subprocess.check_output([str(binary),'--version'],text=True).splitlines()[0];assert version.split()[1]==pin['BLENDER_VERSION']
mods=Path('/workspace/node_modules').resolve();assert mods.is_dir()
run=H/'runs'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S-%f');run.mkdir(parents=True)
receipt={'status':'running','grant_note':a.grant_note,'camera_unchanged_sha256':snapshot['camera_sha256'],'source_sha256':snapshot['source_sha256'],'snapshot_sha256':sha(H/'snapshot.json'),'baseline_actual_glb_sha256':snapshot['baseline_glb_sha256'],'baseline_actual_image_gate':'differs from closed school combined review','baseline_render_quality':'PNG crop preserves decoded JPEG comparison pixels; original bare PNG unavailable','new_image_gate':'unreviewed','producer':'actual copied official build.py/emit, structure_id__phase_id seed','exports_requested_this_run':1,'captures_requested_this_run':1,'Blender':version,'archive_sha256':sha(archive),'live_checkout_inputs':False,'stale_props_context_rendered':False,'stages':[]}
def save():(run/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def command(argv,cwd,log,timeout):
 save()
 with log.open('w') as out:
  p=subprocess.Popen(argv,cwd=cwd,stdout=out,stderr=subprocess.STDOUT,start_new_session=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PW_EXECUTABLE':'/usr/bin/chromium'})
  try:p.wait(timeout=timeout)
  except BaseException:
   try:os.killpg(p.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    p.wait()
   raise
 if p.returncode:raise RuntimeError(f'Command failed{p.returncode}: {log}')
try:
 root=run/'after';shutil.copytree(H/'candidate',root);(root/'node_modules').symlink_to(mods,target_is_directory=True)
 assert not list((root/'assets/gltf').glob('*.glb'))
 before=run/'before';shutil.copytree(H/'baseline',before)
 photo_rel='data/sources/assets/21617595_10203558686525015_5452300313452439832_n.jpg';(before/photo_rel).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/photo_rel,before/photo_rel)
 review_before=run/'reviews/before';review_before.mkdir(parents=True)
 shutil.copyfile(H/'baseline/reviews/render-from-side-by-side.png',review_before/'render.png')
 shutil.copyfile(H/'baseline/reviews/T-2372-school-shore-side-by-side.jpg',review_before/'T-2372-school-shore-side-by-side.jpg')
 command([str(binary),'-b','-noaudio','--factory-startup','--python',str(root/'generators/build.py'),'--','--only','chappel_infant_school','--scene','1835','--wrote',str(root/'wrote.txt')],root,root/'export.log',600)
 command([sys.executable,str(H/'verify_export.py'),str(root),'after'],root,root/'contract.log',60)
 receipt['stages'].append({'new_export_contract':'passed','new_glb_sha256':sha(root/'assets/gltf/chappel_infant_school__log_1833.glb')});save()
 camera=root/'docs/RESEARCH/school-next/T-2372-school-shore.json';reviews=run/'reviews/after';reviews.mkdir(parents=True)
 command(['node','tools/photo_match.mjs',str(camera),'--out',str(reviews)],root,root/'photo-match.log',600)
 paths=[Path(x.strip()) for x in (root/'photo-match.log').read_text().splitlines() if x.strip().endswith('-render.png')];assert len(paths)==1 and paths[0].is_relative_to('/tmp')
 shutil.copyfile(paths[0],reviews/'render.png')
 m=json.loads(camera.with_suffix('.match.json').read_text());assert m['verdict']=='unreviewed' and m['photo_sha256']==snapshot['source_sha256'] and m['camera_sha256']==snapshot['camera_sha256'] and m['glb_sha256']==sha(root/'assets/gltf/chappel_infant_school__log_1833.glb')
 receipt['stages'].append({'new_capture':'passed','source_side_by_side_sha256':sha(reviews/'T-2372-school-shore-side-by-side.jpg'),'render_sha256':sha(reviews/'render.png')})
 command([sys.executable,str(H/'assemble_detail.py'),str(run)],H,run/'detail.log',60)
 for rel,want in snapshot['candidate'].items():
  if rel=='assets/manifest.json':continue
  assert sha(root/rel)==want,(rel,'frozen input changed')
 receipt['status']='completed_one_new_actual_export_capture_UNREVIEWED';receipt['limits']='Actual images require direct review; original T2372 all-picture acceptance remains. Building-only plane excludes world/site/props/terrain/interior; no subject/date/metric resolution. Eventual shared-family canonical all81 refresh, gates and appQA owed; isolated data-only change affects one asset.'
 save();(H/'latest-run.txt').write_text(str(run)+'\n');print(run)
except BaseException as exc:
 receipt['status']='FAILED';receipt['error']=str(exc);save();raise
