"""Focused raw geometry/data contracts only; no Blender/browser."""
from pathlib import Path
from types import ModuleType
from dataclasses import asdict
import sys,json,hashlib,ast
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;N=H/'candidate';O=H/'baseline';key='chappel_infant_school__log_1833'
sys.path.insert(0,str(N/'generators'));sys.modules['bpy']=ModuleType('bpy')
def load(n,path):
 m=ModuleType(n);m.__file__=str(path);sys.modules[n]=m;exec(compile(path.read_text(),str(path),'exec'),m.__dict__);return m
op=load('school_old_params',O/'generators/archetypes/log_dwelling_params.py');np=load('school_new_params',N/'generators/archetypes/log_dwelling_params.py')
sys.modules['archetypes.log_dwelling_params']=op;old=load('school_old_mesh',O/'generators/archetypes/log_dwelling.py');sys.modules['archetypes.log_dwelling_params']=np;new=load('school_new_mesh',N/'generators/archetypes/log_dwelling.py')
assert all(p.read_bytes()==(N/'generators/common'/p.relative_to(O/'generators/common')).read_bytes() for p in (O/'generators/common').rglob('*.py'))
from common.mesh import MeshBuilder
class Raw(MeshBuilder):
 def to_object(self,materials=None):self.materials=materials;return self
for m in [old,new]:m.MeshBuilder=Raw;m.simple_material=lambda *a,**kw:(a,kw)
def raw(v):return (v.verts,v.faces,v.conf,v.mat_index,v.named,v.materials)
b=json.loads((O/'data/structures/chappel_infant_school.json').read_text());r=json.loads((N/'data/structures/chappel_infant_school.json').read_text());p=np.from_phase(r['phases'][0],r);off=np.from_phase(b['phases'][0],b);prior=op.from_phase(b['phases'][0],b)
assert p.front_door_state=='recess'
x=asdict(p);y=asdict(off);assert {k for k in x if x[k]!=y[k]}=={'front_door_state','confidence'}, {k for k in x if x[k]!=y[k]}
assert raw(old.build(prior,key))==raw(new.build(off,key)), 'Existing actual baseline differs with newer disabled controls'
# Reconstructing the door must not alter any physical/historical value.
copy=json.loads(json.dumps(r));copy['phases'][0]['form'].pop('front_door_state');copy['research_note']=b['research_note'];assert copy==b
bs=json.loads((O/'data/sources/eliza_chappel_school_shore_view.json').read_text());ns=json.loads((N/'data/sources/eliza_chappel_school_shore_view.json').read_text());s=dict(ns);s['note']=bs['note'];assert s==bs
assert ns['rights_status']=='cleared' and ns['verified'] is False and ns['rights_checked']==bs['rights_checked']
assert 'public-domain determination' in ns['rights_note'] and 'Artist unidentified' in ns['rights_note']
import jsonschema
jsonschema.validate(r,json.loads((H/'structures.schema.json').read_text()));jsonschema.validate(ns,json.loads((H/'source.schema.json').read_text()))
built=new.build(p,key);baseline=new.build(off,key);assert raw(built)!=raw(baseline)
# Ray into the doorway: project polygon into X/Z; intersection returns outermostY.
def inside(poly,x,z):
 yes=False
 for a,b in zip(poly,poly[1:]+poly[:1]):
  if (a[1]>z)!=(b[1]>z) and x<(b[0]-a[0])*(z-a[1])/(b[1]-a[1])+a[0]:yes=not yes
 return yes
def hits(mesh,x,z):
 result=[]
 for i,face in enumerate(mesh.faces):
  v=[mesh.verts[k] for k in face]
  if max(t[1] for t in v)-min(t[1] for t in v)<1e-8 and inside([(t[0],t[2]) for t in v],x,z):result.append((v[0][1],mesh.mat_index[i],mesh.conf[face[0]]))
 return sorted(result)
door=hits(built,3.658,1.);assert door and abs(door[-1][0]-(5.486-.30))<1e-8 and door[-1][1]==new.M_DARK and door[-1][2]==1.,door
adj=hits(built,2.8,1.);assert adj[-1][0]>5.486-.15,adj
cam=Path('docs/RESEARCH/school-next/T-2372-school-shore.json');assert (N/cam).read_bytes()==(O/cam).read_bytes()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inputs=json.loads((H/'inputs.json').read_text());assert sha(N/cam)==inputs['same_camera_sha256']
photo=(N/cam).parent/json.loads((N/cam).read_text())['photo'];assert sha(photo)==inputs['source_sha256']
assert sha(O/'assets/gltf'/f'{key}.glb')==inputs['actual_baseline_glb_sha256']
# This package changes data only. Shared producer copies are execution support, not a new module proposal.
report={'status':'PASSED_LIGHT_ONLY_UNRENDERED','actual_old_producer_school_raw_defaults_exact':True,'official_seed':key,'data_only_one_new_form_attribute':'front_door_state=recess','all_other_record_values_unchanged':True,'source_only_note_append_credit_rights_unchanged':True,'source_and_structure_schemas':'passed','door_blind_back_y':door[-1][0],'door_back_material':door[-1][1],'door_back_confidence':door[-1][2],'unchanged_solid_physical_polygon':True,'same_actual_camera_sha256':sha(N/cam),'actual_baseline_master_sha256':inputs['actual_baseline_glb_sha256'],'triangles':sum(len(f)-2 for f in built.faces),'vertices':len(built.verts),'not_a_global_code_change':True,'limits':'No new GLB/render/acceptance. Footprint collision remains solid; no interior or walker passage. All81 replay belongs to eventual shared log-family integration, not this isolated data-only overlay.'}
(H/'light-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
