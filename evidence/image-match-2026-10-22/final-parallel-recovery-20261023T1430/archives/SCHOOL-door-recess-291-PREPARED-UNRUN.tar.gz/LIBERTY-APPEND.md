### L-school-dark-door-recess-2372 — a dark blind exterior doorway

**Decision:** The actual school-shore comparison still shows a closed pale planked leaf where the picture has a dark doorway occupied by a woman. The model now opts into the existing `front_door_state: recess` treatment. Its cut front skin, framed reveals, threshold and dark back 0.30 m inside are reconstructed visual proxies. This does not infer an interior, passage, door swing, historical leaf position, or 1835 occupant. Solid footprint collision and the walker contract remain unchanged. No source pixels become a texture.

**Source:** `eliza_chappel_school_shore_view`. Artist unidentified; reproduced by the Digital Research Library of Illinois History Journal in its 2018 Eliza Chappell article, https://drloihjournal.blogspot.com/2018/01/eliza-chappell-the-first-chicago-teacher-paid-by-public-funds-in-1833.html . The owner approved attributed project reference/comparison/display use on 2026-10-22 (T-3053). This is not a public-domain determination, copyright-holder grant or general open licence. The subject, original artist/publication/date, school/annex identification and historical camera remain unresolved.

**Bounds:** Preserve the proposed roof-axis/opening values, footprint, position, dates, inferred building grade and unknown 1835 use. The school had left this building in 1834. The drawing's broader scene is composed, not a metric construction. Broad facade, plain gable triangle, roof covering, opening alignment, chinking/tones, unestablished rear stack and camera remain different. Rebuild and inspect the actual same-camera comparison before judging this increment. T-2372 retains its full original acceptance and remains open; this proposal is unrendered.

**Covers:** `chappel_infant_school.log_1833.form.front_door_state`.
**Ticket:** T-2372.
**Recorded:** 2026-10-23.
