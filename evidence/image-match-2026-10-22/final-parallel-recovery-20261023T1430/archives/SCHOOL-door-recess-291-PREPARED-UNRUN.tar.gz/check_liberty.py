from pathlib import Path
from types import ModuleType
import json,ast,sys
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;S=H/'contract-support';sys.path.insert(0,str(S))
def load(n,p):
 m=ModuleType(n);m.__file__=str(p);sys.modules[n]=m;exec(compile(p.read_text(),str(p),'exec'),m.__dict__);return m
lib=load('school_liberty_compiler',S/'compile_liberties.py');names=json.loads((S/'structure-names.json').read_text());entries,errors=lib.parse('## Per-subject liberties\n\n'+(S/'prior-log81-liberties.md').read_text(),names,sources={});assert not errors,errors
new,errors=lib.parse('## Per-subject liberties\n\n'+(H/'LIBERTY-APPEND.md').read_text(),names,sources={});assert not errors and len(new)==1 and len(new[0]['covers'])==1,errors
ledger=json.loads((S/'liberties.json').read_text());ledger['liberties']+=entries+new
nodes=[n for n in ast.parse((S/'validate.py').read_text()).body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in {'Report','graded_values','inferred_values','unbuilt_values','check_liberties_coverage'}]
ns={'PHASE_ASPECTS':('footprint','position','documented_range'),'STRUCTURE_ASPECTS':('function','occupants','present_status','built'),'GEOMETRY_OWES_LIBERTY':('absent','simplified')};exec(compile(ast.Module(body=nodes,type_ignores=[]),'actual_liberty_contract','exec'),ns)
p=load('school_liberty_params',H/'candidate/generators/archetypes/log_dwelling_params.py');r=json.loads((H/'candidate/data/structures/chappel_infant_school.json').read_text());rep=ns['Report']();ns['check_liberties_coverage']({r['id']:r},ledger,rep,{'log_dwelling':p.CONSUMED},forward_only=True);assert not rep.errors,rep.errors
out={'status':'passed_light_only','new_entries':1,'new_precise_covers':1,'actual_forward_coverage_errors':0,'note_reader':'phases[].form.front_door_state.note is already required by frozen log81 helper; retain it at integration','limits':'Copied actual parser/coverage functions, not canonical compiler/gates.'};(H/'liberty-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
