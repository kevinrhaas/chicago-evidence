# Next bounded Lake House comparison — prepared, not executed

## Existing actual evidence, reopened

The preserved fort fixture has pinned Blender4.5.3 exports and fixed 800×640
neutral-ground diagnostic views. `PRESERVED-DIAGNOSTICS.json` keeps both actual
review records including full GLB hashes, bounds, camera positions and paths.
The baseline and proposed oblique and proposed overhead images were reopened
visually for this handoff. The baseline is a fully covered rectangular box; the
proposal visibly opens the existing24×15m footprint to ground below its4m walls.
The oblique/overhead views show the interior faces and ground cleanly at these
stands. They do not establish hidden construction details, real wall thickness,
excavation, July1835 progress or the published app's material/ground behavior.

Fixed existing cameras, Blender GLB axes:

- overhead: position(12,7.5,42), target(12,7.5,0), lens40mm;
- oblique: position(40,-25,25), target(12,7.5,2), lens45mm.

These are engineering diagnostic cameras, not a solve of the print. Preserve
both exactly across the official before/after build. Do not rename them source
cameras or install them into accepted `data/reference_views`.

## Next roof trial, bounded

1. Parent composes only the previously reviewed `_roof` none/flat split through
   `/tmp/chicago-next-model/fort-selective-integration`, preserving its guarded
   keyword-only API and all separate fort/lighthouse/gallery/cupola additions.
2. Official pinned25-family bake and corresponding derivatives/manifests, actual
   recipe hashes and sidecars. The earlier fixture GLB hash is not proof of the
   final recipe; never restamp a current input hash onto the older export.
3. Reuse the two fixed diagnostic cameras on the official GLB. Compare open
   interior/wall edges, all four exterior faces including the door face, ground
   and app camera backface behavior. Retain existing position, footprint, storey,
   wall height, masonry and chimney values. Roof absence remains reconstructed.
4. Actual desktop and390×780 app card/scene checks, no page errors; review the
   later-print contextual link and concise date caveat. Full preflight remains
   parent-owned. Do not declare image matches from these diagnostics.

## Phase-aware print camera plan

The ticket's actual print depicts a finished hotel in a later setting, not a
construction photograph. A source-camera trial must retain the full original
image and its occluding fort/lighthouse/boat context and separately identify
which background block is the hotel before assigning metric model points. Do
not infer a completed-hotel roof or cupola solely from a filename or uncited
recognition; label all manual picks, attribution, uncertainty and occlusions.

A common-camera feasibility pass may use independently placed fort/lighthouse
controls as controls, never use this retrospective tier5 picture to move them.
Record residuals/held-out points and drawing inconsistency; do not assume a
single metrically exact lens. A shell-only overlay on that camera can document
the **expected epoch difference**, but cannot turn the later completed hotel's
storeys/openings/roof into July1835 requirements or produce a matches verdict.

No new completed-hotel phase is authorized by this proposal. If a later dated
phase is added under its own reviewed scope, its source-camera gate can compare
the completed hotel then. For July1835 the June10 newspaper is contemporary
text, not an image: absent a date-correct construction view, retain the honest
picture-phase mismatch and source adjudication. Exact progress, dimensions,
hidden interior and excavation stay disclosed as reconstruction.

No new render, browser, Blender or heavy job was run for this plan.
