from pathlib import Path
import sys,json,copy,hashlib
import jsonschema
ROOT=Path('/workspace/chicago/chicago/4d');OUT=Path(__file__).parent;PROP=OUT/'proposed/chicago/4d';sys.path[:0]=[str(ROOT/'tools'),str(ROOT/'generators')]
import mesh_inputs,compile_pictures as cp,grade_structures as gs,compile_source_use as cs
sid='lake_house_construction';sourceid='kellogg_1856_lake_house'
a=json.loads((ROOT/'data/structures'/f'{sid}.json').read_text());b=json.loads((PROP/'data/structures'/f'{sid}.json').read_text());s=json.loads((PROP/'data/sources'/f'{sourceid}.json').read_text())
jsonschema.validate(b,json.loads((ROOT/'data/structures.schema.json').read_text()));jsonschema.validate(s,json.loads((ROOT/'data/source.schema.json').read_text()))
x=copy.deepcopy(a);y=copy.deepcopy(b)
for r in [x,y]:r.pop('research_note');r['phases'][0].pop('change_note');r['phases'][0]['documented_range'].pop('note');r['function'].pop('note')
assert x==y
assert mesh_inputs.structure_inputs_sha(a,a['phases'][0])==mesh_inputs.structure_inputs_sha(b,b['phases'][0])
sources={p.stem:json.loads(p.read_text()) for p in (ROOT/'data/sources').glob('*.json')};oldpics=cp.derive(None,'',sources,{sid:json.dumps(a)},{'1835':[sid]}, {})['1835']['by_structure'].get(sid,[])
sources[sourceid]=s;newpics=cp.derive(None,'',sources,{sid:json.dumps(b)},{'1835':[sid]}, {})['1835']['by_structure'].get(sid,[])
entry=next(e for e in newpics if e['id']==sourceid);assert entry['title'].startswith('[Later hotel, not 1835]')
rulings=json.loads((ROOT/'data/structure_grades.json').read_text());cams=[]
g0=gs.grade_structure(sid,a['phases'][0]['documented_range']['confidence'],oldpics,cams,rulings,'1835');g1=gs.grade_structure(sid,b['phases'][0]['documented_range']['confidence'],newpics,cams,rulings,'1835');assert g0==g1
indexpath=ROOT/'data/sidecars/1835/sources/index.json';raw=indexpath.read_bytes();idx=json.loads(raw);c=cs.Compiler(ROOT)
# Compose the requested T2378 exact-source correction in memory; no writes.
kinzie=json.loads(Path('/tmp/chicago-next-model/T-2378-primary-20261023/proposed/chicago/4d/data/sources/kinzie_1857_chicago_1831_panorama.json').read_text());krow=next(x for x in idx['sources'] if x['source_id']==kinzie['id']);krow['citation']=c.say(kinzie['citation']);krow['date']=kinzie['date']
idx['sources']=[r for r in idx['sources'] if r['source_id']!=sourceid]
idx['sources'].append({'source_id':sourceid,'citation':c.say(s['citation']),'type':s['type'],'date':s['date'],'tier':s['tier'],'use':'unused','counts':{'claims':0,'entities':0,'grades':[[0,0,0],[0,0,0]]},'has_archive_link':False});idx['sources'].sort(key=lambda x:x['source_id'])
new=cs.packed(idx).encode();assert len(new)<=cs.INDEX_BUDGET,(len(new),cs.INDEX_BUDGET)
print('PASS: real schemas; only 4 prose fields changed; all existing dimensions, form values, confidences and placement remain identical.')
print('PASS: unchanged mesh-input SHA',mesh_inputs.structure_inputs_sha(b,b['phases'][0]))
print('PASS: actual Photos compiler provides clearly later-state contextual link; grade unchanged',g1)
print('PASS: combined in-memory compact index estimate',len(raw),'->',len(new),'cap',cs.INDEX_BUDGET,'headroom',cs.INDEX_BUDGET-len(new))
print('This is a combined row-size estimate, not full rederive/app QA. Requires the shorter T2378 source row; no cap change.')
