# T-2379 later-picture context and chronology repair — unapplied

`T-2379-context.patch` is a valid three-file source/structure/dossier diff,
checked by `git apply --check`. It adds a clearly labeled later-hotel image link
and makes the card state the contemporary June10 construction notice first.
It corrects the word “frame” to “building”: the notice does not specify fabric.
All existing geometry values, confidences, mesh inputs and placement remain
identical. The separately proposed none/flat roof correction is untouched.

`check.py` runs only focused read-only schema/primitive metadata checks.
`validation.txt` records actual Photos compiler, unchanged inferred grade/mesh,
and compact-index estimate. Compact source citation is deliberately concise;
full lithograph title, attribution, catalogue basis and temporal limits remain
in the full source notes. New source is a credited NYPL holder link, not a
newly acquired licensed image. A fresh NYPL fetch returned only an Incapsula
challenge; the proposal explicitly uses the existing inventory attribution.

**Budget dependency:** this added source fits only with the shorter T2378
exact-publication source row also proposed. Combined index estimate167979B,
21B headroom under unchanged168000B. Parent must rederive the actual combined
candidate and guard this tight bound; no ceiling increase is proposed.

The source transcript and extracted c001 were read at their exact issue-page2,
column5, lines1658–1684. Original scan is not in checkout; the publication source
record says owner-local PDFs. Bracketed supplies and transcription-mediated
status remain. No scan-read confirmation or grade promotion is claimed.

`CAMERA-AND-ROOF-TRIAL.md` and `PRESERVED-DIAGNOSTICS.json` preserve the existing
actual pinned roof diagnostics and next official-bake/camera plan. No new
render or browser job was run. The finished-hotel picture is not backdated and
cannot demonstrate a July1835 construction match. Parent owns canonical edits,
full25 bake/derivatives, card QA, preflight, PRs and eventual ticket decisions.
