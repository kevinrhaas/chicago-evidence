from pathlib import Path
import json,difflib,hashlib
root=Path('/workspace/chicago'); out=Path(__file__).parent; prop=out/'proposed'
sourceid='kellogg_1856_lake_house'
source={
'id':sourceid,'type':'illustration',
'citation':'[Later hotel, not 1835] Kellogg/Blanchard print (1856).',
'author':'E. B. & E. C. Kellogg, lithographers, for Rufus Blanchard','date':'1856','describes_date':'circa 1836–1849',
'repository':'New York Public Library, I. N. Phelps Stokes Collection of American Historical Prints',
'url':'https://digitalcollections.nypl.org/items/510d47d9-7d36-a3d9-e040-e00a18064a99',
'locator':'The committed image chicago/reference/images/chicago/chicago_fort_dearborn_river_mouth_1830.jpg, 1600 by 1131 pixels. The completed Lake House appears behind the foreground fort/lighthouse group; the filename is not a scene date.',
'tier':5,'rights_status':'public_domain','asset_use':'cross_check','verified':True,
'rights_note':'The committed IMAGE_SOURCES.md inventory credits NYPL and its public-domain statement; the lithograph was published in 1856. No licensed Granger reproduction is acquired or authorized here.',
'access_notes':'The actual committed image and IMAGE_SOURCES.md catalogue entry were reopened and read on 23 October 2026. A fresh NYPL URL request returned only a 212-byte Incapsula challenge, not a readable catalogue record; no fresh catalogue verification is claimed. This source preserves the existing inventory attribution rather than inferring it from the filename.',
'note':'Full title: Old Fort Dearborn, erected at the mouth of Chicago River for defence against the Indians. Tinted lithograph published in 1856. This later view depicts a finished hotel, not the July 1835 building site. It is provided as explicitly dated contextual evidence and as the ticket’s actual picture, not as attestation of the chosen roofless construction phase. The Chicago Democrat notice of 10 June 1835 is text evidence of active building three weeks before the scene date, not a photograph and not proof of progress, wall height, dimensions, roof absence or finished openings. Do not backdate this print’s completed storeys, roof, cupola, glazing, chimneys or grounds. No camera or pictured-grade ruling is established.',
'what_it_supplies':['the actual later-state picture named by the Lake House matching ticket','a view including the completed Lake House in the circa 1836–1849 fort setting, according to the committed catalogue inventory','a credited holder link clearly distinguished from scene-date construction evidence'],
'what_it_does_not_supply':['the state of the building site on 1 July 1835','a surveyed coordinate, metric dimension or calibrated camera','a construction-stage roof, wall-height, storey, opening or material-progress attestation','proof that a finished hotel image can close the unfinished-phase image gate']}
paths={}
p='chicago/4d/data/sources/'+sourceid+'.json';paths[p]=('',json.dumps(source,ensure_ascii=False,indent=2)+'\n')
p='chicago/4d/data/structures/lake_house_construction.json';old=(root/p).read_text();d=json.loads(old)
phase=d['phases'][0]
phase['documented_range']['note']='A contemporary notice establishes active building in Kinzie’s Addition on 10 June 1835, three weeks before the scene date: Chicago Democrat, Vol. II No. 8, issue page 2 column 5, claim chicago_democrat_1835_06_10#c001. The reading remains transcription-mediated with bracketed supplies; it gives no groundbreaking day or construction progress. The retained 1835-01-01 lower bound is not a known start date. The older discussion below identifies a separate attribution problem in modern compilations; it no longer describes the only evidence for the scene-year site.\n\n'+phase['documented_range']['note'].replace('because it is the only thing that puts this structure in the scene at all.','because those two modern paragraphs cannot establish a groundbreaking date by themselves.')
phase['change_note']='A hotel is under construction here: the Chicago Democrat reported it building in Kinzie’s Addition on 10 June 1835, three weeks before the scene. The exact progress on 1 July remains unknown. The scene keeps its reconstructed one-storey brick shell and existing dimensions; roof, walls and hidden interior details have not been established from a construction picture. The linked later lithograph shows the completed hotel and does not attest this phase.'
d['research_note']='CURRENT CONSTRUCTION AND PICTURE LIMIT — T-2379. The Chicago Democrat of 10 June 1835, Vol. II No. 8, issue page 2 column 5, claim chicago_democrat_1835_06_10#c001, reports “There is [a] new house building in Kinzie’s addition [to be] named we understand, the Lake Hous[e].” The claim is transcription-mediated; bracketed supplies are retained. This is contemporary evidence of an active site three weeks before 1 July, but does not date the start or specify walls, roof, footprint, storeys or excavation. The record’s existing shell dimensions and form remain unchanged and reconstructed/inferred where already declared. The later finished-hotel picture ('+sourceid+'; chicago/reference/images/chicago/chicago_fort_dearborn_river_mouth_1830.jpg) is catalogued circa 1836–1849 despite its filename. It is contextual only: no completed roof, cupola, upper storeys or openings are transferred to July 1835, and no camera, pictured-grade ruling or match verdict is established.\n\nHISTORICAL RESEARCH RECORD — the older chronology below predates adoption of the June 10 notice. Its statement that modern compilations are the only scene-year evidence is superseded by the contemporary notice above; its construction-progress and retrospective-street cautions remain.\n\n'+d['research_note']
d['research_note']=d['research_note'].replace('\u0002','"')
d['function']['note']=d['function']['note'].replace('an unfinished frame that people are calling the Lake House','an unfinished building that people are calling the Lake House')
paths[p]=(old,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
p='chicago/4d/docs/RESEARCH/lake_house_construction.md';old=(root/p).read_text()
insert='''## Current scene-year evidence and picture limit — T-2379, 23 October 2026

The Chicago Democrat, **10 June 1835**, Vol. II No. 8, **issue page 2 column 5**,
claim `chicago_democrat_1835_06_10#c001`, reports:

> There is [a] new house building in Kinzie's addition [to be] named we understand,
> the "Lake Hous[e]."

This notice is contemporary evidence of construction three weeks before 1 July.
It supersedes the older claim below that modern compilations supply the only
scene-year evidence. It does not date the groundbreaking or show how much had
been built. The committed claim remains `reading: transcription_mediated` and
its bracketed supplies remain: the archival transcript and extracted claim were
read, **not the unavailable original page scan**. Source PDFs are owner-local
and absent from this checkout; no scan confirmation or confidence upgrade is claimed.
The source transcript locator is issue page2 / PDF page22 / column5, lines1658–1684.

The actual ticket picture, `chicago_fort_dearborn_river_mouth_1830.jpg`, is the
Kellogg/Blanchard lithograph published1856 and catalogued circa1836–1849. Its
finished Lake House is reachable through the contextual illustration source
`kellogg_1856_lake_house`. It cannot establish the roof,
storeys, windows or worksite progress of July1835. No completed features are
backdated. The existing roofless-shell correction is separately proposed and
still requires the official fort-family bake and actual app review.

The historical sections below are retained with this correction: the two
compilations are not the only scene-year witnesses; Bonnell is not the earliest
dated construction notice now held. Exact progress and dimensions remain unknown.
No accepted camera, rendered match, or ticket completion is established here.

'''
new=old.replace('## 1. What Andreas actually says',insert+'## 1. What Andreas actually says',1)
new=new.replace('**Everything about the finished building\nis documented and nothing at all about its state on 1 July 1835 is**','**The finished building has retrospective descriptions; the contemporary June10 notice\nestablishes construction, while exact progress on 1 July1835 is unknown**')
paths[p]=(old,new)
patch=[]
for p,(a,b) in paths.items():
 dest=prop/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(b)
 patch.append(f'diff --git a/{p} b/{p}\n')
 if not a: patch.append('new file mode 100644\n')
 patch.extend(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/'+p if a else '/dev/null',tofile='b/'+p))
(out/'T-2379-context.patch').write_text(''.join(patch))
print(out/'T-2379-context.patch')
