"""Light analytic projections only; no renderer, image editing or camera refit."""
from pathlib import Path
import json,math
HERE=Path(__file__).resolve().parent;BASE=Path('/tmp/chicago-next-model/T-2384-1835')
body=json.loads((BASE/'candidate/chicago/4d/data/structures/st_marys_church.json').read_text())['phases'][0]
old=body['form']['chapel_profile']['value'];new=json.loads((HERE/'candidate/chicago/4d/data/structures/st_marys_church.json').read_text())['phases'][0]['form']['chapel_profile']['value']
ridge=body['form']['wall_height_m']['value']+7.62/2*math.tan(math.radians(body['form']['roof_pitch_deg']['value']))
views={'moss':{'display':[1456,1696],'cross_tip':[891,75],'cornice_horizontal_extent':[750,1030],'read_uncertainty_display_px':12,'role':'rough calibration prior from held ticket picture'},'gale':{'display':[1247,2048],'cross_tip':[804,449],'cornice_horizontal_extent':[699,896],'read_uncertainty_display_px':12,'role':'withheld cross-source diagnostic; failure retained, not refitted away'}}
reports=[]
for view,obs in views.items():
 c=json.loads((BASE/'cameras'/f'{view}-original-site.json').read_text());t=math.radians(c['yaw_deg']);eye=c['eye'];f=c['focal_px'];pp=c['principal_px'];size=c['image_px'];display=obs['display']
 def project(x,y,z):
  dx,dy,dz=x-eye[0],y-eye[1],z-eye[2];depth=dx*math.sin(t)+dy*math.cos(t);right=dx*math.cos(t)-dy*math.sin(t)
  assert depth>0
  return [(pp[0]+f*right/depth)*display[0]/size[0],(pp[1]-f*dz/depth)*display[1]/size[1]]
 def prediction(q,projection,cap_rise):
  x=q['belfry_near_setback_m'];y=3.81;z=ridge+q['belfry_plinth_above_ridge_m']+q['belfry_open_height_m']+cap_rise
  cross=project(x,y,z+q['belfry_cap_height_m']+.08+.11+q['cross_height_m']);half=q['belfry_width_m']/2+projection
  points=[project(x+dx,y+dy,z) for dx,dy in [(-half,-half),(-half,half),(half,half),(half,-half)]]
  return {'cornice_points_display_px':points,'cornice_horizontal_extent_display_px':[min(p[0] for p in points),max(p[0] for p in points)],'cross_tip_display_px':cross,'cross_error_display_px':math.dist(cross,obs['cross_tip'])}
 reports.append({'view':view,'observations':obs,'old':prediction(old,.12,.23),'next':prediction(new,.075,.18),'camera':'unchanged research seed; seven body controls were fit, not independent validation','limits':'Rough visual landmark readings, no automatic segmentation and no rendered confirmation. Cross-source disagreement remains open. No source coordinate, installation date or camera acceptance is inferred.'})
(HERE/'camera-diagnostics.json').write_text(json.dumps(reports,indent=2)+'\n');print(json.dumps([{ 'view':r['view'],'old_cross_error_display_px':r['old']['cross_error_display_px'],'next_cross_error_display_px':r['next']['cross_error_display_px']} for r in reports],indent=2))
