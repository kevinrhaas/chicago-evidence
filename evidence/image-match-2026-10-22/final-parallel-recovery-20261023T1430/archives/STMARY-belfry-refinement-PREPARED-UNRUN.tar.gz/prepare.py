from pathlib import Path
import json,hashlib,difflib,shutil
HERE=Path(__file__).resolve().parent
BASE=Path('/tmp/chicago-next-model/T-2384-1835/candidate')
CAND=HERE/'candidate'
paths=['chicago/4d/generators/archetypes/frame_dwelling_chapel.py','chicago/4d/data/structures/st_marys_church.json']
files={}
helper=(BASE/paths[0]).read_text()
replacements={
 'for z,t in ((base-.06,.12),(top,.14),(top+.14,.09)):':'for z,t in ((base-.045,.09),(top,.11),(top+.11,.07)):',
 'cx-r-.12,cy-r-.12,z,cx+r+.12,cy+r+.12':'cx-r-.075,cy-r-.075,z,cx+r+.075,cy+r+.075',
 'x-.065,y-.065,base,x+.065,y+.065,top':'x-.0475,y-.0475,base,x+.0475,y+.0475,top',
 'x-.095,y-.095,z,x+.095,y+.095,z+.065':'x-.070,y-.070,z,x+.070,y+.070,z+.050',
 '(x1,y1,z),.065)':'(x1,y1,z),.045)',
 '(x1,y1,base+.56),.045)':'(x1,y1,base+.56),.030)',
 '(x1,y1,base+.16),.045)':'(x1,y1,base+.16),.030)',
 'curve(b,pts,.105)':'curve(b,pts,.075)',
 'capbase=top+.23;radius=r+.14':'capbase=top+.18;radius=r+.09',
}
for old,new in replacements.items():
 assert helper.count(old)==1,(old,helper.count(old));helper=helper.replace(old,new)
helper=helper.replace('def belfry(b,p):\n','def belfry(b,p):\n # T-2384 next study: slimmer reconstructed stock follows both viewed drawings.\n # These dimensions are a test prior, not measured joinery or a dated addition.\n',1)
files[paths[0]]=helper
record=json.loads((BASE/paths[1]).read_text());phase=record['phases'][0];assert phase['id']=='frame_1833';profile=phase['form']['chapel_profile'];assert profile['value']['belfry_width_m']==2.05
profile['value']['belfry_width_m']=1.50
assert profile['value']['belfry_near_setback_m']==1.20
profile['value']['belfry_near_setback_m']=.85
profile['note']+=' Next isolated study narrows the reconstructed square belfry from 2.05 to 1.50 m sets its reconstructed near-gable setback from 1.20 to 0.85 m, and slims its post/rail/brace/cornice stock after both actual v1 comparisons showed excessive width and weight. This is an unrendered bounded metric prior; it supplies no new date or measured historic dimension.'
files[paths[1]]=json.dumps(record,indent=2,ensure_ascii=False)+'\n'
patch='';hashes={}
for path,new in files.items():
 old=(BASE/path).read_text();p=CAND/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(new);hashes[path]={'baseline_sha256':hashlib.sha256(old.encode()).hexdigest(),'next_sha256':hashlib.sha256(new.encode()).hexdigest()}
 patch+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
(HERE/'next-over-prior-candidate.patch').write_text(patch)
(HERE/'baseline-guards.json').write_text(json.dumps(hashes,indent=2)+'\n')
(HERE/'record-change.json').write_text(json.dumps({'base':'T-2384-1835 fully materialized candidate, never a whole-record copy onto newer sourceS metadata','record_id':'st_marys_church','phase_id':'frame_1833','guarded_changes':[{'json_pointer':'/phases/0/form/chapel_profile/value/belfry_width_m','expected_old':2.05,'new_reconstructed_value':1.5},{'json_pointer':'/phases/0/form/chapel_profile/value/belfry_near_setback_m','expected_old':1.2,'new_reconstructed_value':.85}],'preserve':'all current sourceS metadata, dates, position, bearing, polygon and unrelated form values','note_append':profile['note'].split(' Next isolated study',1)[1]},indent=2)+'\n')
print('Prepared two-file overlay on prior isolated candidate only; no export or canonical write.')
