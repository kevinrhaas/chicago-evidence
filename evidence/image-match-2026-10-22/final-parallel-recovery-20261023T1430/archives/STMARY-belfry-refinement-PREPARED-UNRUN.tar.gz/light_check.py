from pathlib import Path
import sys,types,json,importlib.util,math,dataclasses,hashlib
import jsonschema
HERE=Path(__file__).resolve().parent
BASE=Path('/tmp/chicago-next-model/T-2384-1835/candidate/chicago/4d');ROOT=Path('/workspace/chicago/chicago/4d');CAND=HERE/'candidate/chicago/4d'
sys.path.insert(0,str(ROOT/'generators'));sys.modules['bpy']=types.ModuleType('bpy')
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
params=load('chapel_next_params',BASE/'generators/archetypes/frame_dwelling_params.py')
old=json.loads((BASE/'data/structures/st_marys_church.json').read_text());new=json.loads((CAND/'data/structures/st_marys_church.json').read_text());op,np=old['phases'][0],new['phases'][0]
for key in ['id','documented_range','position','footprint']:assert op[key]==np[key],key
for key in op['form']:
 if key!='chapel_profile':assert op['form'][key]==np['form'][key],key
q0=op['form']['chapel_profile']['value'];q1=np['form']['chapel_profile']['value'];assert {k for k in q0 if q0[k]!=q1[k]}=={'belfry_width_m','belfry_near_setback_m'}
a=params.from_phase(op,old);b=params.from_phase(np,new);b.validate()
x=load('chapel_old_geometry',BASE/'generators/archetypes/frame_dwelling_chapel.py').chapel_mesh(a,'study')
y=load('chapel_next_geometry',CAND/'generators/archetypes/frame_dwelling_chapel.py').chapel_mesh(b,'study')
assert all(all(math.isfinite(t) for t in v) for v in y.verts)
assert len(y.verts)==len(y.conf) and len(y.faces)==len(y.mat_index)
assert all(all(0<=i<len(y.verts) for i in f) for f in y.faces)
assert (x.verts[:20],x.faces[:5])==(y.verts[:20],y.faces[:5])
assert params.front_wall(a)==params.front_wall(b)
jsonschema.Draft202012Validator(json.loads((ROOT/'data/structures.schema.json').read_text())).validate(new)
report={'scope':'two-file overlay onto prior opt-in1835candidate, not canonical adoption','schema':'pass','profile_validation':'pass','unchanged':'main body, openings/shared facade readers, dates, position, bearing and polygon','changed_parameters':{k:{'old':q0[k],'next':q1[k]} for k in q0 if q0[k]!=q1[k]},'finite_indexed_mesh':'pass','vertices':len(y.verts),'triangles':sum(len(f)-2 for f in y.faces),'export_browser':'NOT RUN; no new GLB or match verdict','shared_family_if_base_adopted':'271master rebake still owed; not avoided by this isolated overlay'}
(HERE/'light-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
