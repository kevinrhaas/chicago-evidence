# T-2384 — next belfry comparison, prepared but not rendered

T-2384 is now normally claimed by this continuation. Claim commit `8fc9b2f951b6c2efa52965dc9d2b4fdd91ec4d47` was published to tickets/main and verified there. The claim used an independent tiny context under `/tmp/stmary-T2384-claim-context`, exact authoritative ticket-tool SHA256 `cf3ba8fd23e0e82424f834378c8fadae3f9af7b118a8732cf1a1d6eb18608f5d`, normal remote checks, no force/bypass. The writer window was coordinated with the tavern agent and released after the claim. This is ownership, not image acceptance.

This directory prepares a **two-file overlay on the prior isolated positive-1835 proposal**, not a patch directly onto the frozen canonical M branch. `next-over-prior-candidate.patch` changes only the chapel helper and St Mary's proposed record. `baseline-guards.json` gives exact expected prior bytes. `record-change.json` supplies guarded scalar changes for later selective materialization; never overwrite current sourceS metadata with a stale whole record. No canonical checkout, asset, manifest or scene was edited; no Blender/browser job ran.

## Actual pictures and chronology reread

The held ticket picture is the Moss engraving published in Andreas 1884 vol1 p291, not a dated 1843 exposure. The exact publication credit is preserved by parent sourceS. Its form has a blank near gable, five tall side sash, an end side door, small far stack, slender open belfry, curved braces/cap and cross. Andreas p290 says no tower at initial 1833 construction, then only “Some time afterwards.” This gives no post 1835 lower bound.

The full signed Trowbridge plate in Gale 1902 oppositep49 was reread. Its caption puts the depicted church at original State/Lake with 1834 erection; p48 says built 1833 and finished the following year, with p49 retaining25 ×35 ft. Its narrative is a retrospective 1835 walk. This is positive original-site support for a reconstructed belfry choice, not independent period proof or a dated installation. Possible dependence on Andreas/common earlier material remains declared.

Garraghan 1921 p127, reread from the actual scan, prints Quarter's entry headed **1844, May**: “The old church is a long, low, frame building, having a small steeple and bell surmounted by a cross.” The following100 ×55 ft dimensions belong to the **new brick church**. P106 places the old moved church north of Madison, some yards west of Michigan, within the December 1839 narrative; its footnote's21 June 1839 date is lot purchase, not a move day. P112 places the old frame church north of Madison between Wabash/Michigan when the college opened3 June 1844. These are later-site facts, not a license to place the 1844 range/occupancy in 1835. Quarter's dated description establishes presence by May 1844, not the earliest possible belfry installation.

The May24,1835 Bruté letter, transmitted in Garraghanp84 and reread on the scan, says he was unable to enlarge the church because title was uncertain. This bounds floor-area enlargement, not bell absence. No new original manuscript was inspected and no new tower date is asserted. Full source URLs, quotations and bounded newspaper search remain in `../T-2384-belfry-followup/README.md`; `source-reread.json` logs this rereading explicitly as such.

## Proposed visible correction

Both frozen v1 comparisons showed an overly broad, heavy belfry. The next metric prior narrows its reconstructed square width2.05→1.50 m and sets its near-gable setback1.20→0.85 m within the unchanged roof footprint. Post stock changes130→95 mm, cross rails65→45 mm, diagonal rails45→30 mm and curved brace105→75 mm. Cornice projections120→75 mm, with correspondingly lighter cornice/cap-base profile. These are bounded reconstructed joinery choices, not source measurements.

The main body, five windows, side door, shared facade readers,25 ×35 ft polygon, dates, position and bearing stay identical to the prior proposal. No May 1844 enlarged prototype dimensions are borrowed. The next belfry still has enough roof clearance under the strict profile validator. The helper remains opt-in; legacy household defaults are untouched. Adopting the base producer still requires the owed **271 frame-family master rebuild**, honest recipes, derivatives and normal validation; this overlay does not reduce that obligation.

## Camera controls and limits

Keep **both frozen body-camera seeds unchanged** for the first before/after review. Their seven fitted body points are calibration points, not independent validation. No new camera is accepted or enrolled. `camera_diagnostics.py` projects rough hand-read belfry controls without producing/editing images or fitting away differences. The primary Moss cross/cornice guided this test prior. Gale is withheld as a cross-source diagnostic; its cross remains substantially displaced under the same profile. That disagreement must be inspected and recorded rather than erased by an automatic camera change.

For later fitting, explicitly separate wall plate from overhanging fascia, and reserve belfry/plinth/cap points and opening reveals as holdouts. The original body seeds have large principal-point offsets and no independent holdout solution; their mean residuals alone do not establish optical correctness. Ground, sidewalk, people and concealed faces are unresolved by this isolated study. Moss and Gale cap/rail/boarding details may disagree as retrospective drawings; the held Moss image governs this narrow test, while Gale remains a separately compared source, not interchangeable period corroboration.

## Checks and next execution

`light-checks.json`: schema/profile validation and finite indexed mesh pass; 4,374 accumulated vertices,2,186 triangles; unchanged main body and shared opening rectangles checked. **No export/browser comparison has run for this overlay.** The previous actual GLB/cameras/matches under `../T-2384-1835/runs/v1` remain untouched and both verdicts remain `differs`.

Only after the parent grants a heavy slot: materialize the exact prior candidate plus this guarded overlay outside product metadata; use the audited direct emit API, fresh output and protected metadata receipts; render Moss and Gale separately using the same frozen body cameras. Inspect the actual output before changing any verdict. Do not run `build.py --out` as supposed isolation, copy a preview GLB into canonical assets, restamp old recipes, or start the271 family bake during the parent's preflight. Original T-2384 remains open.
