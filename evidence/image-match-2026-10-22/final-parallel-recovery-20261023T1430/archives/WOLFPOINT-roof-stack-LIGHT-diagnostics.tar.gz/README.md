# Wolf Point roof, stack and camera controls — LIGHT baseline analysis

2026-10-23. This is an analysis of the **actual reviewed master** `be265ed9a60c01298d7dc687e998b7ff50b4c0636020aff7094be176702f6268` from the closed one-export/one-capture run `T-2386-door-log-relief-next/runs/20261023-141756-738729`. No new model variant, generator/data patch, camera change, export/capture, canonical file or frozen package was created/changed. The source image gate remains **differs**, full original T-2386 remains open/claimed. Heavy slot CLEAR. This directory freezes a small independent actual baseline for further inspection.

## Existing controls and actual output

The actual GLB has **zero images and zero textures**. The material named `roof_shingle` has only base colour factor[0.34,0.30,0.27,1] and roughness0.9. It has no texture map, normal relief or substrate extras. This is diagnostic of this actual master, not a new renderer contract based on a material name. The label alone does not make it a shingle field on screen. `photo_match` uses the loaded material normally; its only special building tint is Keith's stone. It does not synthesize a shingle pattern from this name.

In copied `generators/archetypes/log_dwelling.py`, `_elbow_roof` emits the clipped **flat upper-envelope roof polygons**, plus the existing120mm projected roof edge and50mm underside/edge thickness. Rounded-gable faces are emitted separately under the now-rendered `compound_log_profile`. Neither the elbow roof nor its new log profile produces a roof covering pattern. This explains the obvious smooth roof in the actual comparison without requiring another hypothesis or camera.

Existing parameter meanings:

- `roof_type: gable` is an inferred category. `roof_pitch_deg:42` is a reconstructed angle; it changes the silhouette, not texture.
- `compound_roof_overhang_m:.12` changes roof edges and their existing50mm thickness proxy; it does not add shingles or create an independently controlled eave thickness.
- `roof_condition` is a **weathering finish**, not a covering selector. The material programme argues log-building shingles under existing libertyL266; its documented ordinary-building argument is not an attestation of this tavern's historical roofing. Do not put “shingle” into roof_condition, change global roof colours/defaults, or treat the material name as a reliable surface-detail API.
- `_ridge_stack` emits one plain **rectangular box** through the core ridge: reconstructed `chimney_ridge_at:[.29]`, width`.45m`, head`.50m`. Width affects both plan axes; head is measured above the nominal ridge. No masonry joints, cap, opening or independent cross-ridge station control exists here. Its generic `chimney` material is not proof of brick, clay or stone identity.
- `roof_pipe:[.74,.14,.55]` is core-ridge fraction, diameter and exposed head. `_elbow` emits a dark, eight-sided **closed uncapped proxy**. It is a distinct slender projection, not silently another masonry chimney count or an attested stove/flue/interior system.

All this was read from the exact frozen producer/record and actual decoded GLB. `analysis.json` records the exact current controls, material and actual projected bounds. No controls were changed.

## Camera residuals, without refitting

The same square-pixel camera SHA is `2a96283300029b94481286f5b246c2c9c53efb6f505ab140ddef543288a48f82`. It retains6000px focal, reconstructed5m span/2.6m eave gauge and eye height2m. There is **no metric control**, and absolute scale/focal-distance ambiguity remains. Source is the cleared1867Blanchard/Shober NYPLsheet depicting1833, not a contemporary July1835 record. Full source, actual before/after and identical crop have been directly inspected.

`analysis.json` reprojects the prior approximate12corner/apex picks under the unchanged current camera and physicalL references. These are the same picks used to generate the earlier camera hypothesis, **not independent fit validation**. Reference eave/base points are nominal physical corners, not claimed visible mesh-edge detections. Actual roof-apex values use the nearest decoded actual roof vertices and explicitly distinguish them from nominal references. The nominal roundedL already had about1.60pxRMS/3.77pxmaximum residual at these12picks. Those small residuals do not close mass perspective, source fabrication, hidden topology or the camera.

Secondary approximate source points were not camera controls. Current projections in source1920×1697pixel coordinates:

| Feature | Existing approximate source point | Current model point | Residual(model−source) |
|---|---|---|---|
| broad head top centre |306,750 |304.48,753.83 |−1.52,+3.83px |
| thin projection top centre |406,752 |407.74,751.03 |+1.74,−0.97px |
| raised right light centre |485,859 |487.35,859.03 |+2.35,+0.03px |
| left entry reference centre |229,885 |227.65,883.67 |−1.35,−1.33px |
| right entry reference centre |448,879 |449.93,882.42 |+1.93,+3.42px |

The exact actualGLB broad-head top projects to x295.37..313.58,y753.68..753.97; the pipe top to x405.71..409.76,y750.99..751.06. These are geometric projections of mesh vertices, not rendered/occlusion-segmented source rectangles. Prior manual source picks have a few-pixel uncertainty. A3.8pxbroad-head difference is comparable to that uncertainty; it does **not** justify automatically changing head height or camera. The current light correction fixes its old vertical reference residual; it does not prove exact sash/joinery. Blind recess back pixels differ from old face-plane reference centres by design; these rows remain exterior reference centres, not an aperture pixel-edge fit.

The still-obvious mass perspective differences require checking complete roof lines, eave breaks and doorway widths under the fixed camera, rather than claiming that a small12point residual proves a finished match. Roof pitch/camera should not be changed to disguise absent covering detail.

## Source-bounded next decision

The actual source clearly supports a **dark textured roof field** rather than the smooth neutral model. At the currently deposited1920pxsheet scale it does not securely measure individual shingles, exact courses, dimensions, material colour, cap geometry or weathering. A fresh attempt at the same Commons file's imageinfo/3840thumbnail API returned403, so no higher-resolution original detail was obtained in this pass. The request/error is in `higher-resolution-attempt.json`; no new source was adopted.

The most useful next bounded *design decision* is therefore a local roof-covering relief proxy on the existing clipped elbow roof, retaining the exact current silhouette, room/physical polygon, pole, doors, lighting and camera. Before implementation, select one honest surface representation and its bounds; category may rely on the existing roofing argument plus source appearance, chosen piece rhythm/section/overlap and all geometry must remain reconstructed. Do not transfer image pixels as textures or claim a measured historical shingle field. Do not make a second hidden plane above the clipped valley, open cracks/duplicate roof surfaces, or affect all81defaults. If a new opt-in is later chosen, keyword-only default-off, supported-elbow guards, consumed field/note/Covers/source and all81raw/material/confidence default parity are required; code+data+official81rebake/consumer/gates/appQA belong to the eventual combined integration, not an invisible precursor PR.

Keep stack changes separate until the actual source head/cap can be read more precisely. The current two projections are already within a few source pixels at the old approximate picks. Their **plain fabrication/material proxies** are visibly unresolved, but current evidence does not warrant combining speculative station, cap, material, height and camera changes into one new bundle. No new variant or field is prepared here.

## Recovery

Run `python3 /tmp/chicago-next-model/T-2386-roof-stack-analysis/analyze.py` for lightweight deterministic read/projection checks only. All required analysis inputs are copied alongside it; initial creation logic names frozen actual paths only for missing inputs, so keep `master.glb`, `camera.json`, `record.json`, `prior-picks.json` and `glb_contract.py` together. This is not a Blender/browser runner. `analysis.json` is an analytic report, never an accepted reference-view/matches record. Parent's future school capture remains separately queued and unrun until explicit grant.
