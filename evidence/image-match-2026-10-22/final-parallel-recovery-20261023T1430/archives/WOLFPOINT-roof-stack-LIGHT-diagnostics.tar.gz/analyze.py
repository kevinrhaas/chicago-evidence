"""Read frozen actual GLB and camera; no image/render/model changes or fitting."""
from pathlib import Path
import json,math,sys,hashlib,shutil
H=Path(__file__).resolve().parent
R=Path('/tmp/chicago-next-model/T-2386-door-log-relief-next/runs/20261023-141756-738729');F=R/'after';P=Path('/tmp/chicago-next-model/T-2386-door-log-relief-next')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Freeze only required analysis inputs; no live checkout.
for dst,src in {'master.glb':F/'assets/gltf/wolf_point_tavern__log_frame_1828.glb','camera.json':F/'docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.json','record.json':F/'data/structures/wolf_point_tavern.json','prior-picks.json':Path('/tmp/chicago-next-model/T-2386-topology/rounded-overlay-projection.json'),'glb_contract.py':P/'glb_contract.py'}.items():
 if not (H/dst).exists():shutil.copyfile(src,H/dst)
assert sha(H/'master.glb')=='be265ed9a60c01298d7dc687e998b7ff50b4c0636020aff7094be176702f6268'
sys.dont_write_bytecode=True;sys.path.insert(0,str(H));from glb_contract import read,values
d,b=read(H/'master.glb');c=json.loads((H/'camera.json').read_text());r=json.loads((H/'record.json').read_text());ph=r['phases'][0];form=ph['form'];e=c['eye'];sn=math.sin(math.radians(c['yaw_deg']));cs=math.cos(math.radians(c['yaw_deg']))
def project(v):
 du,dv,dz=[v[k]-e[k] for k in range(3)];dep=du*sn+dv*cs;assert dep>c['near_m'];return [c['principal_px'][0]+c['focal_px']*(du*cs-dv*sn)/dep,c['principal_px'][1]-c['focal_px']*dz/dep]
by_mat={};allpoints=[]
for mesh in d['meshes']:
 for p in mesh['primitives']:
  raw=values(d,b,p['attributes']['POSITION']);vs=[(raw[i],-raw[i+2],raw[i+1]) for i in range(0,len(raw),3)];n=d['materials'][p['material']]['name'];by_mat.setdefault(n,[]).extend(vs);allpoints+=vs
roof=by_mat['roof_shingle'];chim=by_mat['chimney'];zmax=max(v[2] for v in chim);top=[v for v in chim if abs(v[2]-zmax)<1e-6];q=[project(v) for v in top]
nominal=json.loads((H/'prior-picks.json').read_text());rows=[]
# Prior12picks only: report model core references, plus actual nearest roof-vertex residuals where present.
for p in nominal['rows']:
 v=p['actual_overlay_point_local_m'];qq=project(v);s=p['source_px'];row={'feature':p['feature'],'source_px':s,'source_pick_uncertainty_px':'3–6 from prior topology read','model_reference_local_m':v,'reference_projected_px':qq,'reference_residual_px':[qq[k]-s[k] for k in range(2)]}
 if 'apex' in p['feature']:
  near=min(roof,key=lambda vv:sum((vv[k]-v[k])**2 for k in range(3)));pq=project(near);row.update({'actual_GLBroof_nearest_vertex_local_m':near,'actual_GLBroof_projected_px':pq,'actual_GLBroof_residual_px':[pq[k]-s[k] for k in range(2)]})
 rows.append(row)
features={}
for n,pick in nominal['secondary_features_not_fit_to_camera'].items():
 v=pick['point'][:]
 if n=='right_window_centre':v[2]=1.7
 qq=project(v);features[n]={'local_m':v,'source_approx_px':pick['source_approx'],'projected_px':qq,'residual_px':[qq[k]-pick['source_approx'][k] for k in range(2)],'pick_limits':'Approximate prior manual point; no new source measurement, no refit or solved camera'}
# Exact actualGLB broad head and dark pipe silhouette, separate from nominal roof reference.
dark=by_mat['dark'];pipe=[v for v in dark if abs(v[0]-2.5)<.071 and abs(v[1]-.74*10.1)<.071 and v[2]>4.9];assert pipe
pipehead=max(v[2] for v in pipe);pp=[project(v) for v in pipe if abs(v[2]-pipehead)<1e-6]
roofmat=next(m for m in d['materials'] if m['name']=='roof_shingle')
report={'status':'LIGHT_ACTUAL_BE265ED9_BASELINE_ANALYSIS_ONLY_NO_VARIANT','master_sha256':sha(H/'master.glb'),'same_camera_sha256':sha(H/'camera.json'),'source_pick_provenance':'Copied rounded-overlay-projection.json; prior approx12corners/apices and secondary picks. These picks are not independent of original camera fit.','source_date_limits':'Cleared1867NYPLsheet depicts1833retrospectively, not July1835construction evidence.','roof_material':roofmat,'GLB_images':len(d.get('images',[])),'GLB_textures':len(d.get('textures',[])),'roof_field_points':len(roof),'existing_roof_controls':{k:form[k] for k in ['roof_type','roof_pitch_deg','compound_roof_overhang_m']},'existing_stack_controls':{k:form[k] for k in ['chimney_ridge_at','ridge_stack_w_m','ridge_stack_head_m','roof_pipe']},'actual_broad_stack_head_local_z':zmax,'actual_broad_stack_top_projected_bbox_px':{'min':[min(v[k] for v in q) for k in range(2)],'max':[max(v[k] for v in q) for k in range(2)]},'actual_thin_pipe_head_local_z':pipehead,'actual_thin_pipe_top_projected_bbox_px':{'min':[min(v[k] for v in pp) for k in range(2)],'max':[max(v[k] for v in pp) for k in range(2)]},'unchanged_camera_model_control_rows':rows,'unchanged_camera_secondary_features':features,'conclusion':'No covering relief or texture exists in this actual master despite roof_shingle material label. Broad head is a plain rectangular box and pipe an uncapped8sidedclosedproxy. Analyse source category/detail before new optin; no camera or data values changed.','no_photometric_metric_attestation':True,'new_exports_captures':0,'limits':'Analytic projection of actualmesh/record under unchanged provisionalcamera, not pixel segmentation/occlusion proof, historic station or freshfit. Base/eave references are nominal physical points; actualroof apices use decoded vertices. Fullimage gate remainsdiffers.'}
(H/'analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['status','master_sha256','same_camera_sha256','GLB_images','GLB_textures','actual_broad_stack_top_projected_bbox_px','actual_thin_pipe_top_projected_bbox_px','unchanged_camera_secondary_features']},indent=2))
