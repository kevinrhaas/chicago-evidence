# T-2378 exact-publication source correction — unapplied

Apply-ready three-file patch `T-2378-primary-source.patch`, checked against current
root HEAD792598d88. `PATCH-HASHES.json` records exact before/after hashes and full
base HEAD. Parent owns canonical application, rederive, card QA and gate.

The exact1881 keyed-cut reproduction explicitly locates Beaubien’s pictured
house at the northeast Michigan/SouthWater corner. The proposed source/card
wording adopts the sale-located homestead as the preferred **inferred** identity,
from the same Wentworth witness. Exact earlier building lineage is still unknown.
The same publication's Hubbard criticism and all FactoryHouse separation limits
are preserved in source notes and dossier. See `PRIMARY-FINDING.md` and actual
printed86/87 JPGs for visually checked evidence. No numerical geometry change.

Focused validation passed: real source/structure schemas; three structure prose
fields only; mesh-input SHA902255ea... unchanged; actual Photos compiler displays
“[Inferred Beaubien residence]” and publication link; actual whole-building grade
remains inferred with no accepted picture. Root's existing generic grade reason
still reads “no picture ... found” because this proposal adds no pictured ruling;
this correction must not be presented as a solved image gate.

The compact index's citation/date fields become shorter: current167838B ->
estimated167723B (115B saved), leaving277B under the unchanged168000B cap.
This estimate uses the real packing and reader-text functions to replace the one
current source-index row. Fullsource notes retain provenance/limits. Actual
combined rederive remains parent-owned; no budget or assertion is weakened.

No Blender/browser/heavy job, root edit, geometry bake, camera installation,
match verdict, ticket closure, code commit or PR was performed. T2378 andT2379
normal claims were published separately at724d5d62/4618c934; sharedtickets clean
when the writer window was released.
