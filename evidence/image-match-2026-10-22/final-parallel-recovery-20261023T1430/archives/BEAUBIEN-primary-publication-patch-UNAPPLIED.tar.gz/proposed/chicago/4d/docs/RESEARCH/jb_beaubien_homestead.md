
# Col. Jean Baptiste Beaubien's Homestead — research dossier

**Record:** `data/structures/jb_beaubien_homestead.json` · **Scene status:** standing on
1835-07-01 · **South Water Street parcel** · **`review_required: true`**

An early residence whose exact building identity, construction date and appearance remain unresolved.

## 1. What is documented

Andreas: the **American Fur Company factory building**, erected by Capt. Bradley, bought by Jean
Baptiste Beaubien in **1817**. Beaubien afterwards converted an earlier cabin to a barn and built
a new residence and a small trading post.

> **Corrected 2026-09-06 (T-0718), and read § 6 before using the sentence above.** The **1817**
> in it belongs to a *different building* — the Dean house at the lake shore — and Andreas dates
> the factory building's arrival to **1822**. The record's `documented_range` carries the same
> correction; the bound itself was not moved on that ticket, and § 6 says why. The repair is **T-0893**.

A second source gives the same building a **different origin** — the United States Factory House,
bought from the government by the Fur Company in 1822 — and that reading, its conflict with
Andreas and the identity question it opens are § 6 below, not this section.

**A live fact for the scene:** Beaubien's pre-emption certificate for the whole 75.69-acre fort
reservation is dated **28 May 1835**, recorded **26 June 1835**, price **$94.61** — five weeks old
and unchallenged on 1835-07-01. It was voided by *Wilcox v. Jackson*, 38 U.S. 498, in **1839**,
which is outside this scene.

## 2. The corner, decided — north-east

**Settled 2026-09-06 under T-0718, against the previous adoption.** This section used to be
headed *"the corner is contested inside a single source"* and adopted the **south-west** on the
rule that a statement *about* the thing outranks a statement that merely passes it. The rule is
right; the reading it was applied to was wrong. Both pages were then read directly off the
archive.org scan of `historyofchicago01andr`.

| passage | reading | what the passage actually is |
|---|---|---|
| Andreas, scan p. 185 | *"where now is the **southwest** corner of South Water Street and Michigan Avenue"* | Andreas's own one-sentence summary of the homestead — followed immediately by the 1839 sale |
| Andreas, scan p. 339 | *"go east upon South Water Street until you come to the **northeast** corner"* | **John Wentworth's address of 21 May 1881, reprinted** — and expressly an instruction for finding this house |

**Scan p. 339 is not a boundary walk and it is not Andreas.** Verbatim:

> If you wish to find the traditional residence of General Jean Baptiste Beaubien, after he moved
> from what was before known as the John-Dean house, go east upon South Water Street until you come
> to the northeast corner of South Water Street and Michigan Avenue, and you will find it.

**One witness, not two.** That is word for word the sentence `chicagology_prefire052` reprints and
`wentworth_1881_fort_dearborn` holds as a document. Andreas 1884 is carrying Wentworth 1881, so the
north-east reaches this project twice from a single mouth — recorded here so that no later run
counts it twice.

**The south-west sentence cites the transaction that contradicts it.** Andreas p. 185 continues:
*"This was bid in at the land sale in June, 1839, by James H. Collins, for $1,049."* That is the
sale Wentworth narrates on p. 339, same buyer and same price — and Wentworth says which land it
was:

> …the land upon the **east side of Michigan Avenue, in Block 5, between South Water Street and the
> lots reserved**, where the Marine Hospital afterward was, except the corner lot, known as Lot 11 …
> Mr. Collins bid $1,049 for the next five lots, 10, 9, 8, 7, and 6, **where Beaubien's house,
> out-buildings, and garden were**.

East of Michigan Avenue, north of South Water Street, south of the reserved lots: the **north-east
quadrant**, and the only one of the four the sale can have been in. P. 185's second clause places
the ground its first clause mis-sites.

**The move.** About **47 m** north-east, to E 448199.8, N 4637570.6 (EPSG:26916) — the same OSM
intersection centre as before with the offset mirrored, so the two placements are comparable. The
point stands on traced ground at **+3.48 m** above the summer-1835 water surface, against +2.51 m
where it stood before. Confidence stays `inferred`: a better-argued corner is still a retrospective
corner.

**What is still open.** Wentworth's own lot list puts the house on lots 6–10, the five lots *north*
of corner lot 11 — so the buildings stood some distance north of the corner and his "you will find
it" is a finder's approximation. No plat of the Fort Dearborn Addition with a lot dimension for
Block 5 has been read here, so that distance is not quantified and is not invented. **The committed
point is a floor: the true position is at the corner or north of it, never south or west of it.**

## 3. A caveat that matters more than the corner

**Neither street existed here in 1835.** The reservation was unplatted, no street crossed it, and
South Water Street was ordered pitched only *"from the United States Reservation to Randolph
Street"*. Wentworth is speaking in 1881 and Andreas writing in 1884, both locating an old building by the
streets of their own day — and the Fort Dearborn Addition whose Block 5 they cite was not platted
until 1839.
Any future evidence should be read as fixing this building relative to the **fort**, not to a grid
that arrived later. The facade bearing has **no attested basis whatever** and is a placeholder
inherited from the retrospective grid.

## 4. The homestead was four buildings, and the scene draws one house and two outbuildings

Andreas describes: the factory building (this record), a **new residence**, a **small trading
post**, and a **cabin converted to a barn**.

**T-1743, 2026-10-03 — the owner's ruling, and what it changed.** The owner read the group T-1712
built as *three identical log houses by the fort, two of them on the fort road*, and both halves
were measured true: the house, the new residence and the trading post were all `log_dwelling`
at one wall height, one pitch and one chimney, and the two T-1712 records stood 17.9 m east of
the house on the centreline of `fort_road`, 0.0 m from it, in the road `data/streets/1835.json`
already drew to the fort's south gate. The owner ruled for **one dwelling and two outbuildings**
(answer b on the ticket):

- **Andreas's "new residence" is read as the house this record already models**, and
  `beaubien_new_residence` is withdrawn. § 6a reads Wentworth's "traditional residence" at the
  corner as most likely the new residence, so the two records were very probably one house drawn
  twice. This is a reading, not a finding: nothing reached says which of Andreas's two houses
  stood at the corner, and if a source ever separates them, the residence comes back as its own
  record with a place of its own. The phrase is kept on this record's `aka`.
- **`beaubien_trading_post` is an outbuilding** — a low log store, single-slope roof, one door, no
  chimney — **west** of the house, 4.0 m clear of its west wall, the side
  away from the road. Its place and its form are as invented as before and L283 says so.
- **`beaubien_barn` keeps its place** behind the house, 13.8 m from the road's centreline and
  outside its 12 m corridor, and gains a hay-loft door so it reads as a barn.
- **The road is clear**, and `tools/check_structure_corridors.py --gate` now refuses any building
  newly drawn in any street corridor at the street's own width — the check whose absence let the
  two records stand on an unplatted road, since every corridor gate before it asked only the
  platted grid.

So the scene shows the attested group as Wentworth's sale describes it — *"Beaubien's house,
out-buildings, and garden"* — one house with its out-buildings, and the garden still unbuilt.
The text below is the section as T-1712 left it, kept because it is the record of how the group
came to be drawn four-up.

**This section used to say "and one is modelled", and to refuse the other three** — "nothing
reached gives any of them a size, a material, a form, or a position relative to the factory
building, so they would be three invented boxes placed by eye around a fourth." **That refusal was
already out of date when it was read on 2026-09-28**, and this is the correction rather than a new
argument: `beaubien_barn` was built on 2026-08-11 in exactly the way this section forbids — by eye,
16.3 m behind the house, with the direction and the distance recorded as invented and the invention
claimed by **L72** — so one of the three had been standing for seven weeks while the page still
refused all three.

**T-1712 applies the barn's disposition to the two that were left.** `beaubien_new_residence`
(9.75 x 6.10 m, 32 x 20 ft, on the frontage line 17.9 m east of this record's origin) and
`beaubien_trading_post` (6.10 x 4.88 m, 20 x 16 ft, on the yard line at the same easting) are built
as log dwellings with their **presence and their use attested** and their **position, footprint and
storey count invented and graded `reconstructed`**, and **L283** carries the invention, the method
and what it costs. The ask is the owner's: T-1203 asks this ground for "the documented country seats
with their reconstructed neighbours".

**What was NOT done, and each of these is a live thread rather than an omission.**

- **No confidence on any committed record was raised.** Everything §§ 2, 6 and 6a say about how
  loosely this group is placed is unchanged, and the two new records inherit all of it.
- **`occupants` still answers nothing.** Andreas says Beaubien built a new residence, so which
  building of the group he actually slept in on the scene date is unattested; this record's
  `occupants` block says so, and the new residence is deliberately given **no occupants at all**,
  because a record called a residence is not evidence about where a man slept.
- **The garden is still unbuilt.** Wentworth's sale passage names "Beaubien's house, out-buildings,
  and garden" together on lots 6–10, so a garden on this ground is documented — but it is a fence
  line and ground cover rather than a structure, no source gives it an extent, and
  `fort_dearborn_garrison_garden` only has one because the 1830 plate draws its four corners.
- **"Out-buildings" is plural and the group now stands two of them.** The barn and the trading post
  are both out-buildings of a sort; nothing says either was one of the ones standing in 1839, and
  the plural is not spent as evidence for a fifth building.

## 5. Why review is flagged

Same reasoning as `madore_beaubien_house` § 4. `AGENTS.md`'s standing constraint on Native
presence and representation, the August 1835 removal, and the reservation claim all meet in this
record. It states built fabric and the documented dates of the claim and leaves interpretation to
a review this project has not yet sought.

## 6. The origin: the United States Factory House — and whether this is it

**Added 2026-09-04 under T-0595.** Until now this dossier said nothing about where the
building came from. A source Andreas did not copy does, and it does **not** agree with him.

**The claim.** Gurdon S. Hubbard, quoted at length and inside quotation marks by H. H.
Hurlbut, *Chicago Antiquities* (Chicago, 1881), pp. 28–36 — `chicago_antiquities_american_fur_co`,
claim `bk_afc_009`:

> In 1822, Crafts succumbed, and engaged himself to the American Fur Company bought from the
> U.S. the Factory House, located just south of Fort Dearborn, to which Beaubien removed his
> family.

The sentence is **ungrammatical as transcribed** and the reading supplies a missing *which*
("…engaged himself to the American Fur Company, **which** bought from the U.S. the Factory
House…"). The verbatim quote is kept beside the reading for exactly that reason. What it
offers is an origin, a date, a former owner and a bearing from the fort: the **United States
factory** — the government trading house — sold to the American Fur Company in **1822**, with
Beaubien's family moved into it.

**A second, independent description of the same building.** Hubbard's own autobiography
(1911), p. 38 — `hubbard_autobiography_1911`, claim `bk_hub_063`, describing the place as he
found it in 1818:

> Just east of the road, and adjoining the fence running east to the river, was the "Factor
> House," a two-story, squared-log structure, inclosed by a neat split-picket fence. This
> building was occupied from 1804 to about the year 1810 by a Mr. Jouett, United States
> factor… At the second construction of the fort he was succeeded by John Dean.

Two storeys, squared log, a split-picket fence, and two named factors. Note that this is the
same witness in both places — Hubbard in 1881 through Hurlbut, and Hubbard in 1911 — so the
descriptions are independent of each other as *texts* and not as *testimony*.

### The disagreement, not smoothed over

| | Andreas (this record's source) | Hurlbut's Hubbard, `bk_afc_009` |
|---|---|---|
| what it was | the **American Fur Company's** factory building | the **United States** Factory House |
| who erected it | Capt. Bradley | not stated |
| who bought it | **Beaubien**, 1817 | the **American Fur Company**, 1822, from the U.S. |
| where | corner of South Water St and Michigan Ave (retrospective) | "just south of Fort Dearborn" |

Different buyer, different seller, five years apart, and two bearings from the fort that are
not the same bearing — South Water and Michigan is *north* of the fort, not south of it.

> **The first two rows of that table are withdrawn (T-0718, 2026-09-06).** Andreas scan p. 205
> says the factory building went to the American Fur Company and on to Beaubien in **1822**, which
> is Hubbard's year and Hubbard's chain; the "Beaubien, 1817" reading came from a *different*
> Andreas passage about a *different* house. The sources never disagreed about this building. The
> last row — the bearing from the fort — stands, and it is now the whole of the open question.

### The John Dean question, answered — and it fails on the *house*, not the man

**T-0718, 2026-09-06.** The question § 6 opened was this: Hubbard names **John Dean** as the United
States factor who succeeded Jouett at the Factor House (`bk_hub_063`), and Wentworth finds
Beaubien's residence *"after he moved from what was before known as the John-Dean house"*. If those
two John Deans were one man, Beaubien had **left** the Factory House and this record modelled the
house he moved *to*.

**The premise does not survive the reading.** Two further Andreas pages, read directly off the scan:

> **p. 183** — In 1815, a short time before the rebuilding of the fort, an army contractor named
> **Dean**, built a house **on the lake shore, at the mouth of the Chicago River, near where is now
> the foot of Randolph Street**. In 1817, Mr. Beaubien purchased this house, which was **a low,
> gloomy building of five rooms, for $1,000** … After this purchase he lived in the Dean house for
> several years, his son Alexander being born there. He used the old cabin after this for a barn.

> **p. 191** — While living in Chicago, Mr. Varnum boarded in **the old John Dean house**, with J. B.
> Beaubien, then its owner. … After the goods belonging to the United States remaining in the
> factory had been disposed of, **the building, which was just south of the fort**, was bought by a
> Mr. Whiting … It was sold by Mr. Whiting to the American Fur Company, and by that company to Jean
> Baptiste Beaubien, whose residence it remained until 1839.

> **p. 205** — In 1822, after the abandonment of the United States Factory at Chicago, by Government,
> **the factory building was bought by the American Fur Company, and soon after sold to John B.
> Beaubien, who made it his dwelling house.**

**The John-Dean house is a third building.** Andreas gives it a builder, a year, a site, a price and
a room count, and p. 191 holds it apart from the factory in a single paragraph — the John Dean house
on one side, *"the building, which was just south of the fort"* on the other. So Wentworth's sentence
does **not** say Beaubien left the Factor House; it says he left the lakeshore house at the foot of
Randolph Street.

**Whether contractor Dean and factor John Dean are one man is *not established*, in as many words.**
Andreas supplies the forename "John" for the house; Hubbard supplies the office for the man; nothing
reached joins them. It no longer bears on this record either way, because the sentence turns on which
*house* Beaubien left and Andreas answers that directly.

### So is the modelled building the Factory House? More likely than it was — still not proved

Read forward, Andreas's own sequence is: the **Dean house** at the lake shore from 1817; the
**factory building** from **1822** (p. 205, and `bk_afc_009` gives the same year and the same chain);
and Wentworth's *"traditional residence, after he moved from … the John-Dean house"* is then that
second building, at the corner § 2 now places this record on.

**Two corrections fall out of that**, and they are corrections to this dossier, not new claims:

1. **Andreas and Hurlbut's Hubbard do not disagree about the factory building.** The table above —
   "Beaubien, 1817" against "the American Fur Company, 1822, from the U.S." — was an artefact of a
   **conflation**: the 1817 purchase in Andreas is the *Dean house*, and Andreas dates the factory
   building's arrival to 1822 exactly as Hubbard does. The disagreement this dossier reported was
   never between the sources.
2. **The record's phase was misnamed, and is now `log_1822` — T-0893, 2026-09-11.** `factory_1817`
   fused the two buildings in its id and in its `documented_range.from`. Nothing was moved on
   T-0718, because changing the bound renames the phase and with it the committed GLB, two
   manifests, the 1835 sidecar and a `docs/LIBERTIES.md` coverage line; **T-0893 moved all of
   them**, and § 6b records what the id became and why it is not `factory_1822`.

**What blocked the identity was a position, not a date — and § 6a answers it.** Andreas p. 191 and
Hurlbut's Hubbard both put the factory building **just south of the fort**. That was filed as
**T-0894** rather than resolved by preferring whichever source agrees with the position already
committed, and T-0894 resolved it by measurement.

**Nothing was resized or regraded on this evidence.** `bk_hub_063`'s **two storeys** against this
record's inferred one is now *more* relevant than it was, and `form.stories` is still **1** — see the
value's own note. Doubling the massing of the oldest building in the dataset on a 1911 recollection
of 1818, about a building whose sources site it somewhere this record is not, is the move § 6 forbids.
If **T-0894** settles toward the Factor House, the value moves to 2 and the building rebakes.

### 6a. The bearing, measured — T-0894, 2026-09-11

**The plan has both locators in one frame, and nobody had looked.** Every reading of this question
before this one read *prose*, and prose is why it would not close: *"just south of the fort"* and
*"the north-east corner of South Water and Michigan"* are two locators in two frames with no common
term. F. Harrison Jr.'s 1830 plan — `harrison_1830_river_mouth`, the plate this project's fort,
garrison garden, Out Buildings and Mrs Jouett's grave are all placed from — **letters `U.S. Factor's
House`**, on the reservation, south of the stockade.

Read by the transform T-0883 stated and T-0882 reused (anchor px 1445, 644 on local ENU 1152.0,
221.0; 0.33528 m/px):

| | local ENU | |
|---|---|---|
| the three blocks the plate letters, ink-weighted | **(1145.6, 38.7)** | 152 m south of the palisade's nearest corner |
| `jb_beaubien_homestead`, footprint centroid | **(1133.2, 177.8)** | 10 m south of that same corner |
| separation | **140 m** | against ~20 m of working uncertainty here and 25 m on the plate |

`data/traces/harrison_1830_us_factors_house.json` is the reading: per-block pixels, sizes and
bearings, and three checks — the grave, the Out Buildings and the garden's road frontage all land on
their own ink under the same transform, so the 140 m is a measurement and not an impression.

**Two things fall out, and the first is a correction to this dossier.**

1. **This record never stood north of the fort.** § 6 said so above, and the sentence was reading the
   modern intersection's *name* rather than the georeference: South Water and Michigan is north of
   the fort **on today's street grid**, and § 3 has already warned that neither street existed here
   in 1835. In the committed frame the record stands 10 m *south* of the palisade's southern corner.
   The bearing was never the contradiction; the **distance** is.
2. **The identity is withdrawn, and the position stays.** What places this record is the 1839 sale —
   Block 5, east of Michigan Avenue, between South Water Street and the reserved lots — and that
   ground is not the ground the plate letters, 140 m south inside the reservation. So the two
   passages that say "just south of the fort" are right about the Factor House and this is not it.
   Moving the point onto the Factor's House would assert the identity the same measurement refuses.
   The alias *"the American Fur Company factory building"* came off the record on this ticket.

**What is still not established, in as many words.** *Which* building of the homestead group this is.
Andreas leaves room for the answer — he says Beaubien built a **new residence** — and Wentworth's
"traditional residence" at the corner is most likely that one, but nothing reached says so and
nothing here is regraded to make it look tidier. The corner stays `inferred`.

**`form.stories` is settled at 1**, and the reason has changed from caution to a measurement:
`bk_hub_063`'s two-storey squared-log Factor House describes a building 140 m from this one. No bake
follows, because no geometry moved.

**And the Factor's House is now a ticket rather than a question.** The plate gives its three blocks
an arrangement and a size to ±20 %, and no material, no roof, no opening, and no way to say which of
the three carries Hubbard's two storeys. `refused_here` in the trace says why nothing was built on
this ticket.

### 6b. The id, moved — T-0893, 2026-09-11

**`factory_1817` → `log_1822`, and the opening bound with it: `1817-01-01` → `1822-01-01`.** Both
halves of the old id were wrong, and they were wrong on two different tickets' evidence.

**The year** is T-0718's finding, above: the 1817 purchase in Andreas is the *Dean house* at the
foot of Randolph Street — a third building this project models nothing of (**T-0895**) — and the
year the same sources give for Beaubien leaving it is **1822** (Andreas pp. 191, 205; Hurlbut's
Hubbard, `bk_afc_009`). Andreas and Hubbard agree on the year and the chain.

**The word *factory*** does not survive § 6a. `factory_1822` would have re-asserted on the record's
own id the identity T-0894 refused by measurement, 140 m. So the id takes this record's
**construction** and its opening year — the form `log_1820`, `log_1823` and `log_1831` already carry
elsewhere in this dataset — and claims nothing about *which* building of the homestead group it is.

**What the 1822 is doing on a record § 6a says is not the factory building.** It is a **floor**, the
same kind of bound `1817-01-01` was meant to be. Beaubien was in the Dean house from 1817 "for
several years" and left it in 1822; what places this record is the 1839 sale, and Wentworth finds
the residence there *"after he moved from … the John-Dean house"*. So he is not at this corner
before 1822 on any reading reached: either the residence the retrospectives follow from 1822 to 1839
**is** this building, and 1822 opens it, or the homestead group held more than one building across
that span and this is a later one of them. **The residual is stated rather than smoothed:** nothing
reached names the year this particular building went up, so `1822-01-01` is the earliest date the
sources leave open and not a construction date. The confidence stays **`inferred`** — moving a bound
onto better reasoning is not grounds to regrade it.

**The phase id is an input to the mesh hash**, so the rename staled the committed GLB and
`jb_beaubien_homestead` was re-baked on the same commit; the glTF node prefix now reads `log_1822`
too. No geometry moved — the resolved generator parameters are byte-identical before and after.

**What moved in the same commit:** the record, `assets/gltf/` and `assets/web/` masters and their
two manifests, the 1835 sidecar and its index, `docs/LIBERTIES.md` L17's Covers line and the
compiled `data/liberties.json`, and this dossier.

## 7. Open threads

- Any description of the factory building's material or size. **Construction is `inferred` as log
  from date and place alone**; if it was frame the record is on the wrong archetype.
- Wentworth and Quaife on Fort Dearborn (both now source records in this project) for the
  reservation's building group.
- ~~**Whether the modelled building is the Factory House at all.**~~ **Closed, T-0894, § 6a:** it is
  not. The 1830 plate letters the Factor's House 140 m south of this record's centroid. What
  replaces it as an open thread is narrower — *which* building of the homestead group this is, with
  Andreas's "new residence" the reading with most room in it and no source reached that says so.
- **The `U.S. Factor's House` itself, unbuilt.** Measured at local ENU (1145.6, 38.7) and refused as
  fabric on T-0894 for want of everything above the footprint; `data/traces/harrison_1830_us_factors_house.json`.
- **A lot dimension for Block 5 of the Fort Dearborn Addition**, which would turn Wentworth's lots
  6–10 into a distance north of the corner and tighten § 2 from a floor to a position.
- **Any plan or description of the John-Dean house**, the 1815 lakeshore building of five rooms at
  the foot of Randolph Street — a documented Chicago building this project does not model at all.
  Filed as **T-0895**.
- The 1835 pre-emption papers themselves, which may describe improvements.

## The parcel's shared inventions

Three things are true of every record in the South Water Street parcel and are written once here
rather than sixteen times:

1. **The borrowed rectangle.** No period map this project has georeferenced shows a building
   footprint, and no source gives a South Water or Lake Street commercial building a dimension
   except Hogan's store (45 x 20 ft) and Philo Carpenter's log shop (16 x 20 ft). Every other
   footprint in the parcel is a rectangle built from figures borrowed from the dataset's own
   attested buildings — 40 ft frontage (Green Tree Tavern, Western Hotel), 25 ft depth (derived
   from the Green Tree's room module), 20 ft depth (Hogan's store) — capped by Andreas's
   documented **55 ft South Water lot width**. The repetition is the admission.
2. **The position method.** Modern intersection centres read from OpenStreetMap at EPSG:26916 on
   2026-08-11, offset 12.2 m (half an 80 ft platted street) to the kerb. South Water Street is
   today's Wacker Drive along the south bank; Wacker was built on its right of way in 1924-26 and
   widened northward over the old dock line, so the two lines are close but not identical.
   Working uncertainty is about **20 m** — the georeference's own residual (17.5 m RMS on Wright
   1834, 3.7 per cent paper stretch) — plus whatever the source's own vagueness adds, which is
   stated per record.
3. **The ground is not there.** Everything in this parcel east of about local E +320 stands
   outside the committed `e1834_harbor_cut` terrain box and is declared
   `ground_contact: outside_modelled_ground`. That is a terrain gap, not a structure gap.


## 8. The keyed 1831 panorama is contextual, not an identified appearance reference — T-2378

**The bounded correction.** The current house record no longer describes itself as
known to have been built before 1817 or as the dataset’s oldest building. Its log
material, one-storey form, dimensions, placement and per-attribute grades are
unchanged. The 1817 purchase belongs to the separate Dean house; 1822 is an earliest
allowed bound on this record, not a demonstrated construction year. The card’s
phase account now states those limits directly. Earlier readings remain above as
research history, not a reason to restore the withdrawn identity.

**The actual picture inspected.** `kinzie_1857_chicago_1831_panorama` records the
existing 1920 by 1042 pixel local reproduction
`chicago/reference/images/chicago/chicago_fort_dearborn_1831_1.jpg`. The upper credit
names Wau-Bun, Mrs. Juliette A. Kinzie, Chicago, 1857; the lower key names Dean House,
Gen. J. B. Beaubien’s, Fort, Wash-house, Agency-House and John-Kinzie House. Its
source citation explicitly says the modern Beaubien-group identification is
unresolved, so the Images context link cannot reasonably be read as an accepted
picture match. The date of this labeled reproduction is not established, and the
inventory’s public-domain attribution is not a fresh remote catalogue check.

**The text was also read, with its limit.** The committed Wau-Bun EPUB’s chapter
“Chicago in 1831”, under source `kinzie_waubun_1856`, reads:

> The residence of Jean Baptiste Beaubien stood at this period between the gardens
> and the river-bank, and still farther south was a rickety tenement, built many
> years before by Mr. John Dean, the sutler of the post.

This is a text excerpt read from
`chicago/reference/Wau-bun/wau-bun-pg12183-images-3.epub`, not a reread of a dated
manuscript or a new exact page citation. It supports the relative order of the
named groups, not a material, dimension, storey count, opening or stack pattern.
It does not close the distinction § 6a measures between the sale-located house and
the Factory House approximately 140 m south. The owner’s T-1743 reading of one
dwelling and two outbuildings stays in force.

**What is not done.** No roof, upper storey, white paint, sash, attic light or stack
is invented as a pictorial attestation. No building is moved to fit the panorama;
it is tier-5 form/context material, not a survey control. No camera is installed
and no `pictured` ruling promotes the house’s grade. A cited contextual source
illustration by itself does not establish that the record’s building is depicted.
The 1831 Wau-Bun-derived views are not treated as independent eyewitnesses.

**Next comparison.** Keep candidate identities separate, locate a better original
or reproduction if available, and solve the same panorama against the fort’s
independent surveyed/plan controls and the two separately modeled Beaubien
candidates. A camera fit alone cannot override a failed building identification.
Only after that ruling should a form difference be assigned to this house. T-2378
remains open, and no `matches` verdict is established by this metadata correction.

## 9. Exact keyed-publication annotation strengthens the working identity — T-2378

**23 October 2026, source correction; no geometry change.** Internet Archive’s
`earlychicagofort00wentiala`, Wentworth’s1881 *Fort Dearborn*, printed **pp.86–87**,
was retrieved and both page images opened. Page86 reproduces the exact local keyed
panorama. Directly beneath it is an additional annotation absent from our local crop:

> Gen. Beaubien’s house was near the N.-E. cor. Michigan Avenue and South-Water Street.

That explicitly ties the pictured house to the same retrospective corner by which
this record is located. **The preferred working identification is therefore this
sale-located homestead, at inferred confidence.** This supersedes §8’s narrower
statement that only the bare house key and Wau-Bun geography were available. It
is the same1881 Wentworth witness as the sale narrative, not independent
corroboration. Neither the annotation nor the sale establishes which earlier
Beaubien building or new residence this corner house was. The separately modeled
Factory House140m south retains its own squared-log/two-storey evidence; those
details are not transferred to this record.

Hubbard’s letter of20July1881 starts under this cut and continues on p.87:

> It is certainly unlike the Fort and surroundings, as I recollect them.

He specifically corrects the fort’s high elevation, pointed shore/river bends,
relative blockhouse height and omission of the circa1824–25 brick building. His
suggestion that the engraver worked without Kinzie’s correction is probable,
not proven. An exact common-camera fit must not move surveyed coordinates or
terrain to these pictorial errors. Wau-Bun’s printed1857 credit is preserved;
the exact edition in which the cut first appeared is still not established.

**Next bounded comparison:** with identity now preferred rather than entirely
unjoined, isolate the keyed house’s visible form and test the current one-storey
model against it using a declared provisional drawing camera. Treat possible
upper-storey, gable, window and chimney readings as questions until actual pixels
and render are compared. Retain the1831-to1835 survival assumption explicitly.
No numerical form, confidence, mesh, placement, camera, pictured ruling or match
verdict changes in this source correction. T-2378 remains open.

Exact page images and fetch hashes are preserved in the read-only proposal’s
`PRIMARY-FINDING.md` and `FETCH-MANIFEST.json`; these are evidence artifacts, not
published payload. Readable printed86/87 were fetched from archive download
`page/n95.jpg` and `page/n96.jpg`; the endpoint differs from the leaf labels in
the page-number JSON, so the actual printed numerals were checked visually.
