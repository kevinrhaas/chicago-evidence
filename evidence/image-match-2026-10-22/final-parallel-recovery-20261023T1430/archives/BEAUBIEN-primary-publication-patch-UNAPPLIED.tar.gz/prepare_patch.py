from pathlib import Path
import json,difflib,hashlib,copy
root=Path('/workspace/chicago');out=Path(__file__).parent
paths={}; sid='kinzie_1857_chicago_1831_panorama'
p='chicago/4d/data/sources/'+sid+'.json';old=(root/p).read_text();s=json.loads(old)
s['citation']='[Inferred Beaubien residence] “Fort Dearborn and Chicago in 1831.” Keyed cut in Wentworth, Fort Dearborn (1881), p. 86; credits Kinzie’s Wau-Bun (1857).'
s['date']='1881 reproduction; printed credit 1857'
s['repository']='Internet Archive, digitized Fergus Historical Series pamphlet; keyed reproduction also held on Wikimedia Commons'
s['url']='https://archive.org/stream/earlychicagofort00wentiala#page/86/mode/1up'
s['locator']='John Wentworth, Fort Dearborn (Fergus Historical Series No. 16, 1881), printed pp. 86–87: the exact keyed panorama, its explanatory corner annotation, and G. S. Hubbard’s letter dated 20 July 1881. Actual downloaded page images were visually read. The local 1920 by 1042 reproduction is chicago/reference/images/chicago/chicago_fort_dearborn_1831_1.jpg.'
s['access_notes']='Fresh Commons imageinfo metadata identifies Wentworth’s pamphlet as the source. Internet Archive metadata, OCR and printed pp. 86–87 were retrieved on 23 October 2026; both actual page images were visually opened. Page 86 repeats the same keyed cut and adds the corner annotation quoted in the note. Page 87 carries Hubbard’s criticism. The archive download/page/n95.jpg and n96.jpg endpoints were checked against their printed numerals; page-number JSON leaf numbers did not map directly to that endpoint. The exact original Wau-Bun edition remains unestablished: this verifies the 1881 keyed reproduction, not an 1857 first appearance.'
s['note']='PREFERRED WORKING IDENTIFICATION, INFERRED FROM THE SAME RETROSPECTIVE WITNESS. Immediately beneath the exact keyed cut, Wentworth’s printed p. 86 states: “Gen. Beaubien’s house was near the N.-E. cor. Michigan Avenue and South-Water Street.” This explicitly associates the pictured house with the retrospective corner used by the sale-located homestead record and makes that record the preferred working identification over the separately modeled Factory House. It is Wentworth 1881, the same witness as the sale narrative, not independent corroboration or an 1831 survey. It does not establish whether the corner dwelling was a new residence or an earlier building, nor transfer the Factory House’s squared-log fabric or two storeys. HUBBARD’S CRITICISM IS PART OF THIS SAME PUBLICATION: his letter of 20 July 1881, pp. 86–87, says the cut is “certainly unlike the Fort and surroundings, as I recollect them.” He corrects the fort’s high ground, sharp point and river bends, blockhouse height and missing circa 1824–25 brick building. His suggestion that the sketch was engraved without Kinzie’s correction is explicitly probable, not proven. Do not distort surveyed positions or terrain to force this drawing. The credited 1831 view remains retrospective tier-5 form evidence, with survival to July 1835 unproved. No form measurements, camera, pictured-grade ruling or match verdict are added. The Wau-Bun-derived 1831 pair are not independent eyewitnesses.'
s['what_it_supplies']=['the exact keyed 1831 panorama in an independently inspected 1881 publication','Wentworth’s explicit annotation placing the keyed Beaubien house near Michigan Avenue and South Water Street’s northeast corner','a preferred, inferred identification with the sale-located homestead, subject to the same-witness and drawing-accuracy limits','Hubbard’s contemporary-to-publication criticism of this drawing’s geography and fort buildings']
s['what_it_does_not_supply']=['independent corroboration of Wentworth’s sale narrative or an 1831 surveyed position','which earlier or later Beaubien building stood at that corner','the Factory House’s separately documented squared-log fabric or two storeys for this dwelling','a calibrated camera, metric dimensions, accepted form or proof of unchanged appearance in July 1835','an accepted image match or independent eyewitness status for two Wau-Bun-derived reproductions']
paths[p]=(old,json.dumps(s,ensure_ascii=False,indent=2)+'\n')
p='chicago/4d/data/structures/jb_beaubien_homestead.json';old=(root/p).read_text();d=json.loads(old);phase=d['phases'][0]
phase['form']['construction']['note']='Log remains the existing inferred reading from settlement building practice, not an attested material for this residence. Beaubien’s 1817 purchase concerned the separate Dean house; 1822 is an earliest allowed date rather than a known building year. Wentworth’s annotation beneath the keyed 1831 panorama places its Beaubien house near the same northeast corner used for this sale-located dwelling, making this the preferred working identification at inferred confidence. Both locators come from Wentworth, not independent witnesses. The building’s lineage and July 1835 appearance remain unresolved. No pictured material, Factory House description or numerical form is transferred here.'
phase['change_note']='Modelled as one Beaubien residence with a barn and trading post. Wentworth’s annotation beneath the keyed 1831 picture places its Beaubien house near the same northeast corner used for this dwelling: a preferred, inferred identification from the same retrospective witness as the sale narrative. Exact building lineage, construction year and appearance remain unknown. The U.S. Factor’s House is separately modelled about 140 m south; its two-storey description is not transferred. Existing form and grades stay unchanged pending an actual picture comparison. Beaubien’s reservation claim was dated 28 May 1835 and recorded 26 June.'
oldlead,history=d['research_note'].split('\n\nHISTORICAL RESEARCH RECORD',1)
d['research_note']='CURRENT IDENTITY AND IMAGE READING — T-2378. The existing record represents one Beaubien dwelling with a barn and trading post under the owner’s T-1743 reading. Freshly inspected Wentworth 1881 printed p. 86 reproduces the exact keyed panorama ('+sid+') and states beneath it: “Gen. Beaubien’s house was near the N.-E. cor. Michigan Avenue and South-Water Street.” This explicit picture annotation supports the sale-located homestead as the preferred working identification, at inferred confidence. Both corner locators are Wentworth, so this is a stronger reading of one witness, not independent corroboration. The precise lineage of the corner dwelling remains unresolved; the 1817 purchase was the separate Dean house, and 1822 is a lower bound rather than a known building year. The separate Factory House about 140 m south keeps its own description; no squared-log fabric or two-storey evidence is borrowed. On pp. 86–87, Hubbard explicitly criticizes this cut’s fort heights, terrain and river geography; those errors must not be imposed on surveyed positions. No storey count, material, opening, chimney, numerical form, camera or pictured-grade ruling changes here. Survival of its depicted 1831 form to July 1835 is not established.\n\nHISTORICAL RESEARCH RECORD'+history
paths[p]=(old,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
p='chicago/4d/docs/RESEARCH/jb_beaubien_homestead.md';old=(root/p).read_text()
add='''
## 9. Exact keyed-publication annotation strengthens the working identity — T-2378

**23 October 2026, source correction; no geometry change.** Internet Archive’s
`earlychicagofort00wentiala`, Wentworth’s1881 *Fort Dearborn*, printed **pp.86–87**,
was retrieved and both page images opened. Page86 reproduces the exact local keyed
panorama. Directly beneath it is an additional annotation absent from our local crop:

> Gen. Beaubien’s house was near the N.-E. cor. Michigan Avenue and South-Water Street.

That explicitly ties the pictured house to the same retrospective corner by which
this record is located. **The preferred working identification is therefore this
sale-located homestead, at inferred confidence.** This supersedes §8’s narrower
statement that only the bare house key and Wau-Bun geography were available. It
is the same1881 Wentworth witness as the sale narrative, not independent
corroboration. Neither the annotation nor the sale establishes which earlier
Beaubien building or new residence this corner house was. The separately modeled
Factory House140m south retains its own squared-log/two-storey evidence; those
details are not transferred to this record.

Hubbard’s letter of20July1881 starts under this cut and continues on p.87:

> It is certainly unlike the Fort and surroundings, as I recollect them.

He specifically corrects the fort’s high elevation, pointed shore/river bends,
relative blockhouse height and omission of the circa1824–25 brick building. His
suggestion that the engraver worked without Kinzie’s correction is probable,
not proven. An exact common-camera fit must not move surveyed coordinates or
terrain to these pictorial errors. Wau-Bun’s printed1857 credit is preserved;
the exact edition in which the cut first appeared is still not established.

**Next bounded comparison:** with identity now preferred rather than entirely
unjoined, isolate the keyed house’s visible form and test the current one-storey
model against it using a declared provisional drawing camera. Treat possible
upper-storey, gable, window and chimney readings as questions until actual pixels
and render are compared. Retain the1831-to1835 survival assumption explicitly.
No numerical form, confidence, mesh, placement, camera, pictured ruling or match
verdict changes in this source correction. T-2378 remains open.

Exact page images and fetch hashes are preserved in the read-only proposal’s
`PRIMARY-FINDING.md` and `FETCH-MANIFEST.json`; these are evidence artifacts, not
published payload. Readable printed86/87 were fetched from archive download
`page/n95.jpg` and `page/n96.jpg`; the endpoint differs from the leaf labels in
the page-number JSON, so the actual printed numerals were checked visually.
'''
paths[p]=(old,old+add)
patch=[];hashes={}
for p,(a,b) in paths.items():
 dest=out/'proposed'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(b)
 hashes[p]={'before_sha256':hashlib.sha256(a.encode()).hexdigest(),'after_sha256':hashlib.sha256(b.encode()).hexdigest()}
 patch.append(f'diff --git a/{p} b/{p}\n');patch.extend(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p))
(out/'T-2378-primary-source.patch').write_text(''.join(patch));(out/'PATCH-HASHES.json').write_text(json.dumps({'base_head':'792598d88','files':hashes},indent=2)+'\n')
print(out/'T-2378-primary-source.patch')
