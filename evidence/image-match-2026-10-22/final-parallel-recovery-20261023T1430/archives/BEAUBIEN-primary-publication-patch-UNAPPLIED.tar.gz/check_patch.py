from pathlib import Path
import json,sys,copy,hashlib
import jsonschema
ROOT=Path('/workspace/chicago/chicago/4d');OUT=Path(__file__).parent;PROP=OUT/'proposed/chicago/4d'
sys.path[:0]=[str(ROOT/'tools'),str(ROOT/'generators')]
import mesh_inputs,compile_pictures as cp,grade_structures as gs,compile_source_use as cs
sid='jb_beaubien_homestead';sourceid='kinzie_1857_chicago_1831_panorama'
a=json.loads((ROOT/'data/structures'/f'{sid}.json').read_text());b=json.loads((PROP/'data/structures'/f'{sid}.json').read_text());s=json.loads((PROP/'data/sources'/f'{sourceid}.json').read_text())
jsonschema.validate(b,json.loads((ROOT/'data/structures.schema.json').read_text()));jsonschema.validate(s,json.loads((ROOT/'data/source.schema.json').read_text()))
x=copy.deepcopy(a);y=copy.deepcopy(b)
for r in [x,y]:r.pop('research_note');r['phases'][0].pop('change_note');r['phases'][0]['form']['construction'].pop('note')
assert x==y
assert mesh_inputs.structure_inputs_sha(a,a['phases'][0])==mesh_inputs.structure_inputs_sha(b,b['phases'][0])
sources={p.stem:json.loads(p.read_text()) for p in (ROOT/'data/sources').glob('*.json')}
p0=cp.derive(None,'',sources,{sid:json.dumps(a)},{'1835':[sid]}, {})['1835']['by_structure'].get(sid,[])
sources[sourceid]=s
p1=cp.derive(None,'',sources,{sid:json.dumps(b)},{'1835':[sid]}, {})['1835']['by_structure'].get(sid,[])
e=next(e for e in p1 if e['id']==sourceid);assert e['title'].startswith('[Inferred Beaubien residence]')
assert e['url']==s['url']
rulings=json.loads((ROOT/'data/structure_grades.json').read_text());cams=[]
for p in (ROOT/'data/reference_views'/sid).glob('*.json'):
 if not p.name.endswith('.match.json'):cams.append(json.loads(p.read_text()))
g0=gs.grade_structure(sid,a['phases'][0]['documented_range']['confidence'],p0,cams,rulings,'1835');g1=gs.grade_structure(sid,b['phases'][0]['documented_range']['confidence'],p1,cams,rulings,'1835');assert g0==g1
indexfile=ROOT/'data/sidecars/1835/sources/index.json';raw=indexfile.read_bytes();index=json.loads(raw);row=next(x for x in index['sources'] if x['source_id']==sourceid)
c=cs.Compiler(ROOT);row['citation']=c.say(s['citation']);row['date']=s['date']
new=cs.packed(index).encode();assert len(new)<=cs.INDEX_BUDGET
print('PASS: real source/structure schemas; exactly three structure prose fields changed; all form values, confidences, position and footprint preserved.')
print('PASS: mesh input SHA unchanged',mesh_inputs.structure_inputs_sha(b,b['phases'][0]))
print('PASS: actual Photos compiler yields inferred-identification title and exact publication link.')
print('PASS: actual grade function unchanged',g1)
print('PASS: compact-index row replacement estimate',len(raw),'->',len(new),'delta',len(new)-len(raw),'cap',cs.INDEX_BUDGET,'headroom',cs.INDEX_BUDGET-len(new))
print('Not a full compiler/gate run; parent must rederive the actual combined candidate. No camera/render/match is claimed.')
