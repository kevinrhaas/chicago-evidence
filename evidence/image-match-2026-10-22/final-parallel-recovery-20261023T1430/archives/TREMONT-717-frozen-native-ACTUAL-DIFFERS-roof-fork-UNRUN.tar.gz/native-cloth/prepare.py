"""Freeze read-only production inputs into an isolated diagnostic. No browser/export."""
from pathlib import Path
import hashlib,json,shutil
ROOT=Path('/workspace/chicago/chicago/4d'); OUT=Path(__file__).parent; F=OUT/'fixture'
assert not F.exists(),'Keep frozen fixtures immutable; choose a new packet to refresh.'
copies={}
def copy(src,rel):
 dst=F/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);copies[rel]={'original':str(src),'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'bytes':src.stat().st_size}
for rel in ['renderers/web/js','renderers/web/vendor/three-0.185.1']:
 for src in sorted((ROOT/rel).rglob('*')):
  if src.is_file():copy(src,str(src.relative_to(ROOT)))
for rel in ['roofs/wood_shingles_weathered','roofs/roof_boards_weathered','walls/clapboard_board_face','walls/hewn_log_face']:
 base=ROOT/'assets/textures/chicago_1835_pbr'/rel
 for src in sorted(base.rglob('*')):
  if src.is_file():copy(src,str(src.relative_to(ROOT)))
for rel in ['assets/LICENSES.md','assets/gltf/tremont_house_1__frame_1833.glb','data/sidecars/1835/tremont_house_1.json','data/terrain/epochs/e1834_harbor_cut/heightfield.json','data/terrain/epochs/e1834_harbor_cut/heightfield.bin','data/structures/tremont_house_1.json','data/sources/gifford_tremont_house_no_1.json']:
 copy(ROOT/rel,rel)
copy(Path('/workspace/chicago/chicago/reference/images/chicago/chicago_first_tremont_house_1833.jpg'),'source.jpg')
copy(Path('/tmp/chicago-next-model/T-2385-roof-tone-next/fixture/review/after/gifford-roof-tone.json'),'camera.json')
assert copies['assets/gltf/tremont_house_1__frame_1833.glb']['sha256']=='ed3c2605c9c3c584511e3e093a4b57facff7854b29e9a73354891297708a244a'
assert copies['camera.json']['sha256']=='16830ecda2efde0b4ccdb028bc559fb88529711a11b9cb0f05adbf4e8294bda2'
assert copies['source.jpg']['sha256']=='b45d60680a0a519e561a7293bec824675d6014a6cac4da31a38ddc70d1323e59'
(OUT/'frozen-inputs.json').write_text(json.dumps({'source_root':str(ROOT),'files':copies,'purpose':'Exact production modules/assets frozen for isolated one-building native-runtime flag drawing; no official build or image-match acceptance.'},indent=2)+'\n')
print(f'Frozen {len(copies)} files, {sum(x["bytes"] for x in copies.values())} bytes; no production file modified.')
