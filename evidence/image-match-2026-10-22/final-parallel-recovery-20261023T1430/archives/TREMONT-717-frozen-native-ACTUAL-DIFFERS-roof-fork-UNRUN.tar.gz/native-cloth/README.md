# Ready-to-execute isolated native roof-cloth diagnostic

**Authorized capture completed exit0 and actual images reviewed; still differs.** See `runs/authorized-792598d/REVIEW.md` and `ACTUAL-REVIEW.json`. Root granted the bounded normal/confidence capture after strict gatePASS1056/commit792598d. Execsession69528, browser and server are closed; slot released. Exact frozen inputs/adapters remained unchanged. No export, wind/material alternative or acceptance occurred. Any additional capture requires another root slot release; T-2385 stays open and its camera provisional.

Dry validation (safe/light, browser never imported or launched):

```bash
node /tmp/chicago-next-model/T-2385-next-review/native-cloth/run.mjs --dry
```

After root releases the slot:

```bash
node /tmp/chicago-next-model/T-2385-next-review/native-cloth/run.mjs --capture
```

The runner closes browser and ephemeral server even on failure. Existing output directories are never overwritten. Optionally supply `--out /tmp/<new-output-directory>`. Playwright resolves from `/workspace/node_modules`; `PLAYWRIGHT_REQUIRE_ROOT` can supply another Node resolution root and `PW_EXECUTABLE` another existing browser. No installation/download is attempted.

## What is native and exact

- Exact current master SHA256`ed3c2605c9c3c584511e3e093a4b57facff7854b29e9a73354891297708a244a`; no GLB bake, UV edit, asset replacement or duplicate cloth.
- Exact provisional Gifford camera SHA256`16830ecda2efde0b4ccdb028bc559fb88529711a11b9cb0f05adbf4e8294bda2`, original source photoSHA256`b45d60680a0a519e561a7293bec824675d6014a6cac4da31a38ddc70d1323e59`; no fit or camera reauthoring.
- Production `createBuildings`, `createFlags`, `flagMount`, `createConfidenceView`, facade/weathering, grade, roof/wall relief and heightfield modules are copied byte-for-byte from root M. They execute actual normal production entry points, not rewritten lookalikes or a test-injected flag polygon.
- The actual canonical phase sidecar selects phaseframe_1833/date1835-07-01. The flag uses existing phase/date-local anchor and24-star pattern, fly1.85m/hoist1.3m. This does not date Gifford's undated scene or shorten the building phase.
- Native `createBuildings` owns the complete instance matrix and actual bounds. The camera eye/orientation is transformed through `buildings.matrixOf('tremont_house_1')`, not a duplicate placement formula. At runtime six control points must project within1e-6px of the frozen camera's analytic values before capture. Matrix elements and projection controls are reported.
- Production `Heightfield.adopt/sample` reads the frozen actual epoch grid. A thin terrain interface provides `surfaceHeight` to the unchanged native `groundUnder`; no guessed ground elevation. The hotel and sampled feet lie within this grid; no distant coast/apron is needed for this selected building.
- Production flags retain their default windFROM225°/TO45°. Actual `flags.update(.15)` runs once, then update0 holds time. No wind or pose alternative is activated. The actual holder orientation and actual GPU time must confirm this default; reading the constant alone is not the capture proof.
- Confidence uses actual production grade modes and shader patch. The normal and confidence screenshots use the same flag instance and held time. Reconstructed cloth must haveconfidence1 and the real linked GPU reconstructed mode dither/opacity0.34.

## Exact adapter limits

This is an **isolated one-building native-runtime diagnostic**, not the complete published town app. `fixture/renderers/web/diagnostic.mjs` is the thin authored adapter: it supplies the actual model/sidecar registry, loads the production layers, sets the frozen source camera, controls time, observes GPU draws and exposes one render function. It does not implement flag/anchor/grade/weathering geometry or shaders.

Lighting and a flat comparison ground plane retain the earlier photo_match study's controlled setup, transformed through the actual building matrix. This is deliberately labelled comparison lighting/ground, not a surveyed sun, app atmospheric view or rebuilt native terrain surface. Native building relief/tonal treatment remains enabled, so an observed roof-tone difference from the earlier raw-loader photo_match may arise from the production reader. The registry contains only this building; any facade-tone algorithm depending on neighbours sees that explicit subset. No claim of full-town tone parity is made.

This Tremont driver supports its current level/yaw camera only. It must not be reused for a fort's inclined `basis_right_up_forward` camera without an explicit basis adapter; parent/fort reviewer has been informed. The first-fort staff may use the existing legacy standalone bounding-box mount, but requires all relevant group members/native matrices and its own phase/date—no hotel anchor substitution.

## Actual GPU proof, not synthetic uniforms

The production flag's real `onAfterRender` observes the linked active program. It reads actual GPU`modelViewMatrix`, `projectionMatrix`, `uFlagTime`, `uConfMode`, `uGradeMode`, `uGradeOpacity` and `uHideLevel`; compares matrices to the actual drawn mesh/camera transforms; and hashes the actual linked vertex/fragment shader sources. It refuses missing uniforms, wrong time, wrong matrices, duplicate/missing cloth or broken confidence controls. Actual scene model/camera matrices, holder, native wind bearing, phase/date,495 cloth vertices and confidence values are recorded.

Reported projected static bounds explicitly omit the production shader's flutter. The screenshot is the actual GPU output. No CPU cloth simulation, copied old screenshot, synthetic projected polygon or manually generated flag is accepted as proof. Side-by-side review images pair the original source bytes with the just-captured actual canvas image.

Expected outputs under a new runs directory:

- `normal.png`, `confidence.png` — exact1637×796 actual native canvas captures.
- `normal.json`, `confidence.json` — actual draw/matrix/uniform/input hash receipts.
- `source-vs-native-normal.png`, `source-vs-native-confidence.png` — complete source/capture comparisons,3298×796.
- `requests.json`, `run.json` — local input-read hashes, errors and scope; any refusal writes`failure.json`.

No match JSON is written; no ticket, accepted reference_views, canonical file or GitHub state changes. Root/agent must open actual captures and document the residual cloth direction/shape/mount/grade differences before deciding next work.

## Freeze and dry checks

`frozen-inputs.json` holds328 exact production/source/asset files (~32MB), including original asset licence ledger. `adapter-inputs.json` separately hashes the three authored fixture files and runner. The runner refuses changed frozen inputs or adapters before importing Playwright. Production modules are not patched. `prepare.py` refuses to overwrite an existing fixture; do not refresh this packet in place.

Dry checks passed: all frozen hashes; exact model/camera/photo; model extras and identity master-node bounds; actual pure production `flagMount` acceptance with the canonical phase/date; reconstructed flag/flying/anchor grades; native wind constant; complete72-module static import closure including vendored Three/addons. `node --check` passed for the runner and browser adapter. Initial dry validation preceded capture. The authorized run subsequently passed actual shader linking, GPU matrix/uniform checks and93local input requests with0HTTP/page/native-producer errors; see its immutable receipts.

Gifford credit remains N. Roswell Gifford, reproduced Chicagology<https://chicagology.com/prefire/prefire021/>. Owner approved attributed project reference/comparison/source display; original publication/collection/copyright remain unresolved. No public-domain/general redistribution finding is made. See the frozen source record and root's adopted two-row source-credit correction.
