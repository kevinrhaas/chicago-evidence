# Actual native capture reviewed — still differs

Authorized after root M strict gatePASS1056/commit792598d. Execsession69528 completedexit0; browser and ephemeral server closed, slot released to parent/fort reviewer. No retries or fixture/assertion changes occurred during capture.

Opened both complete source/native normal and confidence comparisons. Cloth really draws on the roof spar at the exact frozen Gifford camera/current ed3c master. The actual default native wind makes it appear as a thin nearly vertical strip to image-right of staff, while Gifford has a broad flag extending image-left. This confirms the predicted pose/foreshortening gap; it is not evidence for changing the correct local anchor. Static plane bounds are about4.87px wide, explicitly excluding shader flutter; the real screenshot shows the mismatch independently.

GPU evidence: actual linked program, source projection/modelview matrices equal across modes, heldtime0.150000006, actual windTO45deg,495vertices and reconstructedconfidence1. Confidence GPUmode1 uses reconstructed dither2/opacity0.34. No native producer problems, page errors or localHTTPerrors. Control-point projection equality to unchanged source camera passed.

Roof remains pale tan relative to source dark hatching; dark kit entries and other window/shutter/entry/stack/arch/context differences remain. No lighting/material/wind alternatives were executed. This isolated production-layer diagnostic uses controlled comparison lights/flat ground and a one-building registry, not a complete town atmosphere view. Gifford date, pattern, dimensions and exact pose remain unresolved/reconstructed; original T-2385 remains open and camera provisional.

See ACTUAL-REVIEW.json for hashes, exact input/camera proof and residuals. Preserve this run. A separately authorized held-pose alternative should keep source camera/model/anchor/dimensions fixed and label wind/pose reconstructed, without changing global weather or baking duplicate cloth.
