import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {fileURLToPath,pathToFileURL} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url)),root=path.join(here,'fixture');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const frozen=JSON.parse(fs.readFileSync(path.join(here,'frozen-inputs.json'))),adapter=JSON.parse(fs.readFileSync(path.join(here,'adapter-inputs.json')));
for(const [rel,item]of Object.entries({...frozen.files,...adapter.files}))assert.equal(sha(fs.readFileSync(path.join(root,rel))),item.sha256,`frozen input changed:${rel}`);
assert.equal(sha(fs.readFileSync(fileURLToPath(import.meta.url))),adapter.runner_sha256,'runner changed after freeze');
const camera=JSON.parse(fs.readFileSync(path.join(root,'camera.json'))),sidecar=JSON.parse(fs.readFileSync(path.join(root,'data/sidecars/1835/tremont_house_1.json')));
assert.equal(frozen.files['assets/gltf/tremont_house_1__frame_1833.glb'].sha256,'ed3c2605c9c3c584511e3e093a4b57facff7854b29e9a73354891297708a244a');
assert.equal(frozen.files['camera.json'].sha256,'16830ecda2efde0b4ccdb028bc559fb88529711a11b9cb0f05adbf4e8294bda2');
assert.deepEqual(camera.image_px,[1637,796]);assert.equal(sidecar.id,'tremont_house_1');assert.equal(sidecar.phase,'frame_1833');assert.equal(sidecar.target_date,'1835-07-01');
const flagSource=fs.readFileSync(path.join(root,'renderers/web/js/flags.js'),'utf8');assert.match(flagSource,/const WIND_FROM_DEG = 225;/);assert.match(flagSource,/export function createFlags/);
const bytes=fs.readFileSync(path.join(root,'assets/gltf/tremont_house_1__frame_1833.glb')),glb=JSON.parse(bytes.subarray(20,20+bytes.readUInt32LE(12)).toString());
assert(glb.nodes.some(n=>n.extras?.structure_id==='tremont_house_1'&&n.extras?.phase_id==='frame_1833'));assert(glb.nodes.every(n=>!n.matrix&&!n.translation&&!n.rotation&&!n.scale),'dry bounds require identity master nodes');
const mins=[Infinity,Infinity,Infinity],maxs=[-Infinity,-Infinity,-Infinity];
for(const mesh of glb.meshes)for(const primitive of mesh.primitives){const a=glb.accessors[primitive.attributes.POSITION];assert(a.min&&a.max);for(let i=0;i<3;i++){mins[i]=Math.min(mins[i],a.min[i]);maxs[i]=Math.max(maxs[i],a.max[i]);}}
const {flagMount}=await import(pathToFileURL(path.join(root,'renderers/web/js/flag-anchors.js')));
const mount=flagMount({anchor:sidecar.attributes.flag_anchor.value,phase:sidecar.phase,targetDate:sidecar.target_date},{min:mins,max:maxs},{fly:12*.3048,hoistToFly:1/1.85,truckGap:.18});
assert.equal(mount.fly,1.85);assert.equal(mount.hoist,1.3);assert.equal(sidecar.attributes.flag.confidence,'reconstructed');assert.equal(sidecar.attributes.flag_flying.confidence,'reconstructed');assert.equal(sidecar.attributes.flag_anchor.confidence,'reconstructed');
const visited=new Set();
function dependencies(rel){if(visited.has(rel))return;visited.add(rel);const src=fs.readFileSync(path.join(root,rel),'utf8');for(const m of src.matchAll(/(?:from\s*|import\s*)['"]([^'"\n]+)['"]/g)){let child;if(m[1]==='three')child='renderers/web/vendor/three-0.185.1/three.module.js';else if(m[1].startsWith('three/addons/'))child='renderers/web/vendor/three-0.185.1/addons/'+m[1].slice('three/addons/'.length);else if(m[1].startsWith('.'))child=path.posix.normalize(path.posix.join(path.posix.dirname(rel),m[1]));else continue;assert(fs.existsSync(path.join(root,child)),`unfrozen module import:${rel}->${child}`);dependencies(child);}}
for(const file of ['renderers/web/js/buildings.js','renderers/web/js/flags.js','renderers/web/js/confidence.js','renderers/web/js/terrain.js'])dependencies(file);
const dry={status:'dry validation passed; browser not launched',frozenProductionInputs:Object.keys(frozen.files).length,adapterInputs:Object.keys(adapter.files).length,staticProductionModuleClosure:visited.size,glbSha256:frozen.files['assets/gltf/tremont_house_1__frame_1833.glb'].sha256,cameraSha256:frozen.files['camera.json'].sha256,photoSha256:frozen.files['source.jpg'].sha256,phase:sidecar.phase,targetDate:sidecar.target_date,actualPureFlagMount:mount,defaultProductionWindFromDeg:225,limits:'Browser linking/capture and visual review remain required; no match verdict.'};
fs.writeFileSync(path.join(here,'dry-validation.json'),JSON.stringify(dry,null,2)+'\n');console.log(JSON.stringify(dry));
if(!process.argv.includes('--capture'))process.exit(0);
const opt=k=>{const i=process.argv.indexOf(k);return i<0?null:process.argv[i+1];};
const out=path.resolve(opt('--out')||path.join(here,'runs',new Date().toISOString().replaceAll(':','-')));assert(!fs.existsSync(out),'refuse to overwrite a prior diagnostic run');fs.mkdirSync(out,{recursive:true});
const require=createRequire(path.join(process.env.PLAYWRIGHT_REQUIRE_ROOT||'/workspace','package.json')),{chromium}=require('playwright');
const mime={'.js':'text/javascript','.mjs':'text/javascript','.html':'text/html','.json':'application/json','.glb':'model/gltf-binary','.jpg':'image/jpeg','.png':'image/png','.webp':'image/webp','.bin':'application/octet-stream','.ktx2':'image/ktx2'};
const requests=[],errors=[];
const server=http.createServer((req,res)=>{const u=new URL(req.url,'http://localhost');let decoded;try{decoded=decodeURIComponent(u.pathname);}catch{res.writeHead(400);res.end();return;}const p=path.resolve(root,'.'+decoded);if(!p.startsWith(root+path.sep)||!fs.existsSync(p)||!fs.statSync(p).isFile()){requests.push({path:decoded,status:404});res.writeHead(404);res.end();return;}requests.push({path:decoded,status:200,sha256:sha(fs.readFileSync(p))});res.writeHead(200,{'Content-Type':mime[path.extname(p)]||'application/octet-stream'});fs.createReadStream(p).pipe(res);});
let browser;
try{
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});const base=`http://127.0.0.1:${server.address().port}`;
 browser=await chromium.launch({executablePath:process.env.PW_EXECUTABLE||'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']});
 const page=await browser.newPage({viewport:{width:1637,height:796},deviceScaleFactor:1});page.on('pageerror',e=>errors.push(e.stack||e.message));
 await page.route('**/*',route=>{const url=new URL(route.request().url());if(url.origin===base||['data:','blob:'].includes(url.protocol))return route.continue();errors.push(`external request refused:${url.href}`);return route.abort();});
 await page.goto(base+'/renderers/web/index.html?assets=/assets/&data=/data/&jobs=0&ktx2=0',{waitUntil:'domcontentloaded',timeout:180000});
 await page.waitForFunction(()=>window.__diagnostic?.ready||window.__diagnostic?.error,null,{timeout:180000,polling:250});
 const setup=await page.evaluate(()=>window.__diagnostic.error);assert(!setup,setup);assert.deepEqual(errors,[]);
 for(const on of [false,true]){
  const mode=on?'confidence':'normal',proof=await page.evaluate(on=>window.__diagnostic.render(on),on);
  assert.equal(proof.nativeProblems.length,0,`native producer problems:${JSON.stringify(proof.nativeProblems)}`);
  proof.inputHashes={glb:dry.glbSha256,camera:dry.cameraSha256,source:dry.photoSha256};proof.frozenInputManifestSha256=sha(fs.readFileSync(path.join(here,'frozen-inputs.json')));proof.adapterManifestSha256=sha(fs.readFileSync(path.join(here,'adapter-inputs.json')));
  fs.writeFileSync(path.join(out,mode+'.json'),JSON.stringify(proof,null,2)+'\n');await page.screenshot({path:path.join(out,mode+'.png'),timeout:180000});
 }
 // A review layout of ORIGINAL source bytes and the just-captured actual GPU
 // canvas images. No synthesized cloth, recolouring, pixel edits or match record.
 await page.setContent('<!doctype html><style>html,body{margin:0}div{display:flex;gap:24px}img{width:1637px;height:796px;display:block}</style><div><img id="source"><img id="native"></div>');
 await page.setViewportSize({width:3298,height:796});
 for(const mode of ['normal','confidence']){
  await page.evaluate(({src,native})=>{document.querySelector('#source').src=src;document.querySelector('#native').src=native;},{src:'data:image/jpeg;base64,'+fs.readFileSync(path.join(root,'source.jpg')).toString('base64'),native:'data:image/png;base64,'+fs.readFileSync(path.join(out,mode+'.png')).toString('base64')});
  await page.waitForFunction(()=>[...document.images].every(i=>i.complete&&i.naturalWidth===1637));await page.screenshot({path:path.join(out,'source-vs-native-'+mode+'.png'),timeout:180000});
 }
 assert.deepEqual(errors,[]);assert.deepEqual(requests.filter(r=>r.status>=400),[]);
 fs.writeFileSync(path.join(out,'requests.json'),JSON.stringify(requests,null,2)+'\n');fs.writeFileSync(path.join(out,'run.json'),JSON.stringify({status:'actual native drawing captured; human review required',inputs:dry,errors,limits:'Diagnostic only, controlled photo_match lights/flat plane, selected one-building production registry. Not a full-town screenshot or acceptance. Original T-2385 remains open.'},null,2)+'\n');console.log(`Native runtime capture complete:${out}`);
}catch(error){fs.writeFileSync(path.join(out,'failure.json'),JSON.stringify({error:error.stack||error.message,errors,requests},null,2)+'\n');throw error;}
finally{if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));}
