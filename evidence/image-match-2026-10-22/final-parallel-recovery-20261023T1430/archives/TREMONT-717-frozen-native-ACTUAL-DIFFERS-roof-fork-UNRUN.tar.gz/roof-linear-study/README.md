# Frozen roof-only material study — PREPARED/DRY ONLY

No study capture, Blender/export, canonical edit or adopted material has run. Root's user deadline stops new scope; keep this ready for a separately granted short capture or the next session. Original T-2385 stays open; source camera remains provisional.

Safe next command:

```bash
node /tmp/chicago-next-model/T-2385-roof-linear-study-792598d/run.mjs --dry
```

Only after root explicitly grants a browser slot:

```bash
node /tmp/chicago-next-model/T-2385-roof-linear-study-792598d/run.mjs --capture
```

The runner creates a new output directory, captures three normal-only states, and closes browser/server in finally. No retry or input/assertion change may be hidden; failed runs preserve failure.json. Do not rerun preparation-history scripts over the frozen packet.

## Baseline and alternatives

The closed actual native normal screenshot/receipt is copied byte-for-byte into `baseline/`; it uses exact canonical master ed3c2605 and unchanged Gifford camera16830ecda2. Its actual native cloth is correctly mounted but appears edge-on; roof reads pale relative to source. The closed native packet/captures are separately hash-guarded and were not modified by this fork.

Exactly one source material is varied: GLTFLoader's `roof_shingle` linear RGB(0.2941176593,0.2509804070,0.2156862766). No global exposure lowering is proposed.

| Research alternative | Linear RGB multiplier | Expected loader RGB after override |
|---|---:|---|
| linear-0.5 | 0.5 | 0.14705883,0.12549020,0.10784314 |
| linear-0.25 | 0.25 | 0.07352941,0.06274510,0.05392157 |
| linear-0.125 | 0.125 | 0.03676471,0.03137255,0.02696078 |

These are **reconstructed research alternatives**, bracketing a source whose selected roof patch is far darker than the current native/read comparison. They retain the current channel ratios as a bounded experiment, not a claim of historical black/brown pigment, actual age/weather-blackening, a calibrated reflectance or a matches verdict. The source's monochrome painted contrast cannot establish original colour. No candidate is selected for adoption.

## Controlled path and actual readbacks prepared

The fork copies the same328 production/source/asset inputs. Production flags, anchors, buildings, relief, facade/weathering, grade and height sampling are unchanged. Only authored diagnostic adapters differ, and their hashes are frozen separately. `adapter-changes.patch` shows the adapter addition relative to closed native baseline; exact authoritative adapter bytes/hash are in `adapter-inputs.json`.

For each factor the browser must first record actual GLTFLoader material slots, then multiply only that one material's linear RGB. It refuses another changed slot or any non-RGB property change, and hashes actual source geometry/index/normal/UV/confidence streams before/after to prove no geometry mutation.

The real production buildings reader may whiten batch uniforms and put colour into its per-instance texture. Therefore the study records actual `getColorAt` values for each native batch instance, identifies the roof batch by the original material object identity, and checks it consumes the requested factor. The expected original native albedo is separately labelled an evaluation of production `toneFactors`, not an unrendered GPU baseline. Roof onAfterRender must also prove the actual linked GPU sampler is bound to the real native instance-colour texture and record its contents/shader hashes. A changed roof material is always logged; the study never claims same-material parity just because the source GLB hash is unchanged.

Across the three captures it compares actual source geometry, compacted native geometry, all non-roof source materials/native instance colours and reader material properties. Camera/GPU projection/flag modelview, windTO45deg/time0.15, phase/date, clothconfidence1, native grade modes/opacity/hidden levels must equal the actual closed native baseline. Render settings record actual unchanged exposure, light intensity/position, tone mapping and output space. Native material relief/texture identity stays untouched.

One real native canvas state is captured per factor, with its full original-source comparison and receipt. No confidence-mode sweep, alternate wind, doorway material or geometry experiment is included. A one-building native registry and controlled photo_match lights/flat plane remain explicit limits inherited from the baseline; this is not a complete published-town atmospheric scene.

## Dry validation and remaining work

`node --check` passed for runner/adapter; `run.mjs --dry` passed328 input hashes/3 adapter hashes/72-module closure, fixed factor set and actual pure flagMount phase/date bounds. Closed parent packet/capture hashes also pass. Browser linking of the new roof sampler observation and actual three-factor invariants remain unexecuted; an actionable refusal must be reported rather than relaxed silently.

No official recipe freshness changes arise from preparation. If a factor is later chosen, it needs an honest consumed producer parameter or other approved material implementation, reconstructed note/liberty and an actual fresh canonical build/reader review. Never restamp old GLB hashes or say a runtime override is already the adopted master. Parent owns originalT-2385/pendingM placement, canonical edits, gates and PR decisions.
