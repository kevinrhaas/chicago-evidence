// Isolated diagnostic adapter; all building/flag/anchor/grade/height sampling
// implementations are imported byte-for-byte from frozen production modules.
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { createBuildings } from './js/buildings.js';
import { createFlags } from './js/flags.js';
import { createConfidenceView } from './js/confidence.js';
import { Heightfield } from './js/terrain.js';
import { toneFactors } from './js/facades.js';
const need=(v,msg)=>{if(!v)throw new Error(msg);};
const get=async p=>{const r=await fetch(p);need(r.ok,`input ${p}: HTTP${r.status}`);return r;};
const sha=async text=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text)))].map(v=>v.toString(16).padStart(2,'0')).join('');

const byteSha=async array=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new Uint8Array(array.buffer,array.byteOffset,array.byteLength)))].map(v=>v.toString(16).padStart(2,'0')).join('');
async function geometryReadback(geometry){
 const attributes={};for(const [name,a]of Object.entries(geometry.attributes).sort()){
  const array=a.array??a.data?.array;need(array,`geometry attribute has no readable bytes:${name}`);
  attributes[name]={count:a.count,itemSize:a.itemSize,normalized:a.normalized,constructor:array.constructor.name,stride:a.data?.stride??null,offset:a.offset??null,sha256:await byteSha(array)};
 }
 const index=geometry.getIndex();return{attributes,index:index?{count:index.count,constructor:index.array.constructor.name,sha256:await byteSha(index.array)}:null};
}
const materialReadback=m=>({name:m.name,type:m.type,linearRgb:m.color.toArray(),opacity:m.opacity,metalness:m.metalness,roughness:m.roughness,side:m.side,transparent:m.transparent,map:m.map?.name??null,emissive:m.emissive?.toArray()??null,emissiveIntensity:m.emissiveIntensity??null});
const factor=Number(new URLSearchParams(location.search).get('roof_factor'));
need([.5,.25,.125].includes(factor),'roof_factor must be one of the three frozen research alternatives');
window.__diagnostic={ready:false,error:null};
try {
 const [cam,sidecar,meta,bin]=await Promise.all([(await get('/camera.json')).json(),(await get('/data/sidecars/1835/tremont_house_1.json')).json(),(await get('/data/terrain/epochs/e1834_harbor_cut/heightfield.json')).json(),(await get('/data/terrain/epochs/e1834_harbor_cut/heightfield.bin')).arrayBuffer()]);
 need(sidecar.id==='tremont_house_1'&&sidecar.phase==='frame_1833'&&sidecar.target_date==='1835-07-01','wrong canonical sidecar phase/date');
 const gltf=await new GLTFLoader().loadAsync('/assets/gltf/tremont_house_1__frame_1833.glb');
 let identified=false;gltf.scene.traverse(o=>{if(o.userData?.structure_id==='tremont_house_1'&&o.userData?.phase_id==='frame_1833')identified=true;});need(identified,'exact master extras absent');
 const sourceMeshes=[];const uniqueMaterials=[];
 gltf.scene.traverse(o=>{if(o.isMesh){sourceMeshes.push(o);for(const m of(Array.isArray(o.material)?o.material:[o.material]))if(!uniqueMaterials.includes(m))uniqueMaterials.push(m);}});
 const loaderBaseline=uniqueMaterials.map(materialReadback);
 const sourceGeometryBefore=await Promise.all(sourceMeshes.map(async o=>({name:o.name,geometry:await geometryReadback(o.geometry)})));
 const roofMaterials=uniqueMaterials.filter(m=>m.name==='roof_shingle');need(roofMaterials.length===1,'expected one explicit master roof material');
 const canonical=[.29411765933036804,.250980406999588,.21568627655506134];
 need(roofMaterials[0].color.toArray().every((v,i)=>Math.abs(v-canonical[i])<1e-8),'actual GLTFLoader baseline differs from canonical roof factor');
 roofMaterials[0].color.multiplyScalar(factor); // ONLY intentional experiment mutation, before native reader
 const loaderModified=uniqueMaterials.map(materialReadback);
 const changedMaterials=loaderBaseline.map((old,i)=>({slot:i,before:old,after:loaderModified[i]})).filter(row=>JSON.stringify(row.before)!==JSON.stringify(row.after));
 need(changedMaterials.length===1&&changedMaterials[0].before.name==='roof_shingle','unexpected non-roof loader material change');
 const check={...changedMaterials[0].after,linearRgb:changedMaterials[0].before.linearRgb};need(JSON.stringify(check)===JSON.stringify(changedMaterials[0].before),'roof experiment changed more than linear RGB');
 const sourceGeometryAfter=await Promise.all(sourceMeshes.map(async o=>({name:o.name,geometry:await geometryReadback(o.geometry)})));
 need(JSON.stringify(sourceGeometryAfter)===JSON.stringify(sourceGeometryBefore),'source geometry changed during material-only override');
 const registry=new Map([['tremont_house_1',{id:'tremont_house_1',sidecar,gltf}]]);
 const field=new Heightfield();field.adopt(meta,bin);
 const terrain={surfaceHeight:(e,n)=>field.sample(e,n)};
 const confidence=createConfidenceView();
 const buildings=await createBuildings({registry,confidence,terrain});
 const nativeBatchReadback=[];
 const nativeTone=buildings.facadeTones().tremont_house_1;
 const expectedOriginalNativeRoof=canonical.map((v,i)=>v*toneFactors(...canonical,nativeTone)[i]);
 for(const [batchIndex,batch]of buildings.batches.entries()){
  const roof=roofMaterials.includes(batch.material);const colors=[];
  for(let i=0;i<batch.instanceCount;i++)colors.push(batch.getColorAt(i,new THREE.Color()).toArray());
  if(roof)for(const color of colors)need(color.every((v,i)=>Math.abs(v-expectedOriginalNativeRoof[i]*factor)<1e-6),'actual native roof instance colour does not consume requested linear multiplier');
  nativeBatchReadback.push({batchIndex,roof,material:materialReadback(batch.material),geometry:await geometryReadback(batch.geometry),instanceColors:colors});
 }
 const roofBatches=buildings.batches.filter(batch=>roofMaterials.includes(batch.material));need(roofBatches.length===1,'cannot identify actual native roof batch by original material identity');
 const materialStudy={label:`RECONSTRUCTED research alternative: roof-only linear RGB x${factor}; no historical pigment claim`,factor,loaderBaseline,loaderModified,changedMaterials,sourceGeometryUnchanged:true,sourceGeometryBefore,nativeBatchReadback,nativeWeathering:buildings.weathering,nativeTone,expectedOriginalNativeRoof,expectedBaselineLimit:'Expected original native roof albedo is evaluated with the actual production toneFactors; actual loaded baseline material and actual modified batch getColorAt readbacks are separately recorded. No unrendered baseline is called a GPU capture.'};
 const problems=[...buildings.problems];
 const matrix=buildings.matrixOf('tremont_house_1');
 const box=buildings.instanceBounds().tremont_house_1;
 need(matrix&&box,'native building failed to draw');
 const scene=new THREE.Scene();scene.background=new THREE.Color(0xe8ecef);scene.add(buildings.group);
 // Keep the source-camera study's lighting, rotated through the SAME native
 // building placement as its camera. This is controlled comparison lighting,
 // not a claimed historic/native world sun. Native material relief/tones are live.
 scene.add(new THREE.HemisphereLight(0xdfe8f0,0x8a8070,1.1));
 const light=new THREE.DirectionalLight(0xfff4e0,2.4);light.castShadow=true;
 const origin=new THREE.Vector3().setFromMatrixPosition(matrix);
 const sourceSun=new THREE.Vector3(cam.sun_uvy[0],cam.sun_uvy[2],-cam.sun_uvy[1]).transformDirection(matrix).multiplyScalar(75);
 light.position.copy(origin).add(sourceSun);light.target.position.copy(origin);scene.add(light,light.target);
 Object.assign(light.shadow.camera,{left:-40,right:40,top:40,bottom:-40,near:1,far:200});light.shadow.mapSize.set(4096,4096);light.shadow.bias=-.0004;
 const [W,H]=cam.image_px,[cx,cy]=cam.principal_px,f=cam.focal_px;
 const FW=2*Math.max(cx,W-cx),FH=2*Math.max(cy,H-cy);
 const camera=new THREE.PerspectiveCamera(2*Math.atan(FH/2/f)*180/Math.PI,FW/FH,.1,500);
 camera.setViewOffset(FW,FH,FW/2-cx,FH/2-cy,W,H);
 const t=cam.yaw_deg*Math.PI/180;
 const eye=new THREE.Vector3(cam.eye[0],cam.eye[2],-cam.eye[1]);
 const target=eye.clone().add(new THREE.Vector3(Math.sin(t),0,-Math.cos(t)));
 camera.position.copy(eye.applyMatrix4(matrix));camera.up.set(0,1,0).transformDirection(matrix);camera.lookAt(target.applyMatrix4(matrix));camera.updateMatrixWorld(true);
 const project=p=>{const q=p.clone().project(camera);return[(q.x+1)*W/2,(1-q.y)*H/2,q.z];};
 const controls=[[0,9.14,0],[0,0,0],[15.24,0,0],[0,9.14,7.8],[0,0,7.8],[15.24,0,7.8]];
 const cameraControls=controls.map(([u,v,y])=>{
  const q=project(new THREE.Vector3(u,y,-v).applyMatrix4(matrix));
  const du=u-cam.eye[0],dv=v-cam.eye[1],dy=y-cam.eye[2],dep=du*Math.sin(t)+dv*Math.cos(t),right=du*Math.cos(t)-dv*Math.sin(t);
  const expected=[cx+f*right/dep,cy-f*dy/dep];need(Math.hypot(q[0]-expected[0],q[1]-expected[1])<1e-6,'native transformed camera differs from frozen source camera');return{uvy:[u,v,y],native_px:q.slice(0,2),analytic_px:expected};
 });
 const ground=new THREE.Mesh(new THREE.PlaneGeometry(400,400),new THREE.MeshStandardMaterial({color:0x9a9686,roughness:1}));ground.rotation.x=-Math.PI/2;ground.position.copy(origin);ground.position.y-=.01;ground.receiveShadow=true;scene.add(ground);
 const renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});renderer.setPixelRatio(1);renderer.setSize(W,H);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.shadowMap.enabled=true;document.body.appendChild(renderer.domElement);
 const flags=createFlags({registry,buildings,confidence,problems});scene.add(flags.group);flags.update(.15); // actual production update once, then held
 const mesh=flags.group.getObjectByName('flag:tremont_house_1');need(mesh?.isMesh,'actual production flag not created');need(flags.drawn.length===1,'missing/duplicate native flag');
 const anchor=sidecar.attributes.flag_anchor.value;
 const expected=new THREE.Vector3(anchor.head[0],anchor.head[2],-anchor.head[1]).applyMatrix4(matrix);expected.y-=.18;
 need(mesh.parent.position.distanceTo(expected)<1e-6,'native flag holder misses canonical local anchor');
 const values=[...new Set(mesh.geometry.getAttribute('_confidence').array)];need(values.length===1&&values[0]===1,'cloth reconstructed confidence changed');
 const roofDraw=[];
 for(const batch of roofBatches)batch.onAfterRender=function(r,s,c,g,m){
  try{
   const gl=r.getContext(),program=r.properties.get(m).currentProgram;
   const loc=gl.getUniformLocation(program.program,'batchingColorTexture');need(loc!==null,'actual roof program omits native batching colour texture');
   const unit=gl.getUniform(program.program,loc),active=gl.getParameter(gl.ACTIVE_TEXTURE);gl.activeTexture(gl.TEXTURE0+unit);
   const bound=gl.getParameter(gl.TEXTURE_BINDING_2D);gl.activeTexture(active);
   const texture=r.properties.get(this._colorsTexture).__webglTexture;need(bound&&bound===texture,'actual roof GPU sampler is not bound to native instance-colour texture');
   roofDraw.push({linked:gl.getProgramParameter(program.program,gl.LINK_STATUS),nativeColorTextureBound:true,textureUnit:unit,colorTextureWidth:this._colorsTexture.image.width,colorTextureHeight:this._colorsTexture.image.height,colorTextureData:[...this._colorsTexture.image.data],vertexSource:gl.getShaderSource(program.vertexShader),fragmentSource:gl.getShaderSource(program.fragmentShader)});
  }catch(e){roofDraw.push({error:e.message});}
 };
 const draw=[];
 mesh.onAfterRender=function(r,s,c,g,m){
  try{
   const gl=r.getContext(),props=r.properties.get(m),p=props.currentProgram;
   const uniform=name=>{const l=gl.getUniformLocation(p.program,name);need(l!==null,`GPU uniform missing:${name}`);const x=gl.getUniform(p.program,l);return ArrayBuffer.isView(x)?[...x]:x;};
   const vertex=gl.getShaderSource(p.vertexShader),fragment=gl.getShaderSource(p.fragmentShader);
   const mv=new THREE.Matrix4().multiplyMatrices(c.matrixWorldInverse,this.matrixWorld);
   const gpuMV=uniform('modelViewMatrix'),gpuProjection=uniform('projectionMatrix');
   need(gpuMV.every((x,i)=>Math.abs(x-mv.elements[i])<1e-4),'GPU modelViewMatrix differs from actual native flag transform');
   need(gpuProjection.every((x,i)=>Math.abs(x-c.projectionMatrix.elements[i])<1e-4),'GPU projectionMatrix differs from source camera');
   draw.push({linked:gl.getProgramParameter(p.program,gl.LINK_STATUS),mode:uniform('uConfMode'),gradeModes:uniform('uGradeMode'),gradeOpacity:uniform('uGradeOpacity'),hiddenLevels:uniform('uHideLevel'),flagTime:uniform('uFlagTime'),gpuModelViewMatrix:gpuMV,gpuProjectionMatrix:gpuProjection,actualFlagWorldMatrix:this.matrixWorld.toArray(),actualCameraWorldMatrix:c.matrixWorld.toArray(),vertexSource:vertex,fragmentSource:fragment});
  }catch(e){draw.push({error:e.message});}
 };
 const render=async on=>{
  need(on===false,'roof study captures normal only, unchanged native confidence mode');confidence.set(on);draw.length=0;roofDraw.length=0;scene.updateMatrixWorld(true);camera.updateMatrixWorld(true);flags.update(0);confidence.render(renderer,scene,camera);
  need(roofDraw.length>0,'actual native roof batch not drawn');const roofObservation=roofDraw.at(-1);need(!roofObservation.error,roofObservation.error);need(roofObservation.linked,'actual roof program did not link');
  need(draw.length>0,'actual flag not drawn by GPU');const observation=draw.at(-1);need(!observation.error,observation.error);need(observation.linked,'native flag GPU program not linked');need(observation.mode===(on?1:0),'actual native confidence mode disagrees');need(Math.abs(observation.flagTime-.15)<1e-6,'flag time not held');
  need(/_confidence/.test(observation.vertexSource)&&/vConfidence/.test(observation.fragmentSource),'actual linked flag shader missing grade path');
  if(on)need(observation.gradeModes[2]===2&&Math.abs(observation.gradeOpacity[2]-.34)<1e-5,'actual reconstructed cloth not default dither');
  const direction=new THREE.Vector3(1,0,0).transformDirection(mesh.parent.matrixWorld),bearing=(Math.atan2(direction.x,-direction.z)*180/Math.PI+360)%360;
  need(Math.abs(bearing-45)<1e-6,'native default downwind direction changed');
  const staticPixels=[];const pos=mesh.geometry.getAttribute('position');for(let i=0;i<pos.count;i++)staticPixels.push(project(new THREE.Vector3().fromBufferAttribute(pos,i).applyMatrix4(mesh.matrixWorld)));
  return{renderSettings:{toneMapping:renderer.toneMapping,exposure:renderer.toneMappingExposure,outputColorSpace:renderer.outputColorSpace,hemisphereIntensity:scene.children.find(o=>o.isHemisphereLight).intensity,sunIntensity:light.intensity,sunPosition:light.position.toArray(),sunTarget:light.target.position.toArray()},materialStudy,actualRoofGpu:{...roofObservation,vertexSource:undefined,fragmentSource:undefined,vertexShaderSha256:await sha(roofObservation.vertexSource),fragmentShaderSha256:await sha(roofObservation.fragmentSource)},scope:'Isolated native production buildings/flags/anchors/confidence/heightfield, actual frozen master and unchanged source camera; controlled photo_match lighting/ground, not full town/app atmospheric screenshot or image acceptance.',mode:on?'confidence':'normal',state:'native-default-wind-from225-time0.15',targetDate:sidecar.target_date,phase:sidecar.phase,drawn:flags.drawn,anchor,buildingMatrix:matrix.toArray(),bounds:box,holder:mesh.parent.position.toArray(),clothVertices:pos.count,clothConfidenceValues:values,actualWindToBearingDeg:bearing,cameraControls,projectionMatrix:camera.projectionMatrix.toArray(),staticClothBoundsPx:{min:[0,1].map(i=>Math.min(...staticPixels.map(p=>p[i]))),max:[0,1].map(i=>Math.max(...staticPixels.map(p=>p[i])))},staticBoundsLimit:'Unmodified plane positions exclude actual vertex-shader flutter; screenshot is the real GPU output.',nativeProblems:problems,draw:{...observation,vertexSource:undefined,fragmentSource:undefined,vertexShaderSha256:await sha(observation.vertexSource),fragmentShaderSha256:await sha(observation.fragmentSource)}};
 };
 window.__diagnostic={ready:true,error:null,render,limits:'Native runtime-layer diagnostic only; provisional camera and original picture-match case remain open.'};
}catch(e){window.__diagnostic.error=e.stack||e.message;console.error(e);}
