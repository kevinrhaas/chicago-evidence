"""Focused Python accumulator checks only; no Blender or exports."""
from pathlib import Path
import sys,types,importlib.util,json,copy,inspect,dataclasses,math,hashlib
ROOT=Path('/workspace/chicago/chicago/4d'); OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'generators'));sys.modules.setdefault('bpy',types.ModuleType('bpy'))
from archetypes import frame_tavern as oldbuilder
from archetypes import frame_tavern_params as oldparams
from common.mesh import MeshBuilder
MeshBuilder.to_object=lambda self,mats=None:(self,mats)
def capture(n,*args,**kwargs):return n,args,kwargs
oldbuilder.simple_material=capture

def freeze(v):return repr(v).encode()
def signature(v):
 mesh,mats=v;return hashlib.sha256(freeze((mesh.verts,mesh.faces,mesh.conf,mesh.mat_index,mesh.named,mats))).hexdigest()
records=[]
for f in sorted((ROOT/'data/structures').glob('*.json')):
 r=json.loads(f.read_text())
 if r.get('archetype')!='frame_tavern':continue
 for phase in r['phases']:
  if phase.get('archetype',r['archetype'])=='frame_tavern':
   try:p=oldparams.from_phase(phase,r)
   except Exception:continue
   records.append((r,phase,p,signature(oldbuilder.build(p,r['id']+'__'+phase['id']))))
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
newparams=load('archetypes.frame_tavern_params',OUT/'proposed/generators/archetypes/frame_tavern_params.py')
newbuilder=load('archetypes.frame_tavern_proposed',OUT/'proposed/generators/archetypes/frame_tavern.py');newbuilder.simple_material=capture
legacy=lambda m:[(n,p.default) for n,p in inspect.signature(m.FrameTavernParams).parameters.items() if p.kind==inspect.Parameter.POSITIONAL_OR_KEYWORD]
assert legacy(oldparams)==legacy(newparams) and len(legacy(newparams))==40
assert inspect.signature(newparams.FrameTavernParams).parameters['corner_shutter_angles'].kind==inspect.Parameter.KEYWORD_ONLY
unchanged=[]
for r,phase,oldp,sig in records:
 p=newparams.from_phase(phase,r);assert p.corner_shutter_angles==()
 assert signature(newbuilder.build(p,r['id']+'__'+phase['id']))==sig,r['id']
 unchanged.append(r['id']+'__'+phase['id'])
r,phase,_,_=next(x for x in records if x[0]['id']=='tremont_house_1');p=newparams.from_phase(phase,r)
phase_copy=copy.deepcopy(phase)
phase_copy['form']['corner_shutter_angles']={'value':[{'face':'x_min','story':2,'bay':1,'negative_deg':30,'positive_deg':15}], 'confidence':'reconstructed','note':'Isolated diagnostic candidate, no adoption or historical measurement.'}
parsed=newparams.from_phase(phase_copy,r)
assert parsed.corner_shutter_angles==(('x_min',2,1,30,15),)
assert 'corner_shutter_angles' in newparams.CONSUMED
for changes in [{'shutters':None},{'confidence':{**p.confidence,'corner_shutter_angles':'inferred'}}]:
 try:dataclasses.replace(parsed,**changes).validate()
 except newparams.ParamError:pass
 else:raise AssertionError(changes)
base=signature(newbuilder.build(p,'bounded'));zero=dataclasses.replace(p,corner_shutter_angles=(('x_min',2,1,0,0),));assert signature(newbuilder.build(zero,'bounded'))==base
bad=[(('x_min',True,1,20,0),),(('x_min',2,1,True,0),),(('bad',2,1,0,0),),(('x_min',3,1,0,0),),(('x_min',2,3,0,0),),(('x_min',0,1,20,0),),(('x_min',2,1,-1,0),),(('x_min',2,1,76,0),),(('x_min',2,1,float('nan'),0),),(('x_min',2,1,10,0),('x_min',2,1,0,10)),(('x_min',2,1,0),)]
for entry in bad:
 try:dataclasses.replace(p,corner_shutter_angles=entry).validate()
 except newparams.ParamError:pass
 else:raise AssertionError(entry)
for face in ['x_min','x_max','y_min','y_max']:
 for angles in [(30,0),(0,30),(30,15)]:
  override=(face,2,1,*angles);q=dataclasses.replace(p,corner_shutter_angles=(override,));q.validate()
  mesh,mats=newbuilder.build(q,'bounded')
  assert signature((mesh,mats))!=base
  for ff,mi in zip(mesh.faces,mesh.mat_index):
   if mi!=newbuilder.M_SHUTTER:continue
   assert all(mesh.conf[i]==1 for i in ff)
  # Exercise actual rotated emitter and verify outward normals relative to its own center.
  leaf=MeshBuilder('leaf');axis=face[0];outward=-1 if face.endswith('min') else 1
  newbuilder._corner_angled_leaf(leaf,axis,0,outward,2,-1,.357,3,4.35,30,1)
  center=[sum(v[i] for v in leaf.verts)/len(leaf.verts) for i in range(3)]
  assert len(leaf.faces)==6
  for ff in leaf.faces:
   a,b,c=[leaf.verts[i] for i in ff[:3]];u=[b[i]-a[i] for i in range(3)];v=[c[i]-a[i] for i in range(3)]
   n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
   fc=[sum(leaf.verts[j][i] for j in ff)/len(ff) for i in range(3)]
   assert sum(n[i]*(fc[i]-center[i]) for i in range(3))>0
report={'legacy_positional_parameters':40,'kw_only_new_field':True,'unchanged_current_phase_count':len(unchanged),'unchanged_current_phases':unchanged,'zero_override_geometry_identical':True,'invalid_cases_refused':len(bad)+2,'actual_from_phase_consumer_verified':True,'rotated_faces_both_axes_both_signs':'finite, outward normals; existing shutter material and confidence1','scope':'Python mesh accumulator only; no Blender/browser/GLB/publish or image acceptance'}
(OUT/'shutter-proposal-light-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
