# Bounded next proposal — not adopted or rendered

The complete current source-versus-ed3c comparison is:

`/tmp/chicago-next-model/T-2385-roof-tone-next/fixture/review/after/gifford-roof-tone-side-by-side.jpg`

The original source is on the left1637px; gutter24px; current hotel render on the right1637px. Parent has this exact path. Source/camera/GLB hashes are independently checked in the parent packet inventory.

## Source-picked shutter and entrance study

`source-picks-and-candidates.json` records approximate native-image bounds for the clearest upper-middle gable shutter pair and two pictured entrances, with explicit edge uncertainty/occlusion. The source does not calibrate hinge angles. The candidate15/30/45degree poses are reconstructed diagnostic alternatives, not measured source facts. No nonzero angle is selected for adoption and no historical colour, slat count, hardware or date is invented.

`shutter-angle-proposal.patch` is a runnable two-module opt-in producer proposal against the current combined frame code. It adds a sparse `corner_shutter_angles` tuple, keyword-only, defaultempty; it supports only the existing shuttered corner_gable scheme, one selected window/leaf pair per override and finite0..75degree values. Zero retains the old add_box branch exactly; nonzero makes a rotated closed leaf with existing material/confidence1. Face/story/bay selectors cannot duplicate, address a door or leave the face. Local negative/positive tangent semantics avoid the ambiguous label image-left. No common modules change.

No target data is enabled by this code patch: use `source-picks-and-candidates.json` to construct one isolated copied-data experiment on x_min/story2/bay1 only, with baseline0/0 and candidate15/15,30/15,45/15. Keep all other windows, hidden faces, footprint, phase and date fixed. Choose a pose only after an actual unchanged-camera render supports its silhouette within the picked uncertainty; precise degrees remain reconstructed even then.

Before any adopted target record, add its explicit reconstructed occurrence/note, matching `name_pool_keys` path in `data/reconstruction/name_pool_keys.json`, and a narrow reconstructed-only LIBERTIES Cover for `tremont_house_1.frame_1833.form.corner_shutter_angles`. Do not call occurrence or degrees inferred merely to avoid a liberty. The code adds the field to CONSUMED because the real builder reads it; there is no record_only placeholder. The source attribution and rights record remain controlling.

For entries, this packet deliberately supplies outline constraints without a new door-kit implementation. The source gable doorway contains light interior marks while the rendered closed leaf is dark red; colour/lighting can explain much of the apparent opening before geometry is changed. Project the current broad jamb/header into the picked polygons, then distinguish frame shape error from tone. The long-platform corners are occluded and no full trace is invented. Any retained dimensional or invisible-face choices remain reconstructed.

## Lightweight proof and staleness

`check_shutter_proposal.py` ran in about1second using the actual Python accumulator and copied proposed modules, stubbing only Blender material emission. Its receipt `shutter-proposal-light-checks.json` verifies:

- original40 positional parameters/defaults unchanged; new field iskeyword-only;
- all24 currently parsable family phase parameter/build outputs unchanged by empty default, including the inactive earlier Sauganash phase; this includes the23 current family master targets;
- explicit0/0 equals baseline geometry;
- thirteen invalid target/angle/confidence configurations refused; actual from_phase parsing/CONSUMED use verified;
- both axes and both face signs produce finite closed leaves with outward face normals, existing shutter material and reconstructed confidence.

The proposed source hashes are in `shutter-angle-manifest.json`; `git apply --check` passed against those exact current modules. These are source/accumulator checks, not export or image evidence. Module byte changes would stale all23 current family recipes even when default geometry is equal, so official adoption requires fresh canonical exports and derivatives using the normal producer; do not copy old GLBs or restamp manifest hashes. Parent retains all root integration/gate/PR ownership.

`DIAGNOSTICS.md` separates the verified material-read path, lighting/material experiments and same-camera actual-native-cloth requirements. None was rendered. No Blender/browser/fullgate/publish/GitHub/ticket mutation or acceptance claim occurred.
