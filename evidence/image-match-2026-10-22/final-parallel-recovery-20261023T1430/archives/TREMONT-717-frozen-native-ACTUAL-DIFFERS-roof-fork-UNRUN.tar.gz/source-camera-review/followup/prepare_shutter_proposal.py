from pathlib import Path
import json,difflib,hashlib
ROOT=Path('/workspace/chicago/chicago/4d'); OUT=Path(__file__).parent
files={}
for rel in ['generators/archetypes/frame_tavern.py','generators/archetypes/frame_tavern_params.py']:
 files[rel]=(ROOT/rel).read_text()
p=files['generators/archetypes/frame_tavern_params.py']
p=p.replace('"gable_arch_treatment", "corner_entry_surround", "gable_arch_text",','"gable_arch_treatment", "corner_entry_surround", "gable_arch_text",\n    "corner_shutter_angles",')
p=p.replace('    corner_entry_surround: bool = field(default=False, kw_only=True)','''    # Sparse (face, zero-based story, zero-based bay, negative/positive leaf degrees).
    # Zero lies flat against the wall; positive rotates the outer edge outward.
    # Empty preserves every old emitter call and the original forty positional args.
    corner_shutter_angles: tuple[tuple[str, int, int, float, float], ...] = field(
        default=(), kw_only=True)
    corner_entry_surround: bool = field(default=False, kw_only=True)''')
anchor='        detailed = (self.first_story_height_m is not None or self.entry_raise_m > 0'
assert p.count(anchor)==1
validate='''        if not isinstance(self.corner_shutter_angles, tuple):
            raise ParamError("corner_shutter_angles must be a tuple of sparse leaf overrides")
        if self.corner_shutter_angles:
            if self.elevation_scheme != "corner_gable" or not self.shutters:
                raise ParamError("corner_shutter_angles requires shuttered corner_gable")
            if self.confidence.get("corner_shutter_angles", "reconstructed") != "reconstructed":
                raise ParamError("corner_shutter_angles are reconstructed, not measured hinges")
        seen_shutters = set()
        for entry in self.corner_shutter_angles:
            if not isinstance(entry, tuple) or len(entry) != 5:
                raise ParamError("corner_shutter_angles entries require face/story/bay/two angles")
            face, story, bay, neg, pos = entry
            if face not in ("x_min", "x_max", "y_min", "y_max"):
                raise ParamError("corner_shutter_angles has an unknown local face")
            bays = 3 if face.startswith("x") else 5
            if type(story) is not int or not 0 <= story < self.stories:
                raise ParamError("corner_shutter_angles story is outside the block")
            if type(bay) is not int or not 0 <= bay < bays:
                raise ParamError("corner_shutter_angles bay is outside the face")
            if story == 0 and bay == bays // 2:
                raise ParamError("corner_shutter_angles cannot target a door")
            key = (face, story, bay)
            if key in seen_shutters:
                raise ParamError("corner_shutter_angles cannot duplicate a window")
            seen_shutters.add(key)
            for angle in (neg, pos):
                if isinstance(angle, bool) or not isinstance(angle, (int, float)) or not math.isfinite(angle) or not 0 <= angle <= 75:
                    raise ParamError("corner_shutter_angles angles must be finite degrees in 0..75")
'''
p=p.replace(anchor,validate+anchor)
p=p.replace('        corner_entry_surround=val("corner_entry_surround", False),','''        corner_entry_surround=val("corner_entry_surround", False),
        corner_shutter_angles=tuple((o["face"], o["story"], o["bay"],
                                     o["negative_deg"], o["positive_deg"])
                                    for o in (val("corner_shutter_angles") or ())),''')
b=files['generators/archetypes/frame_tavern.py']
a='''                     z0: float, z1: float) -> None:
    """Open leaves on either wall axis; every section/detail is reconstructed.'''
assert b.count(a)==1
b=b.replace(a,'''                     z0: float, z1: float,
                     angles: tuple[float, float] = (0.0, 0.0)) -> None:
    """Open leaves on either wall axis; every section/detail is reconstructed.''')
b=b.replace('''    for side in (-1, 1):
        inner = (u0 if side < 0 else u1) + side * (openings.CASING_W_M + 0.01)''','''    for side in (-1, 1):
        inner = (u0 if side < 0 else u1) + side * (openings.CASING_W_M + 0.01)
        angle = angles[0 if side < 0 else 1]
        if angle:
            _corner_angled_leaf(b, axis, plane, outward, inner, side,
                                leaf_w, z0, z1, angle, conf)
            continue''',1)
anchor='\n\ndef _fenestration_corner_gable('
assert b.count(anchor)==1
helper='''

def _corner_angled_leaf(b: MeshBuilder, axis: str, plane: float,
                         outward: int, hinge: float, side: int, width: float,
                         z0: float, z1: float, angle: float, conf: float) -> None:
    """An explicit reconstructed hinge pose, retaining the old leaf section.

    No random variation or source-attested angle; only selected windows opt in.
    All six faces use existing shutter material and reconstructed confidence.
    """
    t = math.radians(angle)
    def point(along, normal, z):
        u = hinge + side * (along * math.cos(t) - normal * math.sin(t))
        n = plane + outward * (LIP_M + 0.010 + along * math.sin(t) + normal * math.cos(t))
        return (n, u, z) if axis == "x" else (u, n, z)
    # Standard cuboid faces, reversing orientation if the axis map reflects it.
    pts = [point(a, n, z) for z in (z0, z1) for n in (0.0, 0.025) for a in (0.0, width)]
    faces = ((0,2,3,1),(4,5,7,6),(0,1,5,4),(2,6,7,3),(0,4,6,2),(1,3,7,5))
    determinant = -side*outward if axis == "x" else side*outward
    for face in faces:
        if determinant < 0:
            face = tuple(reversed(face))
        b.add_poly([pts[i] for i in face], conf, M_SHUTTER)
'''
b=b.replace(anchor,helper+anchor)
old='''                _corner_shutters(b, params, axis, plane, outward,
                                 u0, u1, z0, z0 + win_h)'''
new='''                face = f"{axis}_{'min' if outward < 0 else 'max'}"
                angles = next(((neg, pos) for f, s, bay, neg, pos
                               in params.corner_shutter_angles
                               if (f, s, bay) == (face, story, i)), (0.0, 0.0))
                _corner_shutters(b, params, axis, plane, outward,
                                 u0, u1, z0, z0 + win_h, angles)'''
assert b.count(old)==1;b=b.replace(old,new)
proposed={'generators/archetypes/frame_tavern_params.py':p,'generators/archetypes/frame_tavern.py':b}
patch=[]; manifest=[]
for rel,after in proposed.items():
 dest=OUT/'proposed'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(after)
 before=files[rel];patch.extend(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/chicago/4d/'+rel,tofile='b/chicago/4d/'+rel))
 manifest.append({'path':'chicago/4d/'+rel,'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest()})
(OUT/'shutter-angle-proposal.patch').write_text(''.join(patch));(OUT/'shutter-angle-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Prepared two-module opt-in code proposal only; no target data enabled or root writes.')
