# Separate controlled checks; prepared only, no execution

## Material and lighting path

`material-path-read.json` reads the actual ed3c GLB and current producer/loader. The roof is the intended slot with linear base factor(0.2941,0.2510,0.2157), roughness0.9 and metallic0. No texture/emissive/extension overrides are present. `hex_rgba` explicitly treats divided bytes as linear; its equivalent unlit display colour is roughly148/137/128 in sRGB8, not hex4B4037 on a display. This convention is deliberate and shared; no conversion correction to `common/materials.py` is proposed. Keith's record guard excludes Tremont. The renderer uses Three linear PBR, hemisphere1.1, sun2.4, ACES and sRGB output.

Approximate same-coordinate patches in the saved full comparison give roof luma source57.4/render142.6, near-gable blank source206.9/render161.2. Thus globally darkening the image alone would worsen that bright-gable gap. JPEG/paper/painted shading and patch choices prevent treating these numbers as reflectance or a colour specification. The entries are likewise mixed light/dark in the source, not proof of open doors; a selected gable-door patch is source159.7/render64.2. Existing closed six-panel/transom geometry must not become an invented black opening merely because of the dark rendered material.

Prepare independent, labelled comparison rows using the exact same ed3c GLB and camera:

1. Baseline unchanged renderer settings. Assert geometry/material input hashes.
2. Lighting-only rows: retain every material and tone mapping/exposure; change hemisphere/sun ratio or direction one factor at a time, recording light settings. Check roof/near-gable/long-wall/door patches together. Do not optimize just one patch or call lighting surveyed.
3. Material-read rows: first an unlit material-factor swatch diagnostic, explicitly not a match render; then a roof-only multiplicative linear-factor sweep(1,0.5,0.25) under baseline lighting. Apply overrides only to an isolated diagnostic clone, never an official GLB. If an entry-only tonal diagnostic is needed, do it as a separate labelled row. No automatic choice or claim of literal historical black/white/brown follows.
4. Compare any useful tonal choice in normal native app lighting before adoption. A retained per-building stock must remain reconstructed, consume a real producer parameter, carry source/liberty notes and receive a fresh official bake. Never silently retune common material colours or all23 family defaults.

No new lighting code/camera/material has been executed or adopted in this packet.

## Native same-camera runtime-cloth diagnostic

This is a native-reader drawing check, separate from baked `photo_match` and separate from image-match acceptance. Use the application's actual `createFlags` and `flagMount` path; do not make a substitute flag mesh, bake cloth into the hotel or change `photo_match` to a synthetic stand-in.

Inputs and setup:

- Exact ed3c canonical hotel GLB, canonical compiled phase sidecar/registry and building instance placement matrix. Record hashes of model, sidecar, `flags.js`, `flag-anchors.js`, confidence control and scene inputs.
- Date1835-07-01, phaseframe_1833. Keep pattern valid through1836-07-03 without shortening hotel phase1839-10-27. No scene-date inference from the undated Gifford plate.
- Exact current Gifford camera: source1637×796, focal1320.031937501163px, principal468.2747693455644/460.63883228759966, localeye[-47.51829894710495,-37.89004630139154,2.4453554996967415], yaw28.15896409466343. Transform the footprint-frame eye and orientation through the actual drawn hotel's existing `buildings.matrixOf(id)`, rather than guessing a second world conversion. Local[U,V,Y]→glTF[U,Y,-V] is the existing contract. Assert several hotel vertices project at the same pixels as the saved baked camera before reviewing cloth. Capture only after model/sidecar/flag drawing readiness, without card overlays covering the hotel.
- Use actual registry plus `buildings.matrixOf`/`instanceBounds` when constructing flags. Confirm no reported mount refusal; expected anchor head[5.6388,4.57,15.061870276202958] and foot[5.6388,4.57,10.661870276202958] in footprint_enu_m. Actual holder must be head−0.18m in world-up after model placement, not hotel bounding-box centre.
- Hold real layer time deterministically: new layer beginsuFlagTime0; call its actual update once with fixed dt0.15, then0 for captures. Recordactual linked GPU uniform and wind, rather than only requested values. Current native wind is FROM225°; do not change it silently just to send cloth image-left. Source flying direction is an appearance constraint for a separately labelled pose experiment, not an attested meteorological bearing.
- Capture normal mode and reconstructed-confidence mode using actual confidence.patch integration. Read actual draw callback: flagpatternus_flag_24_star, fly1.85m/hoist1.3m,495vertices, confidence1. Verify actual linked vertex/fragment confidence and held time, source-screen hoist position/cloth silhouette, mounting offset and no duplicate cloth. Static bounds omit shader flutter, so inspect actual screenshot.

Deliver source versus native screenshot plus a separately labelled baked-versus-native pair. Native atmosphere, terrain/context and runtime effects can differ from isolated photo_match; record those differences. Camera equivalence and a real cloth draw do not validate the reconstructed pattern, dimensions or pose or establish a matches verdict.
