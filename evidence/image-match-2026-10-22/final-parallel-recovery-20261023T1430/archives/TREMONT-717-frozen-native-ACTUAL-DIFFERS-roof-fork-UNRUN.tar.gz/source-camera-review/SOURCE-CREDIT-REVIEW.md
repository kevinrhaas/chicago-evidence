The two-row correction is complete and parent-adopted. Input/output SHA256s:

| Catalogue | Before | After (independently verified canonical) |
|---|---|---|
| reference/images/IMAGE_SOURCES.md | dc40b301b8b374943da055e97b3b971bb7081f72c241d4bad6f3c35940b7a7cc | fecc13402ea99e7d5c4c4f6cb8f3047fca78211e233022ba026b1ddeabe1ff9b |
| reference/planning/images/IMAGE_SOURCES.md | 600217fa7971b8bbccc7a82c5d5add01cbc9192a4b1aa231eb3f26e77a2c5861 | 571be9322cf14a354c3f6c649735160bbdf248da484e9097491b31647f5a78a3 |

No source date/public-domain finding exists to support the removed ca1900/PD assertions. Original user-supplied Chicagology link and Gifford credit remain. Wording follows the authoritative source record's owner-approved attributed project-use decision while retaining unresolved original publication/collection/copyright. No root writes by this child. Parent owns commit/gates/PR. See machine-readable guards and adoption review; no mesh or camera changed.
