# T-2385 light source/camera review — 2026-10-23

This review reads the original Gifford reproduction, current canonical record/GLB, latest saved source comparison and an actual saved app flag screenshot. It creates no app changes, exports, cameras accepted into `data/reference_views`, browser sessions, ticket updates or match acceptance. Parent owns root integration and GitHub work. T-2385 remains open and the reviewed comparison remains **differs**.

## Exact current comparison and picture inventory

The original ticket lists one actual picture: `gifford_tremont_house_no_1`, N. Roswell Gifford's undated drawing reproduced by Chicagology at <https://chicagology.com/prefire/prefire021/>. The current generated Images catalogue independently lists that same single picture for `tremont_house_1`. I opened the actual local 1637×796 image, not only its description. The 1845 Gurley/Johnston second-Tremont advertisement elsewhere in the library depicts the successor; it is not another first-house view or a source for this building's 1835 details. No accepted first-Tremont reference-view file exists in the current tree.

The exact canonical mesh SHA256 is `ed3c2605c9c3c584511e3e093a4b57facff7854b29e9a73354891297708a244a`. It equals the saved latest dark-roof after comparison's recorded GLB hash. The saved photo and camera hashes also agree with their actual input files; see `inventory.json`. The comparison I opened is:

`/tmp/chicago-next-model/T-2385-roof-tone-next/fixture/review/after/gifford-roof-tone-side-by-side.jpg`

Some earlier proposal READMEs call their changes unapplied; that historical status is superseded by the current canonical hash equality. Earlier light-roof or two-storey captures are not this current mesh.

## Camera constraints and remaining fit

Keep this numeric camera unchanged for the next controlled model experiment. It is provisional framing, not an accepted or historically solved camera. It fits six manually picked wall-envelope corners of a reconstructed 15.24×9.14×7.8m box, with 3.546px point RMS and 6.866px maximum point error. The bottom-right corner alone differs vertically by +6.858px; its drawn ground contact is partly obscured by the frontage/road. Neither its ground-pick uncertainty nor the drawing's perspective may be silently resolved by moving the georeferenced hotel.

`camera-feature-diagnostics.json` adds arithmetic projection of three actual inspected source features without refitting anything:

| Feature | Source pick, px | Current projected point, px | Error, px |
|---|---|---|---|
| Near-gable roof apex | 953,277 | 946.34,275.77 | -6.66,-1.23 |
| Staff top | 1034,192 | 1034.71,194.26 | +0.71,+2.26 |
| Staff/ridge junction, partly obscured | 1034,279 | 1034.71,283.99 | +0.71,+4.99 |

These picks have approximate 3/3/5px reading uncertainty. Roof pitch/staff were already chosen from this source and camera, so these are **not independent calibration controls**. The apex's mainly horizontal discrepancy cannot be fixed by changing roof pitch alone under this level pinhole camera. Reinspect roof overhang, corner picks and drawn gable asymmetry together before changing the envelope. Do not rotate or change the footprint merely to reduce this residual.

Next camera work should inventory source openings/eaves/roof edges with separate uncertainty labels, fit the camera on one control subset and report unused-feature residuals. Ground contacts hidden by board walks should not get equal certainty to a clear eave. A camera-only change must compare the exact current mesh against the original and show whether it improves other controls rather than only its fit subset. The drawing supplies no scale or surveyed viewpoint; camera adjustments cannot create metric dimensions, coordinates or an exact 1835 date.

## Visible differences, in useful next-work order

1. **Roof/wall contrast and lighting:** the stock dark-roof change is visible progress, but the source roof and long eaves elevation are much darker relative to the near gable than in the comparison. Investigate comparison lighting and neutral tonal response before claiming another historical pigment. The existing `dark_brown` is reconstructed; the monochrome picture does not attest brown shingles, age, weathering history or pale/white paint. A lighting-only experiment should hold geometry/materials fixed and retain the existing comparison for evidence.
2. **Shutters and sash:** the source contains dense light/dark sash marks and unevenly angled shutter leaves. The kit repeats regular coplanar rectangular leaves and uniform openings. A bounded next implementation could add explicit opt-in shutter opening angles on the two pictured faces, keeping legacy defaults and hidden-face choices reconstructed. First mark each legible pictured leaf; do not randomize or claim the image resolves all slat counts/hardware. Source screen-space opening bounds should precede any change to the existing 0.85×1.35m kit windows.
3. **Entrance/platform treatment:** raised entrances are now present, but source guard rails, posts and platform silhouettes differ from the uniform four-step/platform kit. Isolate the two visible entrances, compare their 2D outlines and pick the clearly visible stock, while leaving exact metric width/rise/riser count and hidden entries reconstructed. Do not infer a new building porch from the raised board walk.
4. **Stacks:** four offset stack occurrences now read substantially closer, but their plain brick-toned faces/caps differ from the drawing's alternating light faces and dark cap edges. A source-bounded light/dark treatment could improve appearance; a particular masonry pigment, mortar recipe, flue section and exact offsets remain reconstruction. Do not change all tavern stacks to fix this one view.
5. **Arched field/name:** the dark opaque arch is a cautious interpretation of unresolved marks; current `TREMONT` is a knowingly reconstructed documented name, not a recovered inscription. Its baseline and regular stroke font remain visibly different. No attic glazing, sign transcription or pigment can be newly attested from this reproduction. Retain the explicit reconstruction notes if its placement/shape is refined.
6. **Context:** the source shows continuous neighbouring storefronts, boardwalk/posts and muddy street. The saved GLB comparison is an isolated hotel on a flat ground plane. That absence prevents claiming a whole-image match; it is not a warrant to move unrelated structures or copy their lettered signs without separate source/scene-date work.

## Flag: actual app draw versus baked comparison

The current `tools/photo_match.mjs` imports GLTFLoader and renders the loaded member GLBs. It does not import `flags.js`, consume flag sidecars or call the runtime flag layer. This is direct code inspection, independently consistent with the current comparison's explicit `not shown` cloth difference. The baked staff is visible, but cloth absence in that image is **not** proof that the actual app flag is missing.

I opened the saved mobile app screenshot and its draw receipt:

`/tmp/frame-integration/e474-integration-citations-fixed/group-card-QA/mobile-tremont_house_1-flag-normal.{png,json}`

It visibly contains cloth on the roof spar; its actual GPU draw receipt records `us_flag_24_star`, fly1.85m/hoist1.3m, 495 cloth vertices, reconstructed confidence1 and holder at staffhead−0.18m. This is a historical app capture from before the latest roof tone, not a current same-camera image match. Its projected cloth bounds are about14.31×15.39px in that mobile app viewpoint, not the Gifford camera.

A next source comparison must use an explicitly labelled runtime-layer diagnostic from the unchanged Gifford camera, same local anchor, held wind/time and documented date. Source cloth flies to image-left; app cloth orientation is wind-driven, so flag pose is another comparison variable, not evidence for moving its roof anchor. Gifford's small monochrome flag does not resolve 24-star pattern or national colours. The 24-star choice and dimensions/flying state remain reconstructed; its validity ends1836-07-03 while the building phase still ends1839-10-27. Do not insert cloth permanently into the hotel GLB or shift the whole-building-bounds anchor.

## Narrow provenance correction, adopted by parent

`source-credit-correction.patch` changes exactly the first-Tremont entry in the two IMAGE_SOURCES.md mirrors. It removes an unsupported ca1900 production date and public-domain assertion, retains N. Roswell Gifford/Chicagology credit and the owner's source link, and states the owner-approved project-use scope and unresolved original publication/collection/copyright. It changes no underlying source record, camera, mesh or building record.

`source-credit-guards.json` records exact full-file before/after hashes and one occurrence of each guarded old string. `git apply --check` passed before parent adoption. Parent applied the exact patch; I independently verified both canonical files equal the proposed after hashes. See `source-credit-adoption-review.json`. Four trailing-double-space notices are retained Markdown hard breaks, not extra cleanup. This correction grants no public-domain/general redistribution claim and supplies no new image-match acceptance.

## Verification and next handoff

Light checks only: exact input hashes, one-picture inventory, absent accepted reference views, direct renderer-path inspection, arithmetic projection, guarded two-row diff and adopted-file hashes. `review_geometry.py` reruns the arithmetic and writes only inside this packet. No Blender/browser/check.sh/publisher/asset refresh ran. No ticket/GitHub mutation was attempted. Parent can archive this entire folder, including its source-credit before/after copies and receipts.
