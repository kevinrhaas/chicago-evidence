from pathlib import Path
import shutil,json,hashlib
old=Path('/tmp/chicago-next-model/T-2385-next-review/native-cloth')
new=Path('/tmp/chicago-next-model/T-2385-roof-linear-study-792598d')
assert not new.exists(),'Choose a new immutable packet; never overwrite prior study.'
new.mkdir();shutil.copytree(old/'fixture',new/'fixture');shutil.copyfile(old/'frozen-inputs.json',new/'frozen-inputs.json')
(new/'baseline').mkdir()
for name in ['normal.png','normal.json','source-vs-native-normal.png','run.json','ACTUAL-REVIEW.json']:
 shutil.copyfile(old/'runs/authorized-792598d'/name,new/'baseline'/name)
shutil.copyfile(old/'run.mjs',new/'run.mjs')
closed={}
for rel in ['frozen-inputs.json','adapter-inputs.json','run.mjs','fixture/renderers/web/diagnostic.mjs','runs/authorized-792598d/normal.png','runs/authorized-792598d/normal.json','runs/authorized-792598d/source-vs-native-normal.png']:
 p=old/rel;closed[rel]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(new/'closed-native-parent-guards.json').write_text(json.dumps(closed,indent=2)+'\n')
factors=[.5,.25,.125]
base=[.29411765933036804,.250980406999588,.21568627655506134]
(new/'study.json').write_text(json.dumps({'scope':'Separate reconstructed runtime material-only alternatives, not adopted assets/pigments/weather history or a source-match verdict','source_master_sha256':'ed3c2605c9c3c584511e3e093a4b57facff7854b29e9a73354891297708a244a','canonical_roof_linear_rgb':base,'material_name':'roof_shingle','factors':[{'id':f'linear-{x:g}','linear_factor':x,'expected_modified_linear_rgb':[v*x for v in base],'label':f'Reconstructed research alternative: roof-only linear RGB ×{x:g}; no historical black/brown/pigment inference'} for x in factors],'capture_modes':['normal only; native confidence patch/state remains unchanged'],'held':{'geometry':'exact canonical master and real production reader; no Blender','camera_sha256':'16830ecda2efde0b4ccdb028bc559fb88529711a11b9cb0f05adbf4e8294bda2','walls_and_other_materials':'unchanged','lights_exposure_tonemapping':'unchanged from authorized native baseline','native_wind_from_deg':225,'native_time':.15,'confidence_mode':0},'baseline':'byte-exact copies of authorized native baseline in baseline/; no new baseline screenshot requested'},indent=2)+'\n')
print(new)
