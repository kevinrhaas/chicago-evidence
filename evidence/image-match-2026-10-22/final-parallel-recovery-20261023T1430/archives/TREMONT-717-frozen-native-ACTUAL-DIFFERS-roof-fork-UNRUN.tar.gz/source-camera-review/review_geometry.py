"""Light arithmetic only; no fitter, generator, Blender, browser or tracked writes."""
from pathlib import Path
import math,json,hashlib,struct
ROOT=Path('/workspace/chicago/chicago/4d')
OUT=Path(__file__).parent
CAM=Path('/tmp/chicago-next-model/T-2385-roof-tone-next/fixture/review/after/gifford-roof-tone.json')
cam=json.loads(CAM.read_text()); rec=json.loads((ROOT/'data/structures/tremont_house_1.json').read_text()); form=rec['phases'][0]['form']
w,d=rec['phases'][0]['footprint']['polygon'][2]
h=form['wall_height_m']['value']; pitch=form['roof_pitch_deg']['value']; overhang=.25
ridge=h+(d/2+overhang)*math.tan(math.radians(pitch))
def project(p):
 du,dv,dz=[a-b for a,b in zip(p,cam['eye'])]; t=math.radians(cam['yaw_deg']); dep=du*math.sin(t)+dv*math.cos(t); right=du*math.cos(t)-dv*math.sin(t)
 return [cam['principal_px'][0]+cam['focal_px']*right/dep,cam['principal_px'][1]-cam['focal_px']*dz/dep]
picks=[
 ('near gable roof apex',[-overhang,d/2,ridge],[953,277],3,'New manual reading consistent with current record roof_pitch_deg.note; roof overhang included.'),
 ('flagstaff top',[w*.37,d/2,ridge+form['flagstaff_height_m']['value']],[1034,192],3,'Top of drawn staff; source flag cloth is separate and not in baked GLB.'),
 ('flagstaff ridge junction',[w*.37,d/2,ridge],[1034,279],5,'Roof/staff junction partly hidden by roof and adjacent chimney; approximate only.')]
rows=[]
for name,point,pix,unc,note in picks:
 pred=project(point);res=[a-b for a,b in zip(pred,pix)]
 rows.append({'feature':name,'source_pixel_xy':pix,'manual_pick_uncertainty_radius_px':unc,'current_reconstructed_uvy_m':point,'predicted_pixel_xy':pred,'residual_xy_px':res,'point_residual_px':math.hypot(*res),'note':note,'used_to_refit_camera':False})
report={'status':'provisional diagnostic; no accepted camera or match','camera_path':str(CAM),'camera_sha256':hashlib.sha256(CAM.read_bytes()).hexdigest(),'current_dimensions_m':[w,d,h],'dimensions_confidence':'reconstructed; none measured from Gifford','equations':'Level vertical-preserving pinhole, same projection as saved camera and photo_match.mjs. No optimization performed.','important_limit':'Roof pitch and staff already selected using this source/camera; these are not independent withheld calibration controls. Their small residuals cannot validate camera or historical dimensions.','observations':rows}
(OUT/'camera-feature-diagnostics.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(rows,indent=2))
