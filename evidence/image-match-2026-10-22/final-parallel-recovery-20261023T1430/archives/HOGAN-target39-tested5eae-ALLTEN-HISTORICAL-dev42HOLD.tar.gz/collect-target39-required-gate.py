"""Read-only actual TARGET39 gate log capture; never retries or mutates CI."""
from pathlib import Path
import datetime,hashlib,json,re,subprocess
r=Path(__file__).resolve().parent
out=r/'target39-required-gate';out.mkdir(exist_ok=True)
head='39cafabb5da9262b8e81557b9f3ab1632d6ce624'
rid=39963907886
base='repos/kevinrhaas/chicago'
def api(s):return json.loads(subprocess.check_output(['gh','api',s],text=True,timeout=60))
run=api(f'{base}/actions/runs/{rid}')
assert run['head_sha']==head and run['event']=='pull_request'
(out/'run.json').write_text(json.dumps(run,indent=2)+'\n')
if run['status']!='completed':
 print(json.dumps({'TARGET_HEAD':head,'run':rid,'status':run['status'],'actual_verdict_pending':True}));raise SystemExit(0)
assert run['conclusion']=='success',run['conclusion']
jobs=api(f"{base}/actions/runs/{rid}/attempts/{run['run_attempt']}/jobs")
(out/'jobs.json').write_text(json.dumps(jobs,indent=2)+'\n')
assert jobs['total_count']==len(jobs['jobs'])
gates=[x for x in jobs['jobs']if x['name']=='gate'];assert len(gates)==1
job=gates[0];assert job['conclusion']=='success'
for name in ['Run the gate','Does this change carry a changelog entry?']:
 assert len([x for x in job['steps'] if x['name']==name and x['conclusion']=='success'])==1
body=subprocess.check_output(['gh','api',f"{base}/actions/jobs/{job['id']}/logs"],timeout=120)
(out/'actual-job.log').write_bytes(body)
text=re.sub(r'\x1b\[[0-9;]*m','',body.decode())
counts=re.findall(r'CHECK PASS[^\n]*?— (\d+) steps, none red\.',text)
assert counts and int(counts[-1])==1053,counts
assert 'check-changelog-entry.mjs' in text and head in text
assert 'changelog entry: present' in text
proof={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'TARGET_HEAD':head,'run':rid,'attempt':run['run_attempt'],'job':job['id'],'actual_CHECK_PASS_steps':int(counts[-1]),'actual_changelog_step':'success; actual entry-present transcript','all_successful_steps':[x['name']for x in job['steps']if x['conclusion']=='success'],'log_sha256':hashlib.sha256(body).hexdigest(),'log_bytes':len(body),'qualification':'Actual TARGET39 gate only; tested5eae smoke bank and source equality separately required; no merge performed'}
(out/'VERIFIED.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
