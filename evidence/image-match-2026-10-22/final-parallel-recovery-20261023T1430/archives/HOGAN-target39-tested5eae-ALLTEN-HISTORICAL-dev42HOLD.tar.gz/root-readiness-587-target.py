"""Read-only by default; only the root agent may explicitly invoke --merge."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
from concurrent.futures import ThreadPoolExecutor

parser = argparse.ArgumentParser()
parser.add_argument('--plan', default='/tmp/hogan-5eae-final-head-smokes.json')
parser.add_argument('--merge', action='store_true')
parser.add_argument('--target-receipt', default=str(Path(__file__).resolve().parent / '587-final-target-receipt.json'))
args = parser.parse_args()
root = Path(__file__).resolve().parent
worktree = root.parent
plan = json.loads(Path(args.plan).read_text())
repo, tested_head, number = plan['repository'], plan['head'], plan['pr']
target = json.loads(Path(args.target_receipt).read_text())
head = target['TARGET_HEAD']
assert target['TESTED_HEAD'] == tested_head == '5eaeac194eb12843e511e1ab5d7deff70daa57e3'
assert head != tested_head and len(head) == 40
assert hashlib.sha256(Path(args.plan).read_bytes()).hexdigest() == target['tested_plan_sha256']
assert repo == 'kevinrhaas/chicago' and number == 1229
assert target['incoming_dev'] == '587d8f33162896ca979447073ed37a5e4fe1d5f1'
assert plan['branch'] == 'steward/t2377-hogan-picture-match'
assert plan['dispatch_complete'] and len(plan['runs']) == 10
assert len({r['id'] for r in plan['runs']}) == 10
for viewport in ['mobile', 'desktop']:
    assert sorted(part for row in plan['runs'] if row['viewport'] == viewport for part in row['parts']) == list(range(1, 16))
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, text=True).strip() == head
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree)
for path, expected in plan['contract_sha256'].items():
    assert hashlib.sha256((worktree / path).read_bytes()).hexdigest() == expected

def get(endpoint):
    return json.loads(subprocess.check_output(['gh', 'api', endpoint], text=True, timeout=60))

pr = get(f'repos/{repo}/pulls/{number}')
assert pr['head']['sha'] == head and pr['head']['ref'] == plan['branch'] and pr['base']['ref'] == 'dev'
if pr['merged']:
    print(json.dumps({'already_merged': True, 'head': head, 'merge_commit_sha': pr['merge_commit_sha']}))
    raise SystemExit(0)
assert pr['state'] == 'open'
with ThreadPoolExecutor(max_workers=4) as pool:
    runs = list(pool.map(lambda row: get(f"repos/{repo}/actions/runs/{row['id']}"), plan['runs']))
for run in runs:
    assert run['head_sha'] == tested_head and run['workflow_id'] == plan['workflow_id']
    assert run['event'] == 'workflow_dispatch' and run['head_branch'] == plan['branch']
checks = get(f'repos/{repo}/commits/{head}/check-runs?filter=latest&per_page=100')
assert checks['total_count'] == len(checks['check_runs']), 'Check-run pagination needs explicit handling; do not certify truncated results'
statuses = get(f'repos/{repo}/commits/{head}/status')
assert statuses['total_count'] == len(statuses['statuses']), 'Status pagination needs explicit handling'
dev = get(f'repos/{repo}/git/ref/heads/dev')['object']['sha']
comparison = get(f'repos/{repo}/compare/{dev}...{head}')
ancestry_ok = comparison['status'] in ['ahead', 'identical']
if not ancestry_ok:
    (root / '587-target-current-dev-divergence.json').write_text(json.dumps(comparison, indent=2) + '\n')

def read_lease():
    # The CLI protocol deliberately exits 3 for a held live lap; 0 means free/stale.
    result = subprocess.run(['node', 'tools/ticket.mjs', 'lap', '1229', '--status'], cwd=worktree / 'chicago/4d', text=True, capture_output=True, timeout=60)
    live_root = result.returncode == 3 and result.stdout.startswith('held lap/pr-1229') and 'Codex Hogan and parallel picture-match integration' in result.stdout and 'dead' not in result.stdout.lower()
    return result, live_root

lease_result, lease_ok = read_lease()
lease = lease_result.stdout
lease_sha = get(f'repos/{repo}/git/ref/heads/lap/pr-1229')['object']['sha'] if lease_ok else None
transcript_path = root / '5eae-smoke-final-logs/ALL-TEN-ACTUAL-TRANSCRIPTS.json'
transcripts_ok = False
transcript_reason = 'Actual all-ten transcript proof not yet complete'
if transcript_path.exists():
    proof = json.loads(transcript_path.read_text())
    assert proof['head'] == tested_head and proof['workflow_id'] == plan['workflow_id']
    assert proof['all_ten_actual_transcripts_verified'] and proof['all15_parts_at_both_viewports']
    actual = {row['id']: row for row in proof['runs']}
    assert set(actual) == {row['id'] for row in plan['runs']}
    fresh_runs = {row['id']: row for row in runs}
    for row in plan['runs']:
        got = actual[row['id']]
        assert got['actual_transcript_verified'] and got['published'] and got['zero_page_errors']
        assert got['assertions_passed'] > 0 and got['assertions_failed'] == 0
        assert got['staged_assertions_passed'] > 0
        assert got['staged_assertions_passed'] + got['always_on_assertions_passed'] == got['assertions_passed']
        assert got['actual_parts'] == row['parts'] and got['viewport'] == row['viewport'] and got['stage'] == row['stage']
        assert got['attempt'] == fresh_runs[row['id']]['run_attempt']
        assert got['actual_checkout_head'] == tested_head
        assert got['actual_viewport_px'] == ('390x780' if row['viewport'] == 'mobile' else '1280x800')
        folder = transcript_path.parent
        archive = folder / f"{row['id']}-attempt{got['attempt']}.zip"
        text = folder / f"{row['id']}-actual-smoke.txt"
        assert hashlib.sha256(archive.read_bytes()).hexdigest() == got['log_zip_sha256']
        assert hashlib.sha256(text.read_bytes()).hexdigest() == got['actual_transcript_sha256']
        checkout = folder / f"{row['id']}-actual-checkout.txt"
        assert hashlib.sha256(checkout.read_bytes()).hexdigest() == got['checkout_transcript_sha256']
    transcripts_ok = True
    transcript_reason = 'All ten current-attempt actual published transcripts verified with matching file hashes'

# Native T-0216 policy: the completed smoke bank remains tied to TESTED_HEAD.
# Reuse for TARGET_HEAD requires exact whole-input and separate changelog equality.
equivalence = json.loads((root / '587-native-smoke-input-equivalence-staged.json').read_text())
assert equivalence['TESTED_HEAD'] == tested_head
assert subprocess.check_output(['git', 'show', '-s', '--format=%T', head], cwd=worktree, text=True).strip() == target['target_tree'] == equivalence['target_staged_tree']
paths = equivalence['explicit_paths']
assert not subprocess.check_output(['git', 'diff', tested_head, head, '--', *paths], cwd=worktree)
assert not subprocess.check_output(['git', 'diff', tested_head, head, '--', 'chicago/4d/tools/dev-smoke-state.mjs'], cwd=worktree)
native_hash = subprocess.check_output(['node', 'tools/dev-smoke-state.mjs', 'hash'], cwd=worktree / 'chicago/4d', text=True).strip()
native_ask = subprocess.check_output(['node', 'tools/dev-smoke-state.mjs', 'ask', '--viewport', 'desktop', '--stage', '13'], cwd=worktree / 'chicago/4d', text=True)
import re
changelog_match = re.search(r'your release notes:\s+(sha256:[a-f0-9]{16})', native_ask)
assert changelog_match and 'WORKING TREE DIRTY' not in native_ask
assert native_hash == target['native_smoke_hash_target'] == target['native_smoke_hash_tested'] == equivalence['native_smoke_hash_tested_clean'] == equivalence['native_smoke_hash_target_staged_clean']
assert changelog_match[1] == target['native_changelog_hash_target'] == target['native_changelog_hash_tested'] == equivalence['native_changelog_hash_tested'] == equivalence['native_changelog_hash_target_staged']
gate_proof = json.loads((root / target['fullgate_receipt']).read_text())
assert gate_proof['full_gate_exit'] == 0 and gate_proof['actual_steps'] == 1053
assert gate_proof['candidate_tree'] == target['target_tree']
for name, identity in gate_proof['logs'].items():
    body = (root / name).read_bytes()
    assert len(body) == identity['bytes'] and hashlib.sha256(body).hexdigest() == identity['sha256']

target_ci_proof_path = root / 'target39-required-gate/VERIFIED.json'
target_ci_transcript_ok = False
if target_ci_proof_path.exists():
    target_ci_proof = json.loads(target_ci_proof_path.read_text())
    assert target_ci_proof['TARGET_HEAD'] == head
    assert target_ci_proof['actual_CHECK_PASS_steps'] == 1053
    latest_gates = [c for c in checks['check_runs'] if c['name'] == 'gate']
    assert len(latest_gates) == 1
    target_gate_url = latest_gates[0]['details_url']
    assert f"/runs/{target_ci_proof['run']}/job/{target_ci_proof['job']}" in target_gate_url
    latest_gate_run = get(f"repos/{repo}/actions/runs/{target_ci_proof['run']}")
    assert latest_gate_run['head_sha'] == head
    assert latest_gate_run['run_attempt'] == target_ci_proof['attempt']
    target_ci_log = target_ci_proof_path.parent / 'actual-job.log'
    target_ci_bytes = target_ci_log.read_bytes()
    assert len(target_ci_bytes) == target_ci_proof['log_bytes']
    assert hashlib.sha256(target_ci_bytes).hexdigest() == target_ci_proof['log_sha256']
    target_ci_transcript_ok = True

conditions = {
    'github_mergeable_clean': pr.get('mergeable') is True and pr.get('mergeable_state') == 'clean',
    'all_ten_TESTED_HEAD_workflows_success': all(r['status'] == 'completed' and r['conclusion'] == 'success' for r in runs),
    'required_gate_success': any(c['name'] == 'gate' and c['status'] == 'completed' and c['conclusion'] == 'success' for c in checks['check_runs']),
    'all_latest_checks_accepted': all(c['status'] == 'completed' and c['conclusion'] in ['success', 'skipped', 'neutral'] for c in checks['check_runs']),
    'all_commit_statuses_success': all(s['state'] == 'success' for s in statuses['statuses']),
    'actual_TESTED_HEAD_transcripts_complete_and_current': transcripts_ok,
    'native_smoke_and_changelog_equivalence_TARGET_to_TESTED': True,
    'TARGET_local_strict_gate_passed_exact_candidate_tree': True,
    'TARGET_current_required_gate_actual_transcript_verified': target_ci_transcript_ok,
    'actual_dev_ancestor_of_source': ancestry_ok,
    'root_owned_live_lap': lease_ok,
}
snapshot = {
    'checked_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'ready': all(conditions.values()), 'conditions': conditions,
    'TARGET_HEAD': head, 'TESTED_HEAD': tested_head, 'pr': number, 'dev': dev,
    'native_smoke_hash': native_hash, 'native_changelog_hash': changelog_match[1],
    'reuse_policy': 'Native T-0216 equal input hash; actual completed bank stays labelled TESTED_HEAD',
    'mergeable_state': pr.get('mergeable_state'),
    'transcript_reason': transcript_reason, 'lease_reading': lease,
    'lease_status_exit': lease_result.returncode, 'lease_ref_sha': lease_sha,
    'runs': [{k: r[k] for k in ['id', 'status', 'conclusion', 'html_url', 'head_sha', 'run_attempt']} for r in runs],
    'checks': [{k: c[k] for k in ['name', 'status', 'conclusion']} for c in checks['check_runs']],
    'merge_performed': False,
}
(root / 'github-readiness-587-target.json').write_text(json.dumps(snapshot, indent=2) + '\n')
print(json.dumps(snapshot), flush=True)
if not args.merge:
    raise SystemExit(0)
assert snapshot['ready'], 'Not ready: no merge write performed'
# Root-only explicit write, after a fresh head/dev/lease race check.
assert get(f'repos/{repo}/pulls/{number}')['head']['sha'] == head
assert get(f'repos/{repo}/git/ref/heads/dev')['object']['sha'] == dev
assert read_lease()[1], 'Root no longer owns a live lap'
assert get(f'repos/{repo}/git/ref/heads/lap/pr-1229')['object']['sha'] == lease_sha, 'Lap changed; re-read before merging'
payload = {'sha': head, 'merge_method': 'squash', 'commit_title': "Progress on T-2377: Hogan's pictured openings and ridge chimney (#1229)", 'commit_message': 'First geometry increment. T-2377 remains open; the reviewed provisional comparison still differs.'}
result = subprocess.run(['gh', 'api', '-X', 'PUT', f'repos/{repo}/pulls/{number}/merge', '--input', '-'], input=json.dumps(payload), text=True, capture_output=True, check=True)
receipt = json.loads(result.stdout)
(root / 'github-merge-receipt-587-target.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
assert receipt.get('merged') is True
