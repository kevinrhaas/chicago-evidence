// Actual frozen walker with real temporary sidecars; flat test surface, no browser.
import fs from 'node:fs';
import {register} from 'node:module';
import {fileURLToPath,pathToFileURL} from 'node:url';
import path from 'node:path';
const base=path.dirname(fileURLToPath(import.meta.url)),root=base+'/snapshot';
const vendor=pathToFileURL(root+'/renderers/web/vendor/three-0.185.1/').href;
register(`data:text/javascript,${encodeURIComponent(`export function resolve(s,c,next){if(s==='three')return {url:'${vendor}three.module.js',shortCircuit:true};if(s.startsWith('three/addons/'))return {url:'${vendor}addons/'+s.slice(13),shortCircuit:true};return next(s,c);}`)}`,import.meta.url);
const THREE=await import('three');
const {createWalker,footprintsFrom,WALK}=await import(pathToFileURL(root+'/renderers/web/js/walker.js'));
const {createIntent}=await import(pathToFileURL(root+'/renderers/web/js/controls/intent.js'));
const J=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const study=J(base+'/clearance-light.json');
const registry=new Map(fs.readdirSync(root+'/data/sidecars/1835').filter(n=>n.endsWith('.json')).map(n=>{const sc=J(root+'/data/sidecars/1835/'+n);return [sc.id,{id:sc.id,sidecar:sc}];}));
const fp=footprintsFrom(registry),flat={walkHeight:()=>0,surfaceHeight:()=>0,isWater:()=>false};
function route(start,yaw,seconds){
 const w=createWalker({camera:new THREE.PerspectiveCamera(),terrain:flat,footprints:fp,spawn:{local_e:start[0],local_n:start[1],yaw_deg:yaw}}),intent=createIntent();
 for(let i=0;i<seconds*60;i++){intent.forward=1;w.update(1/60,intent);}
 return {start,yaw,seconds,end:[w.state.e,w.state.n],distance:Math.hypot(w.state.e-start[0],w.state.n-start[1])};
}
function settle(start){
 const w=createWalker({camera:new THREE.PerspectiveCamera(),terrain:flat,footprints:fp,spawn:{local_e:start[0],local_n:start[1],yaw_deg:0}});w.update(1/60,createIntent());return {start,end:[w.state.e,w.state.n]};
}
const house=study.entrances.find(v=>v.structure_id==='log_jail_keeper_house'),jail=study.entrances.find(v=>v.structure_id==='log_jail');
const oldSpeed=WALK.speed;WALK.speed=1.;
let out;
try{
 const origin=[463.07,-268.43],along=[.9999673320745274,-.008082993489538583],normal=[.008082993489538583,.9999673320745274];
 const street=route(origin.map((x,i)=>x+normal[i]*1.165),Math.atan2(along[0],along[1])*180/Math.PI,25);
 const keeper=route([house.at_local_enu_m[0],house.at_local_enu_m[1]+6],180,8);
 const core=route([jail.at_local_enu_m[0],jail.at_local_enu_m[1]+6],180,8);
 out={status:'LIGHT flat-substrate native walker only; not terrain/app/mesh QA',radius_m:WALK.radius,footprints:fp.map(v=>v.id),
  palisade_passages:fp.find(v=>v.id==='log_jail_palisade').passages??null,public_route:street,keeper_route:keeper,core_route:core,
  inside_spawn:settle([466.01,-269.67]),keeper_lateral_error:Math.abs(keeper.end[0]-house.at_local_enu_m[0]),keeper_wall_standoff:keeper.end[1]-house.at_local_enu_m[1],
  external_closed_gate_collision:'NOT CONSUMED. The keeper route crosses the visible closed forecourt wicket; current footprint walker does not receive forecourt rail/gate geometry. Do not claim a closed gate blocks it.',
  limitations:'Secure enclosure is a filled envelope, not curtain segments. Inside spawn pushed out; core/yard access blocked. Native doorway-zone overlap is reported separately; centre approach does not prove whole hand/apron clearance.'};
}finally{WALK.speed=oldSpeed;}
fs.writeFileSync(base+'/walker-light-results.json',JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out,null,2));
