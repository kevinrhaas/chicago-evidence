"""LIGHT camera-only refinement against rounded chosen pilot geometry."""
from pathlib import Path
import ast,json,math
import numpy as np
B=Path(__file__).resolve().parent
tree=ast.parse((B/'visible_features.py').read_text());nodes=[]
for n in tree.body:
 if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='out' for t in n.targets):break
 nodes.append(n)
ns={'__file__':str(B/'visible_features.py')};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(B/'visible_features.py'),'exec'),ns)
row=next(r for r in json.loads((B/'corrected-visible-results.json').read_text())['cases'] if r['case']=='12_over_12_6x8_free_core')
x=np.array([row['fit'][n] for n in ns['names']]);x[7:]=[6.4,-.35,5.5,3.4,2.95,27.3,3.92,3.24,7.7]
target=ns['target'];project=ns['project'];obs=ns['obs'];train=ns['train'];sigma=ns['sigma'];held=ns['hold']
def unpack(v):
 a=x.copy();a[:7]=v;return a
def loss(v):
 a=unpack(v);pts,bases,p=target(a,'12_over_12_6x8');pred=project(a,pts)
 return ((pred[train]-obs[train])/sigma[train,None]).ravel()
r=ns['least_squares'](loss,x[:7],bounds=(ns['lo'][:7],ns['hi'][:7]),max_nfev=220)
refined=unpack(r.x)
(B/'rounding-refit-not-selected.json').write_text(json.dumps({'warning':'Not used: rounding refit reaches eye_v100bound for subpixel-to1px gain. Preserve the original visible-control camera and report uncertainty.', 'fit':dict(zip(ns['names'],refined.tolist()))},indent=2)+'\n')
# Keep the pre-rounding fitted camera rather than spending extra freedom on a
# boundary-seeking refit for less than1pixel gain. Rounded target is still tested.
pts,bases,p=target(x,'12_over_12_6x8');pred=project(x,pts);error=np.linalg.norm(pred-obs,axis=1)
camera=json.loads((B/'snapshot/data/reference_views/log_jail/gale-compound-pilot.json').read_text())
camera.update(principal_px=[1370.5,float(x[6])],focal_px=float(x[5]),eye=[float(x[0]),float(x[1]),1.7],yaw_deg=float(x[2]),
 basis_right_up_forward=[v.tolist() for v in ns['basis'](x)],sun_uvy=[6,4,7],sky='sun',
 solve={'status':'UNSELECTED corrected-visible-control joint research pilot; not image acceptance',
  'method':'Rounded fixed candidate dimensions; camera fitted to core/keeper roof, native window heads/sills, door head, and near/far palisade bases/near head. Widths and far palisade head held out. No keeper base equality; foreground rail occludes it.',
  'metric_control':'Retained reconstructed20x15ft core plan and generic12over12/6x8pane stock set assumed model scale, not historical survey or purchases.',
  'train_rms_px':float(np.sqrt(np.mean(error[train]**2))),'held_out_rms_px':float(np.sqrt(np.mean(error[held]**2))),
  'light':'Reconstructed[6,4,7] rather than prior[6,-2,7]: source gable/front timbers are lit; same light in both actual before/after captures. Exact solar angle/date is not asserted.',
  'limits':'Gale1902plate caption1836; retrospective1835narrative. Andreas roof/door conflicts remain. Generic sash/door/stack and core barred lights/two stacks still differ. No matches verdict.'})
(B/'snapshot/data/reference_views/log_jail/gale-compound-pilot.json').write_text(json.dumps(camera,indent=2)+'\n')
result={'status':'LIGHT only; camera and rounded target unselected/unrendered','fit':dict(zip(ns['names'],x.tolist())),
 'train_rms_px':camera['solve']['train_rms_px'],'held_out_rms_px':camera['solve']['held_out_rms_px'],
 'base_projection_px':project(x,bases).tolist(),'base_note':'Occlusion bounds only, never visible ground contacts.',
 'points':[{'name':n,'trained':i in train,'source_px':o.tolist(),'projected_px':q.tolist(),'residual_px':(q-o).tolist()} for i,(n,o,q) in enumerate(zip(ns['labels'],obs,pred))]}
(B/'rounded-camera-fit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='points'},indent=2))
