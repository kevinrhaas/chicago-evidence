"""Meaningful frozen native proofs; no renderer, live root or canonical writes."""
from pathlib import Path
import ast,copy,dataclasses,hashlib,importlib.util,json,math,sys,zlib
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;S=B/'snapshot';sys.path.insert(0,str(S/'generators'))
import jsonschema,mesh_inputs
J=lambda p:json.loads(p.read_text())
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
def functions(path):
 tree=ast.parse(path.read_text());nodes=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0)]
 for n in tree.body:
  if isinstance(n,ast.FunctionDef) and n.name!='build':nodes.append(n)
  elif isinstance(n,ast.Assign):
   try:ast.literal_eval(n.value)
   except (ValueError,TypeError):continue
   nodes.append(n)
 ns={'math':math,'zlib':zlib};exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(path),'exec'),ns);return ns
class Collector:
 def __init__(self,name):self.name=name;self.tone_fn=None;self.polys=[]
 def add_poly(self,points,confidence,mat=0):
  points=tuple(tuple(p) for p in points);centre=tuple(sum(p[k] for p in points)/len(points) for k in range(3))
  tones=tuple(self.tone_fn(p,centre,mat) if self.tone_fn else 1. for p in points)
  self.polys.append((points,confidence,mat,tones));return []
def capture(ns,p,name):
 b=Collector(name);ns['_worm_fence' if p.wall_kind=='worm_fence' else '_stockade'](b,p);return b.polys
p0=module('jointpali_old',S/'previous-inputs/generators/archetypes/palisade_params.py');p1=module('jointpali_new',S/'generators/archetypes/palisade_params.py')
n0=functions(S/'previous-inputs/generators/archetypes/palisade.py');n1=functions(S/'generators/archetypes/palisade.py')
legacy=J(B/'legacy-controls.json');assert len(legacy)==15
for row in legacy:
 r=J(S/'legacy-controls'/f"{row['structure_id']}.json");ph=next(v for v in r['phases'] if v['id']==row['phase_id'])
 a=p0.from_phase(ph,r);b=p1.from_phase(ph,r);aa=dataclasses.asdict(a);bb=dataclasses.asdict(b)
 assert bb.pop('forecourt_rails')==() and bb.pop('forecourt_wickets')==();assert aa==bb
 assert [f.name for f in dataclasses.fields(type(a)) if not f.kw_only]==[f.name for f in dataclasses.fields(type(b)) if not f.kw_only]
 assert capture(n0,a,Path(row['asset']).stem)==capture(n1,b,Path(row['asset']).stem),row['asset']
print('PASS all15 legacy native parameters/positional fields/raw polygons/material/confidence/tone exact parity.')
schema=J(S/'data/structures.schema.json');records={};recipes={}
for sid in ['log_jail','log_jail_keeper_house','log_jail_palisade']:
 r=J(S/'data/structures'/f'{sid}.json');jsonschema.validate(r,schema);records[sid]=r;ph=r['phases'][0]
 p=mesh_inputs.resolve_params(r['archetype'],ph,r);p.validate();recipes[sid+'__'+ph['id']+'.glb']=mesh_inputs.structure_inputs_sha(r,ph)
 if sid!='log_jail':assert not any(k in r for k in ['occupants','person_id','residents'])
old=J(S/'previous-inputs/data/structures/log_jail.json')['phases'][0];now=records['log_jail']['phases'][0]
assert old['footprint']==now['footprint'] and old['position']==now['position']
assert now['form']['wall_height_m']['confidence']=='reconstructed'
gale=J(S/'data/sources/trowbridge_first_jail_gale_1902.json');ucr=J(S/'data/sources/calisphere_ucr_first_jail_catalogue_1930.json')
assert gale['rights_status']=='public_domain' and ucr['rights_status']=='check_required' and 'text_only' in json.dumps(ucr)
pali=records['log_jail_palisade'];ph=pali['phases'][0];p=p1.from_phase(ph,pali);raw=capture(n1,p,'log_jail_palisade__context_1835')
assert not p.wickets and len(p.forecourt_wickets)==1
assert any(tuple(r)==(p.width_m,p.depth_m,0,p.depth_m) for r in p.curtain_runs),'front curtain must remain continuous'
assert any(r[0]==r[2]==p.width_m and r[1]==3.4 and r[3]==p.depth_m for r in p.curtain_runs),'high return missing behind gate'
assert all(v[0]>p.width_m and v[2]>p.width_m for v in p.forecourt_wickets),'outer gate must not cut secure curtain'
assert all(math.isfinite(v) for pts,*_ in raw for pt in pts for v in pt) and all(c==1. for _,c,*_ in raw)
mutations=[('bool',lambda f:f['forecourt_wickets']['value'][0].__setitem__(0,False)),
 ('string',lambda f:f['forecourt_wickets']['value'][0].__setitem__(0,'7.8')),
 ('nan',lambda f:f['forecourt_wickets']['value'][0].__setitem__(0,float('nan'))),
 ('inside_secure',lambda f:f['forecourt_wickets']['value'][0].__setitem__(0,7.0)),
 ('behind_front',lambda f:f['forecourt_wickets']['value'][0].__setitem__(1,5.0)),
 ('diagonal',lambda f:f['forecourt_wickets']['value'][0].__setitem__(3,5.8)),
 ('too_far',lambda f:f['forecourt_rails']['value'][0].__setitem__(2,40.)),
 ('tall',lambda f:f['forecourt_wickets']['value'][0].__setitem__(4,2.)),
 ('wide_gate',lambda f:f['forecourt_wickets']['value'][0].__setitem__(2,12.)),
 ('four_rails',lambda f:f['forecourt_rails']['value'][0].__setitem__(5,4)),
 ('fractional_rails',lambda f:f['forecourt_rails']['value'][0].__setitem__(5,2.5)),
 ('overlap',lambda f:f['forecourt_rails']['value'][0].__setitem__(0,8.3)),
 ('no_high_curtain',lambda f:f['curtain_runs'].update(value=[])),
 ('worm',lambda f:f['wall_kind'].update(value='worm_fence')),
 ('ordinary_gate',lambda f:f.update(gate_sides={'value':['n']})),
 ('too_many_rails',lambda f:f['forecourt_rails'].update(value=f['forecourt_rails']['value']*3))]
for name,mut in mutations:
 q=copy.deepcopy(ph);mut(q['form'])
 try:p1.from_phase(q,pali)
 except (ValueError,TypeError):pass
 else:raise AssertionError('missing refusal '+name)
result={'status':'LIGHT PASS; actual export/browser UNRUN','legacy_default_raw_parity':15,'meaningful_refusals':len(mutations),'three_record_schema_and_native_params':'PASS','core_plan_and_placement_unchanged':True,'high_return_and_front_continuous':True,'outer_gate_not_secure_gap':True,'all_new_palisade_confidence_reconstructed':True,'palisade_polygons':len(raw),'front_pickets':max(1,round(p.width_m/p.picket_spacing_m)),'recipes':recipes,'production_pending_masters':18,'recipe_no_asset_implication':True,'walker_limits':'Whole secure envelope only; forecourt rail/wicket not collision-consumed; no interior access claim.'}
(B/'light-proof.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS3 schemas/native parameters, source rights distinction, fixed core plan/anchor, full high return and separate outer gate,16 meaningful guards.')
print(json.dumps(result,indent=2))
