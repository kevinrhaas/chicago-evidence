"""LIGHT exact native Covers and source-specific supporting merge proposals."""
from pathlib import Path
import ast,json,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;S=B/'snapshot';sys.path.insert(0,str(S/'tools'))
import compile_liberties as cl
tree=ast.parse((S/'tools/validate.py').read_text());nodes=[]
for n in tree.body:
 if isinstance(n,ast.FunctionDef) and n.name in ['graded_values','inferred_values']:nodes.append(n)
 elif isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['STRUCTURE_ASPECTS','PHASE_ASPECTS'] for t in n.targets):nodes.append(n)
ns={};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(S/'tools/validate.py'),'exec'),ns)
records={sid:json.loads((S/'data/structures'/f'{sid}.json').read_text()) for sid in ['log_jail','log_jail_keeper_house','log_jail_palisade']}
claims=ns['inferred_values'](records);tokens=sorted('.'.join([sid]+([pid] if pid else [])+[aspect]) for sid,pid,aspect,_ in claims)
raw=', '.join('`'+v+'`' for v in tokens);errors=[];parsed=cl.parse_covers(raw,'L-log-jail-gale-compound-2380',errors);assert not errors,errors
assert len(parsed)==len(tokens)==24
body='''### L-log-jail-gale-compound-2380 — The pictured jail compound and separate outer rail

**Covers:** COVERS.

**Decision:** Prepare an UNSELECTED research candidate from the independently public-domain Gale/Trowbridge1902 plate, captioned1836. Preserve the existing reconstructed20×15ft core plan and geographic anchor; test3.92m core eave with22degree roof,5.50×3.40m keeper house at2.95m eave/27.3degrees, and7.70×5.622m high enclosure at3.24m. These are chosen appearance dimensions under an assumed model/pane scale, not historical measurements or an accepted camera solve. Alternative native glazing hypotheses give different heights.

**Corrected controls:** Visible roof corners, window heads/sills, door head and curtain corners govern the research fit. The earlier keeper wall-foot equalities are withdrawn: foreground rails obscure the base and door bottom. No invented ground datum or4.2m roof-only overfit is adopted. The rounded candidate retains31px training and27px held-out width/far-head error and must be actually rendered before any judgment. Exact pane stock, framing, material tones, hidden faces, door/stack/sash details and context positions remain reconstructed.

**Corrected boundary:** Native source detail clearly shows high pointed timbers behind the entire low gate. Keep the high return/front continuous; the low wicket is separate outer street-rail/keeper-forecourt furniture, not a cut in the prison boundary. House origin is reconstructed relative(6.40,−0.35)m; enclosure origin stays(−0.35,−0.35)m. Full-height runs stop at the partly embedded house. The external closed wicket is chosen1m wide/high; a14m straight three-rail run continues from it. Sections,2m maximum post interval, offsets and closed instant are reconstructed. The secure footprint does not pretend to include these external rails or provide a passage.

**Timber and light:**0.25m split sections/0.27m spacing give about29front posts toward the roughly28–30legible source rhythm;0.25m points, all stock and hidden returns are chosen proxies. Existing six-sided split facets/material slots/_TONE are retained. Neutral photo_match does not consume_TONE. Reconstructed source-facing[6,4,7]sun is shared by both comparison captures; no exact historic time/weather is asserted.

**Source and dates:** Gale's retrospective1835p51 walk names the small jail concealed in high palisade and keeper house partly within, facingRandolph; the plate explicitly says1836. July continuity remains an inference. Andreas1884shows a different hip/pyramidal rear cap and keeper doorway face in a later courthouse ensemble; the later separate oaken cell is not securely identified. Do not invent a phase/alteration date or duplicate cell to clear either image. UCR's1930creation/issuance/copy facts remain check_required/text_only, with collection credit; use the independent1902 publication, not rights-held copy-specific additions. No JohnBeach person/occupant identity is linked.

**Interaction and clearance limits:** Native conservative timber-plan hull is0.571m inside the drawn Randolph block edge, with no drawn/control roadway intrusion or lot overlap; the PublicSquare has no lots. Keeper stoop margin is2.080m. These are project-derived plan checks, not archival setbacks or terrain QA. Native doorway zones overlap the filled secure envelope. A flat native walker reaches the keeper-door centre at0.34m standoff and traverses25m sidewalk, but ignores the external CLOSED wicket/rail. The core approach is blocked and an inside spawn is pushed out. No whole-apron/hand clearance, external-gate collision, interior passage or app/terrain QA pass is claimed.

**Scope:** Empty-default keyword-only forecourt controls preserve every existing15palisade master's native parameter/positional/geometry/material/confidence/tone output. Adoption still requires18fresh masters:15shared-family refreshes plus changed core and two context members, with derivatives and full gates. This increment changes no shared frame/outbuilding module. Missing core barred lights/two stacks, keeper gable lights, facade/roof material details, plankwalk/flagstaff and other source context remain. Original T-2380 stays open; no matches or grade promotion is asserted.

**Ticket:** T-2380.
**Recorded:** 2026-10-23.
'''.replace('COVERS',raw)
(B/'proposed-liberty-replacement.md').write_text(body)
(B/'exact-covers.json').write_text(json.dumps({'native_parser':'compile_liberties.parse_covers','native_enumerator':'validate.inferred_values','count':len(tokens),'tokens':tokens,'claims':parsed},indent=2)+'\n')
(B/'name-pool-additions.json').write_text(json.dumps({'merge_read_structures_union':['phases[].form.forecourt_rails.note','phases[].form.forecourt_wickets.note'],'prerequisite_paths_still_required':['phases[].form.curtain_runs.note','phases[].form.wickets.note'],'instruction':'Merge into the current normal name-pool declaration; never replace other paths or restamp producer receipts.'},indent=2)+'\n')
permissions=[{'structure_id':'log_jail_keeper_house','why':'Gale1902 actualp51 explicitly places the keeper house partly in the jail enclosure facingRandolph (gale_1902_jail_walk_text). The exact public-domain plate trowbridge_first_jail_gale_1902 supplies visible compound form. July1835presence/continuity is inferred; actual plate caption1836 and all chosen metrics/relative coordinates remain bounded. This admits this keeper-house component, not an unrelated dwelling/person identity.'},
 {'structure_id':'log_jail_palisade','why':'Gale1902p51 explicitly says the small log jail is concealed by a high plank palisade (gale_1902_jail_walk_text). Actual trowbridge_first_jail_gale_1902 additionally shows a distinct low outer street rail/keeper-forecourt gate with high timbers behind it. This source-specific boundary/outer-frontage context is admitted on the reservedPublicSquare at the namedRandolph-facing compound, including the reconstructed14mrail run; it is not a blanket reserved-land or military-works waiver. ExactJuly1835completion/metrics are not proved; platecaption1836 and retrospective1835narrative remain separate.'}]
(B/'reserved-ground-permission-merge.json').write_text(json.dumps({'block_id':'blk_randolph_lasalle','merge_only_these_structure_ids':permissions},indent=2)+'\n')
with (S/'assets/LICENSES.md').open('a') as f:f.write('\n\n## Unadopted T-2380 joint research pilot\n\nThe three procedural pilot masters log_jail__log_1833.glb, log_jail_keeper_house__context_1835.glb and log_jail_palisade__context_1835.glb derive only from project generators/data and independently published1902Gale/Trowbridge artwork (trowbridge_first_jail_gale_1902), public domain by age. The reference data/sources/assets/jail-gale1902/upright.png is a lossless clockwise quarter-turn of that verified plate. Exact title/copyright/page provenance is retained in its source record and recovery evidence. No geometry, texture or copy-specific newspaper/UCR addition is derived from the separate rights-held catalogue surrogate. Dimensions, pane stock, contact/rail placement, closed instant and materials are reconstructed;July1835continuity is inferred from the retrospective text, not proved by the1836caption. Temporary outputs are not asset promotion or image acceptance.\n')
print('PASS native24 exact reconstructed Covers; prepared2normal name-pool additions and specific reserved-ground merge entries.')
