"""Sealed unselected joint pilot: only execute under a new parent heavy grant."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,subprocess,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;S=B/'snapshot';J=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def commands(root,m,candidate):
 out=[]
 if candidate:
  out.append([m['blender'],'-b','-noaudio','--factory-startup','--threads','2','--python',str(root/'generators/build.py'),'--','--only','log_jail,log_jail_keeper_house,log_jail_palisade','--scene','1835','--no-bake','--out',str(root/'assets/gltf'),'--wrote',str(root/'wrote.txt')])
 out.append(['node',str(root/'tools/photo_match.mjs'),str(root/'data/reference_views/log_jail/gale-compound-pilot.json'),'--glb','assets/gltf/log_jail__log_1833.glb','--out',str(root/'reviews')])
 return out
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute',action='store_true');ap.add_argument('--accept-unselected-pilot',action='store_true');args=ap.parse_args()
 m=J(B/'snapshot.json');manifest=J(B/'snapshot-manifest.json')
 assert sha(Path(__file__))==m['runner_sha256'],'runner drift'
 assert not any(p.is_symlink() for p in S.rglob('*'))
 assert {str(p.relative_to(S)) for p in S.rglob('*') if p.is_file()}==set(manifest),'snapshot file-set drift'
 for rel,w in manifest.items():assert sha(S/rel)==w['sha256'],'snapshot drift: '+rel
 for name,w in m['actual_predecessor_assets'].items():assert sha(S/'assets/gltf'/name)==w['sha256'],'actual baseline asset drift'
 plan={label:commands((B/'runs/PLAN'/label).resolve(),m,label=='candidate') for label in ['baseline','candidate']}
 for group in plan.values():
  for cmd in group:
   if '--python' in cmd:assert Path(cmd[cmd.index('--python')+1]).is_absolute()
 if not args.execute:
  print('DRY RUN PASS: sealed inputs only; no live canonical reads.0 baseline builds +3 actual candidate exports +2 same-camera/light complete3-member captures. UNSELECTED/UNRUN.');print(json.dumps(plan,indent=2));return
 assert args.accept_unselected_pilot,'parent must select this still-unresolved research pilot under a heavy grant'
 for key,want in [('blender','blender_binary_sha256'),('chromium','chromium_launcher_sha256'),('chromium_binary','chromium_binary_sha256')]:assert sha(Path(m[key]))==m[want],key
 env={**os.environ,**m['allowed_runtime_dependencies'],'PYTHONDONTWRITEBYTECODE':'1','PW_EXECUTABLE':m['chromium']};env.pop('NODE_OPTIONS',None)
 stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S-%f');run=B/'runs'/stamp
 for label in ['baseline','candidate']:
  root=run/label;shutil.copytree(S,root,symlinks=False)
  if label=='baseline':
   for rel in m['increment_files']:
    shutil.copyfile(root/'previous-inputs'/rel,root/rel)
   for sid in m['group']:
    rel='data/sidecars/1835/'+sid+'.json';shutil.copyfile(root/'previous-inputs'/rel,root/rel)
  cmds=commands(root.resolve(),m,label=='candidate');dump(root/'commands.json',cmds)
  for i,cmd in enumerate(cmds):
   with (root/f'command-{i}.log').open('w') as log:subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
   if '--python' in cmd:
    wrote=(root/'wrote.txt').read_text().splitlines();assert len(wrote)==3 and set(wrote)==set(m['recipes']),'export scope drift'
    manifest_actual=J(root/'assets/manifest.json')['assets']
    for asset,w in m['recipes'].items():assert manifest_actual[asset]['inputs_sha256']==w,'actual recipe drift: '+asset
  cam=root/'data/reference_views/log_jail/gale-compound-pilot.json';match=J(cam.with_suffix('.match.json'))
  assert match['verdict']=='unreviewed' and [v['structure_id'] for v in match['rendered_members']]==m['group'],'group/verdict drift'
  print(label,'finished:',root/'reviews',flush=True)
 before=J(run/'baseline/data/reference_views/log_jail/gale-compound-pilot.json');after=J(run/'candidate/data/reference_views/log_jail/gale-compound-pilot.json');assert before==after,'camera/light differs'
 print('All jobs exited. Inspect source and actual comparisons before a verdict. No adoption, promotion, app/ticket writes, production bake or closure. Known missing details/interaction/source conflicts remain.')
if __name__=='__main__':main()
