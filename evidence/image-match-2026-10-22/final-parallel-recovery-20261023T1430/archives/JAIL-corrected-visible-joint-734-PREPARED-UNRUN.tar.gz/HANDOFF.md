# T-2380 closed research handoff — 2026-10-23

**UNSELECTED / UNAPPLIED / actual new export and browser review UNRUN. Original image acceptance remains DIFFERS and open.** This packet closes research for handoff; it does not establish a matching building, solve the camera, or authorize canonical adoption. No live process or heavy slot remains held.

The sealed `snapshot/` has 668 ordinary files, 17,863,767 bytes, no project symlinks. `snapshot-manifest.json` pins every file. All project inputs, absolute build-script paths, source image, prior actual assets, camera and required consumer modules are frozen. Shared pinned Blender, Chromium, Node and Python installations are declared runtime dependencies, not live project inputs. `run_preview.py` dry run passed. Preparation scripts record construction history; restore the sealed payload rather than rerunning preparation over it.

After an explicit future heavy-slot grant, the exact command is:

```sh
python3 /tmp/chicago-next-model/T-2380-visible-joint-pilot/run_preview.py --execute --accept-unselected-pilot
```

The bounded runner performs **zero baseline builds, three actual candidate exports, and two complete three-member captures with the same optics and light**. Its baseline is the prior actual UNADOPTED compound proposal, not an adopted production compound. Prior GLBs remain baseline evidence; expected new recipes do not imply new assets exist. There is no bake, variant search, canonical edit or ticket write. A production unit, if later approved after actual comparison, still requires 18 fresh masters: 15 existing palisades, the core jail and two new context members, followed by genuine derivatives and project gates. Do not restamp old producers.

## Corrections retained explicitly

`camera-correction-history/CONTROL-CORRECTION.md` records two errors exposed by native-source review. The presumed keeper wall bases at about y1094–1100 are rails/threshold occlusion, not visible ground equality. Earlier height conclusions using them are withdrawn; raw conditional results remain preserved. Corrected controls use visible roof edges, opening heads/sills, door head and palisade features, with only a one-sided hidden-base bound. Six roof-edge endpoints can share a vanishing point after shifts below manual picking uncertainty; no proved inconsistent perspective excuses the model.

Pointed high timbers continue behind the whole low gate in the Gale plate. The low gate is separate outer street-rail/forecourt furniture. Both earlier front-cut and end-return-cut secure wickets are superseded, not erased. The pilot retains the high front and return, and places the low closed gate and three-rail run outside them. The older 14-by-10-foot keeper trial, fixed-height trials, rejected boundary-seeking refit, old captures and conditional measurements remain research history, not alternate accepted solutions.

## Bounded next hypothesis

The core retains the model's 20-by-15-foot plan and position and 22-degree roof, with a **chosen 3.92-metre eave**. The plan and height are reconstructed inputs, not attested measurements. The keeper is a chosen 5.50-by-3.40-metre, one-storey proxy, eave 2.95 metres and pitch 27.3 degrees; no invented upper floor or personal identity is added. The secure curtain is a chosen 7.70-by-5.622-metre envelope, height 3.24 metres. The low gate, rail length, stake count and all exact placements are reconstructed. New forecourt fields are keyword-only, empty by default and separately guarded; shared frame/outbuilding generators are unchanged.

The camera uses corrected default 12/12 generic sash controls as one hypothesis. Competing generic glazing stocks give different scale/height answers. The rounded candidate has about 31.26-pixel training RMS and 27.38-pixel held-out RMS; that is an unsolved camera with visible remaining errors. The separate camera-only refit that hits a range boundary is saved and not selected. Common source-facing light is declared, not material evidence. Native tone attributes are not consumed by the photo renderer. **No new actual picture has been produced for this pilot.**

Core barred lights and two stacks, the keeper's two ground gable lights and attic light, sash/door/log-end/trim details, terrain/plankwalk and other context remain missing or different. Do not claim the complete pictured compound matches after a massing-only research preview.

## Source, rights and date bounds

Geometry research uses the independently public-domain exact Trowbridge drawing printed in Gale's 1902 book, IA `reminiscencesofe00ingale`, plate n79 facing printed page 53; title/copyright evidence is independently retained in prior archives. The plate caption says 1836. Gale's retrospective 1835 walk, page 51, supports a concealed log jail, high palisade and keeper house partly within the enclosure facing Randolph. It does not measure coordinates, eaves or an exact 1 July 1835 arrangement. The model's scene-date choice remains reconstructed.

The separate UCR/Calisphere catalogue copy retains its Created and/or Issued 1930-09-19 fact and check-required/text-only status; that date is not publication proof. No geometry or permission is derived from that catalogue copy or the later 1947 layout. Andreas's independent courthouse/jail plate has a contrasting low hip/pyramidal jail cap and different keeper openings; its separate cell text and fall-1835 courthouse chronology remain unresolved. Both original ticket pictures remain in scope. No John Beach person link is inferred merely from matching a name.

## Light proof and application boundary

`light-proof.json` records exact native raw/default parity for all 15 registered legacy palisades, 16 meaningful forecourt refusals, three schema/native-parameter checks, continuous secure front/return, reconstructed confidence, and native recipes. `exact-covers.json` records 24 exact paths checked using the real liberty parser. The liberty replacement, name-pool additions and two specific source-grounded Public Square permissions are separate merge material, not a blanket waiver.

`next-from-actual-compound.patch` changes five files **relative to the frozen prior actual unadopted proposal**. It is not a blind patch against current canonical sourceS/frame work. `apply_owned_overlay.py` writes only under its own temporary overlay directory, checks every before/after hash plus Gale/UCR source hashes, and refuses reapplication and canonical targets. The apply/refusal proof is retained. Later canonical integration requires fresh guarded composition, native compilation, liberty/grade checks and genuine assets; do not weaken an older composer guard.

Drawn block/lot and legal street-control lines were both checked with frozen native consumers. The full actual palisade geometry hull, including the outer rail, has about 0.571-metre north margin; the secure envelope about 0.789 metres. No drawn/control intrusion or lot overlap was found. Keeper stoop conservative margin is about 2.080 metres. These are layout checks on reconstructed context, not historical surveyed permission.

The actual native walker on a flat test substrate passes the 25-metre public route and reaches the keeper door centre with a 0.34-metre wall standoff. **The visual CLOSED outer gate/rail is not collision-consumed; that route crosses it.** The secure curtain is represented as a filled whole envelope: core access is blocked and an inside spawn is pushed outside. Door-zone overlap remains reported. Centre-line arrival does not establish whole-body/hand/apron clearance, terrain app QA or an operable gate. No broad walker rewrite is included.

## Actual predecessor and recovery

`old-actual-evidence-selection.json` selects the first real complete-group run, its two reviewed comparisons, camera/match contracts, actual GLBs/manifests, logs and the corrected direct review. That first actual group **DIFFERS**, and root independently agreed. Its early claim that the house extended beyond the frame was corrected: roof/chimney are inside the full frame but wrongly high relative to the source. Generated-unreviewed match files and subsequently reviewed-differs files remain separate.

Prior archives preserve the earlier roof/compound/clearance proposals and composer (tickets commits 4038f9ff7a39f5457aa37e8d87277e3e39d5c9d8 and 21139bb25925384ba23ba04fc020404509e6e4bb), plus the readiness-only 583-file checkpoint (b08e8c76d2245ef4f671338aa62f18f25ef12ca9). New corrected controls and this pilot supersede specific assumptions without rewriting those archives. The original T-2380 claim will be normally released only after archival confirmation, with handoff reason and original scope intact; never marked done.
