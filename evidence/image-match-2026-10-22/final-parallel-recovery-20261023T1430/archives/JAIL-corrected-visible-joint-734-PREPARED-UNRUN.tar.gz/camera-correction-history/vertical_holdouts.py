"""Add source verticals; reserve far wall corner+foot rather than training every pixel."""
from pathlib import Path
import ast,json
import numpy as np
B=Path(__file__).resolve().parent
# Execute definitions only: do not rerun/write the prior roof-only diagnostic.
tree=ast.parse((B/'analyze.py').read_text());nodes=[]
for node in tree.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cases' for t in node.targets):break
 nodes.append(node)
ns={'__file__':str(B/'analyze.py')};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(B/'analyze.py'),'exec'),ns)
oldxyz=ns['xyz']
def xyz(x):
 a,b,w,d,h,p=x[9:15]
 return np.concatenate([oldxyz(x),np.array([[w,0,h],[w,d,h],[0,d,h]])+[a,b,0]])
ns['xyz']=xyz
ns['obs']=np.concatenate([ns['obs'],[[664,918],[858,878],[1291,882]]])
ns['labels']+=['keeper_near_back_wall_top','keeper_near_front_wall_top','keeper_far_front_wall_top']
train=list(range(8))+[8,9,11,12]
cases=[('level_joint_walls_hold_far_corner',[0,1,3,6,8]+list(range(9,15))),
 ('full_camera_joint_walls_hold_far_corner',[0,1,3,4,5,6,8]+list(range(9,15))),
 ('full_camera_joint_walls_free_core_hold_far_corner',[0,1,3,4,5,6,8]+list(range(9,16))),
 ('full_camera_joint_walls_free_eye_hold_far_corner',[0,1,2,3,4,5,6,8]+list(range(9,15))),
 ('full_camera_joint_walls_free_core_eye_hold_far_corner',[0,1,2,3,4,5,6,8]+list(range(9,16)))]
out=[ns['run'](n,a,train) for n,a in cases]
(B/'vertical-holdout-results.json').write_text(json.dumps({'warning':'New explicit manual wall-top picks: ±10–15px, feet partly hidden. Far-front wall top+foot never trained; core20×15ft plan always fixed. Generic native minima are search constraints, never source findings. No image verdict or new geometry.', 'cases':out},indent=2)+'\n')
for r in out:print(json.dumps({k:v for k,v in r.items() if k in ['case','train_rms_px','holdout_rms_px','bounds_hit','fit']}))
