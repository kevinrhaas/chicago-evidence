"""Allow only reconstructed context width/placement; keep core20x15ft fixed."""
from pathlib import Path
import ast,json
import numpy as np
B=Path(__file__).resolve().parent
tree=ast.parse((B/'compound_holdouts.py').read_text());nodes=[]
for node in tree.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cases' for t in node.targets):break
 nodes.append(node)
c={'__file__':str(B/'compound_holdouts.py')};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(B/'compound_holdouts.py'),'exec'),c)
ns=c['ns'];oldxyz=ns['xyz']
ns['names']+=['palisade_width'];ns['initial']=np.r_[ns['initial'],7.85];ns['lo']=np.r_[ns['lo'],6.9];ns['hi']=np.r_[ns['hi'],8.2]
# Old6.65m house bound was a chosen clearance, not evidence.6.4 remains beyond
# native core's log/roof tip≈6.354m. No walkable side passage is asserted.
ns['lo'][9]=6.4
def xyz(x):
 pts=oldxyz(x[:17]);pts[[14,16],0]=x[17]-.35;return pts
ns['xyz']=xyz
cases=[
 ('context_width_fixed_core',[0,1,3,4,5,6,8]+list(range(9,15))+[16,17]),
 ('context_width_free_core',[0,1,3,4,5,6,8]+list(range(9,18))),
]
out=[ns['run'](n,a,c['train'],c['sigma']) for n,a in cases]
(B/'context-plan-holdout-results.json').write_text(json.dumps({'warning':'No geometry/camera selected. Core20x15ft plan fixed; context widths6.9–8.2m and keeper x>=6.4m are reconstructed search bounds preserving fixed core tip, not attested dimensions. West curtain and north/front plane fixed; no geospatial or walker claim. Far-front keeper top+foot and far curtain head held out.','cases':out},indent=2)+'\n')
for r in out:print(json.dumps({k:v for k,v in r.items() if k in ['case','train_rms_px','holdout_rms_px','bounds_hit','fit']}))
