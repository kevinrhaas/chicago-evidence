"""Add independently identified front-curtain corners and reserve far head."""
from pathlib import Path
import ast,json
import numpy as np
B=Path(__file__).resolve().parent
tree=ast.parse((B/'vertical_holdouts.py').read_text());nodes=[]
for node in tree.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cases' for t in node.targets):break
 nodes.append(node)
c={'__file__':str(B/'vertical_holdouts.py')};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(B/'vertical_holdouts.py'),'exec'),c)
ns=c['ns'];oldxyz=ns['xyz']
ns['names']+=['palisade_height'];ns['initial']=np.r_[ns['initial'],2.8];ns['lo']=np.r_[ns['lo'],2.0];ns['hi']=np.r_[ns['hi'],3.5]
ns['labels']+=['palisade_near_front_foot','palisade_far_front_foot','palisade_near_front_head','palisade_far_front_head']
ns['obs']=np.concatenate([ns['obs'],[[1390,1168],[2030,1139],[1390,840],[2030,880]]])
def xyz(x):
 return np.concatenate([oldxyz(x[:16]),[[7.5,5.272,0],[-.35,5.272,0],[7.5,5.272,x[16]],[-.35,5.272,x[16]]]])
ns['xyz']=xyz
train=c['train']+[14,15,16]
# Picket silhouette/corner read ±15px; foot partly hidden±20px; roof10px.
sigma=np.array([10]*8+[20]*3+[12]*3+[20,20,15,15])[train,None]
cases=[
 ('complete_group_fixed_core_free_palisade',[0,1,3,4,5,6,8]+list(range(9,15))+[16]),
 ('complete_group_free_core_free_palisade',[0,1,3,4,5,6,8]+list(range(9,17))),
 ('complete_group_fixed_core_free_eye_palisade',[0,1,2,3,4,5,6,8]+list(range(9,15))+[16]),
]
out=[ns['run'](n,a,train,sigma) for n,a in cases]
(B/'compound-holdout-results.json').write_text(json.dumps({'warning':'LIGHT ANALYTIC ONLY. Palisade near/far front feet+near head train; far head and far keeper wall top/foot remain held out. Existing7.85x5.622 envelope fixed relative core; palisade height is reconstructed and allowed2–3.5m. Picture points±15–20px, not surveyed post centers. No phase/metric selected.','cases':out},indent=2)+'\n')
for r in out:print(json.dumps({k:v for k,v in r.items() if k in ['case','train_rms_px','holdout_rms_px','bounds_hit','fit']}))
