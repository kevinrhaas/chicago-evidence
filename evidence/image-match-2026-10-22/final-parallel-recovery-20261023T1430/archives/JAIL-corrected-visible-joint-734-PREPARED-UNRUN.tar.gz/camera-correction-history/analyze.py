"""Light, finite 3D camera diagnostics. No renderer or canonical writes."""
from pathlib import Path
import json,math,hashlib
import numpy as np
from scipy.optimize import least_squares
B=Path(__file__).resolve().parent
old=json.loads((B/'input-roof-fit.json').read_text())
core=np.array(old['roof_points_model_m'],float)
labels=['core_near_ridge','core_near_front_eave','core_far_front_eave','core_far_ridge',
        'keeper_near_ridge','keeper_near_back_roof_eave','keeper_near_front_roof_eave','keeper_far_front_roof_eave',
        'keeper_near_back_wall_foot','keeper_near_front_wall_foot','keeper_far_front_wall_foot']
obs=np.array(old['roof_points_source_px']+[[751,780],[646,913],[855,868],[1295,874],[664,1094],[857,1100],[1289,1098]],float)
names=['eye_u','eye_v','eye_height','yaw','pitch','roll','focal','cx','cy',
       'keeper_u','keeper_v','keeper_width','keeper_depth','keeper_eave','keeper_pitch','core_eave']
initial=np.array([17.36007893680829,19.804130569075454,1.7,214.79591841294882,0,0,2577.806775370104,1370.5,892.5371066958759,6.85,.2048,6.096,4.2672,2.4,30,2.66])
lo=np.array([8,8,.8,190,-12,-5,500,900,500,6.65,-2,3.5,3,2.35,25,2.35])
hi=np.array([100,100,3,260,12,5,20000,1840,1600,12,3,10,8,3.4,55,5.0])
def basis(x):
 y,p,r=np.deg2rad(x[3:6]);forward=np.array([np.sin(y)*np.cos(p),np.cos(y)*np.cos(p),np.sin(p)])
 right=np.array([np.cos(y),-np.sin(y),0]);up=np.cross(right,forward)
 return right*np.cos(r)+up*np.sin(r),up*np.cos(r)-right*np.sin(r),forward
def xyz(x):
 a,b,w,d,h,p=x[9:15];rise=(d+.5)/2*math.tan(math.radians(p))
 house=np.array([[w,d/2,h+rise],[w,-.25,h],[w,d+.25,h],[0,d+.25,h],[w,0,0],[w,d,0],[0,d,0]])+[a,b,0]
 c=core.copy();c[:,2]+=x[15]-2.66
 return np.concatenate([c,house])
def project(x):
 right,up,forward=basis(x);delta=xyz(x)-x[:3];dep=delta@forward
 return np.column_stack([x[7]+x[6]*(delta@right)/dep,x[8]-x[6]*(delta@up)/dep])
def run(name,active,train,sigma=10):
 active=list(active)
 def unpack(v):
  a=initial.copy();a[active]=v;return a
 def loss(v):
  a=unpack(v);errors=((project(a)[train]-obs[train])/sigma).ravel()
  # Tiny orientation prior only selects among ambiguous roofs; never counted as source evidence.
  return np.r_[errors,a[4]/100,a[5]/100]
 best=None
 shift=np.zeros_like(initial);shift[:16]=[8,12,0,0,1,0,1200,0,20,0,0,-1,-.5,0,0,0]
 for start in [initial,initial+shift]:
  v=np.clip(start[active],lo[active]+1e-8,hi[active]-1e-8)
  r=least_squares(loss,v,bounds=(lo[active],hi[active]),max_nfev=450)
  if best is None or np.sum(loss(r.x)**2)<best[0]:best=(np.sum(loss(r.x)**2),r)
 r=best[1];x=unpack(r.x);pred=project(x);hold=[i for i in range(len(obs)) if i not in train]
 residual=np.linalg.norm(pred-obs,axis=1)
 return {'case':name,'status':'UNSELECTED ANALYTIC ONLY; NOT RENDERED',
   'trained_points':[labels[i] for i in train],'held_out_points':[labels[i] for i in hold],
   'fit':dict(zip(names,x.tolist())),'basis_right_up_forward':[v.tolist() for v in basis(x)],
   'train_rms_px':float(np.sqrt(np.mean(residual[train]**2))),
   'holdout_rms_px':float(np.sqrt(np.mean(residual[hold]**2))) if hold else None,
   'bounds_hit':[names[i] for i in active if min(abs(x[i]-lo[i]),abs(x[i]-hi[i]))<.002],
   'jacobian_singular_values':np.linalg.svd(r.jac,compute_uv=False).tolist(),
   'points':[{'name':n,'trained':i in train,'source_px':o.tolist(),'projected_px':p.tolist(),'residual_px':(p-o).tolist()} for i,(n,o,p) in enumerate(zip(labels,obs,pred))]}
cases=[
 ('full_camera_core_roof_only',[0,1,3,4,5,6,8],list(range(4))),
 ('level_joint_roofs',[0,1,3,6,8]+list(range(9,15)),list(range(8))),
 ('full_camera_joint_roofs',[0,1,3,4,5,6,8]+list(range(9,15)),list(range(8))),
 ('full_camera_joint_roofs_free_principal',[0,1,3,4,5,6,7,8]+list(range(9,15)),list(range(8))),
 ('full_camera_joint_roofs_free_core',[0,1,3,4,5,6,8]+list(range(9,16)),list(range(8))),
]
out=[run(*c) for c in cases]
result={'warning':'Camera/target fitting diagnostics, not historical metric inference or selected adoption. Fixed20x15ft core remains reconstructed in canonical record; source caption1836, retrospective1835 narrative. Level and full-basis cases use identical training points; keeper feet are NEVER trained.',
 'bounds':dict(zip(names,zip(lo.tolist(),hi.tolist()))),'cases':out}
(B/'results.json').write_text(json.dumps(result,indent=2)+'\n')
for r in out:print(json.dumps({k:v for k,v in r.items() if k in ['case','train_rms_px','holdout_rms_px','bounds_hit','fit']}))
# The same physical direction must have one projective vanishing point. Three
# u-direction roof edges test that without metric dimensions or a camera solve.
edges=[('core_ridge',obs[0],obs[3]),('core_front_eave',obs[1],obs[2]),('keeper_front_eave',obs[6],obs[7])]
lines=[]
for n,a,b in edges:
 line=np.cross(np.r_[a,1],np.r_[b,1]);line=line/np.linalg.norm(line[:2]);lines.append(line)
pair=np.cross(lines[0],lines[1]);vp=pair[:2]/pair[2]
crosscheck={'method':'Common-u-direction vanishing-point holdout; two core edges train, keeper edge held out; no metric assumptions.',
 'core_only_vanishing_point_px':vp.tolist(),
 'keeper_edge_perpendicular_distance_at_vp_px':float(abs(np.dot(lines[2],np.r_[vp,1]))),
 'keeper_edge_y_at_core_vp':float(-(lines[2][0]*vp[0]+lines[2][2])/lines[2][1]),
 'source_edges':[{'name':n,'a':a.tolist(),'b':b.tolist()} for n,a,b in edges],
 'limits':'Large extrapolation amplifies manual endpoint error. This tests the parallel-wall/parallel-ridge interpretation and source sketch consistency, not a statistical rejection of all possible historic target shapes.'}
(B/'vanishing-holdout.json').write_text(json.dumps(crosscheck,indent=2)+'\n')
print(json.dumps(crosscheck))
