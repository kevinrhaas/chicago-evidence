**CONTROL INTERPRETATION SUPERSEDED:** Read [CONTROL-CORRECTION.md](CONTROL-CORRECTION.md) first. Earlier keeper-base equalities are not valid ground controls; raw results below remain as dated research history. The low gate is separate outer forecourt furniture, not a secure-curtain cut.

# T-2380 full-camera / holdout audit — LIGHT, UNAPPLIED

No Blender, browser, canonical/app/ticket writes, asset production or new image verdict. Earlier sealed proposals, raw actual comparisons and unselected14×10ft trial are preserved. No heavy runtime is held.

## Original pictures actually inspected

The original ticket lists exactly two images. Their dimensions/hashes and the independently published detailed artwork are pinned in `source-inputs.json`.

1. `chicago_cook_county_jail_1836.jpg`: later high-contrast newspaper reproduction of the detailed Gale/Trowbridge composition. Header says “Cook County's First Jail Over100YearsAgo”; it is not a contemporary1836 photograph. The independent1902Gale n79 plate is the geometry/camera source, with title/copyright proof already adopted. Its actual caption explicitly says1836. UCR's creation/issuance1930field remains separate/text-only/check-required; no copy-specific layout or publication is relabelledPD.
2. `chicago_first_courthouse_1835.jpg`: actual Andreas1884artwork with visible copyright, showing courthouse and background jail compound. The filename's1835 is not a source-provedJulydate. The courthouse itself dates afterJuly, in fall1835. The matching CookCounty1884caption independently identifies the whole ensemble as courthouse+jail; it does not label the rear block as the original1833cell rather than the later separate oaken cell.

The fullGale plate and newspaper reproduction are the same composition, not independent confirmations. The Andreas composition is independent and materially different: shallow hip/pyramidal rear cap instead of the detailed high gable; keeper gable has a ground-level door+window/attic light rather than the detailed image's two ground sash/attic light with door on the long face. Occlusion hides the core base/openings in Andreas. No camera can turn ahip intoagable or move anopening toaperpendicularwall. An assignment to phases/different cells remains unproven; no invented alteration date or duplicate cell is introduced to clear the gate.

Gale retrospective1835p51walk places keeperhouse partly in the enclosure facingRandolph; its actual plate says1836. That supports compound relationship, not every detail by1July1835. Alloriginal views remain open. Source conflicts must be stated and a governing reading chosen explicitly; publication age alone does not decide which roof stood inJuly.

## Held model inputs and tested camera freedoms

Core plan20×15ft is fixed throughout, exactly as requested. It is a fixed **model** input: canonical footprint explicitly calls it reconstructed/INVENTED and says no dimension was reached, so it is not described as a surveyed historic plan. Initial core eave2.66m/pitch22°/eye1.7m are also held inputs, later varied only in labelled diagnostics. Existing placement never moves.

`analyze.py` tests level and genuine3Dbasis cameras with yaw/pitch/roll, finite focal/principal bounds, two starting poses and native keeper roof expansion(.25m overhang each depthside). Four core roof points plus four keeper roof points train the joint roof cases; **all three keeper feet are held out**. It does not fit the camera merely to hide the keeper.

| Diagnostic | Trained roofRMS | Held-out keeper feetRMS | Interpretation |
|---|---:|---:|---|
|Level, fixedcore|41px|45px|Native keeper minima and placement bounds hit.|
|Fullbasis, fixedcore|26px|103px|Pitch/roll reduce rooferror but worsen ground projection. Reject as a complete solve.|
|Fullbasis, freeprincipal|25px|105px|Extra intrinsic freedom does not repair holdouts.|
|Fullbasis, freecoreheight|11px|242px|Returns4.325m eave by overfitting roofs; emphatically **not evidence for4.2m**.|

The core-only fullcamera also remains underconstrained:13px trainedrooferror,318px keeperholdouterror, pitchbound hit. A flatfour-point roof fit cannot establish the fullcompound camera.

## Add vertical wall constraints and reserve far corner

`vertical_holdouts.py` adds near keeperwall tops and feet; **far-front walltop+foot remain untrained**. This constrains camera roll through actual verticaledges rather than accepting aroof-only pose. With fixed2.66m core, fullcamera gives34px train/30px holdout. Free core gives3.35m eave,28px train/27px holdout, with the camera-distance/keeper-minimum bounds hit. Free eyeheight yields similar residuals but hits its0.8m minimum.

`pitch_holdouts.py` also varies the reconstructed22°core roof while keeping20×15ftplan fixed. Fixedcoreeave gives27.45°roof,33px train/28px holdout; freecoreeave gives3.36m/21.57°,28px train/27px holdout. These are sensitivities, **not selected dimensions**. Generic keeper minima2.35m/25° remain active and therefore partly determine every relative-height result. There is no independent absoluteheightcalibration. More physical sourceconstraints/sourcepoint uncertainty and actual completegroup comparison are required before choosing any higher core or roofangle.

All manual picks are visible in the earlier `T-2380-joint-fit-next/source-picks.png`; added walltop picks are listed in `vertical_holdouts.py`. Roofpicks are approximate8–10px, walltops10–15px and obscuredfeet~20px. Residuals remain larger than those intended uncertainties; no numerical convergence is a picturematch. These studies do not fit palisade corners yet because their mapping is entangled with the newly discovered wicket/end-return topology; adopting the incorrect front-wall wicket as acontrol would bias the solve.

## Test sketch consistency honestly

The two corelongroof edges extrapolate tovanishingpoint(2912,811); the untouched keeperlongroof edge misses it by85px at that distant point. That initially looks suspicious. But `vanishing_tolerance.py` fits onecommon vanishingpoint toallsixoriginalendpoints, allowing their lines toshift within the manualreading uncertainty: only4px endpointRMS/5.4px max. Therefore **these edges do not prove inconsistent sketchperspective**. Largeextrapolation magnifies smallendpointchanges. No excuse to discard the picture or distort the target is inferred.

## Concrete next scope

Do not run/promote the unselected14×10ft trial as afinal solution. It remains acontrolled future comparison only. The strongest independent topology correction is still the lowwicket on the house-to-nearcorner return and acontinuouslongfrontcurtain. Existingparameters express that without a sharedgeneratorchange. Exacthousemassing and wholecamera are still open.

Nextsourcecontrols should explicitly map both frontpalisadecorners, housewallbaseverticals, coregableextent exposedabovehouse and barredlight/stack silhouettes; use one subset tosolve and others asholdouts. Bothoriginalviewfamilies need separate cameras and explicit roof/doorconflict notes. Do not trainoneclosedgate/courtforeground rectangle as though it were asurveyed physicalcorner. Anewcamera must improve those independentcontrols, not merely lower roofRMS.

Current243outbuilding/271frame_dwelling/15palisademasters were counted separately in the prior lightpackage. Pictured2corestacks and barredgable/side apertures cannot be generated honestly by the current one-forge-stack/tinyfixedvent scheme; future opt-in detail changes must preserve defaults and price that sharedfamilyunit. Existing palisade already has splitfacets/_TONE; neutralphoto_match does notconsume_TONE. No global material/normalshack is added here.

Results and scientificdiagnostics are recoverable as scripts+JSON. They create no fakeGLBs, historical coordinates, phase dates, occupancy identities or walkerpassage claims. Original imagegate remains **differs/open**.
