"""Endpoint-space consistency rather than misleading far-VP extrapolation."""
from pathlib import Path
import json,math
import numpy as np
from scipy.optimize import least_squares
B=Path(__file__).resolve().parent
r=json.loads((B/'vanishing-holdout.json').read_text());edges=np.array([[a['a'],a['b']] for a in r['source_edges']],float)
def residual(v):
 vp=v[:2];theta=v[2:];normals=np.column_stack([-np.sin(theta),np.cos(theta)])
 return np.einsum('ijk,ik->ij',edges-vp,normals).ravel()
angles=np.arctan2(edges[:,1,1]-edges[:,0,1],edges[:,1,0]-edges[:,0,0])
fit=least_squares(residual,np.r_[r['core_only_vanishing_point_px'],angles],max_nfev=250)
out={'warning':'All3 edges trained in this separate tolerance diagnostic; not a holdout. Uncertain hand-drawn endpoints permit rotation/shift, so the85px far-VP discrepancy alone is NOT proof of sketch inconsistency.',
 'common_vp_px':fit.x[:2].tolist(),'endpoint_perpendicular_residual_px':residual(fit.x).reshape(3,2).tolist(),
 'endpoint_rms_px':float(np.sqrt(np.mean(residual(fit.x)**2))),
 'endpoint_max_px':float(max(abs(residual(fit.x)))),
 'manual_roof_pick_sigma_px':10,
 'conclusion':'If endpoint residuals lie within manual reading/drawing uncertainty, reject a claim of proven inconsistent perspective from these edges alone.'}
(B/'vanishing-tolerance.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
