"""Corrected LIGHT joint fit: native visible openings, no wall-base equality."""
from pathlib import Path
import ast,dataclasses,importlib.util,json,math,sys
import numpy as np
from scipy.optimize import least_squares
B=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frozen_frame_params',B/'native_frame_dwelling_params.py');fp=importlib.util.module_from_spec(spec);sys.modules[spec.name]=fp;spec.loader.exec_module(fp)
old=json.loads((B/'input-roof-fit.json').read_text());core=np.array(old['roof_points_model_m'])
names=['eye_u','eye_v','yaw','pitch','roll','focal','principal_y','keeper_u','keeper_v','keeper_width','keeper_depth','keeper_eave','keeper_pitch','core_eave','palisade_height','palisade_width']
initial=np.array([25,30,215,-2,0,4000,1100,6.85,.2048,6.096,4.2672,2.8,30,2.66,2.8,7.85])
lo=np.array([8,8,190,-15,-5,500,300,6.4,-3,3.5,3,2.35,25,2.35,2,6.9])
hi=np.array([100,100,260,15,5,20000,2200,12,3,10,8,3.4,55,5,3.5,8.2])
labels=['core_near_ridge','core_near_front_eave','core_far_front_eave','core_far_ridge',
 'keeper_near_ridge','keeper_near_back_roof_eave','keeper_near_front_roof_eave','keeper_far_front_roof_eave',
 'keeper_left_front_window_head','keeper_left_front_window_sill','keeper_right_front_window_head','keeper_right_front_window_sill','keeper_front_door_head',
 'palisade_near_front_foot','palisade_far_front_foot','palisade_near_front_head',
 'keeper_left_window_mid_left','keeper_left_window_mid_right','keeper_right_window_mid_left','keeper_right_window_mid_right',
 'keeper_door_mid_left','keeper_door_mid_right','palisade_far_front_head']
obs=np.array(old['roof_points_source_px']+[[751,780],[646,913],[855,868],[1295,874],
 [944,965],[944,1076],[1072,968],[1072,1074],[1207,973],
 [1390,1168],[2030,1139],[1390,840],
 [919,1020],[969,1020],[1048,1021],[1096,1021],[1185,1030],[1229,1030],[2030,880]],float)
sigma=np.array([10]*8+[10]*5+[20,20,15]+[10]*6+[15],float)
train=list(range(16));hold=list(range(16,len(labels)))
def basis(x):
 y,p,r=np.deg2rad(x[2:5]);f=np.array([np.sin(y)*np.cos(p),np.cos(y)*np.cos(p),np.sin(p)])
 right=np.array([np.cos(y),-np.sin(y),0]);up=np.cross(right,f)
 return right*np.cos(r)+up*np.sin(r),up*np.cos(r)-right*np.sin(r),f
def target(x,key):
 a,b,w,d,h,p=x[7:13];rise=(d+.5)/2*math.tan(math.radians(p))
 roof=np.array([[w,d/2,h+rise],[w,-.25,h],[w,d+.25,h],[0,d+.25,h]])+[a,b,0]
 params=fp.FrameDwellingParams(width_m=w,depth_m=d,stories=1.,wall_height_m=h,roof_pitch_deg=p,construction='braced_frame',plan='single_pen',bays=3,glazing=key,porch='stoop',chimneys=1)
 front=fp.front_wall(params)['openings'];windows=sorted([v for v in front if v['kind']=='window'],key=lambda q:q['u0'],reverse=True);door=next(v for v in front if v['kind']=='door')
 opening=[]
 for win in windows:
  xc=(win['u0']+win['u1'])/2
  opening.extend([[a+xc,b+d+.026,win['z1']],[a+xc,b+d+.026,win['z0']]])
 opening.append([a+(door['u0']+door['u1'])/2,b+d+.03,door['z1']])
 pali=[[x[15]-.35,5.272,0],[-.35,5.272,0],[x[15]-.35,5.272,x[14]]]
 widths=[]
 for v in windows:
  mid=(v['z0']+v['z1'])/2
  # Under positive-u camera the higher-u jamb appears to the source LEFT.
  widths.extend([[a+v['u1'],b+d+.026,mid],[a+v['u0'],b+d+.026,mid]])
 mid=door['z1']-.5
 widths.extend([[a+door['u1'],b+d+.03,mid],[a+door['u0'],b+d+.03,mid]])
 c=core.copy();c[:,2]+=x[13]-2.66
 pts=np.concatenate([c,roof,opening,pali,widths,[[-.35,5.272,x[14]]]])
 bases=np.array([[a+w,b,0],[a+w,b+d,0],[a,b+d,0]])
 return pts,bases,params
def project(x,pts):
 right,up,f=basis(x);d=pts-[x[0],x[1],1.7];dep=d@f
 return np.column_stack([1370.5+x[5]*(d@right)/dep,x[6]-x[5]*(d@up)/dep])
def run(key,free_core):
 active=list(range(13))+([13] if free_core else [])+[14,15]
 def unpack(v):
  x=initial.copy();x[active]=v;return x
 def loss(v):
  x=unpack(v);pts,bases,p=target(x,key);pred=project(x,pts)
  # Only require the base not to terminate ABOVE its last visible/occluded wall.
  # There is no equality to1094–1100 and no invented calibrated ground datum.
  occ=np.minimum(0,project(x,bases)[:,1]-[1094,1100,1098])/20
  return np.r_[((pred[train]-obs[train])/sigma[train,None]).ravel(),occ,x[3]/200,x[4]/200]
 best=None
 for start in [initial,np.array([35,45,215,-5,0,5500,1300,6.7,-1,5.5,4,3.1,28,3.5 if free_core else 2.66,2.8,7.5])]:
  v=np.clip(start[active],lo[active]+1e-7,hi[active]-1e-7)
  r=least_squares(loss,v,bounds=(lo[active],hi[active]),diff_step=.015,max_nfev=220)
  cost=float(np.sum(loss(r.x)**2))
  if best is None or cost<best[0]:best=(cost,r)
 x=unpack(best[1].x);pts,bases,p=target(x,key);pred=project(x,pts);res=np.linalg.norm(pred-obs,axis=1)
 front=fp.front_wall(p)
 return {'case':key+('_free_core' if free_core else '_fixed_core'),'status':'UNSELECTED corrected-control diagnostic; NO actual capture/adoption',
  'fit':dict(zip(names,x.tolist())),'train_rms_px':float(np.sqrt(np.mean(res[train]**2))),'holdout_rms_px':float(np.sqrt(np.mean(res[hold]**2))),
  'weighted_cost':best[0],'bounds_hit':[names[i] for i in active if min(abs(x[i]-lo[i]),abs(x[i]-hi[i]))<.003],
  'basis_right_up_forward':[v.tolist() for v in basis(x)],'native_front_wall':front,
  'base_projection_px':project(x,bases).tolist(),'base_semantics':'Occluded bounds only, not ground controls.',
  'points':[{'name':n,'trained':i in train,'source_px':o.tolist(),'projected_px':q.tolist(),'residual_px':(q-o).tolist()} for i,(n,o,q) in enumerate(zip(labels,obs,pred))]}
out=[]
for key in ['12_over_12_6x8','9_over_6_6x8','6_over_6_6x8']:
 for free in [False,True]:
  r=run(key,free);out.append(r);print(json.dumps({k:r[k] for k in ['case','train_rms_px','holdout_rms_px','bounds_hit','fit']}),flush=True)
(B/'corrected-visible-results.json').write_text(json.dumps({'warning':'No historic dimension/grade or pilot selected. Exact frozen native facade rules and discrete sash/stud setout used; finite-difference step accounts for snapping. Three glazing choices are competing generic pane-stock hypotheses, not asserted source counts or metric calibration. Source wall/threshold/rail lines are NOT ground; earlier equality-based height inferences are withdrawn. Held-out widths and far fence head check overfit.','cases':out},indent=2)+'\n')
