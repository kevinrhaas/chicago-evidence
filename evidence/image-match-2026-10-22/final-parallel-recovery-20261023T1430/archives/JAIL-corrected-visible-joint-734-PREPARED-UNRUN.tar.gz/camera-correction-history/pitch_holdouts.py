"""Test the chosen22deg core roof too, without changing the fixed core plan."""
from pathlib import Path
import ast,json,math
import numpy as np
B=Path(__file__).resolve().parent
tree=ast.parse((B/'vertical_holdouts.py').read_text());nodes=[]
for node in tree.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cases' for t in node.targets):break
 nodes.append(node)
context={'__file__':str(B/'vertical_holdouts.py')};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(B/'vertical_holdouts.py'),'exec'),context)
ns=context['ns'];oldxyz=ns['xyz']
ns['names']+=['core_pitch'];ns['initial']=np.r_[ns['initial'],22.];ns['lo']=np.r_[ns['lo'],15.];ns['hi']=np.r_[ns['hi'],45.]
def xyz(x):
 pts=oldxyz(x[:16]);rise=2.286*math.tan(math.radians(x[16]));eavefall=rise*.25716/2.286
 pts[:4,2]=x[15]+np.array([rise,-eavefall,-eavefall,rise]);return pts
ns['xyz']=xyz
train=context['train'];run=ns['run']
cases=[
 ('full_camera_fixed_core_eave_free_roof_pitch',[0,1,3,4,5,6,8]+list(range(9,15))+[16]),
 ('full_camera_free_core_eave_free_roof_pitch',[0,1,3,4,5,6,8]+list(range(9,17))),
]
out=[run(n,a,train) for n,a in cases]
(B/'pitch-holdout-results.json').write_text(json.dumps({'warning':'Roof22deg is itself reconstructed and may be tested. Core20x15ft plan never changed; far keeper wall corner+foot held out. No camera or metric selected.', 'cases':out},indent=2)+'\n')
for r in out:print(json.dumps({k:v for k,v in r.items() if k in ['case','train_rms_px','holdout_rms_px','bounds_hit','fit']}))
