"""Seal final owned inputs after light proofs. Never executes preview heavy jobs."""
from pathlib import Path
import difflib,hashlib,json,os,re,subprocess,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;S=B/'snapshot';J=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (B/'snapshot.json').exists(),'already frozen; use a new package for further variants'
def human(s):
 s=re.sub(r'(?<=[A-Za-z])(?=\d)', ' ',s)
 s=re.sub(r'(?<=\d)(?=[A-Za-z])', ' ',s)
 return s.replace('PublicSquare','Public Square').replace('sourcecaption','source caption').replace('platecaption','plate caption').replace('streetrail','street rail').replace('keeperhouse','keeper house').replace('coreeaves','core eaves')
def clean(n):
 if isinstance(n,dict):
  return {k:human(v) if k in ['note','research_note','why'] and isinstance(v,str) else clean(v) for k,v in n.items()}
 if isinstance(n,list):return [clean(v) for v in n]
 return n
for sid in ['log_jail','log_jail_keeper_house','log_jail_palisade']:
 p=S/'data/structures'/f'{sid}.json';p.write_text(json.dumps(clean(J(p)),indent=2,ensure_ascii=False)+'\n')
for name in ['proposed-liberty-replacement.md']:
 p=B/name;p.write_text(human(p.read_text()))
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','PYTHONPATH':'/workspace/shared/python'}
cam=S/'data/reference_views/log_jail/gale-compound-pilot.json';rawcam=cam.read_bytes();cam.unlink()
with (B/'native-compile-final.log').open('w') as log:subprocess.run([sys.executable,str(S/'tools/compile_preview_members.py')],cwd=S,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
cam.write_bytes(rawcam)
for script in ['verify_light.py','check_clearance.py']:
 with (B/(script+'.log')).open('w') as log:subprocess.run([sys.executable,str(B/script)],cwd=B,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
with (B/'walker_light.log').open('w') as log:
 nodeenv={**os.environ};nodeenv.pop('NODE_OPTIONS',None);subprocess.run(['node',str(B/'walker_light.mjs')],cwd=B,env=nodeenv,stdout=log,stderr=subprocess.STDOUT,check=True)
rels=['data/structures/'+sid+'.json' for sid in ['log_jail','log_jail_keeper_house','log_jail_palisade']]+['generators/archetypes/palisade.py','generators/archetypes/palisade_params.py']
patch=''
for rel in rels:
 a=(S/'previous-inputs'/rel).read_text();b=(S/rel).read_text()
 patch+=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(B/'next-from-actual-compound.patch').write_text(patch)
files={str(p.relative_to(S)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in S.rglob('*') if p.is_file()}
assert not any(p.is_symlink() for p in S.rglob('*'))
(B/'snapshot-manifest.json').write_text(json.dumps(files,indent=2)+'\n')
previous=J(B/'previous-runtime.json');provenance=J(B/'input-provenance.json');proof=J(B/'light-proof.json')
meta={k:previous[k] for k in ['blender','blender_binary_sha256','chromium','chromium_launcher_sha256','chromium_binary','chromium_binary_sha256','allowed_runtime_dependencies','group']}
meta.update(status='SEALED UNSELECTED RESEARCH PILOT; actual exports/browser UNRUN',
 actual_predecessor_assets=provenance['actual_predecessor_assets'],recipes=proof['recipes'],increment_files=rels,
 snapshot_files=len(files),snapshot_bytes=sum(v['bytes'] for v in files.values()),project_source_symlinks=0,
 expected_counts={'baseline_builds':0,'candidate_master_exports':3,'same_optic_complete_group_captures':2,'members_each':3,'separate_pending_production_master_unit':18},
 runner_sha256=sha(B/'run_preview.py'),geometry_data_applyable_only_from='Frozen previous actual UNADOPTED compound input; current canonical requires fresh guarded composition, not blind old patch application.',
 sourceS_gale_sha256=sha(S/'data/sources/trowbridge_first_jail_gale_1902.json'),sourceS_ucr_sha256=sha(S/'data/sources/calisphere_ucr_first_jail_catalogue_1930.json'))
(B/'snapshot.json').write_text(json.dumps(meta,indent=2)+'\n')
with (B/'preview-dry-run.log').open('w') as log:subprocess.run([sys.executable,str(B/'run_preview.py')],cwd=B,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Sealed',len(files),'files/',meta['snapshot_bytes'],'bytes; light native/default/guard/clearance/walker and dry runner PASS. Heavy UNRUN.')
