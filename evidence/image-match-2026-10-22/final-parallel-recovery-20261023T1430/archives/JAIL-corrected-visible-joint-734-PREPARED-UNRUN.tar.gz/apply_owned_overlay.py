"""Apply guarded five-file increment only to a disposable overlay inside this package."""
from pathlib import Path
import argparse,hashlib,json,subprocess
B=Path(__file__).resolve().parent;S=B/'snapshot';J=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=argparse.ArgumentParser(description=__doc__);a.add_argument('overlay');args=a.parse_args();target=Path(args.overlay).resolve()
assert target.is_relative_to(B/'owned-overlays'),'refusing any canonical/external target'
m=J(B/'snapshot.json');rels=m['increment_files']
# Finish every read/guard before any mutation. This cannot paper over current root
# or a different sourceS/frame checkpoint; parent must compose those separately.
for rel in rels:
 p=target/rel;assert p.resolve().is_relative_to(target) and not p.is_symlink() and p.is_file(),rel
 assert sha(p)==sha(S/'previous-inputs'/rel),'base drift; no writes: '+rel
for rel,key in [('data/sources/trowbridge_first_jail_gale_1902.json','sourceS_gale_sha256'),('data/sources/calisphere_ucr_first_jail_catalogue_1930.json','sourceS_ucr_sha256')]:
 p=target/rel;assert p.resolve().is_relative_to(target) and not p.is_symlink() and sha(p)==m[key],'sourceS drift; no writes'
subprocess.run(['git','apply','--check',str(B/'next-from-actual-compound.patch')],cwd=target,check=True)
subprocess.run(['git','apply',str(B/'next-from-actual-compound.patch')],cwd=target,check=True)
for rel in rels:assert sha(target/rel)==sha(S/rel),'unexpected result '+rel
print('Applied exact five-file increment to owned review overlay only. No assets, producers, canonical adoption, image verdict or ticket closure.')
