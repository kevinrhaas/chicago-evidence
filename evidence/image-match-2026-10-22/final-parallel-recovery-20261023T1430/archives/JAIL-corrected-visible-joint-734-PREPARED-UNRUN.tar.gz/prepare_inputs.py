"""LIGHT input freeze only; no canonical writes or heavy tools."""
from pathlib import Path
import hashlib,json,shutil
B=Path(__file__).resolve().parent;OLD=Path('/tmp/chicago-next-model/T-2380-preview-readiness');S=B/'snapshot'
J=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not S.exists()
for r,w in J(OLD/'snapshot-manifest.json').items():assert sha(OLD/'snapshot'/r)==w['sha256'],r
shutil.copytree(OLD/'snapshot',S)
actual=OLD/'runs/20261023-122911-699932/candidate';contract=J(OLD/'actual-run-contract.json')
for name,w in contract['candidate_assets'].items():
 p=actual/'assets/gltf'/name;assert sha(p)==w['sha256'];shutil.copyfile(p,S/'assets/gltf'/name)
shutil.copyfile(actual/'assets/manifest.json',S/'assets/manifest.json')
for stem in ['data/structures','data/sidecars/1835']:
 for sid in ['log_jail','log_jail_keeper_house','log_jail_palisade']:
  p=S/stem/f'{sid}.json';dest=S/'previous-inputs'/stem/f'{sid}.json';dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
for name in ['palisade.py','palisade_params.py']:
 dest=S/'previous-inputs/generators/archetypes'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(S/'generators/archetypes'/name,dest)
repo=Path('/workspace/chicago/chicago/4d');master=J(repo/'assets/manifest.json')['assets'];controls=[]
for asset,row in master.items():
 if row.get('archetype')!='palisade':continue
 p=repo/'data/structures'/f"{row['structure_id']}.json";dest=S/'legacy-controls'/p.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
 controls.append({'asset':asset,**row,'record_sha256':sha(p)})
assert len(controls)==15
(B/'legacy-controls.json').write_text(json.dumps(controls,indent=2)+'\n')
for name in ['input-roof-fit.json','corrected-visible-results.json','source-inputs.json','wicket-topology-detail.png','keeper-visible-controls.png']:
 shutil.copyfile(Path('/tmp/chicago-next-model/T-2380-camera-holdouts-next')/name,B/name)
shutil.copyfile(OLD/'snapshot.json',B/'previous-runtime.json')
(B/'input-provenance.json').write_text(json.dumps({'source_snapshot_manifest_sha256':sha(OLD/'snapshot-manifest.json'),'actual_predecessor_contract_sha256':sha(OLD/'actual-run-contract.json'),'actual_predecessor_assets':contract['candidate_assets'],'legacy_count':15,'canonical_writes':False},indent=2)+'\n')
print('Prepared frozen inputs and15 actual legacy controls; no export/browser.')
