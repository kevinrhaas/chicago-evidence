"""LIGHT native footprint/street/entrance consumers on frozen genuine records."""
from pathlib import Path
import ast,json,math,sys,zlib
import numpy as np
from scipy.spatial import ConvexHull
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;S=B/'snapshot'
sys.path[:0]=[str(S/'tools'),str(S/'generators')]
import plat_corridors as pc,plat_occupancy as po,generate_entrances as ge,generate_business_signboards as gbs
from block_faces import face_frame,project
CORRIDOR_LINE='both'
CORRIDOR_LINE_WHY='Drawn lines measure block/lot/frontage seating; control lines separately test legal platted roadway intrusion. Neither line moves.'
J=lambda p:json.loads(p.read_text())
# Native light geometry accumulator from own verifier, definitions only.
tree=ast.parse((B/'verify_light.py').read_text());nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in ['module','functions','Collector','capture']]
ns={'ast':ast,'math':math,'zlib':zlib,'importlib':__import__('importlib'),'sys':sys};exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(B/'verify_light.py'),'exec'),ns)
params=ns['module']('clearance_pali',S/'generators/archetypes/palisade_params.py');builder=ns['functions'](S/'generators/archetypes/palisade.py')
datum=J(S/'data/datum.json');grid=J(S/'data/traces/vectors/thompson_lots.json');block=next(b for b in grid['blocks'] if b['id']=='blk_randolph_lasalle');frames={side:face_frame(block,side) for side in ['north','west']}
drawn=pc.corridors();control=pc.corridors(from_control=True)
records={sid:J(S/'data/structures'/f'{sid}.json') for sid in ['log_jail','log_jail_keeper_house','log_jail_palisade']}
def inspect(poly):
 return {'drawn_block_margins_m':{n:round(-max(project(f,p)[1] for p in poly),5) for n,f in frames.items()},
  'drawn_corridor_intrusion':pc.intrusion(poly,drawn),'control_corridor_intrusion':pc.intrusion(poly,control),
  'lot_overlaps':[(b['id'],i,round(a,5)) for b in grid['blocks'] for i,l in enumerate(b['lots']) if (a:=po.overlap_area(poly,l['polygon']))>po.SLIVER_M2]}
out={'status':'LIGHT native consumers only; no actual mesh/terrain/app/QA pass','corridor_line':CORRIDOR_LINE,'corridor_line_why':CORRIDOR_LINE_WHY,'square_lots':len(block['lots']),'footprints':{}}
for sid,r in records.items():out['footprints'][sid]=inspect(po.world_polygon(r['phases'][0],datum))
pal=records['log_jail_palisade'];ph=pal['phases'][0];p=params.from_phase(ph,pal);raw=ns['capture'](builder,p,'log_jail_palisade__context_1835')
pts=np.array(list({(pt[0],pt[1]) for poly,*_ in raw for pt in poly}));hull=pts[ConvexHull(pts).vertices].tolist();copyph={**ph,'footprint':{'polygon':hull}}
out['native_palisade_geometry_conservative_plan_hull']=inspect(po.world_polygon(copyph,datum))
out['native_palisade_geometry_conservative_plan_hull']['local_polygon']=hull
scs=[J(S/'data/sidecars/1835'/f'{sid}.json') for sid in records];ge._sidecars=lambda:scs;gbs.STRUCTURES=S/'data/structures'
ent=ge.build();zones=ge.doorway_zones();out['entrances']=ent['entrances'];out['entrance_unread']=ent['unread']
for e in out['entrances']:
 zone=next(z for eid,z in zones if eid==e['id'])
 e['other_group_envelope_blockers']=[sid for sid,r in records.items() if sid!=e['structure_id'] and po.overlap_area(zone,po.world_polygon(r['phases'][0],datum))>1e-6]
house=next(e for e in out['entrances'] if e['structure_id']=='log_jail_keeper_house');he,hn=house['at_local_enu_m'];stoop=[[he-.775,hn],[he+.775,hn],[he+.775,hn+.92],[he-.775,hn+.92]]
out['keeper_stoop_conservative_plan']=inspect(stoop)
out['limitations']=['Native accumulator is actual generator logic with official object seed, not a fabricated GLB; only pinned Blender can establish export/image/mesh QA.',
 'Whole secure-footprint envelope remains a filled walker obstacle; forecourt rail/gate lie outside it and are NOT collision-consumed. No closed-gate or inside-yard passage is claimed.',
 'This limited study names3 group structures. It does not certify all-town collisions, terrain, app/mobile QA or image match.',
 'PublicSquare context permission must specifically cite Gale1902p51house/high enclosure and exactPDplateouterrail, with July continuity inference; no blanket reserved-land waiver.']
(B/'clearance-light.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
