# Actual irregular masonry trial — differs

Root executed one pinned candidate export and one fixed-camera photo_match capture; both exited0. The4926-triangle baseline and its actual comparison were held unchanged rather than re-exported or re-rendered. Root directly viewed the complete fresh comparison.

Irregular masonry is visible, but the tower silhouette/proportions, gallery/lantern detail, lighting and provisional camera remain different. The40ft datum, depicted-date continuity and other original pictures remain unresolved. Geometry/material contracts pass within their recorded scope; the Node GLTFLoader state check is not a native-app GPU/Bygrade test. No canonical adoption or image acceptance is claimed.
