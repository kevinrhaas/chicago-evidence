from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,subprocess,zipfile,re,datetime,hashlib
r=Path(__file__).resolve().parent;p=json.loads(Path('/tmp/chicago-wrap-20261023/FINAL-HEAD-SMOKE-PLAN.json').read_text());out=r/'08f-smoke-final-logs';out.mkdir(exist_ok=True)
def api(endpoint):return json.loads(subprocess.check_output(['gh','api',endpoint],text=True,timeout=45))
def collect(row):
 rid=row['id'];run=api(f"repos/{p['repository']}/actions/runs/{rid}");assert run['head_sha']==p['head'] and run['workflow_id']==p['workflow_id'] and run['event']=='workflow_dispatch' and run['head_branch']==p['branch']
 (out/f'{rid}-run.json').write_text(json.dumps(run,indent=2)+'\n');result={**row,'status':run['status'],'conclusion':run['conclusion'],'attempt':run['run_attempt']}
 if run['status']!='completed':return result
 assert run['conclusion']=='success',result
 jobs=api(f"repos/{p['repository']}/actions/runs/{rid}/attempts/{run['run_attempt']}/jobs");(out/f'{rid}-jobs.json').write_text(json.dumps(jobs,indent=2)+'\n');smoke=next(j for j in jobs['jobs']if j['name']=='smoke');assert smoke['conclusion']=='success';assert next(x for x in smoke['steps']if x['name']=='Run the smoke against the published mirror')['conclusion']=='success'
 archive=out/f'{rid}-attempt{run["run_attempt"]}.zip'
 if not archive.exists():
  response=subprocess.run(['gh','api',f"repos/{p['repository']}/actions/runs/{rid}/attempts/{run['run_attempt']}/logs"],capture_output=True,timeout=120);assert response.returncode==0,response.stderr.decode();archive.write_bytes(response.stdout)
 with zipfile.ZipFile(archive)as z:
  path=next(n for n in z.namelist()if n.startswith('smoke/')and n.endswith('Run the smoke against the published mirror.txt'));text=z.read(path).decode();(out/f'{rid}-actual-smoke.txt').write_text(text)
  checkout_path=next(n for n in z.namelist() if n.startswith('smoke/') and 'Run actions_checkout@v4.txt' in n and 'Post Run' not in n)
  checkout=z.read(checkout_path).decode();lines=checkout.splitlines();where=next(i for i,line in enumerate(lines) if 'git log -1 --format=%H' in line);checkout_head=lines[where+1].split()[-1];assert checkout_head==p['head'];(out/f'{rid}-actual-checkout.txt').write_text(checkout)
 assert 'node tools/smoke_renderer.mjs --published' in text
 assert re.search(r'SMOKE_VIEWPORT:\s*'+re.escape(row['viewport'])+r'\b',text)
 assert re.search(r'SMOKE_STAGE:\s*'+re.escape(row['stage'])+r'\b',text)
 assert f'stages filtered to "{row["stage"]}" of 15' in text
 assert f'stage {row["stage"]} of 15' in text
 size='390x780'if row['viewport']=='mobile'else'1280x800';assert f'{row["viewport"]} {size}: zero page errors'in text
 matches=list(re.finditer(r'(\d+) passed, (\d+) failed',text));assert matches;summary=matches[-1];assert int(summary[1])>0 and int(summary[2])==0;assert 'SMOKE PASS'in text
 staged=re.search(r'(\d+) staged-section check\(s\) \(stage '+re.escape(row['stage'])+r' of 15\), (\d+) always-on check\(s\)',text);assert staged and int(staged[1])>0 and int(staged[1])+int(staged[2])==int(summary[1])
 result.update({'staged_assertions_passed':int(staged[1]),'always_on_assertions_passed':int(staged[2]),'actual_transcript_verified':True,'actual_checkout_head':checkout_head,'checkout_transcript_sha256':hashlib.sha256(checkout.encode()).hexdigest(),'actual_parts':row['parts'],'actual_viewport_px':size,'assertions_passed':int(summary[1]),'assertions_failed':int(summary[2]),'zero_page_errors':True,'published':True,'log_zip_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'actual_transcript_sha256':hashlib.sha256(text.encode()).hexdigest()});return result
with ThreadPoolExecutor(max_workers=4)as pool:rows=list(pool.map(collect,p['runs']))
complete=all(x.get('actual_transcript_verified')for x in rows)
if complete:
 for v in ['mobile','desktop']:assert sorted(n for x in rows if x['viewport']==v for n in x['actual_parts'])==list(range(1,16))
snapshot={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':p['head'],'workflow_id':p['workflow_id'],'all_ten_actual_transcripts_verified':complete,'all15_parts_at_both_viewports':complete,'merge_performed':False,'root_current_ci_base_head_lease_review_required':True,'runs':rows};name='ALL-TEN-ACTUAL-TRANSCRIPTS.json'if complete else'LATEST-PARTIAL-TRANSCRIPTS.json';(out/name).write_text(json.dumps(snapshot,indent=2)+'\n');print(json.dumps({'snapshot':str(out/name),'verified':sum(x.get('actual_transcript_verified',False)for x in rows),'pending':[(x['viewport'],x['stage'])for x in rows if not x.get('actual_transcript_verified')],'all_ten_verified':complete}),flush=True)
