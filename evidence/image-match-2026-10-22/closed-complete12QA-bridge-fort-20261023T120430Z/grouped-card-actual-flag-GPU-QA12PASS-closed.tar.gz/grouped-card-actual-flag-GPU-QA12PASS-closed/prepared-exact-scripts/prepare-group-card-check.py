from pathlib import Path
import json,hashlib
S=Path('/tmp/source-prerequisite/card-check.mjs');O=Path('/tmp/frame-integration');R=Path('/workspace/chicago/chicago/4d');original=S.read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest()
keys={'green_tree_tavern':['eaves_bays','gable_wall_cladding'],'sauganash_hotel':['cross_wing','cross_wing_end','cross_wing_depth_m','roof_pitch_deg','end_windows','gable_wall_cladding'],'tremont_house_1':['stories','wall_height_m','roof_pitch_deg','chimneys','chimney_placement','corner_entry_surround','elevation_scheme','entry_raise_m','first_story_height_m','flag','flag_anchor','flag_flying','flagstaff','flagstaff_height_m','gable_arch_treatment','gable_lunette','gable_arch_text','roof_colour','shutters']}
expect={}
for sid,fields in keys.items():
 p=R/f'data/structures/{sid}.json';r=json.loads(p.read_text());ph=next(ph for ph in r['phases'] if ph['documented_range']['from']<='1835-07-01'<=ph['documented_range']['to']);expect[sid]={'phase':ph['id'],'grade':'attested','record_sha256':sha(p.read_bytes()),'attributes':{k:{'value':ph['form'][k]['value'],'confidence':ph['form'][k]['confidence']} for k in fields}}
jail_sources={}
for sid in ['trowbridge_first_jail_gale_1902','calisphere_ucr_first_jail_catalogue_1930']:
 p=Path('/workspace/chicago/chicago/4d/data/sources')/(sid+'.json');record=json.loads(p.read_text());jail_sources[sid]={'sha256':sha(p.read_bytes()),'rights_status':record['rights_status'],'asset_use':record['asset_use'],'url':record['url']}
(O/'group-card-expected.json').write_text(json.dumps({'source_script_sha256':sha(original),'review_tree':str(R),'hotels':expect,'jail_supersession':{'grade':'inferred','artwork_use':'Independent verified1902 plate clears artwork; UCR copy stays text_only/check_required','sources':jail_sources}},indent=2)+'\n')
s=original.decode();s=s.replace('Three source-prerequisite cards','Six grouped source/frame prerequisite cards').replace("'/tmp/source-prerequisite/card-check'","'/tmp/frame-integration/group-card-check'")
s=s.replace("const viewports=[['mobile',390,780,true],['desktop',1280,800,false]];", "const viewports=[['mobile',390,780,true],['desktop',1280,800,false]];\nassert(!process.env.QA_VIEWPORT,'Grouped acceptance requires both viewports; unset QA_VIEWPORT');")
s=s.replace("const cards=['st_marys_church','jb_beaubien_homestead','log_jail'];", "const cards=['st_marys_church','jb_beaubien_homestead','log_jail','green_tree_tavern','sauganash_hotel','tremont_house_1'];\nconst expectedHotels=JSON.parse(fs.readFileSync(new URL('./group-card-expected.json',import.meta.url),'utf8')).hotels;")
s=s.replace("return {grade:s?.grade,attributes:s?.attributes,problems:","return {phase:s?.phase,grade:s?.grade,attributes:s?.attributes,problems:")
s=s.replace("     await page.evaluate(async id=>{const a=window.__chicago4d;a.frame(id);a.pick(id);await a.navigator.select('inspect');a.navigator.open(2);},sid);", "     await captureScene(page,sid,prefix);\n     await page.evaluate(async id=>{const a=window.__chicago4d;a.pick(id);await a.navigator.select('inspect');a.navigator.open(2);},sid);")
s=s.replace("     }else{\n      assert.equal(data.grade?.value,'inferred');", "     }else if(sid==='log_jail'){\n      assert.equal(data.grade?.value,'inferred');",1)
needle="      await focusText(researchPane,/IMAGE RESEARCH.*RIGHTS CORRECTION|Keystone.Mast Collection/i);\n     }"
replacement=needle[:-1]+'''else{
      const wanted=expectedHotels[sid];assert(wanted,'hotel expectation missing');
      assert.equal(data.phase,wanted.phase);assert.equal(data.grade?.value,wanted.grade);assert(data.grade.pictures?.length>0,'hotel whole-picture grade basis missing');
      for(const [key,claim] of Object.entries(wanted.attributes)){
       assert.deepEqual(data.attributes?.[key]?.value,claim.value,`${sid} ${key} value`);
       assert.equal(data.attributes?.[key]?.confidence,claim.confidence,`${sid} ${key} confidence`);
      }
      const displayed=await sourcesPane.evaluate(p=>[...p.querySelectorAll('details.src-fact')].map(d=>({label:d.querySelector('.src-label')?.innerText.trim(),grade:d.dataset.grade})));
      write(`${prefix}-displayed-source-grades.json`,displayed);
      const plain=key=>key.replaceAll('_',' ').toLowerCase();
      const normalized=label=>String(label||'').toLowerCase().replace(/[()]/g,'').trim();
      for(const key of sid==='green_tree_tavern'?['eaves_bays','gable_wall_cladding']:sid==='sauganash_hotel'?['end_windows','gable_wall_cladding','roof_pitch_deg']:['flag','flag_anchor','flag_flying','flagstaff','entry_raise_m','gable_arch_treatment','gable_arch_text','roof_colour']){
       const fact=displayed.find(f=>normalized(f.label)===plain(key));
       assert(fact,`${sid} actual Sources fact missing: ${key}`);assert.equal(fact.grade,wanted.attributes[key].confidence,`${sid} visible Sources grade ${key}`);
      }
      assert.match(research.text,/Grade\\s+Attested\\b/i,'hotel whole-building grade not visible');
      if(sid==='tremont_house_1'){
       assert.match(photos.text,/Gifford/i,'actual Gifford image credit missing');
       assert(photos.links.some(a=>/chicagology\\.com\\/prefire\\/prefire021/i.test(a.url)),'actual Tremont source link missing');
       for(const key of ['flag','flag_anchor','flag_flying'])assert(!['record_only','absent','simplified'].includes(data.attributes[key].geometry),`${key} falsely marked unbuilt`);
       await focusText(researchPane,/Gifford|flag|reconstruct/i);
      }else{
       assert.match(photos.text,/Andreas/i,'actual Andreas image credit missing');assert.match(photos.text,/1884/,'actual 1884 publication credit missing');
       assert(photos.links.some(a=>/archive\\.org\\/(?:details|download)\\/historyofchicago01andr/i.test(a.url)),'actual Andreas plate source link missing');
       await focusText(researchPane,/reconstruct|Andreas/i);
      }
     }'''
# The replacement adds an explicit hotel branch; keep the jail branch closing brace.
replacement=replacement.replace("\n     else{","\n     }else{")
assert needle in s;s=s.replace(needle,replacement,1)
helpers=Path('/tmp/frame-integration/group-scene-helper.txt').read_text()
s=s.replace('try {\n await new Promise((resolve,reject)=>',helpers+'\ntry {\n await new Promise((resolve,reject)=>',1)
s=s.replace("scene screenshots.","scene screenshots.")
s=s.replace("research_credit_checked:true,screenshot_prefix:prefix", "research_credit_checked:true,hotel_expected_attributes:sid in expectedHotels?expectedHotels[sid].attributes:null,screenshot_prefix:prefix")
# The source-only script is historical and remains unchanged. This group uses
# the superseding, actually inspected Gale1902 artwork source and copy caveats.
start=s.index("     }else if(sid==='log_jail'){")+len("     }else if(sid==='log_jail'){\n")
end=s.index("     }else{\n      const wanted=expectedHotels[sid];",start)
s=s[:start]+(O/'jail-gale-1902-assertions.txt').read_text()+s[end:]
# Verified1902 hotel sources add actual visible credit/original-link/date-limit checks.
hotel_anchor = "       assert(photos.links.some(a=>/archive\\.org\\/(?:details|download)\\/historyofchicago01andr/i.test(a.url)),'actual Andreas plate source link missing');\n"
assert s.count(hotel_anchor)==1
hotel_checks='\n'.join('       '+line for line in (O/'hotel-gale-1902-assertions.txt').read_text().splitlines())+'\n'
s=s.replace(hotel_anchor,hotel_anchor+hotel_checks)
# Read the native summary text before CSS text-transform. The visible innerText
# is uppercase; comparing it to mixed-case Record left the real fold closed.
record_selector="d.querySelector(':scope > summary')?.innerText.trim()==='Record'"
assert s.count(record_selector)==1
s=s.replace(record_selector,"d.querySelector(':scope > summary')?.textContent.trim().toLowerCase()==='record'")
# Layout is measured only after the actual Navigator finite CSS transitions finish.
# The diagnostic observed a 50px dock pane with three running time0 transitions,
# then a 288px pane/288px scrollWidth after their native finished promises.
marker="async function snapshotPane(page,target,prefix,key){\n"
assert s.count(marker)==1
s=s.replace(marker,marker+" // Await the real dock-to-open transition before measuring readable card layout.\n await page.locator('.navigator').evaluate(async n=>{getComputedStyle(n).width;await Promise.all(n.getAnimations().filter(a=>Number.isFinite(a.effect.getComputedTiming().endTime)).map(a=>a.finished));});\n",1)
(O/'group-card-check.mjs').write_text(s)
assert S.read_bytes()==original,'source-only script changed'
print(json.dumps({'source_preserved_sha256':sha(original),'group_sha256':sha(s.encode()),'expected_hotels':list(expect)},indent=2))
