# T-2375 independent source audit: closed evidence only

No tracked code, source record, model, camera, ticket or published asset changed. Original T-2375 remains open with verdict differs. Frozen board/profile previews remain unchanged. The cumulative proposal still dry-applies to the current source; all six bridge masters require actual recipe refresh through the supported bake path if shared controls are integrated.

Actual Andreas1884 p631 at IA n1295 was downloaded and viewed. It is the exact composition used by the frozen proposal reference, independently establishing the existing1884 publication basis for that underlying artwork. Proposed inferred board/profile/bearing controls cite only that public-domain source; rise/sections remain reconstructed. The separate Baker-Co Old Point engraving remains check_required and was not cleared by this audit.

An unapplied metadata-only proposal corrects the Andreas record's false exclusions of lighthouse, warehouses and background masts, plus its unsigned-author claim despite a visible Braunhold signature. Parent must review exact attribution before integrating. No rights assertion was silently changed in the repository.

Kirkland1892 title, copyright and actual p119 were also viewed. It reuses the Andreas composition with diagonal leaf-panel crosspieces and is not the separate Baker-Co picture. Actual p119 quotes Hurlbut, quoting the Times, that the draw worked by chain cables and opened with cranks. This is retrospective secondary text, not a verified1834 specification/newspaper issue, and does not settle exact machinery or dimensions. It should inform future T-2375 research without promoting reconstruction or accepting an image match.

See SOURCE-AUDIT.json and KIRKLAND-1892-READING.json for exact URLs, hashes, current source/record scope and limitations. A Moses1895 p94 illustration remains only a search lead; no actual page was viewed or cleared. Large OCR finding aids are omitted; the actually inspected primary pages and reproducible URLs are retained. Future agents must preserve attribution, declared liberties and remaining camera/image differences.
