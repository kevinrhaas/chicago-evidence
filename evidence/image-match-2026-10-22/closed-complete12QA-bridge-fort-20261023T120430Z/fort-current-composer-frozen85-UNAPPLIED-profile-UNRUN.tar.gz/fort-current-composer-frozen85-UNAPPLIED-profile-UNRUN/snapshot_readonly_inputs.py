"""Capture only read-only consumer dependencies for a fresh guarded proof."""
from pathlib import Path
import hashlib,json,subprocess
H=Path(__file__).resolve().parent
R=Path('/workspace/chicago')
PATHS=['chicago/4d/tools/compile_pictures.py', 'chicago/4d/tools/compile_scene.py', 'chicago/4d/tools/compile_source_use.py', 'chicago/4d/tools/replace_invented_residents.py', 'chicago/4d/tools/compile_liberties.py', 'chicago/4d/tools/validate.py', 'chicago/4d/tools/generate_entrances.py', 'chicago/4d/generators/mesh_inputs.py', 'chicago/4d/generators/code_inputs.py', 'chicago/4d/generators/common/openings.py']
rows=[{'path':p,'sha256':hashlib.sha256((R/p).read_bytes()).hexdigest()} for p in PATHS]
(H/'readonly-consumer-inputs.json').write_text(json.dumps({'source_head':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),'inputs':rows},indent=2)+'\n')
print('Captured10read-onlyconsumerdependencies; canonical tree untouched')
