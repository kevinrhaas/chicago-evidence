# Bridge printed p631 source audit: future source-only dependency

This note links an independently verified audit; it is NOT part of the21-file fort patch or25-fort-family geometry. The bridge source correction is UNAPPLIED here, and no bridge generator, record, master, camera or source file is included in this fort candidate.

Audit: `/tmp/chicago-next-model/T-2375-source-audit-20261023/SOURCE-AUDIT.json`, observed2026-10-23T10:59:15Z. The actual1884 Andreas volume1 printed p631/IA leaf n1295 shows the exact captioned drawbridge composition: peaked boarded closed-draw parapets, gallows/bearing cribs, foreground boat, alongside schooner, lighthouse, warehouses and additional masts. Its old source prose incorrectly excluded those background features and called the plate unsigned; the clearer oriented reference carries L.Braunhold,del. Locator upper-half wording also needs correction. These are source/credit fixes, not new metric evidence or an accepted camera.

Actual page URL: https://archive.org/download/historyofchicago01andr/page/n1295_large.jpg
Page SHA256: e4385ac4b95796ca4fff6370c2d7b1c2c0abfd6733e60fb9b794012da1f0ac8b
Reference SHA256: e050ec582de1c82416a77ac9958fdc7ac174946037ac7c7816f93367f182aa8b
Both hashes were rechecked for this dependency note. The downloaded derivative is mirrored; the held historical reference is correctly oriented. The audit establishes the source's1884 US-publication public-domain basis independently of the separate Baker-Co engraving, whose `dearborn_street_bridge_1834_engraving` record remains check_required. No blanket rights change is made.

Before future T-2375 geometry adoption, integrate the narrowly corrected `andreas_1884_dearborn_drawbridge_plate` source/credit and producer/card evidence together, using `andreas_1884_dearborn_drawbridge_plate.corrected-proposal.json`, `source-prose-correction.patch` and `proposal-notes.md` in that audit directory. Retain qualitative retrospective inference and reconstructed1.2m trial rise/sections; do not promote them to surveyed metrics. The bridge remains differs/open and its eventual shared-helper bake is a separate six-bridge-family action. It does not expand or block this public-domain-based fort25 proposal.
