#!/usr/bin/env bash
# Prepared for root review. Default is read-only. Never called with--apply by child.
set -euo pipefail
fort_adoption_package="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$fort_adoption_package/verify_current.py"
case "${1:---dry-run}" in
  --dry-run) ;;
  --apply) git -C /workspace/chicago apply "$fort_adoption_package/staged/current-tree.patch" ;;
  *) printf '%s\n' 'usage: apply.sh [--dry-run|--apply]' >&2; exit 2 ;;
esac
