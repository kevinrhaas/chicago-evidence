#!/usr/bin/env python3
"""Read-only root integration planner. Emits guarded patch ONLY under /tmp."""
from pathlib import Path
import sys,copy,json,hashlib,difflib,importlib.util,subprocess,re,ast
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;REPO=Path('/workspace/chicago');F=Path('/tmp/chicago-next-model/fort-selective-integration');FACE=Path('/tmp/chicago-next-model/T-2387-face-layout-next');N=Path('/tmp/chicago-next-model/T-2373-narrow-trial');P=Path('/tmp/chicago-next-model/T-2373-profile-next');ROOT='chicago/4d/';OUT=H/'staged'
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
sha=lambda b:hashlib.sha256(b).hexdigest() if b is not None else None
base=load(F/'materialize.py','fort_prior_materializer')
# Entire original frozen prerequisite is guarded and plan() writes nothing.
outputs,report=base.plan(REPO)
receipts={row['path']:row for row in report['files']}
def current(rel):return outputs[rel][1] if rel in outputs else (REPO/rel).read_bytes() if (REPO/rel).exists() else None
def set_output(rel,data):
 before=(REPO/rel).read_bytes() if (REPO/rel).exists() else None;outputs[rel]=(before,data)
def merge_json(rel,old,new):
 now=json.loads(current(rel)) if current(rel) else None;changes=[];doc=base.merge(old,new,now,changes=changes);set_output(rel,(json.dumps(doc,ensure_ascii=False,indent=2)+'\n').encode());receipts[rel]={'path':rel,'strategy':'exact_leaf3way','changes':changes}
# Apply only five new face attributes, preserving base galleries and current independent JSON fields.
for p in (FACE/'candidate'/ROOT/'data/structures').glob('*.json'):
 rel=str(p.relative_to(FACE/'candidate'));merge_json(rel,json.loads((FACE/'baseline'/rel).read_text()),json.loads(p.read_text()))
# Narrower physical polygon/radius first, then profile/apertures and note clarifications.
rr=ROOT+'data/structures/chicago_lighthouse_1832.json'
merge_json(rr,json.loads((N/'baseline'/rr).read_text()),json.loads((N/'candidate'/rr).read_text()))
merge_json(rr,json.loads((P/'baseline'/rr).read_text()),json.loads((P/'candidate'/rr).read_text()))
# Final two modules already compose all reviewed features; guard every frozen proposed byte.
for rel in [ROOT+'generators/archetypes/fort_structure.py',ROOT+'generators/archetypes/fort_structure_params.py']:
 pinned=next(r for r in json.loads((P/'inputs.json').read_text()) if r['path']==rel)
 data=(P/'candidate'/rel).read_bytes();assert sha(data)==pinned['candidate_sha256'];compile(data.decode(),rel,'exec');set_output(rel,data);receipts[rel]={'path':rel,'strategy':'base_module_guard_then_frozen_composed_module','frozen_sha256':sha(data)}
for rel in [ROOT+'generators/archetypes/facade_openings.py',ROOT+'tools/generate_business_signboards.py']:
 old=(FACE/'baseline'/rel).read_bytes();new=(FACE/'candidate'/rel).read_bytes();now=current(rel)
 if now not in (old,new):raise base.Conflict(rel+': independent current reader edit; recompose explicitly')
 set_output(rel,new);receipts[rel]={'path':rel,'strategy':'exact_guarded_reader'}
# Upgrade source from the ACTUAL1842 publication audit, not a guessed Commons description.
srel=ROOT+'data/sources/castelnau_1842_chicago_harbor.json'
merge_json(srel,json.loads((F/'staged/candidate'/srel).read_text()),json.loads((P/'source-next-research.json').read_text()))
# Repair only unlanded liberty drafts. Current ledger remains an exact preserved prefix.
fragments=[]
for p in sorted((F/'evidence/liberty-fragments').glob('*.md')):
 text=p.read_text().replace('L-lake-house-open-shell-T-2379','L-lake-house-open-shell-t-2379')
 if p.name=='second-fort-cupola-2388.md':
  start=text.index('**Covers:**');end=text.index('\n\n**Decision:**',start)
  text=text[:start]+'**Covers:** '+', '.join('`fort_dearborn_blockhouse.log_1816.form.'+k+'`' for k in ['cupola','cupola_width_m','cupola_height_m','cupola_roof_pitch_deg','chimneys'])+'.'+text[end:]
 fragments.append((p.name,text))
fragments.append(('lighthouse-narrow.md',(N/'LIBERTY-APPEND.md').read_text()))
faceids=['commanding_officers_barracks','north_range','officers_barracks','soldiers_barracks_se','soldiers_barracks_sw']
facecovers=', '.join('`first_fort_dearborn_'+s+'.first_fort_1803.form.face_openings`' for s in faceids)
fragments.append(('first-fort-face-layout.md','''### L-first-fort-face-layout-t2387-next — Counted range openings, reconstructed joinery

**Covers:** '''+facecovers+'''.
**Decision:** Whistler's actual1808 folded elevations show four front rectangles per storey on the north, southwest, southeast and commanding ranges, and five on the west officers range. Their exact metric set-out, window/door interpretation, glazing and casing are reconstructed. One ground door occupies the central bay, or the left central bay in even-count ranges. Rear rectangles retain the earlier reconstruction; upper rectangles remain windows, not asserted gallery doors. No plan, origin, position, bearing, date or wall height is changed.
**Source and limit:** `whistler_1808_fort_dearborn_draught`; a primary1808 drawing, not a measured1812 elevation. Count/face assignment is inferred, and continuity to1812 is an inference. Entire explicit layout remains reconstructed.
**How to resolve:** render each actual front and compound view, replace reconstructed identities/metrics only where visible evidence supports it, and retain every unresolved full-match gate.
**Recorded:** 2026-10-23, an increment under T-2387; no match claimed.
'''))
fragments.append(('lighthouse-profile-apertures.md','''### L-lighthouse-profile-apertures-t2373-next — Reconstructed vertical partition and tiny apertures

**Covers:** `chicago_lighthouse_1832.tower_1832.form.tower_profile`, `chicago_lighthouse_1832.tower_1832.form.tower_openings`.
**Decision:** The actual Castelnau1842 plate supplies a lower gallery band, upper rail, tall cap/cage assembly and small shaft marks. Reconstruct gallery underside8.719767m, cap break11.0m, rail1.0m and three tiny single-light windows on existing facets8/10/7. Two light-face apertures are clear; the third shaded mark is less certain. No unequivocal ground door has been identified, and none is invented from masonry or platform shadows.
**Uncertainty:** exact dimensions, framing, glazing, facet assignment and shaft/lantern division are reconstructed. The many decimals reproduce a framing diagnostic, not historical metric precision. Source circa1838 appearance is carried back toJuly1835 by continuity inference. The nominal12.19m/40ft literal remains, but its historical datum is unresolved; it is not asserted as shaft-only, cage-top or overall. Physical total bounds and ground feet are preserved, and no foundation is raised to fit the picture. All new geometry is reconstructed.
**Source:** `castelnau_1842_chicago_harbor`, independently inspected actual1842 publication; no Getty preview is used for this geometry.
**How to resolve:** review actual rendered before/after comparisons, solve remaining camera uncertainty and obtain a contemporary tower specification for the height datum. Every original picture gate remains open.
**Recorded:** 2026-10-23, a research increment under T-2373; no match claimed.
'''))
ledger=(REPO/(ROOT+'docs/LIBERTIES.md')).read_text();newledger=ledger
# Explicit known section is cheap insurance against appending under a newly added custom heading.
if newledger.rstrip().splitlines()[-1].startswith('## '):pass
newledger+='\n\n## Per-subject liberties\n\n'
normalized=H/'normalized-liberty-fragments';normalized.mkdir(exist_ok=True)
for name,text in fragments:
 (normalized/name).write_text(text);newledger,_=base.append_fragment(newledger,text,name)
assert newledger.startswith(ledger);set_output(ROOT+'docs/LIBERTIES.md',newledger.encode());receipts[ROOT+'docs/LIBERTIES.md']={'path':ROOT+'docs/LIBERTIES.md','strategy':'append_normalized_drafts_to_current_exact_prefix','fragments':[x[0] for x in fragments]}
# New notes are declared READ under the existing raw-pool policy; do not ignore names to evade it.
keysrel=ROOT+'data/reconstruction/name_pool_keys.json';keys=json.loads(current(keysrel));read=keys['read']['structures'];ignored=keys.get('ignored',{}).get('structures',{});added=[]
nameword=re.compile(r'\b[A-Z][a-z]{2,}\b')
def leaves(n,p=''):
 if isinstance(n,dict):
  for k,v in n.items():yield from leaves(v,p+'.'+k if p else k)
 elif isinstance(n,list):
  for v in n:yield from leaves(v,p+'[]')
 elif isinstance(n,str):yield p,n
for rel,(_,data) in sorted(outputs.items()):
 if '/data/structures/' not in rel:continue
 for key,text in leaves(json.loads(data)):
  if nameword.search(text) and key not in read and key not in ignored:
   read.append(key);added.append(key)
if added:set_output(keysrel,(json.dumps(keys,ensure_ascii=False,indent=2)+'\n').encode());receipts[keysrel]={'path':keysrel,'strategy':'append_missing_read_paths_to_current','paths':added}
# One whole-tower appearance ruling; never restore old sourceS/frame rulings or infer all30 from a compound.
grel=ROOT+'data/structure_grades.json';grades=json.loads(current(grel));ruling={'scene':'1835','structure':'chicago_lighthouse_1832','picture':'castelnau_1842_chicago_harbor','why':'The independently inspected1842 Castelnau harbour plate shows the full1832 tower, shaft, gallery and lantern, with only its lowest foot partly obscured by the platform/shore details. It is a reasonable whole-building oblique appearance witness. The circa1838 depiction does not attest everyJuly1835 feature unchanged, metric dimensions or an accepted camera match.'}
if any(all(r.get(k)==ruling[k] for k in ['scene','structure','picture']) for r in grades.get('not_pictured',[])):
 raise base.Conflict(grel+': current source reading explicitly excludes the proposed picture; re-review')
existing=[r for r in grades['pictured'] if all(r.get(k)==ruling[k] for k in ['scene','structure','picture'])]
if not existing:grades['pictured'].append(ruling);set_output(grel,(json.dumps(grades,ensure_ascii=False,indent=2)+'\n').encode());receipts[grel]={'path':grel,'strategy':'append_one_whole_tower_appearance_ruling_to_current'}
# Output patch + immutable input guards; never copy manifests/assets/derived source uses.
OUT.mkdir(exist_ok=True);patch=[];rows=[]
for rel,(before,after) in sorted(outputs.items()):
 dest=OUT/'candidate'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(after)
 rows.append({**receipts.get(rel,{'path':rel,'strategy':'base_selective_plan'}),'current_sha256':sha(before),'candidate_sha256':sha(after)})
 if before!=after:
  patch.append('diff --git a/'+rel+' b/'+rel+'\n'+('new file mode 100644\n' if before is None else ''))
  patch.extend(difflib.unified_diff((before or b'').decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+rel if before is not None else '/dev/null',tofile='b/'+rel))
(OUT/'current-tree.patch').write_text(''.join(patch));doc={'source_head':subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip(),'files':rows,'family_refresh':report['family_refresh'],'name_pool_read_paths_added':added,'normalized_liberty_ids':[re.search(r'^### (\S+)',t,re.M)[1] for _,t in fragments],'actual_profile_preview':'pending; do not adopt until actual review','repository_writes':False,'asset_manifest_or_generated_tail_copies':False};(OUT/'review-manifest.json').write_text(json.dumps(doc,indent=2)+'\n');(OUT/'structure-ids.txt').write_text(','.join(r['structure_id'] for r in doc['family_refresh']['assets'])+'\n')
# Refuse evidence staleness caused by concurrent root work, including text/keys/frame/sourceS inputs.
for row in rows:
 p=REPO/row['path'];assert sha(p.read_bytes() if p.exists() else None)==row['current_sha256'],row['path']+':root changed during composition'
subprocess.run(['git','-C',str(REPO),'apply','--check',str(OUT/'current-tree.patch')],check=True)
print(json.dumps({'status':'dry_run_materialized','files':len(rows),'fort_family':len(doc['family_refresh']['assets']),'current_root_preserved':True,'append_only_current_ledger_preserved':True,'name_pool_new_paths':added,'patch_apply_check_pass':True,'profile_preview_still_pending':True},indent=2))
