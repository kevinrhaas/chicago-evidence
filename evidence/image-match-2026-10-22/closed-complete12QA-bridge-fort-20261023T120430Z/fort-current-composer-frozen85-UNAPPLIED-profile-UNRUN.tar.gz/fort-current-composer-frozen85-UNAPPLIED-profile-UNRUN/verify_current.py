from pathlib import Path
import json,hashlib,subprocess
H=Path(__file__).resolve().parent;R=Path('/workspace/chicago');j=json.loads((H/'staged/review-manifest.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest() if b is not None else None
head=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip()
assert head==j['source_head'],'HEAD changed (including any Hogan fold); rematerialize and rerun raw guards'
for row in json.loads((H/'readonly-consumer-inputs.json').read_text())['inputs']:
 assert sha((R/row['path']).read_bytes())==row['sha256'],row['path']+':read-only proof dependency changed; rematerialize'
for row in j['files']:
 p=R/row['path'];assert sha(p.read_bytes() if p.exists() else None)==row['current_sha256'],row['path']+':root changed; recompose and review before applying'
 assert sha((H/'staged/candidate'/row['path']).read_bytes())==row['candidate_sha256'],row['path']+':candidate changed'
for row in j['family_refresh']['assets']:
 p=R/'chicago/4d/assets/gltf'/row['asset'];assert sha(p.read_bytes())==row['current_master_sha256'],row['asset']+':current master changed'
subprocess.run(['git','-C',str(R),'apply','--check',str(H/'staged/current-tree.patch')],check=True)
print('PASS21current-input/candidate guards,25actualmasterguards,patchapplycheck; no writes')
