from pathlib import Path
import shutil
H=Path(__file__).resolve().parent;P=Path('/tmp/chicago-next-model/T-2373-profile-next');C=H/'staged/candidate/chicago/4d';D=H/'proofs/profile'
for name in ['baseline','candidate']:
 for p in (P/name).rglob('*'):
  if p.is_file():
   dest=D/name/p.relative_to(P/name);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for p in C.rglob('*'):
 if p.is_file() and (p.name in ['fort_structure.py','fort_structure_params.py'] or '/data/structures/' in str(p)):
  dest=D/'candidate/chicago/4d'/p.relative_to(C);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
for name in ['check_light.py','camera-profile-research.json','profile-and-openings-next.patch']:shutil.copy2(P/name,D/name)
print('Prepared geometry proof copies; frozen originals unchanged')
