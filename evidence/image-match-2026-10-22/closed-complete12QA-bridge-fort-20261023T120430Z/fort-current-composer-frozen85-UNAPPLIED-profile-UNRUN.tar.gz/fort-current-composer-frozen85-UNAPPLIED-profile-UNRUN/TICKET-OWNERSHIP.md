# Existing ticket ownership — read-only audit

Read the actual local ticket bodies; no claims, ticket writes, new tickets or state changes were made.

- **T-3041**, `T-3000-3249/T-3041-match-the-first-fort-dearborn-buildings-against-.md`: OPEN/M, parent T-2387. Owns full first-fort matching: every picture, all21 named records plus9 extant context records, dated forms, actual before/after and an image gate without unresolved visible differences. This is the closest existing owner of the first-fort portion; a helper or bounded increment cannot complete it.
- **T-3040**: DONE/S, PR1218, parent T-2387. Owns compound-render/stale-review tooling only and explicitly claims no geometry/matches. Do not repurpose it.
- **T-2373**, **T-2379**, **T-2388**: OPEN/M original lighthouse, Lake House construction and second-fort matching; each retains its full image gate and has no current prerequisite child that owns these new shared controls.
- **T-2387**: SPLIT, with its unsatisfied matching ask carried by T-3041; do not describe the original ask as completed.
- **T-2123**: historical DONE/M roof/wood/picket work, PR459; does not own this new capability.

A full-text ticket search for gallery_storeys, lantern_profile, tower_profile, cupola_width_m, 25-family/25-master, shared fort, fort controls and fort.family found no separate existing ticket that owns the combined25-master geometry-capability scope. Use T-3041 for its first-fort work and relate T-2373/T-2379/T-2388 as applicable; do not invent or mutate a completion ticket in this read-only handoff. Root chooses the final workflow. No original full image gate is closed by this proposal.
