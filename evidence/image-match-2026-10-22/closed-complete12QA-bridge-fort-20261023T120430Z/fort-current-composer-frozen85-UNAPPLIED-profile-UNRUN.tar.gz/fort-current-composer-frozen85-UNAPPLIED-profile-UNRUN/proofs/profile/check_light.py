from pathlib import Path
from types import ModuleType
from dataclasses import asdict,replace
import ast,copy,inspect,json,math,sys,subprocess
import numpy as np,jsonschema
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;R=Path('/workspace/chicago');S=Path('/tmp/chicago-next-model/fort-selective-integration/staged/candidate');root='chicago/4d/';pr=root+'generators/archetypes/fort_structure_params.py';gr=root+'generators/archetypes/fort_structure.py';rr=root+'data/structures/chicago_lighthouse_1832.json'
def load(path,name):
 m=ModuleType(name);sys.modules[name]=m;exec(compile(path.read_text(),str(path),'exec'),m.__dict__);return m
old=load(H/'baseline'/pr,'profile_before');new=load(H/'candidate'/pr,'profile_after');added={'tower_openings','tower_profile'}
assert new.CONSUMED==old.CONSUMED|added
assert old.FortStructureParams.__match_args__==new.FortStructureParams.__match_args__
for k,p in inspect.signature(new.FortStructureParams).parameters.items():
 if k in added:assert p.kind==inspect.Parameter.KEYWORD_ONLY and p.default is None
 else:assert p==inspect.signature(old.FortStructureParams).parameters[k]
family=json.loads(Path('/tmp/chicago-next-model/fort-selective-integration/staged/review-manifest.json').read_text())['family_refresh']['assets'];phases=[]
for row in family:
 rel=root+'data/structures/'+row['structure_id']+'.json';path=H/'baseline'/rel if (H/'baseline'/rel).exists() else S/rel if (S/rel).exists() else R/rel
 rec=json.loads(path.read_text());ph=next(p for p in rec['phases'] if p['id']==row['phase_id']);a=old.from_phase(ph,rec);b=new.from_phase(ph,rec);d=asdict(b)
 for k in added:assert d.pop(k) is None
 assert d==asdict(a)
 bpos=new.FortStructureParams(*[getattr(a,k) for k in a.__match_args__],**{k:getattr(a,k) for k,p in inspect.signature(old.FortStructureParams).parameters.items() if p.kind==inspect.Parameter.KEYWORD_ONLY});bpos.validate();dd=asdict(bpos)
 for k in added:dd.pop(k)
 assert dd==asdict(a);phases.append((a,b))
def functions(path):return {n.name:n for n in ast.parse(path.read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
af=functions(H/'baseline'/gr);bf=functions(H/'candidate'/gr)
assert set(bf)==set(af)|{'_TowerFacetBuilder','_tower_apertures','_birdcage_partitioned'}
for name in af:
 if name not in ['_tower','_birdcage_lantern']:assert ast.dump(af[name])==ast.dump(bf[name]),name
sys.path.insert(0,str(R/'chicago/4d/generators'));from common import openings
class Collect:
 def __init__(self):self.faces=[];self.named={}
 def named_mat(self,name,*spec):self.named.setdefault(name,(1000+len(self.named),spec));return self.named[name][0]
 def add_poly(self,points,confidence,mat=0):self.faces.append((tuple(tuple(float(v) for v in p) for p in points),float(confidence),mat));return list(range(len(points)))
mesh=ast.parse((R/'chicago/4d/generators/common/mesh.py').read_text());box=next(n for n in next(n for n in mesh.body if isinstance(n,ast.ClassDef) and n.name=='MeshBuilder').body if isinstance(n,ast.FunctionDef) and n.name=='add_box');ns={};exec(compile(ast.Module(body=[box],type_ignores=[]),'<actual add_box>','exec'),ns);Collect.add_box=ns['add_box']
def extracted(nodes,module):
 names=['_tower','_birdcage_lantern','_TowerFacetBuilder','_tower_apertures','_birdcage_partitioned'];tree=ast.Module(body=[copy.deepcopy(nodes[k]) for k in names if k in nodes],type_ignores=[])
 ns={'math':math,'openings':openings,'M_WALL':0,'M_ROOF':1,'M_DARK':2,'M_TRIM':3,'tower_opening_layout':getattr(module,'tower_opening_layout',None)}
 exec(compile('from __future__ import annotations\n'+ast.unparse(tree),'<actual tower functions>','exec'),ns);return ns
xo=extracted(af,old);xn=extracted(bf,new)
for a,b in phases:
 if a.kind=='tower':
  for profile,lit in [('legacy',False),('legacy',True),('birdcage_dome',True)]:
   ca,cb=Collect(),Collect();xo['_tower'](ca,replace(a,lantern_profile=profile,lantern=lit));xn['_tower'](cb,replace(b,lantern_profile=profile,lantern=lit));assert ca.faces==cb.faces and ca.named==cb.named
baseline=json.loads((H/'baseline'/rr).read_text());candidate=json.loads((H/'candidate'/rr).read_text());oldp=old.from_phase(baseline['phases'][0],baseline);p=new.from_phase(candidate['phases'][0],candidate);before,after=Collect(),Collect();xo['_tower'](before,oldp);xn['_tower'](after,p)
def bounds(col):
 vs=[v for points,_,_ in col.faces for v in points];return [[min(v[i] for v in vs) for i in range(3)],[max(v[i] for v in vs) for i in range(3)]]
ba,bb=bounds(before),bounds(after);assert np.allclose(ba,bb,rtol=0,atol=1e-12),(ba,bb)
# Nominal measured literal and all physical footprint/location/date data remain fixed.
for key in ['position','footprint','documented_range']:assert candidate['phases'][0][key]==baseline['phases'][0][key]
for key,val in baseline['phases'][0]['form'].items():
 if key=='wall_height_m':assert {k:v for k,v in val.items() if k!='note'}=={k:v for k,v in candidate['phases'][0]['form'][key].items() if k!='note'}
 else:assert candidate['phases'][0]['form'][key]==val
assert p.wall_height_m==oldp.wall_height_m==12.19
feet=lambda col:sorted(set(v for points,_,_ in col.faces for v in points if abs(v[2])<1e-9));assert feet(before)==feet(after)
for points,c,mat in after.faces:
 assert c==1 and np.isfinite(np.array(points)).all()
 for i in range(1,len(points)-1):assert np.linalg.norm(np.cross(np.array(points[i])-points[0],np.array(points[i+1])-points[0]))>1e-10
# Existing planar five-range API survives composition; no flat tower front is fabricated.
assert new.front_wall(p) is None
for name in ['north_range','soldiers_barracks_sw','soldiers_barracks_se','officers_barracks','commanding_officers_barracks']:
 rec=json.loads((H/'candidate'/(root+'data/structures/first_fort_dearborn_'+name+'.json')).read_text());pa=old.from_phase(rec['phases'][0],rec);pb=new.from_phase(rec['phases'][0],rec);assert old.front_wall(pa)==new.front_wall(pb)
# Reject profile inversion, impossible rail, datatypes and unsupported use; keep bbox independently checked.
for value in [True,{},dict(p.tower_profile,cap_base_m=99),dict(p.tower_profile,gallery_rail_height_m=3),dict(p.tower_profile,gallery_underside_m=float('nan'))]:
 try:replace(p,tower_profile=value).validate()
 except new.ParamError:pass
 else:raise AssertionError(value)
for change in [{'lantern':False},{'kind':'quarters'},{'lantern_profile':'legacy'}]:
 try:replace(p,**change).validate()
 except new.ParamError:pass
 else:raise AssertionError(change)
# Source control predictions are diagnostic; physical fields were not camera-fit by altering position/grade.
cam=json.loads((H/'camera-profile-research.json').read_text());k=cam['focal_px']/102.8;cy=cam['principal_px'][1];project=lambda z:cy-k*(z-2)
y={'base':project(0),'gallery_underside':project(p.tower_shaft_height_m),'gallery_top':project(p.tower_shaft_height_m+.09),'upper_rail':project(p.tower_shaft_height_m+.09+p.tower_profile['gallery_rail_height_m']),'cap_base':project(p.tower_profile['cap_base_m']),'finial':project(bb[1][2])}
assert abs(y['base']-200)<1e-9 and abs(y['gallery_underside']-89)<1e-9 and abs(y['finial']-38)<=3
assert abs(y['upper_rail']-75)<=2 and abs(y['cap_base']-60)<=3
schema=json.loads((R/'chicago/4d/data/structures.schema.json').read_text());jsonschema.validate(candidate,schema)
check=subprocess.run(['git','apply','--check',str(H/'profile-and-openings-next.patch')],cwd=H/'baseline',capture_output=True,text=True);assert check.returncode==0,check.stderr
out={'status':'passed','all25_composed_default_parameter_parity':len(phases),'legacy16positional_and10existing_keyword_fields_preserved':True,'new2fields_keyword_only':True,'all3_default_tower_profiles_face_stream_and_named_materials_equal':True,'five_range_fronts_exactly_preserved':True,'unchanged_overall_bounds_m':bb,'ground_feet_exactly_equal':True,'nominal12_19_literal_position_bearing_dates_polygon_unchanged':True,'profile_faces':len(after.faces),'profile_triangles':sum(len(points)-2 for points,_,_ in after.faces),'all_finite_nondegenerate_reconstructed':True,'same_square_pixel_camera_framing_diagnostic_y':y,'data_schema_and_patch_check_pass':True,'no_blender_browser_or_canonical_writes':True,'actual_picture_review':'pending explicit heavy slot; do not mark matches'}
(H/'light-check.json').write_text(json.dumps(out,indent=2)+'\n');(H/'raw-profile-geometry.json').write_text(json.dumps({'faces':after.faces,'bounds':bb})+'\n');print(json.dumps(out,indent=2))
