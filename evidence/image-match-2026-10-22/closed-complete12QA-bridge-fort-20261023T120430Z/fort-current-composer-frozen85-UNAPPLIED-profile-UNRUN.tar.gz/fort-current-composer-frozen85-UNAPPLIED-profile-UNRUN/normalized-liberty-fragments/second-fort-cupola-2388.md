

### L-second-fort-cupola-2388 — A capped drum on the second fort's blockhouse

**Covers:** `fort_dearborn_blockhouse.log_1816.form.cupola`, `fort_dearborn_blockhouse.log_1816.form.cupola_width_m`, `fort_dearborn_blockhouse.log_1816.form.cupola_height_m`, `fort_dearborn_blockhouse.log_1816.form.cupola_roof_pitch_deg`, `fort_dearborn_blockhouse.log_1816.form.chimneys`.

**Decision:** Build the small capped drum shown above the right-hand corner
blockhouse in Kurz & Allison panel 5 (`kurz_allison_1893`; public-domain crop
`data/sources/assets/prefire_views_kevin_2026_08/p3_1.png`). Its occurrence in
the 1835 reconstruction is inferred from an 1893 retrospective illustration.
The source is evidence of appearance, never a coordinate or a metric survey.

**What is invented:** the drum is 1.8 m square, centred on the main pyramid;
its head stands 1.2 m above that roof's apex, under a 35-degree pyramidal cap
with 0.12 m eaves. Its skirt intersects the main roof. Three dark vent bands
on each face represent a ventilated wooden drum; the print does not resolve
their count or construction. The timber finish and roof covering follow the
existing archetype palette. These dimensions are starting proportions for
comparison, not a camera-derived measurement or a completed match.

**The chimney choice:** the earlier reconstructed single chimney stood at
the same centre. No separate stack is distinguishable on this blockhouse
in panel 5, so it is omitted rather than moved to an unsupported location.
This does not prove historical absence or settle a concealed heating arrangement.

**Date boundary:** this is the second fort, rebuilt in 1816 and represented
at the 1835 scene date. Whistler's statement that first-fort cupolas were not
yet built in 1808 concerns a different fort at an earlier date; it neither
prohibits a later inferred presence nor establishes this second-fort cupola.

**What is kept:** the 1830-plan footprint, south-west placement, bearing,
main wall height, jetty and loopholes. No surveyed coordinate is moved to
make the retrospective composition fit.

**How to resolve:** refine the group camera, rebake, compare the new silhouette
against panel 5 and the other dated views, and adjust reconstructed dimensions
where the pictures support it. T-2388 remains open; no `matches` verdict follows
from adding this feature.

**Ticket:** T-2388.
**Recorded:** 2026-10-22.
