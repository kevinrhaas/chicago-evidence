### L-lighthouse-narrow-trial-2373 — Narrow the reconstructed physical tower, preserving its centre

**Decision:** trial an explicitly reconstructed3.04m diameter instead of the previous
invented5.6m diameter. Retain the nominal12.19m height value, all other existing
form values, surveyed position, bearing and dates. The circa1838 Castelnau picture
published1842 supports the broad slender silhouette, not metres or a1835 installation
date. At the corrected square-pixel diagnostic camera the conditional diameter
predicts24.0px shaft-head and32.2px gallery-floor widths against coarse24±3/31±3px
picks. The camera remains reconstructed and unsolved; the diameter is not measured
historical fact. The source floor is the band at y88–90, not the upper rail at75–76.

**Physical bounds, not an invisible envelope:** replace the physical bounding square
with[1.28,4.32]² relative to the existing polygon-coordinate origin. The new3.04m square
and the12-sided shaft both retain local centre(2.8,2.8), so no world placement changes.
The explicit tower-only resolver carries the nonzero bbox minimum into the mesh
centre. The GLB origin remains polygon-coordinate(0,0); it is not moved to the bbox
corner. Collision, Show Me and static contact now read the narrowed polygon;
rendered terrain bedding reads actual narrowed mesh feet. A square still conservatively
bounds a round tower, the same approximation as before. Do not keep a5.6m blocking
box around a visibly3.04m tower or add an invented envelope exemption.

**Remaining reconstruction:** taper.62, gallery multiplier1.34, lantern multiplier.86,
member counts/sections, cap curve, material/colour, missing stepped footing and the
vertical shaft/lantern partition remain unresolved. Existing radius-dependent cap
geometry shortens the maximum height13.4052→12.84968m; the nominal12.19m parameter
is unchanged. Neither Andreas's forty-foot sentence nor Lighthousefriends says
whether forty feet includes the lantern/cap/finial. The changed total is a declared
consequence of the radial trial, not a newly attested total or permission to stretch
that forty-foot number. New radial geometry carries reconstructed confidence.

**Supersedes:** L44's5.6m diameter only for this opted-in lighthouse phase; retain the
historical entry and its other unresolved choices. The birdcage-profile liberty
continues to own its member counts and source-date continuity. No other fort or
tower opts into this diameter, and every disabled/default geometry path stays the
same. All25 shared-module recipes still require a real supported final bake.

**How to resolve:** render the unchanged-camera baseline and trial and inspect the
actual source beside both, including width, finial/gallery-floor heights, cap/cage,
stepped footing, material and context. Keep remaining differences and the original
T-2373 case open; numerical projection is never a matches verdict. Contemporary
measured tower plans, contracts or a clear federal height-datum specification could
replace these choices.

**Covers:** `chicago_lighthouse_1832.tower_1832.footprint`,
`chicago_lighthouse_1832.tower_1832.form.tower_diameter_m`.

**Recorded:**2026-10-23, research trial under T-2373; not integrated or matched.
