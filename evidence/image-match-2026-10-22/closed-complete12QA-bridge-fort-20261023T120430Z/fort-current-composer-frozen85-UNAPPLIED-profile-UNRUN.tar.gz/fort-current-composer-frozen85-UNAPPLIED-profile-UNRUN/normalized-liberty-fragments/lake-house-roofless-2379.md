

### L-lake-house-open-shell-t-2379 — Lake House's chosen roofless worksite must actually be open, and the roof chronology remains reconstructed

**Covers:** `lake_house_construction.shell_1835.form.roof_type`
**Decision:** Keep the existing `roof_type: none`, one-storey, 4.0 m-high shell on
its existing 24 by 15 m footprint for the 1 July 1835 worksite, within L77's declared
zero-to-two-storey progress range. The 10 June 1835 Chicago Democrat notice
(`chicago_democrat_1833_1835`, issue `chicago_democrat_1835_06_10`, page 2 column 5,
claim c001, transcription-mediated) says the house is building in Kinzie's Addition.
It does not state a roof or any construction dimension. The roofless choice is
**reconstructed**, not proved by the later opening or the hotel still being finished
in 1836: an unfinished building may already have its roof. The later Kellogg print
of the completed hotel does not date progress in July 1835. T-2379 removes the
full 360 square-metre roof polygon that the generator erroneously emitted for
`none` as though the record had said `flat`. This is implementation of the chosen
absence, not the removal of a historically attested roof. Existing wall surfaces,
magazine-selector doorway, footprint, wall height and placement remain. No cellar
excavation, wall-thickness survey, building materials stock, scaffold or irregular
progress is asserted by this correction. The site is still a simplified shell.
**How to resolve:** a dated account or image of construction progress before
1 July 1835; inspect baseline/rebuilt overhead and oblique views to confirm that the
record's chosen roof absence is implemented. Matching a later finished hotel would
not resolve the scene-date question.
**Ticket:** T-2379.
**Recorded:** 2026-10-22 (proposal; not yet appended to the repository ledger).
