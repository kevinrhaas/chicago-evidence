#!/usr/bin/env python3
from pathlib import Path
import sys,json,copy,shutil,importlib.util,subprocess,hashlib,inspect,ast
from dataclasses import asdict
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;R=Path('/workspace/chicago/chicago/4d');C=H/'staged/candidate/chicago/4d';S=H/'shadow';S.mkdir(exist_ok=True)
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
# Isolated overlay of only candidate leaves. Symlink all unrelated root inputs READ ONLY by convention.
overrides={str(p.relative_to(C)):p for p in C.rglob('*') if p.is_file()}
# CLI modules must resolve their own ROOT to this shadow; all dependencies remain current.
for rel in ['tools/replace_invented_residents.py','tools/compile_liberties.py','tools/validate.py','generators/mesh_inputs.py','generators/code_inputs.py']:
 dest=H/'driver-copies'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/rel,dest);overrides[rel]=dest

def mirror(src,dst,prefix=''):
 dst.mkdir(exist_ok=True);names={p.name for p in src.iterdir()}|{k[len(prefix):].split('/')[0] for k in overrides if k.startswith(prefix)}
 for name in names:
  rel=prefix+name;sp=src/name;dp=dst/name
  if rel in overrides:
   if dp.is_symlink():dp.unlink()
   shutil.copy2(overrides[rel],dp)
  elif any(k.startswith(rel+'/') for k in overrides):
   if dp.is_symlink():dp.unlink()
   mirror(sp,dp,rel+'/')
  elif not dp.exists() and not dp.is_symlink():dp.symlink_to(sp,target_is_directory=sp.is_dir())
mirror(R,S)
sys.path[:0]=[str(S/'tools'),str(S/'generators')]
import jsonschema
schema=json.loads((S/'data/structures.schema.json').read_text());ss=json.loads((S/'data/source.schema.json').read_text())
structures={p.stem:json.loads(p.read_text()) for p in (S/'data/structures').glob('*.json')};changed=[]
for p in (C/'data/structures').glob('*.json'):jsonschema.validate(json.loads(p.read_text()),schema);changed.append(p.stem)
for p in (C/'data/sources').glob('*.json'):jsonschema.validate(json.loads(p.read_text()),ss)
lib=load(S/'tools/compile_liberties.py','adoption_lib_parser');doc,problems=lib.build();(H/'ledger-parser-problems.json').write_text(json.dumps(problems,indent=2)+'\n')
if problems:
 print(json.dumps({'ledger_problems':len(problems),'first':problems[:15]},indent=2));raise SystemExit(1)
newids=json.loads((H/'staged/review-manifest.json').read_text())['normalized_liberty_ids'];newentries=[x for x in doc['liberties'] if x['id'] in newids];assert len(newentries)==8
assert all(e['section']!='resolved' for e in newentries)
# Full proposed ledger parsed. Actual validator verifies every owed value of the25 family (forward scope).
val=load(S/'tools/validate.py','adoption_validate');scope=json.loads((H/'staged/review-manifest.json').read_text())['family_refresh']['assets'];family={row['structure_id']:structures[row['structure_id']] for row in scope};rep=val.Report();rep2=val.Report();consumed={'fort_structure':frozenset(load(C/'generators/archetypes/fort_structure_params.py','adoption_params_for_coverage').CONSUMED)}
val.check_liberties_coverage(family,doc,rep,consumed=consumed,forward_only=True)
assert not rep.errors,rep.errors[:10]
# Reverse-check only new claims against exact real structures/phase/attribute/confidence, avoiding unrelated terrain scope.
claims=[]
for e in newentries:
 for c in e['covers']:
  assert c['domain']=='structure';st=structures[c['structure']];ph=next(p for p in st['phases'] if p['id']==c['phase']);aspect=c['aspect'];node=ph
  for seg in aspect.split('.'):node=node[seg]
  assert node.get('confidence') in ['inferred','reconstructed'],(e['id'],c,node)
  claims.append(c)
# Legacy API and every pre-existing derived property are exact on all25 CURRENT root records with opt-ins absent.
legacy=load(Path('/tmp/chicago-next-model/fort-selective-integration/payload/baseline/chicago/4d/generators/archetypes/fort_structure_params.py'),'adoption_legacy16')
final=load(C/'generators/archetypes/fort_structure_params.py','adoption_final28');oldnames=list(inspect.signature(legacy.FortStructureParams).parameters);newnames=set(inspect.signature(final.FortStructureParams).parameters)-set(oldnames);assert len(oldnames)==16 and len(newnames)==12
assert legacy.FortStructureParams.__match_args__==final.FortStructureParams.__match_args__
for k in oldnames:assert inspect.signature(legacy.FortStructureParams).parameters[k]==inspect.signature(final.FortStructureParams).parameters[k]
for k in newnames:assert inspect.signature(final.FortStructureParams).parameters[k].kind==inspect.Parameter.KEYWORD_ONLY
for row in scope:
 record=json.loads((R/'data/structures'/(row['structure_id']+'.json')).read_text());ph=next(p for p in record['phases'] if p['id']==row['phase_id']);a=legacy.from_phase(ph,record);b=final.from_phase(ph,record)
 dd=asdict(b)
 for k in newnames:dd.pop(k)
 assert dd==asdict(a)
 positional=final.FortStructureParams(*[getattr(a,k) for k in oldnames]);positional.validate();dd=asdict(positional)
 for k in newnames:dd.pop(k)
 assert dd==asdict(a)
 for name,property_obj in vars(legacy.FortStructureParams).items():
  if isinstance(property_obj,property):assert getattr(a,name)==getattr(b,name)
# Name pool CLI on the actual overlay: raw-text equality plus parsed declarations, exact same unweakened self-test.
env={**__import__('os').environ,'PYTHONDONTWRITEBYTECODE':'1'}
r=subprocess.run([sys.executable,str(S/'tools/replace_invented_residents.py'),'--self-test'],capture_output=True,text=True,env=env);(H/'name-pool-cli-selftest.log').write_text(r.stdout+r.stderr);assert r.returncode==0,(r.stdout+r.stderr)[-4000:]
# Summarize actual raw/parsed additions and check every register candidate's surname-membership unchanged.
names=load(S/'tools/replace_invented_residents.py','adoption_name_pool');pool,und=names.harvest_names();assert not und
saved=(names.DATA,names.STRUCTURES,names.HOUSEHOLDS,names.EXCLUSIONS,names.NAME_POOL_KEYS)
names.DATA=R/'data';names.STRUCTURES=R/'data/structures';names.HOUSEHOLDS=R/'data/residents/households';names.EXCLUSIONS=R/'data/exclusions.json';names.NAME_POOL_KEYS=R/'data/reconstruction/name_pool_keys.json';before,_=names.harvest_names()
names.DATA,names.STRUCTURES,names.HOUSEHOLDS,names.EXCLUSIONS,names.NAME_POOL_KEYS=saved
added=sorted(set(pool)-set(before));removed=sorted(set(before)-set(pool));register=json.loads((R/'data/research/newspapers/register_1835.json').read_text());changed_candidates=[p['id'] for p in register['persons'] if (names.surname(p['name']) in pool)!=(names.surname(p['name']) in before)];assert not changed_candidates,changed_candidates
report={'status':'passed','full_ledger_entries':doc['count'],'full_ledger_parser_problems':0,'new_normalized_liberties':newids,'new_exact_reverse_checked_invention_claims':len(claims),'actual25_family_validator_forward_coverage_errors':0,'changed_structure_schemas_pass':len(changed),'new_source_schemas_pass':2,'legacy16constructor_plus12keyword_fields_and_original_derived_properties_all25':True,'name_pool_actual_CLI_selftest_pass':True,'name_pool_raw_equals_parsed_proved_by_unmodified_selftest':True,'name_pool_new_words':added,'name_pool_removed_words':removed,'register_candidate_surname_membership_changes':changed_candidates,'no_canonical_writes_no_heavy_jobs':True}
(H/'light-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
