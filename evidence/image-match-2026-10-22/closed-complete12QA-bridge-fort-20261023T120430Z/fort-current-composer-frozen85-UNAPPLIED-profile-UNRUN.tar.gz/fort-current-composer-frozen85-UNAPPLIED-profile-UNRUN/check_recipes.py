from pathlib import Path
import sys,json,hashlib
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;S=H/'shadow';R=Path('/workspace/chicago/chicago/4d');sys.path[:0]=[str(S/'generators')];import mesh_inputs
manifest=json.loads((R/'assets/manifest.json').read_text())['assets'];scope=json.loads((H/'staged/review-manifest.json').read_text())['family_refresh']['assets'];rows=[]
for row in scope:
 p=S/'data/structures'/(row['structure_id']+'.json');rec=json.loads(p.read_text());ph=next(x for x in rec['phases'] if x['id']==row['phase_id']);proposed=mesh_inputs.structure_inputs_sha(rec,ph,'fort_structure');old=manifest[row['asset']]['inputs_sha256'];assert proposed!=old
 rows.append({'asset':row['asset'],'current_manifest_recipe':old,'proposed_recipe':proposed,'actual_current_master_sha256':hashlib.sha256((R/'assets/gltf'/row['asset']).read_bytes()).hexdigest(),'rebake_required':True})
(H/'recipe-check.json').write_text(json.dumps({'status':'passed','scheme':mesh_inputs.SCHEME,'exactly25_current_fort_master_members':len(rows),'all25_need_real_rebake':True,'archetype_module_changes_only_fort':True,'no_common_emit_pin_or_frame_generator_edits_in_candidate':True,'assets':rows,'no_freshness_restamping_or_asset_copies':True},indent=2)+'\n');print('PASS25 proposed recipes differ from actual current manifest; real25 bake required')
