from pathlib import Path
from types import SimpleNamespace
import sys,importlib.util,ast,json,re
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;R=Path('/workspace/chicago/chicago/4d');C=H/'staged/candidate/chicago/4d';S=H/'shadow';sys.path[:0]=[str(R/'tools'),str(R/'generators')]
def load(p,n):
 spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);sys.modules[n]=m;spec.loader.exec_module(m);return m
params=load(C/'generators/archetypes/fort_structure_params.py','consumer_final_params');import archetypes
sys.modules['archetypes.fort_structure_params']=params
facade=load(C/'generators/archetypes/facade_openings.py','consumer_facade')
def fn(p,name):return next(n for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef) and n.name==name)
gbs={'STRUCTURES':S/'data/structures','TARGET_DATE':'1835-07-01','_load':lambda p:json.loads(p.read_text()),'_RESOLVERS':{'fort_structure':params.from_phase},'facade_openings':facade}
exec(compile('from __future__ import annotations\n'+ast.unparse(fn(C/'tools/generate_business_signboards.py','_front_wall')),'actual_gbs_front_wall','exec'),gbs)
family=json.loads((H/'staged/review-manifest.json').read_text())['family_refresh']['assets']
for row in family:assert gbs['_front_wall'](row['structure_id']) is None
ens={'gbs':SimpleNamespace(_front_wall=gbs['_front_wall'],facade_openings=facade),'ENTRANCE_KINDS':('door','shop_door','open_bay'),'GROUND_Z_M':.3,'OPENING_GAP_M':.15,'SHOPFRONT':frozenset({'shop_door','show_window'})}
for name in ['front_doors','merged_openings']:exec(compile('from __future__ import annotations\n'+ast.unparse(fn(R/'tools/generate_entrances.py',name)),'actual_entrance_reader','exec'),ens)
for row in family:assert ens['front_doors']({'id':row['structure_id'],'archetype':'fort_structure'})==([],None)
gbs['TARGET_DATE']='1812-07-01'
for name,count in [('north_range',4),('soldiers_barracks_sw',4),('soldiers_barracks_se',4),('officers_barracks',5),('commanding_officers_barracks',4)]:
 sid='first_fort_dearborn_'+name;wall=gbs['_front_wall'](sid);assert len(wall['openings'])==count*2;doors,_=ens['front_doors']({'id':sid,'archetype':'fort_structure'});assert len(doors)==1;assert ens['merged_openings']({'id':sid,'archetype':'fort_structure'})==[]
# Actual citation/public_text path boundary, without importing broad scene producers.
from tiers import tier_ladder,tier_label
scene_ast=ast.parse((R/'tools/compile_scene.py').read_text());nodes=[]
for n in scene_ast.body:
 name=n.target.id if isinstance(n,ast.AnnAssign) and isinstance(n.target,ast.Name) else None
 if name in ['SOURCE_FIELD_SURFACE','VISITOR_SOURCE_FIELDS'] or isinstance(n,ast.FunctionDef) and n.name=='cite':nodes.append(n)
ns={'tier_ladder':tier_ladder,'tier_label':tier_label};exec(compile(ast.Module(body=nodes,type_ignores=[]),'actual_cite','exec'),ns)
ps={'re':re};exec(compile(ast.Module(body=[fn(R/'tools/compile_source_use.py','public_text')],type_ignores=[]),'actual_public_text','exec'),ps)
sources={p.stem:json.loads(p.read_text()) for p in (C/'data/sources').glob('*.json')};cites=ps['public_text'](ns['cite'](list(sources),sources));text=json.dumps(cites)
assert not any(x in text for x in ['/tmp/','/workspace/','chicago/reference/','data/sources/assets/'])
assert 'access_notes' not in text and all(c['citation'] for c in cites)
# The new source reaches the actual picture-card join and explicit whole-tower grade.
cp=load(R/'tools/compile_pictures.py','consumer_compile_pictures');rec=(C/'data/structures/chicago_lighthouse_1832.json').read_text();pictures=cp.derive(None,'',sources,{'chicago_lighthouse_1832':rec},{'1835':['chicago_lighthouse_1832']},{})['1835']['by_structure']['chicago_lighthouse_1832'];assert any(p['id']=='castelnau_1842_chicago_harbor' for p in pictures)
gr=load(R/'tools/grade_structures.py','consumer_grade');rulings=json.loads((C/'data/structure_grades.json').read_text());grade=gr.grade_structure('chicago_lighthouse_1832','inferred',pictures,[],rulings,'1835');assert grade['value']=='attested' and grade['pictures']==['castelnau_1842_chicago_harbor']
# Preserve every prior ruling and name-key declaration when replayed on a later root.
prior=json.loads((R/'data/structure_grades.json').read_text())
for key,value in prior.items():
 if key=='pictured':assert rulings[key][:len(value)]==value
 else:assert rulings[key]==value
prior_keys=json.loads((R/'data/reconstruction/name_pool_keys.json').read_text());new_keys=json.loads((C/'data/reconstruction/name_pool_keys.json').read_text())
assert prior_keys['ignored']==new_keys['ignored']
for kind,keys in prior_keys['read'].items():assert new_keys['read'][kind][:len(keys)]==keys
out={'status':'passed' ,'all25_1835_fort_fronts_stay_unread':True,'all25_1835_fort_ground_doors_unchanged_none':True,'five1812_explicit_fronts_have_counts_and_one_door_without_overlap':True,'actual_source_cite_and_public_text_have_no_localpaths':True,'new_source_reachable_on_actual_picture_card_join':True,'explicit_whole_tower_grade_ruling_works_without_matches_claim':True,'root_existing_sourceS_frame_rulings_preserved':True,'no_blender_browser_or_root_writes':True}
(H/'consumer-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
