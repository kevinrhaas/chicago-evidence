# Direct original/default preservation proof — PASS

This closes the earlier proof-baseline gap. `check_api_geometry.py` compared an executed picture proposal with its keyword-only repair, through the same builder; later glyph/tone comparisons proved only those incremental changes. Those receipts alone were not the comprehensive original pre-M builder vs final builder comparison.

The new comparison actually executes the ORIGINAL builder AND params from `e41ae248f6eaad1ead26c93537a7d1c7b438d3c0` against the final canonical builder AND params frozen here. Both original files are also byte-exact to the selective helper's `payload/old` files. It uses every ORIGINAL top-level frame_tavern record from that commit, unchanged. It never substitutes the current three hotel opt-ins or executed-proposal records, strips attributes, or creates a version fixture. All11 new form controls are absent from the original records, and the final actual from_phase reader resolves them to their defaults. Every old resolved parameter is exactly equal.

**Production cohort:23 original records,23 producer-selected canonical family phases PASS.** The original producer's actual `resolve_phase` and `phases_in_scenes` function ASTs were executed with the original1812/1835/1904 scene target dates; those selectors and dates equal current production. The selected23 output names exactly match the actual canonical23 bake's wrote.txt. The original version directory was inspected:4 unrelated version records,0 frame_tavern versions.

**Additional stored-phase check:1 PASS, separately.** Sauganash also stores `log_1829`; none of the committed scene dates selects it. It is NOT a24th canonical frame-family output. It was additionally compared to guard its old path, but the production acceptance cohort remains23. `selected-phase-proof.json` records both sets explicitly, and every row of `proof.json` carries its producer-selected status.

For each comparison, both builders receive the same actual canonical name `structure_id__phase_id`, and each actual reader supplies the same siding seed `structure_id|phase_id`. Raw accumulated vertex coordinates, faces, per-vertex confidence, face material indices, named material specifications and base material specifications compare exactly, with individual channel hashes retained. All40 positional parameters/defaults/order remain exact; all11 additions are keyword-only and resolve to defaults. The8 shared helper source files are independently pinned and byte-identical between e41 and final, so no different helper revision is silently borrowed by either side.

The only substitutions are Blender-free observation boundaries: MeshBuilder.to_object returns its real accumulator and material specifications, and simple_material returns its original name/arguments instead of allocating bpy materials. Neither geometry helper, builder logic, actual from_phase reader, original input nor canonical name/seed is replaced. Both paths use identical observation boundaries.

Files:

- `compare.py`, `run.log`, `proof.json`: executed comparison, PASS,23 selected plus1 additional stored phase.
- `selected-phase-proof.json`, `canonical23-wrote.txt`: actual producer selection and exact actual bake cohort correspondence.
- `original/`: exact original builder/params/build selector source,23 original records and3 scene records.
- `final/`: exact final canonical builder/params snapshots compared, with hashes in proof.json.

No new repository test or app source was written. No Blender, browser, master export, canonical asset/recipe mutation or app acceptance run occurred. This is direct parameter/accumulator/material/confidence preservation proof. It does not assert24 canonical exports, byte-exact GLBs/UV packing, pixel equality, completed image matches or complete published-card/full-gate acceptance.
