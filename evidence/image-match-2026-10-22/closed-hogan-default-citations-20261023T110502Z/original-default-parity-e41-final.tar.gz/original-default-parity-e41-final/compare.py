"""Direct ORIGINAL e41/default-input vs FINAL-source accumulator proof; no Blender."""
from pathlib import Path
import subprocess,json,hashlib,sys,types,importlib.util,dataclasses,inspect,math,ast,datetime
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;R=Path('/workspace/chicago');APP=R/'chicago/4d';BASE='e41ae248f';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(R),*args])
commit=git('rev-parse',BASE).decode().strip()
def blob(rel):return git('show',commit+':chicago/4d/'+rel)
def freeze(rel,data):
 p=H/rel;p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():assert p.read_bytes()==data,str(p)+' changed after initial freeze'
 else:p.write_bytes(data)
 return p
# Exact original source from a concrete pre-M commit, not an executed proposal.
old_paths={};source_proof={}
for name in ['frame_tavern.py','frame_tavern_params.py']:
 rel='generators/archetypes/'+name;old=blob(rel);new=(APP/rel).read_bytes();old_paths[name]=freeze('original/'+rel,old);freeze('final/'+rel,new)
 payload=Path('/tmp/chicago-next-model/T-3055-selective-integration/payload/old/chicago/4d')/rel
 source_proof[rel]={'original_e41_sha256':sha(old),'final_root_sha256':sha(new),'original_payload_old_exact':payload.read_bytes()==old}
# The two paths share only helpers proved byte-identical to the original commit.
common={}
for rel in git('ls-tree','-r','--name-only',commit,'--','chicago/4d/generators/common').decode().splitlines():
 p=R/rel
 if not p.is_file():continue
 old=git('show',commit+':'+rel);new=p.read_bytes();assert old==new,rel+' helper drift';common[rel]={'original_and_final_sha256':sha(old),'byte_identical':True}
# Load ORIGINAL top-level records, directly at e41. Do not use current opt-ins,
# rewritten proposals, or any nested versions directory.
prefix='chicago/4d/data/structures/';files=git('ls-tree','--name-only',commit+':'+prefix[:-1]).decode().splitlines();files=[f for f in files if f.endswith('.json')];requests=''.join(commit+':'+prefix+f+'\n' for f in files).encode();data=subprocess.run(['git','-C',str(R),'cat-file','--batch'],input=requests,capture_output=True,check=True).stdout;offset=0;records=[]
for name in files:
 e=data.index(b'\n',offset);head=data[offset:e].split();size=int(head[-1]);raw=data[e+1:e+1+size];offset=e+size+2;r=json.loads(raw)
 if r.get('archetype')=='frame_tavern':
  freeze('original/data/structures/'+name,raw);records.append((r,sha(raw)))
# Execute the actual producer phase-selector functions extracted verbatim from
# their AST, without importing Blender/emitter dependencies or calling build().
build_src=blob('generators/build.py');freeze('original/generators/build.py',build_src);current_build=(APP/'generators/build.py').read_bytes()
old_ast=ast.parse(build_src);new_ast=ast.parse(current_build)
def selector_nodes(tree):
 return [next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name==key) for key in ['resolve_phase','phases_in_scenes']]
old_select=selector_nodes(old_ast);new_select=selector_nodes(new_ast);assert all(ast.dump(a)==ast.dump(b) for a,b in zip(old_select,new_select))
scene_paths=git('ls-tree','--name-only',commit+':chicago/4d/data/scenes').decode().splitlines();scenes=[]
for name in scene_paths:
 if not name.endswith('.json'):continue
 raw=blob('data/scenes/'+name);freeze('original/data/scenes/'+name,raw);sc=json.loads(raw);now=json.loads((APP/'data/scenes'/name).read_text());assert sc['target_date']==now['target_date'];scenes.append({'id':name[:-5],'target_date':sc['target_date'],'original_sha256':sha(raw)})
ns={'dt':datetime,'targets':[datetime.date.fromisoformat(sc['target_date']) for sc in scenes]};exec(compile(ast.fix_missing_locations(ast.Module(body=old_select,type_ignores=[])),'original_build_phase_selectors','exec'),ns)
selected={(r['id'],ph['id']) for r,_ in records for ph in ns['phases_in_scenes'](r)}
wrote=(H.parent/'canonical23/wrote.txt').read_bytes();freeze('canonical23-wrote.txt',wrote);actual_outputs=set(wrote.decode().splitlines());assert {sid+'__'+pid+'.glb' for sid,pid in selected}==actual_outputs
version_paths=git('ls-tree','-r','--name-only',commit,'--','chicago/4d/data/structures/versions').decode().splitlines();version_sources=[]
for path in version_paths:
 if not path.endswith('.json'):continue
 raw=git('show',commit+':'+path);v=json.loads(raw);version_sources.append({'path':path,'sha256':sha(raw),'archetype':v.get('archetype')})
frame_versions=[v for v in version_sources if v['archetype']=='frame_tavern'];assert not frame_versions
selection_proof={'actual_producer':'generators/build.py::resolve_phase and main::phases_in_scenes, original AST functions executed with original scene dates','original_build_sha256':sha(build_src),'current_build_sha256':sha(current_build),'phase_selector_AST_original_final_exact':True,'scene_dates_original_final_exact':scenes,'selected_canonical_phase_count':len(selected),'selected_outputs_match_actual_canonical23_wrote_exactly':True,'canonical23_wrote_sha256':sha(wrote),'selected_original_record_phases':[{'structure':sid,'phase':pid} for sid,pid in sorted(selected)],'all_stored_phases_not_selected':[{'structure':r['id'],'phase':ph['id']} for r,_ in records for ph in r['phases'] if (r['id'],ph['id']) not in selected],'original_nested_version_sources_checked':version_sources,'original_frame_tavern_version_count':len(frame_versions)}
(H/'selected-phase-proof.json').write_text(json.dumps(selection_proof,indent=2)+'\n')
sys.path.insert(0,str(APP/'generators'));sys.modules.setdefault('bpy',types.ModuleType('bpy'))
pkg=types.ModuleType('archetypes');pkg.__path__=[str(APP/'generators/archetypes')];sys.modules['archetypes']=pkg
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
op=load('original_e41_params',old_paths['frame_tavern_params.py']);sys.modules['archetypes.frame_tavern_params']=op
ob=load('original_e41_builder',old_paths['frame_tavern.py']);assert ob.FrameTavernParams is op.FrameTavernParams
np=load('final_root_params',H/'final/generators/archetypes/frame_tavern_params.py');sys.modules['archetypes.frame_tavern_params']=np
nb=load('final_root_builder',H/'final/generators/archetypes/frame_tavern.py');assert nb.FrameTavernParams is np.FrameTavernParams
from common.mesh import MeshBuilder
MeshBuilder.to_object=lambda self,mats=None:(self,list(mats or []))
for builder in [ob,nb]:builder.simple_material=lambda name,*args,**kwargs:(name,args,kwargs)
old_fields=dataclasses.fields(op.FrameTavernParams);new_fields=dataclasses.fields(np.FrameTavernParams);old_names={f.name for f in old_fields};added=[f.name for f in new_fields if f.name not in old_names]
so=inspect.signature(op.FrameTavernParams).parameters;sn=inspect.signature(np.FrameTavernParams).parameters;assert all(sn[k]==v for k,v in so.items());assert list(so)==list(np.FrameTavernParams.__match_args__);assert len(so)==40;assert all(sn[k].kind==inspect.Parameter.KEYWORD_ONLY for k in added)
params_default={f.name:(f.default_factory() if f.default_factory is not dataclasses.MISSING else f.default) for f in new_fields if f.name in added}
def digest(value):return sha(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def channels(result):
 mesh,mats=result
 return {'vertices':mesh.verts,'faces':mesh.faces,'confidence':mesh.conf,'face_material_indices':mesh.mat_index,'named_material_specs':mesh.named,'base_material_specs':mats}
report={'baseline_commit':commit,'baseline_description':'Original pre-M builder+params and all ORIGINAL e41 top-level frame_tavern records, not the executed picture proposal','final_description':'Current canonical source snapshots at comparison time; current opted-in records NOT used','source_proof':source_proof,'common_helpers_exact':common,'canonical_name_rule':'structure_id + __ + phase_id','canonical_siding_seed_rule':'structure_id + | + phase_id (actual unchanged from_phase reader)','record_count':len(records),'phase_count':sum(len(r['phases']) for r,_ in records),'version_record_count':0,'canonical_producer_selected_phase_count':len(selected),'additional_stored_phase_count':sum(len(r['phases']) for r,_ in records)-len(selected),'selection_proof':'selected-phase-proof.json','original_positional_parameters_defaults_order_preserved':list(so),'new_keywordonly_fields':added,'phases':[],'failures':[],'canonical_writes':False,'blender_browser_or_mesh_export':False,'proof_limits':'Accumulator params/geometry/material/confidence proof only. Does not establish byte-exact GLBs/UV unwrap, pixel equality, whole image matches or completed app acceptance.'}
for record,rsha in records:
 for phase in record['phases']:
  name=record['id']+'__'+phase['id'];a=op.from_phase(phase,record);b=np.from_phase(phase,record);ad=dataclasses.asdict(a);bd=dataclasses.asdict(b);extensions={key:bd.pop(key) for key in added};assert not(set(added)&set(phase.get('form',{}))),name+' original already opted into new fields';assert extensions==params_default,(name,extensions,params_default);assert a.siding_seed==b.siding_seed==record['id']+'|'+phase['id'];cs0=channels(ob.build(a,name));cs1=channels(nb.build(b,name));equal={key:cs0[key]==cs1[key] and digest(cs0[key])==digest(cs1[key]) for key in cs0};params_exact=ad==bd and digest(ad)==digest(bd);row={'structure':record['id'],'phase':phase['id'],'canonical_producer_selected':(record['id'],phase['id']) in selected,'canonical_name':name,'canonical_siding_seed':a.siding_seed,'original_record_sha256':rsha,'new_control_form_keys_absent':True,'new_parameters_resolve_to_defaults':True,'all_old_params_exact':params_exact,'old_params_sha256':digest(ad),'final_old_param_subset_sha256':digest(bd),'channels_equal':equal,'old_channel_sha256':{k:digest(v) for k,v in cs0.items()},'final_channel_sha256':{k:digest(v) for k,v in cs1.items()},'vertices':len(cs0['vertices']),'faces':len(cs0['faces'])};report['phases'].append(row)
  if not(params_exact and all(equal.values())):report['failures'].append({'name':name,'params_exact':params_exact,'channels_equal':equal})
report['canonical_producer_selected_comparisons']=[row['canonical_name'] for row in report['phases'] if row['canonical_producer_selected']];report['additional_stored_only_comparisons']=[row['canonical_name'] for row in report['phases'] if not row['canonical_producer_selected']];assert len(report['canonical_producer_selected_comparisons'])==23;assert report['additional_stored_only_comparisons']==['sauganash_hotel__log_1829'];report['result']='PASS' if not report['failures'] else 'FAIL';(H/'proof.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['baseline_commit','record_count','phase_count','canonical_producer_selected_phase_count','additional_stored_phase_count','version_record_count','result','failures']},indent=2));assert not report['failures'],report['failures']
