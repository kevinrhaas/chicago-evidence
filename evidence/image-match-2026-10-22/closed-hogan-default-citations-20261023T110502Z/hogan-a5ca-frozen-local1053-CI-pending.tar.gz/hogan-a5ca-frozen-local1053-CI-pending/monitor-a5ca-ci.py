from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import datetime,json,subprocess,time,sys
root=Path(__file__).resolve().parent; plan=json.loads((root/'e474-smoke-runs-new-head.json').read_text()); assert plan.get('dispatch_complete') and len(plan['runs'])==10
repo=plan['repository'];head=plan['head'];out=root/'live-a5ca-ci-monitor';out.mkdir(exist_ok=True)
def api(path):
 r=subprocess.run(['gh','api',path],text=True,capture_output=True,timeout=45)
 if r.returncode:raise RuntimeError(r.stderr.strip())
 return json.loads(r.stdout)
def get(row):
 x=api(f"repos/{repo}/actions/runs/{row['id']}");assert x['head_sha']==head
 return {**row,'status':x['status'],'conclusion':x['conclusion'],'attempt':x['run_attempt'],'updated_at':x['updated_at']}
errors=0
while True:
 stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
 try:
  rows=plan['runs']+[{'id':39941322173,'kind':'required_gate','url':f'https://github.com/{repo}/actions/runs/39941322173'},{'id':39941313642,'kind':'content_warranted','url':f'https://github.com/{repo}/actions/runs/39941313642'}]
  with ThreadPoolExecutor(max_workers=4) as pool:states=list(pool.map(get,rows))
  pr=api(f'repos/{repo}/pulls/1229');checks=api(f'repos/{repo}/commits/{head}/check-runs?filter=latest&per_page=100')
  snap={'head':head,'observed_at':stamp,'pr_head':pr['head']['sha'],'base_head':pr['base']['sha'],'mergeable':pr['mergeable'],'mergeable_state':pr['mergeable_state'],'runs':states,'checks':checks,'merge_performed':False,'root_review_required':True}
  path=out/f'{stamp}.json';path.write_text(json.dumps(snap,indent=2)+'\n');errors=0
  if pr['head']['sha']!=head:print(json.dumps({'event':'HEAD_CHANGED','expected':head,'actual':pr['head']['sha'],'snapshot':str(path)}),flush=True);sys.exit(2)
  failed=[x for x in states if x['status']=='completed' and x['conclusion'] not in ['success','skipped','neutral']]
  failed_checks=[x for x in checks['check_runs'] if x['status']=='completed' and x['conclusion'] not in ['success','skipped','neutral']]
  if failed or failed_checks:
   (out/'ACTUAL_FAILURE.json').write_text(json.dumps({'failed':failed,'failed_checks':failed_checks,'snapshot':str(path)},indent=2)+'\n');print(json.dumps({'event':'ACTUAL_FAILURE','failed':failed,'failed_checks':[{k:x.get(k) for k in ['name','conclusion','details_url']}for x in failed_checks],'snapshot':str(path)}),flush=True);sys.exit(1)
  if all(x['status']=='completed' and x['conclusion']=='success' for x in states) and all(x['status']=='completed' and x['conclusion'] in ['success','skipped','neutral']for x in checks['check_runs']):
   (out/'ALL_TWELVE_SUCCESS.json').write_text(json.dumps(snap,indent=2)+'\n');print(json.dumps({'event':'ALL_TWELVE_SUCCESS','head':head,'snapshot':str(out/'ALL_TWELVE_SUCCESS.json'),'merge_performed':False,'root_review_required':True}),flush=True);sys.exit(0)
 except Exception as e:
  errors+=1;(out/f'{stamp}-API-error.txt').write_text(str(e)+'\n')
  if errors>=5:print(json.dumps({'event':'MONITOR_API_ERROR','detail':str(e)}),flush=True);sys.exit(3)
 time.sleep(60)
