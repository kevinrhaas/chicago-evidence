Hogan’s store now follows the pictured door/window arrangement, gable-light proxy and ridge chimney in Edgar S. Cameron’s first-post-office drawing. The documented footprint, position, bearing and phase dates remain unchanged. Numeric opening dimensions and stations remain reconstructed; the card credits Cameron and the Chicago Historical Society.

**T-2377 remains open.** This is a first model increment. Its provisional comparison still differs in perspective, door and gable treatment, stack detail, materials and context. No accepted image match or original-ticket closure is claimed. [Source, camera and before/after comparison](https://github.com/kevinrhaas/chicago/tree/a5cae2adc766425103151debd8ef57b152d70022/chicago/4d/docs/RESEARCH/hogan-picture-match-T-2377) retain the original-publication verification limits.

Current head `a5cae2adc766425103151debd8ef57b152d70022` incorporates dev `e4745b3c5714185079215d06d8072a4791c6de4a`, including its human/transport contracts, Prairie geometry and Glessner research. Raw documentation preserves both histories; actual producers regenerate the five conflicting derived files. Hogan’s record, source and master GLB remain byte-identical to the validated first increment. No sourceS/frame proposal is imported. The final diff against dev changes no smoke assertion, timeout, workflow or error handling.

Validation:

- **Official strict local preflight PASS: 1053/1053 checks**, required readers enabled, plus changelog and ticket-ID checks. The actual ordered producer tail settled after two laps. All final logs are saved. Measured preflight wall time was 793 seconds: temporary fixture directories were inside the isolated worktree, causing fixture Git commands to inherit its Git root and perform real remote-ref fetch/scans. Read-only ancestry and hash checks confirm no tracked source/tree or HEAD mutation. This environment issue is recorded; future TMPDIR must be outside all Git worktrees. No timing or CI-limit fit claim is made.
- Published targeted Hogan app/card QA passed at `6156a0367a2379f0d986b88c7c8236c4ebec0e55` for mobile 390×780 and desktop 1280×800, including visible source credit and no unexpected page/loader errors. Hogan’s record, source and master are byte-identical through this head. This is content-equivalent Hogan-only evidence; it does not claim a new full-app browser run at the current head.
- All ten fresh published-smoke workflows below are pinned to `a5cae2adc766425103151debd8ef57b152d70022` and cover parts 1–15 exactly once at each viewport, including incoming dev’s human and transport contracts. Part 13 is separate. **These workflows and current-head CI are pending; merge readiness is not established.** [Current required gate](https://github.com/kevinrhaas/chicago/actions/runs/39941322173), [content warrant decision](https://github.com/kevinrhaas/chicago/actions/runs/39941313642).

| Parts | Mobile | Desktop |
|---|---|---|
| 1-4 | [39941364360](https://github.com/kevinrhaas/chicago/actions/runs/39941364360) | [39941379137](https://github.com/kevinrhaas/chicago/actions/runs/39941379137) |
| 5-8 | [39941393073](https://github.com/kevinrhaas/chicago/actions/runs/39941393073) | [39941406736](https://github.com/kevinrhaas/chicago/actions/runs/39941406736) |
| 9-12 | [39941419811](https://github.com/kevinrhaas/chicago/actions/runs/39941419811) | [39941433356](https://github.com/kevinrhaas/chicago/actions/runs/39941433356) |
| 13 | [39941349710](https://github.com/kevinrhaas/chicago/actions/runs/39941349710) | [39941335551](https://github.com/kevinrhaas/chicago/actions/runs/39941335551) |
| 14-15 | [39941446088](https://github.com/kevinrhaas/chicago/actions/runs/39941446088) | [39941459693](https://github.com/kevinrhaas/chicago/actions/runs/39941459693) |

Historical evidence remains explicit:

- Former `05f6b886e`: nine smoke runs passed; [desktop 14–15, run39909852234](https://github.com/kevinrhaas/chicago/actions/runs/39909852234) remains failed on an external Glessner thumbnail (`net::ERR_BLOCKED_BY_ORB`; 160 assertions passed, one failed). No error allowlist or assertion weakening was applied.
- Former `50b6`: local strict preflight passed1049. Eight dedicated smoke workflows passed; its two still-running desktop workflows were explicitly cancelled as superseded after preserving status/log evidence, to release capacity for the current exact head. No complete50b6 browser-coverage claim is made, and its receipts do not establish new-head coverage.
- The old50b6 [required gate39933433418](https://github.com/kevinrhaas/chicago/actions/runs/39933433418) failed twice when its hosted runner received shutdown and exited143, without a validator verdict. The cause of those shutdowns is unresolved; neither attempt is reclassified as a pass.
- The old50b6 [content-build warrant run39933426147](https://github.com/kevinrhaas/chicago/actions/runs/39933426147) timed out during checkout on attempt1, then passed its authorized failed-job-only retry. Its ordinary no-bake decision skipped dependents; no geometry bake ran.
- The first earlier local attempt failed only on the external ticket queue’s stale T-3056 title; central repair`e92ad0fc` and the successful full rerun remain preserved.

[Immutable50b6 evidence archive](https://github.com/kevinrhaas/chicago-tickets/blob/125283a1b2f82500908d880aec521a92fb04681d/evidence/image-match-2026-10-22/hogan-pr1229-50b6-checkpoint-20261023T094744Z/README.md) and [CI recovery addendum](https://github.com/kevinrhaas/chicago-tickets/blob/601efa47d28f8f28c079dab083e62ff4157ea041/evidence/image-match-2026-10-22/hogan-50b6-ci-recovery-addendum-20261023T095659Z/README.md) are retained unchanged. A separate current-head checkpoint is being archived.

Merge target is `dev`. Merge requires all ten exact-head runs to succeed, clean current-head CI, current dev/head freshness and the root agent’s held-lap review. Original picture-match work continues after this bounded increment.
