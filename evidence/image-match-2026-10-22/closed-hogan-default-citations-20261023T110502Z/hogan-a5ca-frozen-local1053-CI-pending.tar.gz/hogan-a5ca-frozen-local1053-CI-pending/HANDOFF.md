# Hogan PR1229 current-head recovery checkpoint

Frozen after normal push of a5cae2adc766425103151debd8ef57b152d70022, merge of old50b6 and dev e4745b3c5714185079215d06d8072a4791c6de4a. Original T-2377 remains open and comparison differs; no accepted match. No sourceS/M proposal imported.

Official local strict preflight PASS1053/1053, required readers, changelog and IDs PASS, exit0. Ordered actual producer tail PASS59steps/two laps/last moved nothing. Wall793s is measured, not a performance-budget claim. Temporary fixture Git ancestry caused real git fetch/ref scans; read-only probe and source/index/HEAD proofs preserved. Future TMPDIR must be outside all Git worktrees. No code/test weakening or extra rerun was used.

All ten fresh published-smoke workflows are pinned to exacta5ca and tile parts1–15 once at mobile390x780 and desktop1280x800; see e474-smoke-runs-new-head.json. Current-head required gate39941322173 and content warrant39941313642 remain pending at this snapshot. No CI/browser coverage acceptance or merge readiness is claimed. Child must not merge; root must review all ten success, latest CI, current dev/head freshness and live owned lap.

Historical50b6 remains separate: local1049PASS, eight dedicated smoke PASS, desktop13 and desktop14–15 explicitly cancelled as superseded after source head advanced, per root authorization. Both final ZIP logs/status and cancellation reasons preserved. Its required gate twice received hosted-runner shutdown143 without validator verdict; cause unresolved, no workflow/timeout/assertion change or further oldhead retries. Historical05f6 ORB failure remains red and is linked in PR body/earlier archives.

Previous immutable archives stay unchanged: tickets125283a1b2f82500908d880aec521a92fb04681d (50b6 checkpoint) and601efa47d28f8f28c079dab083e62ff4157ea041 (warranted-recovery addendum). This bundle complements those archives; it does not replace their history.

Resume: /tmp/hogan-pr1229-integration on steward/t2377-hogan-current-dev, source branch steward/t2377-hogan-picture-match. Current light read-only monitor session19143 writes outside this frozen bundle to .hogan-recovery/live-a5ca-ci-monitor and monitor-a5ca-ci.log. Never duplicate dispatches; complete exact-head plan is already recorded. Parent root owns final PR review/merge; heavy slot released after actual preflight.
