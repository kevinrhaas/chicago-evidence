"""Reproducible provisional framing against current invented Tremont envelope.
This is not a calibrated historical camera or support for changing metric data.
"""
import json, math, pathlib
import numpy as np
from scipy.optimize import least_squares
OUT=pathlib.Path(__file__).parent
# Pixels picked manually from inspected 1637x796 local Gifford reproduction.
# Three wall corners, then those corners' eaves: approximate/partly obscured.
world=np.array([[0,9.14,0],[0,0,0],[15.24,0,0],[0,9.14,5.2],[0,0,5.2],[15.24,0,5.2]],float)
pixels=np.array([[875,516],[1035,519],[1253,505],[875,350],[1037,334],[1253,350]],float)

def project(p,points):
    eu,ev,ey,yaw,f,cx,cy=p
    t=math.radians(yaw); d=points-np.array([eu,ev,ey])
    dep=d[:,0]*math.sin(t)+d[:,1]*math.cos(t)
    right=d[:,0]*math.cos(t)-d[:,1]*math.sin(t)
    return np.column_stack([cx+f*right/dep,cy-f*d[:,2]/dep])

def fun(p): return (project(p,world)-pixels).ravel()
bounds=([-300,-300,0.2,2,300,-1000,200],[-1,-1,5.0,88,10000,2600,700])
fits=[]
for distance in [20,50,100,200]:
    for angle in [30,45,60]:
        p0=[-distance,-distance,1.7,angle,distance*40,1000,460]
        fit=least_squares(fun,p0,bounds=bounds,max_nfev=10000,xtol=1e-12,ftol=1e-12,gtol=1e-12)
        fits.append(fit)
fit=min(fits,key=lambda r:np.linalg.norm(r.fun)); eu,ev,ey,yaw,f,cx,cy=fit.x
pred=project(fit.x,world)
res=pred-pixels
metrics={'fit_scope':'provisional framing of existing reconstructed wall envelope, not historical calibration','eye':fit.x[:3].tolist(),'yaw_deg':yaw,'focal_px':f,'principal_px':[cx,cy],'coordinate_rms_px':float(np.sqrt(np.mean(res**2))),'point_rms_px':float(np.sqrt(np.mean(np.sum(res**2,axis=1)))),'maximum_point_residual_px':float(np.linalg.norm(res,axis=1).max()),'observations':[{'world_uvy':w.tolist(),'pixel_xy':p.tolist(),'predicted_xy':r.tolist(),'residual_xy':d.tolist()} for w,p,r,d in zip(world,pixels,pred,res)],'parameter_bounds':{'lower':bounds[0],'upper':bounds[1]},'at_or_near_bound':bool(any(abs(fit.x-np.array(bounds[0]))<1e-3) or any(abs(fit.x-np.array(bounds[1]))<1e-3))}
(OUT/'camera-fit.json').write_text(json.dumps(metrics,indent=2)+'\n')
cam={'structure_id':'tremont_house_1','source_id':'gifford_tremont_house_no_1','photo':'/workspace/chicago/chicago/reference/images/chicago/chicago_first_tremont_house_1833.jpg','image_px':[1637,796],'principal_px':[cx,cy],'focal_px':f,'eye':[eu,ev,ey],'yaw_deg':yaw,'sun_uvy':[-1,-0.4,1.4],'solve':f'PROVISIONAL BASELINE FRAMING ONLY, NOT A SOLVED CAMERA. Six manually selected current wall-envelope corners (15.24 x 9.14 m, 5.2 m wall height) fitted by bounded least squares with level, vertical-preserving pinhole projection. Envelope dimensions are reconstructed, not picture-derived measurements. Point RMS {metrics["point_rms_px"]:.3f} px, maximum point residual {metrics["maximum_point_residual_px"]:.3f} px. Exact picks and residuals are camera-fit.json in the T-2385 handoff. Picture shows three storeys while current mesh has two; wrong envelope and inconsistent retrospective perspective prevent calibrated inference. Camera must be re-examined with corrected massing; no metric, geographic or date claim follows. Left gable is lighter than right eaves wall in monochrome drawing; sun direction is provisional for comparison, not surveyed lighting. Uses owner-approved attributed project reference source; no public-domain finding.'}
(OUT/'gifford-provisional.json').write_text(json.dumps(cam,indent=2)+'\n')
print(json.dumps({k:metrics[k] for k in ['eye','yaw_deg','focal_px','principal_px','point_rms_px','maximum_point_residual_px','at_or_near_bound']},indent=2))
