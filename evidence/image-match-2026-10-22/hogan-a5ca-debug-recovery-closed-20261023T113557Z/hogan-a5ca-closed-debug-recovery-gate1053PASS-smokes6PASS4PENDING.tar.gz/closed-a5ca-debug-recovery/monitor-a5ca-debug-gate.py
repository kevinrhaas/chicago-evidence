from pathlib import Path
import json,subprocess,time,datetime,sys
r=Path(__file__).resolve().parent/'a5ca-gate-failure';rid=39941322173;head='a5cae2adc766425103151debd8ef57b152d70022';repo='kevinrhaas/chicago';errors=0
while True:
 stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
 try:
  def api(path):return json.loads(subprocess.check_output(['gh','api',path],text=True,timeout=45))
  run=api(f'repos/{repo}/actions/runs/{rid}');assert run['head_sha']==head and run['run_attempt']==2
  (r/f'debug-attempt2-{stamp}.json').write_text(json.dumps(run,indent=2)+'\n');errors=0
  if run['status']=='completed':
   jobs=api(f'repos/{repo}/actions/runs/{rid}/attempts/2/jobs');(r/'debug-attempt2-final-jobs.json').write_text(json.dumps(jobs,indent=2)+'\n');(r/'debug-attempt2-final-run.json').write_text(json.dumps(run,indent=2)+'\n')
   artifacts=api(f'repos/{repo}/actions/runs/{rid}/artifacts');(r/'debug-attempt2-artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n')
   result=subprocess.run(['gh','api',f'repos/{repo}/actions/runs/{rid}/attempts/2/logs'],capture_output=True,timeout=90);(r/'debug-attempt2-logs.zip').write_bytes(result.stdout);(r/'debug-attempt2-logs-fetch.stderr').write_bytes(result.stderr)
   for job in jobs['jobs']:
    if job['name']=='gate':
     result=subprocess.run(['gh','api',f'repos/{repo}/actions/jobs/{job["id"]}/logs'],capture_output=True,timeout=90);(r/'debug-attempt2-gate-job.log').write_bytes(result.stdout);(r/'debug-attempt2-gate-job-fetch.stderr').write_bytes(result.stderr)
   print(json.dumps({'event':'DEBUG_GATE_COMPLETED','head':head,'run_id':rid,'attempt':2,'conclusion':run['conclusion'],'merge_performed':False,'no_further_retry':True,'directory':str(r)}),flush=True);sys.exit(0 if run['conclusion']=='success' else 1)
 except Exception as e:
  errors+=1;(r/f'debug-attempt2-{stamp}-API-error.txt').write_text(str(e)+'\n')
  if errors>=5:print(json.dumps({'event':'MONITOR_API_ERROR','detail':str(e)}),flush=True);sys.exit(3)
 time.sleep(60)
