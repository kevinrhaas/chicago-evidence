# Local roof measurement for declared offset stacks

UNAPPLIED: canonical app and geometry unchanged. Parent requested the minimal independent mesh measurement for the new slope_offsets path after the existing global-ridge proxy falsely failed the current four-stack roof.

The candidate modifies ONLY tools/measure_stack_ordinance.py. Existing non-offset paths retain their accessor-bound readings and assertions. Only a record explicitly declaring slope_offsets enters the strict decoded-triangle path; no structure ID, source identity, generator parameter, height table or geometry exemption selects a pass. The current style requires a frame_tavern master, an embedded uncompressed FLOAT VEC3 mesh and one identity node. Unrecognized transforms/layouts fail closed until deliberately supported.

Brick/chimney faces are welded by actual positions, their connected shaft/cap islands merge on overlapping horizontal footprint and touching vertical extent, and recovered count must equal the record. Roof readings use actual upward triangles; all four cap-box corners and centre must query successfully. Clipping each roof triangle to the WHOLE cap footprint also finds a ridge away from those five samples. The covered area must equal the cap area without holes/overlaps; the highest clipped roof point is conservative. Every recovered stack is measured and the worst local clearance supplies the existing ordinance row. Existing18in=0.4572m and0.0005m tolerance are unchanged. Missing roof, missing master, bad counts, corrupt/accessor buffers, compressed/sparse data or unsafe transforms refuse.

Actual read-only results in actual-legacy-parity-and-local-verdict.json:

-442 current rows,441 legacy rows serialized byte-exact before/after. New offset row is the only changed reading. It retains all4 stacks and reports its minimum, not merely the highest stack.
-Current GLB ed3c2605c9c3c584511e3e093a4b57facff7854b29e9a73354891297708a244a: actual local clearances1.6375386904,0.4875392716,0.8875394392,1.0875389590m; all pass.
-In-memory actual-GLB negative control lowers only the second shaft top/cap0.10m: exactly1 of4 fails, the other3 stay compliant. The file is untouched.
-The existing4 cases and floor assertion still execute, followed by15 independent mesh assertions including short-with-tall, missing roof/coverage, count mismatch, truncated buffers, invalid indices, normalized/sparse/nonfinite POSITION, transforms and scene roots. Off-centre ridge test proves five samples alone are insufficient; clipping returns the actual maximum. See self-test.log.

Apply only after comparing baseline-guard.json to the current canonical tool. local-roof.patch is the one-file diff; measure_stack_ordinance.py is the full exact candidate. compose.py only writes this owned package and reproduces the proposal; local_functions.py and local_selftest.py are preparation fragments, not proposed new canonical modules. No new check.sh gate or registry tool is introduced. After actual adoption run existing gate and self-test plus remeasure this modified existing tool through node tools/measure_step_isolation.mjs --tool tools/measure_stack_ordinance.py. Full integration preflight remains required.

This is the project's existing dimensional ratchet, not a claim that the undated Gifford picture attests ordinance compliance before its5August1835 enactment. The source positions, heights, camera, roof, palettes, GLB, provenance and old recipe remain unchanged.
