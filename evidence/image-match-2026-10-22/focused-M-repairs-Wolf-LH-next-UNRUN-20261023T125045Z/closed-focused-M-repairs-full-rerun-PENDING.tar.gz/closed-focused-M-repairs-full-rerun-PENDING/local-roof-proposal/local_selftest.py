def local_stack_self_test():
    """Actual triangle fixtures; no generator module or height metadata."""
    import math
    import struct

    failures = []

    def fixture(rises=(0.8, 0.8, 0.8, 0.8), ridge=False):
        if ridge:
            # A ridge inside the cap but away from its centre. Five samples
            # alone miss its maximum; the clipped triangle vertices must catch it.
            roof = []
            for z0, h0, z1, h1 in ((0, 5, 3.1, 5.31), (3.1, 5.31, 8, 4.82)):
                a,b,c,d = (0,h0,z0),(0,h1,z1),(20,h1,z1),(20,h0,z0)
                roof.extend(((a,b,c),(a,c,d)))
            foot = 5.3
        else:
            a,b,c,d = (0,5,0),(0,7.4,8),(20,7.4,8),(20,5,0)
            roof, foot = [(a,b,c),(a,c,d)], 5.9
        brick = []

        def box(x0,y0,z0,x1,y1,z1):
            p = [(x,y,z) for x in (x0,x1) for y in (y0,y1) for z in (z0,z1)]
            # Five faces: no lower face, matching emitted shaft/cap boxes.
            for a,b,c,d in ((0,1,3,2),(4,6,7,5),(0,2,6,4),(2,3,7,6),(1,5,7,3)):
                brick.extend(((p[a],p[b],p[c]),(p[a],p[c],p[d])))
        for x, rise in zip((2,6,10,14), rises):
            box(x-.25,foot-.3,2.75,x+.25,foot+rise,3.25)
            box(x-.3,foot+rise,2.7,x+.3,foot+rise+.075,3.3)
        js = {"buffers": [], "bufferViews": [], "accessors": [],
              "materials": [{"name":"roof_shingle"},{"name":"brick"}],
              "meshes":[{"primitives":[]}], "nodes":[{"mesh":0}],
              "scenes":[{"nodes":[0]}], "scene":0}
        blob = bytearray()
        for material, triangles in enumerate((roof,brick)):
            vertices = [p for tri in triangles for p in tri]
            attrs = []
            for kind, ct, fmt, data in (("VEC3",5126,"fff",vertices),
                                         ("SCALAR",5125,"I",[(i,) for i in range(len(vertices))])):
                while len(blob)%4:
                    blob.append(0)
                start = len(blob)
                for value in data:
                    blob.extend(struct.pack("<"+fmt,*value))
                js["bufferViews"].append({"buffer":0,"byteOffset":start,"byteLength":len(blob)-start})
                js["accessors"].append({"bufferView":len(js["bufferViews"])-1,
                                        "componentType":ct,"type":kind,"count":len(data)})
                attrs.append(len(js["accessors"])-1)
            js["meshes"][0]["primitives"].append({"material":material,"attributes":{"POSITION":attrs[0]},"indices":attrs[1]})
        js["buffers"] = [{"byteLength":len(blob)}]
        return js,{0:bytes(blob)}

    def check(label, assertion):
        if not assertion:
            failures.append(label)
        print(f"  {'ok   ' if assertion else 'FAIL '}: {label}")

    def rejects(label, edit, expected=4):
        js, bins = fixture()
        edit(js,bins)
        try:
            local_stack_clearances(js,bins,expected)
        except (ValueError, KeyError, IndexError, TypeError, struct.error):
            check(label, True)
        else:
            check(label, False)

    js,bins = fixture()
    rows = local_stack_clearances(js,bins,4)
    check("four shafts/caps recovered from split-face triangle vertices", len(rows)==4)
    check("whole-cap highest roof gives exact conservative clearance", all(abs(r['above']-.785)<1e-5 for r in rows))
    check("all four locally compliant offset stacks pass", not offenders(rows))
    low = local_stack_clearances(*fixture((.8,.2,.8,.8)),4)
    check("one short offset stack fails while three taller stacks remain compliant",
          len(offenders(low))==1 and sum(r['above']>=MINIMUM_M for r in low)==3)
    ridge = local_stack_clearances(*fixture(ridge=True),4)
    check("clipped triangles catch off-centre ridge missed by five point samples",
          all(abs(r['roof_top']-5.31)<1e-5 and r['roof_top']>max(r['roof_samples'])+.009 for r in ridge))
    rejects("missing roof fails closed", lambda j,b:j['meshes'][0]['primitives'].pop(0))
    rejects("missing roof coverage at a cap corner fails closed", lambda j,b:j['accessors'][1].update(count=3))
    rejects("record/mesh chimney count disagreement fails closed", lambda j,b:None,3)
    rejects("truncated binary fails closed", lambda j,b:b.update({0:b[0][:-20]}))
    rejects("out-of-range indices fail closed", lambda j,b:b.update({0:b[0][:72]+struct.pack('<I',999999)+b[0][76:]}))
    rejects("normalized POSITION fails closed", lambda j,b:j['accessors'][0].update(normalized=True))
    rejects("sparse POSITION fails closed", lambda j,b:j['accessors'][0].update(sparse={'count':1}))
    rejects("nonfinite POSITION fails closed", lambda j,b:b.update({0:struct.pack('<f',math.nan)+b[0][4:]}))
    rejects("nonidentity node transforms fail closed", lambda j,b:j['nodes'][0].update(translation=[0,1,0]))
    rejects("wrong scene roots fail closed", lambda j,b:j['scenes'][0].update(nodes=[]))
    return failures
