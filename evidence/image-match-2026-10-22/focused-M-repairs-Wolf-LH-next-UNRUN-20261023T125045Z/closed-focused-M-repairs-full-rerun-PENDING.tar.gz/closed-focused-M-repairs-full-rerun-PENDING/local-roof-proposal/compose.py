from pathlib import Path

P = Path(__file__).resolve().parent
s = (P / 'baseline.py').read_text()
f = (P / 'local_functions.py').read_text()


def replace(old, new):
    global s
    assert s.count(old) == 1, old
    s = s.replace(old, new)


replace('def readings():\n', f + '\n\ndef readings():\n')
replace('            if n <= 0:\n                continue\n', '''            slope_offsets = (phase.get("form", {}).get("chimney_placement", {}) or {}).get("value") == "slope_offsets"
            if n <= 0 and not slope_offsets:
                continue
''')
replace('''            if key not in by_key:
                continue
            tops = material_tops(read_glb(ROOT / "assets" / "gltf" / by_key[key])[0])
''', '''            if key not in by_key:
                if slope_offsets:
                    raise ValueError(f"{key}: slope_offsets has no committed master")
                continue
            glb = read_glb(ROOT / "assets" / "gltf" / by_key[key])
            if slope_offsets:
                if arch_of[key] != "frame_tavern":
                    raise ValueError(f"{key}: unsupported slope_offsets archetype")
                measured = local_stack_clearances(*glb, n)
                worst = min(measured, key=lambda row: row["above"])
                names = {m.get("name") for m in glb[0].get("materials", [])}
                out.append({"id": rec["id"], "archetype": arch_of[key], "stacks": n,
                            "material": "+".join(sorted(names.intersection(STACK_MATERIALS))),
                            "roof_top": worst["roof_top"], "above": worst["above"],
                            "per_stack": measured})
                continue
            tops = material_tops(glb[0])
''')
replace('''  here rather than left for a reader to assume.
''', '''  here rather than left for a reader to assume.

The declared `slope_offsets` scheme is measured separately: it has no stack above
the global ridge, so that bound cannot answer this question. Decode the actual
brick/chimney and upward roof triangles, recover every shaft and cap, and use the
highest roof point under the entire cap footprint for each stack. All stacks must
clear the same eighteen-inch floor; no generator heights or named-building
exemptions are used. Unsupported mesh layouts, missing roof coverage and a count
that disagrees with the record fail closed. Existing schemes keep the original
bounds reading. This is the project's existing dimensional ratchet, not evidence
that this undated retrospective image attests compliance in July1835.
''')
if (P / 'local_selftest.py').exists():
    replace('def self_test():\n', (P / 'local_selftest.py').read_text() + '\n\ndef self_test():\n')
    replace('    if failures:\n', '    failures.extend(local_stack_self_test())\n\n    if failures:\n')
(P / 'measure_stack_ordinance.py').write_text(s)
