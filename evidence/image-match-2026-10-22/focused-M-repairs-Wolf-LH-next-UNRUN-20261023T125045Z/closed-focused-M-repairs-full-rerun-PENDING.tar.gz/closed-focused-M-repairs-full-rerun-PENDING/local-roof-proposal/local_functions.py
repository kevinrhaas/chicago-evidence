def local_stack_clearances(js, bins, expected):
    """Actual uncompressed, identity-node mesh: each stack over its own roof.

    Bounded to the declared slope_offsets path. Unsupported layouts fail closed;
    no generator heights, accessor bounds or structure-name exemptions are used.
    glTF is Y-up, so the horizontal footprint is X/Z. Shaft/cap mesh islands are
    welded by positions, then merged only when their XY footprints and Z ranges
    intersect (in Y-up terms, XZ and Y). Every recovered stack is measured.
    """
    import math
    import struct

    def refuse(why):
        raise ValueError("local stack measurement: " + why)

    def integer(value):
        return isinstance(value, int) and not isinstance(value, bool) and value >= 0

    if not integer(expected) or expected < 1:
        refuse("invalid expected chimney count")
    if js.get("extensionsUsed") or len(js.get("buffers", [])) != 1:
        refuse("extensions or multiple buffers unsupported")
    blob = bins.get(0)
    if not isinstance(blob, bytes) or js["buffers"][0].get("uri"):
        refuse("missing embedded buffer")
    if js["buffers"][0].get("byteLength") not in range(len(blob) - 3, len(blob) + 1):
        refuse("buffer length mismatch")
    nodes = js.get("nodes", [])
    if len(nodes) != 1 or nodes[0].get("children"):
        refuse("only one identity mesh node is supported")
    node = nodes[0]
    identity = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]
    for key, want in (("matrix", identity), ("translation", [0, 0, 0]),
                      ("rotation", [0, 0, 0, 1]), ("scale", [1, 1, 1])):
        if node.get(key, want) != want:
            refuse("nonidentity node transform unsupported")
    scenes = js.get("scenes", [])
    scene = js.get("scene", 0)
    if not integer(scene) or scene >= len(scenes) or scenes[scene].get("nodes") != [0]:
        refuse("unsafe scene roots")
    mesh_i = node.get("mesh")
    if not integer(mesh_i) or mesh_i >= len(js.get("meshes", [])):
        refuse("missing mesh")

    def accessor(index, positions=False):
        if not integer(index) or index >= len(js.get("accessors", [])):
            refuse("missing accessor")
        acc = js["accessors"][index]
        ct = acc.get("componentType")
        types = {5123: ("H", 2), 5125: ("I", 4), 5121: ("B", 1)}
        if positions:
            if ct != 5126 or acc.get("type") != "VEC3":
                refuse("POSITION must be unnormalized FLOAT VEC3")
            fmt, size, n = "f", 4, 3
        else:
            if ct not in types or acc.get("type") != "SCALAR":
                refuse("indices must be unsigned integer SCALAR")
            fmt, size = types[ct]
            n = 1
        if acc.get("normalized") or acc.get("sparse") or acc.get("extensions"):
            refuse("normalized/sparse/extension accessor unsupported")
        count, vi = acc.get("count"), acc.get("bufferView")
        if not integer(count) or count < 1 or not integer(vi) or vi >= len(js.get("bufferViews", [])):
            refuse("invalid count or buffer view")
        view = js["bufferViews"][vi]
        if view.get("buffer", 0) != 0 or view.get("extensions"):
            refuse("external/compressed view unsupported")
        vo, ao = view.get("byteOffset", 0), acc.get("byteOffset", 0)
        length, stride = view.get("byteLength"), view.get("byteStride", size * n)
        if not all(integer(x) for x in (vo, ao, length, stride)) or stride < size * n or stride % size:
            refuse("invalid view layout")
        if vo + length > len(blob) or ao + (count - 1) * stride + size * n > length:
            refuse("truncated accessor")
        values = [struct.unpack_from("<" + fmt * n, blob, vo + ao + i * stride)
                  for i in range(count)]
        if positions and not all(math.isfinite(x) for point in values for x in point):
            refuse("nonfinite POSITION")
        return values

    bricks, roofs = [], []
    for prim in js["meshes"][mesh_i].get("primitives", []):
        mi = prim.get("material")
        if not integer(mi) or mi >= len(js.get("materials", [])):
            refuse("invalid material")
        name = js["materials"][mi].get("name", "")
        target = bricks if name in STACK_MATERIALS else roofs if name == "roof" or name.startswith("roof_") else None
        if target is None:
            continue
        if prim.get("mode", 4) != 4 or prim.get("extensions") or prim.get("targets"):
            refuse("only static uncompressed triangles supported")
        points = accessor(prim.get("attributes", {}).get("POSITION"), True)
        ix = [v[0] for v in accessor(prim.get("indices"))]
        if len(ix) % 3 or any(i >= len(points) for i in ix):
            refuse("invalid triangle indices")
        for offset in range(0, len(ix), 3):
            tri = tuple(points[i] for i in ix[offset:offset + 3])
            a, b, c = tri
            cross = ((b[1]-a[1])*(c[2]-a[2])-(b[2]-a[2])*(c[1]-a[1]),
                     (b[2]-a[2])*(c[0]-a[0])-(b[0]-a[0])*(c[2]-a[2]),
                     (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))
            if sum(v*v for v in cross) <= 1e-16:
                refuse("degenerate triangle")
            if target is bricks or cross[1] > 1e-9:
                target.append(tri)
    if not bricks or not roofs:
        refuse("missing stack or upward roof triangles")

    # Exported faces split normals/UVs, so index connectivity is insufficient.
    parent = list(range(len(bricks)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def join(i, j):
        parent[find(i)] = find(j)

    seen = {}
    for i, tri in enumerate(bricks):
        for point in tri:
            key = tuple(round(x, 6) for x in point)
            if key in seen:
                join(i, seen[key])
            seen[key] = i
    islands = {}
    for i, tri in enumerate(bricks):
        islands.setdefault(find(i), []).extend(tri)
    boxes = [[list(min(p[k] for p in points) for k in range(3)),
              list(max(p[k] for p in points) for k in range(3))]
             for points in islands.values()]
    if any(any(hi[k] - lo[k] <= 1e-6 for k in range(3)) for lo, hi in boxes):
        refuse("stack island has no volume")
    # A cap touches its shaft at a different rectangle, without welded vertices.
    changed = True
    while changed:
        changed = False
        for i in range(len(boxes)):
            for j in range(i + 1, len(boxes)):
                a, b = boxes[i], boxes[j]
                horizontal = all(min(a[1][k], b[1][k]) - max(a[0][k], b[0][k]) > 1e-6 for k in (0, 2))
                vertical = min(a[1][1], b[1][1]) - max(a[0][1], b[0][1]) >= -1e-5
                if horizontal and vertical:
                    boxes[i] = [[min(a[0][k], b[0][k]) for k in range(3)],
                                [max(a[1][k], b[1][k]) for k in range(3)]]
                    boxes.pop(j)
                    changed = True
                    break
            if changed:
                break
    if len(boxes) != expected:
        refuse(f"record counts {expected} stacks; mesh recovers {len(boxes)}")

    def clip(poly, axis, edge, sign):
        out = []
        for a, b in zip(poly, poly[1:] + poly[:1]):
            da, db = sign * (a[axis] - edge), sign * (b[axis] - edge)
            if da >= 0:
                out.append(a)
            if (da < 0) != (db < 0):
                t = da / (da - db)
                out.append(tuple(a[k] + t * (b[k] - a[k]) for k in range(3)))
        return out

    def height(tri, x, z):
        a, b, c = tri
        det = (b[2]-c[2])*(a[0]-c[0]) + (c[0]-b[0])*(a[2]-c[2])
        if abs(det) < 1e-12:
            return None
        u = ((b[2]-c[2])*(x-c[0]) + (c[0]-b[0])*(z-c[2])) / det
        v = ((c[2]-a[2])*(x-c[0]) + (a[0]-c[0])*(z-c[2])) / det
        if min(u, v, 1-u-v) < -1e-6:
            return None
        return u*a[1] + v*b[1] + (1-u-v)*c[1]

    results = []
    for lo, hi in sorted(boxes, key=lambda b: (b[0][0], b[0][2])):
        samples = [(x, z) for x in (lo[0], hi[0]) for z in (lo[2], hi[2])]
        samples.append(((lo[0]+hi[0])/2, (lo[2]+hi[2])/2))
        sampled = []
        for x, z in samples:
            values = [h for tri in roofs if (h := height(tri, x, z)) is not None]
            if not values:
                refuse("roof missing under stack footprint corner/centre")
            sampled.append(max(values))
        # Clipping also catches a ridge crossing the cap away from the centre:
        # a linear triangle's maximum is at a clipped vertex, not an arbitrary sample.
        clipped, area = [], 0.0
        for tri in roofs:
            poly = list(tri)
            for axis, edge, sign in ((0, lo[0], 1), (0, hi[0], -1),
                                     (2, lo[2], 1), (2, hi[2], -1)):
                poly = clip(poly, axis, edge, sign) if poly else []
            if len(poly) < 3:
                continue
            a = abs(sum(p[0]*q[2]-q[0]*p[2] for p, q in zip(poly, poly[1:]+poly[:1]))) / 2
            if a > 1e-10:
                area += a
                clipped.extend(p[1] for p in poly)
        wanted = (hi[0]-lo[0])*(hi[2]-lo[2])
        if abs(area-wanted) > max(1e-6, wanted*1e-5) or not clipped:
            refuse("roof does not cover footprint once (hole/overlap)")
        roof = max(clipped + sampled)
        if not lo[1] < roof < hi[1]:
            refuse("stack does not penetrate measured roof")
        results.append({"bbox_min": lo, "bbox_max": hi, "top": hi[1],
                        "roof_top": roof, "above": hi[1]-roof,
                        "roof_samples": sampled})
    return results
