# Structure-version fixture: include actual runtime reader

UNAPPLIED. The real validator now reads the flag renderer contract relative to validate.ROOT. This self-test deliberately changes ROOT to a fixture that omitted the renderer. The clean baseline failed before its mutations, while real-root direct contract tests passed. Copy the exact existing reader into the sandbox; preserve every version/missing-mesh/stale-mesh/refused-label assertion. No dummy declaration and no exemption is introduced.

`fixture.patch` adds just the missing actual source file to the existing fixture copy list. `proof.json` records a lightweight actual sandbox-builder exercise plus actual contract parser; it is not a claim that the full version test passed.

After parent applies and verifies the guard, rerun `python3 tools/test_structure_versions.py`. New-step isolation measurements, sequential from chicago/4d:

```sh
node tools/measure_step_isolation.mjs --tool tools/test_frame_tavern_picture_features.py
node tools/measure_step_isolation.mjs --tool tools/test_flag_anchors.mjs
node tools/measure_step_isolation.mjs --tool tools/test_flag_form_contract.py
node tools/audit_step_isolation.mjs --check --quiet
```

Each --tool runs the exact declared check.sh invocation under the existing probes and merges only that measured row into tools/step_isolation.json; it does not rebuild the whole registry. It is an actual measurement, not a manually inserted empty wrote row. No measurement has run in this child package, because parent owns registry writes and heavy scheduling. The fixture-copy change is in an already measured tool; remeasure tools/test_structure_versions.py as well if required to refresh that modified tool’s empirical record, after its targeted test is green.
