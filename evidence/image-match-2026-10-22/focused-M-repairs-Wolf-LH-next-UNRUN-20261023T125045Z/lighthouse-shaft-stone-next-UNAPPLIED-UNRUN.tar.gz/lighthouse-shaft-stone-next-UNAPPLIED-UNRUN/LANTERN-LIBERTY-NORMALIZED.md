### L-lighthouse-lantern-detail-2373 — Light cage and shallow crown within the old envelope

**Covers:** `chicago_lighthouse_1832.tower_1832.form.tower_lantern_detail`.
**Decision:** After actual Castelnau comparison, use lantern-only alpha0.18,0.16m dark sill,0.72m dome rise,12cage members45mm wide,16gallery posts35mm wide, lower gallery ring and18mm finial radius. The longer stem partitions the same old cap envelope. Shared opaque glass and shaft panes stay unchanged.
**Uncertainty:** Actual imagery supports light/open framing, a lower band and shallow rounded crown, not optical values, member counts, sections or paint. Every number and finish is reconstructed. Source circa1838-to-July1835 continuity is inferred. Actual lantern comparison improved the opaque drum but still DIFFERS; no exact image match or full original acceptance is claimed.
**Source:** `castelnau_1842_chicago_harbor`, actual1842 plate and held reproduction.
**How to resolve:** Match all dated pictures from current canonical masters and solve outstanding camera/height-datum uncertainty. No overall bounds, profile gallery/cap-base, foundation, georeference, bearing, date or nominal40ft change is claimed.
**Recorded:** 2026-10-23, normalizing the prior frozen proposal in this NEW package only; earlier frozen files remain untouched.
