from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;R=Path('/workspace/worktrees/t2373-lighthouse/chicago/4d');sys.path.insert(0,str(R/'tools'))
import compile_liberties as lib
text='## Per-subject liberties\n\n'+'\n\n'.join((H/p).read_text() for p in ['LANTERN-LIBERTY-NORMALIZED.md','LIBERTY-DRAFT.md'])
entries,problems=lib.parse(text,{'chicago_lighthouse_1832':'Chicago Lighthouse1832'})
assert not problems,problems
assert len(entries)==2 and all(e['section']!='resolved' for e in entries)
r=json.loads((H/'candidate/chicago/4d/data/structures/chicago_lighthouse_1832.json').read_text());checks=[]
for e in entries:
 for c in e['covers']:
  assert c['domain']=='structure' and c['structure']==r['id'] and c['phase']=='tower_1832'
  node=r['phases'][0]
  for key in c['aspect'].split('.'):node=node[key]
  assert node['confidence']=='reconstructed' and node.get('note')
  checks.append(c)
report={'status':'passed','draft_entries':len(entries),'parser_problems':problems,'exact_actual_candidate_reverse_claims':checks,'not_canonical_ledger_admission':True};(H/'liberty-draft-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
