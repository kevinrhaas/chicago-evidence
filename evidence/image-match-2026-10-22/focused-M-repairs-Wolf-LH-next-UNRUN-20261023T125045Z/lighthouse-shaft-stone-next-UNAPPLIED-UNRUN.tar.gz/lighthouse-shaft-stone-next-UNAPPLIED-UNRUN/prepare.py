from pathlib import Path
import ast,hashlib,json,shutil,subprocess
H=Path(__file__).resolve().parent;PRE=Path('/tmp/chicago-next-model/T-2373-lantern-detail-next');run=Path((PRE/'latest-run.txt').read_text().strip());paths=['chicago/4d/generators/archetypes/fort_structure_params.py','chicago/4d/generators/archetypes/fort_structure.py','chicago/4d/data/structures/chicago_lighthouse_1832.json']
for rel in paths:
 for kind in ['baseline','candidate']:
  dest=H/kind/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(run/'proposed'/Path(rel).relative_to('chicago/4d'),dest)
p=H/'candidate'/paths[0];s=p.read_text();s=s.replace('"tower_lantern_detail", "face_openings",','"tower_lantern_detail", "tower_masonry", "face_openings",')
needle='    tower_lantern_detail: dict | None = field(default=None, kw_only=True)';assert s.count(needle)==1;s=s.replace(needle,needle+'\n\n    # Lighthouse-only procedural stone and plain recessed aperture treatment.\n    tower_masonry: dict | None = field(default=None, kw_only=True)')
needle='        if self.tower_lantern_detail is not None:';assert s.count(needle)==1
s=s.replace(needle,'''        if self.tower_masonry is not None:
            if self.kind != "tower" or self.construction != "stone":
                raise ParamError("tower_masonry requires a stone tower")
            d=self.tower_masonry
            keys={"course_m","bond_m","joint_m","relief_m","reveal_m","seed"}
            if not isinstance(d,dict) or set(d)!=keys or any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in d.values()):
                raise ParamError("tower_masonry needs six finite declared controls")
            if not (.2<=d['course_m']<=.6 and .3<=d['bond_m']<=1.2 and .01<=d['joint_m']<=.05
                    and .002<=d['relief_m']<=.025 and d['relief_m']<d['reveal_m']<=.12
                    and isinstance(d['seed'],int) and 0<=d['seed']<=100000):
                raise ParamError("tower_masonry controls out of reconstructed bounds")
'''+needle)
old='set(o) != {"facet", "width_m", "z0_fraction", "z1_fraction"}';assert old in s;s=s.replace(old,'set(o)-{"offset_m"} != {"facet", "width_m", "z0_fraction", "z1_fraction"}')
s=s.replace('for k in ("width_m", "z0_fraction", "z1_fraction")):', 'for k in ("width_m", "z0_fraction", "z1_fraction")) or ("offset_m" in o and (isinstance(o["offset_m"],bool) or not isinstance(o["offset_m"],(float,int)) or not math.isfinite(o["offset_m"]))):')
old='''                if o["width_m"]+.24 > 2*top_radius*math.sin(math.pi/12):''';assert old in s
s=s.replace(old,'''                padding = .025 if self.tower_masonry is not None else .12
                if o["width_m"]+2*padding+2*abs(o.get("offset_m",0)) > 2*top_radius*math.sin(math.pi/12):''')
s=s.replace('        tower_lantern_detail=val("tower_lantern_detail", None),','        tower_lantern_detail=val("tower_lantern_detail", None),\n        tower_masonry=val("tower_masonry", None),')
s=s.replace('"u0": -o["width_m"]/2, "u1": o["width_m"]/2,','"u0": o.get("offset_m",0)-o["width_m"]/2, "u1": o.get("offset_m",0)+o["width_m"]/2,');p.write_text(s)
p=H/'candidate'/paths[1];s=p.read_text();old='''    lo, up = ring(r0, 0.0), ring(r1, shaft)
    for i in range(n):
        j = (i + 1) % n
        b.add_poly([lo[i], lo[j], up[j], up[i]], c, M_WALL)

    if p.tower_openings:
        _tower_apertures(b, p, cx, cy, r0, shaft)
''';new='''    lo, up = ring(r0, 0.0), ring(r1, shaft)
    if p.tower_masonry is not None:
        _tower_stone_shaft(b,p,cx,cy,r0,shaft)
    else:
        for i in range(n):
            j = (i + 1) % n
            b.add_poly([lo[i], lo[j], up[j], up[i]], c, M_WALL)
        if p.tower_openings:
            _tower_apertures(b, p, cx, cy, r0, shaft)
''';assert s.count(old)==1;s=s.replace(old,new);s+='\n\n'+(H/'stone_helpers.txt').read_text();p.write_text(s)
p=H/'candidate'/paths[2];rec=json.loads(p.read_text());f=rec['phases'][0]['form'];f['tower_masonry']={'value':{'course_m':.30,'bond_m':.50,'joint_m':.025,'relief_m':.012,'reveal_m':.06,'seed':2373},'confidence':'reconstructed','sources':['castelnau_1842_chicago_harbor'],'note':'PROCEDURAL MASONRY DIAGNOSTIC after actual lantern-detail review: the actual Castelnau plate shows irregular horizontal masonry marks and plain narrow dark apertures, unlike the smooth shaft and bright kit casing.0.30m nominal variable courses,0.50m nominal staggered bond,25mm joints,12mm inward relief,60mm aperture reveals and deterministic seed2373 are reconstructed, not measured ashlar or mortar dimensions. All relief stays inside the old12 tapered facet planes; original foot/top seats preserve bounds, ground contacts, centre and lantern/profile. Five local stone tones and dark joint proxy vary the old reconstructed stone palette; monochrome gives no paint or stone-colour attestation. No image pixels, texture, geometry or palette are sampled from the source or another building. Stone courses could include graphic hatch and do not prove exact lithology or masonry bond. No surveyed placement, nominal40ft, date, bearing, foundation or lantern change.1838-to-July1835 continuity remains inferred and no match is claimed.'}
f['tower_openings']['value'][0].update({'width_m':.34,'offset_m':-.055})
f['tower_openings']['value'][1].update({'width_m':.42,'offset_m':-.03,'z0_fraction':.70,'z1_fraction':.79})
f['tower_openings']['value'][2].update({'width_m':.54,'offset_m':0.0})
f['tower_openings']['note']+=' SOURCE-BOUNDED LOCAL TREATMENT TRIAL: projected old widths were only2.98/2.72/2.72px against coarse6±2/7±3/7±2px source marks. Reconstructed widths become0.34/0.42/0.54m, tangent offsets-0.055/-0.03/0m; the uncertain shaded mark grows vertically tofractions0.70..0.79. Clear left aperture levels remain unchanged. Plain60mm recesses replace white kit casing without a ground door. Pixel bounds constrain the diagnostic but do not attest physical window metrics or joinery.'
p.write_text(json.dumps(rec,indent=2)+'\n')
for p in(H/'candidate').rglob('*.py'):ast.parse(p.read_text())
for name in ['camera-profile-research.json','source-next-research.json','run-preview.sh','prepare_fixture.py','glb_contracts.py','check_material_export.py','check_renderer.mjs']:
 shutil.copy2(PRE/name,H/name)
# Baseline now already has the light cage; both exports must preserve its alpha.
p=H/'check_material_export.py';s=p.read_text().replace("if kind=='baseline':assert not blend\n else:","if kind in ['baseline','proposed']:");p.write_text(s)
meta=[{'path':rel,**{kind+'_sha256':hashlib.sha256((H/kind/rel).read_bytes()).hexdigest() for kind in ['baseline','candidate']}} for rel in paths];(H/'inputs.json').write_text(json.dumps(meta,indent=2)+'\n')
r=subprocess.run(['git','diff','--no-index','--','baseline','candidate'],cwd=H,text=True,capture_output=True);assert r.returncode==1;(H/'shaft-stone-next.patch').write_text(r.stdout.replace('a/baseline/','a/').replace('b/candidate/','b/'));print(H)
