"""Light-only continuation against the closed actual physical-L run; no heavy IO."""
from pathlib import Path
import shutil,json,difflib,hashlib
H=Path(__file__).resolve().parent;P=Path('/tmp/chicago-next-model/T-2386-L-preview');R=P/'runs/20261023-121002-482061'
assert not (H/'candidate').exists(),'Never overwrite a frozen next proposal'
shutil.copytree(P/'templates/after',H/'candidate')
rels=['generators/archetypes/log_dwelling.py','generators/archetypes/log_dwelling_params.py','data/structures/wolf_point_tavern.json','data/sources/blanchard_shober_1867_wolf_point.json']
for rel in rels:
 d=H/'baseline'/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/'after'/rel,d)
for rel in ['assets/gltf/wolf_point_tavern__log_frame_1828.glb','assets/manifest.json','docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.json','export-contract.json']:
 d=H/'baseline'/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/'after'/rel,d)
for rel in ['render.png','nypl-1867-L-provisional-side-by-side.jpg']:
 d=H/'baseline/reviews'/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/'reviews/after'/rel,d)
# Add explicit, keyword-only, off-by-default controls. No old constructor changes.
p=H/'candidate/generators/archetypes/log_dwelling_params.py';s=p.read_text()
s=s.replace('"compound_joint", "roof_pipe",','"compound_joint", "roof_pipe", "compound_wall_cladding", "compound_roof_overhang_m", "sign_pole_set_out",')
needle='    compound_joint: str | None = field(default=None, kw_only=True)';assert s.count(needle)==1
s=s.replace(needle,needle+'''
    # Optional pictured envelope/edge controls, currently bounded to elbow plans.
    compound_wall_cladding: str | None = field(default=None, kw_only=True)
    compound_roof_overhang_m: float = field(default=0.0, kw_only=True)
    # (baseXY,headXYZ,armXYZ,boardWH,hangerDrop), local reconstructed set-out.
    sign_pole_set_out: tuple | None = field(default=None, kw_only=True)''')
needle='        if self.compound_joint not in (None, "elbow"):';assert s.count(needle)==1
s=s.replace(needle,'''        if self.compound_wall_cladding not in (None, "log_courses"):
            raise ParamError("compound_wall_cladding is None or log_courses")
        if (isinstance(self.compound_roof_overhang_m, bool) or
                not isinstance(self.compound_roof_overhang_m, (int,float)) or
                not math.isfinite(self.compound_roof_overhang_m) or
                not 0 <= self.compound_roof_overhang_m <= .30):
            raise ParamError("compound_roof_overhang_m outside finite0..0.30m")
        if ((self.compound_wall_cladding is not None or self.compound_roof_overhang_m > 0)
                and self.compound_joint != "elbow"):
            raise ParamError("compound envelope controls require the bounded elbow")
        if self.sign_pole_set_out is not None:
            _validate_sign_pole_set_out(self)
'''+needle)
needle='        compound_joint=val("compound_joint"),';assert s.count(needle)==1
s=s.replace(needle,needle+'''
        compound_wall_cladding=val("compound_wall_cladding"),
        compound_roof_overhang_m=val("compound_roof_overhang_m",0.0),
        sign_pole_set_out=_read_sign_pole_set_out(val("sign_pole_set_out")),''')
s+='''

def _read_sign_pole_set_out(raw):
    if raw is None:
        return None
    if not isinstance(raw,dict) or set(raw) != {"base_xy","head_xyz","arm_vector_xyz","board_wh","hanger_drop_m"}:
        raise ParamError("sign_pole_set_out needs exactly base_xy,head_xyz,arm_vector_xyz,board_wh,hanger_drop_m")
    try:
        return (tuple(raw["base_xy"]),tuple(raw["head_xyz"]),tuple(raw["arm_vector_xyz"]),tuple(raw["board_wh"]),raw["hanger_drop_m"])
    except TypeError as exc:
        raise ParamError("sign_pole_set_out coordinates must be sequences") from exc


def _validate_sign_pole_set_out(p):
    if p.compound_joint != "elbow" or not p.sign or p.sign_mount != "sapling_pole":
        raise ParamError("explicit pole set-out requires the bounded elbow's stated sapling sign")
    v=p.sign_pole_set_out
    if not isinstance(v,tuple) or len(v)!=5:
        raise ParamError("sign_pole_set_out needs five engine-neutral components")
    for part,n in zip(v[:4],(2,3,3,2)):
        if not isinstance(part,tuple) or len(part)!=n:
            raise ParamError("sign_pole_set_out coordinate/size component has wrong shape")
    values=tuple(x for part in v[:4] for x in part)+(v[4],)
    if any(isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) for x in values):
        raise ParamError("sign_pole_set_out needs finite numbers")
    (bx,by),(tx,ty,tz),(ax,ay,az),(bw,bh),drop=v;cw=core_extent(p)[2]
    # First declared position stays in the physical empty courtyard, not a hidden
    # part of the old bounding box; a200mm margin exceeds the105mm pole radius.
    if not (cw+.2 <= bx <= p.width_m+2 and cw+.2 <= by <= p.depth_m+2):
        raise ParamError("explicit pole base must stand clear in the elbow courtyard")
    if (not cw+.2 <= tx <= p.width_m+3 or not cw+.2 <= ty <= p.depth_m+3 or
            not 7 <= tz <= 14 or math.hypot(tx-bx,ty-by)>tz*.25):
        raise ParamError("explicit pole head height/lean outside bounded sapling pose")
    if not (1 <= math.hypot(ax,ay) <= 3.5 and abs(az)<=1.5 and .8<=bw<=2.4 and .5<=bh<=1.5 and .1<=drop<=.6):
        raise ParamError("explicit sign arm/board/hanger outside bounded dimensions")
'''
p.write_text(s)
# Optional elbow envelope: default geometry path keeps exact old calls/order.
p=H/'candidate/generators/archetypes/log_dwelling.py';s=p.read_text()
needle='''    cw=core_extent(p)[2];D=p.depth_m;W=p.width_m;h=p.wall_height_m;t=math.tan(math.radians(p.roof_pitch_deg))
    def emit(poly,z):
        if len(poly)>=3:b.add_poly([(x,y,z(x,y)) for x,y in poly],1.,M_ROOF)''';assert s.count(needle)==1
s=s.replace(needle,'''    cw=core_extent(p)[2];D=p.depth_m;W=p.width_m;h=p.wall_height_m;t=math.tan(math.radians(p.roof_pitch_deg))
    o=p.compound_roof_overhang_m
    def emit(poly,z):
        if len(poly)>=3:
            pts=[(x,y,z(x,y)) for x,y in poly]
            b.add_poly(pts,1.,M_ROOF)
            if o>0:b.add_poly([(x,y,z-.05) for x,y,z in reversed(pts)],1.,M_ROOF)''')
replacements={
'emit(rect(0,0,cw/2,D),lambda x,y:h+x*t)':'emit(rect(-o,-o,cw/2,D+o),lambda x,y:h+x*t)',
'emit(rect(cw/2,cw,cw,D),lambda x,y:h+(cw-x)*t)':'emit(rect(cw/2,cw+o,cw+o,D+o),lambda x,y:h+(cw-x)*t)',
'rect(cw/2,0,cw,cw/2)':'rect(cw/2,-o,cw+o,cw/2)',
'rect(cw/2,cw/2,cw,cw)':'rect(cw/2,cw/2,cw+o,cw+o)',
'emit(rect(cw,0,W,cw/2),lambda x,y:h+y*t)':'emit(rect(cw+o,-o,W+o,cw/2),lambda x,y:h+y*t)',
'emit(rect(cw,cw/2,W,cw),lambda x,y:h+(cw-y)*t)':'emit(rect(cw+o,cw/2,W+o,cw+o),lambda x,y:h+(cw-y)*t)',
}
for a,z in replacements.items():assert a in s,a;s=s.replace(a,z)
needle='''    # +Y and +X pictured ends plus unseen rear core cap; CCW outward.
    b.add_poly([(cw,D,h),(0,D,h),(cw/2,D,z)],1.,M_ROOF)
    b.add_poly([(0,0,h),(cw,0,h),(cw/2,0,z)],1.,M_ROOF)
    b.add_poly([(W,0,h),(W,cw,h),(W,cw/2,z)],1.,M_ROOF)''';assert s.count(needle)==1
s=s.replace(needle,'''    # +Y and +X pictured ends plus unseen rear core cap; CCW outward.
    if p.compound_wall_cladding == "log_courses":
        _log_course_gable(b,"y",D,0,cw,h,z,+1)
        _log_course_gable(b,"y",0,0,cw,h,z,-1)
        _log_course_gable(b,"x",W,0,cw,h,z,+1)
    else:
        b.add_poly([(cw,D,h),(0,D,h),(cw/2,D,z)],1.,M_ROOF)
        b.add_poly([(0,0,h),(cw,0,h),(cw/2,0,z)],1.,M_ROOF)
        b.add_poly([(W,0,h),(W,cw,h),(W,cw/2,z)],1.,M_ROOF)
    if o>0:
        # Reconstructed50mm edge, not a source-measured board or thickness.
        outline=[(-o,-o),(cw/2,-o),(cw+o,-o),(W+o,-o),(W+o,cw/2),(W+o,cw+o),(cw+o,cw+o),(cw+o,D+o),(cw/2,D+o),(-o,D+o)]
        def top(x,y):
            za=h+min(x,cw-x)*t if x<=cw+o+1e-9 else -math.inf
            zb=h+min(y,cw-y)*t if x>=cw/2-1e-9 and y<=cw+o+1e-9 else -math.inf
            return max(za,zb)
        for (x,y),(xx,yy) in zip(outline,outline[1:]+outline[:1]):
            za,zb=top(x,y),top(xx,yy)
            b.add_poly([(x,y,za),(x,y,za-.05),(xx,yy,zb-.05),(xx,yy,zb)],1.,M_ROOF)''')
needle='''        if i==0:hewn_log_wall(b,*r,0.,p.wall_height_m,1.,M_LOG,M_CHINK,skip=("bottom","top"))''';assert s.count(needle)==1
s=s.replace(needle,'''        log_face=i==0 or p.compound_wall_cladding == "log_courses"
        if log_face:hewn_log_wall(b,*r,0.,p.wall_height_m,1.,M_LOG,M_CHINK,skip=("bottom","top"))''')
needle='''kind=kind,frame_wall=i==1,relief=.026 if i else RELIEF_M)''';assert s.count(needle)==1
s=s.replace(needle,'''kind=kind,frame_wall=not log_face,relief=RELIEF_M if log_face else .026)''')
needle='''        if p.sign_mount == "sapling_pole":_sign_pole(b,p,ridge,p.worst_conf("sign","sign_mount"),p.conf("sign"),p.conf("sign_device"))''';assert s.count(needle)==1
s=s.replace(needle,'''        if p.sign_pole_set_out is not None:_posed_sign_pole(b,p)
        elif p.sign_mount == "sapling_pole":_sign_pole(b,p,ridge,p.worst_conf("sign","sign_mount"),p.conf("sign"),p.conf("sign_device"))''')
s+='''

def _log_course_gable(b,axis,plane,u0,u1,z0,z1,outward):
    """Triangle and horizontal course relief; every chosen dimension reconstructed.

    The inferred source category is log coursing, not literal measured wood/chink,
    exact colour, log section or joinery. Continue the existing340mm rhythm into
    the triangular face without changing the shared logwork default elsewhere.
    """
    mid=(u0+u1)/2;half=(u1-u0)/2;rise=z1-z0
    def xyz(u,z,proud=0):return (u,plane+outward*proud,z) if axis=="y" else (plane+outward*proud,u,z)
    def emit(pts,mat):
        # +Y front has decreasingU, +X front increasingU when seen from outside.
        reverse=(axis=="y") == (outward>0)
        b.add_poly(list(reversed(pts)) if reverse else pts,1.,mat)
    emit([xyz(u0,z0),xyz(u1,z0),xyz(mid,z1)],M_LOG)
    za=math.ceil(z0/.34)*.34
    while za<z1-.04:
        low=max(z0,za-.0275);high=min(z1,za+.0275)
        lohalf=half*(1-(low-z0)/rise);hihalf=half*(1-(high-z0)/rise)
        pts=[xyz(mid-lohalf,low,RELIEF_M),xyz(mid+lohalf,low,RELIEF_M),xyz(mid+hihalf,high,RELIEF_M),xyz(mid-hihalf,high,RELIEF_M)]
        emit(pts,M_CHINK)
        # Tiny bottom return makes a geometric relief rather than a painted line.
        emit([xyz(mid-lohalf,low),xyz(mid+lohalf,low),xyz(mid+lohalf,low,RELIEF_M),xyz(mid-lohalf,low,RELIEF_M)],M_CHINK)
        za+=.34


def _posed_sign_pole(b,p):
    """Source-bounded pose; all set-out, sections and device remain reconstructed."""
    (bx,by),(tx,ty,top),arm,(bw,bh),drop=p.sign_pole_set_out
    def add(a,z):return tuple(x+y for x,y in zip(a,z))
    def scale(a,s):return tuple(x*s for x in a)
    def dot(a,z):return sum(x*y for x,y in zip(a,z))
    def cross(a,z):return (a[1]*z[2]-a[2]*z[1],a[2]*z[0]-a[0]*z[2],a[0]*z[1]-a[1]*z[0])
    def unit(a):return scale(a,1/math.sqrt(dot(a,a)))
    def polept(z):return (bx+(tx-bx)*z/top,by+(ty-by)*z/top,z)
    def member(a,z,r,sides=8,mat=M_LOG):
        v=unit(tuple(y-x for x,y in zip(a,z)));q=unit(cross(v,(0,0,1) if abs(v[2])<.95 else (0,1,0)));w=cross(v,q)
        ring=[add(scale(q,r*math.cos(k*math.tau/sides)),scale(w,r*math.sin(k*math.tau/sides))) for k in range(sides)]
        for i in range(sides):j=(i+1)%sides;b.add_poly([add(a,ring[i]),add(a,ring[j]),add(z,ring[j]),add(z,ring[i])],1.,mat)
        b.add_poly([add(a,q) for q in reversed(ring)],1.,mat);b.add_poly([add(z,q) for q in ring],1.,mat)
    member(polept(-POLE_SET_M),polept(top*.56),POLE_BUTT_R)
    member(polept(top*.56),polept(top),POLE_HEAD_R)
    origin=polept(top-.4);e=unit(arm);up=unit(add((0,0,1),scale(e,-e[2])));normal=cross(e,up)
    member(add(origin,scale(e,-.35)),add(origin,arm),POLE_ARM_R,6)
    member(polept(top-1.6),add(origin,scale(arm,.45)),.035,6)
    centre=add(add(origin,scale(arm,.65)),scale(up,-drop))
    bt=SIGN_BOARD[2]
    def pt(u,v,n=0):return add(add(add(centre,scale(e,u)),scale(up,v)),scale(normal,n))
    # Slender reconstructed iron hangers; no literal hinge pattern is claimed.
    for u in (-bw*.34,bw*.34):member(pt(u,0),pt(u,drop+.035),.018,6,M_DARK)
    front=[pt(-bw/2,-bh,bt/2),pt(bw/2,-bh,bt/2),pt(bw/2,0,bt/2),pt(-bw/2,0,bt/2)]
    back=[pt(-bw/2,-bh,-bt/2),pt(bw/2,-bh,-bt/2),pt(bw/2,0,-bt/2),pt(-bw/2,0,-bt/2)]
    b.add_poly(front,1.,M_SIGN);b.add_poly(list(reversed(back)),1.,M_SIGN)
    for i in range(4):j=(i+1)%4;b.add_poly([back[i],back[j],front[j],front[i]],1.,M_SIGN)
    if p.sign_device == "wolf":
        dw=bw*DEVICE_FRACTION[0];dh=min(bh*DEVICE_FRACTION[1],dw/_WOLF_ASPECT);dw=dh*_WOLF_ASPECT
        uv=[(-dw/2+u*dw,-bh+(bh-dh)/2+v*dh) for u,v in _WOLF_UV]
        for side in (-1,1):
            pts=[pt(u,v,side*(bt/2+DEVICE_PROUD_M)) for u,v in uv]
            b.add_poly(pts if side>0 else list(reversed(pts)),1.,M_PAINT)
'''
p.write_text(s)
# One bounded record increment: preserve physical plan/world anchor/date.
p=H/'candidate/data/structures/wolf_point_tavern.json';r=json.loads(p.read_text());f=r['phases'][0]['form'];source='blanchard_shober_1867_wolf_point'
f['compound_wall_cladding']={'value':'log_courses','confidence':'inferred','sources':[source],'note':'T-2386 actual L render continuation: the governing 1867 NYPL sheet visibly shows horizontal log-like courses on both facing walls and through both gable triangles. Apply that pictured envelope to this bounded compound, without asserting that both hidden structures were solid log or overriding the text that the tavern was partly frame. Exact340mm course rhythm,55mm pale relief, notching, material tones and hidden faces are reconstructed kit choices, not source measurements or attested textures/colours.'}
f['compound_roof_overhang_m']={'value':.12,'confidence':'reconstructed','sources':[source],'note':'T-2386 continuation chooses120mm roof projection and50mm vertical slab/edge thickness to represent the thin visible eave/rake edge missing from the actual flush L render. These are bounded model dimensions, not source-measured metres. Existing pitch/ridge/wall plan/camera remain unchanged; actual roof-edge comparison is still required.'}
f['sign_pole_set_out']={'value':{'base_xy':[5.4,7.3],'head_xyz':[6.45,6.0,10.3],'arm_vector_xyz':[-1.32,1.63,.66],'board_wh':[1.6,1.05],'hanger_drop_m':.32},'confidence':'reconstructed','sources':[source],'note':'T-2386 continuation reconstructs a local sapling/sign pose from the governing sheet: pole base around[350,915]sourcepx, head[303,610], rising cross-arm toward[363,598], tilted hanging board around[322..378,611..652]. Same provisional square-pixel camera and5m building gauge; no historical metre or geographic coordinate follows from these picks. Place the base in the actual empty L courtyard, keep it and the shaft clear of the walls, lean screen-left, enlarge/tilt the board and add a slim supporting brace. All local coordinates, pole height/taper, arm reach/section, board dimensions/drop and iron pieces are chosen proxies; original wolf silhouette and neutral colours remain reconstructed. Base screen-height residual is deliberately retained instead of moving the pole tens of metres toward the camera to overfit the common-grade drawing. Existing sign occurrence/mount evidence and all world position uncertainty remain.'}
# Raise only the known right small light, retaining its width and height.
window=f['compound_parts']['value'][0]['front_opening'][1];assert window[1]=='window';window[4]=1.4;window[5]=2.0
f['compound_parts']['note']+=' T-2386 surface/pole continuation supersedes only the low-window proxy: raise that existing right light300mm to z1.4..2.0m, retaining width and station; its prior analytic centre was about9sourcepx low. This is a reconstructed local set-out change, not an attested sill height. The separate +X access consumer is now implemented by the entry/site followup. Roof/gable/cladding and pole changes are explicitly carried by the new opt-ins; full matching remains open.'
r['research_note']+=' T-2386 actual physical-L review found material topology/two-entry improvement but differs. This bounded continuation addresses facing horizontal wall/gable courses, roof edges, pole/sign pose and low right light, with reconstructed details and unchanged provisional camera; it does not close any image gate.'
p.write_text(json.dumps(r,indent=2)+'\n')
p=H/'candidate/data/sources/blanchard_shober_1867_wolf_point.json';src=json.loads(p.read_text());src['note']+=' T-2386 actual-render continuation reads horizontal coursing through both facing gables, a markedly screen-left-leaning sapling and rising cross-arm with a tilted suspended board. These visible categories can guide inferred form; no exact timber section, colour, texture, sign drawing, height, local station, overhang or metric/world coordinate is attested by the sheet. The new proposal retains the existing source credit/rights/date limits and requires another actual rendered comparison.';p.write_text(json.dumps(src,indent=2)+'\n')
patch=''
for rel in rels:patch+=''.join(difflib.unified_diff((H/'baseline'/rel).read_text().splitlines(True),(H/'candidate'/rel).read_text().splitlines(True),fromfile='a/chicago/4d/'+rel,tofile='b/chicago/4d/'+rel))
(H/'surface-pole-next.patch').write_text(patch)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(H/'inputs.json').write_text(json.dumps({'baseline_actual_run':str(R),'baseline_GLb_sha256':sha(H/'baseline/assets/gltf/wolf_point_tavern__log_frame_1828.glb'),'unchanged_camera_sha256':sha(H/'candidate/docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.json'),'files':[{'path':rel,'baseline_sha256':sha(H/'baseline'/rel),'candidate_sha256':sha(H/'candidate'/rel)} for rel in rels]},indent=2)+'\n')
print('Prepared4-file source-bounded continuation; no Blender/browser/export.')
