"""Verify the fixture's official output and decoded contract. Run after export only."""
from pathlib import Path
import json,sys,hashlib
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;R=Path(sys.argv[1]).resolve();label=sys.argv[2]
assert R.is_relative_to(H/'runs') and label in ['before','after']
sys.path.insert(0,str(R/'generators'))
import mesh_inputs
from glb_contract import read,summary
name='wolf_point_tavern__log_frame_1828.glb';asset=R/'assets/gltf'/name
assert set(p.name for p in (R/'assets/gltf').glob('*.glb'))=={name}
assert (R/'wrote.txt').read_text().splitlines()==[name]
manifest=json.loads((R/'assets/manifest.json').read_text());assert set(manifest['assets'])=={name};entry=manifest['assets'][name]
r=json.loads((R/'data/structures/wolf_point_tavern.json').read_text());ph=r['phases'][0]
assert entry['structure_id']==r['id'] and entry['phase_id']==ph['id'] and entry['bytes']==asset.stat().st_size
assert entry['inputs_sha256']==mesh_inputs.structure_inputs_sha(r,ph,r['archetype'])
doc,bin=read(asset);stats=summary(doc,bin)
assert stats['confidence_values'] and 1.0 in stats['confidence_values']
# Fresh pinned export should retain the actual source builder's triangle count.
raw=json.loads((H/'light-check.json').read_text())
assert stats['triangles']==raw['triangles'],(stats,raw)
out={'status':'passed_export_contract_essentials','label':label,'asset':name,'sha256':hashlib.sha256(asset.read_bytes()).hexdigest(),'producer':'actual copied generators/build.py -> emit.emit_structure; official structure_id__phase_id seed','inputs_sha256':entry['inputs_sha256'],'manifest_entry':entry,'decoded':stats,'raw_triangle_count_equal':True,'limits':'No canonical validator, web derivative, app performance, terrain/site/props clearance or visual acceptance.'}
(R/'export-contract.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
