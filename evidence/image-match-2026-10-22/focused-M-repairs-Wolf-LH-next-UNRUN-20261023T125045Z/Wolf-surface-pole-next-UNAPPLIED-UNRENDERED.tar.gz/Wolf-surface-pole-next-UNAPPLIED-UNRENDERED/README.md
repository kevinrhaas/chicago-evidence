# T-2386: horizontal gable courses and pictured pole pose

**FROZEN / UNAPPLIED / UNRENDERED next proposal.** Original T-2386 was normally claimed under `school_lighthouse_castle_bridge` in tickets commit `e7e32d34e8698ccd966a80948cea704d80fd7e2e`, without force. Its complete all-picture acceptance is unchanged. This package continues the closed actual L comparison, whose two source-image records are `differs`; it is neither a completion child nor a replacement for the original ticket.

## Actual baseline and bounded next increment

Baseline is the **actual** after master from `/tmp/chicago-next-model/T-2386-L-preview/runs/20261023-121002-482061`, SHA256 `91143e47202d0b705965cca35f62f05c0b510577befde36dccaf82d71e73a7d2`. That successful pinned export, full source/render comparison, bare render and record/producer inputs are copied here. Root and this agent directly inspected it: opposing gables, connected L and two entries improved, while the plain/clapboard left face, blank triangles, pole/sign pose and low right light remained conspicuous differences.

The four-file `surface-pole-next.patch` applies after the final log81 + physical-L + side-entry + centre-preserving-origin composition. It changes two log modules, Wolf Point's record and the existing shared source's appended note. No common module, other structure record, world position, physical polygon, date, camera, source credit or rights status changes.

- `compound_wall_cladding="log_courses"` is an explicit inferred envelope category, bounded to the existing elbow. Both facing walls and triangles receive horizontal courses. Existing partly-log/partly-frame evidence remains; a pictured course envelope does not identify hidden structural timber. The 340 mm rhythm, 55 mm pale bands, notches, palette and unseen face are reconstructed kit choices. No attested colour, measured timber section or photographic texture is claimed.
- `compound_roof_overhang_m=0.12` adds a small roof projection plus a chosen 50 mm edge/underside slab while keeping the ridge elevations, pitch and true L. The clipped external upper envelope remains single at the sampled joints. These are reconstructed edge dimensions. The source's full roof fabric, joinery and exact eaves still need actual comparison.
- `sign_pole_set_out` places a sapling in the actual empty courtyard, leaning screen-left, with a rising cross-arm, slim support brace, enlarged tilted suspended board and the existing reconstructed canine outline. Base [5.4,7.3], head [6.45,6.0,10.3], arm vector [-1.32,1.63,0.66] m, board 1.60×1.05 m and hanger drop 0.32 m are **reconstructed local choices** under the unchanged camera and 5 m gauge. New detail primitives emit confidence1.0, retaining the original occurrence/mount evidence in metadata. No metric or geographic station, literal historic board drawing or exact ironwork is asserted.
- Raise only the existing right small light by 300 mm, to z1.4–2.0 m, retaining width and along-wall station. No added window, annex, doorway count or camera adjustment.

These are three new **keyword-only**, disabled-by-default fields (`None`, `0.0`, `None`). Existing positional constructors and unsupported-combination guards remain. Controls are refused outside the bounded elbow; the explicit sapling pose additionally requires a stated sapling sign, finite bounded courtyard/head/arm/board dimensions and safe wall-side base/head coordinates. Existing +X side-entry descriptor is unchanged. Doors still use closed kit proxies; no false interior passage is introduced.

## Source, camera and expected residuals

The only source is the same **1867 NYPL Blanchard/Shober sheet, depicting1833**, credited in the source record and copied full image. Its printed US deposit/publication year supports public-domain status by age. The metadata-conflicted Newberry poster is not used. `source-feature-picks.json` and `source-pick-grid.png` document rough re-readings, not a new historical research unit. Approximate picks carry roughly3–6px uncertainty, sometimes worse around the obscured pole foot or board edges.

The camera is byte-identical to the closed actual L comparison: SHA256 `2a96283300029b94481286f5b246c2c9c53efb6f505ab140ddef543288a48f82`, square pixels, fixed6000px focal and the same reconstructed principal/eye/yaw/near plane. Its historical station/metric scale and upright common-grade drawing assumptions remain unresolved. The camera's original `solve.comparison` prose describes the first comparison pair; this continuation reuses its bytes unchanged, while this README and the new runner receipt identify the actual L baseline correctly.

Light projection of chosen pole base/head gives approximately [351.2,909.2] /[301.9,605.6] px against rough source [350,915] /[303,610]. The roughly6px foot-height residual is intentional: fitting the same ground plane exactly would move the post tens of metres toward the camera. Keep the post in the physical courtyard and admit the drawing/grade uncertainty. Window centre moves from about[487.35,867.81] to[487.35,859.03], against rough source[485,859]. These are numerical checks, not an actual new rendered match.

Actual raw projected bounds change from [152.32,689.65]–[519.10,921.61] to [146.70,596.54]–[519.10,921.48] px. The unchanged common detail crop [30,540,570,950] contains both. Main change at the top is the higher, relocated sign; the modest left extension is the roof edge. Full-source captures remain available and no crop conceals out-of-frame geometry.

## Verification and provenance obligations

`light-check.json` passes exact raw vertices/faces/material/confidence parity for all81 frozen final-log81 records with new controls off, and separately for the **existing actual L** with them off. New fields are keyword-only. Twelve invalid guards, actual record/source schemas, finite nondegenerate geometry, camera near/far/framing and109 upper-roof samples pass. New gable/roof/pole detail faces are reconstructed. The proposed mesh has2077vertices /1079triangles; no GLB export or viewer has been run for it.

`liberty-check.json` passes the actual copied parser/coverage routines, retaining the prior8+1+1 entries and adding one new entry with3precise Covers. The inferred wall category is not falsely claimed as a reconstructed attribute. Append `LIBERTY-APPEND.md` after the existing entries. Merge the3new research-prose paths in `note-reader-fragment.json` into the current name-pool `read.structures` list; retain all existing registrations and independent source edits. Normal source/grade/liberty/scene compilation remains owed.

`freshness-scope.json` records the complete81-asset family from the frozen final helper. Shared log builder bytes and resolved parameter fields change, so **all81 require the official coordinated refresh**, not one canonical Wolf Point bake or a hash restamp. Recompute the family scope against the parent's then-current tree/manifest before integration if it has changed. Raw default parity is not an official export/freshness proof or an app gate.

Patch dry-run (passed):

```sh
cd /tmp/chicago-next-model/T-2386-surface-pole-next/baseline
git apply --check -p3 ../surface-pole-next.patch
```

The patch carries normal repository paths `a/chicago/4d/...`; use normal stripping from the repo root when selectively integrating. Apply after the prior physical-L/side-entry/origin changes, preserving current independent Hogan, source-S, frame/fort and source-credit edits. Do not restore an old whole tree or layer the superseded parallel-gable trial.

## Prepared future actual comparison

Light-only dry runner, already passed:

```sh
python3 /tmp/chicago-next-model/T-2386-surface-pole-next/run_next.py
```

Only after a new explicit parent heavy-slot grant:

```sh
python3 /tmp/chicago-next-model/T-2386-surface-pole-next/run_next.py \
  --execute-after-root-grant \
  --grant-note 'Root granted the bounded Wolf Point surface/pole comparison'
```

This produces **one new actual pinned official `build.py` export and one new same-camera source/render capture**, reusing the closed actual L master/render as the exact before image. It does not rebuild or rewrite the before evidence. The absolute frozen build.py path avoids the earlier relative-path failure. Pinned cached archive/version, singleton manifest, real official asset-key seed (`wolf_point_tavern__log_frame_1828`), input hash, decoded GLB contract essentials, triangle count and source/camera/output hashes are checked. Capture uses an ephemeral server/browser and scoped process-group cleanup. No install, network fetch, live-checkout source read or canonical file write occurs.

Successful outputs go only to new `runs/<timestamp>/`: actual master/contracts/logs, full before/after comparisons, bare renders, common source-before-after detail and receipt. The new research match record stays `unreviewed` until actual direct inspection. Do not preassign matches or close T-2386. No execution is currently authorized by this prepared package alone; parent holds the heavy slot.

Runtime inputs are self-contained regular copies: candidate, exact actual baseline, source photo/metadata, copied parser/schema/81-record proof and viewer support. Only the existing Blender cache, installed Python/Pillow/Node/Chromium and `/workspace/node_modules` are shared runtime dependencies. `prepare.py` is one-time documentation and refuses to overwrite the candidate. `snapshot.json`, `inputs.json`, `checkpoint.json` and `ARTIFACTS.json` bind the frozen proposal; no heavy job is active.

## Limits carried forward

The new fixture is building-only on a neutral plane. It excludes neighbours, river/terrain, plants and town props; the four stale trade-goods instances inside the existing L remain a required normal regeneration, not a clearance exception. The unchanged centre-preserving world origin stays explicitly reconstructed. Local pole coordinates are not a new surveyed site; post terrain/contact/walker clearance is not certified by this proposal. The walker still collides with the solid concave footprint and cannot traverse an interior doorway.

Actual future comparison must judge the gable/body courses, pole/brace/board, roof edges and window directly. Closed doors, authentic materials/tones/textures, exact chinking/notching, sign device, hidden plan, date continuity, camera ambiguity and every other ticket picture remain required. If the parent accepts this visible increment, compose it **before the one official log81 integration refresh**, then regenerate affected scene/contact/entrance/yard props and run full source/liberty/freshness checks and desktop/mobile app QA. Original T-2386 stays unfinished until its complete image-gate acceptance is met.
