"""Portable comparison contact sheet; identical unwarped crop, no camera changes."""
from pathlib import Path
import sys,json
from PIL import Image,ImageDraw
H=Path(__file__).resolve().parent;run=Path(sys.argv[1]).resolve();assert run.is_relative_to(H/'runs')
box=(30,540,570,950);scale=2;w=(box[2]-box[0])*scale;h=(box[3]-box[1])*scale
sources=[('1867 NYPL sheet; depicts1833',run/'before/data/sources/assets/nypl-full.jpg'),('Before: actual physical L',run/'reviews/before/render.png'),('After: courses / pole proposal',run/'reviews/after/render.png')]
canvas=Image.new('RGB',(w*3+48,h+40),'white');draw=ImageDraw.Draw(canvas)
for i,(label,p) in enumerate(sources):
 im=Image.open(p).convert('RGB');assert im.size==(1920,1697)
 canvas.paste(im.crop(box).resize((w,h),Image.Resampling.NEAREST),(i*(w+24),40));draw.text((i*(w+24)+8,10),label,fill='black')
canvas.save(run/'reviews/source-before-after-detail.png')
(run/'reviews/detail-receipt.json').write_text(json.dumps({'crop_original_px':box,'integer_display_scale':scale,'interpolation':'nearest; source and both renders identical crop, no warp','not_a_camera_adjustment':True,'source_credit':'NYPL, I. N. Phelps Stokes Collection; Rufus Blanchard / Chas. Shober & Co.,1867. Governing cleared sheet, depicts1833.','limits':'Source context/land/river/people remain in source crop; renderer contains only tavern and common neutral plane. Full comparison files retained.'},indent=2)+'\n')
