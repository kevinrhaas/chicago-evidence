### L-wolfpoint-centre-preserving-origin-2386 — rebase a reconstructed model origin

**Building:** Wolf Point Tavern.
**Decision:** Changing the former12x7m placeholder to a physical7.2x10.1m L must not silently choose a new world centre or leave its primary worn apron in the river. Rebase the local origin by(-1.55E,-2.40N)m toE446993.85,N4637348.30 at the retained90degree bearing, keeping the old bbox centre exactly. This is an explicitly reconstructed model-origin/plan choice, not a coordinate derived from tier5picture pixels or a new survey. The old coarse source-supported west-bank/relative-order site and40m along/20m across uncertainty remain. Position confidence is reconstructed to expose the exact new choice; no source is promoted to metric control. Relative to the old rectangle the final bbox centre is unchanged, while the different concave outline and the ShowMe vertex-mean centre differ as recorded in geometry receipts.

The retained-origin L trial's primary apron enters the native1835river by about0.39m. With the centre-preserving rebase its body and primary apron clear that committed river outline by about3.69m and2.18m, with nearest stable/store separations about9.15m and9.60m. These are runtime model-coherence checks at the committed datum, not measured historic setbacks or newly verified1835banks. Keep the phase dates, bearing, source credits and historical uncertainty. Sidecar/contact/terrain/entrance/route and app checks must regenerate normally; no asset hash or derived grade is handwritten.

**Covers:** `wolf_point_tavern.log_frame_1828.position`.
**Ticket:** T-2386.
**Recorded:** 2026-10-23.
