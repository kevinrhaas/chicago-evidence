# Hogan 05f6 desktop 14–15 failure — exact diagnosis

**Run:** [39909852234](https://github.com/kevinrhaas/chicago/actions/runs/39909852234), job `120270070304`, exact head `05f6b886e5a31f17ec21e743f945cc4a89abc745`.

The smoke body completed: **160 passed, 1 failed**, with all 148 staged checks and 13 always-on checks executed. Its sole failure was the final **`desktop 1280x800: zero page errors`** assertion:

```
request failed (net::ERR_BLOCKED_BY_ORB)
https://kevinrhaas.github.io/chicago-images/prairie-1904/files/a18-rba-lowe-glessner-stable-18th-c1900-thumb.jpg
```

This was not a timeout, cancellation, Hogan model assertion, 1904 placement mismatch or draw-budget failure. Step 6 ran from 06:12:46 to 07:12:59 UTC, about 60m13s, and exited 1 normally after its complete summary. Boot reached ready in 59.8 s of its 240 s limit. The suite and vendor checks finished.

## Exact part and context

The error's bare `request failed (...)` prefix is emitted by the **original page** requestfailed listener at exact-head smoke line 1759. Part 14 reuses that page, navigates it to 1904, inspects Glessner and opens Photos / All N. The Glessner Photos assertion passed at **06:59:29 UTC**. The affected item is Glessner's Lowe-collection 18th Street/stable thumbnail, an existing 1904 collection picture. Part 15 uses a fresh context and prefixes its errors differently; the original page is parked on about:blank at its start. Thus the request belongs to the part 14 original-page/1904 image context, although the listener records no event timestamp and the failure was printed only at 07:12:59 after part 15. A precise request instant or failed response body cannot be reconstructed from these logs.

`smoke_renderer.exact-head.mjs` preserves the actual tested code. `smoke-versus-dev-parent.patch` shows that, versus dev parent `5135fb7674eea8cf5b140a7cf0c8bc208b0b1f4e`, the smoke change only restores T-3009's Indiana placement expectations. The picture and Photos loader code has no delta against that parent. The restored placement assertion passed. This does not resemble the earlier independent 1904 oracle regression.

GitHub REST currently confirms **the other nine runs at exactly 05f6 are success**, including desktop part 13 and mobile 14–15. The mobile 14–15 archive also records the Glessner Photos check and final zero-page-error assertion passing. It does not prove that mobile's lazy image loading requested this exact thumbnail. See `all-ten-current-statuses.json` and the retained mobile archive.

## Repository and deployed resource investigation

Read-only investigation at **08:13–08:16 UTC on 2026-10-23** found no persistent image/path/host defect:

- Local `/workspace/chicago-images/prairie-1904/files/a18-rba-lowe-glessner-stable-18th-c1900-thumb.jpg` is **36,122 bytes**, matching its MANIFEST and GitHub Contents API size/path. Its SHA256 is **`37dd1540e0f28a2907d0ee14e5fe2f64b815f6b1f8275618ba6c368956ff2c9d`**.
- The identical Pages URL returned **HTTP 200, `Content-Type: image/jpeg`, length 36,122, `Access-Control-Allow-Origin: *`**, and the exact same SHA256 on repeated ordinary/image-context requests. A tracked-redirect-handler request observed **no redirects**. The body is a valid **480 × 368 RGB JPEG**, verified by decoding; it is neither an HTML/error page nor an LFS pointer.
- GitHub raw-main returns the identical valid thumbnail. The corresponding full-image Pages URL also returns HTTP 200 with a JPEG body, 283,996 bytes.
- The file's last Git change is `8f4ba839c2766d0afcc26df99552bed2f6a5607e`, **2026-10-02**, and its response Last-Modified is 2026-10-20. The image path is present in the original image store, not introduced by Hogan.
- The Pages configuration names the expected repository URL/main root. No `AGENTS.md` exists at `/`, `/workspace`, the image repository root or within that image repository; the applicable 4d contract remains read. No repository changes were made.

Full response headers, exact bodies, decoded metadata and repository/API receipts are retained. The failed CI run has **zero uploaded artifacts**, no HAR, and no recorded failed-response MIME/status/body. Therefore **the exact server-side trigger for Chromium ORB is unknown**. A transient CDN/network/non-image response is consistent with the lone external failure and current valid resource, but is not proven by a historical response capture.

## Recommended action

**No code, path, asset or hosting PR is justified by the evidence currently available.** Keep the existing zero-page-error assertion strict; do not ignore ORB or allowlist this URL. Preserve this failed run as a failed run. Run the complete required 15-part coverage on the next combined head after its actual compile/publish, including a fresh desktop 14–15 result (or unchanged separate part 14/15 legs if parent already partitions that way). A new passing head is new evidence; it does not rewrite this failure.

If the same resource fails again, obtain its actual browser response/HAR or browser network diagnostic before proposing a host/data fix. No browser, renderer, workflow dispatch, rerun, assertion change, app write or ticket write was performed for this investigation.
