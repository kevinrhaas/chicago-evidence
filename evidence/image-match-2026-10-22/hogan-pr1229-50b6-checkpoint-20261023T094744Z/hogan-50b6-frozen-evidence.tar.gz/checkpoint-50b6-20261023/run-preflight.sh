#!/usr/bin/env bash
set -uo pipefail
hogan_root=/tmp/hogan-pr1229-integration
hogan_logs="$hogan_root/.hogan-recovery"
export PYTHONPATH="/workspace/shared/python${PYTHONPATH:+:$PYTHONPATH}"
export PATH="/workspace/shared/tools/usr/bin:$PATH"
export npm_config_cache=/workspace/shared/npm-cache
export CHECK_JOBS=4 C4D_GATE_REQUIRE_READERS=1
export CHECK_TIMINGS="$hogan_logs/second-full-check-timings.tsv"
export TMPDIR="$hogan_logs/tmp"
cd "$hogan_root/chicago/4d" || exit 2
: > "$CHECK_TIMINGS"
rm -f "$hogan_logs/second-full-preflight.exit"
./tools/preflight.sh > "$hogan_logs/second-full-preflight.log" 2>&1
hogan_exit=$?
printf '%s\n' "$hogan_exit" > "$hogan_logs/second-full-preflight.exit"
for hogan_item in preflight-check.log preflight-cl.log preflight-ids.log; do
 if [ -f "/tmp/$hogan_item" ]; then cp "/tmp/$hogan_item" "$hogan_logs/second-full-$hogan_item"; fi
done
exit "$hogan_exit"
