from pathlib import Path
import datetime,json,subprocess,sys,time
ROOT=Path(__file__).resolve().parent;repo='kevinrhaas/chicago';branch='steward/t2377-hogan-picture-match';head=sys.argv[1];workflow='chicago-4d-smoke.yml';planpath=ROOT/'smoke-runs-new-head.json'
def api(endpoint):return json.loads(subprocess.check_output(['gh','api',endpoint],text=True))
def remote_head():return api(f'repos/{repo}/git/ref/heads/{branch}')['object']['sha']
def listing():return api(f'repos/{repo}/actions/workflows/{workflow}/runs?branch={branch}&event=workflow_dispatch&per_page=100')['workflow_runs']
assert len(head)==40 and api(f'repos/{repo}/pulls/1229')['head']['sha']==head
assert remote_head()==head
jobs=[('desktop','13'),('mobile','13')]+[(v,s) for s in ['1-4','5-8','9-12','14-15'] for v in ['mobile','desktop']]
if planpath.exists():
 plan=json.loads(planpath.read_text());assert plan['head']==head
 assert not plan.get('pending_dispatch'),'Pending dispatch exists: inspect recorded before IDs/latest API runs before repeating anything.'
else:plan={'repository':repo,'pr':1229,'branch':branch,'head':head,'workflow_id':365585058,'scope':'All15parts at bothviewports; 1-4/5-8/9-12/13/14-15. Historical05f6ORBfailure preserved; no assertion/workflow/timeout changes. No PR merge authorized.','runs':[]}
def save():planpath.write_text(json.dumps(plan,indent=2)+'\n')
for viewport,stage in jobs:
 if any(r['viewport']==viewport and r['stage']==stage for r in plan['runs']):continue
 assert remote_head()==head,'PR source branch advanced: stop dispatching mixed-head coverage'
 before={r['id'] for r in listing()};payload={'ref':branch,'inputs':{'viewport':viewport,'stage':stage}}
 plan['pending_dispatch']={'viewport':viewport,'stage':stage,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before_ids':sorted(before)};save()
 subprocess.run(['gh','api','-X','POST',f'repos/{repo}/actions/workflows/{workflow}/dispatches','--input','-'],input=json.dumps(payload),text=True,check=True,capture_output=True)
 for attempt in range(20):
  matches=[r for r in listing() if r['id'] not in before and r['head_sha']==head]
  if matches:break
  time.sleep(2)
 assert len(matches)==1,f'Ambiguous dispatch receipt: {len(matches)}. Pending receipt remains on disk.'
 run=matches[0];parts=[13] if stage=='13' else list(range(int(stage.split('-')[0]),int(stage.split('-')[1])+1))
 row={'viewport':viewport,'stage':stage,'parts':parts,'id':run['id'],'url':run['html_url'],'head':run['head_sha']};plan['runs'].append(row);plan.pop('pending_dispatch');save();print(json.dumps(row),flush=True)
for v in ['mobile','desktop']:assert sorted(p for r in plan['runs'] if r['viewport']==v for p in r['parts'])==list(range(1,16))
assert len(plan['runs'])==10
plan['dispatch_complete']=True;save();print('Ten exact-head smoke runs dispatched. Await root CI/coverage review; do not merge PR.',flush=True)
