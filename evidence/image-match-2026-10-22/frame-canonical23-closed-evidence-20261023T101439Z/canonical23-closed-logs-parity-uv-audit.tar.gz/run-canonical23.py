import datetime, hashlib, json, os, subprocess
from pathlib import Path

app = Path('/workspace/chicago/chicago/4d')
out = Path('/tmp/frame-integration/canonical23')
out.mkdir(exist_ok=True)
env = dict(os.environ)
env.update(PYTHONPATH='/workspace/shared/python', npm_config_cache='/workspace/shared/npm-cache', CHECK_JOBS='4', C4D_GATE_REQUIRE_READERS='1')
env['PATH'] = '/workspace/shared/tools/usr/bin:' + env['PATH']
blender = '/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender'
assert hashlib.sha256(Path(blender).read_bytes()).hexdigest() == '5e15447670804c855fef6033ac9b8fd82696b762095becf0df79b1c2f8034397'
assert hashlib.sha256((Path(blender).parent.parent / 'blender-4.5.3-linux-x64.tar.xz').read_bytes()).hexdigest() == '975c58fcb244273838534bba771e64ad87739216b0f9b39a888531a49a72d845'
family = json.loads(Path('/tmp/chicago-next-model/T-3055-selective-integration/family-refresh.json').read_text())
ids = family['structure_ids']
assert len(ids) == len(set(ids)) == 23
def run(label, args):
    print(label, datetime.datetime.now(datetime.timezone.utc).isoformat(), flush=True)
    with (out / (label + '.log')).open('w') as log:
        result = subprocess.run(args, cwd=app, env=env, stdout=log, stderr=subprocess.STDOUT)
    (out / (label + '.exit')).write_text(str(result.returncode) + '\n')
    result.check_returncode()
run('build', [blender, '-b', '-noaudio', '--factory-startup', '--python', 'generators/build.py', '--', '--only', ','.join(ids), '--wrote', str(out / 'wrote.txt')])
wrote = (out / 'wrote.txt').read_text().splitlines()
assert len(wrote) == 23 and set(wrote) == {a['asset'] for a in family['assets']}, wrote
run('web', ['bash', 'tools/web_derivatives.sh', '--only', ','.join(wrote)])
run('liberties', ['python', 'tools/compile_liberties.py'])
run('entrances', ['python', 'tools/generate_entrances.py'])
run('tail', ['node', 'tools/rederive.mjs', '--tail', 'tools/compile_scene.py'])
run('workbook-parity', ['python', '/tmp/source-prerequisite/restore-workbook-parity.py', '--repo', '/workspace/chicago', '--receipt', str(out / 'workbook-parity.json')])
print('CANONICAL23 BUILD/DERIVE/TAIL PASS', flush=True)
