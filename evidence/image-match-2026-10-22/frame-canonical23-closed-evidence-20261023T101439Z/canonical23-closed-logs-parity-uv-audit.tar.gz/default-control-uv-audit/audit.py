"""Read-only semantic audit of the one non-byte-exact legacy family master."""
from pathlib import Path
import struct,json,hashlib,shutil
H=Path(__file__).resolve().parent;APP=Path('/workspace/chicago/chicago/4d');OLD=H.parent/'default-control-before.glb';CURRENT=APP/'assets/gltf/recon_1835_blk_washington_market_h3_04__inferred_1835.glb';sha=lambda b:hashlib.sha256(b).hexdigest()
def glb(data):
 magic,version,length=struct.unpack_from('<III',data);assert magic==0x46546c67 and version==2 and length==len(data);offset=12;chunks={}
 while offset<len(data):
  size,kind=struct.unpack_from('<II',data,offset);chunks[kind]={'data':data[offset+8:offset+8+size],'file_offset':offset+8};offset+=size+8
 return json.loads(chunks[0x4E4F534A]['data']),chunks
ob=OLD.read_bytes();nb=CURRENT.read_bytes();oj,oc=glb(ob);nj,nc=glb(nb);assert oj==nj;assert oc[0x4E4F534A]['data']==nc[0x4E4F534A]['data'];old=oc[0x004e4942]['data'];new=nc[0x004e4942]['data'];assert len(old)==len(new)
diffs=[i for i,(a,b) in enumerate(zip(old,new)) if a!=b];bv=oj['bufferViews'][oj['accessors'][28]['bufferView']];start=bv.get('byteOffset',0)+oj['accessors'][28].get('byteOffset',0);end=start+bv['byteLength'];assert diffs and all(start<=i<end for i in diffs)
changed=[]
for i in range(oj['accessors'][28]['count']):
 a=struct.unpack_from('<2f',old,start+8*i);b=struct.unpack_from('<2f',new,start+8*i)
 if a!=b:changed.append({'vertex':i,'old':a,'new':b,'delta':[b[j]-a[j] for j in range(2)]})
def accessor_values(index,blob):
 a=oj['accessors'][index];v=oj['bufferViews'][a['bufferView']];count={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];fmt={5126:'f',5123:'H',5125:'I',5121:'B'}[a['componentType']];size=struct.calcsize('<'+fmt)*count;stride=v.get('byteStride',size);base=v.get('byteOffset',0)+a.get('byteOffset',0);return [struct.unpack_from('<'+fmt*count,blob,base+i*stride) for i in range(a['count'])]
users=[]
for mi,m in enumerate(oj['meshes']):
 for pi,p in enumerate(m['primitives']):
  for semantic,index in p['attributes'].items():
   if index==28:
    mat=oj['materials'][p['material']];indices=[x[0] for x in accessor_values(p['indices'],old)];positions=accessor_values(p['attributes']['POSITION'],old);normals=accessor_values(p['attributes']['NORMAL'],old);conf=accessor_values(p['attributes']['_CONFIDENCE'],old)
    for c in changed:
     i=c['vertex'];c['position']=positions[i];c['normal']=normals[i];c['confidence']=conf[i][0];c['referenced_triangle_ordinals']=[j//3 for j in range(0,len(indices),3) if i in indices[j:j+3]]
    users.append({'mesh':mi,'mesh_name':m.get('name'),'primitive':pi,'semantic':semantic,'material_index':p['material'],'material':mat,'indices_accessor':p['indices'],'attributes':p['attributes'],'changed_vertices_all_referenced':all(c['referenced_triangle_ordinals'] for c in changed)})
assert len(users)==1 and users[0]['semantic']=='TEXCOORD_0' and users[0]['material']['name']=='trim'
differing_accessors=[i for i in range(len(oj['accessors'])) if accessor_values(i,old)!=accessor_values(i,new)]
assert differing_accessors==[28],differing_accessors
assert 'images' not in oj and 'textures' not in oj and not oj.get('extensionsUsed')
for name,data in [('old.glb',ob),('current.glb',nb)]:
 p=H/name
 if p.exists():assert p.read_bytes()==data
 else:p.write_bytes(data)
report={'old_input':str(OLD),'current_input':str(CURRENT),'old_sha256':sha(ob),'current_sha256':sha(nb),'old_bytes':len(ob),'current_bytes':len(nb),'file_differing_byte_count':sum(a!=b for a,b in zip(ob,nb)),'gltf_json_chunk_bytes_exact':True,'bin_differing_byte_count':len(diffs),'all_bin_differences_inside_accessor':28,'accessor':oj['accessors'][28],'buffer_view':bv,'bin_relative_changed_byte_offsets':diffs,'changed_float_count':sum(a!=b for c in changed for a,b in zip(c['old'],c['new'])),'changed_vertex_uv_pairs':len(changed),'max_absolute_uv_component_delta':max(abs(x) for c in changed for x in c['delta']),'changed_components':sorted(set('UV'[j] for c in changed for j,x in enumerate(c['delta']) if x)),'primitive_users':users,'changes':changed,'all_other_bin_bytes_exact':True,'independently_decoded_differing_accessors':differing_accessors,'all_positions_normals_indices_confidence_material_parameters_exact':True,'gltf_contains_images':False,'gltf_contains_textures':False,'gltf_uses_extensions':False,'canonical_writes':False,'blender_browser_or_rerender_performed':False,'interpretation':'One untextured trim primitive has different packed TEXCOORD_0 values. Standard glTF PBR has no texture input reading these UVs. Current web roof/wall relief also excludes trim. This is UV-only unwrap/packing variation with no geometry/material/confidence change; no claim of 20 legacy byte-exact outputs or full reproduction of Blender internal cause is made.'}
(H/'audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['old_sha256','current_sha256','old_bytes','current_bytes','file_differing_byte_count','changed_float_count','changed_vertex_uv_pairs','max_absolute_uv_component_delta','changed_components','all_other_bin_bytes_exact']},indent=2));print(json.dumps(users,indent=2))
