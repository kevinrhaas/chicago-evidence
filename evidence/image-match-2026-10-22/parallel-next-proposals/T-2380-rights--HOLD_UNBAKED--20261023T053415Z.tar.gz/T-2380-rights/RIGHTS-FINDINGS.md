# T-2380 rights investigation — HOLD UNBAKED

Independent research found a matching copy older than the 1947 Chicago Tribune reproduction, but did not establish a reusable-rights basis for this specific artwork. The current geometric proposal and source record in `../T-2380-next/` are explicitly held; `rights_status` is `check_required`. No repository file, asset, ticket state or published source inventory was changed.

## Actual earlier catalogue and picture

Catalogue read: https://calisphere.org/item/ark:/13030/kt438nc0n9/ (the corresponding OAC URL redirects to it). Retained as `calisphere.html`, `calisphere.txt` and `oac.html`.

- Institution: UCR/California Museum of Photography, Keystone-Mast Collection.
- Identifier: 1996.0009.L54254, ark:/13030/kt438nc0n9.
- Title: “Cook County’s first Jail as it was in 1836 - Located on the Northwest Corner of the Public Square, Chicago.”
- Creator: Francis Dare. This is the catalogue attribution for the photographic copy; it does not identify the original engraving artist.
- Date Created and/or Issued: September 19, 1930.
- Publication Information: Keystone View Company.
- Format: Keystone one-sided photo print, 7.18 in. ×4.18 in.
- Required credit: “Keystone-Mast Collection, UCR/California Museum of Photography, University of California at Riverside.”

The catalogue surrogate was downloaded and actually viewed (`calisphere-jail.jpg`, with a smaller full-frame `calisphere-jail-full.jpg`). The artwork visibly matches the ticket's detailed jail image: identical tall rear jail, keeper's roof, palisade, oxen, figures, dog and birds. The catalogue image preserves its historical caption below the artwork and lacks the later newspaper header. This is visual identification, not a formal pixel-match result.

The rights statement requests contacting UCR for copyright-status information and warns that some collection materials may be protected. It does not affirm public-domain status or supply a reuse licence for this item. We did not contact anyone.

## What this resolves, and what it does not

The identical copy catalogued in1930 establishes that this artwork existed before1947. Thus the 1947 newspaper credit alone cannot date the original artwork. It does not establish an original nineteenth-century publication, nor even unambiguously establish public distribution of the1930copy: the catalogue combines creation and issuance in a single date field. A US work actually published in1930 would have completed its95-year term at the end of2025, but that publication prerequisite remains unverified here. A creation date alone is insufficient. The institutional caution is not itself proof of copyright; neither is the inherited inventory's public-domain assertion proof of expiry.

Therefore do not derive or bake the preserved core-silhouette proposal from this source until an original publication, actual1930publication, affirmative clearance or another adequate basis is established. Do not apply the archived pre-rights-review patch. No user clearance for this jail artwork was found in the session; school/Tremont clearance is not extended to it.

## Independent research bounds

Retained Internet Archive OCR/metadata searches include Andreas's History of Chicago volume1(1884), Andreas's History of Cook County(1884), Currey's Chicago history volume1(1912), and Hurlbut's Chicago Antiquities(1881). Searches used jail, first-jail, courthouse, public-square and engraving/caption terms. Illustration lists located courthouse-and-jail material, but no identified matching detailed jail original. OCR cannot prove absence; book-page images were not exhaustively reviewed. Andreas's jail construction/addition prose was found in OCR, but has not been read on the actual page image and is not used here as new attested chronology.

Retained web searches include exact image title, Francis Dare/Keystone, first-jail history, Currey, old engraving and publication terms. DuckDuckGo supplied the Calisphere lead. Google yielded a script/redirect page; Bing returned irrelevant results. These failed search pages are retained for audit, not represented as corroboration or absence proof.

## Current package and next bounded step

`../T-2380-next/T-2380-next.patch` preserves the proposed existing-parameter core change (4.2m walls,32-degree gable, reconstructed) plus the corrected `check_required` source. Its light check passes structure/source schema, parameter parsing, unchanged footprint/place/date/use/doors, no stockade/keeper-house additions and the explicit rights hold. No actual mesh export, browser comparison, bake, matched verdict or closure was done.

A useful next independent lead is the Keystone negative/print record or a dated Keystone publication/catalogue identifying this copy as issued in1930; another is page-level review of earlier Chicago illustration books. Those are research leads, not established rights facts. Parent can continue the other approved ticket work while this single source-dependent proposal remains held.
