#!/usr/bin/env bash
# PREPARED ONLY. Parent permits browser after isolated export review.
set -euo pipefail
log_package="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
log_run="$(cat "$log_package/latest-run.txt")"
test -f "$log_run/export-verification.json"
for log_kind in baseline proposed; do
  cd "$log_run/$log_kind"
  for log_camera in docs/RESEARCH/log-combined-review/*.json; do
    case "$log_camera" in *.match.json) continue;; esac
    log_name="$(basename "$log_camera" .json)"
    PW_EXECUTABLE="${PW_EXECUTABLE:-/usr/bin/chromium}" node tools/photo_match.mjs "$log_camera" --out "$log_run/reviews/$log_kind" > "$log_run/$log_kind-$log_name.log" 2>&1
  done
done
