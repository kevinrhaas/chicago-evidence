# Combined log-family fixture — isolated, unapplied

Exactly five original tickets: **T-2372, T-2374, T-2381, T-2382 and T-2386**.
Separate source packages remain unchanged. No repository files, manifests, assets,
ticket state or branches were edited. No Blender, browser or heavy gate was run.

`log-combined.patch` is an apply-checked cumulative **11-file diff** against
`input-snapshot.json`. `candidate/` contains the complete proposed files.
`prepare.py` composes shared code through explicit three-way merges and rejects
unknown conflicts; it does not apply anything. Original proposal inputs are:

| Ticket | Preserved package | Visible increment |
|---|---|---|
| T-2372 | `../T-2372` and `../T-2372-roof` | Higher/larger sash, broader doorway, explicit local-Y entrance-gable ridge |
| T-2374 | `../T-2374` | Existing footprint built as five log rooms instead of its bounding box; intersecting gables |
| T-2381 | `../T-2381` | Log downstairs, vertical boards upstairs/gable on Miller's tall block |
| T-2382 | `../T-2382` and `../T-2382-next` | Upright bare sash and a small roof-piercing head near the annex's free end |
| T-2386 | `../T-2386` | Small roof head replaces the exterior end stack |

The combined fixture intentionally omits Carpenter's optional chimney-material
selector. Its stick-and-clay chimney finish remains an explicit mismatch, not a
false claim of reproduced masonry. No school-shore subject identification is made.

## Shared code and evidence integration

Three new parameters are all keyword-only, preserving the complete old positional
constructor signature: `compound_parts=()`, `roof_ridge_axis=None`, and
`frame_addition_cladding="clapboard"`. Empty/default options preserve legacy output.
Explicit core axis rejects compound_parts because every compound part owns its
own axis. The roof, loft, core gable classification and chimney use one resolved
axis; existing unsupported shed/hip/end-opening/lean-to combinations reject.

Cobweb's stepped facade metadata reports the actual projecting centre and its
door, not an imaginary 13 m flat front. Compound rectangles must be connected,
non-overlapping and partition the recorded orthogonal footprint exactly. Its roof
intersections are overlapping surfaces, not detailed boolean valleys: inspect
buried caps, lighting, notches and flashing in the actual export. New compound
geometry has reconstructed confidence. Miller's pictured finish faces retain
inferred confidence; chosen narrow board-edge sections/rhythm carry 1.0, following
the parent's explicit ruling. No shared materials/mesh/emit registry code changes.

The sole new source identity `blanchard_shober_1867_wolf_point` retains the Wolf
Point author's exact citation, publisher/lithographer credit, public-domain age
reasoning and retrospective limits, and incorporates the Miller author's explicit
right-building reading. It distinguishes the 1833 depicted date from publication
in 1867. School source attribution, URL, rights_checked and project-specific owner
clearance are preserved verbatim; only declared current reference use expands to
the roof. No public-domain or copyright-holder permission claim is added.

All append-only liberties are retained as separate `liberty-fragments/` and
combined in the candidate LIBERTIES. The earlier Carpenter generic-stack caution
is explicitly superseded by the following stack increment. No coordinate,
footprint polygon, building date, use or occupancy changes. Cobweb's uncertain
1835 survival and application of its 1831 form back to 1820 remain explicit.

`proposed-grade-rulings.json` is **separate from the cumulative patch**, for parent
review/integration. Actual full-building pictures support pictured rulings for
Miller, Wolf Point and the annex under its existing Beaubien-caption identity.
Their current sidecars incorrectly still say no picture found. This proposal does
not attest exact dimensions, scene-date appearance or completed matching. Keep
school and Cobweb inferred pending identity/subject resolution; never enroll the
research cameras just to obtain an attested grade. Official sidecars/grades must
be derived in the final integration, not copied from these placement-only fixtures.

## Lightweight checks completed

```sh
python /tmp/chicago-next-model/log-combined/prepare.py
python /tmp/chicago-next-model/log-combined/focused_check.py
python /tmp/chicago-next-model/log-combined/prepare_cameras.py
git -C /workspace/chicago apply --check /tmp/chicago-next-model/log-combined/log-combined.patch
```

`combined-focused-check.json` records complete actual raw builder comparisons:
all **81 legacy phase** parameters, vertices, faces, confidence streams, material
indices/specifications and named opening materials remain exactly identical with
new options absent. It also verifies old constructor signature order, schemas,
source rights/credits, five actual geometry increments, finite/nondegenerate
faces, specific opt-in parameters, stepped openings and **14 invalid combined
guards**. This uses real raw MeshBuilder/logwork/opening methods, replacing only
Blender material/object emission. It is not a GLB or shading test.

The isolated fixture copies were prepared successfully and checked without a
build/browser. Each has 81 affected log masters plus the unchanged Sauganash
context master, all regular file copies. Five camera JSON/photo paths resolve;
the annex review resolves both scene members through the real Node group helper.
Actual mesh_inputs calculations confirm all81 recipe hashes change. Results are
in `fixture-light-checks.json`; `latest-run.txt` identifies the prepared copies.
Input/candidate drift is refused before future fixture creation.

The Miller/Carpenter author independently reviewed the merged implementation,
source and exact data adoption and requested no corrections. The school/axis
author independently checked shared imports/confidence, all ridge call sites,
keyword-only fields and unsupported-combination guards and found no new issue.
Both were read-only targeted reviews, not export or full-test validation.

## Full freshness scope and Hogan dependency

`freshness-scope.json` enumerates every **81 registered log_dwelling master**,
phase, baseline asset SHA and intended-change flag; `structure-ids.txt` is the
exact complete batch selection across all available scenes. Five masters change
intentionally; the other **76** should preserve exported geometry/bytes. Shared
builder bytes and resolved dataclass fields change all recipes, even with defaults
disabled. Never blind-restamp old manifests. Real pinned family export plus web
derivatives and generated registries must validate freshness.

**Hogan PR must merge before official log-family integration.** This fixture
reads the parent's current refined Hogan record/GLB and preserves its raw output,
but changes no Hogan data. The input snapshot records those bytes. Refresh and
re-review the fixture against the merged parent checkout before official use.
Do not use an older main snapshot to overwrite Hogan's latest openings, stack,
confidence or source/grade work. Prepared runs remain isolated evidence only.

## Prepared export/review runners — not run

Only run after the parent releases the quiet preflight/resource reservation:

```sh
bash /tmp/chicago-next-model/log-combined/run-export.sh
bash /tmp/chicago-next-model/log-combined/run-reviews.sh
```

Export creates a NEW timestamped `runs/` fixture, validates cached Blender archive
SHA against the copied pin and the binary's exact 4.5.3 version, then builds the
81-ID batch once with all scenes available. No download/install, verification
bypass or repository path mutation. Native exporter failure status is preserved;
stdout/stderr go to `export.log`. `verify_exports.py` checks the exact written
set and recomputed recipes and refuses unexpected byte drift among the 76 defaults.
Selected alternate versions are currently absent; preparation refuses if present
so they cannot silently escape the batch scope.

Review uses identical copied before/after cameras/photos and sequential browsers,
with `/usr/bin/chromium` and the existing working `/workspace/node_modules` package
tree. Each ephemeral photo-match server closes with its browser. No shared
publisher or app server is used. Only Node package resolution is symlinked;
generators, data, GLBs, manifests and pictures are regular copies under `/tmp`.

Five review cameras are provisional, never solved/matches:

- School reuses the actually rendered T-3053 baseline pose; identity, perspective,
  proportions, open door and covering remain unresolved.
- Cobweb aims near the tiny alleged agency house; positive subject identification
  is unresolved. It is an unrendered framing estimate, not a five-part elevation.
- Miller and Wolf Point start from reconstructed oblique frames around the two
  buildings on the inspected NYPL sheet. No optimised landmark fit or residual is
  claimed. Their first actual renders may require camera refinement.
- Carpenter uses the prior provisional hotel anchor pose with the real annex
  scene placement added. It does not recalibrate their relationship. The context
  hotel mesh is current committed baseline, not the separate pending frame-family
  proposal, and is not a sixth changed ticket in this package.

Photo-match creates unreviewed records only inside disposable research fixtures.
The shared flat grade plane is not final terrain. Inspect actual before/after
images and record `differs` with concrete remaining differences; do not publish a
matches verdict or copy these cameras to data/reference_views on these checks.

## Official integration still required

After Hogan merge: coordinate branch/ticket ownership; resolve parent code/data
drift; review source/grade rulings; export under pinned Blender; inspect roof
junctions, logs, openings, stack embedding, normals, materials and all five actual
paired pictures; refine unrendered cameras as needed; derive compressed meshes;
compile liberty/source/licence/scene/grade metadata, entrances and signage; inspect
credited source cards and visible changes on desktop/mobile; measure material,
triangle/draw/performance costs; run normal full checks and preflight before a
reviewable PR. Add an honest incremental changelog/status then. Every original
image-match ticket remains open: their full accepted comparison is unfinished.


## Actual run completed — 2026-10-23

Parent released the resource reservation. The existing copied snapshot was checked
against saved hashes without reading the live checkout, then run-frozen-export.sh
built all 81 masters with the verified pinned binary. All 10 same-camera committed
before/proposed after captures completed, browsers closed, and were inspected.
All research verdicts are now differs. See the run's reviews/README.md,
visual-review.json and decoded-export-review.json; these supersede earlier
“prepared only” execution status while all release limitations above still apply.

75 of 76 default assets are committed-byte-identical. Kinzie stable has only three
UV accessor changes, all JSON/non-UV/index/material/confidence identical. A fresh
original-code isolated control export exactly equals its proposed GLB. The strict
original verifier remains failed on committed UV-byte drift; it was not weakened.
All 81 actual GLBs passed decoded contract essentials. No official hashes were
restamped. Source/before/after detail crops show each increment and remaining
differences; Miller's lower logs visibly improve but its upper vertical edge
treatment is effectively invisible and requires refinement. Cobweb implements
the text plan; its tiny picture is not positively identified or matched. School
gable/higher lights and Carpenter/Wolf Point roof-head categories improve while
their full pictured forms remain discrepant. No derivatives, full gate, app/card
review, terrain check or accepted match was run. CPU/browser slot returned to
the frame-family agent after closure; no additional heavy job remains.
