"""Actual raw builder comparison with Blender emission replaced by a recorder."""
from pathlib import Path
from types import ModuleType
from dataclasses import asdict, replace
import ast, copy, hashlib, json, math, sys
sys.dont_write_bytecode=True
root=Path('/workspace/chicago/chicago/4d'); out=Path('/tmp/chicago-next-model/log-combined')
sys.path.insert(0,str(root/'generators'))
def load(name,text,path=None):
 m=ModuleType(name); m.__file__=str(path or out/(name+'.py'));sys.modules[name]=m
 exec(compile(text,str(m.__file__),'exec'),m.__dict__);return m
# Keep the real raw MeshBuilder methods. Only bpy-dependent material/object
# creation is replaced. Shared logwork and openings are the current real kits.
tree=ast.parse((root/'generators/common/mesh.py').read_text())
cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='MeshBuilder')
cls=copy.deepcopy(cls)
cls.body=[n for n in cls.body if not isinstance(n,ast.FunctionDef) or n.name!='to_object']
ns={'math':math};exec(compile(ast.fix_missing_locations(ast.Module(body=[cls],type_ignores=[])),'raw_mesh','exec'),ns)
C=ns['MeshBuilder']
def to_object(self,materials=None):self.materials=materials;return self
C.to_object=to_object
mesh=ModuleType('common.mesh');mesh.MeshBuilder=C
mesh.simple_material=lambda *a,**k:(a,k)
sys.modules['common.mesh']=mesh
old=load('t2374_old_params',(root/'generators/archetypes/log_dwelling_params.py').read_text())
new=load('t2374_new_params',(out/'candidate/chicago/4d/generators/archetypes/log_dwelling_params.py').read_text())
sys.modules['archetypes.log_dwelling_params']=old
before=load('t2374_old_builder',(root/'generators/archetypes/log_dwelling.py').read_text(),root/'generators/archetypes/log_dwelling.py')
sys.modules['archetypes.log_dwelling_params']=new
after=load('t2374_new_builder',(out/'candidate/chicago/4d/generators/archetypes/log_dwelling.py').read_text(),root/'generators/archetypes/log_dwelling.py')
def raw(b):return (b.verts,b.faces,b.conf,b.mat_index,b.named,b.materials)
import inspect,jsonschema
meta=json.loads((out/'input-snapshot.json').read_text())
for rel,want in meta['input_sha256'].items():
 p=Path('/workspace/chicago')/rel
 assert (hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None)==want,rel+' drifted'
for rel,want in meta['candidate_sha256'].items():
 assert hashlib.sha256((out/'candidate'/rel).read_bytes()).hexdigest()==want,'candidate drift: '+rel
old_sig=inspect.signature(old.LogDwellingParams);new_sig=inspect.signature(new.LogDwellingParams)
added={'compound_parts','roof_ridge_axis','frame_addition_cladding'}
assert [v for k,v in new_sig.parameters.items() if k not in added]==list(old_sig.parameters.values())
assert all(new_sig.parameters[k].kind==inspect.Parameter.KEYWORD_ONLY for k in added)
count=0;old_records={};old_raw={}
for path in sorted((root/'data/structures').glob('*.json')):
 r=json.loads(path.read_text())
 if r.get('archetype')!='log_dwelling':continue
 old_records[r['id']]=r
 for ph in r['phases']:
  a,b=old.from_phase(ph,r),new.from_phase(ph,r)
  data=asdict(b)
  assert data.pop('compound_parts')==()
  assert data.pop('roof_ridge_axis') is None
  assert data.pop('frame_addition_cladding')=='clapboard'
  assert data==asdict(a),(r['id'],ph['id'],'params')
  x,y=before.build(a,'same'),after.build(b,'same')
  assert raw(x)==raw(y),(r['id'],ph['id'],'raw geometry/material/confidence')
  old_raw[(r['id'],ph['id'])]=x;count+=1
scope=json.loads((out/'freshness-scope.json').read_text())
assert count==len(scope['assets'])==81
assert len(scope['original_tickets'])==5
schema=json.loads((root/'data/structures.schema.json').read_text())
source_schema=json.loads((root/'data/source.schema.json').read_text())
for path in (out/'candidate/chicago/4d/data/sources').glob('*.json'):
 jsonschema.validate(json.loads(path.read_text()),source_schema)
resolved={};rows=[];invalid=[]
for sid in scope['intended_changed_geometry']:
 r=json.loads((out/f'candidate/chicago/4d/data/structures/{sid}.json').read_text())
 jsonschema.validate(r,schema)
 for a,b in zip(old_records[sid]['phases'],r['phases']):
  for key in ['position','footprint','documented_range','existence','use','occupants']:
   if key=='footprint':assert a[key]['polygon']==b[key]['polygon']
   else:assert a.get(key)==b.get(key),(sid,key)
  p=new.from_phase(b,r);resolved[sid]=p;detail=after.build(p,'detail')
  baseline=old_raw[(sid,b['id'])];assert raw(detail)!=raw(baseline),sid+' has no actual geometry increment'
  assert all(math.isfinite(v) for pt in detail.verts for v in pt)
  for face in detail.faces:
   pts=[detail.verts[i] for i in face];normal=[0.,0.,0.]
   for a,b in zip(pts,pts[1:]+pts[:1]):
    normal[0]+=(a[1]-b[1])*(a[2]+b[2]);normal[1]+=(a[2]-b[2])*(a[0]+b[0]);normal[2]+=(a[0]-b[0])*(a[1]+b[1])
   assert sum(v*v for v in normal)>1e-16,(sid,'degenerate face')
  def summary(obj):return dict(faces=len(obj.faces),fan_triangles=sum(len(f)-2 for f in obj.faces),min=[min(v[i] for v in obj.verts) for i in range(3)],max=[max(v[i] for v in obj.verts) for i in range(3)],confidence=sorted(set(obj.conf)),named_materials=list(obj.named))
  rows.append(dict(structure_id=sid,before=summary(baseline),after=summary(detail)))
school=resolved['chappel_infant_school'];castle=resolved['cobweb_castle'];miller=resolved['miller_house'];carp=resolved['philo_carpenter_log_shop'];wolf=resolved['wolf_point_tavern']
assert school.roof_ridge_axis=='y' and new.resolved_core_ridge_axis(school)=='y'
assert school.window_w_m==.85 and school.window_h_m==.85 and school.door_w_m==1.2
assert len(castle.compound_parts)==5 and set(after.build(castle,'x').conf)=={1.0}
assert (new.front_wall(castle)['u0'],new.front_wall(castle)['u1'])==(4.,9.)
assert [entry[0] for entry in new.compound_front_rects(castle)]==[9.,8.,8.]
assert miller.frame_addition_cladding=='log_lower_vertical_upper'
assert carp.chimney_ridge_at==(.8,) and carp.ridge_stack_w_m==.55 and carp.ridge_stack_head_m==.65
assert carp.window_w_m==.7 and carp.window_h_m==1.4 and not hasattr(carp,'chimney_material')
assert wolf.chimney_ridge_at==(.58,) and wolf.ridge_stack_w_m==.45 and wolf.ridge_stack_head_m==.5
for q in [replace(castle,roof_ridge_axis='x'),replace(castle,roof_ridge_axis='y'),replace(castle,piazza=True),replace(castle,stories=2),replace(castle,compound_parts=castle.compound_parts+(castle.compound_parts[0],)),replace(school,roof_ridge_axis='z'),replace(school,roof_type='shed'),replace(school,lean_to=True),replace(school,hip_end='min'),replace(school,end_openings=(('+x','window',.5,None),)),replace(school,chimney_end='max'),replace(miller,frame_addition=False),replace(miller,frame_addition_stories=1),replace(miller,frame_addition_cladding='unknown')]:
 try:q.validate()
 except new.ParamError:invalid.append(True)
 else:raise AssertionError('unsupported combined guard accepted')
# Actual helper checks: lower log zone, existing finish-face grade, chosen edge grade.
class Calls:
 def __init__(self):self.calls=[]
 def add_box(self,*a,**k):self.calls.append(('box',a,k))
 def add_poly(self,*a,**k):self.calls.append(('poly',a,k))
 def add_gable_roof(self,*a,**k):self.calls.append(('roof',a,k));return a[4]+((a[3]-a[1]+.5)/2)*math.tan(math.radians(a[5]))
c=Calls();after._vertical_addition_gables(c,0,0,10,6,5.2,7.7,.5)
assert {a[1] for kind,a,kw in c.calls if kind=='poly'}=={.5}
assert {a[6] for kind,a,kw in c.calls if kind=='box'}=={1.0}
c=Calls();after._vertical_addition_edges(c,0,0,10,6,2.6,5.2,1.0)
assert {a[6] for kind,a,kw in c.calls if kind=='box'}=={1.0}
source=json.loads((out/'candidate/chicago/4d/data/sources/blanchard_shober_1867_wolf_point.json').read_text())
assert source['date']=='1867' and source['describes_date']=='1833' and source['rights_status']=='public_domain' and 'Miller' in source['note']
source=json.loads((out/'candidate/chicago/4d/data/sources/eliza_chappel_school_shore_view.json').read_text())
original=json.loads((root/'data/sources/eliza_chappel_school_shore_view.json').read_text())
for key in ['rights_status','rights_checked','rights_note','citation','verified','url']:
 assert source.get(key)==original.get(key),key+' school clearance changed'
report=dict(status='passed',legacy_raw_phase_geometry_material_confidence_identical=count,legacy_constructor_signature_preserved=True,invalid_combined_guards_rejected=len(invalid),original_tickets=scope['original_tickets'],intended_geometry_changes=rows,limits='Pure Python actual raw builder checks, no Blender/export, derivative, browser, accepted camera, matches, scene budgets or full gate.')
(out/'combined-focused-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='intended_geometry_changes'},indent=2))
