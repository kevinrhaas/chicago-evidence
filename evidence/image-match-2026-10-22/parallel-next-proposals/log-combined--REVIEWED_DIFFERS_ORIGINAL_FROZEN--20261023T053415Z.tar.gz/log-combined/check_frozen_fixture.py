"""Validate only isolated copies against saved metadata; never read live checkout."""
from pathlib import Path
import hashlib,json,sys
out=Path(__file__).resolve().parent;run=Path(sys.argv[1]).resolve()
assert run.is_relative_to(out/'runs')
meta=json.loads((out/'input-snapshot.json').read_text());scope=json.loads((run/'scope.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows={}
for label in ['baseline','proposed']:
 root=run/label
 for path in root.rglob('*'):
  if path.is_symlink():assert path==root/'node_modules',path
 for row in scope['assets']:
  asset=root/'assets/gltf'/row['asset'];assert asset.is_file() and not asset.is_symlink()
  assert sha(asset)==row['baseline_sha256'],str(asset)+' not an untouched baseline copy'
  rel=f"chicago/4d/data/structures/{row['structure_id']}.json"
  expected=meta['candidate_sha256'].get(rel) if label=='proposed' else None
  expected=expected or meta['input_sha256'][rel]
  assert sha(root/rel.removeprefix('chicago/4d/'))==expected,rel
 for rel,want in meta['input_sha256'].items():
  if not rel.startswith('chicago/4d/generators/'):continue
  expected=meta['candidate_sha256'].get(rel,want) if label=='proposed' else want
  assert sha(root/rel.removeprefix('chicago/4d/'))==expected,rel
 cams=list((root/'docs/RESEARCH/log-combined-review').glob('*.json'));assert len(cams)==5
 for cam in cams:
  photo=(cam.parent/json.loads(cam.read_text())['photo']).resolve()
  assert photo.is_relative_to(root) and photo.is_file() and not photo.is_symlink()
 rows[label]={str(p.relative_to(root)):sha(p) for p in sorted(root.rglob('*')) if p.is_file() and 'node_modules' not in p.relative_to(root).parts and '__pycache__' not in p.parts}
(run/'frozen-integrity-before.json').write_text(json.dumps(dict(status='passed',files=rows,live_checkout_read=False),indent=2)+'\n')
print('Frozen copies verified: 81 baseline masters each, full generator/data snapshots, 5 copied-photo cameras; no live checkout reads.')
