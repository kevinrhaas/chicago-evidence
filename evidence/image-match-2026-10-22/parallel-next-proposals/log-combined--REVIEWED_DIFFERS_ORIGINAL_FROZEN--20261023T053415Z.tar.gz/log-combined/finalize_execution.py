from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent;run=Path((p/'latest-run.txt').read_text().strip())
c=json.loads((p/'checkpoint.json').read_text())
c.update(status='isolated_export_and_ten_comparisons_reviewed_all_differs',actual_export_executed=True,actual_browser_executed=True,live_checkout_reads_after_frozen_start=False,all_jobs_closed=True,exported_masters=81,default_committed_byte_parity='75/76; remaining stable has only three UV accessor changes; fresh original-code stable control byte-identical to proposed',decoded_glb_contracts='passed 81',actual_reviews=str(run/'visual-review.json'),next_commands=['Official integration only after Hogan merge and parent source/grade/visual review','Refine Miller visible upper-board treatment; retain all five differs verdicts','Close/oblique Cobweb tail/junction check remains before release'])
(p/'checkpoint.json').write_text(json.dumps(c,indent=2)+'\n')
r=p/'README.md';s=r.read_text()
s+='''

## Actual run completed — 2026-10-23

Parent released the resource reservation. The existing copied snapshot was checked
against saved hashes without reading the live checkout, then run-frozen-export.sh
built all 81 masters with the verified pinned binary. All 10 same-camera committed
before/proposed after captures completed, browsers closed, and were inspected.
All research verdicts are now differs. See the run's reviews/README.md,
visual-review.json and decoded-export-review.json; these supersede earlier
“prepared only” execution status while all release limitations above still apply.

75 of 76 default assets are committed-byte-identical. Kinzie stable has only three
UV accessor changes, all JSON/non-UV/index/material/confidence identical. A fresh
original-code isolated control export exactly equals its proposed GLB. The strict
original verifier remains failed on committed UV-byte drift; it was not weakened.
All 81 actual GLBs passed decoded contract essentials. No official hashes were
restamped. Source/before/after detail crops show each increment and remaining
differences; Miller's lower logs visibly improve but its upper vertical edge
treatment is effectively invisible and requires refinement. Cobweb implements
the text plan; its tiny picture is not positively identified or matched. School
gable/higher lights and Carpenter/Wolf Point roof-head categories improve while
their full pictured forms remain discrepant. No derivatives, full gate, app/card
review, terrain check or accepted match was run. CPU/browser slot returned to
the frame-family agent after closure; no additional heavy job remains.
'''
r.write_text(s)
for folder,skip_runs in [(run,False),(p,True)]:
 files={str(f.relative_to(folder)):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(folder.rglob('*')) if f.is_file() and not f.is_symlink() and 'node_modules' not in f.relative_to(folder).parts and '__pycache__' not in f.parts and f.name!='ARTIFACTS.json' and (not skip_runs or 'runs' not in f.relative_to(folder).parts)}
 (folder/'ARTIFACTS.json').write_text(json.dumps(files,indent=2)+'\n')
print('Reviewed checkpoint and hashed artifacts updated; all jobs closed')
