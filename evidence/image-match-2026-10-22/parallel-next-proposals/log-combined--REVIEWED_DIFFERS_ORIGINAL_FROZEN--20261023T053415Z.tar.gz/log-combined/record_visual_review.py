"""Record actual reviewed differences, only within the disposable run."""
from pathlib import Path
import datetime,hashlib,json
out=Path(__file__).resolve().parent;run=Path((out/'latest-run.txt').read_text().strip())
notes={
'T-2372-school-shore':{
 'visible_increment':'Actual same-camera after image now has an entrance gable and larger/higher flanking lights instead of an eave over the doorway and low small windows.',
 'differences':[
  'School versus annex subject identity and original date remain unresolved; a resemblance preview does not settle them.',
  'The retained broad frontage/proportions and reconstructed camera do not align with the narrower drawn log facade; right side is cropped.',
  'The new gable triangle is plain roof-coloured material; the drawing shows horizontal log courses into the gable.',
  'The door remains closed while the drawing has an open doorway with a woman; exact opening spacing, dimensions and sash divisions still differ.',
  'Roof shakes/shingles, log-course scale/chinking, surface tones and unpictured rear stack remain unresolved; this is neutral overcast review rather than a measured lighting solution.'
 ]},
'T-2374-cobweb-subject-unresolved':{
 'visible_increment':'Actual after replaces the high single rectangle-wide roof with a lower central front gable and flanking wing roofs. This implements Wau-Bun’s compound description, not a demonstrated picture match.',
 'differences':[
  'Positive identity of the tiny house above the unled Agency-House caption is unresolved; no whole-building visual grade or measured camera is established.',
  'Even if that house is the subject, its prominent gable/return silhouette does not match the long low symmetric five-part reconstruction in this frame.',
  'The source subject is tiny and the camera provisional; no exact dimensions, opening count, roof plan or stack disposition is recovered.',
  'Both rear tails and most roof junctions are unshown in this head-on distant render; inspect close oblique/rear geometry before release.',
  'Partial clapboarding/date, wall finish, 1835 survival and applying the 1831 form back to 1820 remain unresolved.'
 ]},
'T-2381-miller-nypl':{
 'visible_increment':'Actual after replaces the lower-storey clapboard with visibly coarser log courses and removes uniform horizontal siding upstairs. The chosen fine upper board edges are effectively invisible in this neutral view.',
 'differences':[
  'Upper vertical boarding remains visually inadequate: same-material 12mm board-edge relief is too faint at this framing; do not describe the blank-looking upper wall as a complete reproduction.',
  'The source has three upper front windows; the model retains two, with different proportions and generic glazing/door.',
  'The low cabin remains behind the tall block rather than fully alongside; provisional camera obliquity also disagrees, so this frame cannot isolate the plan error metrically.',
  'The tall full-height exterior stack differs from the pictured modest roof head; roof profile, missing source textures/tones and exact cladding break still differ.',
  'The 1867 publication depicts 1833 retrospectively and does not independently establish unchanged July 1835 condition.'
 ]},
'T-2382-carpenter-braunhold-group':{
 'visible_increment':'Actual joint after shows upright bare sash and a small roof head toward the annex’s free end, replacing low square lights and the full-height hotel-junction exterior stack.',
 'differences':[
  'The annex sash is now tall but the generic glazing appears predominantly vertical strips; the source has finer horizontal subdivisions and different frame detailing.',
  'The annex doorway remains closed rather than the depicted open dark doorway.',
  'The chosen chimney station/section/head are reconstructed and its inherited stick-and-clay colour/plain cap do not reproduce the source masonry form.',
  'The hotel anchor roof/gable/massing is still wrong; this review deliberately uses its committed baseline mesh, not the pending frame-family change.',
  'Joint perspective, exact annex roof proportions, log texture/chinking and group contact remain unresolved; the main-only camera fit is not an annex camera solution.',
  'Existing Beaubien-caption identification and uncertain July 1835 survival/use remain; no duplicate hotel log wing is enabled.'
 ]},
'T-2386-wolfpoint-nypl':{
 'visible_increment':'Actual after removes the broad exterior end stack and leaves a small plain head penetrating the roof, moving the chimney disposition toward the source.',
 'differences':[
  'The source’s two low gable-front volumes are not reproduced by the model’s inline eave-front core/frame arrangement.',
  'The second front entrance and separate slender roof pipe remain unbuilt/unresolved.',
  'Reconstructed chimney station, shaft width, head/cap, fabric and colour remain provisional, not measured from a solved camera.',
  'Pole/sign height, scale, position, drawing, openings, roof covering and log/frame finishes still differ.',
  'The oblique source camera is uncalibrated; the retrospective 1833 depiction published 1867 does not prove unchanged July 1835 appearance.'
 ]}}
summary=[]
for name,review in notes.items():
 for kind in ['baseline','proposed']:
  root=run/kind;camera=root/f'docs/RESEARCH/log-combined-review/{name}.json';match=camera.with_suffix('.match.json')
  doc=json.loads(match.read_text());cam=json.loads(camera.read_text())
  assert doc['camera_sha256']==hashlib.sha256(camera.read_bytes()).hexdigest()
  assert doc['glb_sha256']==hashlib.sha256((root/doc['glb']).read_bytes()).hexdigest()
  doc['verdict']='differs';doc['differences']=[dict(what=s,status='open') for s in review['differences']]
  if kind=='baseline':doc['differences'].insert(0,dict(what='Committed-before baseline still has the prior generic geometry; the proposed increment is described separately in the paired visual review.',status='open'))
  doc['review']=dict(reviewed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Actual committed-before and proposed-after side-by-sides plus source/before/after detail crop inspected. Research fixture only.',visible_increment=review['visible_increment'],accepted_camera=False,source_limits_preserved=True)
  match.write_text(json.dumps(doc,indent=2,ensure_ascii=False)+'\n')
 summary.append(dict(camera=name,verdict='differs',**review))
(run/'visual-review.json').write_text(json.dumps(dict(all_five_verdicts='differs',all_ten_actual_captures_inspected=True,accepted_cameras=0,tickets_closed=0,reviews=summary),indent=2,ensure_ascii=False)+'\n')
print('Recorded differs for all10 actual research captures; no accepted view or ticket mutation')
