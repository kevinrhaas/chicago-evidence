# Actual isolated log-family comparisons — all differ

Captured 2026-10-23 from the frozen 20261023-050224-069556 snapshot. The official
copied build.py/emit.py pipeline used structure_id__phase_id names and verified
Blender 4.5.3. Parent checkout changes cannot affect these copies. All ten actual
source/before and source/after side-by-sides were inspected, plus the source / 
committed-before / proposed-after detail panels in `details/`. Every research
match record is `differs`. No accepted camera, ticket closure or repository write.

`../visual-review.json` records per-view differences. Main findings:

- School: entrance-gable orientation and higher/larger lights now read, but the
  plain roof-coloured gable lacks the drawing's logs, width/proportions/camera
  disagree, doorway is closed and subject identity remains unresolved.
- Cobweb: five-part/text massing is built; this is not demonstrated resemblance
  to the tiny alleged agency house. The proposed long low silhouette still
  differs. Subject identity, close rear/tail/junction review, siding/date remain.
- Miller: lower logs clearly replace clapboard, but fine same-material upper
  board edges are effectively invisible. Vertical boarding is not yet visibly
  reproduced. Two versus three upper windows, huge exterior stack, cabin
  placement, textures and provisional camera remain major differences.
- Carpenter: tall bare sash and roof-piercing free-end stack improve disposition.
  Glazing divisions, open doorway, masonry finish/cap, roof, group camera/contact
  still differ. The context hotel is the committed mesh, not the pending frame
  family model; its own discrepancies are visible and retained.
- Wolf Point: small roof head improves the stack disposition. Paired front gables,
  second doorway, separate pipe, sign/pole scale, textures and camera still differ.

The school and Cobweb views must not be used to promote identity/grade. Miller,
Wolf Point and the annex have separate proposed pictured rulings under existing
identifications; picture availability does not override numeric attribute grades.

## Source credits and permitted use

- School: artist unidentified; reproduced by the **Digital Research Library of
  Illinois History Journal**, 2018 Eliza Chappell article:
  <https://drloihjournal.blogspot.com/2018/01/eliza-chappell-the-first-chicago-teacher-paid-by-public-funds-in-1833.html>.
  Owner approved attributed project reference/comparison/display on 2026-10-22,
  T-3053. This is project-specific owner clearance, not a public-domain finding,
  copyright-holder permission or general redistribution licence. Exact copied
  source citation and rights_checked remain under proposed/data/sources.
- Cobweb context: *Fort Dearborn and Chicago in 1831*, heading “From Wau-Bun,
  by Mrs. Juliette A. Kinzie, Chicago, 1857”; retrospective wood engraving after
  Kinzie. Inventory Commons locator:
  <https://commons.wikimedia.org/wiki/File:Fort_Dearborn_%26_Chicago_in_1831.jpg>.
  Existing inventory treats the pre-1930 print as public domain. The model's
  composition evidence is the separately cited Wau-Bun text, not measured from
  the tiny, still unidentified picture subject.
- Miller and Wolf Point: *Wolf's Point in 1833*, publisher **Rufus Blanchard**,
  lithographer **Chas. Shober & Co.**, Chicago, **1867**, under the auspices of
  the Chicago Historical Society; NYPL I.N. Phelps Stokes Collection surrogate:
  <https://commons.wikimedia.org/wiki/File:Wolf%27s_Point_in_1833_(NYPL_Hades-118496-54620).tif>.
  Public-domain age determination rests on the actual printed 1867 deposit line;
  scene date 1833 is distinct from publication. This print is not a survey or
  direct observation of the July 1835 state.
- Carpenter / hotel: *The Sauganash Hotel*, Braunhold attribution, published in
  **A.T. Andreas, History of Chicago, vol.1 (1884)**; committed local surrogate:
  chicago_sauganash_hotel_1831.jpg. Existing source locator:
  <https://archive.org/details/historyofchicago01andr/page/n1297/mode/1up>.
  Public domain by 1884 US publication age. Existing source record's older
  signature-legibility wording differs from the clearly lettered local surrogate;
  no new artist identity or contemporary observation is invented here.

Full source JSON copies, actual photos and original camera JSON are retained in
both isolated sides. Detail panels are crops of the unchanged original source
and the two real captures, not new renders or fitted/aligned transformations.
These estimated views use a common flat grade plane, neutral overcast lighting,
and no final terrain or source scenery. They cannot validate app performance.

## Export proof and limitations

All81 selected masters exported; recipes current. Actual decoded GLB checks cover
finite positions/attributes, unit normals, valid indices, material references and
float SCALAR _CONFIDENCE counts/values. Five intended meshes change. Among76
defaults,75 are identical to committed bytes; Kinzie stable differs only in three
TEXCOORD_0 accessors with identical JSON/non-UV/index/material/confidence data.
A fresh frozen-original-code stable control export is byte-identical to the
proposed stable, proving this difference already arises from pinned baseline
UV packing, not the log opt-ins. See ../decoded-export-review.json.

The original strict verifier correctly retains its failure on the committed UV
bytes; it was not weakened, nor were hashes restamped. No derivatives, complete
GLB validator, hidden roof/tail visual review, full application/terrain/lighting
check, source-card UI check, full repository gate or official publication ran.
