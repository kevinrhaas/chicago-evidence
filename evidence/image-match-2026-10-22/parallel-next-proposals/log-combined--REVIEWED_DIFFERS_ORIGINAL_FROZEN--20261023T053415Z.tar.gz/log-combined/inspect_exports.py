"""Read frozen GLBs: contract essentials, decoded parity and UV-only control."""
from pathlib import Path
import hashlib,json,math,struct
out=Path(__file__).resolve().parent;run=Path((out/'latest-run.txt').read_text().strip())
scope=json.loads((run/'scope.json').read_text())
def read(path):
 raw=path.read_bytes();magic,version,total=struct.unpack_from('<III',raw)
 assert magic==0x46546c67 and version==2 and total==len(raw),path
 at=12;doc=None;binary=None
 while at<len(raw):
  size,kind=struct.unpack_from('<II',raw,at);chunk=raw[at+8:at+8+size]
  if kind==0x4e4f534a:doc=json.loads(chunk)
  if kind==0x004e4942:binary=chunk
  at+=8+size
 assert doc['asset']['version']=='2.0' and binary is not None
 return doc,binary
arity={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
formats={5120:'b',5121:'B',5122:'h',5123:'H',5125:'I',5126:'f'}
def payload(doc,binary,index):
 a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']]
 assert v.get('buffer',0)==0 and not a.get('sparse')
 n=arity[a['type']];fmt=formats[a['componentType']];width=struct.calcsize('<'+fmt)*n
 stride=v.get('byteStride',width);offset=v.get('byteOffset',0)+a.get('byteOffset',0)
 assert offset+(a['count']-1)*stride+width<=len(binary)
 return b''.join(binary[offset+i*stride:offset+i*stride+width] for i in range(a['count']))
def values(doc,binary,index):
 a=doc['accessors'][index];fmt=formats[a['componentType']]
 data=payload(doc,binary,index);return list(struct.unpack('<'+fmt*(len(data)//struct.calcsize(fmt)),data))
def summary(doc,binary):
 triangles=draws=verts=0;confs=set();positions=[]
 for mesh in doc.get('meshes',[]):
  for p in mesh['primitives']:
   draws+=1;assert p.get('mode',4)==4
   attrs=p['attributes'];assert 'POSITION' in attrs and 'NORMAL' in attrs and '_CONFIDENCE' in attrs
   pos=doc['accessors'][attrs['POSITION']];count=pos['count'];verts+=count
   assert pos['componentType']==5126 and pos['type']=='VEC3'
   for attr,index in attrs.items():
    a=doc['accessors'][index];assert a['count']==count
    vals=values(doc,binary,index);assert all(math.isfinite(v) for v in vals)
    if attr=='NORMAL':
     assert all(abs(sum(v*v for v in vals[i:i+3])-1)<1e-4 for i in range(0,len(vals),3))
    if attr=='_CONFIDENCE':
     assert a['componentType']==5126 and a['type']=='SCALAR'
     confs.update(vals);assert set(vals)<={0.,.5,1.}
    if attr=='POSITION':positions.extend(tuple(vals[i:i+3]) for i in range(0,len(vals),3))
   ind=values(doc,binary,p['indices']);assert len(ind)%3==0 and all(0<=v<count for v in ind)
   triangles+=len(ind)//3
   if 'material' in p:assert 0<=p['material']<len(doc['materials'])
 for m in doc.get('materials',[]):
  pbr=m.get('pbrMetallicRoughness',{})
  assert all(0<=v<=1 for v in pbr.get('baseColorFactor',[1,1,1,1]))
 return dict(primitives=draws,vertices=verts,triangles=triangles,materials=len(doc.get('materials',[])),confidence_values=sorted(confs),local_gltf_bounds={'min':[min(p[i] for p in positions) for i in range(3)],'max':[max(p[i] for p in positions) for i in range(3)]})
def diff(a,ab,b,bb):
 if a!=b:return {'json_identical':False,'changed_accessor_roles':'different geometry/layout metadata'}
 roles={i:set() for i in range(len(a['accessors']))}
 for mesh in a['meshes']:
  for p in mesh['primitives']:
   for attr,index in p['attributes'].items():roles[index].add(attr)
   roles[p['indices']].add('indices')
 changed=[dict(index=i,roles=sorted(roles[i])) for i in roles if payload(a,ab,i)!=payload(b,bb,i)]
 return dict(json_identical=True,changed_accessor_roles=changed)
rows=[];defaults=[];targets=[]
for row in scope['assets']:
 asset=row['asset'];old=run/'baseline/assets/gltf'/asset;new=run/'proposed/assets/gltf'/asset
 a,ab=read(old);b,bb=read(new);before=summary(a,ab);after=summary(b,bb)
 delta=diff(a,ab,b,bb);equal=old.read_bytes()==new.read_bytes()
 item=dict(asset=asset,expected_geometry_change=row['expected_geometry_change'],byte_identical=equal,before=before,after=after,delta=delta)
 rows.append(item)
 if row['expected_geometry_change']:targets.append(item)
 else:
  assert delta['json_identical'] and all(d['roles']==['TEXCOORD_0'] for d in delta['changed_accessor_roles']),asset+' unexpected non-UV drift'
  defaults.append(item)
stable='kinzie_stable_1812__kinzie_1804.glb'
control=run/'default-control/assets/gltf'/stable;new=run/'proposed/assets/gltf'/stable
assert control.read_bytes()==new.read_bytes(),'Fresh legacy stable control differs from opt-in-disabled proposed export'
report=dict(status='passed_contract_and_default_geometry_checks_with_documented_committed_uv_drift',assets_checked=len(rows),default_masters=len(defaults),default_byte_identical=sum(r['byte_identical'] for r in defaults),default_non_uv_accessor_json_material_index_confidence_parity=True,uv_only_drift=[r for r in defaults if not r['byte_identical']],fresh_legacy_stable_control_sha256=hashlib.sha256(control.read_bytes()).hexdigest(),fresh_legacy_stable_equals_proposed=True,target_exports=targets,limits='Contract essentials and actual decoded fields, not full validator, app performance, textures, manifoldness, visual acceptance or web derivatives. Strict original export verifier remains failed on committed UV bytes; no manifest restamping or ignored geometry failure.')
(run/'decoded-export-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['uv_only_drift','target_exports']},indent=2))
