"""Validate actual isolated outputs/recipes after export, never restamp inputs."""
from pathlib import Path
import hashlib,json,sys
run=Path(sys.argv[1]).resolve();out=Path(__file__).resolve().parent
assert run.is_relative_to(out/'runs')
base=run/'baseline';new=run/'proposed';scope=json.loads((run/'scope.json').read_text())
want={row['asset'] for row in scope['assets']};wrote=set((run/'wrote.txt').read_text().splitlines())
assert wrote==want,{'missing':sorted(want-wrote),'unexpected':sorted(wrote-want)}
sys.dont_write_bytecode=True;sys.path.insert(0,str(new/'generators'));import mesh_inputs
manifest=json.loads((new/'assets/manifest.json').read_text())['assets'];rows=[];drift=[]
for row in scope['assets']:
 asset=row['asset'];b=(base/'assets/gltf'/asset).read_bytes();a=(new/'assets/gltf'/asset).read_bytes()
 record=json.loads((new/f"data/structures/{row['structure_id']}.json").read_text());phase=next(p for p in record['phases'] if p['id']==row['phase_id'])
 assert manifest[asset]['inputs_sha256']==mesh_inputs.structure_inputs_sha(record,phase,'log_dwelling')
 old_sha=hashlib.sha256(b).hexdigest();new_sha=hashlib.sha256(a).hexdigest();changed=old_sha!=new_sha
 if changed and not row['expected_geometry_change']:drift.append(asset)
 rows.append(dict(asset=asset,baseline_sha256=old_sha,export_sha256=new_sha,bytes=len(a),bytes_changed=changed,intended_geometry_change=row['expected_geometry_change'],recipe_current=True))
report=dict(exported_master_count=len(rows),all_recipes_current=True,legacy_byte_drift=drift,assets=rows,limits='No derivative, browser, source card, match, grade compilation, scene budget or full gate validation. Unexpected legacy drift must be investigated before integration.')
(run/'export-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(exported=len(rows),legacy_byte_drift=drift),indent=2))
assert not drift,'unexpected legacy byte drift: review before copying assets'
