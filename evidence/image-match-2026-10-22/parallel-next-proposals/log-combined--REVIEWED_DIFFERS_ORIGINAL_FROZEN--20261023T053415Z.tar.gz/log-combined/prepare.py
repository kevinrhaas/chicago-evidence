"""Compose five frozen proposals, writing /tmp only. No builds or browser."""
from pathlib import Path
import ast,difflib,hashlib,json,re,subprocess
out=Path(__file__).resolve().parent;repo=Path('/workspace/chicago');app=repo/'chicago/4d';parcels=out.parent
candidate=out/'candidate';candidate.mkdir(exist_ok=True)
updates={};inputs={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
def current(rel):
 p=repo/rel;inputs[str(rel)]=sha(p);return p.read_text() if p.exists() else ''
def add(rel,after):
 old=current(rel);updates[str(rel)]=(old,after);p=candidate/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(after)
def threeway(ours,base,theirs,name):
 paths=[out/f'{name}.{label}' for label in ['ours','base','theirs']]
 for p,s in zip(paths,[ours,base,theirs]):p.write_text(s)
 result=subprocess.run(['git','merge-file','-p',*[str(p) for p in paths]],capture_output=True,text=True)
 assert 0<=result.returncode<=3,result.stderr
 return result.stdout
def resolve_known(s,name):
 pattern=r'^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n'
 def resolve(m):
  a,b=m.groups()
  if name=='log_dwelling.py':
   assert a.strip()=='lean_to_extent, compound_front_rects,' and b.strip()=='lean_to_extent, resolved_core_ridge_axis,'
   return '    lean_to_extent, compound_front_rects, resolved_core_ridge_axis,\n'
  assert ('compound_parts' in a and 'roof_ridge_axis' in b),(a,b)
  return a+b
 s=re.sub(pattern,resolve,s,flags=re.M|re.S)
 assert not any(marker in s for marker in ['<<<<<<<','=======','>>>>>>>'])
 return s
for name in ['log_dwelling.py','log_dwelling_params.py']:
 rel=Path('chicago/4d/generators/archetypes')/name;base=current(rel)
 cobweb=(parcels/'T-2374'/name.replace('.py','.proposed.py')).read_text()
 school=(parcels/'T-2372-roof/tree'/rel).read_text()
 mixed=(parcels/'T-2381/after'/rel).read_text()
 # Every standalone proposal must still derive from this same code baseline.
 assert (parcels/'T-2381/before'/rel).read_text()==base,'Miller code baseline drifted'
 merged=resolve_known(threeway(cobweb,base,school,name),name)
 merged=threeway(merged,base,mixed,name+'-miller')
 assert '<<<<<<<' not in merged
 if name.endswith('_params.py'):
  assert merged.count('    compound_parts: tuple = ()')==1
  merged=merged.replace('    compound_parts: tuple = ()','    compound_parts: tuple = field(default=(), kw_only=True)')
  assert merged.count('    frame_addition_cladding: str = "clapboard"')==1
  merged=merged.replace('    frame_addition_cladding: str = "clapboard"','    frame_addition_cladding: str = field(default="clapboard", kw_only=True)')
  assert 'getattr(self, "compound_parts", ())' in merged
 else:
  # Parent ruling: pictured finish faces inferred; invented edge detail reconstructed.
  merged=merged.replace('_vertical_addition_edges(b, ax0, ay0, ax1, ay1, split, az, c_finish)',
                        '_vertical_addition_edges(b, ax0, ay0, ax1, ay1, split, az, 1.0)')
  assert merged.count('top,\n                      conf, M_FRAME, skip=("bottom", "top"))')==1
  merged=merged.replace('top,\n                      conf, M_FRAME, skip=("bottom", "top"))',
                        'top,\n                      1.0, M_FRAME, skip=("bottom", "top"))')
 ast.parse(merged);add(rel,merged)
school=json.loads((parcels/'T-2372/tree/chicago/4d/data/structures/chappel_infant_school.json').read_text())
roof=json.loads((parcels/'T-2372-roof/tree/chicago/4d/data/structures/chappel_infant_school.json').read_text())
school['phases'][0]['form']['roof_ridge_axis']=roof['phases'][0]['form']['roof_ridge_axis']
add('chicago/4d/data/structures/chappel_infant_school.json',json.dumps(school,indent=2,ensure_ascii=False)+'\n')
for sid,p in {
 'cobweb_castle':parcels/'T-2374/proposed-structure.json',
 'miller_house':parcels/'T-2381/after/chicago/4d/data/structures/miller_house.json',
 'philo_carpenter_log_shop':parcels/'T-2382-next/after-sash-chimney.json',
 'wolf_point_tavern':parcels/'T-2386/tree/chicago/4d/data/structures/wolf_point_tavern.json',
}.items():add(f'chicago/4d/data/structures/{sid}.json',p.read_text())
source=json.loads((parcels/'T-2372/tree/chicago/4d/data/sources/eliza_chappel_school_shore_view.json').read_text())
source['note']+=' T-2372 combined increment also uses the owner-approved attributed school-shore picture to guide a reconstructed doorway-gable roof direction. This is not a new identification of the school or Sauganash annex, a surveyed alignment, a July 1835 attestation, public-domain claim, or an accepted image-gate camera.'
add('chicago/4d/data/sources/eliza_chappel_school_shore_view.json',json.dumps(source,indent=2,ensure_ascii=False)+'\n')
wolf=json.loads((parcels/'T-2386/tree/chicago/4d/data/sources/blanchard_shober_1867_wolf_point.json').read_text())
miller=json.loads((parcels/'T-2381/after/chicago/4d/data/sources/blanchard_shober_1867_wolf_point.json').read_text())
assert all(miller[k]==v for k,v in wolf.items() if k not in ['note','what_it_supplies'])
assert miller['note'].startswith(wolf['note']) and miller['what_it_supplies'][:len(wolf['what_it_supplies'])]==wolf['what_it_supplies']
add('chicago/4d/data/sources/blanchard_shober_1867_wolf_point.json',json.dumps(miller,indent=2,ensure_ascii=False)+'\n')
fragments={}
fragments['T-2372']='''### L-school-pictured-openings-roof-2372 — provisional doorway gable and higher lights

The owner-approved attributed school-shore reproduction guides a reconstructed
doorway-gable roof direction and opening treatment without identifying its subject
as this school or establishing original copyright/publication or a July 1835 state.
The existing footprint, 90-degree placement and 35-degree pitch remain. Sash
0.85 m square, doorway 1.20 m wide with 2.05 m clear height, common 2.07 m head,
rounded inherited front centres, no external front shutters and a local-Y core
ridge are chosen model dimensions/directions. The unseen rear light follows the
same new band; roof, loft/gable classification and rear stack follow one declared
axis. These are not metric evidence. The former eave-front roof assumption is
superseded only for this record. Open door state, covering, massing/proportions,
subject identity, historical function and camera remain unresolved; T-2372 stays
open. The source credit, URL and project-specific owner clearance are retained,
without claiming public domain or copyright-holder permission.
**Covers:** chappel_infant_school.log_1833.form.front_set_out,
chappel_infant_school.log_1833.form.window_w_m,
chappel_infant_school.log_1833.form.window_h_m,
chappel_infant_school.log_1833.form.door_w_m,
chappel_infant_school.log_1833.form.door_h_m,
chappel_infant_school.log_1833.form.roof_ridge_axis.
**Ticket:** T-2372.
'''
cobweb=(parcels/'T-2374/T-2374.patch').read_text()
base_lib=current('chicago/4d/docs/LIBERTIES.md')
# Extract the exact author's append via its prepared source file diff text.
libstart='### L-cobweb-compound-2374'
lines=cobweb.splitlines();start=next(i for i,l in enumerate(lines) if l=='+'+libstart+' — five log rooms instead of one bounding box')
fragment=[]
for line in lines[start:]:
 if line.startswith('--- ') or line.startswith('diff '):break
 if line.startswith('+'):fragment.append(line[1:])
fragments['T-2374']='\n'.join(fragment)+'\n'
fragments['T-2381']=(parcels/'T-2381/proposed-liberty.md').read_text()+'\nCombined confidence ruling: wall/gable finish category faces remain inferred; chosen narrow board-edge sections and rhythm emit reconstructed confidence (1.0).\n'
fragments['T-2382']=(parcels/'T-2382/proposed-liberty.md').read_text()+'\nT-2382 next increment below supersedes this first entry’s generic end-stack description.\n\n'+(parcels/'T-2382-next/proposed-liberty.md').read_text()
fragments['T-2386']='''### L-wolf-point-pictured-stack-2386 — smaller roof-piercing head

The 1867 Blanchard/Shober lithograph depicting 1833 draws a head through the tavern
roof rather than the former full-height exterior gable stack. This is an inferred
disposition from a retrospective picture, not a dated 1835 construction record.
Exact core ridge station 0.58, 0.45 m square shaft and 0.50 m head rise are
reconstructed first-comparison choices. The original one-stack count, coordinates,
footprint, dimensions, roof pitch and use remain. The separate slender pipe,
parallel-gable massing, second entrance and camera remain unresolved; T-2386 is open.
**Covers:** wolf_point_tavern.log_frame_1828.form.chimney_ridge_at,
wolf_point_tavern.log_frame_1828.form.ridge_stack_w_m,
wolf_point_tavern.log_frame_1828.form.ridge_stack_head_m.
**Ticket:** T-2386.
'''
for ticket,body in fragments.items():
 p=out/'liberty-fragments'/f'{ticket}.md';p.parent.mkdir(exist_ok=True);p.write_text(body)
add('chicago/4d/docs/LIBERTIES.md',base_lib+'\n\n'+'\n\n'.join(fragments.values()))
# Reuse the author's dossier append, but do not copy its entire older LIBERTIES.
dossier=current('chicago/4d/docs/RESEARCH/cobweb_castle.md')
add('chicago/4d/docs/RESEARCH/cobweb_castle.md',dossier+'''

## T-2374 compound-massing increment (2026-10-23)

The previous single-bounding-box description records the former mesh. The
compound_parts opt-in represents five connected log rooms on the existing polygon,
with intersecting reconstructed gables. Wau-Bun supplies composition; dimensions,
exact plan, roof directions/joints, openings and stack positions remain chosen.
Partial siding remains simplified; 1835 survival, application of the 1831 form
back to 1820 and positive picture identification are unresolved. See
L-cobweb-compound-2374. T-2374 stays open; no matched camera is asserted.
''')
patch=''.join(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+rel if a else '/dev/null',tofile='b/'+rel)) for rel,(a,b) in updates.items())
(out/'log-combined.patch').write_text(patch)
manifest_path=app/'assets/manifest.json';manifest=json.loads(manifest_path.read_text());assets=manifest.get('assets',manifest)
intended=['chappel_infant_school','cobweb_castle','miller_house','philo_carpenter_log_shop','wolf_point_tavern'];scope=[]
for asset,entry in assets.items():
 sid=entry.get('structure_id');path=app/f'data/structures/{sid}.json'
 if not sid or not path.exists():continue
 record=json.loads(path.read_text())
 if record.get('archetype')!='log_dwelling':continue
 scope.append(dict(asset=asset,structure_id=sid,phase_id=entry['phase_id'],baseline_sha256=sha(app/'assets/gltf'/asset),expected_geometry_change=sid in intended))
 for p in [path,app/'assets/gltf'/asset]:inputs[str(p.relative_to(repo))]=sha(p)
scope.sort(key=lambda row:row['asset'])
(out/'freshness-scope.json').write_text(json.dumps(dict(archetype='log_dwelling',assets=scope,intended_changed_geometry=intended,original_tickets=['T-2372','T-2374','T-2381','T-2382','T-2386']),indent=2)+'\n')
(out/'structure-ids.txt').write_text(','.join(sorted(set(r['structure_id'] for r in scope)))+'\n')
inputs['chicago/4d/assets/manifest.json']=sha(manifest_path)
for p in sorted((app/'generators').rglob('*.py')):inputs[str(p.relative_to(repo))]=sha(p)
inputs['chicago/4d/generators/blender.pin']=sha(app/'generators/blender.pin')
(out/'input-snapshot.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),input_sha256=inputs,candidate_sha256={rel:hashlib.sha256(b.encode()).hexdigest() for rel,(a,b) in updates.items()},hogan_pr_merge_required_before_official_integration=True),indent=2)+'\n')
print(json.dumps(dict(files=len(updates),patch_bytes=len(patch.encode()),masters=len(scope),intended_changes=sum(r['expected_geometry_change'] for r in scope),original_tickets=5)))
