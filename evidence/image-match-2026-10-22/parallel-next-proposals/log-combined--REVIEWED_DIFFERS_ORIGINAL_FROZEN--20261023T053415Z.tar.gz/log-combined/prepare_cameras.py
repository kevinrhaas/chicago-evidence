"""Provisional research cameras only; no solved-view enrolment or rendering."""
from pathlib import Path
import json
out=Path(__file__).resolve().parent;repo=Path('/workspace/chicago/chicago/4d')
cameras={}
school=json.loads(Path('/tmp/t3053-next-parcels/T-2372/shore-provisional.json').read_text())
school['solve']['purpose']='Reuse the actually rendered T-3053 baseline framing for identical before/after model review. The school/annex identity, metric fit and scene date remain unresolved; no matches claim.'
school['solve']['remaining']='The combined proposal changes openings and chooses an entrance-gable ridge, but door state, roof covering, exact proportions, subject identity and camera remain unresolved. The same frozen pose may expose new silhouette differences.'
cameras['T-2372-school-shore']=school
def preview(sid,source,photo,image,principal,focal,eye,yaw,note):
 return dict(structure_id=sid,source_id=source,photo=str(repo/'../reference/images/chicago'/photo),image_px=image,principal_px=principal,focal_px=focal,eye=eye,yaw_deg=yaw,sky='overcast',solve=dict(status='provisional_reconstructed_preview_not_solved',purpose='Identical isolated before/after framing only. No optimisation, measured camera station, residual or matches verdict.',choices=note,metric_control='None. Existing model dimensions are retained reconstruction/inference, not image-derived metre controls.',light='Neutral overcast review, not a color or illumination inference.',limits='Retrospective picture and July 1835 limits remain; unpictured faces stay reconstructed. Research-only camera, never auto-enrol under data/reference_views.'))
cameras['T-2374-cobweb-subject-unresolved']=preview('cobweb_castle','kinzie_waubun_1856','chicago_fort_dearborn_1831_1.jpg',[1920,1042],[1440,385],2200,[45,270,2],188.3,'Reconstructed off-centre pose aimed near the small isolated house left of the poplars, above the Agency-House label. The label has no leader and positive subject identification is unresolved; it must not attest identity, massing, dimensions, coordinates or 1835 survival. Tiny panorama details are insufficient to recover all five parts. This camera is only a practical starting frame for the retained model, and has not been rendered.')
cameras['T-2381-miller-nypl']=preview('miller_house','blanchard_shober_1867_wolf_point','chicago_wolf_point_1833_nypl.jpg',[1920,1697],[1390,816],2900,[35,90,2],200.1,'Reconstructed oblique starting pose, locating the retained main block in the sheet’s right-hand building area. Existing dimensions and current cabin-behind-main arrangement are not a fit to the pictured side-by-side composition. Vertical-board/log division is the bounded increment; roof, upper window count, stacks, tones and camera are still differences. No numeric image landmark fit or residual is asserted; unrendered framing must be inspected first.')
cameras['T-2386-wolfpoint-nypl']=preview('wolf_point_tavern','blanchard_shober_1867_wolf_point','chicago_wolf_point_1833_nypl.jpg',[1920,1697],[350,858],1900,[-25,85,2],159.5,'Reconstructed oblique starting pose for the sheet’s left-bank tavern. The current inline core/addition does not reproduce the two pictured gable-front masses. Pole height, separate slender pipe, second entrance, roof topology and camera remain unresolved. This common framing compares the new small roof head to the old exterior stack; it is unrendered, not a fitted perspective or historic station.')
carp=json.loads(Path('/tmp/chicago-next-model/frame_tavern-combined/preview-root/review/sauganash/andreas-main-gable.provisional.json').read_text())
carp['scene']='1835';carp['also_render']=['philo_carpenter_log_shop']
carp['solve']+=' T-2382 combined log review adds the separately modelled Carpenter/Beaubien cabin as context using unchanged scene placements; the earlier main-only omission is superseded here. The hotel remains the camera anchor, not a sixth changed log-ticket model. Its mesh is the current committed baseline, not the separate pending frame-family proposal. Review the tall sash and near-free-end roof stack, keep their stations/dimensions reconstructed, and inspect both members. This joint framing itself has not been rendered; the single-building fit residual does not calibrate the annex or their relationship.'
cameras['T-2382-carpenter-braunhold-group']=carp
for name,camera in cameras.items():
 from PIL import Image
 photo=Path(camera['photo']).resolve();assert photo.exists(),photo
 assert list(Image.open(photo).size)==camera['image_px'],(name,Image.open(photo).size)
 camera['photo']=str(photo)
 p=out/'cameras'/f'{name}.json';p.parent.mkdir(exist_ok=True);p.write_text(json.dumps(camera,indent=2,ensure_ascii=False)+'\n')
print('Prepared 5 research-only provisional cameras; no render or matches record')
