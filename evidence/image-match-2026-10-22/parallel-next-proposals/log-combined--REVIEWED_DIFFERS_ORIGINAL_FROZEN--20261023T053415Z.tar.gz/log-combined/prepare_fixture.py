"""Prepare separate timestamped copies for a later authorised export/review."""
from pathlib import Path
import datetime,hashlib,json,shutil
out=Path(__file__).resolve().parent;repo=Path('/workspace/chicago/chicago/4d');candidate=out/'candidate/chicago/4d'
meta=json.loads((out/'input-snapshot.json').read_text())
for rel,want in meta['input_sha256'].items():
 p=Path('/workspace/chicago')/rel
 actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
 if actual!=want:raise RuntimeError(f'{rel} drifted; refresh/review package after parent work')
for rel,want in meta['candidate_sha256'].items():
 if hashlib.sha256((out/'candidate'/rel).read_bytes()).hexdigest()!=want:raise RuntimeError('candidate changed: '+rel)
scope=json.loads((out/'freshness-scope.json').read_text())
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S-%f');run=out/'runs'/stamp
assert run.resolve().is_relative_to(out.resolve()) and not run.exists();run.mkdir(parents=True)
for kind in ['baseline','proposed']:
 root=run/kind;root.mkdir()
 shutil.copytree(repo/'generators',root/'generators',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 for rel in ['data/scenes','renderers/web/vendor/three-0.185.1']:shutil.copytree(repo/rel,root/rel)
 for rel in ['data/datum.json','renderers/web/js/keith-stone.js','tools/photo_match.mjs','tools/photo_match_group.mjs']:
  dst=root/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/rel,dst)
 modules=Path('/workspace/node_modules').resolve();assert modules.is_dir(),modules
 (root/'node_modules').symlink_to(modules,target_is_directory=True)
 ids={row['structure_id'] for row in scope['assets']}
 cameras={p.stem:json.loads(p.read_text()) for p in (out/'cameras').glob('*.json')};assert len(cameras)==5
 for name,camera in cameras.items():
  ids.add(camera['structure_id']);ids.update(camera.get('also_render',[]))
  photo=Path(camera['photo']);dest=root/'data/sources/assets'/photo.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(photo,dest)
  camera['photo']='../../../data/sources/assets/'+photo.name
  dst=root/f'docs/RESEARCH/log-combined-review/{name}.json';dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(json.dumps(camera,indent=2)+'\n')
 manifest=json.loads((repo/'assets/manifest.json').read_text());all_assets=manifest.get('assets',manifest)
 selected={k:v for k,v in all_assets.items() if isinstance(v,dict) and v.get('structure_id') in ids}
 source_ids=set()
 for sid in sorted(ids):
  src=repo/f'data/structures/{sid}.json';dst=root/f'data/structures/{sid}.json';dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
  def sources(v):
   if isinstance(v,dict):
    for k,item in v.items():
     if k=='sources' and isinstance(item,list):source_ids.update(s for s in item if isinstance(s,str))
     else:sources(item)
   elif isinstance(v,list):
    for item in v:sources(item)
  sources(json.loads(src.read_text()))
  for scene in (repo/'data/scenes').glob('*.json'):
   src=repo/f'data/sidecars/{scene.stem}/{sid}.json'
   if src.exists():dst=root/f'data/sidecars/{scene.stem}/{sid}.json';dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
  versions=repo/f'data/structures/versions/{sid}'
  if versions.exists():raise RuntimeError(f'{sid}: selected alternates need explicit fixture inclusion')
 for asset in selected:
  dst=root/'assets/gltf'/asset;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/'assets/gltf'/asset,dst)
 manifest['assets']=selected;(root/'assets/manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
 source_ids.update(c['source_id'] for c in cameras.values())
 for sid in source_ids:
  rel=f'data/sources/{sid}.json';src=candidate/rel if (candidate/rel).exists() else repo/rel
  if not src.exists():raise RuntimeError('missing fixture source '+sid)
  dst=root/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
 if kind=='proposed':
  for src in candidate.rglob('*'):
   if src.is_file():dst=root/src.relative_to(candidate);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
 (root/'FIXTURE-ONLY.txt').write_text('Disposable isolated log export/review fixture. Not a complete development checkout. Sidecars supply unchanged placement only; grades/forms are not recompiled here.\n')
(run/'scope.json').write_text(json.dumps(scope,indent=2)+'\n');(out/'latest-run.txt').write_text(str(run)+'\n');print(run)
