#!/usr/bin/env bash
# Parent authorised existing frozen snapshot. No current-checkout preparation.
set -euo pipefail
log_package="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
log_run="$(cat "$log_package/latest-run.txt")"
python3 "$log_package/check_frozen_fixture.py" "$log_run"
log_fixture="$log_run/proposed"
source "$log_fixture/generators/blender.pin"
log_archive="/workspace/shared/blender-dl/$(basename "$BLENDER_URL")"
log_binary="/workspace/shared/blender-dl/$BLENDER_DIR/blender"
printf '%s  %s\n' "$BLENDER_SHA256" "$log_archive" | sha256sum -c -
python3 - "$log_binary" "$BLENDER_VERSION" <<'PY'
import subprocess,sys
r=subprocess.run([sys.argv[1],'--version'],capture_output=True,text=True,check=True)
assert r.stdout.splitlines()[0].split()[1]==sys.argv[2],r.stdout.splitlines()[0]
print(r.stdout.splitlines()[0])
PY
log_ids="$(cat "$log_package/structure-ids.txt")"
cd "$log_fixture"
"$log_binary" -b -noaudio --factory-startup --python generators/build.py -- --only "$log_ids" --wrote "$log_run/wrote.txt" > "$log_run/export.log" 2>&1
python3 "$log_package/verify_exports.py" "$log_run"
