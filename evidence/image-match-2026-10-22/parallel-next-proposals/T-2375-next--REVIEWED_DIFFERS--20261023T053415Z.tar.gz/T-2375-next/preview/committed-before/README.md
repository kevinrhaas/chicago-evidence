# Actual committed bridge before / v2 proposal after

This is the real pre-change committed bridge GLB, not the unmerged v1 proposal.
Its bytes were checked against git object6156a0367a2379f0d986b88c7c8236c4ebec0e55,
chicago/4d/assets/gltf/dearborn_street_drawbridge__draw_1834.glb . Size638,488bytes,
SHA2561889475ca50109802cb2d782af06dc290c00dfc9578ebe53c31fd35dcd25031d .
receipt.json also records an identical locally fetched origin/dev commit, the
exact historical structure/phase and asset-manifest entry.

The unchanged copied photo_match renderer captured this GLB through the same
fixture and same projection, photo and lighting controls as v2. Only the solve
annotation differs to truthfully identify the committed baseline. The numeric
camera is still provisional/bounded, not accepted historical calibration.

Before: andreas-committed-before-side-by-side.jpg / andreas-committed-before-render.png.
After: ../comparisons/andreas-provisional-side-by-side.jpg / andreas-provisional-render.png.
The exact filenames of the original PNGs appear in receipt.json and the parent
preview directory. Both actual comparisons were opened and inspected. The before
has open pole rails/flat deck; the v2 proposal shows board infill, central rise
and aligned bearings. Remaining camera, member/support/trestle, approach, tone,
scene-context and second-image differences remain open. The v2 after is still an
isolated proposal export, not an official final bake/committed after asset; rerender
if its integration/bake changes the GLB hash. Neither comparison accepts a match.

Reproduce only in a free browser slot, from the fixture directory:
NODE_PATH=/workspace/shared/node/node_modules PW_EXECUTABLE=/usr/bin/chromium node tools/photo_match.mjs ../andreas-committed-before.json --glb assets/gltf/dearborn-pole-committed.glb --out ../committed-before

Source credit: Andreas1884vol.1p.631, retrospective public-domain plate,
https://archive.org/details/historyofchicago01andr/page/n1295/mode/1up .
No publisher, production manifest, tracked repository file or ticket was written.
