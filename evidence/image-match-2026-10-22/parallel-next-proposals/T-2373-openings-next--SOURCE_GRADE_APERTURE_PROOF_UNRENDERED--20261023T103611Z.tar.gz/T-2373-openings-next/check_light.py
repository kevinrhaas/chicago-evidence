#!/usr/bin/env python3
from pathlib import Path
from types import ModuleType
from dataclasses import asdict,replace
import ast,inspect,json,sys,math,copy,subprocess,hashlib
import numpy as np
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;R=Path('/workspace/chicago');N=Path('/tmp/chicago-next-model/T-2373-narrow-trial/candidate');S=Path('/tmp/chicago-next-model/fort-selective-integration/staged/candidate');root='chicago/4d/'
pr=root+'generators/archetypes/fort_structure_params.py';gr=root+'generators/archetypes/fort_structure.py';rr=root+'data/structures/chicago_lighthouse_1832.json'
def load(p,n):
 m=ModuleType(n);sys.modules[n]=m;exec(compile(p.read_text(),str(p),'exec'),m.__dict__);return m
old=load(H/'baseline'/pr,'tower_open_old');new=load(H/'candidate'/pr,'tower_open_new')
assert new.CONSUMED==old.CONSUMED|{'tower_openings'}
assert old.FortStructureParams.__match_args__==new.FortStructureParams.__match_args__
for k,p in inspect.signature(new.FortStructureParams).parameters.items():
 if k=='tower_openings':assert p.kind==inspect.Parameter.KEYWORD_ONLY and p.default is None
 else:assert p==inspect.signature(old.FortStructureParams).parameters[k]
family=json.loads(Path('/tmp/chicago-next-model/fort-selective-integration/staged/review-manifest.json').read_text())['family_refresh']['assets'];rows=[]
for row in family:
 rel=root+'data/structures/'+row['structure_id']+'.json';path=N/rel if (N/rel).exists() else S/rel if (S/rel).exists() else R/rel
 rec=json.loads(path.read_text());ph=next(p for p in rec['phases'] if p['id']==row['phase_id']);a=old.from_phase(ph,rec);b=new.from_phase(ph,rec);d=asdict(b);assert d.pop('tower_openings') is None;assert d==asdict(a)
 bpos=new.FortStructureParams(*[getattr(a,n) for n in a.__match_args__],**{k:getattr(a,k) for k,p in inspect.signature(old.FortStructureParams).parameters.items() if p.kind==inspect.Parameter.KEYWORD_ONLY});bpos.validate();dd=asdict(bpos);dd.pop('tower_openings');assert dd==asdict(a)
 rows.append(row['structure_id'])
a=json.loads((H/'baseline'/rr).read_text());b=json.loads((H/'candidate'/rr).read_text());plain=copy.deepcopy(b);del plain['phases'][0]['form']['tower_openings'];assert plain==a;p=new.from_phase(b['phases'][0],b)
def astmap(path):return {n.name:n for n in ast.parse(path.read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
af=astmap(H/'baseline'/gr);bf=astmap(H/'candidate'/gr)
assert set(bf)==set(af)|{'_TowerFacetBuilder','_tower_apertures'}
for name in af:
 if name!='_tower':assert ast.dump(af[name])==ast.dump(bf[name]),name
oldbody=af['_tower'].body;newbody=[n for n in bf['_tower'].body if not(isinstance(n,ast.If) and ast.unparse(n.test)=='p.tower_openings')];assert [ast.dump(n) for n in oldbody]==[ast.dump(n) for n in newbody]
# Execute actual new adapter + existing shared openings kit without bpy, collecting every actual emitted face.
sys.path.insert(0,str(R/'chicago/4d/generators'));from common import openings
class Collect:
 def __init__(self):self.faces=[];self.named={}
 def named_mat(self,name,*_):
  if name not in self.named:self.named[name]=5+len(self.named)
  return self.named[name]
 def add_poly(self,points,confidence,mat=0):self.faces.append((points,confidence,mat));return list(range(len(points)))
ns={'math':math,'openings':openings,'tower_opening_layout':new.tower_opening_layout,'M_TRIM':3}
tree=ast.Module(body=[bf['_TowerFacetBuilder'],bf['_tower_apertures']],type_ignores=[]);exec(compile('from __future__ import annotations\n'+ast.unparse(tree),'<actual proposed tower helpers>','exec'),ns)
col=Collect();radius=p.tower_diameter_m/2;shaft=p.wall_height_m*.86;cx=p.footprint_min_u_m+p.width_m/2;cy=p.footprint_min_v_m+p.width_m/2
ns['_tower_apertures'](col,p,cx,cy,radius,shaft);assert col.faces and len(col.named)==1
zero=0
for verts,conf,mat in col.faces:
 assert conf==1.0 and np.isfinite(np.array(verts)).all()
 for i in range(1,len(verts)-1):
  aa,bb,cc=np.array(verts[0]),np.array(verts[i]),np.array(verts[i+1]);area=np.linalg.norm(np.cross(bb-aa,cc-aa))/2
  if area<1e-10:zero+=1
assert zero==0
# Exact surface mapping: transformed unrelieved panel lies on the existing12-gon facet plane at EACH vertex.
for o in new.tower_opening_layout(p):
 c=Collect();adapt=ns['_TowerFacetBuilder'](c,cx,cy,radius,p.taper,shaft,o['azimuth_deg']);openings.face(adapt,openings.Wall('y',0.,1),0.,o['u0'],o['u1'],o['z0'],o['z1'],1.,9)
 verts=c.faces[0][0];angle=math.radians(o['azimuth_deg']);normal=np.array([math.cos(angle),math.sin(angle)])
 for x,y,z in verts:
  actual=np.dot(np.array([x-cx,y-cy]),normal);expected=radius*(1-(1-p.taper)*z/shaft)*math.cos(math.pi/12);assert abs(actual-expected)<1e-12
 aa,bb,cc=[np.array(x) for x in verts[:3]];winding=np.cross(bb-aa,cc-aa);assert np.dot(winding[:2],normal)>0
# Unsafe types/indices/spans/merged rectangles are refused.
valid=p.tower_openings[0];bad=[True,{},[{}],[dict(valid,facet=True)],[dict(valid,facet=12)],[dict(valid,width_m=1.0)],[dict(valid,width_m=float('nan'))],[dict(valid,z0_fraction=.99)],[valid,valid]]
for x in bad:
 try:replace(p,tower_openings=x).validate()
 except new.ParamError:pass
 else:raise AssertionError(('invalid accepted',x))
try:replace(p,kind='quarters').validate()
except new.ParamError:pass
else:raise AssertionError('tower layout accepted on quarters')
# Existing default and blank layouts add no geometry/readers remain distinguishable.
assert new.tower_opening_layout(replace(p,tower_openings=None)) is None
assert new.tower_opening_layout(replace(p,tower_openings=[]))==[]
import jsonschema
schema=json.loads((R/'chicago/4d/data/structures.schema.json').read_text());jsonschema.validate(b,schema)
r=subprocess.run(['git','apply','--check',str(H/'tower-openings-next.patch')],cwd=H/'baseline',capture_output=True,text=True);assert r.returncode==0,r.stderr
out={'status':'passed','family25default_params_and_legacy16positional_plus9keyword_API_preserved':len(rows),'new_field_keyword_only':True,'other_generator_functions_AST_equal':True,'legacy_tower_body_statements_AST_equal_except_optin_guard':True,'only_lighthouse_record_change_one_form_attribute':True,'actual_existing_openings_kit_used':True,'actual_emitted_aperture_faces':len(col.faces),'triangles':sum(len(v)-2 for v,_,_ in col.faces),'zero_area_triangles':zero,'all_geometry_reconstructed':True,'exact_12gon_tapered_facet_planes_and_outward_winding_proved':True,'only_one_reused_lantern_glass_named_material':True,'data_schema_and_patch_apply_check_pass':True,'no_ground_door_or_flat_front_reader_claimed':True,'heavy_processes_run':False}
(H/'light-check.json').write_text(json.dumps(out,indent=2)+'\n');(H/'raw-aperture-geometry.json').write_text(json.dumps(col.faces)+'\n');print(json.dumps(out,indent=2))
