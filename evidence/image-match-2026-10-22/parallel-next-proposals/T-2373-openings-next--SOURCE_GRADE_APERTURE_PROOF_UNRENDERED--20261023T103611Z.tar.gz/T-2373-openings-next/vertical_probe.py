from pathlib import Path
import json
H=Path(__file__).resolve().parent
camera=json.loads(Path('/tmp/chicago-next-model/T-2373-narrow-trial/camera-corrected-controls-diagnostic.json').read_text()) if Path('/tmp/chicago-next-model/T-2373-narrow-trial/camera-corrected-controls-diagnostic.json').exists() else json.loads(Path('/tmp/chicago-next-model/T-2373-camera-audit/camera-corrected-controls-diagnostic.json').read_text())
k=camera['focal_px']/(2.8-camera['eye'][1]);y0=camera['principal_px'][1]+k*camera['eye'][2]
shaft=12.19*.86;maximum=12.19+(3.04/2)*.62*.7
def yy(z):return y0-k*z
shift=200-y0
# Deliberately two hypotheses, neither a proposed settled height definition.
a={'name':'retain_current_reconstructed_overall_max_and_width_camera_scale','max_z_m':maximum,'scale_px_per_m':k,'base_y':200,'finial_y':yy(maximum)+shift,'gallery_underside_required_z_m':(200-89)/k,'gallery_top_required_z_m':(200-89)/k+.09,'principal_y_for_endpoints':camera['principal_px'][1]+shift,'warning':'Current overall maximum is reconstructed and already exceeds nominal40ft. Lowering the shaft/lantern division here would be an explicit new reconstruction, not an attested measurement.'}
nominal=40*.3048;kk=(200-38)/nominal
b={'name':'illustrative_nominal40ft_as_OVERALL_height_NOT_A_RULING','max_z_m':nominal,'scale_px_per_m':kk,'base_y':200,'finial_y':38,'gallery_underside_required_z_m':(200-89)/kk,'principal_y_for_endpoints':200-kk*camera['eye'][2],'approx_gallery_projected_diameter_px':3.04*.62*1.34*kk,'approx_shaft_head_projected_diameter_px':3.04*.62*kk,'warning':'This hypothesis is geometrically compatible within uncertain width controls, but no reached source proves40ft includes the lantern. Do not change the attested value or declare this datum resolved.'}
out={'status':'diagnostic_only_not_rendered_or_solved','existing_camera':{'scale_px_per_m':k,'base_y':y0,'gallery_underside_y':yy(shaft),'gallery_floor_top_y':yy(shaft+.09),'finial_y':yy(maximum)},'translation_only':{'shift_y_px':shift,'equivalent_apparent_height_shift_m':-shift/k,'finial_y_after_shift':yy(maximum)+shift,'gallery_underside_y_after_shift':yy(shaft)+shift,'gallery_residual_vs89_px':yy(shaft)+shift-89,'conclusion':'Translation can align total endpoints while making gallery22px too high; foundation/camera translation alone cannot solve the profile.'},'hypotheses':[a,b],'source_base_uncertainty_px':8,'square_pixels':True,'attested_data_changed':False,'foundation_model_added':False}
(H/'vertical-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
