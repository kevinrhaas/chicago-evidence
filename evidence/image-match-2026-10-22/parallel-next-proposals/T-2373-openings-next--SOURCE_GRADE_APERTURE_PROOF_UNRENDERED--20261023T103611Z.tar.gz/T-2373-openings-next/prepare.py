from pathlib import Path
import json,difflib,hashlib
H=Path(__file__).resolve().parent;S=Path('/tmp/chicago-next-model/T-2373-narrow-trial/candidate');B=H/'baseline';C=H/'candidate';root='chicago/4d/'
rels=[root+'generators/archetypes/fort_structure_params.py',root+'generators/archetypes/fort_structure.py',root+'data/structures/chicago_lighthouse_1832.json']
for rel in rels:
 for d in [B,C]:(d/rel).parent.mkdir(parents=True,exist_ok=True);(d/rel).write_bytes((S/rel).read_bytes())
p=C/rels[0];t=p.read_text().replace('"tower_diameter_m",','"tower_diameter_m", "tower_openings",',1)
t=t.replace('    # per-attribute confidence, keyed by the attribute name in the record','''    # Tower-only source apertures, centred on existing twelve-sided shaft facets.
    # None/[] add no geometry; window-only until a pictured door is identified.
    tower_openings: list | None = field(default=None, kw_only=True)

    # per-attribute confidence, keyed by the attribute name in the record''')
t=t.replace('    def validate(self) -> None:\n','''    def validate(self) -> None:
        if self.tower_openings is not None:
            if self.kind != "tower":
                raise ParamError("tower_openings needs kind tower")
            if not isinstance(self.tower_openings, list) or len(self.tower_openings) > 24:
                raise ParamError("tower_openings must be a list of at most 24 windows")
            radius = (self.tower_diameter_m if self.tower_diameter_m is not None else self.width_m) / 2
            for o in self.tower_openings:
                if not isinstance(o, dict) or set(o) != {"facet", "width_m", "z0_fraction", "z1_fraction"}:
                    raise ParamError("tower aperture needs facet/width_m/z0_fraction/z1_fraction")
                if isinstance(o["facet"], bool) or not isinstance(o["facet"], int) or not 0 <= o["facet"] < 12:
                    raise ParamError("tower aperture facet must be an integer 0..11")
                if any(isinstance(o[k], bool) or not isinstance(o[k], (int, float)) or not math.isfinite(o[k])
                       for k in ("width_m", "z0_fraction", "z1_fraction")):
                    raise ParamError("tower aperture dimensions must be finite numbers")
                if not .05 <= o["z0_fraction"] < o["z1_fraction"] <= .97 or o["width_m"] < .12:
                    raise ParamError("tower aperture fractions/width outside supported range")
                # Existing window sill horns/casings extend 0.12 m on each side.
                # Keep every emitted piece on its chosen tapered shaft facet.
                shaft = self.wall_height_m*.86
                if ((o["z1_fraction"]-o["z0_fraction"])*shaft < .30
                        or o["z1_fraction"]*shaft+.15 >= shaft):
                    raise ParamError("tower aperture height/trim do not fit the shaft")
                top_radius = radius * (1-(1-self.taper)*(o["z1_fraction"]+.15/shaft))
                if o["width_m"]+.24 > 2*top_radius*math.sin(math.pi/12):
                    raise ParamError("tower aperture and trim exceed shaft facet")
            for i, a in enumerate(self.tower_openings):
                for b in self.tower_openings[i+1:]:
                    if a["facet"] == b["facet"] and not (
                            a["z1_fraction"]+.03 <= b["z0_fraction"] or
                            b["z1_fraction"]+.03 <= a["z0_fraction"]):
                        raise ParamError("tower apertures overlap on one facet")
''')
t=t.replace('        confidence=confidences,','        tower_openings=val("tower_openings", None),\n        confidence=confidences,')
t+='''

def tower_opening_layout(p: FortStructureParams) -> list[dict] | None:
    """The actual tower aperture rectangles, distinct from a flat front wall.

    Existing shaft height is0.86*wall_height_m. Fractions preserve source order
    and move with a future explicitly reconstructed shaft/lantern division.
    """
    if p.tower_openings is None:
        return None
    shaft = p.wall_height_m * .86
    return [{"facet": o["facet"], "azimuth_deg": 15+30*o["facet"],
             "u0": -o["width_m"]/2, "u1": o["width_m"]/2,
             "z0": shaft*o["z0_fraction"], "z1": shaft*o["z1_fraction"],
             "kind": "window"} for o in p.tower_openings]
''';p.write_text(t)
p=C/rels[1];t=p.read_text().replace('import FortStructureParams  # noqa: E402','import FortStructureParams, tower_opening_layout  # noqa: E402')
if 'import FortStructureParams, tower_opening_layout' not in t:raise ValueError('Unexpected params import')
s=t.index('def _tower(');idx=t.index('    if not p.lantern:',s)
t=t[:idx]+'''    if p.tower_openings:
        _tower_apertures(b, p, cx, cy, r0, shaft)

'''+t[idx:]
t+='''

class _TowerFacetBuilder:
    """Map the existing openings kit onto one EXISTING tapered shaft facet.

    Local kit y is outward relief; x runs along the facet. Reversing winding
    compensates for this handedness change. No common kit/API is modified.
    """
    def __init__(self, builder, cx, cy, radius, taper, shaft, azimuth_deg):
        self.builder, self.cx, self.cy = builder, cx, cy
        self.radius, self.taper, self.shaft = radius, taper, shaft
        a = math.radians(azimuth_deg)
        self.normal, self.tangent = (math.cos(a), math.sin(a)), (-math.sin(a), math.cos(a))

    def add_poly(self, points, confidence, mat=0):
        mapped = []
        for u, relief, z in points:
            radius = self.radius*(1-(1-self.taper)*z/self.shaft)*math.cos(math.pi/12)
            mapped.append((self.cx+(radius+relief)*self.normal[0]+u*self.tangent[0],
                           self.cy+(radius+relief)*self.normal[1]+u*self.tangent[1], z))
        return self.builder.add_poly(list(reversed(mapped)), confidence, mat)


def _tower_apertures(b: MeshBuilder, p: FortStructureParams, cx: float, cy: float,
                     radius: float, shaft: float) -> None:
    """Three tiny pictured apertures, with reconstructed metric windows/glazing.

    Their trim, one-pane interpretation, facet assignments and vertical fractions
    are choices; the dark source marks do not attest joinery or a ground door.
    """
    mats = openings.Mats(casing=M_TRIM, sash=M_TRIM,
                         glass=b.named_mat("lantern_glass", *openings.glass_material_spec()))
    for o in tower_opening_layout(p):
        mapped = _TowerFacetBuilder(b, cx, cy, radius, p.taper, shaft, o["azimuth_deg"])
        openings.window(mapped, openings.Wall("y", 0., 1), o["u0"], o["u1"],
                        o["z0"], o["z1"], 1.0, mats, 1, None)
''';p.write_text(t)
p=C/rels[2];r=json.loads(p.read_text());r['phases'][0]['form']['tower_openings']={'value':[{'facet':8,'width_m':.24,'z0_fraction':.865,'z1_fraction':.928},{'facet':10,'width_m':.30,'z0_fraction':.72,'z1_fraction':.78},{'facet':7,'width_m':.30,'z0_fraction':.477,'z1_fraction':.55}],'confidence':'reconstructed','sources':['castelnau_1842_chicago_harbor'],'note':'Three small dark shaft apertures are visible in the actual1842 plate and held Commons reproduction: two narrow apertures on the light/front-left face and one on the shaded upper-right face. The third shaded mark is less certain. Facet indices8/10/7 (azimuth255/315/225 degrees), metric widths0.24/0.30/0.30m, one-pane glazing/casing and normalized height bounds are reconstructed for an initial trial, not measured from the lithograph. No unequivocal ground door is visible; lower masonry/platform shadows are not promoted into a door. Aperture height fractions use an occluded weak source-base control and remain uncertain. Continuity of circa1838 appearance back to July1835 is inferred. No footprint, origin, position, bearing, nominal40ft field, date or foundation elevation is changed. Camera and vertical shaft/lantern division remain unsolved; this increment is not a match.'};p.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
patch=[];inputs=[]
for rel in rels:
 old=(B/rel).read_text();new=(C/rel).read_text();patch+=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel));inputs.append({'path':rel,'baseline_sha256':hashlib.sha256(old.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(new.encode()).hexdigest()})
(H/'tower-openings-next.patch').write_text(''.join(patch));(H/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');print('Prepared3file tower-only overlay; no frozen input or canonical writes')
