import fs from 'node:fs';
import assert from 'node:assert/strict';
import {register} from 'node:module';
const root='/workspace/chicago/chicago/4d/';
const base='/tmp/chicago-next-model/T-2373-narrow-trial/runs/20261023-092203-154696/';
const h=new URL('.',import.meta.url);
const vendor=new URL('file://'+root+'renderers/web/vendor/three-0.185.1/').href;
register(`data:text/javascript,${encodeURIComponent(`export function resolve(s,c,next){if(s==='three')return {url:'${vendor}three.module.js',shortCircuit:true};if(s.startsWith('three/addons/'))return {url:'${vendor}addons/'+s.slice(13),shortCircuit:true};return next(s,c);}`)}`,import.meta.url);
const {Heightfield}=await import('file://'+root+'renderers/web/js/terrain.js');
const {addFeet}=await import('file://'+root+'renderers/web/js/building-feet.js');
const meta=JSON.parse(fs.readFileSync(root+'data/terrain/epochs/e1834_harbor_cut/heightfield.json','utf8'));
const raw=fs.readFileSync(root+'data/terrain/epochs/e1834_harbor_cut/heightfield.bin');
const field=new Heightfield().adopt(meta,raw.buffer.slice(raw.byteOffset,raw.byteOffset+raw.byteLength));
const sc=JSON.parse(fs.readFileSync(root+'data/sidecars/1835/chicago_lighthouse_1832.json','utf8'));
function getFeet(kind){
 const buf=fs.readFileSync(base+kind+'/assets/gltf/chicago_lighthouse_1832__tower_1832.glb');
 const len=buf.readUInt32LE(12),j=JSON.parse(buf.toString('utf8',20,20+len));
 const binStart=20+len+8,points=new Map();
 for(const mesh of j.meshes)for(const prim of mesh.primitives){
  const a=j.accessors[prim.attributes.POSITION],v=j.bufferViews[a.bufferView];
  const start=binStart+(v.byteOffset||0)+(a.byteOffset||0),stride=v.byteStride||12;
  const p={count:a.count,getX:i=>buf.readFloatLE(start+i*stride),getY:i=>buf.readFloatLE(start+i*stride+4),getZ:i=>buf.readFloatLE(start+i*stride+8)};
  const ia=j.accessors[prim.indices],iv=j.bufferViews[ia.bufferView],isz={5121:1,5123:2,5125:4}[ia.componentType],off=binStart+(iv.byteOffset||0)+(ia.byteOffset||0);
  const ix={count:ia.count,getX:i=>isz===4?buf.readUInt32LE(off+i*isz):isz===2?buf.readUInt16LE(off+i*isz):buf.readUInt8(off+i*isz)};
  addFeet(points,{getAttribute:n=>n==='position'?p:null,getIndex:()=>ix});
 }
 return [...points.values()];
}
const placement=sc.placement;assert.equal(placement.rotation_deg,0);
const origin=field.sample(placement.local_e,placement.local_n),result={};
for(const kind of ['baseline','proposed']){
 const feet=getFeet(kind);const elevations=feet.map(([x,z])=>field.sample(placement.local_e+x,placement.local_n-z));
 assert.equal(feet.length,kind==='baseline'?24:12,'FOOT_STEP_M splits5.6m tower edges but not3.04m edges');assert(feet.every(([x,z])=>field.contains(placement.local_e+x,placement.local_n-z)));
 result[kind]={actual_master_foot_samples:feet.length,origin_reference_height_m:origin,feet_min_m:Math.min(...elevations),feet_max_m:Math.max(...elevations),app_groundUnder_anchor_m:Math.min(origin,...elevations)};
}
const out={status:'passed',epoch:'e1834_harbor_cut',epoch_range_covers_both1835_and1838:true,real_Heightfield_and_addFeet_readers:true,source_foot_is_occluded:true,photo_match_uses_flat_zero_grade_and_not_this_field:true,placement_e_n:[placement.local_e,placement.local_n],samples:result,app_anchor_change_m:result.proposed.app_groundUnder_anchor_m-result.baseline.app_groundUnder_anchor_m,no_browser_or_mesh_generation:true};
fs.writeFileSync(new URL('grade-check.json',h),JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out,null,2));
