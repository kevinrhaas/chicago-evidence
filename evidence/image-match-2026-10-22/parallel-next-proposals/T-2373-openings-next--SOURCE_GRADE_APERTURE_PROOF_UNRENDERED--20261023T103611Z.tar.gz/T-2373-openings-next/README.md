# Lighthouse shaft aperture and base-control evidence

Actual1842 plate and Commons source detail were inspected. `source-picks.json` records three tiny marks: two clear narrow front/left apertures and a less certain upper shaded-right aperture. No unequivocal ground door is identified. Research crops under source/ are for inspection, not independent metric photographs.

`tower-openings-next.patch` is a three-file bounded prototype on the frozen narrow tower, preceding the separate combined profile trial. One individually keyword-only `tower_openings` field describes existing shaft facet indices, metric widths and normalized vertical bounds. The builder maps the existing shared window kit onto the exact existing twelve-sided tapered facet planes; it does not pretend the curved tower is the planar five-range front. Default geometry is preserved. All new joinery, glazing, dimensions and facet assignment are reconstructed; no new door/apron is asserted.

`light-check.json`:25 default parameter/API parity,66 actual emitted window-kit faces/132 triangles, no zero-area faces, exact facet planes/outward winding, invalid input refusal, one reused lantern-glass material, record schema and patch check. No Blender/browser was run for this package.

`grade-check.json` uses actual previously exported broad/narrow masters and real app readers. Broad anchor2.472863m; narrow2.474625m, a1.76mm increase. No metre-scale bedding fault was found. `photo_match` uses flat zero grade, so its apparent low foot cannot identify app terrain error. `vertical-check.json` shows that translating the whole tower/frame upward17.45px aligns endpoints but leaves the gallery22.45px too high. Correcting shaft/lantern subdivision is therefore the concrete next geometry trial, while40ft height datum remains unresolved.

The subsequent `/tmp/chicago-next-model/T-2373-profile-next` composes this aperture idea with compatible five-range controls and an explicit reconstructed profile. Its camera/profile predictions remain unreviewed until a future approved preview slot. Frozen narrow receipts are untouched; every original image gate remains open.
