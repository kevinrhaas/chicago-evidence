#!/usr/bin/env bash
# Prepared only. Parent runs after export and explicit quiet-period signal.
set -euo pipefail
fort_package="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fort_run="$(cat "$fort_package/latest-run.txt")"
test -f "$fort_run/export-verification.json"
for fort_kind in baseline proposed; do
  cd "$fort_run/$fort_kind"
  for fort_view in first-fort-panel-1 second-fort-panel-5 lighthouse-castelnau-provisional; do
    PW_EXECUTABLE="${PW_EXECUTABLE:-/usr/bin/chromium}" node tools/photo_match.mjs "docs/RESEARCH/fort-combined-review/$fort_view.json" --out "$fort_run/reviews/$fort_kind" > "$fort_run/$fort_kind-$fort_view.log" 2>&1
  done
done
