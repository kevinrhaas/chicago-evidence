from pathlib import Path
p=Path('/tmp/chicago-next-model/fort-combined/prepare.py');s=p.read_text()
anchor="fragments=out/'liberty-fragments';fragments.mkdir(exist_ok=True)\n"
insert='''# Add the independently tested opt-in first-fort upper gallery.
gallery=Path('/tmp/chicago-next-model/T-2387-gallery')
replace(params,'"gallery", "loopholes"','"gallery", "gallery_storeys", "loopholes"')
replace(params,'    gallery: bool = False\\n',\'''    gallery: bool = False

    # Opt-in double gallery; one preserves the original single canopy exactly.
    # The upper walk is pictured retrospectively, not a measured 1808 elevation.
    gallery_storeys: int = 1
\''')
replace(params,'        if not isinstance(self.cupola, bool):\\n',\'''        if (not isinstance(self.gallery_storeys, int) or isinstance(self.gallery_storeys, bool)
                or self.gallery_storeys not in (1, 2)):
            raise ParamError("gallery_storeys must be the whole number 1 or 2")
        if self.gallery_storeys == 2:
            if not self.gallery or self.kind not in ("quarters", "barracks"):
                raise ParamError("a double gallery requires gallery=true on quarters or barracks")
            if self.stories != 2:
                raise ParamError("a double gallery requires a two-storey range")

        if not isinstance(self.cupola, bool):
\''')
replace(params,'        gallery=bool(val("gallery", False)),','        gallery=bool(val("gallery", False)),\\n        gallery_storeys=val("gallery_storeys", 1),')
gs=(gallery/'files/generators/archetypes/fort_structure.py').read_text()
replace(generator,function_text(after[generator],'_gallery'),function_text(gs,'_gallery'))
replace(generator,'def _chimneys(',function_text(gs,'_gallery_two_storeys')+'\\n\\ndef _chimneys(')
# Geometry includes reconstructed sections even when the profile's occurrence is inferred.
old_conf='    c = p.worst_conf("lantern", "lantern_profile")'
if old_conf in after[generator]:
 replace(generator,old_conf,'    # Every emitted primitive includes reconstructed counts, sections or curve.\\n    c = 1.0')
for f in (gallery/'files/data/structures').glob('*.json'):
 after['chicago/4d/data/structures/'+f.name]=f.read_text()
f=gallery/'files/data/sources/currey_1912_first_fort_birdseye.json'
after['chicago/4d/data/sources/'+f.name]=f.read_text()
'''
assert anchor in s;s=s.replace(anchor,insert+'\n'+anchor)
anchor="for name,text in frags.items():(fragments/name).write_text(text)\n"
new="frags['first-fort-galleries.md']=(gallery/'LIBERTY-APPEND.md').read_text().replace('**Recorded:** proposed during T-3041 work; parent stamps the integration date.','**Recorded:** 2026-10-22 (T-3041; proposal, not a match).')\n"+anchor
assert anchor in s;s=s.replace(anchor,new)
s=s.replace("changed=['chicago_lighthouse_1832','fort_dearborn_blockhouse','first_fort_dearborn_blockhouse_nw','first_fort_dearborn_blockhouse_se']","changed=['chicago_lighthouse_1832','fort_dearborn_blockhouse','first_fort_dearborn_blockhouse_nw','first_fort_dearborn_blockhouse_se']+[json.loads(f.read_text())['id'] for f in (gallery/'files/data/structures').glob('*.json')]")
s=s.replace("['T-2388-next','T-2373','T-2387-next']","['T-2388-next','T-2373','T-2387-next','T-2387-gallery']")
p.write_text(s)
p=Path('/tmp/chicago-next-model/fort-combined/focused_check.py');s=p.read_text();s=s.replace("['cupola','cupola_width_m','cupola_height_m','cupola_roof_pitch_deg']: data.pop(field)","['cupola','cupola_width_m','cupola_height_m','cupola_roof_pitch_deg','gallery_storeys']: data.pop(field)")
s=s.replace("'cupola_roof_pitch_deg','lantern_profile'}\")","'cupola_roof_pitch_deg','lantern_profile','gallery_storeys'}\")")
# Insert gallery suite with only its five opted-in records selected from the combined fixture.
anchor="m=types.ModuleType('fort_combined_params');"
insert="""gs=Path('/tmp/chicago-next-model/T-2387-gallery/check_proposal.py').read_text()
gs=gs.replace(\"FILES=HERE/'files'\",\"FILES=HERE/'candidate/chicago/4d'\")
gs=gs.replace(\"for path in sorted((FILES/'data/structures').glob('*.json')):\",\"for path in sorted((FILES/'data/structures').glob('*.json')):\\n if 'gallery_storeys' not in json.loads(path.read_text())['phases'][0]['form']: continue\")
gs=gs.replace(\"base=json.loads(next((FILES/'data/structures').glob('*.json')).read_text())\",\"base=json.loads(next(p for p in (FILES/'data/structures').glob('*.json') if 'gallery_storeys' in json.loads(p.read_text())['phases'][0]['form']).read_text())\")
gs=gs.replace(\"for path in (FILES/'data/structures').glob('*.json'):\",\"for path in (FILES/'data/structures').glob('*.json'):\\n if 'gallery_storeys' not in json.loads(path.read_text())['phases'][0]['form']: continue\")
gs=gs.replace(\"HERE/'lightweight-checks.json'\",\"HERE/'gallery-focused-check.json'\")
exec(compile(gs,'gallery-independent-focused-suite','exec'),{'__name__':'__main__','__file__':str(out/'gallery-focused-check.py')})
"""
assert anchor in s;s=s.replace(anchor,insert+anchor);p.write_text(s)
