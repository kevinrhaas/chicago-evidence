"""Create a disposable export/review fixture under this package; no repository writes."""
from pathlib import Path
import datetime,hashlib,json,shutil
out=Path(__file__).resolve().parent;repo=Path('/workspace/chicago/chicago/4d');candidate=out/'candidate/chicago/4d'
meta=json.loads((out/'input-snapshot.json').read_text())
for rel,want in meta['input_sha256'].items():
 p=Path('/workspace/chicago')/rel;actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
 if actual!=want:raise RuntimeError(f'{rel} changed; rerun prepare.py and focused_check.py first')
scope=json.loads((out/'freshness-scope.json').read_text());stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S-%f');run=out/'runs'/stamp
assert run.resolve().is_relative_to(out.resolve()) and not run.exists()
run.mkdir(parents=True)
for kind in ['baseline','proposed']:
 root=run/kind;root.mkdir()
 # Copies, not symlinks: no exporter can overwrite a repository mesh or manifest.
 shutil.copytree(repo/'generators',root/'generators',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 for rel in ['data/scenes','renderers/web/vendor/three-0.185.1']:
  shutil.copytree(repo/rel,root/rel)
 for rel in ['data/datum.json','renderers/web/js/keith-stone.js','tools/photo_match.mjs','tools/photo_match_group.mjs','tools/render_structure_review.py']:
  p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/rel,p)
 node_dependencies=Path('/workspace/node_modules').resolve()
 assert node_dependencies.is_dir(),node_dependencies
 (root/'node_modules').symlink_to(node_dependencies,target_is_directory=True)
 cameras={}
 for name in ['first-fort-panel-1','second-fort-panel-5']:
  camera=json.loads((repo/f'docs/RESEARCH/fort-reference-groups-T-3040/{name}.json').read_text());photo=(repo/f'docs/RESEARCH/fort-reference-groups-T-3040'/camera['photo']).resolve();dest=root/'data/sources/assets'/photo.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(photo,dest);camera['photo']='../../../data/sources/assets/'+photo.name;cameras[name]=camera
 camera=json.loads(Path('/tmp/chicago-next-model/T-2373/castelnau-provisional.json').read_text());photo=Path(camera['photo']);dest=root/'data/sources/assets'/photo.name;shutil.copy2(photo,dest);camera['photo']='../../../data/sources/assets/'+photo.name;cameras['lighthouse-castelnau-provisional']=camera
 all_ids={row['structure_id'] for row in scope['assets']}
 for name,camera in cameras.items():
  all_ids.add(camera['structure_id']);all_ids.update(camera.get('also_render',[]));p=root/f'docs/RESEARCH/fort-combined-review/{name}.json';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(camera,indent=2)+'\n')
 manifest=json.loads((repo/'assets/manifest.json').read_text());assets=manifest.get('assets',manifest);selected={k:v for k,v in assets.items() if isinstance(v,dict) and v.get('structure_id') in all_ids}
 for sid in sorted(all_ids):
  src=repo/f'data/structures/{sid}.json';dst=root/f'data/structures/{sid}.json';dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
  for scene in ['1812','1835']:
   src=repo/f'data/sidecars/{scene}/{sid}.json'
   if src.exists():dst=root/f'data/sidecars/{scene}/{sid}.json';dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
  if (repo/f'data/structures/versions/{sid}').exists():raise RuntimeError(f'{sid}: selected alternate versions need explicit fixture inclusion')
 for asset in selected:
  dst=root/'assets/gltf'/asset;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/'assets/gltf'/asset,dst)
 manifest['assets']=selected;(root/'assets/manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
 for source in ['kurz_allison_1893','castelnau_1842_chicago_harbor','currey_1912_first_fort_birdseye']:
  rel=f'data/sources/{source}.json';src=candidate/rel if (candidate/rel).exists() else repo/rel;dst=root/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
 if kind=='proposed':
  for p in candidate.rglob('*'):
   if p.is_file():dst=root/p.relative_to(candidate);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
 (root/'FIXTURE-ONLY.txt').write_text('Disposable isolated fort export/review fixture; not a complete development checkout.\n')
(run/'scope.json').write_text(json.dumps(scope,indent=2)+'\n');(out/'latest-run.txt').write_text(str(run)+'\n')
print(run)
