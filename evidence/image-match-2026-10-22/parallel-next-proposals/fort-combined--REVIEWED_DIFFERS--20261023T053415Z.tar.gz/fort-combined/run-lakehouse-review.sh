#!/usr/bin/env bash
# Prepared diagnostic renders only; parent schedules after its quiet gate.
set -euo pipefail
fort_package="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fort_run="$(cat "$fort_package/latest-run.txt")"
test -f "$fort_run/export-verification.json"
source "$fort_run/proposed/generators/blender.pin"
fort_binary="/workspace/shared/blender-dl/$BLENDER_DIR/blender"
for fort_kind in baseline proposed; do
  BLENDER_USER_CONFIG="$fort_run/blender-config" "$fort_binary" -b -noaudio --factory-startup --python "$fort_package/lakehouse_review.py" -- --glb "$fort_run/$fort_kind/assets/gltf/lake_house_construction__shell_1835.glb" --out "$fort_run/reviews/$fort_kind-lakehouse-diagnostic" --cameras shell-overhead,shell-oblique --size 800 --samples 16 --threads 2 --sky overcast > "$fort_run/$fort_kind-lakehouse-diagnostic.log" 2>&1
done
