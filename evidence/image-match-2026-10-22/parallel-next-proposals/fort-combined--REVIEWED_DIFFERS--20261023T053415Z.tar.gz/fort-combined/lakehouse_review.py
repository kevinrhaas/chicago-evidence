"""Run inside pinned Blender: fixed diagnostic cameras, no historical image claim."""
from pathlib import Path
import runpy
# The driver itself lives outside the disposable fixture; argv's --glb is authoritative.
import sys
args=sys.argv[sys.argv.index('--')+1:]
glb=Path(args[args.index('--glb')+1]).resolve();fixture=glb.parents[2]
ns=runpy.run_path(str(fixture/'tools/render_structure_review.py'),run_name='fort_lakehouse_diagnostic_renderer')
ns['CAMERAS'].clear();ns['CAMERAS'].update({
 'shell-overhead':{'position':(12,7.5,42),'target':(12,7.5,0),'lens':40},
 'shell-oblique':{'position':(40,-25,25),'target':(12,7.5,2),'lens':45},
})
ns['main']()
