"""Compose independent proposals under /tmp; never write the project checkout."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
out=Path(__file__).resolve().parent;repo=Path('/workspace/chicago');candidate=out/'candidate'
cupola=Path('/tmp/chicago-next-model/T-2388-next/candidate');light=Path('/tmp/chicago-next-model/T-2373');first=Path('/tmp/chicago-next-model/T-2387-next')
params='chicago/4d/generators/archetypes/fort_structure_params.py';generator='chicago/4d/generators/archetypes/fort_structure.py';lib='chicago/4d/docs/LIBERTIES.md'
after={params:(cupola/params).read_text(),generator:(cupola/generator).read_text()}
def replace(rel,old,new):
 s=after[rel];assert s.count(old)==1,(rel,old[:60],s.count(old));after[rel]=s.replace(old,new)
replace(params,'PAINTS = ("unpainted", "whitewash", "white", "brick", "earth", "stone")','PAINTS = ("unpainted", "whitewash", "white", "brick", "earth", "stone")\nLANTERN_PROFILES = ("legacy", "birdcage_dome")')
replace(params,'"upper_overhang_m", "lantern", "cupola",','"upper_overhang_m", "lantern", "lantern_profile", "cupola",')
replace(params,'    lantern: bool = False\n','''    lantern: bool = False
    # T-2373: pictured dome, cage and gallery rail. The default retains the
    # previous drum/pyramid; this profile has effect only on a lit tower.
    lantern_profile: str = "legacy"
''')
replace(params,'    def validate(self) -> None:\n','''    def validate(self) -> None:
        if self.lantern_profile not in LANTERN_PROFILES:
            raise ParamError(
                f"lantern_profile {self.lantern_profile!r} not in {LANTERN_PROFILES}")
        if self.lantern_profile != "legacy" and (
                self.kind != "tower" or not self.lantern):
            raise ParamError("lantern_profile needs kind tower and lantern true")
''')
replace(params,'        lantern=bool(val("lantern", False)),','        lantern=bool(val("lantern", False)),\n        lantern_profile=str(val("lantern_profile", "legacy")),')
def function_text(text,name):
 node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name==name)
 lines=text.splitlines(keepends=True);return ''.join(lines[node.lineno-1:node.end_lineno])
ls=(light/'fort_structure.proposed.py').read_text()
replace(generator,function_text(after[generator],'_tower'),function_text(ls,'_tower'))
after[generator]+='\n\n'+function_text(ls,'_birdcage_lantern')
second='chicago/4d/data/structures/fort_dearborn_blockhouse.json';after[second]=(cupola/second).read_text()
lighthouse='chicago/4d/data/structures/chicago_lighthouse_1832.json';after[lighthouse]=(light/'proposed-structure.json').read_text()
source='chicago/4d/data/sources/castelnau_1842_chicago_harbor.json';after[source]=(light/'proposed-source.json').read_text()
for suffix in ['nw','se']:
 rel=f'chicago/4d/data/structures/first_fort_dearborn_blockhouse_{suffix}.json';after[rel]=(first/f'first_fort_dearborn_blockhouse_{suffix}.json').read_text()
# Add the independently tested opt-in first-fort upper gallery.
gallery=Path('/tmp/chicago-next-model/T-2387-gallery')
replace(params,'"gallery", "loopholes"','"gallery", "gallery_storeys", "loopholes"')
replace(params,'    gallery: bool = False\n','''    gallery: bool = False

    # Opt-in double gallery; one preserves the original single canopy exactly.
    # The upper walk is pictured retrospectively, not a measured 1808 elevation.
    gallery_storeys: int = 1
''')
replace(params,'        if not isinstance(self.cupola, bool):\n','''        if (not isinstance(self.gallery_storeys, int) or isinstance(self.gallery_storeys, bool)
                or self.gallery_storeys not in (1, 2)):
            raise ParamError("gallery_storeys must be the whole number 1 or 2")
        if self.gallery_storeys == 2:
            if not self.gallery or self.kind not in ("quarters", "barracks"):
                raise ParamError("a double gallery requires gallery=true on quarters or barracks")
            if self.stories != 2:
                raise ParamError("a double gallery requires a two-storey range")

        if not isinstance(self.cupola, bool):
''')
replace(params,'        gallery=bool(val("gallery", False)),','        gallery=bool(val("gallery", False)),\n        gallery_storeys=val("gallery_storeys", 1),')
gs=(gallery/'files/generators/archetypes/fort_structure.py').read_text()
replace(generator,function_text(after[generator],'_gallery'),function_text(gs,'_gallery'))
replace(generator,'def _chimneys(',function_text(gs,'_gallery_two_storeys')+'\n\ndef _chimneys(')
# Geometry includes reconstructed sections even when the profile's occurrence is inferred.
old_conf='    c = p.worst_conf("lantern", "lantern_profile")'
if old_conf in after[generator]:
 replace(generator,old_conf,'    # Every emitted primitive includes reconstructed counts, sections or curve.\n    c = 1.0')
for f in (gallery/'files/data/structures').glob('*.json'):
 after['chicago/4d/data/structures/'+f.name]=f.read_text()
f=gallery/'files/data/sources/currey_1912_first_fort_birdseye.json'
after['chicago/4d/data/sources/'+f.name]=f.read_text()

# Implement the already-declared roofless Lake House state, keeping flat unchanged.
lake=Path('/tmp/chicago-next-model/T-2379')
roof_source=(lake/'proposed/chicago/4d/generators/archetypes/fort_structure.py').read_text()
replace(generator,function_text(after[generator],'_roof'),function_text(roof_source,'_roof'))
after['chicago/4d/data/structures/lake_house_construction.json']=(lake/'proposed/chicago/4d/data/structures/lake_house_construction.json').read_text()

fragments=out/'liberty-fragments';fragments.mkdir(exist_ok=True)
def additions(patch,start):
 text=Path(patch).read_text();text=text[text.index(start):]
 return '\n'.join(line[1:] for line in text.splitlines() if line.startswith('+') and not line.startswith('+++'))+'\n'
frags={
 'second-fort-cupola-2388.md':additions('/tmp/t3040-next-parcels/T-2388.patch','diff --git a/'+lib),
 'lighthouse-birdcage-2373.md':additions(light/'T-2373.patch','--- a/'+lib),
 'first-fort-chimneys-3041.md':'''\n\n### L-first-fort-pictured-blockhouse-stacks-3041 — Retire two reconstructed stacks

**Decision:** Remove the separate reconstructed chimney from each first-fort
blockhouse, following the silhouette in public-domain Kurz & Allison panel 1
(`kurz_allison_1893`, crop `p4_0.png`). Both pictured blockhouses carry small
roof lanterns and no separate stack, while barracks stacks are plainly drawn.
The resulting zero is an inferred picture-based model choice, not proof of
historical absence, lack of heating, or contemporary eyewitness evidence.
**Supersedes:** L370's one-stack reconstruction for these two blockhouses only.
Keep L370's historical entry and its other roof, height and jetty choices.
**What is retained:** surveyed placements, footprints, bearing, roof dimensions
and the documented 75 ft staff. The first-fort lanterns remain unbuilt; enabling
a second-fort cupola does not enable or date either first-fort lantern.
**How to resolve:** render before/after, retain the unresolved lantern and tower
arrangement differences, and keep the full T-2387 match open.
**Covers:** `first_fort_dearborn_blockhouse_nw.first_fort_1803.form.chimneys`,
`first_fort_dearborn_blockhouse_se.first_fort_1803.form.chimneys`.
**Ticket:** T-3041 (increment under T-2387).
**Recorded:** 2026-10-22.
'''}
frags['first-fort-galleries.md']=(gallery/'LIBERTY-APPEND.md').read_text().replace('**Recorded:** proposed during T-3041 work; parent stamps the integration date.','**Recorded:** 2026-10-22 (T-3041; proposal, not a match).')
frags['lake-house-roofless-2379.md']='\n\n'+(lake/'liberty.md').read_text()
for name,text in frags.items():(fragments/name).write_text(text)
after[lib]=(repo/lib).read_text()+''.join(frags.values())
# An optional gallery parcel is composed later after its own focused review.
for rel,text in after.items():
 p=candidate/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 if rel.endswith('.py'):compile(text,rel,'exec')
 if rel.endswith('.json'):json.loads(text)
manifest=json.loads((repo/'chicago/4d/assets/manifest.json').read_text());assets=manifest.get('assets',manifest)
rows=[{'asset':k,**{q:v[q] for q in ['structure_id','phase_id','archetype']},'baseline_sha256':hashlib.sha256((repo/'chicago/4d/assets/gltf'/k).read_bytes()).hexdigest()} for k,v in assets.items() if isinstance(v,dict) and v.get('archetype')=='fort_structure']
changed=['lake_house_construction','chicago_lighthouse_1832','fort_dearborn_blockhouse','first_fort_dearborn_blockhouse_nw','first_fort_dearborn_blockhouse_se']+[json.loads(f.read_text())['id'] for f in (gallery/'files/data/structures').glob('*.json')]
(out/'freshness-scope.json').write_text(json.dumps({'recipe_stale_count':len(rows),'intended_changed_geometry':changed,'assets':rows,'why':'Shared fort_structure.py bytes and new resolved dataclass fields affect all25 recipes; no manual freshness rewrite is proposed.'},indent=2)+'\n')
(out/'structure-ids.txt').write_text(','.join(row['structure_id'] for row in rows)+'\n')
patch='';hashes={}
for rel,text in after.items():
 before=(repo/rel).read_text() if (repo/rel).exists() else ''
 hashes[rel]=hashlib.sha256(before.encode()).hexdigest() if before else None
 patch+='diff --git a/'+rel+' b/'+rel+'\n'+('new file mode 100644\n' if not before else '')+''.join(difflib.unified_diff(before.splitlines(keepends=True),text.splitlines(keepends=True),fromfile='a/'+rel if before else '/dev/null',tofile='b/'+rel))
(out/'fort-combined.patch').write_text(patch)
(out/'input-snapshot.json').write_text(json.dumps({'base_head':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'input_sha256':hashes,'repository_changed':False,'packages_preserved':['T-2388-next','T-2373','T-2387-next','T-2387-gallery','T-2379']},indent=2)+'\n')
print('Prepared',len(after),'files and',len(rows),'recipe-stale masters; no repository files changed.')
