"""Both independent focused suites against composed code; no Blender/browser."""
from pathlib import Path
import dataclasses,hashlib,json,sys,types
out=Path(__file__).resolve().parent;repo=Path('/workspace/chicago');c=out/'candidate'
meta=json.loads((out/'input-snapshot.json').read_text())
for rel,want in meta['input_sha256'].items():
 p=repo/rel;actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
 if actual!=want:raise RuntimeError(f'{rel} changed; rerun prepare.py before focused checks')
params=c/'chicago/4d/generators/archetypes/fort_structure_params.py';gen=c/'chicago/4d/generators/archetypes/fort_structure.py'
(out/'fort_structure.proposed.py').write_text(gen.read_text());(out/'fort_structure_params.proposed.py').write_text(params.read_text());(out/'proposed-structure.json').write_text((c/'chicago/4d/data/structures/chicago_lighthouse_1832.json').read_text())
# Preserve independent suites; adapt only fixture paths/default-field comparisons/output names.
ls=Path('/tmp/chicago-next-model/T-2373/focused_check.py').read_text()
ls=ls.replace("out=Path('/tmp/chicago-next-model/T-2373')",f'out=Path({str(out)!r})')
ls=ls.replace("data=asdict(b);assert data.pop('lantern_profile')=='legacy'","data=asdict(b);assert data.pop('lantern_profile')=='legacy'\n  for field in ['cupola','cupola_width_m','cupola_height_m','cupola_roof_pitch_deg','gallery_storeys']: data.pop(field)")
ls=ls.replace("out/'focused-check.json'","out/'lighthouse-focused-check.json'")
ls=ls.replace("assert detail.named.keys()=={'lantern_glass'}", "assert detail.named.keys()=={'lantern_glass'}\nlantern_only=Collect();radius=selected.width_m/2\nb['_birdcage_lantern'](lantern_only,selected,radius,radius,radius*selected.taper,selected.wall_height_m*.86,selected.wall_height_m)\nassert all(conf==1.0 for _,conf,_ in lantern_only.faces), 'invented lantern geometry must be reconstructed'")
exec(compile(ls,'lighthouse-independent-focused-suite','exec'),{'__name__':'__main__','__file__':str(out/'lighthouse-focused-check.py')})
cs=Path('/tmp/chicago-next-model/T-2388-next/verify.py').read_text()
start=cs.index("meta=json.loads((out/'recovery.json').read_text())");end=cs.index('# Keep new numeric field types',start);cs=cs[:start]+cs[end:]
cs=cs.replace("new_keys={'cupola','cupola_width_m','cupola_height_m','cupola_roof_pitch_deg'}","new_keys={'cupola','cupola_width_m','cupola_height_m','cupola_roof_pitch_deg','lantern_profile','gallery_storeys'}")
start=cs.index('# Refresh a valid unified diff');end=cs.index('report={',start);cs=cs[:start]+cs[end:]
cs=cs.replace("out/'verification.json'","out/'cupola-focused-check.json'")
exec(compile(cs,'cupola-independent-focused-suite','exec'),{'__name__':'__main__','__file__':str(out/'cupola-focused-check.py')})
gs=Path('/tmp/chicago-next-model/T-2387-gallery/check_proposal.py').read_text()
gs=gs.replace("FILES=HERE/'files'","FILES=HERE/'candidate/chicago/4d'")
gs=gs.replace("for path in sorted((FILES/'data/structures').glob('*.json')):","for path in sorted((FILES/'data/structures').glob('*.json')):\n if 'gallery_storeys' not in json.loads(path.read_text())['phases'][0]['form']: continue")
gs=gs.replace("base=json.loads(next((FILES/'data/structures').glob('*.json')).read_text())","base=json.loads(next(p for p in (FILES/'data/structures').glob('*.json') if 'gallery_storeys' in json.loads(p.read_text())['phases'][0]['form']).read_text())")
gs=gs.replace("for path in (FILES/'data/structures').glob('*.json'):","for path in (FILES/'data/structures').glob('*.json'):\n if 'gallery_storeys' not in json.loads(path.read_text())['phases'][0]['form']: continue")
gs=gs.replace("HERE/'lightweight-checks.json'","HERE/'gallery-focused-check.json'")
exec(compile(gs,'gallery-independent-focused-suite','exec'),{'__name__':'__main__','__file__':str(out/'gallery-focused-check.py')})
lake=Path('/tmp/chicago-next-model/T-2379/check_proposal.py').read_text()
lake=lake.replace("PROP=Path('/tmp/chicago-next-model/T-2379/proposed/chicago/4d')",f"PROP=Path({str(c/'chicago/4d')!r})")
exec(compile(lake,'lake-house-independent-focused-suite','exec'),{'__name__':'__main__','__file__':str(out/'lake-house-focused-check.py')})
m=types.ModuleType('fort_combined_params');sys.modules[m.__name__]=m;exec(compile(params.read_text(),str(params),'exec'),m.__dict__)
changed={}
for sid in ['first_fort_dearborn_blockhouse_nw','first_fort_dearborn_blockhouse_se']:
 p=c/f'chicago/4d/data/structures/{sid}.json';new=json.loads(p.read_text());old=json.loads((repo/f'chicago/4d/data/structures/{sid}.json').read_text());old_form=old['phases'][0]['form'];new_form=new['phases'][0]['form'];q=m.from_phase(new['phases'][0],new)
 assert q.chimneys==0 and q.cupola is False and q.lantern_profile=='legacy'
 assert new['phases'][0]['position']==old['phases'][0]['position'] and new['phases'][0]['footprint']==old['phases'][0]['footprint']
 assert {k:v for k,v in new_form.items() if k!='chimneys'}=={k:v for k,v in old_form.items() if k!='chimneys'}
 changed[sid]={'chimneys':q.chimneys,'cupola':q.cupola,'unchanged_position_footprint_and_other_form':True}
report={'status':'passed','independent_lighthouse_suite':json.loads((out/'lighthouse-focused-check.json').read_text())['status'],'independent_cupola_suite':json.loads((out/'cupola-focused-check.json').read_text())['parameter_validation'],'gallery_suite':json.loads((out/'gallery-focused-check.json').read_text())['invalid_value_and_incompatible_kind_checks'],'lake_house_roof_suite':'passed','first_fort_data_only_checks':changed,'fort_master_count':len(json.loads((out/'freshness-scope.json').read_text())['assets']),'repository_changed':False,'heavy_jobs_run':False}
(out/'combined-focused-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
