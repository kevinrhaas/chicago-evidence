
### L-lighthouse-birdcage-2373 — the lighthouse's pictured lantern silhouette

**Covers:** chicago_lighthouse_1832.tower_1832.form.lantern_profile.
**Read:** the committed Castelnau harbour lithograph, attributed in IMAGE_SOURCES.md
to a circa 1838 view published by A.Bertrand in 1842, shows a rounded cap, finial,
cage uprights and gallery rail. lighthousefriends_chicago names a bird-cage lantern
on the 1832 tower. The later picture bounds an inferred 1835 profile by continuity;
it does not attest unchanged detail on 1 July 1835.
**Reconstructed:** eight 55 mm square cage uprights, twelve 45 mm square gallery posts,
a 650 mm rail with a 55 by 50 mm top ring;60 mm lower/upper cage collars. The gallery
radius remains 1.34 times the shaft's top radius and its slab 90 mm thick; the lantern
radius remains 0.86 times that radius. The rounded cap's horizontal radius is
1.06 times the lantern radius, its rise 0.55 times the shaft-top radius; its profile
is a six-band ellipsoid, not a measured dome. The finial is 0.15 times that radius
high, radius max(25 mm,0.025 times shaft-top radius). Member counts, exact frame
layout and hidden joints are choices within the pictured silhouette. Pane tone
uses the shared reconstructed GLASS row; roof and dark-frame finish are review
proxies, not claimed historic paint or metal colour. The reflectors remain absent.
**Not resolved:** the existing tower width, taper, shaft/lantern split and total
height interpretation. The new cap/finial keeps the previous maximum height:
nominal 12.19 m plus 0.7 times the shaft-top radius. Andreas's forty feet may include
the cap; the current reconstruction does not settle that. Bare-stone paint stays
reconstructed. A monochrome lithograph is no paint sample. No footprint,
position or surveyed camera is derived from this sheet.
**How to resolve:** fit and compare actual reference views after a pinned bake;
read remaining profile/proportion differences, and use a contemporary elevation
or specification to replace the reconstructed counts and sections.
**Ticket:** T-2373. The full picture-matching acceptance stays open.
**Recorded:** 2026-10-22.
