### L-first-fort-double-galleries — the upper courtyard walks

**Decision:** the five first-fort ranges that already carry attested galleries
receive an inferred two-level treatment: an upper walk over the open ground
level, with vertical rail pales and a roof meeting the existing main eave.
Whistler's 1808 note supplies two-storey barracks and galleries fronting the
parade but does not count the gallery levels. The upper walk and balustrade are
read from the later reconstruction published at p. 27 of Currey's *The Story of
Old Fort Dearborn* (1912), now registered separately as
`currey_1912_first_fort_birdseye`. The count is inferred, not contemporary
attestation; the picture does not independently identify every existing record's
interior face. Carrying the treatment to all five corresponding garrison ranges
is an explicitly stated interpretation, not a measured elevation of each one.

**Reconstructed dimensions:** retain the old gallery's 2.1 m reach and nominal
3 m post-bay spacing. Set posts to 0.14 m square, upper floor thickness to 0.14 m,
handrail height to 0.95 m, handrail section to 0.10 x 0.14 m, square pales to
0.055 m at an at-most-0.18 m pitch, and canopy fall to 0.45 m across the reach
plus a 0.15 m outer projection. Upper floor height is half the existing 5.0 m
wall (2.5 m); the roof attaches at that wall's eave and falls to 4.55 m. End
returns of the upper rail are a safety reconstruction. No exterior stair is
invented. New gallery geometry carries reconstructed confidence even though
gallery occurrence remains attested and the chosen two-level count is inferred.

**Bounds:** first Fort Dearborn, ending before 16 August 1812; only
`gallery_storeys: 2` opts into this form. The old one-canopy form is byte-for-byte
unchanged at the helper's geometry-call level when the option is absent. Nothing
is added to the second fort, the lighthouse or other ranges without a record
opting in. The 1912 plate is tier 5, not eyewitness evidence, a height scale,
coordinate, plan or bearing. Its central gateway building and magazine layout
do not overrule Whistler's contemporary measured register. Keep L370's remaining
height/roof/plan-depth choices and the earlier gallery existence source.

**How to resolve:** a contemporary elevation, dimensioned gallery drawing,
quartermaster estimate or construction account could replace the metric choices
or decide whether a particular range had the upper walk. Meanwhile the scene
shows the declared inference rather than a ground-only canopy that fails the
pictured courtyard treatment.

**Covers:** `first_fort_dearborn_commanding_officers_barracks.first_fort_1803.form.gallery_storeys`, `first_fort_dearborn_north_range.first_fort_1803.form.gallery_storeys`, `first_fort_dearborn_officers_barracks.first_fort_1803.form.gallery_storeys`, `first_fort_dearborn_soldiers_barracks_se.first_fort_1803.form.gallery_storeys`, `first_fort_dearborn_soldiers_barracks_sw.first_fort_1803.form.gallery_storeys`.

**Recorded:** 2026-10-22 (T-3041; proposal, not a match).
