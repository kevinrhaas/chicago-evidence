

### L-first-fort-pictured-blockhouse-stacks-3041 — Retire two reconstructed stacks

**Decision:** Remove the separate reconstructed chimney from each first-fort
blockhouse, following the silhouette in public-domain Kurz & Allison panel 1
(`kurz_allison_1893`, crop `p4_0.png`). Both pictured blockhouses carry small
roof lanterns and no separate stack, while barracks stacks are plainly drawn.
The resulting zero is an inferred picture-based model choice, not proof of
historical absence, lack of heating, or contemporary eyewitness evidence.
**Supersedes:** L370's one-stack reconstruction for these two blockhouses only.
Keep L370's historical entry and its other roof, height and jetty choices.
**What is retained:** surveyed placements, footprints, bearing, roof dimensions
and the documented 75 ft staff. The first-fort lanterns remain unbuilt; enabling
a second-fort cupola does not enable or date either first-fort lantern.
**How to resolve:** render before/after, retain the unresolved lantern and tower
arrangement differences, and keep the full T-2387 match open.
**Covers:** `first_fort_dearborn_blockhouse_nw.first_fort_1803.form.chimneys`,
`first_fort_dearborn_blockhouse_se.first_fort_1803.form.chimneys`.
**Ticket:** T-3041 (increment under T-2387).
**Recorded:** 2026-10-22.
