# Fort-family isolated export and visual review

Reviewed 2026-10-23 against parent HEAD `6156a0367a2379f0d986b88c7c8236c4ebec0e55`.
Run: `runs/20261023-050131-135464`. The repository stayed read-only; every export,
manifest, camera, research result and screenshot is an isolated copy under /tmp.
All Blender/browser/server processes are closed. Bridge, then frame-family baseline
captures, received the released execution slot.

## Result and bounds

The combined proposal emits the intended four-ticket increment without changing the
other fifteen family masters relative to freshly rebuilt baselines. The actual
renders show the intended cupola, upper gallery, dome/cage and open Lake House shell.
All three historical comparisons still differ. None is a completed picture match,
an accepted camera solve, a full-scene QA pass, or grounds to close T-2373/T-2379/
T-2387/T-2388. No formal camera/review record was promoted to `matches`.

## Executed validation

- Cached Blender archive SHA256 matched `generators/blender.pin`; binary reported
  Blender 4.5.3 LTS. Baseline and proposed builds each wrote exactly the selected
  twenty-five canonical masters. Every command finished exit 0.
- All twenty-five proposed mesh recipes recompute current. Exactly ten proposed
  master byte streams changed against freshly rebuilt baselines; the remaining
  fifteen are byte-identical. The four independent focused suites also passed.
- Fifty master GLBs passed header/chunk/accessor bounds, exact structure/phase
  extras, triangle indices, finite POSITION/NORMAL/TEXCOORD_0/_CONFIDENCE data,
  optional _TONE finiteness, confidence range, unit normals, material resolution
  and no image-dependency checks. Zero zero-area triangles. Largest normal length
  error: 1.0612e-7. See `glb-contracts.json` in the run.
- Six same-camera historical side-by-side captures completed: baseline/proposed
  first fort (1812, thirty members), second fort (1835, all twenty-one members),
  and the isolated lighthouse. Eight diagnostic model renders also completed:
  baseline/proposed Lake House top and oblique, blockhouse, and officers' gallery.

Twenty of twenty-five rebuilt baseline files reproduce committed bytes exactly.
Five do not: lighthouse, second-fort barracks, commandant's quarters, guard house,
and store house. Their JSON, all index streams, positions, normals, confidence,
tone and materials are identical; only TEXCOORD_0 packing differs. UV differences
range from floating rounding to substantial island relocation (max 0.9322).
These are untextured masters with no AO bake in this run. Do not present them as
twenty-five byte-reproducible committed assets. See `baseline-binary-drift.json`;
fresh-before/fresh-after controlled comparisons isolate the proposed changes.

## Inspected actual images

### T-2388: second fort

`reviews/proposed/second-fort-panel-5-side-by-side.jpg` remains dramatically
different: the source is a low river-level, nearly facade-facing view spanning
the image, while this provisional camera looks steeply down and crowds the model
into the right half. Facade/storey proportions, range identity, galleries,
stockade arrangement and scene context still need work. That camera cannot size
or validate the cupola, and its point-fit residual is not a rendered agreement.

The same-camera diagnostic pair under `reviews/{baseline,proposed}-blockhouse-cupola-diagnostic/`
clearly shows the old centre stack replaced by a small capped square drum. It sits
cleanly in the main pyramid with no visible detached skirt or gross intersection.
This adds the pictured capped-roof feature seen on the right of Kurz & Allison
panel 5 (`p3_1.png`), but 1.8 m width, 1.2 m rise, 35-degree cap, eaves and three
vent bands remain chosen reconstructions. The print does not attest those details,
nor does a diagnostic camera calibrate them. The existing rectangular main-roof
proportions and reconstructed wall/window treatment remain unresolved.

### T-2387: first fort

`reviews/{baseline,proposed}/first-fort-panel-1-side-by-side.jpg` visibly remove
the two distinct blockhouse chimney stacks. Their pictured roof lanterns remain
absent, so the silhouette is still incomplete. The seed camera/compound geometry
also disagree substantially in entrance position, curtain angle/length, roof and
blockhouse placement, staff framing and terrain. The long-gallery change is
largely hidden by this exterior view and is not validated by that comparison.

The officers' diagnostic pair under `reviews/{baseline,proposed}-upper-gallery-diagnostic/`
shows the old low single canopy replaced by a covered upper walk, rail pales,
closed end rails and an open lower level. The actual Currey 1912 local source
`chicago_fort_dearborn_birdseye_1812.jpg` was inspected: the visible courtyard
ranges show that general two-level treatment. Its retrospective composition does
not identify each of the five current named facades independently and cannot
override Whistler's surveyed plan. Metric sections and spacing are reconstructed;
access to the walk is unresolved and no external stair is invented. First-fort
lanterns are not enabled by the second-fort cupola option.

### T-2373: lighthouse

`reviews/{baseline,proposed}/lighthouse-castelnau-provisional-side-by-side.jpg`
shows a rounded cap and fine gallery rail replacing the old pointed cap and bare
ledge. The source has those broad features, but the tower shaft is conspicuously
too wide/tapered in this camera and the base is too far down. The source includes
a distinct stepped footing and context omitted from this isolated model render.
The cage reads very dark at the rendered scale; its glazing, bars, finial and
section dimensions remain reconstructed, not measurements from the print.
The retained 13.4052 m model height versus the nominal forty-foot/12.19 m reading
remains explicitly unresolved. This later scene (described as 1838, published
1842) does not prove the form was present on 1835-07-01.

### T-2379: Lake House

The top/oblique diagnostic pairs under `reviews/{baseline,proposed}-lakehouse-diagnostic/`
unambiguously show removal of the erroneous complete rectangular cap. The proposed
model is an open low wall perimeter with the review ground visible inside. It has
no represented floor, construction scaffolding or framing. These views confirm
the generator now respects `roof_type:none`; they do not attest that the historical
hotel was roofless on 1835-07-01. The June 10 notice supports construction activity
only, through a transcription-mediated claim. A later finished-hotel picture is
not used as an 1835 roof chronology or image gate.

## Integration and recovery

`fort-combined.patch` remains an unapplied fifteen-file cumulative proposal;
`candidate/` and all individual packages are preserved. Input files and appended
liberties were rebased to the parent commit before the run, and apply-check passed.
The isolated fixture uses the working `/workspace/node_modules` resolution for
future runs (the obsolete chicago node_modules symlink is not edited). Existing
browser captures succeeded through ancestor package resolution.

An integrating parent must still run the supported full family refresh/derivatives,
update generated scene/license/liberty coverage normally, inspect actual in-app
cards and models, measure budgets, and run required full gates. Do not copy fixture
manifests over the repository's full registry, remove old liberties, or accept
the provisional cameras. All twenty-five family recipes are in freshness scope;
new geometry belongs to ten masters, adding a net 5,284 triangles in those masters.
No source/date disagreement, original ticket or complete picture match is closed.
