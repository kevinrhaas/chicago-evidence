#!/usr/bin/env bash
set -euo pipefail
fort_package="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fort_run="$(cat "$fort_package/latest-run.txt")"
source "$fort_run/proposed/generators/blender.pin"
fort_binary="/workspace/shared/blender-dl/$BLENDER_DIR/blender"
for fort_kind in baseline proposed; do
  for fort_detail in blockhouse-cupola upper-gallery; do
    if [[ "$fort_detail" == blockhouse-cupola ]]; then
      fort_asset=fort_dearborn_blockhouse__log_1816.glb
    else
      fort_asset=first_fort_dearborn_officers_barracks__first_fort_1803.glb
    fi
    BLENDER_USER_CONFIG="$fort_run/blender-config" "$fort_binary" -b -noaudio --factory-startup --python "$fort_package/detail_review.py" -- --glb "$fort_run/$fort_kind/assets/gltf/$fort_asset" --out "$fort_run/reviews/$fort_kind-$fort_detail-diagnostic" --cameras "$fort_detail" --size 800 --samples 16 --threads 2 --sky overcast > "$fort_run/$fort_kind-$fort_detail-diagnostic.log" 2>&1
  done
done
