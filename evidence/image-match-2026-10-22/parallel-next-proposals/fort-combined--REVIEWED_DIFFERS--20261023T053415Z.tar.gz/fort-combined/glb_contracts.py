"""Inspect both isolated export sets; no checkout mutation or derivative writes."""
from pathlib import Path
import collections,hashlib,json,math,struct,sys
out=Path(__file__).resolve().parent
run=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path((out/'latest-run.txt').read_text().strip())
assert run.is_relative_to(out/'runs')
scope=json.loads((run/'scope.json').read_text())
def decode(path):
 raw=path.read_bytes();magic,version,length=struct.unpack_from('<III',raw)
 assert magic==0x46546c67 and version==2 and length==len(raw),(path,'header')
 off=12;doc=None;binary=None
 while off<len(raw):
  size,kind=struct.unpack_from('<II',raw,off);chunk=raw[off+8:off+8+size]
  assert len(chunk)==size
  if kind==0x4e4f534a:doc=json.loads(chunk)
  elif kind==0x004e4942:binary=chunk
  off+=8+size
 assert doc is not None and binary is not None and off==len(raw)
 def acc(i):
  a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']]
  assert not a.get('sparse')
  fmt={5120:'b',5121:'B',5122:'h',5123:'H',5125:'I',5126:'f'}[a['componentType']]
  n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']]
  width=struct.calcsize('<'+fmt*n);stride=v.get('byteStride',width)
  start=v.get('byteOffset',0)+a.get('byteOffset',0)
  assert a['count']>0 and start+(a['count']-1)*stride+width<=v.get('byteOffset',0)+v['byteLength']<=len(binary)
  vals=[struct.unpack_from('<'+fmt*n,binary,start+j*stride) for j in range(a['count'])]
  if a.get('normalized'):
   div={5120:127,5121:255,5122:32767,5123:65535}[a['componentType']]
   vals=[tuple(max(-1,x/div) for x in v) for v in vals]
  assert all(math.isfinite(x) for v in vals for x in v)
  return vals
 return doc,acc
rows=[]
for kind in ['baseline','proposed']:
 wrote=set((run/f'{kind}-wrote.txt').read_text().splitlines())
 assert wrote=={r['asset'] for r in scope['assets']}
 for row in scope['assets']:
  path=run/kind/'assets/gltf'/row['asset'];d,acc=decode(path)
  assert any(n.get('extras',{}).get('structure_id')==row['structure_id'] and n.get('extras',{}).get('phase_id')==row['phase_id'] for n in d['nodes'])
  count=0;normerr=0;zero=0;confs=collections.Counter();bounds=[[],[],[]]
  for mesh in d['meshes']:
   for p in mesh['primitives']:
    assert p.get('mode',4)==4
    a=p['attributes'];assert {'POSITION','NORMAL','TEXCOORD_0','_CONFIDENCE'}<=a.keys(),(row['asset'],a)
    pos=acc(a['POSITION']);normal=acc(a['NORMAL']);uv=acc(a['TEXCOORD_0']);confidence=acc(a['_CONFIDENCE']);tone=acc(a['_TONE']) if '_TONE' in a else [(0,)]*len(pos)
    assert len({len(pos),len(normal),len(uv),len(confidence),len(tone)})==1
    for v in pos:
     for axis in range(3):bounds[axis].append(v[axis])
    assert all(-1e-6<=x[0]<=1.000001 for x in confidence)
    confs.update(round(x[0],6) for x in confidence)
    normerr=max(normerr,max(abs(math.sqrt(sum(x*x for x in n))-1) for n in normal))
    assert normerr<.002,(row['asset'],normerr)
    indices=[x[0] for x in acc(p['indices'])];assert len(indices)%3==0 and all(0<=i<len(pos) for i in indices)
    count+=len(indices)//3
    for j in range(0,len(indices),3):
     v0,v1,v2=(pos[indices[j+k]] for k in range(3));u=[v1[k]-v0[k] for k in range(3)];v=[v2[k]-v0[k] for k in range(3)]
     cross=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
     if sum(x*x for x in cross)<1e-18:zero+=1
    assert 0<=p['material']<len(d['materials'])
  assert not d.get('images'),(row['asset'],'unexpected image dependency')
  rows.append({'kind':kind,'asset':row['asset'],'triangles':count,'max_normal_length_error':normerr,'zero_area_triangles':zero,'confidence_vertices':dict(confs),'gltf_bounds_min':[min(v) for v in bounds],'gltf_bounds_max':[max(v) for v in bounds],'materials':[m.get('name') for m in d['materials']]})
report={'status':'passed','export_sets':2,'exported_assets':len(rows),'checks':['complete GLB headers/chunks and binary-accessor bounds','exactly25 wrote assets per export','structure/phase extras','triangle topology and indices','finite positions, normals, UVs, confidence, tone','unit normals tolerance0.002','confidence range0to1','material index resolution','no external/image dependencies'],'assets':rows,'limitations':'Checks master GLBs only; no derivatives, texture/AO, full scene budget, accepted camera solve, repository gate or match verdict.'}
(run/'glb-contracts.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'passed','assets':len(rows),'zero_area_triangles':sum(r['zero_area_triangles'] for r in rows),'max_normal_error':max(r['max_normal_length_error'] for r in rows)},indent=2))
