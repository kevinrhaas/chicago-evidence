"""Pinned Blender diagnostic, reconstructed camera; no historical match claim."""
from pathlib import Path
import runpy,sys
args=sys.argv[sys.argv.index('--')+1:]
glb=Path(args[args.index('--glb')+1]).resolve();fixture=glb.parents[2]
ns=runpy.run_path(str(fixture/'tools/render_structure_review.py'),run_name='fort_detail_diagnostic_renderer')
ns['CAMERAS'].clear();ns['CAMERAS'].update({
 'blockhouse-cupola':{'position':(28,-22,20),'target':(7.26,4.9,5.0),'lens':45},
 'upper-gallery':{'position':(24,23,13),'target':(6.675,3,3),'lens':48},
})
ns['main']()
