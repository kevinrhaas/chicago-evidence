# Combined fort-family proposal — isolated, unapplied

This package composes four separately preserved proposals: T-2373 lighthouse,
T-2388 second-fort cupola, T-2387-next first-fort chimney removals, and the
T-2387-gallery upper walks, plus T-2379 roofless-shell correction. No repository code, manifest, asset or ticket was
edited. Pinned baseline/proposed exports and saved-image reviews completed on
2026-10-23. See `REVIEW.md` and `latest-run.txt` for the bounded results.

## Proposed visible changes

- Lighthouse: opt-in `lantern_profile=birdcage_dome` adds a rounded cap/finial,
  cage, gallery rail and the existing shared glass material. Its occurrence/profile
  remain inferred for 1835 from the view described as 1838 and published in 1842; every numeric lantern detail
  primitive is reconstructed (`c=1.0`). The retained total 13.4052 m versus nominal
  forty-foot/12.19 m interpretation remains unresolved.
- Second fort: only its blockhouse opts into `cupola=true`, with reconstructed
  1.8 m square drum, 1.2 m head above the main roof apex and 35-degree cap. The
  former reconstructed centre chimney is omitted instead of intersecting the
  cupola or silently inventing an offset stack.
- First fort: remove the unsupported separate stacks from its two blockhouses.
  Their pictured lanterns remain unbuilt; the second-fort option does not enable
  or date them. A dated 1808 absence is not a prohibition on later inference.
- First fort: five existing garrison ranges opt into `gallery_storeys=2`:
  commanding officers, north range, officers, soldiers SE and soldiers SW. Their
  upper walks are inferred from Currey's retrospective 1912 image; all sections,
  rails, deck and canopy dimensions remain reconstructed. One-storey/default
  galleries retain their old helper geometry exactly.

- Lake House: `roof_type:none` stops emitting the same cover as `flat`; this
  removes the erroneous360m²cap from the existing shell. Roofless progress remains
  reconstructed: the June10notice attests building activity, not roofing chronology.

All surveyed positions, footprints, bearings and existing range dates remain.
Source/date distinctions and unresolved complete picture matches remain explicit.

## Files and checks

`fort-combined.patch` is a valid cumulative 15-file unified diff against the input
snapshot. `candidate/` contains proposed files, not a Git checkout or complete app.
`sources` are in candidate/chicago/4d/data/sources; individual append-only liberty
texts are retained in `liberty-fragments/`. The original proposal directories were
not modified by this composition.

`prepare.py` composes independent fields and helper functions rather than replacing
one proposal with another. Run it again when the parent checkout changes, then run
`focused_check.py` and `git -C /workspace/chicago apply --check /tmp/chicago-next-model/fort-combined/fort-combined.patch`.
These steps only write inside this /tmp package. The source-input snapshot rejects
later drift during checks/fixture preparation, including concurrent LIBERTIES edits.

The independent lighthouse/cupola, gallery and Lake House roof suites run against the
composed modules. They verify all 25 legacy parameter sets preserve previous fields
under disabled defaults, legacy tower face-stream parity, old gallery call-stream
parity (five ranges), invalid combinations, finite nondegenerate lighthouse geometry,
reconstructed new-detail confidence, cupola geometry bounds, and the two data-only
chimney removals. The Lake House suite verifies removal of its erroneous360m²
cap while all17other existing walled roofs and syntheticflat/non-none branches
retain call parity. Results: `lighthouse-focused-check.json`, `cupola-focused-check.json`,
`gallery-focused-check.json`, and `combined-focused-check.json`. This is not Blender
export, renderer, derivative, full gate or image-match validation.

## Exact freshness scope

All 25 current `fort_structure` masters are recipe-stale because their shared
builder changes and the new resolved dataclass fields enter their input recipes.
`freshness-scope.json` lists every asset, phase and baseline SHA256; `structure-ids.txt`
is the exact comma list. Ten masters intentionally change visible geometry; the
other fifteen should retain their emitted geometry. No freshness hash is manually
rewritten. An actual supported export must reproduce/refresh all affected recipes.

No selected fort alternate versions currently exist. The fixture preparer refuses
if that changes, so an alternate cannot be silently omitted from the build scope.

## Isolated runners — completed once

Run only after the parent signals that the quiet local gate is finished.

1. `bash /tmp/chicago-next-model/fort-combined/run-export.sh`
2. `bash /tmp/chicago-next-model/fort-combined/run-reviews.sh`

`prepare_fixture.py` creates a NEW timestamped run under this package's `runs/`,
with independent baseline/proposed copies of generators, selected data, GLBs and
manifests. It copies the needed vendor code and pictures. Output asset paths are
regular copies, never symlinks into the repository. The only symlink is read-only
Node package resolution to the already installed global packages. Nothing in these
runners writes repository files or registries.

The export runner checks the cached archive against generators/blender.pin and
checks the binary's exact version, then runs the already installed pinned 4.5.3
binary on both baseline and proposed 25-ID batches with every scene available. It preserves the native
exit status, logs to baseline-export.log/proposed-export.log and records every written master. No package download,
verification bypass or extra Blender installation is performed. `verify_exports.py`
checks exact selected outputs and recomputed mesh input recipes, and reports master
SHA256 drift. Unexpected byte drift among the fifteen intended-unchanged masters
stops the runner for investigation; it does not overwrite repository assets.

The review runner captures the same initial first-fort, second-fort and lighthouse
cameras against the isolated baseline and proposed masters. Copies of camera files
and pictures ensure before/after framing is identical. All cameras are provisional:
first-fort curtain/staff disagreement, second-fort high-angle misfit and lighthouse
diameter/taper/height mismatch are unresolved. Screenshots go to the run's reviews/.
Match records remain in the disposable fixtures and start unreviewed, never matches.
The group renderer uses a common grade plane, not final terrain. These runs do not
validate in-app performance or assert that any of T-2373/T-2387/T-2388 is complete.

## Integration remains separate

Review all source rights and provenance; resolve any current branch conflicts;
coordinate ticket ownership and an honest incremental PR; export and inspect normals,
materials, overlaps and dimensions; derive compressed meshes; regenerate licences,
scene sidecars, grades/pictures and liberty coverage; inspect credited cards and
models at desktop/mobile; measure extra material/draw costs; run required full gates.
Keep unresolved picture differences and source-date limits explicit. Do not copy
this package's research cameras into accepted views merely to satisfy a gate.


Optional isolated Lake House diagnostics after export: `bash /tmp/chicago-next-model/fort-combined/run-lakehouse-review.sh`.
This uses the copied existing GLB review renderer with explicitly diagnostic top/oblique
cameras and mathematical overcast light. It produces baseline/proposed model images
without pairing them with a later completed-hotel picture or creating match records.
Its four Cycles CPU renders completed and were inspected. `run-detail-review.sh` also
produced four inspected baseline/proposed blockhouse and upper-gallery diagnostics.
These cameras demonstrate emitted geometry only and supply no historic dimensions.
