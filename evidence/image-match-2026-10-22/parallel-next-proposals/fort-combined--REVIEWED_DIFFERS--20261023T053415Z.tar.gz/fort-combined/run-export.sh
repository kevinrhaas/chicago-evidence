#!/usr/bin/env bash
# Prepared only. Parent runs after the quiet gate and export authorization signal.
set -euo pipefail
fort_package="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$fort_package/prepare_fixture.py"
fort_run="$(cat "$fort_package/latest-run.txt")"
fort_fixture="$fort_run/proposed"
source "$fort_fixture/generators/blender.pin"
fort_archive="/workspace/shared/blender-dl/$(basename "$BLENDER_URL")"
fort_binary="/workspace/shared/blender-dl/$BLENDER_DIR/blender"
printf '%s  %s\n' "$BLENDER_SHA256" "$fort_archive" | sha256sum -c -
python3 - "$fort_binary" "$BLENDER_VERSION" <<'PY'
import subprocess,sys
result=subprocess.run([sys.argv[1],'--version'],capture_output=True,text=True,check=True)
assert result.stdout.splitlines()[0].split()[1]==sys.argv[2],result.stdout.splitlines()[0]
print(result.stdout.splitlines()[0])
PY
fort_ids="$(cat "$fort_package/structure-ids.txt")"
for fort_kind in baseline proposed; do
  cd "$fort_run/$fort_kind"
  BLENDER_USER_CONFIG="$fort_run/blender-config" "$fort_binary" -b -noaudio --factory-startup --python generators/build.py -- --only "$fort_ids" --wrote "$fort_run/$fort_kind-wrote.txt" > "$fort_run/$fort_kind-export.log" 2>&1
done
cp "$fort_run/proposed-wrote.txt" "$fort_run/wrote.txt"
python3 "$fort_package/verify_exports.py" "$fort_run"
