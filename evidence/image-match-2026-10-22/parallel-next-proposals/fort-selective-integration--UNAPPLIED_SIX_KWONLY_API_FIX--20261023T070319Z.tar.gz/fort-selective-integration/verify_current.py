#!/usr/bin/env python3
"""Last read-only guard before parent applies the reviewed generated patch."""
from pathlib import Path
import argparse,hashlib,json,subprocess
HERE=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,default=Path('/workspace/chicago'));ap.add_argument('--staged',type=Path,default=HERE/'staged');args=ap.parse_args()
report=json.loads((args.staged/'review-manifest.json').read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
for row in report['files']:
    actual=digest(args.repo/row['path']);assert actual==row['current_sha256'],row['path']+' changed since review; materialize/review again'
    assert digest(args.staged/'candidate'/row['path'])==row['proposed_sha256'],row['path']+' staged payload changed'
for row in report['family_refresh']['assets']:
    p=args.repo/'chicago/4d/assets/gltf'/row['asset'];assert digest(p)==row['current_master_sha256'],row['asset']+' baseline changed since review'
subprocess.run(['git','-C',str(args.repo),'apply','--check',str((args.staged/'current-tree.patch').resolve())],check=True)
print('All17 live input hashes,25 selected master hashes and proposed payload hashes match; patch apply-check passed. No writes.')
