# Selective fort integration materializer — prepared, not applied

One future shared-fort-controls prerequisite PR can carry four visible increments
for T-2373, T-2379, T-2387 and T-2388. All four original picture-match cases stay
open. This package creates no ticket, completion child, claim, match verdict or
image-gate exception. It does not establish that a full building or compound
matches a picture.

The original reviewed proposal remains preserved at `/tmp/chicago-next-model/fort-combined`.
Its baseline is6156a0367a2379f0d986b88c7c8236c4ebec0e55. Current review found only
LIBERTIES.md drift among the fifteen original inputs: the independent Hogan
entry was added after the original package. Applying the old broad patch or
copying the old full liberty file is therefore inappropriate.

## Prepared output and use

Run these cheap commands whenever the parent is ready to inspect a fresh patch:

```sh
python3 /tmp/chicago-next-model/fort-selective-integration/materialize.py
python3 /tmp/chicago-next-model/fort-selective-integration/test_materializer.py
python3 /tmp/chicago-next-model/fort-selective-integration/test_legacy_constructor.py
python3 /tmp/chicago-next-model/fort-selective-integration/verify_current.py
```

The default output is `staged/` under this package: `current-tree.patch`,
`review-manifest.json`, `structure-ids.txt`, and the seventeen proposed files.
The first run passed `git apply --check` against the current dirty repository.
The script NEVER applies a patch and accepts output directories only under /tmp,
outside the inspected repository. It reads current files and computes everything
before creating proposal output. It writes no repository manifest, asset, grade,
sidecar, camera, ticket, license, changelog or generated report.

An integrating parent should inspect the current-tree patch and manifest again,
re-run its apply-check at the moment of integration, then apply it in the intended
branch/worktree after the shared gate slot is free. No integration command runs
automatically here. Do not copy the entire `candidate/` tree wholesale.

- Two shared Python modules are accepted only if identical to the reviewed
  baseline or already identical to the proposal. Any other module edit fails
  closed; it must be explicitly recomposed and reviewed.
- Ten structure records receive only changed JSON leaves. Phases are joined by
  ID, allowing unrelated notes/fields/new phases and current phase order to survive.
  A conflicting intended leaf fails closed. Date, position and footprint equality
  is checked for the existing selected phases.
- Two source records are created only if absent, or accepted if already equal.
  A different record using the same ID fails closed.
- Five liberty fragments append to CURRENT LIBERTIES text. Existing entries,
  including Hogan and any future frame/log entries, remain byte-preserved before
  the appended separator. A duplicate heading with different text is refused.
- Two image inventories receive one exact guarded Currey book-attribution line
  correction each. Their current St Mary, jail and Beaubien/sourceS changes survive.
  The new Castelnau source URL is corrected to File:Chicago1838.jpg to match its
  original research and inventory; this does not claim fresh remote verification.

The payload was frozen with `prepare_package.py`. That helper only writes /tmp
and reconstructs baseline blobs from the pinned Git commit; normal adaptation to
current work should use `materialize.py`, not rerun the old fort composer.

## Visible scope, sources, rights and limits

| Original case | Increment | Source and unresolved limits |
| --- | --- | --- |
| T-2373 | Opt-in birdcage/domed lantern, finial and railed gallery | Castelnau harbour print described circa1838, publication1842, public-domain inventory provenance; continuity into1835 is inferred. Shaft width/taper/base/height, materials and metric cage details remain unresolved/reconstructed. Source record discloses that original plate/catalogue was not freshly reopened. |
| T-2379 | `roof_type:none` actually emits no cover rather than flat roof | Existing shell's rooflessness is reconstructed; June10 notice supports building activity, not roof chronology. Attribute confidence is corrected to reconstructed. A later finished hotel picture is not used to date its roof. |
| T-2387 | Remove two separate blockhouse stacks; opt five garrison ranges into upper galleries | Kurz & Allison1893 panel1 supplies retrospective silhouette; Currey1912 p27 supplies retrospective upper-walk topology. Neither is eyewitness evidence or metric authority; exact five-facade identification is unresolved. First-fort roof lanterns remain absent and access/stairs unresolved. An1808 not-yet-built statement does not prohibit inferred completion by1812. |
| T-2388 | Second-fort blockhouse capped drum; omit intersecting reconstructed stack | Kurz & Allison1893 panel5, public domain. Cupola occurrence is inferred; 1.8m width,1.2m rise,35degree cap, centre mounting and vent treatment reconstructed. Full low-angle compound camera/model still differs. |

The source records, five detailed append-only liberty texts and previous
`REVIEW.md` are frozen under `evidence/`/`payload/`. Preserve L370's earlier
historical decisions while explicitly superseding only the two first-fort stacks.
Currey's book is *The Story of Old Fort Dearborn*, not *Chicago: Its History and
Its Builders*. No source/asset whose rights are check_required is introduced.
All numeric new-detail confidence remains reconstructed; do not promote it merely
because a broad feature is inferred. Keep historical phase dates, surveyed plans
and bearings, institutional credit, source limits, and Native-history review flags.

## Grade, notes and research integration

Run the existing picture/grade compilers after integrating the source changes;
never copy an old structure_grades.json or manually type a whole-building grade.
The selected picture grade remains distinct from per-attribute inference. Currey's
bird's-eye depiction does not by itself independently attest every named range's
appearance. No sourceS ruling is removed or overridden.

The final prerequisite research note should carry the four bounded changes above,
actual baseline/proposed images, exact bake/QA receipts, unresolved mismatches,
source dates and confidence distinctions. Copy only selected research evidence
needed for review, with public-domain credits; do not add the entire temporary run
or any old full manifest. Keep the original four gate cases open. Once a real
prerequisite ticket exists, replace the fragments' old proposal ticket/date wording
with the actual integration reference, preserving original case links and historical
entries. Add the normal one group changelog and required STATUS/ROADMAP notes for
that prerequisite; these project-state edits are intentionally not guessed here.

## Canonical real refresh plan — parent execution after slot release

1. Confirm current master membership is exactly the same25 fort_structure rows.
   `materialize.py` refuses any membership addition/removal, so new alternates
   require re-scoping. Save current asset/recipe and registry snapshots for
   comparison; these are evidence, never files to restore wholesale.
2. Recheck the pinned Blender4.5.3 cached archive SHA256 and binary version as in
   the original run. From the4D directory use the supported selective full bake:

   ```sh
   BLENDER_CACHE=/workspace/shared/blender-dl bash tools/bake.sh --only "$(cat /tmp/chicago-next-model/fort-selective-integration/staged/structure-ids.txt)"
   ```

   This is a FUTURE command, not executed by this package. Do not pass --scene1835
   or omit1812: the first-fort phases must be exported too. Do not use --no-bake
   for the canonical refresh or manually restamp freshness hashes. The normal
   command derives the selected masters, merges live registries and compiles/
   publishes through the supported pipeline; it does not need a new scene.
3. Prove every selected recipe is fresh, exactly25 selected masters were written,
   and only ten intended geometries changed against fresh same-input baselines.
   Regenerate derivatives normally; do not copy isolated manifests or GLBs over
   unrelated assets. Observe any newly discovered selected alternates rather than
   dropping them from registries.
4. Run normal ordered derivation for sources/licenses, pictures/grades, liberty
   coverage, sidecars and publishing, preserving all other branches' generated
   state. Require ordered-tail stability and current full gates appropriate to
   generator changes; previous /tmp receipts do not replace current-tree checks.
5. Inspect credited cards and actual models in desktop/mobile published renders,
   including normals/materials, overlapping rails/caps, source dates and open-case
   text. Measure material/draw/triangle budgets and verify compressed derivatives.
   Existing provisional cameras are diagnostic and must not be promoted to matches.

## Tests and reproducibility

Current cheap regressions pass: ID-based selective phase merge preserves unrelated
fields and added phases; same-leaf conflict and shared-module drift are refused;
current liberty preservation/idempotence; all25 old parameter fields preserve
legacy defaults; exactly ten intended record parameter/confidence changes; no
asset/generated registry output. `light-check.json` is the current receipt.

Before canonical integration, retain durable focused tests for invalid flag/type/
kind combinations, one-storey/default gallery and lantern call-stream parity,
finite nondegenerate cupola/lantern geometry and bounds, reconstructed new-detail
confidence, unchanged flat/non-none roof paths versus genuinely absent roof, and
all25 default parameter parity. The existing independent focused suites/results
under the original package supply these cases; adapt their fixture paths only,
not their assertions. Promote meaningful cases into normal check coverage when
landing the feature. A standalone /tmp suite is not permanent repository coverage.

The earlier actual Blender run rebuilt25 baseline+25 proposed masters with zero
zero-area triangles, finite/accessor checks and unit normals; exactly ten proposed
masters changed vs freshly rebuilt baseline and fifteen were byte-identical.
The net ten-master increment added5,284 triangles. Five rebuilt baselines differed
from committed masters only in TEXCOORD_0 packing: lighthouse, second-fort barracks,
commandant quarters, guard house and store house. Positions, normals, confidence,
tone, indices, materials and JSON were identical; UV differences ranged up to0.9322.
The masters had no image dependencies or AO bake. Preserve that known UV
nondeterminism in the handoff; do not claim all25 reproduce committed bytes.
A new UV-only drift must be inspected by decoded streams before accepting it.

## Positional API audit follow-up

The prior proposal inserted all six new dataclass fields before legacy fields and
broke the existing positional constructor: gallery_storeys shifted loopholes and
subsequent arguments; lantern_profile and cupola fields shifted confidence. The
selective payload now declares each new field individually with
`field(default=..., kw_only=True)`. The sixteen old positional arguments, their
defaults, and `__match_args__` exactly match the pre-feature module.

`test_legacy_constructor.py` demonstrates the prior regression, checks all six new
fields are keyword-only, then supplies all sixteen positional arguments for each
of the actual twenty-five family records, including the final confidence dict.
Every legacy field matches. For each twenty-five proposed records it also proves
that all resolved stored values and derived properties are equal before versus
after this API-only fix. The generator module remains identical to the reviewed
proposal. `legacy-constructor-check.json` records those results. Retain this case
in permanent focused tests when integrating, alongside geometry/default coverage.

The old fort-combined package and actual frozen before/after renders are untouched.
Their visuals remain useful prior evidence because parameter values and builder
geometry are unchanged, but they were built with the pre-fix module bytes. Those
old recipe hashes are not evidence of current freshness. All twenty-five masters
still require a real supported canonical bake from the final module; no hash or
old manifest is copied/restamped to pretend otherwise. No new Blender/browser job
was run for this API audit.
