#!/usr/bin/env python3
"""Cheap safety regressions plus real current25 parameter parity, no bpy/browser."""
import copy,dataclasses,importlib.util,json,sys
from pathlib import Path
import materialize as m
HERE=Path(__file__).resolve().parent
REPO=Path('/workspace/chicago')
def rejects(fn):
    try:fn()
    except m.Conflict:return
    raise AssertionError('Expected safe conflict refusal')
old={'phases':[{'id':'a','form':{'gallery':{'value':True}}},{'id':'b','form':{}}],'research_note':'old'}
new=copy.deepcopy(old);new['phases'][0]['form']['gallery_storeys']={'value':2}
current=copy.deepcopy(old);current['research_note']='independent newer source note';current['phases'].reverse();current['phases'].append({'id':'future','form':{}});current['phases'][1]['form']['unrelated']={'value':7}
result=m.merge(old,new,current)
assert result['research_note']==current['research_note']
assert [p['id'] for p in result['phases']]==['b','a','future']
assert result['phases'][1]['form']['gallery_storeys']=={'value':2}
assert result['phases'][1]['form']['unrelated']=={'value':7}
conflict=copy.deepcopy(current);conflict['phases'][1]['form']['gallery_storeys']={'value':3}
rejects(lambda:m.merge(old,new,conflict))
rejects(lambda:m.guarded_module(b'a=1\n',b'a=2\n',b'a=3\n','module'))
assert m.guarded_module(b'a=1\n',b'a=2\n',b'a=1\n','module')==b'a=2\n'
lib='### L-existing\n\nHogan/sourceS independent prose\n'
frag='### L-fort-test\n\nnew fort text\n'
merged,state=m.append_fragment(lib,frag,'test');assert lib.strip() in merged and state=='append'
assert m.append_fragment(merged,frag,'test')==(merged,'already_present')
rejects(lambda:m.append_fragment(merged,frag.replace('new fort','different'),'test'))
outputs,report=m.plan(REPO)
def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);obj=importlib.util.module_from_spec(spec);sys.modules[name]=obj;spec.loader.exec_module(obj);return obj
rel='chicago/4d/generators/archetypes/fort_structure_params.py'
a=module(HERE/'payload/baseline'/rel,'fort_before')
b=module(HERE/'payload/proposed'/rel,'fort_after')
added={'gallery_storeys','lantern_profile','cupola','cupola_width_m','cupola_height_m','cupola_roof_pitch_deg'}
actual_changes=[]
for row in report['family_refresh']['assets']:
    rel='chicago/4d/data/structures/'+row['structure_id']+'.json';current=json.loads((REPO/rel).read_text())
    ph=next(p for p in current['phases'] if p['id']==row['phase_id'])
    before=dataclasses.asdict(a.from_phase(ph,current));default_after=dataclasses.asdict(b.from_phase(ph,current))
    assert {k:v for k,v in default_after.items() if k not in added}==before,row['structure_id']
    proposed=json.loads(outputs[rel][1]) if rel in outputs else current
    phase=next(p for p in proposed['phases'] if p['id']==row['phase_id'])
    actual=dataclasses.asdict(b.from_phase(phase,proposed))
    if actual!=default_after:actual_changes.append(row['structure_id'])
    if rel in outputs:
        assert ph['footprint']==phase['footprint'] and ph['position']==phase['position']
        assert ph['documented_range']==phase['documented_range']
assert sorted(actual_changes)==sorted(report['family_refresh']['intended_changed_geometry']),actual_changes
# These are reviewed source/library deltas only: generated registries/assets and
# unrelated sourceS/Hogan/frame/log modules are not materializer outputs.
assert len(outputs)==17 and not any('/assets/' in p or '/sidecars/' in p or p.endswith('structure_grades.json') for p in outputs)
assert set(p for p in outputs if p.endswith('.py'))=={'chicago/4d/generators/archetypes/fort_structure.py', 'chicago/4d/generators/archetypes/fort_structure_params.py'}
print(json.dumps({'merge_safety':'passed','module_drift_refusal':'passed','append_only_current_liberty_preservation':'passed','all25_default_legacy_field_parity':'passed','ten_intended_record_changes':actual_changes,'generated_registry_writes':False,'heavy_jobs':False},indent=2))
