#!/usr/bin/env python3
"""Freeze reviewed fort inputs under /tmp; never re-run the old broad composer."""
from pathlib import Path
import hashlib,json,subprocess,shutil
HERE=Path(__file__).resolve().parent
ORIGINAL=Path('/tmp/chicago-next-model/fort-combined')
REPO=Path('/workspace/chicago')
meta=json.loads((ORIGINAL/'input-snapshot.json').read_text())
records=[]
for rel,want in meta['input_sha256'].items():
    if rel.endswith('docs/LIBERTIES.md'):continue
    proposed=(ORIGINAL/'candidate'/rel).read_bytes()
    if rel.endswith('castelnau_1842_chicago_harbor.json'):
        proposed=proposed.replace(b'File:Chicago 1838.jpg',b'File:Chicago1838.jpg')
    if rel.endswith('fort_structure_params.py'):
        edits={'gallery_storeys: int = 1': 'gallery_storeys: int = field(default=1, kw_only=True)', 'lantern_profile: str = "legacy"': 'lantern_profile: str = field(default="legacy", kw_only=True)', 'cupola: bool = False': 'cupola: bool = field(default=False, kw_only=True)', 'cupola_width_m: float = 1.8': 'cupola_width_m: float = field(default=1.8, kw_only=True)', 'cupola_height_m: float = 1.2': 'cupola_height_m: float = field(default=1.2, kw_only=True)', 'cupola_roof_pitch_deg: float = 35.0': 'cupola_roof_pitch_deg: float = field(default=35.0, kw_only=True)'}
        for old,new in edits.items():
            assert proposed.count(old.encode())==1,old
            proposed=proposed.replace(old.encode(),new.encode())
    try:baseline=subprocess.check_output(['git','-C',str(REPO),'show',meta['base_head']+':'+rel],stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError:
        if want is not None:raise
        baseline=None
    assert (hashlib.sha256(baseline).hexdigest() if baseline is not None else None)==want,rel
    for kind,content in [('baseline',baseline),('proposed',proposed)]:
        if content is None:continue
        dest=HERE/'payload'/kind/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(content)
    records.append({'path':rel,'kind':'guarded_module' if rel.endswith('.py') else 'json_leaf_merge' if baseline is not None else 'new_source','baseline_sha256':want,'proposed_sha256':hashlib.sha256(proposed).hexdigest()})
for name in ['liberty-fragments','REVIEW.md','freshness-scope.json','combined-focused-check.json','lighthouse-focused-check.json','cupola-focused-check.json','gallery-focused-check.json']:
    src=ORIGINAL/name;dest=HERE/'evidence'/name;dest.parent.mkdir(parents=True,exist_ok=True)
    if src.is_dir():shutil.copytree(src,dest,dirs_exist_ok=True)
    else:shutil.copy2(src,dest)
(HERE/'package.json').write_text(json.dumps({'reviewed_base':meta['base_head'],'original_package':str(ORIGINAL),'records':records,'text_replacements':[{'path':f'chicago/reference/{middle}images/IMAGE_SOURCES.md','old':'*Published by J. Seymour Currey, Chicago: Its History and Its Builders*','new':'*J. Seymour Currey, The Story of Old Fort Dearborn (Chicago: A. C. McClurg & Co., 1912), p. 27; illustrator uncredited in the consulted caption*','reason':'Correct book attribution against consulted Gutenberg caption/list of illustrations, preserving current sourceS edits.'} for middle in ('','planning/')],'scope':'Shared fort controls with four original-case increments; originals remain open; no completion child or image gate bypass.'},indent=2)+'\n')
print('Frozen',len(records),'non-liberty inputs under',HERE)
