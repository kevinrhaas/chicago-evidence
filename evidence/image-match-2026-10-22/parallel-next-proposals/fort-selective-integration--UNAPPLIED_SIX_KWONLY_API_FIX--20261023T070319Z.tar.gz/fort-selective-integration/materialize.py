#!/usr/bin/env python3
"""Emit a guarded current-tree fort proposal ONLY under /tmp. Never applies it."""
from __future__ import annotations
import argparse,copy,difflib,hashlib,json,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
MISSING=object()
class Conflict(RuntimeError):pass

def digest(data):return hashlib.sha256(data).hexdigest() if data is not None else None

def merge(old,new,current,path='',changes=None):
    """Three-way merge exact leaves; phase ID, not list index, is their identity."""
    if changes is None:changes=[]
    if old==new:return copy.deepcopy(current)
    if isinstance(old,dict) and isinstance(new,dict) and isinstance(current,dict):
        out=copy.deepcopy(current)
        for key in sorted(old.keys()|new.keys()):
            before=old.get(key,MISSING);after=new.get(key,MISSING);now=current.get(key,MISSING)
            if before==after:continue
            val=merge(before,after,now,path+'/'+key,changes)
            if val is MISSING:out.pop(key,None)
            else:out[key]=val
        return out
    if all(isinstance(x,list) for x in (old,new,current)) and old and new and all(isinstance(x,dict) and isinstance(x.get('id'),str) for seq in (old,new,current) for x in seq):
        indexes=[{x['id']:x for x in seq} for seq in (old,new,current)]
        if any(len(idx)!=len(seq) for idx,seq in zip(indexes,(old,new,current))):raise Conflict(path+': duplicate list IDs')
        a,b,c=indexes;out=copy.deepcopy(current)
        # Proposal may change existing phases, but cannot delete/reorder/add phases.
        if a.keys()!=b.keys() or [x['id'] for x in old]!=[x['id'] for x in new]:raise Conflict(path+': proposal changes phase/list membership')
        for ident in a:
            if a[ident]==b[ident]:continue
            if ident not in c:raise Conflict(path+': current phase removed '+ident)
            i=next(i for i,x in enumerate(out) if x['id']==ident)
            out[i]=merge(a[ident],b[ident],c[ident],path+'[id='+ident+']',changes)
        return out
    if current!=old and current!=new:raise Conflict(path+': intended leaf changed independently')
    changes.append({'path':path,'state':'already_present' if current==new else 'apply'})
    return MISSING if new is MISSING else copy.deepcopy(new)

def guarded_module(old,new,current,path):
    if current not in (old,new):raise Conflict(path+': current module differs from reviewed baseline AND proposal; recompose/review explicitly')
    compile(new.decode(),path,'exec')
    return new

def append_fragment(current,fragment,path):
    heading=next((x for x in fragment.splitlines() if x.startswith('### ')),None)
    if not heading:raise Conflict(path+': missing liberty heading')
    if heading in current:
        # Exact fragment must already be present, otherwise an independently edited
        # liberty with this identity must be reviewed rather than duplicated.
        if fragment.strip() not in current:raise Conflict(path+': liberty heading exists with different content')
        return current,'already_present'
    separator='' if current.endswith('\n\n') else '\n' if current.endswith('\n') else '\n\n'
    return current+separator+fragment.strip()+'\n','append'

def plan(repo):
    meta=json.loads((HERE/'package.json').read_text());outputs={};report=[]
    for row in meta['records']:
        rel=row['path'];oldpath=HERE/'payload/baseline'/rel
        old=oldpath.read_bytes() if oldpath.exists() else None
        new=(HERE/'payload/proposed'/rel).read_bytes()
        if digest(old)!=row['baseline_sha256'] or digest(new)!=row['proposed_sha256']:raise Conflict(rel+': frozen payload changed')
        currentpath=repo/rel;current=currentpath.read_bytes() if currentpath.exists() else None
        entry={'path':rel,'strategy':row['kind'],'current_sha256':digest(current),'changes':[]}
        if row['kind']=='guarded_module':
            if current is None:raise Conflict(rel+': module missing')
            result=guarded_module(old,new,current,rel)
        elif old is None:
            if current is not None and json.loads(current)!=json.loads(new):raise Conflict(rel+': source already exists with differing content')
            result=current if current is not None else new
            entry['changes']=[{'path':'/','state':'already_present' if current is not None else 'new_source'}]
        else:
            if current is None:raise Conflict(rel+': structure removed')
            resultdoc=merge(json.loads(old),json.loads(new),json.loads(current),changes=entry['changes'])
            result=(json.dumps(resultdoc,ensure_ascii=False,indent=2)+'\n').encode()
        outputs[rel]=(current,result);entry['proposed_sha256']=digest(result);report.append(entry)
    rel='chicago/4d/docs/LIBERTIES.md';current=(repo/rel).read_bytes();new=current.decode();entry={'path':rel,'strategy':'append_missing_fragments_to_current','current_sha256':digest(current),'changes':[]}
    for fragment in sorted((HERE/'evidence/liberty-fragments').glob('*.md')):
        new,state=append_fragment(new,fragment.read_text(),fragment.name);entry['changes'].append({'fragment':fragment.name,'state':state})
    outputs[rel]=(current,new.encode());entry['proposed_sha256']=digest(new.encode());report.append(entry)
    for row in meta.get('text_replacements',[]):
        rel=row['path'];current=(repo/rel).read_bytes();text=current.decode()
        if row['new'] in text:
            if row['old'] in text:raise Conflict(rel+': both old and corrected inventory attribution present')
            state='already_present'
        else:
            if text.count(row['old'])!=1:raise Conflict(rel+': scoped inventory attribution changed; inspect before composing')
            text=text.replace(row['old'],row['new']);state='replace_one_line'
        outputs[rel]=(current,text.encode())
        report.append({'path':rel,'strategy':'guarded_single_line_inventory_correction','current_sha256':digest(current),'proposed_sha256':digest(text.encode()),'changes':[{'state':state,'reason':row['reason']}]})
    scope=json.loads((HERE/'evidence/freshness-scope.json').read_text())
    manifest=json.loads((repo/'chicago/4d/assets/manifest.json').read_text());assets=manifest.get('assets',manifest)
    live={(r['structure_id'],r['phase_id'],k) for k,r in assets.items() if isinstance(r,dict) and r.get('archetype')=='fort_structure'}
    reviewed={(r['structure_id'],r['phase_id'],r['asset']) for r in scope['assets']}
    if live!=reviewed:raise Conflict('Fort master membership changed: added '+repr(live-reviewed)+' removed '+repr(reviewed-live))
    for row in scope['assets']:
        rel='chicago/4d/assets/gltf/'+row['asset'];row['current_master_sha256']=digest((repo/rel).read_bytes())
    return outputs,{'source_head':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'files':report,'family_refresh':scope,'repository_writes':False,'asset_or_manifest_copies':False}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--repo',type=Path,default=Path('/workspace/chicago'));ap.add_argument('--out',type=Path,default=HERE/'staged');args=ap.parse_args()
    repo=args.repo.resolve();out=args.out.resolve()
    if not out.is_relative_to(Path('/tmp')) or out.is_relative_to(repo):raise SystemExit('Output must stay under /tmp and outside repository')
    outputs,report=plan(repo) # Fail all conflicts BEFORE writing even the proposal.
    out.mkdir(parents=True,exist_ok=True);patch=''
    for rel,(before,after) in outputs.items():
        dest=out/'candidate'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(after)
        if before==after:continue
        patch+='diff --git a/'+rel+' b/'+rel+'\n'+('new file mode 100644\n' if before is None else '')
        patch+=''.join(difflib.unified_diff((before or b'').decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='a/'+rel if before is not None else '/dev/null',tofile='b/'+rel))
    (out/'current-tree.patch').write_text(patch);(out/'review-manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    (out/'structure-ids.txt').write_text(','.join(row['structure_id'] for row in report['family_refresh']['assets'])+'\n')
    subprocess.run(['git','-C',str(repo),'apply','--check',str(out/'current-tree.patch')],check=True)
    print('Materialized',len(outputs),'files; current-tree patch apply-check passed. No repository writes.')
if __name__=='__main__':main()
