#!/usr/bin/env python3
"""Preserve the actual pre-feature positional API, plus every resolved25 recipe."""
import dataclasses,hashlib,inspect,json,sys,importlib.util
from pathlib import Path
HERE=Path(__file__).resolve().parent
REPO=Path('/workspace/chicago')
rel='chicago/4d/generators/archetypes/fort_structure_params.py'
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);obj=importlib.util.module_from_spec(spec);sys.modules[name]=obj;spec.loader.exec_module(obj);return obj
legacy=load(HERE/'payload/baseline'/rel,'fort_legacy_api')
before=load(HERE/'evidence/fort_structure_params.before_keyword_only.py','fort_prior_proposal_api')
fixed=load(HERE/'payload/proposed'/rel,'fort_fixed_api')
newfields={'gallery_storeys','lantern_profile','cupola','cupola_width_m','cupola_height_m','cupola_roof_pitch_deg'}
def positional(cls):return [name for name,p in inspect.signature(cls).parameters.items() if p.kind in (inspect.Parameter.POSITIONAL_ONLY,inspect.Parameter.POSITIONAL_OR_KEYWORD)]
oldnames=positional(legacy.FortStructureParams);brokennames=positional(before.FortStructureParams);fixednames=positional(fixed.FortStructureParams)
assert oldnames!=brokennames,'Fixture must demonstrate the prior proposal regression'
assert fixednames==oldnames
assert fixed.FortStructureParams.__match_args__==legacy.FortStructureParams.__match_args__
assert {name for name,p in inspect.signature(fixed.FortStructureParams).parameters.items() if p.kind==inspect.Parameter.KEYWORD_ONLY}==newfields
# Every existing old default is also identical, not just its argument's name.
for name in oldnames:
    assert inspect.signature(fixed.FortStructureParams).parameters[name].default==inspect.signature(legacy.FortStructureParams).parameters[name].default
scope=json.loads((HERE/'staged/review-manifest.json').read_text())['family_refresh'];rows=[]
for row in scope['assets']:
    current=json.loads((REPO/'chicago/4d/data/structures'/(row['structure_id']+'.json')).read_text());ph=next(p for p in current['phases'] if p['id']==row['phase_id'])
    old=legacy.from_phase(ph,current)
    # Supply every16legacy argument position, including confidence after lantern.
    args=[getattr(old,name) for name in oldnames]
    restored=fixed.FortStructureParams(*args);restored.validate()
    assert {k:v for k,v in dataclasses.asdict(restored).items() if k not in newfields}==dataclasses.asdict(old)
    proposed_path=HERE/'staged/candidate/chicago/4d/data/structures'/(row['structure_id']+'.json')
    proposed=json.loads(proposed_path.read_text()) if proposed_path.exists() else current
    newph=next(p for p in proposed['phases'] if p['id']==row['phase_id'])
    pbefore=before.from_phase(newph,proposed);pafter=fixed.from_phase(newph,proposed)
    assert dataclasses.asdict(pbefore)==dataclasses.asdict(pafter)
    # Includes all derived properties used by builders, not only stored fields.
    for name,member in vars(fixed.FortStructureParams).items():
        if isinstance(member,property):assert getattr(pbefore,name)==getattr(pafter,name)
    rows.append(row['structure_id'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(HERE/'evidence/fort_structure_params.before_keyword_only.py')!=sha(HERE/'payload/proposed'/rel)
assert sha(HERE/'payload/proposed/chicago/4d/generators/archetypes/fort_structure.py')==sha(Path('/tmp/chicago-next-model/fort-combined/candidate/chicago/4d/generators/archetypes/fort_structure.py'))
print(json.dumps({'status':'passed','legacy_positional_parameters':oldnames,'legacy_positional_count':len(oldnames),'legacy_match_args_restored':True,'all_six_new_fields_keyword_only':True,'all25_full_positional_constructors_equal':len(rows),'all25_opt_in_resolved_values_and_properties_equal_before_after_api_fix':len(rows),'generator_module_unchanged_by_api_fix':True,'prior_frozen_previews_preserved':True,'module_bytes_changed_canonical25_recipe_refresh_required':True,'geometry_export_or_browser_run':False},indent=2))
