# Off-scene phase build and picture review — narrow pipeline audit

## Result

There is no existing end-to-end supported route to build, retain, image-gate and
open a later record phase that none of the committed scene dates resolves.
There **is** an existing lower-level exact-phase geometry API plus an existing
explicit-GLB picture renderer. Those permit truthful isolated research previews
now, without inventing an 1844 town or changing July 1835. Canonical retention,
phase-aware closure and an in-app phase inspector remain missing capabilities.

## What the actual code permits

| Mechanism | Result |
| --- | --- |
| `generators/build.py --only <id>` | Selects the record but still calls `phases_in_scenes`; does not select a later phase. |
| `--scene <id>` | Reads a real `data/scenes/<id>.json`; not an arbitrary date, phase or record-only review. |
| `--all` or no scene | Resolves every committed scene date, deduplicating phases. It still misses phases between those dates. |
| `--out /tmp/...` | Changes GLB output directory, **not** manifest destination. Still writes canonical `assets/manifest.json` and version manifest. Do not use it as isolation. |
| `emit.emit_structure(record, phase, archetype, out, bake=True, ao=False)` | Existing whole geometry pipeline accepts any exact authored phase; does not resolve scenes or register a manifest. Good for a research-only export with explicit phase/date/receipt. |
| `photo_match.mjs <camera> --glb <relative-research.glb> --out <comparison-dir>` | Existing single-building renderer honors explicit GLB, no scene required. Keep camera under docs/RESEARCH and record its phase/date in the study. It does not verify source date or GLB extras against a requested phase. |
| `also_render` group mode | Requires a committed scene and compiled sidecars. It cannot currently place a later-phase compound without falsely selecting an earlier scene. |
| `data/structures/versions/...` | Competing builds at an existing scene date, not a time-travel bypass. Build and sidecar compiler resolve the version at the scene target date; validator rejects a version that no scene resolves. |
| `?structure=<id>&version=<label>` | Browser swaps one existing scene entry with a scene-compiled alternate. It neither selects a date nor loads an absent later phase. |
| Inspect Story timeline | Displays dated facts/range words and AFTER YOUR VISIT; not a phase or GLB selector. |
| `?year=1844` | Loads scenes/1844.json and sidecars/1844; not an isolated structure date. No such committed scene exists. |

Committed scene dates are 1812-08-14, 1835-07-01 and 1904-07-01.
Current canonical `st_marys_church` has only `frame_1833`, 1833-10-01 through
1837-06-01. Current `log_jail` has only `log_1833`, 1833-10-01 through 1835-12-31.
Neither record currently resolves May 1844. Add the later church's actual phase
with source/date/location provenance before exporting it; do not widen the 1833
phase or insert the later belfry into the July 1835 mesh.

A courthouse visible in a post-fall-1835 jail picture dates the picture's overall
composition, not necessarily the jail's own alteration. Separate those claims:
an isolated jail model can be compared against a later view only for features
shown to persist, with the temporal inference recorded. Do not add the courthouse
to the July scene merely because it shares that picture.

## Current safe research-preview route

The accompanying `render_phase_study.py` is an **unexecuted standalone wrapper of
existing emit API**, not a new product pipeline. It requires an exact authored
phase and an explicit review date inside its range, refuses product output paths,
keeps prior output rather than overwriting it, and writes the GLB plus its record,
input and output hashes in a receipt. Nothing touches manifests, scene files or
canonical record content. Its pure selector checks ran without importing Blender.

Once the actual later phase is authored and CPU is released, the parent can run
this through the project's pinned Blender. A GLB under a root-relative research
path can then be inspected with the existing `photo_match --glb` command. Output
outside the checkout must first be materialized into a safe root-relative review
location: photo_match's server serves its cwd and does not expose arbitrary /tmp.
Do not pass an absolute --glb path as though the browser can fetch it.

Save a camera, phase/date receipt, source credit, side-by-side and honest verdict
under `docs/RESEARCH/<ticket>/`, not under `data/reference_views/`. The latter
would make automatic grade/picture joins imply a solved canonical view, while the
current closing gate still selects `glbFor(structureId)` from the canonical
manifest and has no requested phase.

This route can produce real source-shaped model evidence now. It cannot satisfy
the original ticket's in-app dated-phase inspection by itself. Do not call a
research preview an 1844 town or claim the original image gate passed.

## Why registering the GLB canonically is currently refused

`tools/validate.py::run_bake_reach_check`, lines 7080–7164, explicitly documents
this exact historical failure: the first courthouse is dated to fall 1835, July's
scene does not resolve it, and an earlier hand-written build left a committed
mesh that the full bake could never refresh. The current gate requires each
registered mesh to be reachable at some scene date. A new later GLB in
assets/manifest.json would intentionally fail this invariant. Do not disable it,
backdate a phase, or manufacture a scene to make the gate pass.

Versions are similarly guarded by `validate.py::check_versions` around
6325–6397 and `compile_scene.py::compile_versions` around 2744–2785.
The renderer's refusal/default fallback is in
`renderers/web/js/structure-versions.js::resolveStructureVersion`.

## Smallest sustainable missing capability

1. Add an explicit exact-phase build selection (e.g. `--only <one-id> --phase
   <phase-id>` and an explicit phase-review date). It must refuse unknown/ambiguous
   phases and date disagreement, preserve every documented range, and reuse
   emit_structure unchanged.
2. Give committed phase studies a deterministic recipe/registry separate from a
   scene. The ordinary refresh must rebuild registered studies after generator
   changes; the freshness gate should accept that reproducible route rather than
   merely exempting off-scene assets. Existing bake-reach prose already names an
   explicit-phase route as one valid remedy. `--phase` alone without the retained
   rebuild route would still leave the normal full bake unable to heal the asset.
3. Let a reference camera name its phase explicitly. Resolve exactly the matching
   asset/recipe and hash its record/phase, GLB, camera and photo. The closing gate
   must use the same resolution, not the first manifest entry with that id. Check
   GLB extras.structure_id/phase_id rather than trusting a filename.
4. Provide an isolated structure-phase inspector, labeled by actual review date
   and documented range, with its own source/card content. It must not replace an
   1835 town building or imply complete reconstruction of the later town. Existing
   single-GLB Three reviewer can supply the small rendering shell; ordinary
   scene-loader/version swapping cannot honestly do this today.

No new scene is needed. No code, data or tests were edited in the repository and
no browser, Blender or heavy process was run during this audit.
