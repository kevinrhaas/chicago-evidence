"""Isolated exact-phase export through the existing emit API; does not register a town.

Run only when Blender/CPU are released. Example (illustrative phase ID):
  blender -b --factory-startup --python /tmp/.../render_phase_study.py -- \
    --root /workspace/chicago/chicago/4d --record /tmp/proposed-church.json \
    --phase relocated_belfry_1844 --at 1844-05-29 \
    --out /tmp/church-study/st_marys_church__relocated_belfry_1844.glb

The record must actually contain the requested phase. No manifest, canonical
record, scene, sidecar or date is modified. This is research export, not a
supported canonical phase-build route or a claim that the pictured date is exact.
"""
from __future__ import annotations
import argparse,datetime as dt,hashlib,json,pathlib,sys

def exact_phase(record, phase_id, review_date):
    target=dt.date.fromisoformat(review_date)
    matches=[p for p in record.get('phases',[]) if p.get('id')==phase_id]
    if len(matches)!=1:raise ValueError(f'exactly one authored phase {phase_id!r} is required; got {len(matches)}')
    phase=matches[0];rng=phase.get('documented_range',{})
    if not (dt.date.fromisoformat(rng['from'])<=target<=dt.date.fromisoformat(rng['to'])):
        raise ValueError(f'{review_date} is outside the authored phase range; no automatic backdating')
    if phase.get('drawn_by'):raise ValueError('phase is drawn by another layer and must not export a GLB')
    return phase

def main():
    args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else sys.argv[1:]
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=pathlib.Path,required=True);ap.add_argument('--record',type=pathlib.Path,required=True)
    ap.add_argument('--phase',required=True);ap.add_argument('--at',required=True);ap.add_argument('--out',type=pathlib.Path,required=True)
    opt=ap.parse_args(args);root=opt.root.resolve();raw=opt.record.read_bytes();record=json.loads(raw)
    phase=exact_phase(record,opt.phase,opt.at)
    if not (root/'data/datum.json').is_file():raise ValueError('root must be a 4D checkout')
    if not json.loads((root/'data/datum.json').read_text()).get('verified'):raise ValueError('datum not verified')
    output=opt.out.resolve()
    for protected in [root/'assets',root/'data',root/'generators',root/'renderers',root/'tools']:
        if output.is_relative_to(protected):raise ValueError('research output must not enter product asset/data/code paths')
    if output.suffix!='.glb':raise ValueError('output must have .glb suffix')
    if output.exists():raise ValueError('preserve the previous export: choose a new output path')
    output.parent.mkdir(parents=True,exist_ok=True)
    sys.path.insert(0,str(root/'generators'))
    import emit,mesh_inputs # Blender is required only for the real export, not selector checks.
    made=emit.emit_structure(record,phase,record['archetype'],output,bake=True,ao=False)
    receipt={'research_only':True,'structure_id':record['id'],'phase_id':phase['id'],
             'review_date':opt.at,'documented_range':phase['documented_range'],
             'record':str(opt.record.resolve()),'record_sha256':hashlib.sha256(raw).hexdigest(),
             'inputs_sha256':mesh_inputs.structure_inputs_sha(record,phase,record['archetype']),
             'glb':str(made.path),'glb_sha256':hashlib.sha256(made.path.read_bytes()).hexdigest(),
             'tris':made.tris,'limits':'An isolated structure study; no town, site-date or surrounding reconstruction is asserted.'}
    output.with_suffix('.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
