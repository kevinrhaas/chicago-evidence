### L-sauganash-lower-roof-fit-2383 — Sauganash roof and attic working appearance refinement

**Covers:** `sauganash_hotel.frame_1831.form.roof_pitch_deg`, `sauganash_hotel.frame_1831.form.end_windows`.

**Decision:** Reconstruct a25.2-degree roof on the existing9.92×8m footprint and5.5m walls, retaining the cross-wing’s shared span/pitch/ridge relationship. The exact same unsolved camera places the near apex around(636.5,350.1), improving the prior38-degree projection around(636.5,231.4) against approximate source(648,350). This remains an appearance-bounded reconstruction: principal point is far outside the plate, wall residuals reach30px and the drawing is not a measured survey. The changed pitch is reconstructed rather than inheriting the old typological inference’s grade.

Retain the two pictured upper sash and their existing numeric choices; lower/widen the attic sash to working centrez6.1m,54percent of depth,.85mwidth×1.2mheight. Fresh native-pixel inspection distinguishes the complete frame (roughlyx625..690,y415..535, manual±10pxuncertainty) from the older detector’s partial hatching/topdetail box. The banked gate is not silently redefined. These stations, sizes, unseen treatment and existing stock details remain reconstructed. No footprint, position, bearing, wall height, date or whole-building grade changes.

Source: `andreas_1884_sauganash_hotel_plate`, F.Braunhold’s engraving in Andreas1884, with its retrospective/date/dependence limits. The verified Gale1902 Trowbridge publication clears artwork use without making a later derivative picture an independent1835witness. Bright-blue shutters retain separate Wau-Bun colour evidence; louvred detail stays inferred. All original comparisons remain open. Actual before/after review must precede adoption; this fragment alone asserts no image match or official asset freshness.

**Ticket:** T-2383 (shared controls T-3055).
**Recorded:** 2026-10-23.
