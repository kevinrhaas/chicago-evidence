# Sauganash lower roof and attic — actual preview reviewed, canonical UNAPPLIED

The current final-frame comparison’s largest silhouette error is its main roof: the near apex projects aroundy231 rather than the source’s approximatey350. This future **data-only** trial changes38° to reconstructed25.2° under the SAME provisional camera. It preserves9.92×8m footprint,5.5m walls, all geographiccontrols, dates, cross-wing span/sharedapex relation, otherfields and generatorbytes. The old38° confidence was inferred typology; the newnumericfit is deliberately reconstructed.

Native source inspection also exposes a detector limit: the banked atticbox(590..663,403..460) is partial hatching/topdetail and not the full sash frame. A manual diagnostic reading puts the complete frame roughlyx625..690,y415..535 with±10pxuncertainty. This trial moves the attic sash fromat.50/z6.7/w.70 toat.54/z6.1/w.85, retainingheight1.2m and the exact upperpair. The existing silhouetteguard passes. No bankedreading/gate is edited or presented as solved.

`prepare_trial.py` creates an isolatedfixture from the final frame review module bytes; it has already run. `verify_trial.py` passed actualparameter validation and accumulated geometry/finite/confidence checks without Blender. `light-check.json` records both exact projected apex values and newatticcentre. The archetype/parameter sources are byte-identical to final T-3055, so adopting this after its real23family bake would stale this building’s recipes only; it does not create another familycodechange. No canonicalrecord, GLB,manifest,sidecar or acceptedcamera was written.

The parent granted an exclusive slot and this command completed using the pinned exporter and actual comparison runner:

```sh
bash /tmp/chicago-next-model/T-2383-roof-next/run_preview.sh
```

This uses pinned4.5.3 and the actual `emit.emit_structure` with canonicalseed, builds before/after into isolated/tmp, then runs four actualphoto comparisons: both mainmeshes alone and both with the **currentcanonical Carpenterlogannex**, using actualscene placements on the standard flatreviewgrade. It copies the currentannex only as context, without asserting the futurelog81proposal shipped. It never calls `build.py` or writes manifests. The exactsame source/camera/light frames both states. Actual output must be viewed and differences recorded; no fullimage-match claim is made by the projected-point arithmetic.

Current status: **actual two exports and four browser comparisons EXECUTED AND VIEWED; parent reviewed all four and approved progress adoption. Canonical UNAPPLIED.** The lower ridge and full attic sash are visibly closer under the same provisional camera. `actual-export-receipt.json` pins both GLBs; `actual-view-review.json` records the actual visual verdict, still `differs`. Remaining main-front openings/trim/stacks, cross-wing mass, sourceperspective, materialtones and allother ticketpictures remain unresolved. Blue shutters are sourcebacked and are preserved. `liberty-candidate.md` is an unappliedfragment; no ticket/PR/officialfreshness claim is made.


## Guarded adoption

After the frozen frame helper, current Tremont note correction and verified Gale hotel source adoption, run `python /tmp/chicago-next-model/T-2383-roof-next/adopt_after_review.py --repo /workspace/chicago`, inspect its plan and output, then repeat with `--apply`. **Apply this roof overlay BEFORE the baked Tremont glyph overlay**, because the roof proof intentionally guards the frozen frame generator bytes. Replan after upstream record/ledger changes.

The latest `post-apply-overlay-receipt.json` is an isolated thin-copy adoption exercise under the glyph package's `layered-namepool-root`; it is not a canonical apply. Its actual raw/parsed name-pool self-test passed. The two per-overlay QA candidates are historical single-overlay drafts; use the composed candidate in the baked-name handoff for both changes. No official bake, ticket closure or accepted match is asserted.
