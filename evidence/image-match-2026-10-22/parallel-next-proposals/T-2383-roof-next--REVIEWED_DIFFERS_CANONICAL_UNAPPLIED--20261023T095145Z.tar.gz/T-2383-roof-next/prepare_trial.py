"""Materialize data-only Sauganash roof/attic comparison fixture; no canonical writes."""
from pathlib import Path
import json,shutil,copy,hashlib,math
H=Path(__file__).resolve().parent
ROOT=Path('/workspace/chicago/chicago/4d')
FRAME=Path('/tmp/chicago-next-model/T-3055-selective-integration/review-tree/chicago/4d')
for rel in ['generators/archetypes/frame_tavern.py','generators/archetypes/frame_tavern_params.py']:
 dest=H/'fixture'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(FRAME/rel,dest)
(H/'fixture/generators/archetypes/__init__.py').touch()
old=json.loads((FRAME/'data/structures/sauganash_hotel.json').read_text());new=copy.deepcopy(old);ph=new['phases'][1];assert ph['id']=='frame_1831';f=ph['form']
assert f['roof_pitch_deg']['value']==38 and f['roof_pitch_deg']['confidence']=='inferred'
assert f['end_windows']['value'][2]=={'end':'+x','at':.5,'z':6.7,'width_m':.7,'height_m':1.2}
f['roof_pitch_deg']={'value':25.2,'confidence':'reconstructed','sources':['andreas_1884_sauganash_hotel_plate'],'note':'ISOLATED T-2383 ROOF TRIAL, NOT A MEASURED HISTORICAL PITCH. Keeping the existing9.92x8m footprint,5.5m walls and exact provisional camera,25.2degrees puts the withheld near ridge apex near(636.5,350.1) against an approximate source pick(648,350), replacing the old38degree projection near(636.5,231.4). This is an appearance-bounded reconstruction, not an accepted camera solve or independent metric calibration. The cross-wing shares the same span/pitch/ridge height as before. No position, footprint, bearing, date or historical dimension is moved to fit it. Source dependence, drawing-perspective uncertainty and actual image match remain unresolved.'}
a=f['end_windows']['value'][2];a.update(at=.54,z=6.1,width_m=.85)
f['end_windows']['note']='ISOLATED T-2383 ATTIC TRIAL. Keep the pictured two upper sash unchanged; lower the attic centre to workingz6.1m, at54percent of the retained8mdepth, widen it to.85m and retain1.2mheight. Actual native-image inspection shows the whole attic frame roughlyx625..690,y415..535, with manual±10pxbounds; the older banked attic detectorboxx590..663,y403..460 captures partialhatching/topdetail and must not be treated as the fullwindow outline. This trial does not silently rebank that gate. These metricstations/sizes remain reconstructed under the same provisionalcamera, whose principalpoint lies outside theimage. The newwindow fits beneath the trialroof with the existingguard; count, upperpair and oppositeend stayunchanged. A real render/review is required; no match or source-date resolution is asserted.'
for label,rec in [('baseline',old),('proposed',new)]:
 p=H/'fixture/data'/label/'sauganash_hotel.json';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(rec,indent=2)+'\n')
cam=json.loads((FRAME/'docs/RESEARCH/frame-picture-match-T-2376-T-2385/sauganash/andreas-main-gable.provisional.json').read_text())
for label in ['before','after']:
 p=H/'fixture/review'/label/'andreas-same-camera.json';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(cam,indent=2)+'\n')
for rel in ['tools/photo_match.mjs','tools/photo_match_group.mjs']:
 p=H/'fixture'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/rel,p)
for rel in ['renderers/web','node_modules']:
 p=H/'fixture'/rel;p.parent.mkdir(parents=True,exist_ok=True)
 if not p.exists():p.symlink_to((ROOT/rel) if rel!='node_modules' else Path('/workspace/node_modules'),target_is_directory=True)
# Confirm proposed fields are the only non-note changes.
rest=copy.deepcopy(new);rest['phases'][1]['form']['roof_pitch_deg']=old['phases'][1]['form']['roof_pitch_deg'];rest['phases'][1]['form']['end_windows']=old['phases'][1]['form']['end_windows'];assert rest==old
(H/'data-only-delta.json').write_text(json.dumps({'baseline_sha256':hashlib.sha256((H/'fixture/data/baseline/sauganash_hotel.json').read_bytes()).hexdigest(),'changed_attributes':['frame_1831.form.roof_pitch_deg','frame_1831.form.end_windows'],'unchanged':'all other JSON, code, dimensions, footprint, geographicposition, bearing, phases/dates, sourceIDs, wholebuildinggrade; upper2sashunchanged','new_roof_pitch_confidence':'reconstructed; intentionallydowngradedfrominferredtypologybecauseappearancefitisnotindependentmetricproof','generator_source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (H/'fixture/generators/archetypes').glob('*.py')},'actual_blender_browser':'UNRUN'},indent=2)+'\n')
print('Prepared isolated data-only fixture; no canonical writes and no Blender/browser run')
