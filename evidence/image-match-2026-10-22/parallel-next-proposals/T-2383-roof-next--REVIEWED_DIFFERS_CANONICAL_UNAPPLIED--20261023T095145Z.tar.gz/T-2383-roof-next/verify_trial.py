"""Light parameter/geometry accumulation check, not Blender or image acceptance."""
import sys,types,json,math,hashlib
from pathlib import Path
H=Path(__file__).resolve().parent;R=Path('/workspace/chicago/chicago/4d')
sys.dont_write_bytecode=True;sys.modules.setdefault('bpy',types.ModuleType('bpy'));sys.path[:0]=[str(H/'fixture/generators'),str(R/'generators')]
from archetypes import frame_tavern as builder
from archetypes import frame_tavern_params as params
from common.mesh import MeshBuilder
MeshBuilder.to_object=lambda self,mats=None:(self,list(mats or []));builder.simple_material=lambda n,*a,**kw:(n,a,kw)
records={label:json.loads((H/f'fixture/data/{label}/sauganash_hotel.json').read_text()) for label in ['baseline','proposed']}
report={}
for label,r in records.items():
 ph=r['phases'][1];p=params.from_phase(ph,r);p.validate();mesh,mats=builder.build(p,r['id']+'__'+ph['id'])
 assert mesh.verts and all(math.isfinite(v) for point in mesh.verts for v in point)
 assert all(0<=v<=1 for v in mesh.conf)
 report[label]={'roof_pitch_deg':p.roof_pitch_deg,'end_windows':p.end_windows,'vertices':len(mesh.verts),'faces':len(mesh.faces),'bounds_xyz':[[min(p[i] for p in mesh.verts) for i in range(3)],[max(p[i] for p in mesh.verts) for i in range(3)]],'confidence_min_max':[min(mesh.conf),max(mesh.conf)],'generator_source_unchanged':True}
 assert hashlib.sha256((H/'fixture/generators/archetypes/frame_tavern.py').read_bytes()).hexdigest()==hashlib.sha256(Path('/tmp/chicago-next-model/T-3055-selective-integration/review-tree/chicago/4d/generators/archetypes/frame_tavern.py').read_bytes()).hexdigest()
cam=json.loads((H/'fixture/review/after/andreas-same-camera.json').read_text());a=math.radians(cam['yaw_deg']);eu,ev,eh=cam['eye'];cx,cy=cam['principal_px'];f=cam['focal_px']
def project(u,v,h):
 du,dv=u-eu,v-ev;D=du*math.sin(a)+dv*math.cos(a);return [cx+f*(du*math.cos(a)-dv*math.sin(a))/D,cy-f*(h-eh)/D]
for label,pitch in [('baseline',38),('proposed',25.2)]:report[label]['same_camera_near_apex_px']=project(10.17,4,5.5+4.25*math.tan(math.radians(pitch)))
report['proposed']['same_camera_attic_centre_px']=project(10.17,8*.54,6.1)
report['source_limits']={'camera':'same unsolved off-image-principal camera, not recalibrated','apex_pick_px':[648,350],'new_attic_frame_manual_rough_bounds_px':[625,415,690,535],'manual_pick_uncertainty_px':10,'old_banked_gate':'not edited; old atticbox is partialhatching/detail, not fullvisiblewindow','roof_confidence':'reconstructed; previous38degree typologyinference notcarriedtonewfit','actual_blender_browser':'UNRUN','image_match':'NOT CLAIMED'}
(H/'light-check.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS both records resolve/build finite accumulated geometry; existing attic guard passes; source/code/placement preserved; actual renderUNRUN')
