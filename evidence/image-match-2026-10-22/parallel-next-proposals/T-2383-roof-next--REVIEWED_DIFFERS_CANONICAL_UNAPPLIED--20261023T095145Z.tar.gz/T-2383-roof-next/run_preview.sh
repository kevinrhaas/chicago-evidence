#!/usr/bin/env bash
set -euo pipefail
trial_root=/tmp/chicago-next-model/T-2383-roof-next
export PYTHONPATH="/workspace/shared/python${PYTHONPATH:+:$PYTHONPATH}"
export PW_EXECUTABLE=/usr/bin/chromium
cd "$trial_root"
/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender -b -noaudio --factory-startup --python "$trial_root/export_trial.py" > "$trial_root/blender-export.log" 2>&1
cd "$trial_root/fixture"
for trial_label in before after; do
 node tools/photo_match.mjs "review/$trial_label/andreas-same-camera.json" --glb "assets/gltf/$trial_label/sauganash_hotel__frame_1831.glb" --out "review/$trial_label" > "$trial_root/photo-$trial_label.log" 2>&1
 node tools/photo_match.mjs "review/$trial_label/andreas-with-current-annex.json" --glb "assets/gltf/$trial_label/sauganash_hotel__frame_1831.glb" --out "review/$trial_label/with-current-annex" > "$trial_root/photo-$trial_label-with-annex.log" 2>&1
done
