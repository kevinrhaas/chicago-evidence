"""Guarded post-frame/source adoption. No apply until actual preview is inspected."""
from pathlib import Path
import argparse,json,copy,hashlib,os
H=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--apply',action='store_true');a=ap.parse_args();root=a.repo/'chicago/4d'
 path=root/'data/structures/sauganash_hotel.json';r=json.loads(path.read_text());old=copy.deepcopy(r);assert r['id']=='sauganash_hotel';i=next(i for i,p in enumerate(r['phases']) if p['id']=='frame_1831');f=r['phases'][i]['form']
 before=json.loads((H/'fixture/data/baseline/sauganash_hotel.json').read_text())['phases'][1]['form'];after=json.loads((H/'fixture/data/proposed/sauganash_hotel.json').read_text())['phases'][1]['form']
 for key in ['roof_pitch_deg','end_windows']:
  assert f[key]==before[key],f'{key}: reviewed post-frame baseline drifted'
  f[key]=copy.deepcopy(after[key])
 f['roof_pitch_deg']['note']=f['roof_pitch_deg']['note'].replace('ISOLATED T-2383 ROOF TRIAL, NOT A MEASURED HISTORICAL PITCH.','T-3055 WORKING PICTURE REFINEMENT, NOT A MEASURED HISTORICAL PITCH.')
 f['end_windows']['note']=f['end_windows']['note'].replace('ISOLATED T-2383 ATTIC TRIAL.','T-3055 WORKING ATTIC REFINEMENT.').replace('A real render/review is required; no match or source-date resolution is asserted.','The inspected working comparison remains different; no accepted match or source-date resolution is asserted.')
 # All non-target JSON remains exact; no unrelated source/research overwrite.
 restored=copy.deepcopy(r)
 for key in ['roof_pitch_deg','end_windows']:restored['phases'][i]['form'][key]=old['phases'][i]['form'][key]
 assert restored==old
 keys=json.loads((root/'data/reconstruction/name_pool_keys.json').read_text());keytext=json.dumps(keys)
 for p in ['phases[].form.roof_pitch_deg.note','phases[].form.end_windows.note','research_note']:assert p in keytext,p
 prefix='CURRENT T-3055 ROOF/ATTIC REFINEMENT: a reconstructed25.2-degree working pitch lowers the Sauganash roof toward the Andreas drawing under the retained provisional camera. The pictured attic sash is lower and slightly wider; its new numeric choices stay reconstructed. Main footprint, wall height, geographic placement, phase dates, source-dependent colours/shutters and whole-picture grade remain unchanged. The original picture comparison still differs, and the drawing/camera/date limits remain unresolved.\n\n'
 r['research_note']=prefix+r['research_note']
 ledgerpath=root/'docs/LIBERTIES.md';ledger=ledgerpath.read_text();fragment=(H/'liberty-candidate.md').read_text();assert '### L-sauganash-lower-roof-fit-2383' not in ledger
 review=H/'post-apply-review';review.mkdir(exist_ok=True);(review/'sauganash_hotel.json').write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n');(review/'LIBERTIES.md').write_text(ledger+'\n\n'+fragment)
 expect=json.loads(Path('/tmp/frame-integration/group-card-expected.json').read_text());target=expect['hotels']['sauganash_hotel'];target['record_sha256']=sha(review/'sauganash_hotel.json')
 for key in ['roof_pitch_deg','end_windows']:target['attributes'][key]={k:f[key][k] for k in ['value','confidence']}
 (review/'group-card-expected.with-sauganash-roof.json').write_text(json.dumps(expect,indent=2)+'\n')
 receipt={'source_record_sha256':sha(path),'new_record_sha256':sha(review/'sauganash_hotel.json'),'old_ledger_sha256':sha(ledgerpath),'declared_existing_namepool_paths':['phases[].form.roof_pitch_deg.note','phases[].form.end_windows.note','research_note'],'new_covers':['sauganash_hotel.frame_1831.form.roof_pitch_deg','sauganash_hotel.frame_1831.form.end_windows'],'new_covers_all_reconstructed':all(f[k]['confidence']=='reconstructed' for k in ['roof_pitch_deg','end_windows']),'all_other_values_preserved':True,'actual_view_review_required_before_apply':True}
 if a.apply:
  actual=json.loads((H/'actual-view-review.json').read_text());assert actual['actual_side_by_sides_viewed'] is True and actual['closer_without_new_regression'] is True and actual['verdict']=='differs'
  exports=json.loads((H/'actual-export-receipt.json').read_text());assert actual['export_receipt_sha256']==sha(H/'actual-export-receipt.json')
  assert actual['reviewed_generator_sha256']==sha(root/'generators/archetypes/frame_tavern.py')
  # Refuse canonical drift between planning and these writes.
  assert sha(path)==receipt['source_record_sha256'] and sha(ledgerpath)==receipt['old_ledger_sha256']
  backups=H/'post-apply-backup';backups.mkdir(exist_ok=True)
  for target,new in [(path,review/'sauganash_hotel.json'),(ledgerpath,review/'LIBERTIES.md')]:
   (backups/target.name).write_bytes(target.read_bytes());tmp=target.with_name('.'+target.name+'.roof-fit.tmp');tmp.write_bytes(new.read_bytes());os.replace(tmp,target)
  receipt['applied']=True
 else:receipt['applied']=False
 (H/'post-apply-overlay-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('APPLIED' if a.apply else 'REVIEW ONLY', 'two-attribute/Research overlay + append-only liberty; QA candidate remains outside app')
if __name__=='__main__':main()
