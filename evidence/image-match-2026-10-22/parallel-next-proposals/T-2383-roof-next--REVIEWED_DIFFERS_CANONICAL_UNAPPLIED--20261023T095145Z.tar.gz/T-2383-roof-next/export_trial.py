"""Pinned isolated emit_structure exports only; no build.py/manifests/canonical writes."""
from pathlib import Path
import json,sys,hashlib,math
import bpy
assert bpy.app.version[:3]==(4,5,3),bpy.app.version_string
H=Path(__file__).resolve().parent;R=Path('/workspace/chicago/chicago/4d');F=H/'fixture'
sys.path[:0]=[str(F/'generators'),str(R/'generators')]
import archetypes
archetypes.__path__.append(str(R/'generators/archetypes'))
from archetypes import frame_tavern as builder
from archetypes import frame_tavern_params as params
from common.mesh import reset_scene
import emit
assert Path(builder.__file__).resolve()==F/'generators/archetypes/frame_tavern.py'
assert emit.ARCHETYPES['frame_tavern']==(params.from_phase,builder.build)
receipt={'blender_version':bpy.app.version_string,'canonical_manifests_written':False,'actual_canonical_seed':True,'models':{}}
for label,outlabel in [('baseline','before'),('proposed','after')]:
 rec=json.loads((F/f'data/{label}/sauganash_hotel.json').read_text());phase=rec['phases'][1];name=rec['id']+'__'+phase['id']
 reset_scene();out=F/f'assets/gltf/{outlabel}/{name}.glb';out.parent.mkdir(parents=True,exist_ok=True)
 result=emit.emit_structure(rec,phase,'frame_tavern',out,bake=True,ao=False)
 ob=bpy.data.objects[name];me=ob.data;assert all(math.isfinite(v) for p in me.vertices for v in p.co)
 conf=[v.value for v in me.attributes['_CONFIDENCE'].data];assert all(0<=v<=1 for v in conf)
 receipt['models'][label]={'glb':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'tris':result.tris,'bounds_xyz':[[min(v.co[i] for v in me.vertices) for i in range(3)],[max(v.co[i] for v in me.vertices) for i in range(3)]],'confidence_range':[min(conf),max(conf)]}
(H/'actual-export-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('ISOLATED SAUGANASH EXPORTS COMPLETE; no official freshness or image-match claim')
