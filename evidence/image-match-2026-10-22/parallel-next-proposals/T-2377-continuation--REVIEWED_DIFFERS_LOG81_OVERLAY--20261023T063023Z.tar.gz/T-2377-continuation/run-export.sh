#!/usr/bin/env bash
set -euo pipefail
parcel="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fixture="$parcel/preview/proposed"
source "$fixture/generators/blender.pin"
blender_binary="/workspace/shared/blender-dl/$BLENDER_DIR/blender"
blender_archive="/workspace/shared/blender-dl/$(basename "$BLENDER_URL")"
printf '%s  %s\n' "$BLENDER_SHA256" "$blender_archive" | sha256sum -c -
python3 - "$blender_binary" "$BLENDER_VERSION" <<'PYVERSION'
import subprocess,sys
result=subprocess.run([sys.argv[1],'--version'],capture_output=True,text=True,check=True)
assert result.stdout.splitlines()[0].split()[1]==sys.argv[2]
print(result.stdout.splitlines()[0])
PYVERSION
cd "$fixture"
"$blender_binary" -b -noaudio --factory-startup --python generators/build.py -- --only hogan_store --wrote "$parcel/preview/wrote.txt" > "$parcel/preview/export.log" 2>&1

PYTHONDONTWRITEBYTECODE=1 python3 "$parcel/inspect_export.py"
