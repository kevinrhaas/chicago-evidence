# Hogan continuation — actual isolated preview reviewed, differs

The inspected Cameron source has a dark occupied doorway and a framed gable rectangle. The current committed model has a closed batten door and an obvious nine-pane gable sash. This follow-up prepares a bounded visible change using the future combined log-family baseline, including Miller's visible boarding refinement. It does not modify the checkout or the completed combined proposal.

`hogan-on-log-family.patch` is a **three-file overlay on the exact frozen files in `before/`**, copied from `/tmp/chicago-next-model/log-combined/boarding-refinement/candidate/chicago/4d` plus the current Hogan record. Apply the future combined proposal and Miller refinement first, then this overlay; do not apply this overlay to the present unmodified log modules. Parent merges the append-only `LIBERTY-entry.md` at the current end of LIBERTIES. No shared `common/openings.py` change is included.

- `front_door_state` defaults to `closed`, keyword-only. `recess` requires a stated single-storey front without compound rooms or an addition. Only the +y skin and proud chink strips are cut at each stated door rectangle; uncut faces retain winding/material/confidence. The opening uses framed returns and a dark blind back 0.30 m inside. There is no invented room, leaf position, hinge or figure.
- `end_openings.kind: hatch` reuses the current shared board-shutter kit at the old light's position and size. It is a reconstructed closure proxy for unresolved painted infill, not proof of boards or absence of glass.
- Existing `ridge_stack_head_m` is trialled at 0.75 m. It remains reconstructed; the ordinary cap and unknown stack fabric remain unresolved.

The footprint, coordinates/bearing, dates/use, eave, roof pitch, door/window stations/sizes and chimney station/width are preserved. Notes are rewritten to describe the final choices. `LIBERTY-entry.md` records exact reconstruction limits and source credit.

## Verification completed without heavy execution

`focused_check.py` runs the actual copied modules/common kits with only Blender object/material creation replaced by a raw recorder. All **81 future-family phase outputs** are exactly equal with the new option absent, including existing five proposed picture refinements; positional constructor parameters retain their order. Six invalid combinations are rejected. The actual Hogan trial has 236 polygons / 470 fan triangles, finite coordinates and no degenerate polygons. It proves the doorway skin/chink is cut, the back is 0.30 m inside with outward winding, and the hatch has no glazing faces. Disabling the cut fails on an uncut doorway. Patch apply-check passes against the frozen overlay base; syntax parses. `focused-check.json` and `mutation-no-cut.log` contain the results.

`freshness-scope.json` lists all 81 assets. All require an official regeneration when either log builder or resolved dataclass changes; only Hogan gains geometry from this overlay. The inherited five visible increments remain in its baseline. No recipes were restamped. No official full gate or supported bake has run for this continuation.

## Actual pinned export and exact-camera comparison

`preview/committed-before/` preserves the actual committed Hogan master `c196950ac57ec0e76d78698de43b956188eeb0ea2403264700991c9587bd5fe2` from HEAD `6156a0367a2379f0d986b88c7c8236c4ebec0e55`; `preview/proposed/` has the new copied generator/record. Both use **identical numeric camera, image, sky and placement**, copied from the existing research camera. No camera fitting or forced physical lens change is prepared. The fixture JSON paths differ only to make the local source available. `input-snapshot.json` and `preview/fixture-inputs.json` freeze exact bytes; `freeze-check.json` confirms the current Hogan record/source/master matched the snapshot when prepared.

Parent released the slot after the strict preflight and application/card QA. `run-export.sh` verified the pinned archive and Blender **4.5.3**, then the copied official build/emit exported only Hogan. Export and both exact-camera browser captures completed exit 0. Actual source/before/after views and original proposal PNG were inspected. Browser/export subprocesses closed; the slot was explicitly released to parent and Tremont before these light evidence writes.

Actual files:

- `preview/reviews/committed-before/cameron-1833-side-by-side.jpg` and `cameron-1833-render.png`: actual committed baseline.
- `preview/reviews/proposed/cameron-1833-side-by-side.jpg` and `cameron-1833-render.png`: actual proposed result.
- `visual-review.json`: differences, exact input hashes and accepted limits; both isolated match records are `differs`.
- `preview/export-review.json`: decoded contract essentials, finite/unit attributes, valid indices/materials/SCALAR confidence and current proposal recipe.

The actual preview visibly replaces the closed door with a dark framed recess. It replaces the obvious glazed gable sash with a boarded rectangle proxy; the board/ledge details and tone remain visibly unlike the unresolved source infill. The shorter stack reduces its visible height in the same camera; shaft/cap/fabric remain unmatched. This is progress toward the depicted openings, not a match claim.

The proposal GLB is **45,616 bytes / 470 triangles / 942 vertices / 8 materials**, SHA256 `687628d4780f2409e045c1cba6b53a871d02524657a475a6a2716591c0ab2182`. The actual committed baseline is 488 triangles / 978 vertices / 10 materials. Source, numeric camera, sky and placement are controlled identically. `preview/fixture-inputs.json` records pre-export inputs; the proposal master/manifest are intended outputs, not unchanged input files.

This is a fixture export, not an official all81 rebuild or accepted match. No AO/full supported bake, derivatives, production manifest writes, scene/grade compilation, source-card/app check, full gate, publisher or ticket mutation ran for this continuation. All other 80 family masters still require the centralized official rebuild after adopting the overlay; no recipe was restamped.

## Source and remaining work

Edgar S. Cameron, *Chicago's First Postoffice in 1833*, halftone after a painting, credited to the Chicago Historical Society. Source record `cameron_c1900_first_post_office` and actual local 2062 × 1507 surrogate are frozen. The existing inventory attributes public-domain age; original publication/holding remain independently unverified. Commons returned 403 in the prior research. No new remote clearance or image-pixel texture is claimed.

The retrospective painting supplies form, no geographic control or independent scale, and does not establish survival/use on 1 July 1835. The existing camera remains provisional and the source has inconsistent perspective. Generic wall/log/chink regularity, roof/board texture and tone, gable cladding, sash pattern, chimney cap/fabric, figure/scene/context and hidden elevations remain open. The **original T-2377 remains open** and its view remains `differs`. The actual continuation render is reviewed as `differs` and saved in the paths above.
