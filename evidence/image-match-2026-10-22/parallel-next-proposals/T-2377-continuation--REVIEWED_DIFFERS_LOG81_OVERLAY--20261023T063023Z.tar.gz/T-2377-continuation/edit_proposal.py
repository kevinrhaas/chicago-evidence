from pathlib import Path
import json,difflib
O=Path(__file__).resolve().parent; R=O/'candidate/chicago/4d'; B=O/'before/chicago/4d'
p=R/'generators/archetypes/log_dwelling_params.py';s=p.read_text()
s=s.replace('END_OPENING_KINDS = ("door", "window", "light")','END_OPENING_KINDS = ("door", "window", "light", "hatch")')
s=s.replace('"roof_condition", "compound_parts",','"roof_condition", "compound_parts", "front_door_state",')
s=s.replace('    door_h_m: float | None = None\n','    door_h_m: float | None = None\n    # Opt-in blind recess for a pictured dark, open doorway; no invented interior\n    # or leaf position. Closed remains the default. Restricted to stated fronts.\n    front_door_state: str = field(default="closed", kw_only=True)\n')
s=s.replace('    def validate(self) -> None:\n','    def validate(self) -> None:\n        if self.front_door_state not in ("closed", "recess"):\n            raise ParamError("front_door_state is closed or recess")\n        if self.front_door_state == "recess" and (self.front_set_out is None or self.compound_parts or self.frame_addition or self.stories != 1):\n            raise ParamError("a recessed front door needs a stated single-storey log front, without compound rooms or addition")\n')
s=s.replace('if kind == "light" and z is None or kind == "door" and z is not None:','if kind in ("light", "hatch") and z is None or kind == "door" and z is not None:')
s=s.replace('        door_h_m=(None if val("door_h_m") is None else float(val("door_h_m"))),','        door_h_m=(None if val("door_h_m") is None else float(val("door_h_m"))),\n        front_door_state=str(val("front_door_state", "closed")),')
p.write_text(s)
p=R/'generators/archetypes/log_dwelling.py';s=p.read_text()
s=s.replace('        ridge_z = _roof(b, params, cx0, cy0, cx1, cy1, wall_z, c_roof)','        if params.front_door_state == "recess":\n            _cut_front_door_recess(b, params, cy1)\n\n        ridge_z = _roof(b, params, cx0, cy0, cx1, cy1, wall_z, c_roof)',1)
s=s.replace('             shutters: bool = True) -> None:','             shutters: bool = True, door_state: str = "closed") -> None:',1)
s=s.replace('    if kind == "door":\n        if frame_wall:', '''    if kind == "door":
        if door_state == "recess":
            # The wall was actually cut back here, including proud chink strips.
            # A 0.30 m blind recess bounds the representation: no interior or
            # unseen leaf/hinge is inferred from Cameron's dark occupied doorway.
            back = -0.30 - w.skin
            openings.surround(b, w, u0, u1, z0, z1, conf, k, sill=False,
                              cap=False, casing_w=0.11, proud=0.045, back=back)
            openings.face(b, w, -0.30, u0, u1, z0, z1, conf, M_DARK)
            openings.threshold(b, w, u0, u1, z0, conf, k.casing, 0.11, 0.045)
            return
        if frame_wall:''',1)
s=s.replace('            _opening(b, "y", y1, u0, u1, z0, z1, 1, conf, kind=kind, shutters=shut)','            _opening(b, "y", y1, u0, u1, z0, z1, 1,\n                     p.conf("front_door_state", "reconstructed") if kind == "door" and p.front_door_state == "recess" else conf,\n                     kind=kind, shutters=shut, door_state=p.front_door_state)',1)
s=s.replace('        if kind == "light":\n            if z - LIGHT_HALF_H >= wall_z:', '        if kind in ("light", "hatch"):\n            if z - LIGHT_HALF_H >= wall_z:',1)
s=s.replace('            _opening(b, "x", x, yc - LIGHT_HALF_W, yc + LIGHT_HALF_W, z - LIGHT_HALF_H,\n                     z + LIGHT_HALF_H, out, c, shutters=False)','''            if kind == "hatch":
                # A boarded proxy for the painting's framed rectangle, not a
                # claim that glass is absent or that its closure is documented.
                w = openings.Wall("x", x, out, RELIEF_M)
                k = _kit(b)
                openings.surround(b, w, yc - LIGHT_HALF_W, yc + LIGHT_HALF_W,
                                  z - LIGHT_HALF_H, z + LIGHT_HALF_H, c, k,
                                  sill=False, cap=False, casing_w=0.07, head_w=0.08, proud=0.03)
                openings.board_shutter(b, w, yc - LIGHT_HALF_W, yc + LIGHT_HALF_W,
                                      z - LIGHT_HALF_H, z + LIGHT_HALF_H, c, k)
            else:
                _opening(b, "x", x, yc - LIGHT_HALF_W, yc + LIGHT_HALF_W, z - LIGHT_HALF_H,
                         z + LIGHT_HALF_H, out, c, shutters=False)''',1)
helper='''
def _cut_front_door_recess(b: MeshBuilder, p: LogDwellingParams, wall_y: float) -> None:
    """Cut only the +y wall skin and chink strips at the stated doorway.

    Four half-plane partitions subtract its rectangle without changing uncut
    faces, their winding, materials or confidence. The new opening kit emits a
    blind back and reveal; this is not a room/interior model.
    """
    def clip(poly, axis, bound, above):
        result = []
        for a, q in zip(poly, poly[1:] + poly[:1]):
            ai = a[axis] >= bound if above else a[axis] <= bound
            qi = q[axis] >= bound if above else q[axis] <= bound
            if ai:
                result.append(a)
            if ai != qi:
                t = (bound - a[axis]) / (q[axis] - a[axis])
                result.append(tuple(a[k] + t * (q[k] - a[k]) for k in range(3)))
        # Boundary vertices may coincide after successive cuts.
        clean = []
        for v in result:
            if not clean or sum((v[k]-clean[-1][k])**2 for k in range(3)) > 1e-20:
                clean.append(v)
        if len(clean) > 1 and sum((clean[0][k]-clean[-1][k])**2 for k in range(3)) < 1e-20:
            clean.pop()
        return clean
    def area(poly):
        n = [0., 0., 0.]
        for a,q in zip(poly, poly[1:] + poly[:1]):
            for k in range(3):
                i,j = (k+1)%3,(k+2)%3
                n[k] += (a[i]-q[i])*(a[j]+q[j])
        return sum(v*v for v in n)
    doors = [r for r in core_front_rects(p) if r[0] == "door"]
    for _, u0, u1, z0, z1 in doors:
        old = [(tuple(b.verts[i] for i in f), tuple(b.conf[i] for i in f), mat)
               for f,mat in zip(b.faces,b.mat_index)]
        b.verts, b.faces, b.conf, b.mat_index = [], [], [], []
        for points,confidence,mat in old:
            poly = list(points)
            if (all(v[1] >= wall_y-1e-9 for v in poly)
                    and min(v[0] for v in poly) < u1 and max(v[0] for v in poly) > u0
                    and min(v[2] for v in poly) < z1 and max(v[2] for v in poly) > z0):
                for axis,bound,above in [(0,u0,True),(0,u1,False),(2,z0,True),(2,z1,False)]:
                    outside = clip(poly,axis,bound,not above)
                    if len(outside) >= 3 and area(outside) > 1e-18:
                        b.add_poly(outside,max(confidence),mat)
                    poly = clip(poly,axis,bound,above)
                    if not poly:
                        break
            else:
                ids = b.add_poly(points,confidence[0],mat)
                for idx,c in zip(ids,confidence):
                    b.conf[idx] = c

'''
s=s.replace('def _kit(b: MeshBuilder)',helper+'def _kit(b: MeshBuilder)',1);p.write_text(s)
p=R/'data/structures/hogan_store.json';r=json.loads(p.read_text());f=r['phases'][0]['form'];src=['cameron_c1900_first_post_office']
f['front_door_state']={'value':'recess','confidence':'reconstructed','sources':src,'note':'Cameron depicts a dark open doorway occupied by a figure. A 0.30 m blind recess with an actually cut facade and framed returns replaces the generic closed board leaf. No interior, leaf position, hinges, figure identity, measured depth or July 1835 door state is attested; the reconstruction follows visible appearance in the retrospective 1833 scene.'}
f['end_openings']['value'][0]['kind']='hatch';f['end_openings']['note']+=' FOLLOW-UP: the visible framed gable rectangle is represented by a boarded hatch proxy rather than a nine-pane glazed sash. Board rhythm, ledges, closure, material and all numeric dimensions are reconstructed; the painting does not resolve its infill well enough to attest glass or boards.'
f['ridge_stack_head_m']={'value':0.75,'confidence':'reconstructed','sources':src,'note':'Provisional 0.75 m head rather than the generic 0.95 m, bounded by the short roof-piercing stack silhouette in Cameron. Not a measurement; painting perspective and unknown cap details remain unresolved. Shaft width and ridge station are unchanged.'}
p.write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
patch=[]
for p in sorted(R.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(R);old=B/rel
 if old.read_bytes()!=p.read_bytes():patch.extend(difflib.unified_diff(old.read_text().splitlines(True),p.read_text().splitlines(True),fromfile='a/chicago/4d/'+str(rel),tofile='b/chicago/4d/'+str(rel)))
(O/'hogan-on-log-family.patch').write_text(''.join(patch))
