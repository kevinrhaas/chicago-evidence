"""Glessner v4's original, metric PBR material library.

This module is deliberately local to the opt-in v4 builder. Nothing here changes
the shared town palette or a previous Glessner version. The maps are reconstructed
surface studies: ten numeric fabrics plus original generated granite and turf albedos.
Photographs were read as visual references, never sampled, traced, projected or embedded. Material names
retain the legacy roof_plane contract. Copper is a metal; the window surface is
dielectric glass with real environment reflections, not painted blue rectangles.

All scalar material colours are LINEAR. Albedo files are sRGB; normal and roughness
files are non-colour data. No atlas claims to be a measured surface of the house.
"""
from __future__ import annotations

import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TEXTURES = ROOT / "assets" / "textures" / "glessner-v4"
SURFACE_UV = "SurfaceUV"
BAKE_UV = "BakeUV"

# One repeat in metres. The module sizes are reconstructed. The tall brick repeat
# covers 32 small courses. Roof tiles use the HABS 6-inch width / 5-inch
# exposure in a 16-by-16 repeat; terracotta is the separate grain-only fabric.
TILE_M = {
    "granite": (1.6, 1.6),
    "brick": (1.7272, 2.1336),
    "flat_brick": (1.7272, 2.1336),
    "limestone": (1.2, 1.2),
    "mortar": (1.2, 1.2),
    "terracotta": (2.4384, 1.95072),
    "roof_tiles": (16 * 6 * .0254, 16 * 5 * .0254),
    "copper": (2.4, 2.4),
    "oak": (0.8, 2.4),
    "painted_wood": (0.8, 2.4),
    "turf": (2.4, 2.4),
    "gravel": (2.0, 2.0),
}
# The generated albedo depicts a smaller crystal field than the procedural
# normal/roughness repeat. UV0 stays metric; glTF carries this texture's scale.
ALBEDO_TILE_M = {"granite": (0.22, 0.22), "turf": (4.0, 4.0)}
# T-2210: Glessner's courtyard is light pink common brick with grey Joliet limestone
# lintels and sills (HABS ILL-1015 data p. 21; Glessner 1923). The K01 kit's Prairie
# houses wear this library's brick and limestone images too, so the courtyard's
# identity is carried here, in Glessner's own slots, and never by repainting them:
# brick slots draw the albedo-only court_brick image over brick's relief, and every
# limestone slot multiplies the cream study down to a grey. Linear, reconstructed hue.
COURT_BRICK = "court_brick"
LIMESTONE_GREY = (0.83, 0.88, 1.0)
# T-2390: the fabrics whose normal map's height field also ships as an occlusion
# map (generate.py `occluded`). It rides the normal map's UV and repeat, so a
# material carries it exactly when it carries that fabric's normal map.
OCCLUSION_FABRICS = frozenset({"granite"})
# LINEAR multipliers on the granite albedo (see build_materials). Reconstructed
# against the owner's colour photographs, 2026-10-12.
GRANITE_TINT = (1.0, 0.97, 0.94)
GRANITE_VARIANT_TINTS = ((0.97, 0.94, 0.92), (1.0, 0.98, 0.95), (0.95, 0.93, 0.92), (1.0, 0.96, 0.91))
# The split-face normal map was calibrated at 1.0 on flat 5x3 facets (T-2209).
# Since each stone is modelled bowed (masonry_house_v4_detail BOW_*), the map's
# 1.6 m repeat of large diagonal facets fought the crown and repeated stone to
# stone; at 0.6 it is grain and chip on the stone's own shape.
GRANITE_NORMAL_STRENGTH = 0.6

# Geometry and material module share these slots. New materials are appended so
# that the existing nine-part composition can be reused without reinterpretation.
GRANITE, BRICK, TRIM, ROOF, COPPER, GLASS, WOOD, LAWN, DRIVE = range(9)
MORTAR, IRON, GLASS_DARK = 9, 10, 11
GRANITE_VARIANTS = (12, 13, 14, 15)
BRICK_VARIANTS = (16, 17, 18)
ROOF_VARIANTS = (19, 20, 21)
LINEN = 22
PAINTED_WOOD = 23
ROUGH_TRIM = 24
GRASS_BLADES = (25, 26, 27)

SLOT_FABRIC = {
    0: "granite", 1: "brick", 2: "limestone", 3: "roof_tiles",
    4: "copper", 6: "oak", 7: "turf", 8: "gravel", 9: "mortar",
    12: "granite", 13: "granite", 14: "granite", 15: "granite",
    16: "brick", 17: "brick", 18: "brick",
    19: "terracotta", 20: "terracotta", 21: "terracotta",
    23: "painted_wood",
    # T-2210: the courtyard's rock-faced trim is Joliet limestone, so its UVs are
    # divided by the limestone repeat its albedo is drawn at (K01 contract metric_uv).
    24: "limestone",
    30: "flat_brick",
}


def _image(bpy, fabric, suffix, colour=False):
    """Load the exact committed map. Missing output is a build error, never a flat fallback."""
    ext = "jpg" if suffix == "basecolor" else "png"
    if fabric == "flat_brick": ext = "png"
    path = TEXTURES / f"{fabric}_{suffix}.{ext}"
    if fabric in ALBEDO_TILE_M and suffix == "basecolor":
        path = TEXTURES / ("turf_patch_photographic_basecolor.png" if fabric == "turf" else f"{fabric}_photographic_basecolor.png")
    if not path.is_file():
        raise FileNotFoundError(f"Glessner v4 PBR map missing: {path}")
    image = bpy.data.images.load(str(path), check_existing=True)
    image.colorspace_settings.name = "sRGB" if colour else "Non-Color"
    return image


def _plain(bpy, name, colour, roughness=0.8, metallic=0.0):
    material = bpy.data.materials.new(name)
    material.use_nodes = True
    material.use_backface_culling = False
    bsdf = material.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (*colour[:3], colour[3] if len(colour) > 3 else 1.0)
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["Metallic"].default_value = metallic
    return material


def _pbr(bpy, name, fabric, tint=(1, 1, 1), normal_strength=1.0, metallic=0.0,
         normal_fabric=None, albedo_fabric=None):
    material = _plain(bpy, name, (*tint, 1), metallic=metallic)
    nt = material.node_tree
    bsdf = nt.nodes.get("Principled BSDF")
    uv = nt.nodes.new("ShaderNodeUVMap")
    uv.uv_map = SURFACE_UV
    for suffix, input_name, colour in (("basecolor", "Base Color", True),
                                        ("roughness", "Roughness", False),
                                        ("normal", "Normal", False)):
        tex = nt.nodes.new("ShaderNodeTexImage")
        tex.label = f"Original {fabric} {suffix}"
        source_fabric = fabric
        if suffix == "normal" and normal_fabric:
            source_fabric = normal_fabric
        if suffix == "basecolor" and albedo_fabric:
            source_fabric = albedo_fabric
        tex.image = _image(bpy, source_fabric, suffix, colour)
        tex.interpolation = "Linear"
        tex.extension = "REPEAT"
        if suffix == "basecolor" and source_fabric in ALBEDO_TILE_M:
            mapping = nt.nodes.new("ShaderNodeMapping")
            mapping.vector_type = "POINT"
            target_u, target_v = ALBEDO_TILE_M[source_fabric]
            source_u, source_v = TILE_M[fabric]
            mapping.inputs["Scale"].default_value = (source_u / target_u, source_v / target_v, 1.0)
            nt.links.new(uv.outputs["UV"], mapping.inputs["Vector"])
            nt.links.new(mapping.outputs["Vector"], tex.inputs["Vector"])
        else:
            nt.links.new(uv.outputs["UV"], tex.inputs["Vector"])
        if suffix == "normal":
            normal = nt.nodes.new("ShaderNodeNormalMap")
            normal.uv_map = SURFACE_UV
            normal.inputs["Strength"].default_value = normal_strength
            nt.links.new(tex.outputs["Color"], normal.inputs["Color"])
            nt.links.new(normal.outputs["Normal"], bsdf.inputs["Normal"])
        elif suffix == "basecolor" and tint != (1, 1, 1):
            # The glTF exporter recognises this multiply and carries its constant
            # as baseColorFactor. Variants share images rather than cloning atlases.
            mix = nt.nodes.new("ShaderNodeMix")
            mix.data_type = "RGBA"
            mix.blend_type = "MULTIPLY"
            mix.inputs[0].default_value = 1.0
            mix.inputs[7].default_value = (*tint, 1.0)
            nt.links.new(tex.outputs["Color"], mix.inputs[6])
            nt.links.new(mix.outputs[2], bsdf.inputs[input_name])
        else:
            nt.links.new(tex.outputs["Color"], bsdf.inputs[input_name])
    occlusion_fabric = normal_fabric or fabric
    if occlusion_fabric in OCCLUSION_FABRICS:
        _occlusion(bpy, nt, uv, occlusion_fabric)
        material["occlusion_map"] = f"assets/textures/glessner-v4/{occlusion_fabric}_occlusion.png"
    material["surface_tier"] = "reconstructed"
    material["texture_generator"] = "assets/textures/glessner-v4/generate.py"
    material["tile_m"] = list(TILE_M[fabric])
    albedo_source = albedo_fabric or fabric
    if albedo_source in ALBEDO_TILE_M:
        material["albedo_provenance"] = ("assets/textures/glessner-v4/turf_patch_provenance.json" if albedo_source == "turf"
                                         else f"assets/textures/glessner-v4/{albedo_source}_photographic_provenance.json")
        material["albedo_tile_m"] = list(ALBEDO_TILE_M[albedo_source])
    return material


def _occlusion(bpy, nt, uv, fabric):
    """Wire `<fabric>_occlusion.png` as the glTF occlusionTexture (T-2390).

    The exporter recognises only a node group literally named "glTF Material Output"
    with an "Occlusion" input (generators/emit.py bake_ao uses the same group). The
    map shares the normal map's SurfaceUV with no mapping node, so it tiles with the
    relief it was computed from.
    """
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.label = f"Original {fabric} occlusion"
    tex.image = _image(bpy, fabric, "occlusion")
    tex.interpolation = "Linear"
    tex.extension = "REPEAT"
    nt.links.new(uv.outputs["UV"], tex.inputs["Vector"])
    group = bpy.data.node_groups.get("glTF Material Output")
    if group is None:
        group = bpy.data.node_groups.new("glTF Material Output", "ShaderNodeTree")
        group.interface.new_socket("Occlusion", in_out="INPUT", socket_type="NodeSocketFloat")
        group.nodes.new("NodeGroupInput")
    node = nt.nodes.new("ShaderNodeGroup")
    node.node_tree = group
    node.name = "glTF Material Output"
    split = nt.nodes.new("ShaderNodeSeparateColor")
    nt.links.new(tex.outputs["Color"], split.inputs["Color"])
    nt.links.new(split.outputs["Red"], node.inputs["Occlusion"])


def vine_material(bpy):
    """The same cutout shader for the exported model and its occlusion baker."""
    material=_plain(bpy, 'glessner_vines', (1,1,1,1), roughness=.52)
    nt=material.node_tree;bsdf=nt.nodes.get('Principled BSDF')
    tex=nt.nodes.new('ShaderNodeTexImage')
    tex.image=bpy.data.images.load(str(TEXTURES/'vines_atlas.png'),check_existing=True)
    tex.image.colorspace_settings.name='sRGB'
    tex.extension='CLIP'
    uv=nt.nodes.new('ShaderNodeUVMap');uv.uv_map=SURFACE_UV
    nt.links.new(uv.outputs['UV'],tex.inputs['Vector'])
    nt.links.new(tex.outputs['Color'],bsdf.inputs['Base Color'])
    # Blender 4.5's glTF exporter recognizes ROUND as MASK/cutoff0.5.
    # The same atlas supplies Full's leaves and Light's wall panels.
    mask=nt.nodes.new('ShaderNodeMath');mask.operation='ROUND'
    nt.links.new(tex.outputs['Alpha'],mask.inputs[0])
    nt.links.new(mask.outputs[0],bsdf.inputs['Alpha'])
    material['surface_tier']='reconstructed'
    material['texture_generator']='tools/generate_glessner_vines.py'
    return material


def build_materials(colours=None, rainwater=None, vines=None, surface_finish=None):
    """Return 28 fabric slots, rainwater (28), vines (29), then plain brick (30).

    Textured fabrics carry reconstructed absolute albedo in their maps. Turf and
    pale compacted gravel preserve the record's courtyard material reading.
    """
    import bpy
    colours = colours or {}
    mats = [
        # Owner, 2026-10-12, against his colour photographs of the Prairie Avenue
        # front: "the color of the granite stone facing is not as grey as you have
        # it". The photographs read a light pink-buff (sRGB red/green 1.05-1.13,
        # blue/green 0.90-0.94 on lit stone), so the multipliers that cooled the
        # albedo's feldspar toward grey are gone; the variants stay close to it.
        _pbr(bpy, "granite", "granite", tint=GRANITE_TINT, normal_strength=GRANITE_NORMAL_STRENGTH),
        _pbr(bpy, "brick", "brick", tint=(0.94, 0.94, 0.94), normal_strength=0.85,
             albedo_fabric=COURT_BRICK),
        # Dressed Joliet limestone: grey, and a little more tooth than the old cream.
        _pbr(bpy, "limestone_trim", "limestone", tint=LIMESTONE_GREY, normal_strength=0.85),
        _pbr(bpy, "roof_plane", "roof_tiles", normal_strength=0.70),
        _pbr(bpy, "copper", "copper", normal_strength=0.18, metallic=0.78),
        _plain(bpy, "glass", (0.945, 0.97, 0.953, 1), roughness=0.065),
        _pbr(bpy, "oak", "oak", normal_strength=0.45),
        _pbr(bpy, "lawn", "turf", normal_strength=0.25),
        _pbr(bpy, "drive", "gravel", normal_strength=0.55),
        _pbr(bpy, "mortar", "mortar", normal_strength=0.65),
        _plain(bpy, "iron", (0.013, 0.017, 0.015, 1), roughness=0.40, metallic=0.70),
        _plain(bpy, "glass_dark", (0.005, 0.007, 0.006, 1), roughness=0.92),
    ]
    glass = mats[GLASS].node_tree.nodes.get("Principled BSDF")
    glass.inputs["IOR"].default_value = 1.52
    # Actual thin dielectric glazing, with a dark interior backing and separate
    # linen blinds supplied by the geometry. An opaque painted pane hid those
    # blinds and made every window an identical blue-grey rectangle in review.
    # Clear dielectric glass has no diffuse component. The previous 6% diffuse
    # share lit the whole pane as a grey card and hid the dark recess. The
    # export/import study retains Fresnel reflections at IOR 1.52 with full
    # transmission; this is not opacity or removal of the glass surface.
    glass.inputs["Transmission Weight"].default_value = 1.0
    if "Specular IOR Level" in glass.inputs:
        glass.inputs["Specular IOR Level"].default_value = 0.50
    # Neutralise the generated image's warm feldspar balance while retaining
    # restrained grey, cream and slightly pink variation between quarried units.
    for i, tint in enumerate(GRANITE_VARIANT_TINTS):
        mats.append(_pbr(bpy, f"granite_{i + 1}", "granite", tint=tint, normal_strength=GRANITE_NORMAL_STRENGTH))
    # Restrained kiln variation shares the same clay fabric in every slot, and
    # the geometry's 60/20/14/6 unit distribution is unchanged. T-2210: every step
    # stays in the pink family, because Glessner names one brick for the whole
    # court ("the same texture and color"); the grey smoky unit read as a second
    # material. Slot names stay, as the LOD derivative lists them.
    mats.append(_pbr(bpy, "brick_dark_red", "brick", tint=(0.86, 0.76, 0.74), normal_strength=0.85,
                     albedo_fabric=COURT_BRICK))
    mats.append(_pbr(bpy, "brick_buff", "brick", tint=(1.0, 0.99, 0.97), normal_strength=0.85,
                     albedo_fabric=COURT_BRICK))
    mats.append(_pbr(bpy, "brick_smoky", "brick", tint=(0.66, 0.58, 0.56), normal_strength=0.85,
                     albedo_fabric=COURT_BRICK))
    for i, tint in enumerate(((0.92, 0.90, 0.88), (1.0, 0.99, 0.976), (0.97, 0.93, 0.91))):
        mats.append(_pbr(bpy, f"roof_plane_{i + 1}", "terracotta", tint=tint, normal_strength=0.70))
    mats.append(_plain(bpy, "linen_blind", (0.74, 0.73, 0.68, 1), roughness=0.98))
    mats.append(_pbr(bpy, "painted_wood", "painted_wood", normal_strength=0.30))
    # Rock-faced courtyard heads, sills, surrounds and tower belts: Joliet limestone
    # (HABS p. 21), no longer the street granite's crystal albedo. The fine grey
    # limestone study carries albedo and roughness; the split-face normal stays the
    # granite study's, drawn at limestone's 1.2 m repeat (its fracture planes about
    # 3-10 cm, not 4-14), while the geometry carries the large pitched faces.
    mats.append(_pbr(bpy, "rough_stone_trim", "limestone", tint=LIMESTONE_GREY, normal_strength=0.80,
                     normal_fabric="granite"))
    # Thin geometry blades sit over the independently textured lawn. These
    # muted linear colours sit below its average reflectance, avoiding lime tips.
    for name, colour in (("dark", (.045, .080, .017)),
                         ("middle", (.075, .120, .028)),
                         ("light", (.105, .150, .045))):
        mats.append(_plain(bpy, f"turf_blade_{name}", (*colour, 1), roughness=0.92))
    if rainwater:
        # Taylor resolves relief against the darker receiver body. A heavily
        # metallic near-black iron material loses that relief without an
        # environment map. This bounded matte oxidised/coated surface is not
        # a colour or alloy recovered from the monochrome photograph.
        finish=rainwater['finish']
        mats.append(_plain(bpy, "rainwater_metal", (*finish['linear_rgb'],1),
                           roughness=finish['roughness'],metallic=finish['metallic']))
    if vines:
        if len(mats)!=29:
            raise ValueError('Vine material follows the complete Glessner rainwater library')
        mats.append(vine_material(bpy))
    if surface_finish:
        from archetypes.masonry_house_v4_finish import validate
        validate(surface_finish)
        f=surface_finish['flat_brick']
        if len(mats)!=30 or any(abs(a-b)>1e-9 for a,b in zip(
                TILE_M['flat_brick'],(f['width_m']*f['columns'],f['course_m']*f['rows']))):
            raise ValueError('Plain brick must follow the complete library at its declared metric repeat')
        mat=_pbr(bpy, "flat_brick", "flat_brick", normal_strength=.85)
        mat['texture_generator']='tools/generate_glessner_finish.py'
        mats.append(mat)
    return mats


def assign_metric_uvs(ob, roof_uvs=None):
    """Metric UVs for walls and pitched planes; preserve them through emit.unwrap.

    SurfaceUV is the first / render-active layer and every PBR node requests it
    explicitly. BakeUV is the edit-active layer: the legacy pipeline's smart
    unwrap edits that disposable layer instead. glTF therefore carries the
    textures on TEXCOORD_0, which the web batching renderer preserves.

    Facades project a horizontal tangent and global height. Roofs project a
    horizontal contour tangent and a unit vector uphill, so tile courses follow
    the physical slope instead of stretching vertically. All coordinates are
    metres before the per-fabric repeat is applied.
    """
    from mathutils import Vector
    mesh = ob.data
    surface = mesh.uv_layers.get(SURFACE_UV) or mesh.uv_layers.new(name=SURFACE_UV)
    for poly in mesh.polygons:
        n = poly.normal.normalized()
        horizontal = Vector((-n.y, n.x, 0.0))
        if horizontal.length < 1e-6:
            horizontal = Vector((1.0, 0.0, 0.0))
            uphill = Vector((0.0, 1.0, 0.0))
        else:
            horizontal.normalize()
            uphill = n.cross(horizontal).normalized()
            if uphill.z < 0:
                uphill.negate()
                horizontal.negate()
        fabric = SLOT_FABRIC.get(poly.material_index)
        tu, tv = TILE_M.get(fabric, (1.0, 1.0))
        for li in poly.loop_indices:
            co = mesh.vertices[mesh.loops[li].vertex_index].co
            uv=(roof_uvs or {}).get(mesh.loops[li].vertex_index,(co.dot(horizontal),co.dot(uphill)))
            surface.data[li].uv = (uv[0] / tu, uv[1] / tv)
    surface.active_render = True
    scratch = mesh.uv_layers.get(BAKE_UV) or mesh.uv_layers.new(name=BAKE_UV)
    mesh.uv_layers.active = scratch
    surface.active_render = True
    ob["metric_surface_uv"] = SURFACE_UV
    return ob
