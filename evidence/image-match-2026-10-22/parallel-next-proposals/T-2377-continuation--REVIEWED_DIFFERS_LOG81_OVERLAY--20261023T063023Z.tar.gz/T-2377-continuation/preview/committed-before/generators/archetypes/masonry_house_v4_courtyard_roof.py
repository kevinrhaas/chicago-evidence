"""T-2016 courtyard roof junctions, in the shared engine-neutral metric frame."""
from __future__ import annotations


def north(params):
    return next(r for r in params.ranges if r['name']=='north_range')


def north_height(params,y):
    n=north(params)
    a,za=(n['y0'],n['eave_lo_z']) if y<=n['ridge_at'] else (n['y1'],n['eave_hi_z'])
    return za+(n['ridge_z']-za)*(y-a)/(n['ridge_at']-a)


def dining(params):
    """Two tiled valley returns, each split into exact planar triangles."""
    if params.detail.get('dining_crested_connection'):
        return dining_connection(params)
    y=params.bays[0];n=north(params);ap=tuple(y['apex']);z=y['band_top_z']
    left,right=sorted((tuple(y['pts'][0]),tuple(y['pts'][-1])))
    spread=.24
    triangles=[]
    for pt,sign in ((left,-1),(right,1)):
        bottom=(*pt,z);ox=pt[0]+sign*spread
        upper=(ox,ap[1],ap[2]);eave=(ox,n['y0'],n['eave_lo_z'])
        triangles.extend([(ap,upper,bottom),(upper,eave,bottom)])
        # Continue the two returns over the same 20 cm eave as their host;
        # otherwise a remnant of the uncut host forms a bar across the copper.
        low=(ox,n['y0']-.20,north_height(params,n['y0']-.20))
        toe=(pt[0],pt[1]-.20,z)
        triangles.extend([(eave,low,bottom),(low,toe,bottom)])
    cut=[(left[0]-spread,n['y0']-.201),(right[0]+spread,n['y0']-.201),
         (right[0]+spread,ap[1]),(left[0]-spread,ap[1])]
    return triangles,cut


def dining_connection(params):
    """A raised cross ridge, intersected with the unchanged north roof plane.

    The copper hip ends over the bay shoulders. Two planar tile slopes continue
    its ridge back to the main ridge. Their valleys are intersections, not a
    rectangular hole cut down to the clerestory (T-2157).
    """
    bay=params.bays[0];n=north(params);ap=tuple(bay['apex'])
    back=(ap[0],n['ridge_at'],n['ridge_z'])
    eave_y=n['y0']-n.get('eave_lo_overhang',.20);eave_z=north_height(params,eave_y)
    # T-2183: at the extended eave, the tile and copper have the same front
    # section (apex -> apron fold -> shoulder). Intersect BOTH pitches with
    # the host. One triangle here would bridge the lower copper fold.
    if n.get('eave_lo_overhang',.20)>.21:
        polygons=[];shoulders=[];folds=[]
        for pt in (bay['pts'][1],bay['pts'][-2]):
            shoulder=(pt[0],ap[1],bay['band_top_z'])
            ring=(pt[0]+(ap[0]-pt[0])*.18,ap[1],
                  shoulder[2]+(ap[2]-shoulder[2])*.11)
            slope=(n['ridge_z']-n['eave_lo_z'])/(n['ridge_at']-n['y0'])
            valley=(ring[0],n['y0']+(ring[2]-n['eave_lo_z'])/slope,ring[2])
            polygons.extend([[ap,ring,valley,back],[ring,shoulder,valley]])
            shoulders.append(shoulder[:2]);folds.append(valley[:2])
        return polygons,[shoulders[0],shoulders[1],folds[1],back[:2],folds[0]]
    polygons=[];valleys=[]
    for pt in (bay['pts'][1],bay['pts'][-2]):
        shoulder=(pt[0],ap[1],bay['band_top_z'])
        ring=(shoulder[0]+(ap[0]-shoulder[0])*.18,ap[1],
              shoulder[2]+(ap[2]-shoulder[2])*.11)
        # The connector has a level ridge, matching the host. Its height only
        # varies across x, so this is the exact tile/host intersection at eave.
        fraction=(ap[2]-eave_z)/(ap[2]-ring[2])
        valley=(ap[0]+(ring[0]-ap[0])*fraction,eave_y,eave_z)
        toe=(shoulder[0],eave_y,shoulder[2])
        ring_toe=(ring[0],eave_y,ring[2])
        ridge_eave=(ap[0],eave_y,ap[2])
        # Convex pieces: a fan over the concave five-corner outline would
        # bridge its valley and put submerged tile triangles inside the host.
        polygons.extend([[back,ridge_eave,valley],
                         [ap,ring,ring_toe,ridge_eave],
                         [ring,shoulder,toe,ring_toe]])
        valleys.append(valley)
    # Only the triangular cross-roof intersection replaces the host. The eave
    # on both sides retains precisely its existing line and slope.
    cut=[(valleys[0][0],eave_y-1e-7),(valleys[1][0],eave_y-1e-7),back[:2]]
    return polygons,cut


def add_dining_roof(b,params):
    """Copper hip/apron, standing seams, tiled cross ridge and matching crests."""
    import math
    from archetypes import masonry_house as legacy
    from archetypes.masonry_house_v4_roof_crests import add_ridge_crest
    bay=params.bays[0];ap=tuple(bay['apex']);z=bay['band_top_z']
    copper,roof=4,3;conf=bay['conf_roof']
    outline=[(*p,z) for p in bay['pts'][1:-1]]
    # A shallow flared apron below the steeper cap, as in the owner close-up.
    # Fractions and seam stock are reconstructed, not survey measurements.
    ring=[(p[0]+(ap[0]-p[0])*.18,p[1]+(ap[1]-p[1])*.18,
           z+(ap[2]-z)*.11) for p in outline]

    def mix(a,c,t):return tuple(a[k]+(c[k]-a[k])*t for k in range(3))
    from archetypes.masonry_house_v4_copper import fold, _unit, _cross
    def normal(pts):
        n=_unit(legacy._normal(pts))
        return n if n[2]>0 else tuple(-v for v in n)
    def sheet(pts,n):
        for index in b.raw(pts,conf,copper,n):
            v=b.verts[index]
            b.roof_uvs[index]=(math.atan2(v[1]-ap[1],v[0]-ap[0])*2.4,math.dist(v,ap))
    def lap(a,c,n):
        # Put the 25-mm lap entirely on the uphill sheet, not hovering across
        # the apron crease. Both low sheets still share the exact fold line.
        side=_unit(_cross(_unit(tuple(c[k]-a[k] for k in range(3))),n))
        sign=1 if sum(side[k]*(ap[k]-(a[k]+c[k])/2) for k in range(3))>0 else -1
        a,c=[tuple(p[k]+side[k]*.0125*sign for k in range(3)) for p in (a,c)]
        fold(b,a,c,n,.025,.002)

    for i,(p,q) in enumerate(zip(outline,outline[1:])):
        a,c=ring[i:i+2]
        lower,upper=normal([p,q,c,a]),normal([a,c,ap])
        sheet([p,q,c,a],lower)
        sheet([a,c,ap],upper)
        lap(a,c,upper)
        for t in (1/3,2/3):lap(mix(a,ap,t),mix(c,ap,t),upper)
        count=max(1,round(math.dist(p,q)/.48))
        for j in range(count):
            foot=mix(p,q,j/count);joint=mix(a,c,j/count)
            fold(b,foot,joint,lower)
            fold(b,joint,mix(ap,joint,.12/math.dist(ap,joint)),upper)
        b.raw([(p[0],p[1],z-.055),(q[0],q[1],z-.055),q,p],conf,copper)
    fold(b,outline[-1],ring[-1],lower)
    fold(b,ring[-1],mix(ap,ring[-1],.12/math.dist(ap,ring[-1])),upper)

    for poly in dining_connection(params)[0]:
        legacy._two_sided_roof(b,poly,conf,roof)
    # Same cap radius, spacing and raised terracotta collars as the main ridge.
    end=north(params)['ridge_at'];start=ap[1]+.30;step=.36
    if params.detail.get('roof_edges'):
        from archetypes.masonry_house_v4_roof_edges import ridge_chain
        ridge_chain(b,params,{'axis':'y','ridge_at':ap[0],'ridge_z':ap[2]},start,
                    end-params.detail['roof_edges']['cap_radius_m'],join_end=True)
    else:
        for i in range(math.ceil((end-start)/step)):
            lo=start+i*step;hi=min(end,lo+step-.012)
            for j in range(12):
                a,c=math.pi*j/12,math.pi*(j+1)/12
                def P(angle,y):return (ap[0]+.14*math.cos(angle),y,ap[2]+.055+.14*math.sin(angle))
                b.raw([P(a,lo),P(c,lo),P(c,hi),P(a,hi)],conf,19+i%3,(0,0,1))
            add_ridge_crest(b,'y',ap[0],ap[2],lo,hi,conf,19+i%3)
    # Folded copper terminal over the hip apex, meeting the first tile cap.
    for j in range(12):
        a,c=math.pi*j/12,math.pi*(j+1)/12
        def P(angle,y):return (ap[0]+.15*math.cos(angle),y,ap[2]+.055+.15*math.sin(angle))
        b.raw([P(a,ap[1]-.025),P(c,ap[1]-.025),P(c,start),P(a,start)],conf,copper,(0,0,1))
    # The visible hip end is folded closed, not an open pipe above the apex.
    b.raw([P(math.pi*j/12,ap[1]-.025) for j in range(13)]+
          [(ap[0]-.15,ap[1]-.025,ap[2]),(ap[0]+.15,ap[1]-.025,ap[2])],
          conf,copper,(0,-1,0))


def copper(params):
    """The low bow hood, trimmed to the north and east host intersections."""
    from archetypes.masonry_house_v4_copper import surface
    return surface(params)


def clip_host(pts,params):
    """Remove replaced tiles without changing any neighbouring roof plane."""
    from archetypes.masonry_house_v4_detail import subtract
    from archetypes.masonry_house import _normal
    holes=[]
    if params.detail.get('dining_roof_junction'):
        if north(params).get('eave_lo_overhang',.20)>.21:
            # The apron makes the whole footprint concave: subtract its
            # convex pieces, never hand a concave cut to the convex clipper.
            holes.extend([[(v[0],v[1]) for v in poly] for poly in dining(params)[0]])
        else:holes.append(dining(params)[1])
    if params.detail.get('continuous_copper_corner'):holes.extend(copper(params)[1])
    if params.detail.get('north_copper_cladding'):
        from archetypes.masonry_house_v4_copper import north_cladding
        holes.extend([[(p[0],p[1]) for p in face] for face in north_cladding(params)])
    normal=_normal(pts);a=pts[0]
    def point(p):
        x,y=p
        return (x,y,a[2]-(normal[0]*(x-a[0])+normal[1]*(y-a[1]))/normal[2])
    poly=[(p[0],p[1]) for p in pts]
    if sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(poly,poly[1:]+poly[:1]))<0:poly.reverse()
    return [[point(p) for p in f] for f in subtract(poly,holes)]


def wall_profile(params,lo,hi,z):
    if params.detail.get('dining_crested_connection'):
        if north(params).get('eave_lo_overhang',.20)<=.21:
            return [(lo,z),(hi,z)]
        # Close the masonry to the low hood's actual underside. Its peak is
        # now exactly at the east endpoint, which must participate in the
        # profile rather than being reset to the lower north-wall datum.
        y=north(params)['y0'];points=[(lo,z),(hi,z)]
        west=next((r for r in params.ranges if r.get('stable_roof',{}).get('level_courtyard_gable')),None)
        if west:
            # Close the small masonry wedge under the restored west slope at
            # the inside corner, just as the copper return is closed below.
            g=west['stable_roof']
            pitch=(g['court_edge_z']-west['ridge_z'])/(g['court_edge_x']-west['ridge_at'])
            join=west['ridge_at']+(z-west['ridge_z'])/pitch
            if lo<join<hi:
                points[0]=(lo,max(z,west['ridge_z']+pitch*(lo-west['ridge_at'])))
                points.append((join,z))
        base=sorted(points)
        def base_height(x):
            for a,c in zip(base,base[1:]):
                if a[0]<=x<=c[0]:
                    return a[1]+(c[1]-a[1])*(x-a[0])/(c[0]-a[0])
            return z
        hood=[]
        for tri in copper(params)[0]:
            for a,b in zip(tri,tri[1:]+tri[:1]):
                if abs(b[1]-a[1])<1e-9:continue
                t=(y-a[1])/(b[1]-a[1])
                if 0<=t<=1:
                    x=a[0]+(b[0]-a[0])*t
                    if lo-1e-8<=x<=hi+1e-8:
                        hood.append((max(lo,min(hi,x)),max(z,a[2]+(b[2]-a[2])*t)))
        merged={}
        for x,h in hood:merged[round(x,7)]=max(h,merged.get(round(x,7),z))
        if not merged:return base
        hood=sorted(merged.items());a,c=hood[0][0],hood[-1][0]
        # Keep the ordinary north wall level OUTSIDE the hood. Interpolating
        # directly from the remote west corner to the first hood point would
        # invent a long rising wall and push it through the tiled roof.
        points=[q for q in base if q[0]<a-1e-8 or q[0]>c+1e-8]
        if a>lo+1e-8:points.append((a,base_height(a)))
        points.extend(hood)
        if c<hi-1e-8:points.append((c,base_height(c)))
        return sorted(points,key=lambda q:q[0])
    bay=params.bays[0];a,c=sorted((bay['pts'][0][0],bay['pts'][-1][0]))
    return [(lo,z),(a-.24,z),(a,bay['band_top_z']),
            (c,bay['band_top_z']),(c+.24,z),(hi,z)]
