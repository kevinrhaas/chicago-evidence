from pathlib import Path
import shutil,json,hashlib
O=Path(__file__).resolve().parent;R=Path('/workspace/chicago/chicago/4d'); P=O/'preview';assert not P.exists();P.mkdir()
meta={};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for kind in ['committed-before','proposed']:
 D=P/kind
 shutil.copytree(R/'generators',D/'generators',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 for src in (O/'candidate/chicago/4d/generators').rglob('*.py'):
  dest=D/'generators'/src.relative_to(O/'candidate/chicago/4d/generators');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
 for rel in ['data/scenes','renderers/web/vendor/three-0.185.1']:shutil.copytree(R/rel,D/rel)
 for rel in ['data/datum.json','renderers/web/js/keith-stone.js','tools/photo_match.mjs','tools/photo_match_group.mjs']:
  dest=D/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/rel,dest)
 (D/'node_modules').symlink_to(Path('/workspace/node_modules').resolve(),target_is_directory=True)
 recroot=O/('candidate' if kind=='proposed' else 'before')/'chicago/4d'
 for rel in ['data/structures/hogan_store.json','data/sources/cameron_c1900_first_post_office.json']:
  dest=D/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(recroot/rel,dest)
 sources=set()
 def scan(v):
  if isinstance(v,dict):
   for k,x in v.items():
    if k=='sources' and isinstance(x,list):sources.update(s for s in x if isinstance(s,str))
    else:scan(x)
  elif isinstance(v,list):
   for x in v:scan(x)
 scan(json.loads((D/'data/structures/hogan_store.json').read_text()))
 for sid in sources:
  dest=D/f'data/sources/{sid}.json'
  if not dest.exists():shutil.copy2(R/f'data/sources/{sid}.json',dest)
 for sc in (R/'data/scenes').glob('*.json'):
  src=R/f'data/sidecars/{sc.stem}/hogan_store.json'
  if src.exists():dest=D/f'data/sidecars/{sc.stem}/hogan_store.json';dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
 manifest=json.loads((R/'assets/manifest.json').read_text());manifest['assets']={k:v for k,v in manifest['assets'].items() if v.get('structure_id')=='hogan_store'}
 dest=D/'assets/gltf/hogan_store__log_1831.glb';dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(O/'committed-before.glb',dest)
 (D/'assets/manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 cam=json.loads((O/'before/chicago/4d/docs/RESEARCH/hogan-picture-match-T-2377/cameron-1833.json').read_text())
 cam['photo']='source.jpg';shutil.copy2(O/'source.jpg',D/'source.jpg');(D/'cameron-1833.json').write_text(json.dumps(cam,indent=2)+'\n')
 (D/'FIXTURE-ONLY.txt').write_text('Proposal-only blind doorway/gable hatch trial. Copied official generator/build/emit, pinned Blender4.5.3 only. No accepted image gate, bake, derivatives, production manifests, room model or ticket mutation. Sidecars carry unchanged placement.\n')
 meta[kind]={str(f.relative_to(D)):sha(f) for f in sorted(D.rglob('*')) if f.is_file() and not f.is_symlink() and 'node_modules' not in f.parts}
(P/'fixture-inputs.json').write_text(json.dumps(meta,indent=2)+'\n')
print(P)
