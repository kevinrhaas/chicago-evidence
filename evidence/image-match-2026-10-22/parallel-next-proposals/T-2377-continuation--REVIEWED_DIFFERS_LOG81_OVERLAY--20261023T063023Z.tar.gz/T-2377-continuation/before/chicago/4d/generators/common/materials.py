"""The material sheet, as code — `docs/RESEARCH/materials.md` wired into the town.

R-W2a measured 1,353 material slots out of the shipped GLBs and wrote them up as a
document. The document reached nothing: every colour and every roughness in this
project was still a literal sitting in whichever module happened to paint that
surface, and two generators — the nine Blender archetypes and the pure-Python
`inferred_placeholder` — carried two palettes that shared not one value. T-0007 is
the parcel that makes the sheet the source. This module IS the sheet: every row
below is a row of materials.md §1.1 or §2, and every archetype and the placeholder
generator now read their colours and their roughness from here rather than from a
constant of their own.

## What a row is

A surface is TWO things, and keeping them apart is what lets the sheet describe a
whitewashed clapboard wall without a combinatorial table:

* a **substrate** — what the wall is made OF. It owns the roughness, the tiling rate
  and the dimensional module that rate is a whole multiple of (materials.md §3.2:
  every tile is 32 clapboard courses, or 12 log courses, or 20 sheathing boards, so
  the seam lands on the surface's own rhythm rather than on a number chosen to look
  right). No substrate owns a colour.
* a **finish** — what it WEARS. It owns the colour, and the three coating finishes
  own a roughness too, because materials.md §2.1 argues them explicitly: a limewashed
  wall is the flattest surface in the town, and lead paint the only smooth one. §2.1
  calls those three "overlay, not a tile" for exactly this reason — they modify the
  substrate's value and gloss and leave its rhythm showing through.

So `resolve(substrate, finish)` gives the pair the exporter needs, and the tile rate
sits beside it for the bake half to draw its atlas against the same numbers.

## COLOUR SPACE — materials.md §3.4's one process rule

**Every value here is LINEAR**, which is what glTF `baseColorFactor` means and what a
Blender node colour is. The six wall finishes and the four roof conditions are
written as hex because that is the form `inferred_placeholder.py` committed them in,
and materials.md §3.4 proved from the whitewash pair that they were authored as
linear values rather than sRGB ones — read as sRGB the two generators' whitewash
would sit 40 % apart in blue instead of 12.6 %. `hex_rgba` therefore divides by 255
and does nothing else, and this paragraph is the "state the space in the file that
holds it" §3.4 asks for. A PNG atlas is sRGB by convention; the bake half has to
convert, and this is the sentence that tells it so.

## THE ROOF COVERING — what was open, what was misread, and what is now claimed

This file used to say, under the heading WHAT IS NOT CLAIMED HERE, that **no source in
this repository states what any Chicago roof of 1835 was covered with**, and therefore
that there was no `shingle` row and no `roof_board` row. That sentence was read for a
year as the reason the roofs could not be given a material, and `outbuilding.py`,
`frame_dwelling.py` and `frame_storefront.py` each quote it back in a comment beside a
roughness literal they declined to choose.

**It overstated its own research.** What `docs/RESEARCH/materials.md` §2.2 grades is
narrower and more permissive than the summary above:

| substrate | evidence | grade |
|---|---|---|
| `shingle` | the one direct attestation in the repository — the North Side school of 1833, *"a frame building twenty-six by thirty-eight feet; twelve-foot posts; sheeted and shingled roof"* | **attested** for that building; **inferred** as the ordinary covering of a framed building here |
| `roof_board` | `outbuilding.py`: *"a shingle field on an outbuilding would be claiming a finish"* | **inferred, and well argued** |

The covering was never the open question. The open question was the **exposure** — how
much of each shingle the weather sees, and therefore the tiling rate — and §2.2 said
exactly how to close it: *pick the exposure from a source or record a liberty*. **L263
recorded the liberty** on the owner's ruling of 2026-09-20: 0.14 m, the same exposure
this project committed for clapboard at T-0049, giving a 4.48 m tile at 228.6 px/m.

So the two rows are here now, and `roof_plane` survives below them as the fallback for
a roof whose covering is genuinely undecidable — carrying zero records today, and kept
rather than deleted so that a reader can see the question was answered and not removed.
`roof_substrate()` is the dealing rule and states its own argument; **L266** is the
liberty for the part of that rule §2.2 does not grade.

What is still graded by CONDITION and not by material is the roof's **finish** — fresh,
weathered, darkened, patched — which 218 records carry. A covering and a weathering are
two different claims and this file keeps them apart.

Likewise still absent: a brick or stone course dimension. §3.2 says plainly that no
source this project holds gives one, so `brick` and `stone` carry `tile_m = None`
rather than a modern brick quietly chosen to make the arithmetic land. L264 committed a
brick course on the same day L263 committed the shingle exposure and it is NOT wired
here — that is the brick half of T-1450's acceptance and it is still open; this parcel
is the roof half and does not reach into it.

## The blast radius, stated

`generators/mesh_inputs.py` hashes every byte of `generators/common/` into every
archetype's mesh inputs, so an edit here stales the whole town. `frame_tavern.py`
keeps its own two colours for precisely that reason and is right to: a value only one
archetype reads does not belong in a shared file. What is here is the opposite case —
the wall finishes, the roof conditions and the log fabric are read by every building
generator in the project and by the placeholder path as well, and holding one copy of
them is the whole point of a sheet.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass

# The sheet this module is. Quoted in every row so a reader can find the argument.
SHEET = "docs/RESEARCH/materials.md"

# Every colour in this file is linear. See the module docstring.
COLOUR_SPACE = "linear"


def hex_rgba(value: str) -> tuple[float, float, float, float]:
    """A hex triple as a LINEAR rgba. Divides by 255 and does nothing else.

    Byte-compatible with `generators/inferred_placeholder.py`'s own helper, which is
    load-bearing: that generator's 94 committed GLBs are gated on their exact bytes,
    so the two paths have to produce the same floats from the same string.
    """
    value = value.lstrip("#")
    return tuple(int(value[i:i + 2], 16) / 255 for i in (0, 2, 4)) + (1.0,)


@dataclass(frozen=True)
class Substrate:
    """What a surface is made of: its roughness, its tile, and the module the tile is
    a whole multiple of. Never a colour — that is the finish's."""

    key: str
    roughness: float
    tier: str
    note: str
    #: metres of surface one square of the atlas covers; None where materials.md
    #: §3.2 says the rate cannot be set without a source it does not hold
    tile_m: float | None = None
    #: the surface's own committed dimensional constant, which `tile_m` is a whole
    #: number of — the condition §3.2 puts on every rate
    module_m: float | None = None
    #: texel density at 1024², which §4 W2 bounds at 128–256 px/m
    texel_px_per_m: float | None = None


@dataclass(frozen=True)
class Finish:
    """What a surface wears. Owns the colour; owns a roughness only where
    materials.md §2.1 argues one, which is the three coatings."""

    key: str
    rgba: tuple[float, float, float, float]
    tier: str
    note: str
    #: a coating states its own gloss and overrides the substrate's (§2.1)
    roughness: float | None = None
    #: True for the three coatings, which are overlays rather than fabrics. The trim
    #: rule below reads it, because boards took the paint and bare stock did not.
    coating: bool = False


# --------------------------------------------------------------- the substrates
#
# materials.md §2.1 and §2.2, one row per surface that actually ships. Tiles are the
# sheet's own arithmetic — 32 clapboard courses of 0.14 m, 12 log courses of 0.34 m,
# 20 sheathing boards of 0.229 m — and land inside the 128–256 px/m band by
# construction rather than by choice.

SUBSTRATES: dict[str, Substrate] = {
    "clapboard": Substrate(
        key="clapboard", roughness=0.86, tier="inferred",
        tile_m=4.48, module_m=0.14, texel_px_per_m=228.6,
        note="Riven or sawn horizontal siding weathering silver. The form is attested "
             "on the Sauganash, the agency house and the Green Tree; the 0.14 m "
             "exposure is a period stock, committed as the archetypes' own default "
             "since T-0049. 32 courses to the tile."),
    "board_and_batten": Substrate(
        key="board_and_batten", roughness=0.88, tier="reconstructed",
        tile_m=4.272, module_m=0.356, texel_px_per_m=239.7,
        note="Vertical boards with a batten over each joint at the usual 14 in "
             "set-out. NO source in this repository puts board-and-batten on any "
             "named Chicago building in 1835 — the set-out is typological. 12 battens "
             "to the tile."),
    "vertical_board": Substrate(
        key="vertical_board", roughness=0.90, tier="reconstructed",
        tile_m=4.58, module_m=0.229, texel_px_per_m=223.6,
        note="Plain vertical sawn boards, no batten. One record carries it and its "
             "own note says INVENTED, NOT DERIVED. 20 boards to the tile."),
    "hewn_log": Substrate(
        key="hewn_log", roughness=0.92, tier="attested",
        tile_m=4.08, module_m=0.34, texel_px_per_m=251.0,
        note="Squared log courses. The log town is the best-attested fabric here; the "
             "0.34 m course is logwork.py's, argued from a squared wall log. 12 "
             "courses to the tile."),
    "chinking": Substrate(
        key="chinking", roughness=0.95, tier="inferred",
        tile_m=2.04, module_m=None, texel_px_per_m=251.0,
        note="Clay and lime between the courses, standing proud. Near-uniform: dried "
             "lime does not scatter the way timber does. The tile is HALF the log's "
             "at half the map, which holds the same 251 px/m — a wall whose two "
             "materials render at two densities reads as two walls."),
    "sawn_board": Substrate(
        key="sawn_board", roughness=0.94, tier="inferred",
        tile_m=4.00, module_m=None, texel_px_per_m=256.0,
        note="Plain sawn stock, random widths, gappy. The widths are geometry — the "
             "outbuilding deals them board by board — so the sheet carries grain "
             "only."),
    "heavy_timber": Substrate(
        key="heavy_timber", roughness=0.90, tier="inferred",
        tile_m=4.00, module_m=None, texel_px_per_m=256.0,
        note="Posts, plates, jambs, headers and battens. Heavy stock holds moisture "
             "and weathers darker than siding. materials.md §4 finding 3 recorded that "
             "TWO different materials shared this name and only this one shipped; "
             "T-0126 splits them, and this substrate is the WEATHERED one — the "
             "`HEAVY_TIMBER` finish. Fresh mill stock on an exposed storefront frame "
             "is the `SAWN_FRAMING` finish and carries its own 0.92."),
    "brick": Substrate(
        key="brick", roughness=0.90, tier="inferred",
        tile_m=None, module_m=None, texel_px_per_m=None,
        note="Fired brick in courses. Two records are attested brick. NO source in "
             "this repository gives a brick or a course dimension, so the rate is "
             "UNRESOLVABLE (§3.2) and is left None rather than filled with a modern "
             "brick."),
    "stone": Substrate(
        key="stone", roughness=0.93, tier="reconstructed",
        tile_m=None, module_m=None, texel_px_per_m=None,
        note="Rubble or dressed masonry. The one record carrying it says bare masonry "
             "is unattested and a limewash the commoner Great Lakes finish. Rate "
             "unresolvable, as brick."),
    "earth": Substrate(
        key="earth", roughness=0.95, tier="inferred",
        tile_m=4.00, module_m=None, texel_px_per_m=None,
        note="Trodden ground and turf. Both records carrying it say plainly that no "
             "source describes it. A noise tile: no rhythm to be integral with."),
    # ------------------------------------------------------------- the roof rows
    #
    # THREE rows, and the module docstring is the argument for why there used to be
    # one. `roof_substrate()` below is the rule that deals them, and it states its
    # own reasoning; L266 is the liberty for the part of it §2.2 does not grade.
    #
    # NEITHER ROUGHNESS IS NEW, and that is deliberate. materials.md §3.1 says in
    # terms that the deliverable is a roughness map and not better constants, and
    # that a round should not be spent re-tuning the 18 numbers. So `shingle` takes
    # the 0.90 the framed archetypes have always shipped and `roof_board` takes the
    # 0.93 `outbuilding.py` has always shipped — NOT `sawn_board`'s 0.94, which is a
    # wall row and would move 130 roofs for no reason anybody argued. What this
    # parcel moves is not a float; it is that each roof is drawn on a row that says
    # what it is made of.
    "shingle": Substrate(
        key="shingle", roughness=0.90, tier="inferred",
        tile_m=4.48, module_m=0.14, texel_px_per_m=228.6,
        note="Riven shingles lapped down the slope. materials.md §2.2 grades the "
             "covering ATTESTED on the North Side school of 1833 — 'a frame building "
             "twenty-six by thirty-eight feet; twelve-foot posts; sheeted and "
             "shingled roof' — and INFERRED as the ordinary covering of a framed "
             "building here. The 0.14 m exposure is L263, taken on the owner's "
             "ruling of 2026-09-20 and set to the clapboard exposure this project "
             "already committed at T-0049, so the town's two lapped surfaces are "
             "dealt from one number. 32 courses to the tile."),
    "roof_board": Substrate(
        key="roof_board", roughness=0.93, tier="inferred",
        tile_m=4.00, module_m=None, texel_px_per_m=256.0,
        note="Plain sawn boards laid down the slope, no shingle field. §2.2 grades "
             "this inferred and well argued, and the argument is `outbuilding.py`'s "
             "own: 'a shingle field on an outbuilding would be claiming a finish'. "
             "The tile is `sawn_board`'s 4.00 m because it IS sawn board — the "
             "widths are random and the surface carries grain, not a rhythm, so "
             "there is no module for the rate to be integral with. The 0.93 is the "
             "outbuilding's own committed roughness and is not re-argued."),
    # THE FALLBACK, and it is kept rather than deleted. `roof_substrate()` resolves
    # every archetype in this dataset to shingle or board, so this row carries ZERO
    # records today — which is the point. A reader who comes to this file asking what
    # a roof of unstated covering is drawn on should find the question answered and
    # the row still standing, not find that it was quietly removed; and the next
    # archetype whose covering nobody can argue has somewhere honest to land.
    "roof_plane": Substrate(
        key="roof_plane", roughness=0.90, tier="reconstructed",
        tile_m=None, module_m=None, texel_px_per_m=None,
        note="The roof plane, COVERING GENUINELY UNDECIDABLE — the fallback, and it "
             "carries no record in this dataset. No covering, therefore no exposure, "
             "therefore no tile: a roof that lands here is one nothing can be said "
             "about, and it is drawn untextured rather than dealt a material it has "
             "no claim to."),
}


# ------------------------------------------------------------------ the finishes
#
# materials.md §1.1's six wall finishes and §2.1's three coatings. The six are the
# vocabulary the DATA speaks — `reconstruction.finish_key`, dealt by the 665-roof
# programme and committed on 222 records — and until this parcel they were read by
# `inferred_placeholder.py` alone, so a weathered wall and a fresh one were the same
# pixel on all 244 archetype buildings (finding 4). The hexes are verbatim from that
# generator, which is what keeps its 94 committed GLBs byte-identical.

FINISHES: dict[str, Finish] = {
    "fresh_timber": Finish(
        key="fresh_timber", rgba=hex_rgba("#C3A478"), tier="reconstructed",
        note="New sawn stock, still pale and warm. §1.1; 37 placeholder walls and, "
             "from T-0007, every archetype building the programme dealt it to."),
    "weathered_timber": Finish(
        key="weathered_timber", rgba=hex_rgba("#817D72"), tier="reconstructed",
        note="Bare stock silvered off by a season or two of weather. §1.1."),
    "mixed_patch": Finish(
        key="mixed_patch", rgba=hex_rgba("#BFAE8E"), tier="reconstructed",
        note="A wall patched from more than one stock, averaged. §1.1."),
    "ochre": Finish(
        key="ochre", rgba=hex_rgba("#A98B52"), tier="reconstructed",
        note="An earth-pigment wash. §1.1. No named Chicago building in this "
             "repository is attested ochre; it is a period finish dealt by the "
             "programme, not a reading of any source about any building."),
    "whitewash": Finish(
        key="whitewash", rgba=hex_rgba("#D8D1BC"), roughness=0.90, coating=True,
        tier="reconstructed",
        note="Lime wash over whatever the wall is made of — it coats the substrate "
             "and does not replace it, so the courses stay showing through. Chalky "
             "and flat: the LEAST glossy surface in the town (§2.1). ATTESTED where a "
             "record attests it and never a default. This value converges the two "
             "palettes materials.md §3.4 measured 12.6 % apart in blue: the "
             "archetypes' 0.88/0.87/0.83 is retired in favour of the vocabulary the "
             "records already speak (finding 5)."),
    "red_oxide": Finish(
        key="red_oxide", rgba=hex_rgba("#7A4437"), roughness=0.85, coating=True,
        tier="reconstructed",
        note="Iron-oxide paint. §2.1 grades it conjectural at the building level and "
             "inferred as a period finish: no named Chicago building here is attested "
             "red. One row for both paths, replacing the archetypes' 0.55/0.16/0.13."),
    "white_paint": Finish(
        key="white_paint", rgba=(0.90, 0.89, 0.85, 1.0), roughness=0.60, coating=True,
        tier="attested",
        note="Lead paint, a remarkable expense here and ATTESTED for exactly one "
             "building — the Sauganash, 'a pretentious white two-story building'. "
             "0.60 is the sheet's number and the point of it: the only smooth wall in "
             "Chicago, which is why its neighbours' plainness reads."),
    "yellow_paint": Finish(
        key="yellow_paint", rgba=hex_rgba("#B68A22"), roughness=0.65, coating=True,
        tier="attested",
        note="Yellow oil paint, and ATTESTED for exactly one building — Kelsey's "
             "boarding-house on the sand hills, 'a small yellow house' (Bonnell, quoted "
             "by Andreas). The HUE is the source's; the VALUE is not, and no source "
             "states one: a straw yellow of the kind yellow ochre ground in oil with "
             "white lead gives, the cheapest yellow a house painter could buy, kept "
             "clear of the `ochre` wash so the one stated colour does not read as a "
             "dealt finish. 0.65 sits beside lead paint's 0.60 because it is the same "
             "kind of coat. L291 owns the invention (T-1724)."),
    "unpainted": Finish(
        key="unpainted", rgba=(0.52, 0.44, 0.34, 1.0), tier="reconstructed",
        note="The archetypes' own committed unpainted tone, measured in §1 across 94 "
             "shipped wall slots. Kept as the default for a record that deals no "
             "finish, so that no NAMED building changes colour without a record "
             "saying it should."),
    "weathered_board": Finish(
        key="weathered_board", rgba=(0.335, 0.310, 0.268, 1.0), tier="reconstructed",
        note="The outbuilding's own board tone, and deliberately NOT the taverns' "
             "unpainted brown: bare sawn softwood silvers within a season, and a shed "
             "carrying a tavern's colour would read as the same building at a "
             "distance. §1, 69 shipped `board` slots."),
}


# --------------------------------------------------------------- roof conditions
#
# §1.1's four. `roof_condition` is stated on 218 records and, until this parcel, was
# read by `inferred_placeholder.py` alone. It says how weathered the roof is. It does
# NOT say what the roof is made of, and nothing in this project does — see the module
# docstring.

ROOF_CONDITIONS: dict[str, Finish] = {
    "fresh": Finish(key="fresh", rgba=hex_rgba("#5E4938"), tier="reconstructed",
                    note="Newly laid, still brown. §1.1."),
    "weathered": Finish(key="weathered", rgba=hex_rgba("#6C6258"), tier="reconstructed",
                        note="Silvered off, the palest of the four. §1.1."),
    "darkened": Finish(key="darkened", rgba=hex_rgba("#4B4037"), tier="reconstructed",
                       note="Weather-blackened. §1.1."),
    "patched": Finish(key="patched", rgba=hex_rgba("#3C3732"), tier="reconstructed",
                      note="Mended more than once, the darkest of the four. §1.1."),
}

#: What a roof wears where no record deals a condition — the one colour §1 measured
#: across all 234 shipped `roof` slots. A named building whose record says nothing
#: about its roof keeps exactly the roof it had.
ROOF_DEFAULT = Finish(
    key="roof_default", rgba=(0.34, 0.30, 0.27, 1.0), tier="reconstructed",
    note="The archetypes' committed roof tone, §1. Unchanged by T-0007 wherever a "
         "record deals no condition, which is every named building in the town.")


# ------------------------------------------------------------------- other rows
#
# §1 and §2.3. These ship today at these values and are held here so one file
# answers "what is this surface" for every generator. Values are unchanged, with
# the openings-and-glazing family below as T-0126's exception — that one converges.

HEWN_LOG = Finish(
    key="hewn_log", rgba=(0.340, 0.266, 0.188, 1.0), tier="inferred",
    note="Weathered hewn oak. logwork.py argues it about a fifth darker than the "
         "paler LOG_RGBA it replaced, having measured that a first pass at 0.295 put "
         "the log dwellings visibly in a different town from the Sauganash's wing. "
         "materials.md finding 2: the Sauganash's own wing never followed that "
         "reconciliation and is the ONE log wall in Chicago built from the other "
         "value. T-0007 brings it across, so the town has one log.")
CHINKING = Finish(
    key="chinking", rgba=(0.700, 0.670, 0.590, 1.0), tier="inferred",
    note="Clay and lime, pale where the logs are dark, standing proud so it catches "
         "light. §1, 50 shipped slots.")


# ------------------------------------------------- openings and glazing (T-0126)
#
# materials.md §2.3's other half, and the family T-0007 deliberately left. Two rows,
# and the reason there are two rather than one is the only distinction the evidence
# actually supports: a pane reflects the sky and a hole does not.
#
# WHAT WAS MEASURED FIRST, because the ticket's own count no longer holds. §2.3 was
# written against FOUR values on four generators; re-measured over `assets/gltf/`
# on 2026-08-24 there are THREE, on 287 slots, because the pure-Python placeholder
# path that carried the fourth ships nothing any more — `inferred_placeholder.py
# --check` reports "0 flagged placeholder GLBs; 226 superseded by a canonical bake",
# so `placeholder_opening_dark` (#2D3D33 at 0.70, a green nothing in this repository
# argues for) is dead code and not a shipped surface. What ships is:
#
#   dark      0.070/0.080/0.090  r 0.35  112 slots  frame_dwelling
#   dark      0.070/0.080/0.090  r 0.40   58 slots  log_dwelling, fort_structure, palisade
#   interior  0.072/0.068/0.060  r 0.60  117 slots  outbuilding
#
# Two colours 0.03 apart at their widest and three roughnesses spread over 0.25 —
# which is the half a visitor sees, because roughness is what decides whether a
# surface catches the sun. A doorway on a frame dwelling glinted and the identical
# doorway on the shed beside it did not.

DARK = Finish(
    key="dark", rgba=(0.072, 0.068, 0.060, 1.0), roughness=0.60,
    tier="reconstructed",
    note="ONE ROW for every dark recess in the town: a window or door panel on a "
         "frame dwelling, a log cabin's door, window and gable vent, the fort's "
         "loopholes and its root-house door, and the outbuilding's interior seen "
         "through a board gap, a vent or an open bay. 'Surfaces, not holes' — "
         "frame_dwelling._opening says it in terms: at this level of detail these "
         "are flat panels standing in for an interior, and interiors are out of "
         "scope. THE COLOUR is the warm near-black this sheet already carried (117 "
         "of the 287 slots ship it); the cool 0.070/0.080/0.090 the other 170 wore "
         "is retired, because a cool cast is SKY, and sky in an opening is the "
         "`GLASS` row's business. Light that reaches an unlit room here has bounced "
         "off timber and lime, so it comes back warm. Near-black rather than black: "
         "an interior in daylight is dark, not a hole in the world. THE ROUGHNESS "
         "is bounded rather than read, and both bounds are values this project "
         "already ships. It cannot sit at `GLASS`'s 0.25, because EVERY ONE of the "
         "287 slots carries surfaces that are certainly not glazed — doorways, gaps "
         "between boards, open bays, loopholes, gable vents, the stockade's shut "
         "gate leaves — and at a glazing gloss an open bay takes the same sun glint "
         "a shop window does. It cannot sit at the bare fabrics behind it either "
         "(heavy_timber 0.90, hewn_log 0.92, sawn_board 0.94), because 156 of the "
         "287 ALSO carry windows, and on the 112 frame dwellings among them every "
         "window is sized off the Green Tree's attested 6x8 lights — so those panels "
         "stand for glazed sash, and a sash with no specular reads as a hole knocked "
         "in the wall. Nothing states where between the two it sits, so it sits at "
         "the midpoint, 0.575, taken to the 0.60 the town already speaks rather "
         "than to a newly invented 0.575 that would mean the same thing 0.025 away "
         "(buildings.js: nothing in the dataset uses two roughness values closer "
         "than 0.01). §2.3; docs/LIBERTIES.md, 'One dark behind every opening in "
         "Chicago' — cited by TITLE because a number in this file cannot be "
         "renumbered without re-staling all 342 masters, and six liberty numbers "
         "collided across parallel branches on 2026-08-24 alone. NOT EVERY USE IS AN OPENING and "
         "this row does not pretend otherwise: the fort's sun-dial plate and its "
         "lighthouse lantern drum, the log dwelling's iron hinge straps and the "
         "stockade's two shut gate leaves ride on the same slot. All are dark and "
         "small; separating them would add a material to an asset, which T-0126's "
         "acceptance forbids and K36(a) is the reason for.")
GLASS = Finish(
    key="glass", rgba=(0.1134, 0.1164, 0.1144, 1.0), roughness=0.065,
    tier="reconstructed",
    note="GLESSNER'S DARK PANE, SINCE T-2278 (owner, 2026-10-10: reuse the dark glass "
         "the 1904 house is drawn with wherever an 1835 building could reasonably have "
         "had glass). T-2109/T-2183 draw Glessner's glass at every detail setting as an "
         "opaque plate: the GLB's own glass colour (0.945, 0.970, 0.953) at 12 per "
         "cent, at the GLB's roughness 0.065, metalness 0. These are exactly those "
         "numbers, so a pane on South Water and a pane on Prairie Avenue are one glass: "
         "a dark, glossy surface that carries the sky, which is how plate glass reads "
         "from a street in daylight. Before T-2278 this row was 0.09/0.11/0.13 at 0.25 "
         "and only the storefronts and taverns used it; the dwellings drew their panes "
         "in the rough `DARK` row, so a house window read as a hole. THAT THE TOWN WAS "
         "GLAZED IS NOW ATTESTED, NOT ONLY INFERRED: window glass by the box, in 8x10, "
         "7x9 and 5x10 in panes, and ready-made window sash were advertised in the "
         "Chicago Democrat 1833-35 by Philo Carpenter, John H. Kinzie, J. K. Botsford, "
         "P. F. W. Peck and Jones & King (data/businesses/biz_*.json, each with its "
         "issues), and the Green Tree's 6x8 lights are the one pane attested on a "
         "building (chicagology_prefire127). What a pane looks like at fifty metres is "
         "still stated nowhere, and the VALUE stays reconstructed: it is Glessner's "
         "drawn glass, adopted, not measured. Sash, casing, sill and cap are geometry, "
         "built by `common/openings.py`.")

# -------------------------------------------------- heavy timber, split (T-0126)
#
# materials.md §4 finding 3, discharged: `timber` was ONE NAME over TWO materials
# 3.2x apart in linear red, and both are defensible because they are not the same
# thing. Re-measured 2026-08-24: `outbuilding`'s ships on 117 slots and
# `frame_storefront`'s ships on ZERO, exactly as the finding said — no record in
# this dataset turns `framing_exposed` on, so the paler value has never been
# rendered and the collision is LATENT. It would have surfaced the first time a
# storefront exposed its framing beside a shed, as two different materials wearing
# one name. Two rows, two names, and the archetypes' material slots renamed to
# match, so the name in the shipped GLB says which of the two it is.
HEAVY_TIMBER = Finish(
    key="heavy_timber", rgba=(0.208, 0.172, 0.128, 1.0), roughness=0.90,
    tier="inferred",
    note="The outbuilding's heavy squared stock: posts, plates, jambs, headers and "
         "battens. Heavy stock holds moisture and weathers darker than thin sawn "
         "siding, and a post darkens from the foot up — outbuilding.py chose it "
         "against a render in which the door frame came out warmer and no darker "
         "than the siding around it. Roughness is the `heavy_timber` substrate's, "
         "restated on the row so the two timbers can be read side by side. Shipped "
         "as the material `heavy_timber`, renamed from `timber` by T-0126.")
SAWN_FRAMING = Finish(
    key="sawn_framing", rgba=(0.66, 0.56, 0.40, 1.0), roughness=0.92,
    tier="reconstructed",
    note="Fresh sawn framing on a storefront that exposes it — paler than the wall "
         "it stands in, not darker, because this is new mill stock and not a shed's "
         "weathered heavy timber. Lumber came into Chicago sawn, from St Joseph by "
         "scow. GRADED DOWN from the `inferred` its shared row carried: no record "
         "in this dataset turns `framing_exposed` on, so there is no building this "
         "value is an inference ABOUT, and a value that has never been rendered "
         "cannot have been reasoned from anything it renders. Shipped as the "
         "material `sawn_framing`, renamed from `timber` by T-0126; it still "
         "reaches no GLB, and now it cannot be mistaken for the row above when it "
         "does.")


# ---------------------------------------------- the bare masonry, and the stack
#
# R-W2a finding 1, discharged by T-0008: `frame_dwelling`, `frame_storefront` and
# `log_dwelling` built their stacks with the ROOF material, so every stack in the town
# was painted the colour of the roof it passes through — wrong in a way a visitor sees
# from the street. Measured off the resolved parameters of the committed masters, that
# is **157 stacks on 143 buildings** counting `frame_tavern`, which took the same fix;
# R-W2a's own "219 on 199" does not reproduce on this tree and is left as it was
# written rather than quietly restated. The fabric question the finding left open is
# answered in `docs/RESEARCH/chimneys.md`, and its answer is TWO materials rather than
# one, because the two stacks are two different objects:
#
# * A FRAMED house's stack rises inside the building and breaks the roof at the ridge.
#   It has to be masonry to do that, and the masonry Chicago had is brick: Blodgett's
#   brick-yard opened on the North Side in the spring of 1833 (`brickyard_north_side`,
#   Andreas), the Lake House went up in brick in 1835, and the one coloured witness to
#   any Chicago stack — the Petford watercolour of the Sauganash, image 8 of the
#   owner's 2026-08-18 brief — paints **brick chimneys** on a framed clapboard block.
#   INFERRED, and the colour is not a new one: it is `frame_tavern`'s committed
#   `BRICK_RGBA`, wired to the Sauganash by T-0092, which now lives here so the town
#   has ONE brick instead of an archetype-local copy per archetype (§2.3's complaint).
# * A LOG cabin's stack stands OUTSIDE the gable, and `log_dwelling._stack` has always
#   said why in as many words: a stick-and-clay or fieldstone stack built against the
#   wall can be pulled away from the building when it catches fire. Nothing in this
#   repository attests any log house's stack, so this is RECONSTRUCTED — the daub the
#   sticks are laid up in, BOUNDED between the chinking it is made of and the palest
#   roof it stands beside, and sitting at the midpoint because nothing says where else
#   it sits. `docs/LIBERTIES.md` L26 owns every stack's POSITION; L168 owns its fabric.
#
# Neither row claims a stack for a building whose record does not count one, and
# neither is a covering claim about the roof it passes through.

# T-0332 RENAMED THIS ROW, AND THE RENAME IS THE WHOLE OF THAT TICKET. It was
# `CHIMNEY_BRICK` from T-0008, when a stack was the only thing in the town made of
# brick. T-0267 brought the fort's wall onto it and T-0092's tavern stack was already
# on it, so one row named for one surface was being read by three, two of them
# attested brick WALLS and neither of them a chimney. The name is now the FABRIC —
# which is what a material sheet row is — and the surfaces ask for it through the two
# selectors below rather than naming it, so nothing has to be renamed again the next
# time a third kind of brick surface arrives. materials.md §9.5 filed it; §10 closes
# it. No alias is kept: three call sites is not a compatibility surface, and a sheet
# carrying two names for one row is the drift this rename exists to end.
#
# The VALUE is untouched, to the last decimal, and that is the check on the parcel:
# a rename that repaints a building is the wrong change.

BRICK = Finish(
    key="brick", rgba=(0.45, 0.23, 0.17, 1.0), roughness=0.85, tier="inferred",
    note="Unpainted soft-mud brick — the town's ONE brick, on a chimney and on a "
         "wall alike. Verbatim `frame_tavern.BRICK_RGBA` (T-0092), off the Petford "
         "watercolour's brick chimneys, so the Sauganash's own stacks do not change "
         "colour when the rest of the town's stop being roof-coloured. It is NOT a "
         "claim that the fort's 1816 brick matched the town's 1833 brick: nothing "
         "here shows the colour of any fort surface, and the row is read there "
         "because it is the only brick this project has argued. "
         "docs/RESEARCH/chimneys.md §2 and §6, materials.md §9 and §10.")
CHIMNEY_STICK_CLAY = Finish(
    key="chimney_stick_clay", rgba=(0.562, 0.527, 0.468, 1.0), roughness=0.95,
    tier="reconstructed",
    note="A cat-and-clay stack: split sticks laid up in courses and daubed inside and "
         "out with the same clay the wall below it is chinked with. Nothing attests any "
         "Chicago log house's stack, so the tone is BOUNDED rather than read, and both "
         "bounds are values this project already ships: it cannot be as pale as the "
         "CHINKING (0.700/0.670/0.590), which is the same clay sitting sheltered under "
         "an eave while a stack takes weather and smoke on every face; and it cannot be "
         "as dark as the palest ROOF CONDITION (weathered, 0.424/0.384/0.345), or it "
         "stops reading as masonry against the roof it stands beside — which is the "
         "whole defect T-0008 exists to fix. Nothing states where between the two it "
         "sits, so it sits at the midpoint of the two, to three decimals. Roughness "
         "is the sheet's `earth` substrate, because the surface is daub. "
         "docs/LIBERTIES.md L168, docs/RESEARCH/chimneys.md §3.")


# ------------------------------------------------------------------- selection
#
# The half materials.md §2 calls "selected by". Until T-0007 the answer for most
# rows was "nothing".

#: Which substrate a wall is, given what the record says it is built of and clad in.
#: `cladding` is stated on 27 records and read on 22 (finding 3); everything else
#: falls back on the construction, which every record states.
_CLADDING_SUBSTRATE = {
    "clapboard": "clapboard",
    "board_and_batten": "board_and_batten",
    "vertical_board": "vertical_board",
}
_CONSTRUCTION_SUBSTRATE = {
    "log": "hewn_log",
    "hewn_log": "hewn_log",
    "plank": "sawn_board",
    "board": "sawn_board",
    "brick": "brick",
    "stone": "stone",
    "earth": "earth",
    # A framed wall says nothing about its skin, and every framed building in this
    # dataset that does not state a cladding is clapboarded — which is the commonest
    # wall in the town and the one the archetypes build by default.
    "balloon_frame": "clapboard",
    "braced_frame": "clapboard",
    "frame": "clapboard",
}

#: `paint` values that name a coating rather than a bare wall, mapped onto the
#: finish rows. `unpainted` is not here: it means the wall wears its own stock, and
#: which stock is then the record's `finish_key` to say.
_PAINT_FINISH = {
    "white": "white_paint",
    "whitewash": "whitewash",
    "red": "red_oxide",
    "red_oxide": "red_oxide",
    "ochre": "ochre",
    "yellow": "yellow_paint",
}


def wall_substrate(construction: str | None = None, cladding: str | None = None,
                   default: str = "clapboard") -> Substrate:
    """The substrate row for a wall — the roughness and the tile, never the colour."""
    if cladding and cladding in _CLADDING_SUBSTRATE:
        return SUBSTRATES[_CLADDING_SUBSTRATE[cladding]]
    if construction and construction in _CONSTRUCTION_SUBSTRATE:
        return SUBSTRATES[_CONSTRUCTION_SUBSTRATE[construction]]
    return SUBSTRATES[default]


def wall_finish(paint: str | None = None, finish_key: str | None = None,
                default: str = "unpainted") -> Finish:
    """Which finish a wall wears, and the ORDER is the argument.

    1. **A stated coating wins.** Where a record says white, whitewash or red, that
       is a claim about this building's surface and it outranks anything a schedule
       dealt. It is also how the one attested paint in the dataset — the Sauganash's
       white — survives this parcel untouched in kind and improved in gloss.
    2. **Otherwise the record's own `finish_key` decides.** On a reconstructed
       anonymous roof the two attributes never disagree — every one of the 44 records
       carrying both states `whitewash` against `whitewash` and `red` against
       `red_oxide` — so this is not a tie-break between rival claims. It is a choice
       between a value the 665-roof programme dealt against a committed schedule and
       a `paint: unpainted` the archetype's own defaults wrote into the record with a
       note saying, in terms, that the family band does not speak to paint or finish
       and the value is the generator's type default. The dealt finish is the better
       evidence of the two, and it is the one 156 records were carrying into nothing.
    3. **Otherwise the archetypes' committed unpainted tone**, so nothing that has no
       record to read changes colour.
    """
    if paint and paint in _PAINT_FINISH:
        return FINISHES[_PAINT_FINISH[paint]]
    if finish_key and finish_key in FINISHES:
        return FINISHES[finish_key]
    return FINISHES[default]


#: The bare masonry fabrics — a wall whose colour is the material's own rather than
#: something it wears. Exactly one row is here, because exactly one bare wall fabric
#: in this town has a colour anybody argued: `BRICK`, off the Petford watercolour. A
#: FRAMED or CLAD wall is deliberately absent — it wears a finish, and `wall_finish`
#: is the question for that one.
_BARE_WALL_FINISH: dict[str, Finish] = {
    "brick": BRICK,
}


def wall_colour(construction: str | None = None) -> Finish | None:
    """What colour a BARE wall of this construction is — or `None` where the sheet
    states no colour for that fabric, which the caller must then answer itself.

    This is §8.3's move made for the wall: T-0267 put the fort's brick wall onto the
    sheet by NAMING the row, and the row was called `chimney_brick`, so a wall was
    painted out of a constant named for a different surface (T-0332). Asked the
    question rather than told the answer, a wall cannot go on pointing at a row that
    has since moved — and the row can be renamed, as it just has been, without
    hunting the archetypes for the name.

    `None` rather than a fallback is the deliberate half. The sheet does not know
    what colour a stone or an earth wall is — no source in this repository states
    either, and no record in the dataset builds one (measured for T-0332) — and a
    selector that quietly dealt the nearest row would be inventing a colour under a
    reader that looks like it is asking the sheet. Saying nothing is the honest
    answer, and it leaves the value where its one holder can argue it.
    """
    if construction and construction in _BARE_WALL_FINISH:
        return _BARE_WALL_FINISH[construction]
    return None


#: Every archetype in this dataset that builds a roof over a building. `palisade`,
#: `bridge_timber` and `pier_crib` are deliberately absent: none of them roofs
#: anything. (The palisade DID carry a material called `roof` until this parcel; it
#: draws two gate leaves and is now called `gate`, so that "a material called roof
#: states its covering" is true of the town rather than true with one exception.)
_ROOFED_BUILDING_ARCHETYPES = frozenset({
    "frame_dwelling", "frame_storefront", "frame_tavern",   # §2.2's framed buildings
    "log_dwelling", "fort_structure",                        # L266
})


#: The archetypes whose roof is a SHED'S roof and not a building's. Exactly one row,
#: and it is the one archetype that argues its own covering in its own source:
#: `outbuilding.py` says a shingle field on an outbuilding would be claiming a finish.
_BOARD_ROOF_ARCHETYPES = frozenset({"outbuilding"})


def roof_substrate(archetype: str | None = None) -> Substrate:
    """What a roof is COVERED WITH, given the kind of building under it.

    The rule is one sentence: **an outbuilding takes boards, every other roofed
    building takes a shingle field.** What follows is why, and which half of it is
    graded and which half is a liberty, because those are not the same and a reader
    should not have to work out which is which.

    **The board half is §2.2's and is not new.** `outbuilding.py` has argued since it
    was written that "a shingle field on an outbuilding would be claiming a finish",
    and `docs/RESEARCH/materials.md` §2.2 grades `roof_board` inferred and well
    argued on exactly that reasoning. A privy, a stable, a wagon shed and a smokehouse
    are built of what is to hand and roofed to keep the rain off a thing, not a
    family. 130 phases.

    **The shingle half is §2.2's for the framed buildings** — the North Side school of
    1833 is the one direct attestation in the repository, and §2.2 grades a shingled
    covering inferred as the ordinary covering of a framed building here. That reaches
    `frame_dwelling` (128), `frame_storefront` (42) and `frame_tavern` (12).

    **And it is L266 for the rest**, which is the part worth being explicit about. The
    rule above also gives a shingle field to the 49 `log_dwelling` cabins and the 14
    `fort_structure` garrison buildings, and §2.2 grades shingle for a FRAMED building
    — not for a log one. The claim being made is that the two coverings this project
    can argue split on what the roof is FOR and not on what the walls are made of: the
    board roof is argued as the shed's, and a log cabin is not a shed, it is a dwelling
    that has to carry a family through a Chicago winter and it meets the same demand
    the framed dwelling's roof meets. That is an argument, not a source, so it takes an
    L-number — L266 — and a reader who asks why a cabin is shingled finds it there.

    **What this is NOT.** It is not a statement about weathering: `roof_finish` owns
    that and the two are kept apart. It is not a colour: no substrate owns one (§1.1).
    And the material NAME an archetype builds from this row is not a contract —
    `docs/GLB-CONTRACT.md` says material names are not pinned and that a renderer keyed
    on one would be reading a convention nobody promised to keep. T-1488 has to settle
    how the substrate actually reaches the renderer.

    Anything unrecognised falls to `roof_plane`, which is the honest landing for a
    covering nothing can be said about. It carries no record today.
    """
    if archetype in _BOARD_ROOF_ARCHETYPES:
        return SUBSTRATES["roof_board"]
    if archetype in _ROOFED_BUILDING_ARCHETYPES:
        return SUBSTRATES["shingle"]
    return SUBSTRATES["roof_plane"]


def roof_material_name(substrate: Substrate) -> str:
    """The name an archetype gives the roof's material slot, given its covering.

    One function rather than a literal per archetype, because seven call sites naming
    the same thing by hand is how this project ended up with two hewn-log colours and
    two materials called `heavy_timber` (materials.md findings 2 and 3).

    It is a LABEL and not a contract. `docs/GLB-CONTRACT.md` says material names are
    not pinned by that document and that a renderer keyed on one would be reading a
    convention nobody promised to keep — which is still true, and is why T-1488 has to
    choose deliberately between proposing a pin and carrying the substrate in the
    material's `extras`. Until it does, this name is for a person reading a GLB.
    """
    return substrate.key if substrate.key.startswith("roof") else f"roof_{substrate.key}"


def roof_finish(roof_condition: str | None = None) -> Finish:
    """What a roof WEARS — a weathering condition, and never a covering.

    The covering is `roof_substrate()`'s, and the two are separate questions asked of
    separate evidence: 218 records state a condition, and what they are made of is a
    rule dealt by archetype. This function's docstring used to cite R-W2a finding 2 as
    an open question; the module docstring records what that finding actually graded
    and L263 records the liberty that closed it.
    """
    if roof_condition and roof_condition in ROOF_CONDITIONS:
        return ROOF_CONDITIONS[roof_condition]
    return ROOF_DEFAULT


def chimney_finish(stack: str) -> Finish:
    """What a stack is built of, given WHERE IT STANDS — `interior` or `exterior_gable`.

    The selector is the disposition and not the record, because no record in this
    dataset states a chimney fabric except the Sauganash's (`chimney_material`,
    T-0092, which `frame_tavern` still reads and folds into its confidence). What the
    two rows above argue is a rule about the two kinds of stack this town has, and
    each archetype already knows which kind it builds — `frame_dwelling` says its
    stack rises inside the wall and breaks the roof at the ridge, `log_dwelling` says
    its stack is built against the gable so it can be pulled away when it fires. Those
    two sentences were already committed; this turns them into two materials.

    Anything else takes brick: an interior stack is the town's majority and the
    better-evidenced of the two. `docs/RESEARCH/chimneys.md` is the whole argument.
    """
    return CHIMNEY_STICK_CLAY if stack == "exterior_gable" else BRICK


def resolve(substrate: Substrate, finish: Finish) -> tuple[tuple, float]:
    """The (rgba, roughness) pair an exporter needs: the substrate's gloss unless the
    finish is a coating that states its own (§2.1 — whitewash 0.90, lead paint 0.60,
    iron oxide 0.85)."""
    roughness = finish.roughness if finish.roughness is not None else substrate.roughness
    return finish.rgba, roughness


def trim_rgba(finish: Finish) -> tuple[float, float, float, float]:
    """Sawn trim against a sided wall.

    §2.3: "trim is derived from the wall paint and needs no sheet of its own", and
    the two rules below are the ones `frame_dwelling` has always argued. Over a
    COATING the boards took the same paint, so the trim is the wall lifted just
    enough to read as a separate board at walking distance. Over BARE TIMBER the trim
    is fresher stock than the weathered siding, so it is paler and slightly greyer —
    and the lift is the per-channel ratio the archetype already shipped
    (0.52/0.44/0.34 wall against 0.60/0.53/0.43 trim), which reproduces that pair
    exactly and generalises it to whichever finish the record deals.
    """
    r, g, b, a = finish.rgba
    if finish.coating:
        return (min(1.0, r * 1.06), min(1.0, g * 1.06), min(1.0, b * 1.06), a)
    return (min(1.0, r * (0.60 / 0.52)), min(1.0, g * (0.53 / 0.44)),
            min(1.0, b * (0.43 / 0.34)), a)


# ---------------------------------------------------------------- the lay and the wear
#
# T-1962 (piece 1 of T-1818: T-0002's other half, under T-1210's fabric rule). A
# finish says what a wall WEARS; these two rows say how the boards were LAID and how
# long they have stood in the weather — both dealt by whose house it is, both
# `reconstructed`, and both read by nothing but the reconstructed roofs: a record with
# no `fabric_basis` is a researched building and keeps exactly the wall it had.
# materials.md §16, rules FIN-L / FIN-W, liberty L348.
#
# **FIN-L, the lay.** A mill sends clapboard at one stock (T-0112 deals it), but a man
# with a hammer lays it, and the exposure he leaves course by course is as true as his
# gauge. `lay_m` is the most one course's exposure may stand off the stock, either way.
# A merchant's joiner set out the wall with a story pole; a labourer's or a yard
# building's courses were laid by eye. Every bound sits well inside the 0.018 m lip
# (`CLAPBOARD_LIP_M`), so no course can climb over the one above it, and inside the
# 0.10-0.16 m band the archetypes already validate a stock against.
#
# **FIN-W, the wear.** `facades.js` silvers a wall by its age, and read that age off
# `documented_range.from` — which on every reconstructed roof is the PROGRAMME's date,
# 1835-01-01, so 262 roofs read half a year old whatever the fabric rule had said of
# them. The rule already deals each roof an `age_state` from its household's arrival
# year (T-1816); this row turns that state into years of exposure, and `rate` is how
# far the class kept its walls up — a coat renewed, a wash re-limed — which slows the
# silvering and never stops it.
LAY_BY_CLASS: dict[str, float] = {
    "merchant": 0.003,    # ~1/8 in: set out with a story pole
    "keeper": 0.004,
    "tradesman": 0.006,   # ~1/4 in: a carpenter's own house, laid by the gauge
    "labourer": 0.008,    # ~5/16 in: laid by eye
    "freight": 0.008,
    "works": 0.008,
    "yard": 0.008,
}

WEATHER_YEARS_BY_AGE: dict[str, float] = {
    "new": 0.5,              # raised in 1835: the spring and early summer before July
    "recent": 1.5,           # raised in 1834: one winter and a half
    "established": 2.5,      # the first boom's, 1832-33
    "older_frontier": 5.0,   # before 1832 — and well short of the fort's dated 19 years
}

MAINTENANCE_BY_CLASS: dict[str, float] = {
    "merchant": 0.5,      # the coat kept up: rule F-M's "money bought the coat"
    "keeper": 0.75,       # a public house's clean face, re-limed
    "tradesman": 1.0,
    "labourer": 1.0,
    "freight": 1.0,
    "works": 1.0,
    "yard": 1.0,
}


def fabric_class(reconstruction: dict | None) -> str | None:
    """The household class the fabric rule dealt this roof, or None for a record the
    rule never reached (every researched building)."""
    basis = (reconstruction or {}).get("fabric_basis") or {}
    cls = basis.get("class")
    return cls if cls in LAY_BY_CLASS else None


def board_lay(reconstruction: dict | None) -> float:
    """FIN-L: how far one course's exposure may stand off the stock, in metres. 0.0 —
    the archetype's even courses, unchanged — wherever the rule has no class."""
    cls = fabric_class(reconstruction)
    return LAY_BY_CLASS[cls] if cls else 0.0


def fabric_tone(reconstruction: dict | None) -> dict | None:
    """FIN-W and FIN-L for one roof, as the sidecar carries them to the renderer, or
    None where the rule has no class. `facades.js` reads `weather_years` in place of
    the programme date and multiplies its silvering by `weather_rate`; the lay is
    geometry and is here so the card and the audits can say what the bake built."""
    cls = fabric_class(reconstruction)
    age = (reconstruction or {}).get("age_state")
    if not cls or age not in WEATHER_YEARS_BY_AGE:
        return None
    return {
        "rule": "FIN-W/FIN-L",
        "class": cls,
        "age_state": age,
        "weather_years": WEATHER_YEARS_BY_AGE[age],
        "weather_rate": MAINTENANCE_BY_CLASS[cls],
        "lay_m": LAY_BY_CLASS[cls],
        "confidence": "reconstructed",
    }


def course_lines(z_lo: float, z_hi: float, exposure: float, lay: float = 0.0,
                 seed: str = "") -> list[float]:
    """The heights of a wall's lap lines, bottom up, from `z_lo` (exclusive) toward
    `z_hi` — the course count the archetypes have always laid, `int(span / exposure)`.

    With `lay` 0 this is exactly `z_lo + i * exposure`, so a wall the rule never
    reached is built to the bit as before. Otherwise each LINE stands off its even
    height by at most `lay / 2`, drawn by a hash of `seed` and the line's number, so a
    course's exposure stays within `exposure ± lay`, the error never accumulates up
    the wall (the top course still meets the plate where it did), and a line holds
    one height all round the house, as a course carried round a corner board does.
    Deterministic: the asset's input hash depends on it."""
    n = int((z_hi - z_lo) / exposure)
    out = []
    for i in range(1, n):
        z = z_lo + i * exposure
        if lay > 0.0:
            h = hashlib.sha256(f"{seed}|lap{i}".encode()).digest()
            u = int.from_bytes(h[:4], "big") / 2 ** 32
            z += (u * 2.0 - 1.0) * lay / 2.0
        out.append(z)
    return out
