from pathlib import Path
from types import ModuleType
from dataclasses import asdict,replace
import sys,ast,copy,math,json,hashlib,inspect
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;B=O/'before/chicago/4d';N=O/'candidate/chicago/4d'
sys.path.insert(0,str(B/'generators'));sys.modules['bpy']=ModuleType('bpy')
def load(name,path):
 m=ModuleType(name);m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_text(),str(path),'exec'),m.__dict__);return m
old=load('hogan_before_params',B/'generators/archetypes/log_dwelling_params.py');new=load('hogan_after_params',N/'generators/archetypes/log_dwelling_params.py')
sys.modules['archetypes.log_dwelling_params']=old;before=load('hogan_before_builder',B/'generators/archetypes/log_dwelling.py')
sys.modules['archetypes.log_dwelling_params']=new;after=load('hogan_after_builder',Path(sys.argv[1]) if len(sys.argv)>1 else N/'generators/archetypes/log_dwelling.py')
from common.mesh import MeshBuilder
class Raw(MeshBuilder):
 def to_object(self,mats=None):self.materials=mats;return self
for m in [before,after]:m.MeshBuilder=Raw;m.simple_material=lambda *a,**k:(a,k)
def raw(b):return (b.verts,b.faces,b.conf,b.mat_index,b.named,b.materials)
def digest(b):return hashlib.sha256(json.dumps(raw(b),sort_keys=True).encode()).hexdigest()
def norm(poly):
 n=[0.,0.,0.]
 for a,q in zip(poly,poly[1:]+poly[:1]):
  for k in range(3):
   i,j=(k+1)%3,(k+2)%3;n[k]+=(a[i]-q[i])*(a[j]+q[j])
 return n
old_sig=inspect.signature(old.LogDwellingParams);new_sig=inspect.signature(new.LogDwellingParams)
assert [v for k,v in new_sig.parameters.items() if k!='front_door_state']==list(old_sig.parameters.values())
assert new_sig.parameters['front_door_state'].kind==inspect.Parameter.KEYWORD_ONLY
rows=[]
for path in sorted((O/'frozen-structures').glob('*.json')):
 r=json.loads(path.read_text())
 if r.get('archetype')!='log_dwelling':continue
 for ph in r['phases']:
  a,b=old.from_phase(ph,r),new.from_phase(ph,r);data=asdict(b);assert data.pop('front_door_state')=='closed';assert data==asdict(a)
  x,y=before.build(a,'same'),after.build(b,'same');assert raw(x)==raw(y),(r['id'],ph['id'])
  rows.append({'id':r['id'],'phase':ph['id'],'raw_sha256':digest(y)})
assert len(rows)==81
r=json.loads((N/'data/structures/hogan_store.json').read_text());orig=json.loads((B/'data/structures/hogan_store.json').read_text());ph=r['phases'][0];p=new.from_phase(ph,r)
assert p.front_door_state=='recess' and p.end_openings==(('+x','hatch',.5,3.35),) and p.ridge_stack_head_m==.75
assert r['phases'][0]['footprint']==orig['phases'][0]['footprint']
for key in ['position','documented_range','existence','use','occupants']:
 assert ph.get(key)==orig['phases'][0].get(key)
for key in ['wall_height_m','roof_pitch_deg','front_set_out','window_w_m','window_h_m','door_w_m','door_h_m','chimney_ridge_at']:
 assert ph['form'][key]==orig['phases'][0]['form'][key],key
assert ph['form']['ridge_stack_w_m']['value']==orig['phases'][0]['form']['ridge_stack_w_m']['value']
assert 'front_door_state' in new.CONSUMED
obj=after.build(p,'hogan_store__log_1831');assert all(math.isfinite(v) for pt in obj.verts for v in pt)
assert all(sum(v*v for v in norm([obj.verts[i] for i in f]))>1e-16 for f in obj.faces)
# Actual cut wall: no log/chink polygon covers an interior sample of the doorway.
rect=next(q for q in new.core_front_rects(p) if q[0]=='door');_,u0,u1,z0,z1=rect;wall_y=new.core_extent(p)[3]
wall=Raw('wall');after.hewn_log_wall(wall,*new.core_extent(p),0.,p.wall_height_m,.5,after.M_LOG,after.M_CHINK,skip=('bottom','top'))
after._cut_front_door_recess(wall,p,wall_y)
def contains(poly,x,z):
 # ray crossing test on the x-z projection
 inside=False
 for a,b in zip(poly,poly[1:]+poly[:1]):
  if (a[2]>z)!=(b[2]>z) and x<(b[0]-a[0])*(z-a[2])/(b[2]-a[2])+a[0]:inside=not inside
 return inside
samples=[(u0+(u1-u0)*fx,z0+(z1-z0)*fz) for fx in [.1,.5,.9] for fz in [.1,.3,.5,.7,.9]]
for f in wall.faces:
 poly=[wall.verts[i] for i in f]
 if all(v[1]>=wall_y-1e-9 for v in poly):assert not any(contains(poly,x,z) for x,z in samples),'uncut wall/chink covers door'
# Recess kit has a real 0.30 m setback, outward back, and no generic door leaf.
kit=Raw('recess');after._opening(kit,'y',wall_y,u0,u1,z0,z1,1,1.,kind='door',door_state='recess')
back=[f for f,m in zip(kit.faces,kit.mat_index) if m==after.M_DARK];assert len(back)==1
pts=[kit.verts[i] for i in back[0]];assert all(abs(v[1]-(wall_y-.3))<1e-9 for v in pts) and norm(pts)[1]>0
assert any(abs(v[1]-(wall_y-.3))<1e-9 for v in kit.verts)
assert not any(m==kit.NAMED_BASE+kit.named['door'][0] and abs(max(kit.verts[i][1] for i in f)-min(kit.verts[i][1] for i in f))<1e-9 and abs(min(kit.verts[i][0] for i in f)-u0)<1e-9 and abs(max(kit.verts[i][0] for i in f)-u1)<1e-9 for f,m in zip(kit.faces,kit.mat_index))
hatch=Raw('hatch');after._end_openings(hatch,p,*new.core_extent(p),p.wall_height_m)
glass=hatch.NAMED_BASE+hatch.named['glass'][0];assert glass not in hatch.mat_index,'hatch still glazed'
assert all(c==1. for c in hatch.conf)
invalid=0
for q in [replace(p,front_door_state='open'),replace(p,front_set_out=None),replace(p,stories=2),replace(p,frame_addition=True),replace(p,end_openings=(('+x','hatch',.5,None),)),replace(p,end_openings=(('+x','hatch',.5,2.5),))]:
 try:q.validate()
 except new.ParamError:invalid+=1
 else:raise AssertionError('unsupported input accepted')
report={'status':'passed','default_future_family_phase_outputs_identical':len(rows),'constructor_positional_signature_preserved':True,'guard_rejections':invalid,'default_outputs':rows,'hogan':{'faces':len(obj.faces),'vertices':len(obj.verts),'fan_triangles':sum(len(f)-2 for f in obj.faces),'raw_sha256':digest(obj),'dark_blind_recess_depth_m':.3,'hatch_unglazed':True,'footprint_position_dates_unchanged':True},'limits':'Pure Python actual generator lists; no Blender/export/browser, supported bake, full gate, image match acceptance or interior simulation.'}
(O/'focused-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='default_outputs'},indent=2))
