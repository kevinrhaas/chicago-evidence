from pathlib import Path
import json,difflib,hashlib,ast,shutil
O=Path(__file__).resolve().parent;R=O/'candidate/chicago/4d';B=O/'before/chicago/4d';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=R/'data/structures/hogan_store.json';r=json.loads(p.read_text());f=r['phases'][0]['form']
f['end_openings']['note']="Cameron's visible gable has a small framed rectangle above the log wall. Its local +x assignment, 0.7 by 0.8 m size and 3.35 m centre are reconstructed within the existing roof, not a compass bearing or metric dimension from the painting. This trial uses a boarded hatch proxy at that same station rather than generic glazed sash. The painting does not resolve the infill well enough to attest glass or boards; board rhythm, ledges, closure and material remain reconstructed. No loft occupancy or hidden gable opening is inferred."
f['ridge_stack_w_m']['note']="Reconstructed 0.65 m square ridge-stack section, reduced from the generic 0.96 m after comparing the actual render to Cameron's narrower visible stack. This numerical section and unseen plan depth are not measured from the retrospective drawing. The head is separately trialled at ridge_stack_head_m; plain cap, masonry and cap details remain reconstructed and unmatched."
p.write_text(json.dumps(r,indent=2)+'\n')
p=O/'focused_check.py';s=p.read_text().replace(", 'ridge_stack_w_m']", "]") if False else p.read_text();s=s.replace(",'ridge_stack_w_m']", "]")
s=s.replace("assert 'front_door_state' in new.CONSUMED", "assert ph['form']['ridge_stack_w_m']['value']==orig['phases'][0]['form']['ridge_stack_w_m']['value']\nassert 'front_door_state' in new.CONSUMED")
p.write_text(s)
for mod in [R/'generators/archetypes/log_dwelling.py',R/'generators/archetypes/log_dwelling_params.py']:
 ast.parse(mod.read_text())
for src in R.rglob('*'):
 if src.is_file():
  dest=O/'preview/proposed'/src.relative_to(R)
  if dest.exists():shutil.copy2(src,dest)
patch=[]
for p in sorted(R.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(R);old=B/rel
 if old.read_bytes()!=p.read_bytes():patch.extend(difflib.unified_diff(old.read_text().splitlines(True),p.read_text().splitlines(True),fromfile='a/chicago/4d/'+str(rel),tofile='b/chicago/4d/'+str(rel)))
(O/'hogan-on-log-family.patch').write_text(''.join(patch))
meta={}
for kind in ['committed-before','proposed']:
 D=O/'preview'/kind;meta[kind]={str(p.relative_to(D)):sha(p) for p in sorted(D.rglob('*')) if p.is_file() and not p.is_symlink() and 'node_modules' not in p.parts}
(O/'preview/fixture-inputs.json').write_text(json.dumps(meta,indent=2)+'\n')
