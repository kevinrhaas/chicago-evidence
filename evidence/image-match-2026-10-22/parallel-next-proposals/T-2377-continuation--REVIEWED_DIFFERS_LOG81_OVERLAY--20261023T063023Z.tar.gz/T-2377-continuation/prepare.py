from pathlib import Path
import shutil,json,hashlib,subprocess
O=Path(__file__).resolve().parent; R=Path('/workspace/chicago/chicago/4d'); F=Path('/tmp/chicago-next-model/log-combined/boarding-refinement/candidate/chicago/4d')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for d in ['before','candidate']:
 b=O/d/'chicago/4d'
 shutil.copytree(R/'generators/common',b/'generators/common',ignore=shutil.ignore_patterns('__pycache__'),dirs_exist_ok=True)
 for name in ['log_dwelling.py','log_dwelling_params.py']:
  p=Path('generators/archetypes')/name;(b/p).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(F/p,b/p)
 for p in ['data/structures/hogan_store.json','data/sources/cameron_c1900_first_post_office.json','docs/RESEARCH/hogan-picture-match-T-2377/cameron-1833.json']:
  dest=b/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/p,dest)
# Freeze all 81 legacy phase inputs, immutable future family input records, and actual committed master.
shutil.copytree(R/'data/structures',O/'frozen-structures',dirs_exist_ok=True)
for p in F.glob('data/structures/*.json'):shutil.copy2(p,O/'frozen-structures'/p.name)
for name,p in {'source.jpg':R.parent/'reference/images/chicago/chicago_first_post_office_1833.jpg','committed-before.glb':R/'assets/gltf/hogan_store__log_1831.glb','prior-paired-detail.png':Path('/tmp/t2377-model/refined-detail.png'),'freshness-scope-before.json':Path('/tmp/chicago-next-model/log-combined/freshness-scope.json')}.items():shutil.copy2(p,O/name)
receipt={'head':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),'overlay_base':str(F),'captured_inputs':{str(p.relative_to(O)):sha(p) for p in sorted(O.rglob('*')) if p.is_file() and p.name!='prepare.py'},'limitations':'Frozen future log-family candidate plus current Hogan. Repository remains read-only; no heavy execution or official freshness acceptance.'}
(O/'input-snapshot.json').write_text(json.dumps(receipt,indent=2)+'\n')
