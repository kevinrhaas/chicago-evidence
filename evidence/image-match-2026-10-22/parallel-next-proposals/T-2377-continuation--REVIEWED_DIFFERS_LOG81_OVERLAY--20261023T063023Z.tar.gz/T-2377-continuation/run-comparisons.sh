#!/usr/bin/env bash
set -euo pipefail
parcel="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for fixture_kind in committed-before proposed; do
 cd "$parcel/preview/$fixture_kind"
 PW_EXECUTABLE=/usr/bin/chromium node tools/photo_match.mjs cameron-1833.json --out "$parcel/preview/reviews/$fixture_kind" > "$parcel/preview/$fixture_kind-photo-match.log" 2>&1
done
