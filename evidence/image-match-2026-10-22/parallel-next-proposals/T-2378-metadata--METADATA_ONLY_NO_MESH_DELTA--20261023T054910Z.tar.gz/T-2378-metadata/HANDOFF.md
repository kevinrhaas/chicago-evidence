# T-2378: bounded card-visible identity/date correction

This is an unapplied metadata/source/research increment agreed with the parent
because a form correction is not yet tied to a securely identified building.
No checkout, ticket, asset, camera or grade-ruling files were edited by this agent.

## Changes

- `data/structures/jb_beaubien_homestead.json`: only three prose fields change.
  `construction.note` removes the false pre1817 rationale; `change_note` directly
  states the construction-date/identity limits in visitor-readable language;
  `research_note` adds the exact image-identification caveat and explicitly labels
  the older superseded argument as historical research. All form values,
  confidences, phase dates, footprint and position remain byte-for-byte equivalent
  as resolved inputs.
- New `data/sources/kinzie_1857_chicago_1831_panorama.json`: the existing local
  illustration and printed credit/key, explicitly unresolved as a picture of this
  modern structure record. Date/rights metadata are bounded to the existing
  inventory and printed caption, not a fresh remote catalogue claim.
- `docs/RESEARCH/jb_beaubien_homestead.md`: removes its misleading oldest-building
  opening and appends the source excerpt, identity limit and next comparison plan.

The existing picture compiler adds a credited contextual holder link because the
research note names the new source. The visible title itself says the identification
is unresolved. No camera or pictured ruling is added; the real structure-grade
function keeps the house **inferred**, with no depicting-picture ids. A contextual
source link is not a claim that the house's appearance has been matched.

## Artifacts

- `T-2378.patch`: standard three-file unified diff, apply from `/workspace/chicago`.
- `proposed/`: full proposed files, not a checkout to copy over newer parent work.
- `SOURCE-EXCERPT.md`: exact existing EPUB member, excerpt and picture credits.
- `CANDIDATE-PLAN.md`: bounded future identity/camera work, without a heavy prototype.
- `check_proposal.py`, `validation.txt`: focused read-only checks.
- `prepare_proposal.py`: construction record for this /tmp proposal.

`git apply --check /tmp/chicago-next-model/T-2378/T-2378.patch` passes against the
current checkout. Run applicability again after parent changes.

## Validation and blast radius

The real source/structure schemas pass. A field comparison proves only the three
intended prose fields changed in the house record. The actual mesh-input hash is
unchanged at
`902255ea4868b7bf1038e4acaa6a59897b05676c66e25e365be3cd681d99bd6f`, matching the
current master manifest: **no master or family rebake is caused by this package**.
No geometry parameters or confidence floats change.

The actual picture compiler derives one context link and the actual grade rule
returns the same inferred result before/after. The phase account and construction
note pass the renderer's real visitor-text filter; the caveat is not dropped as
internal plumbing. This is consumer-function validation, not an app screenshot.

No new geometric liberty is introduced. Existing dimensional/form reconstruction
and its ledger entries remain; a new liberty entry is unnecessary for correcting
an unsupported prose claim while leaving every form/grade unchanged.

## Integration remaining

Integrate source, record and dossier together; regenerate scene sidecars and the
published picture/context files. Inspect the card's clean phase account,
construction note and credited unresolved panorama link at desktop and390x780,
with no page errors. Confirm the derived grade remains inferred and that no camera
or pictured ruling was silently added. Run the required gate/preflight before any
commit/PR/merge. Parent owns ticket state and publication actions.

T-2378's geometry/image acceptance is still unresolved. Do not label the source
as an identified appearance view, add an upper storey from the Factory House,
change the model from guessed tiny details, mark matches or close the ticket on
this documentation increment.
