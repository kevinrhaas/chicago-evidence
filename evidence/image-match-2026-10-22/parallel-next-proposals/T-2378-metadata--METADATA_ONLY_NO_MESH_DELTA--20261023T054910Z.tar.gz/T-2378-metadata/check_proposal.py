"""Read-only metadata/mesh/grade/card-source checks. No rendering or builds."""
import copy,dataclasses,importlib.util,json,sys
from pathlib import Path
import jsonschema
ROOT=Path('/workspace/chicago/chicago/4d');PROP=Path('/tmp/chicago-next-model/T-2378/proposed/chicago/4d')
sys.path[:0]=[str(ROOT/'tools'),str(ROOT/'generators')]
import mesh_inputs,compile_pictures as cp,grade_structures as gs
sid='jb_beaubien_homestead';source_id='kinzie_1857_chicago_1831_panorama'
a=json.loads((ROOT/'data/structures'/f'{sid}.json').read_text());b=json.loads((PROP/'data/structures'/f'{sid}.json').read_text());source=json.loads((PROP/'data/sources'/f'{source_id}.json').read_text())
jsonschema.validate(b,json.loads((ROOT/'data/structures.schema.json').read_text()));jsonschema.validate(source,json.loads((ROOT/'data/source.schema.json').read_text()))
x=copy.deepcopy(a);y=copy.deepcopy(b)
for r in [x,y]:r.pop('research_note');r['phases'][0].pop('change_note');r['phases'][0]['form']['construction'].pop('note')
assert x==y,'Change outside the three intended prose fields'
old_hash=mesh_inputs.structure_inputs_sha(a,a['phases'][0]);new_hash=mesh_inputs.structure_inputs_sha(b,b['phases'][0]);assert old_hash==new_hash
print('PASS: source/structure schemas; exactly construction.note, change_note and research_note change; every form value, confidence, footprint, position and mesh input hash is preserved.')
print('UNCHANGED_MESH_INPUT_SHA256',new_hash)
sources={p.stem:json.loads(p.read_text()) for p in (ROOT/'data/sources').glob('*.json')}
assert source_id not in sources,'Source already exists in current checkout; review package against latest tree'
oldpics=cp.derive(None,'',sources,{sid:json.dumps(a)}, {'1835':[sid]}, {})['1835']['by_structure'].get(sid,[])
sources[source_id]=source
newpics=cp.derive(None,'',sources,{sid:json.dumps(b)}, {'1835':[sid]}, {})['1835']['by_structure'].get(sid,[])
context=[p for p in newpics if p['id']==source_id];assert len(context)==1
assert not context[0].get('library') and context[0].get('view') is None
assert 'Unresolved Beaubien-group identification' in context[0]['title']
print('PASS: actual picture compiler adds one credited contextual link whose visible title says the identification is unresolved.')
camdir=ROOT/'data/reference_views'/sid
cams=[json.loads(p.read_text()) for p in camdir.glob('*.json') if not p.name.endswith('.match.json')]
rulings=json.loads((ROOT/'data/structure_grades.json').read_text())
exist=a['phases'][0]['documented_range']['confidence']
g0=gs.grade_structure(sid,exist,oldpics,cams,rulings,'1835');g1=gs.grade_structure(sid,exist,newpics,cams,rulings,'1835');assert g0==g1
assert source_id not in g1['pictures']
print('PASS: actual derived structure-grade function remains unchanged:',json.dumps(g1))
print('NO CLAIM: camera/identity match, rendered appearance, app screenshot, full gate, ticket closure, PR or merge is not established.')
