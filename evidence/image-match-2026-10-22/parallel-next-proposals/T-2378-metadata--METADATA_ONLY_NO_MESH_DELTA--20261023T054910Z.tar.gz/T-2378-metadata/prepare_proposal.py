from pathlib import Path
import json,difflib
root=Path('/workspace/chicago');out=Path('/tmp/chicago-next-model/T-2378')
sid='kinzie_1857_chicago_1831_panorama'
source={
'id':sid,'type':'illustration',
'citation':'[Unresolved Beaubien-group identification] "Fort Dearborn and Chicago in 1831." Labeled wood-engraved panorama after a sketch attributed to Juliette A. Kinzie; the local reproduction credits Wau-Bun, Chicago, 1857.',
'author':'Engraver not established; after a sketch attributed to Juliette A. Kinzie',
'date':'1857 as credited by the local caption; the date of this labeled reproduction is not established',
'describes_date':'1831',
'repository':'Wikimedia Commons; local reproduction in chicago/reference/images/chicago/',
'url':'https://commons.wikimedia.org/wiki/File:Fort_Dearborn_%26_Chicago_in_1831.jpg',
'locator':'The committed 1920 by 1042 pixel reproduction chicago/reference/images/chicago/chicago_fort_dearborn_1831_1.jpg, with the printed upper credit and lower keys including Dean House, Gen. J. B. Beaubien\u2019s, Fort, Wash-house, Agency-House and John-Kinzie House.',
'rights_status':'public_domain','rights_note':'The committed inventory chicago/reference/images/IMAGE_SOURCES.md identifies the image as public domain by pre-1930 publication. The underlying Wau-Bun illustration is nineteenth-century. The separately advertised Getty/Alamy reproductions are not acquired or licensed by this record.',
'asset_use':'cross_check','tier':5,'verified':True,
'access_notes':'The existing local image and its printed caption/key were opened and read; the inventory entry was checked. No fresh remote Commons or museum catalogue retrieval was performed for this record, and the precise original edition and later reproduction date remain unestablished.',
'note':'The key identifies a Beaubien group in a scene captioned 1831. It does not by itself identify that pictured building with the current sale-located homestead record. That residence, the older U.S. Factor\u2019s House and the Dean house must remain separate candidates. Wau-Bun\u2019s text places Jean Baptiste Beaubien\u2019s residence between the gardens and river-bank, with Dean\u2019s tenement farther south, but supplies no dimensions or fabric for the house. This small panorama is held as an explicitly unresolved contextual picture, not an accepted appearance reference or a solved camera. Its relationship to the other 1831 Wau-Bun-derived lithograph has not been proven independent, so it must not be counted as a second eyewitness.',
'what_it_supplies':['a panorama labeled Chicago in 1831, with a keyed Gen. J. B. Beaubien\u2019s group','the drawn order of the separately keyed Dean, Beaubien, fort and north-bank groups','an existing credited contextual image to investigate before assigning facade details'],
'what_it_does_not_supply':['which of the currently modeled Beaubien buildings the keyed group depicts','a surveyed coordinate, a metric dimension or a camera calibration','independent proof of the pictured buildings\u2019 material, storey count, openings or chimney count on 1 July 1835','proof that two reproductions of the Wau-Bun composition are independent witnesses']}
source_path=f'chicago/4d/data/sources/{sid}.json'
paths=['chicago/4d/data/structures/jb_beaubien_homestead.json','chicago/4d/docs/RESEARCH/jb_beaubien_homestead.md']
old={p:(root/p).read_text() for p in paths};new=dict(old)
p=paths[0];r=json.loads(new[p]);ph=r['phases'][0]
ph['form']['construction']['note']='Log is retained as the existing inferred reading from the settlement\u2019s building practice, not as a directly attested material for this particular residence. A construction date before 1817 is not established here: Beaubien\u2019s 1817 purchase concerned the separate Dean house, and 1822 is this record\u2019s earliest allowed date rather than a known building year. The residence represented here may be the later house associated with the 1839 sale. The keyed 1831 panorama does not settle that identity and supplies no new material attestation for this record. The log form and its grade are unchanged.'
ph['change_note']='Modelled as one Beaubien residence with a barn and trading post. Its construction date and exact appearance remain unknown: 1822 is a lower bound, not a building date. The U.S. Factor\u2019s House is separately modelled about 140 m south and is not identified as this dwelling. The panorama captioned 1831 names a Beaubien group without settling which house it shows; its pictured details have not been transferred here. Beaubien\u2019s reservation claim was dated 28 May 1835, about five weeks before the scene, and recorded 26 June.'
lead=f'''CURRENT IDENTITY AND IMAGE LIMIT — T-2378. The existing record represents one Beaubien dwelling with a barn and trading post under the owner\u2019s T-1743 reading. Its precise building identity and construction year remain unresolved. The 1817 purchase belongs to the Dean house; 1822 is an earliest allowed date, not a date this residence is known to have been built. The contextual panorama ({sid}; chicago/reference/images/chicago/chicago_fort_dearborn_1831_1.jpg) keys \u201cGen. J. B. Beaubien\u2019s\u201d, but it has not been shown to depict this sale-located residence rather than the separately modeled Factory House or another element of the group. No storey count, material, opening or chimney detail is transferred from that unresolved identification, and no camera or pictured-grade ruling is added. The context link carries its own uncertainty in the source citation.\n\nHISTORICAL RESEARCH RECORD — the earlier argument below retains superseded readings where its own later corrections identify them; the current note above and the record\u2019s phase are the present claim.\n\n'''
old_start='THE OLDEST BUILDING IN THIS DATASET AND THE LEAST PRECISELY PLACED.'
assert r['research_note'].startswith(old_start)
r['research_note']=lead+r['research_note'].replace(old_start,'AN EARLY RESIDENCE WHOSE EXACT IDENTITY AND CONSTRUCTION DATE REMAIN UNRESOLVED.',1)
new[p]=json.dumps(r,ensure_ascii=False,indent=2)+'\n'
p=paths[1];s=new[p]
s=s.replace('The **oldest building in this dataset** and the **least precisely placed**.','An early residence whose exact building identity, construction date and appearance remain unresolved.',1)
s+='''

## 8. The keyed 1831 panorama is contextual, not an identified appearance reference — T-2378

**The bounded correction.** The current house record no longer describes itself as
known to have been built before 1817 or as the dataset\u2019s oldest building. Its log
material, one-storey form, dimensions, placement and per-attribute grades are
unchanged. The 1817 purchase belongs to the separate Dean house; 1822 is an earliest
allowed bound on this record, not a demonstrated construction year. The card\u2019s
phase account now states those limits directly. Earlier readings remain above as
research history, not a reason to restore the withdrawn identity.

**The actual picture inspected.** `kinzie_1857_chicago_1831_panorama` records the
existing 1920 by 1042 pixel local reproduction
`chicago/reference/images/chicago/chicago_fort_dearborn_1831_1.jpg`. The upper credit
names Wau-Bun, Mrs. Juliette A. Kinzie, Chicago, 1857; the lower key names Dean House,
Gen. J. B. Beaubien\u2019s, Fort, Wash-house, Agency-House and John-Kinzie House. Its
source citation explicitly says the modern Beaubien-group identification is
unresolved, so the Images context link cannot reasonably be read as an accepted
picture match. The date of this labeled reproduction is not established, and the
inventory\u2019s public-domain attribution is not a fresh remote catalogue check.

**The text was also read, with its limit.** The committed Wau-Bun EPUB\u2019s chapter
\u201cChicago in 1831\u201d, under source `kinzie_waubun_1856`, reads:

> The residence of Jean Baptiste Beaubien stood at this period between the gardens
> and the river-bank, and still farther south was a rickety tenement, built many
> years before by Mr. John Dean, the sutler of the post.

This is a text excerpt read from
`chicago/reference/Wau-bun/wau-bun-pg12183-images-3.epub`, not a reread of a dated
manuscript or a new exact page citation. It supports the relative order of the
named groups, not a material, dimension, storey count, opening or stack pattern.
It does not close the distinction \u00a7 6a measures between the sale-located house and
the Factory House approximately 140 m south. The owner\u2019s T-1743 reading of one
dwelling and two outbuildings stays in force.

**What is not done.** No roof, upper storey, white paint, sash, attic light or stack
is invented as a pictorial attestation. No building is moved to fit the panorama;
it is tier-5 form/context material, not a survey control. No camera is installed
and no `pictured` ruling promotes the house\u2019s grade. A cited contextual source
illustration by itself does not establish that the record\u2019s building is depicted.
The 1831 Wau-Bun-derived views are not treated as independent eyewitnesses.

**Next comparison.** Keep candidate identities separate, locate a better original
or reproduction if available, and solve the same panorama against the fort\u2019s
independent surveyed/plan controls and the two separately modeled Beaubien
candidates. A camera fit alone cannot override a failed building identification.
Only after that ruling should a form difference be assigned to this house. T-2378
remains open, and no `matches` verdict is established by this metadata correction.
'''
new[p]=s
patch=[f'diff --git a/{source_path} b/{source_path}\nnew file mode 100644\n']
source_text=json.dumps(source,ensure_ascii=False,indent=2)+'\n'
patch.extend(difflib.unified_diff([],source_text.splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+source_path))
for p in paths:
 dest=out/'proposed'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(new[p]);patch.append(f'diff --git a/{p} b/{p}\n');patch.extend(difflib.unified_diff(old[p].splitlines(keepends=True),new[p].splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p))
dest=out/'proposed'/source_path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(source_text)
(out/'T-2378.patch').write_text(''.join(patch))
print('Saved three-file metadata/source/research proposal under',out)
