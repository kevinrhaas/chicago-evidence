# T-2380-next: concrete core-only silhouette correction

**HOLD — RIGHTS UNRESOLVED; DO NOT APPLY OR BAKE.** The geometric proposal is preserved for review, but the new source is now `check_required`. Repository unchanged. No Blender/browser/heavy CPU used. Current patch/before/after files supersede the unverified public-domain version archived in `pre-rights-review/`. Do not apply the liberty or derive assets until the source status is resolved.

## Visible correction using existing params

Current log_jail is a2.66 m low wall with a12degree near-flat cap, taken from a written owner-brief summary rather than either ticket-listed image. The actual detailed1836 engraving shows a substantial rear log jail with a clearly pitched gable above the stockade and low adjoining house. The proposed existing wall_height_m=4.2 and roof_pitch_deg=32 change the core silhouette: ridge3.1459 →5.6285 m. roof_type remains gable with a new evidence/conflict note. Both numeric choices are RECONSTRUCTED and require actual paired review. They are not historic measurements from a solved source camera.

Only the core GLB changes. Footprint6.096 ×4.572 m, place, bearing, date range, function, occupants, door and default vent are retained. No stockade, keeper's house, new courtyard, barred aperture or whole-compound date assertion is added. outbuilding generator/params/defaults are unchanged, so this is ONE existing master/web derivative to rebuild rather than a243master shared-generator edit.

## Exact source and scene-date boundaries

The source record cook_county_first_jail_1836_engraving preserves the unidentified engraver, current host's1836 caption and Chicago Tribune10June1947 reproduction credit. Actual local image and actual current host page were read. The host image basename says1837; the caption supplies1836. The committed IMAGE_SOURCES inventory's pre-1930/public-domain assertion has no identified original publication. Independent research found the same picture in the actual UCR/Calisphere Keystone-Mast catalogue, item1996.0009.L54254, dated19September1930 in a combined 'Date Created and/or Issued' field. This proves a copy existed before1947 but does not prove original1930publication. The institutional rights statement gives no affirmative reuse licence. The source is therefore `check_required`; no geometry derived from it may be baked. See ../T-2380-rights/RIGHTS-FINDINGS.md for captures and research bounds. No commercial scan or new binary was substituted.

Chronology is in /tmp/chicago-next-model/T-2380/chronology-findings.md with actual fetched public pages, extracted text and hashes. An1836 caption does not prove replacement or a later phase. Conversely it does not date every pictured component before July1835. The numeric core change uses a declared pre-July continuity reconstruction, not an attested completion claim. The stockade/keeper-house chronology stays unresolved. Andreas's1884 courthouse plate depicts a contrasting shallow hipped/pyramidal jail cap; the more detailed1836-labelled engraving governs this first pitched-core increment, and the mismatch remains open. No forced backdating or hidden claim that both roofs match.

## Existing-parameter limit and next feature

The detailed engraving actually shows an upright rectangular, barred-looking opening in the jail's visible log gable. Existing outbuilding params offer a generic small vent and a hay-loft door, not a cased barred gable window. Do not switch loft on and call the hay door a jail opening. A future opt-in barred light could be justified by that actual drawn detail, with its end/width/height/station reconstructed; a builder/params change would affect freshness inputs for all243 registered outbuilding masters. This first silhouette change avoids that family blast while materially changing the visible core. Chimney(s), roof cap disagreement, log/roof texture, image camera and compound components still need work.

## Light verification and outstanding work

verify.py/log pass structure/source schema, consumed existing params, bounds, isolated form delta, unchanged footprint/date/place/use, retained door/default vent and no new compound pieces. git apply --check passes. No new generator source or shared defaults changed. The light check verifies the explicit rights hold as well as the geometric proposal. Compilation, derivation, publication and appending the liberty are deferred until rights clearance; source inspection is not rights clearance.

After rights resolution, parent would preserve the old master, rebuild only log_jail, regenerate its derivative and sidecar, make a same-camera before/after pair, inspect the actual silhouettes and remaining differences, then run required in-app/gate validation. No mesh export, actual image comparison, matches verdict or closure is claimed here; T-2380 remains open.
