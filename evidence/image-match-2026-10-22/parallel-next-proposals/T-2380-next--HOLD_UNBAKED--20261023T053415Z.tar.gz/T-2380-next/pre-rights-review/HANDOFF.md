# T-2380-next: concrete core-only silhouette correction

This is a proposal ready for parent integration/rebuild, not a source-only stop. Repository unchanged. No Blender/browser/heavy CPU used. T-2380-next.patch and complete before/after files live here; append proposed-liberty.md when applying.

## Visible correction using existing params

Current log_jail is a2.66 m low wall with a12degree near-flat cap, taken from a written owner-brief summary rather than either ticket-listed image. The actual detailed1836 engraving shows a substantial rear log jail with a clearly pitched gable above the stockade and low adjoining house. The proposed existing wall_height_m=4.2 and roof_pitch_deg=32 change the core silhouette: ridge3.1459 →5.6285 m. roof_type remains gable with a new evidence/conflict note. Both numeric choices are RECONSTRUCTED and require actual paired review. They are not historic measurements from a solved source camera.

Only the core GLB changes. Footprint6.096 ×4.572 m, place, bearing, date range, function, occupants, door and default vent are retained. No stockade, keeper's house, new courtyard, barred aperture or whole-compound date assertion is added. outbuilding generator/params/defaults are unchanged, so this is ONE existing master/web derivative to rebuild rather than a243master shared-generator edit.

## Exact source and scene-date boundaries

The source record cook_county_first_jail_1836_engraving preserves the unidentified engraver, current host's1836 caption and Chicago Tribune10June1947 reproduction credit. Actual local image and actual current host page were read. The host image basename says1837; the caption supplies1836. Original19th-century engraving/public-domain classification comes from the already committed IMAGE_SOURCES inventory, not a newly found original catalogue. rights_note/access_notes say this plainly. No commercial scan or new binary was substituted.

Chronology is in /tmp/chicago-next-model/T-2380/chronology-findings.md with actual fetched public pages, extracted text and hashes. An1836 caption does not prove replacement or a later phase. Conversely it does not date every pictured component before July1835. The numeric core change uses a declared pre-July continuity reconstruction, not an attested completion claim. The stockade/keeper-house chronology stays unresolved. Andreas's1884 courthouse plate depicts a contrasting shallow hipped/pyramidal jail cap; the more detailed1836-labelled engraving governs this first pitched-core increment, and the mismatch remains open. No forced backdating or hidden claim that both roofs match.

## Existing-parameter limit and next feature

The detailed engraving actually shows an upright rectangular, barred-looking opening in the jail's visible log gable. Existing outbuilding params offer a generic small vent and a hay-loft door, not a cased barred gable window. Do not switch loft on and call the hay door a jail opening. A future opt-in barred light could be justified by that actual drawn detail, with its end/width/height/station reconstructed; a builder/params change would affect freshness inputs for all243 registered outbuilding masters. This first silhouette change avoids that family blast while materially changing the visible core. Chimney(s), roof cap disagreement, log/roof texture, image camera and compound components still need work.

## Light verification and outstanding work

verify.py/log pass structure/source schema, consumed existing params, bounds, isolated form delta, unchanged footprint/date/place/use, retained door/default vent and no new compound pieces. git apply --check passes. No new generator source or shared defaults changed. Append liberty, compile/rederive/publish using the normal scripts; review the derived structure grade using the reasonable-picture rule rather than force an attested flag for partly obscured details.

Parent must preserve old master, rebuild only log_jail, regenerate its derivative and sidecar, make a same-camera before/after pair, inspect the actual silhouettes and all remaining differences, then run the required in-app/gate validation. No mesh export, actual image comparison, matches verdict or closure is claimed here; T-2380 remains open.
