import copy,dataclasses,json,pathlib,sys
B=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/workspace/chicago/chicago/4d');sys.path.insert(0,str(R/'generators'))
from archetypes.outbuilding_params import from_phase,CONSUMED,vent_rect,loft_rect
rel='chicago/4d/data/structures/log_jail.json';a=json.loads((B/'before'/rel).read_text());b=json.loads((B/'after'/rel).read_text())
assert {'roof_type','roof_pitch_deg','wall_height_m'}<=CONSUMED
x=copy.deepcopy(b)
for k in ['roof_type','roof_pitch_deg','wall_height_m']:x['phases'][0]['form'][k]=a['phases'][0]['form'][k]
x['research_note']=a['research_note'];assert x==a
p=from_phase(a['phases'][0],a);q=from_phase(b['phases'][0],b);p.validate();q.validate()
assert p.width_m==q.width_m==6.096 and p.depth_m==q.depth_m==4.572
assert q.wall_height_m==4.2 and q.roof_pitch_deg==32 and q.roof_type=='gable'
assert q.apex_z_m>p.apex_z_m+2
assert p.door_spans_m==q.door_spans_m and p.door_size_m==q.door_size_m
assert vent_rect(p)==vent_rect(q) # default ventilation remains the existing proxy
assert not p.loft and not q.loft and p.chimneys==q.chimneys==0
assert 'phases' in b and len(b['phases'])==len(a['phases'])==1
import jsonschema
jsonschema.validate(b,json.loads((R/'data/structures.schema.json').read_text()))
srel='chicago/4d/data/sources/cook_county_first_jail_1836_engraving.json';source=json.loads((B/'after'/srel).read_text());jsonschema.validate(source,json.loads((R/'data/source.schema.json').read_text()));assert source['rights_status']=='check_required';assert all(t in source['rights_note'] for t in ['inventory', 'UNRESOLVED', '1930', 'do not derive/bake'])
print('HOLD: source check_required; proposed geometry remains unbaked')
print('PASS: source/structure schema, isolated core-form delta, existing consumed params, wall/roof bounds, retained footprint/date/place/use, retained door and default vent, no compound additions')
print('Before eave/ridge:',p.wall_height_m,p.apex_z_m,'m')
print('After eave/ridge:',q.wall_height_m,q.apex_z_m,'m')
print('UNRUN: paired render, actual GLB rebuild, July1835 alteration-sequence proof, gate and matches verdict')
