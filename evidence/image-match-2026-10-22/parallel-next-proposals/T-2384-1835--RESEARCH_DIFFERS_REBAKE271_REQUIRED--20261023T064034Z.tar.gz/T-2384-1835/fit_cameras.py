"""Separate numerical camera seeds for two retrospective St Mary's pictures."""
from pathlib import Path
import math,json
import numpy as np
from scipy.optimize import least_squares
from PIL import Image
HERE=Path(__file__).resolve().parent;ROOT=Path('/workspace/chicago/chicago/4d')
r=json.loads((HERE/'candidate/chicago/4d/data/structures/st_marys_church.json').read_text());phase=r['phases'][0]
long=phase['footprint']['polygon'][1][0];short=phase['footprint']['polygon'][2][1];h=phase['form']['wall_height_m']['value'];pitch=phase['form']['roof_pitch_deg']['value'];ridge=h+short/2*math.tan(math.radians(pitch))
# Work in short-span/long-run coordinates, then transform the solved camera into
# the canonical record's unchanged east/north axes. No building position rotates.
world=np.array([[0,0,0],[short,0,0],[0,long,0],[0,0,h],[short,0,h],[0,long,h],[short/2,0,ridge]])
labels=['near_northwest_sill','near_southwest_sill','far_northeast_sill','near_northwest_eave','near_southwest_eave','far_northeast_eave','west_gable_apex']
views=[('moss',Path('/workspace/chicago/chicago/reference/images/chicago/chicago_st_marys_church_1843.jpg'),[1456,1696],[[578,1273],[1302,1240],[94,1188],[578,835],[1302,883],[94,945],[970,617]],'andreas_1884_st_marys_engraving'),('gale',HERE/'candidate/chicago/4d/data/sources/assets/gale_1902_st_marys_original_site.jpg',[1247,2048],[[622,1248],[1024,1215],[122,1198],[622,976],[1024,986],[122,997],[839,850]],'gale_1902_st_marys_original_site')]
def projection(q,xyz):
 ex,ey,ez,yaw,f,cx,cy=q;t=math.radians(yaw);delta=xyz-[ex,ey,ez];z=delta[:,0]*math.sin(t)+delta[:,1]*math.cos(t);x=delta[:,0]*math.cos(t)-delta[:,1]*math.sin(t);return np.stack([cx+f*x/z,cy-f*delta[:,2]/z],1)
report=[]
for name,photo,display,pts,source in views:
 size=list(Image.open(photo).size);image=np.array(pts,float)*np.array(size)/display;best=None
 for ex in (-5,-15,-30):
  fit=least_squares(lambda q:(projection(q,world)-image).ravel(),[ex,-15,1.5,30,3500,size[0]*.7,size[1]*.65],bounds=([-200,-300,.1,1,300,-10000,-10000],[-.1,-.5,20,89,40000,10000,10000]),max_nfev=600)
  if best is None or np.linalg.norm(fit.fun)<np.linalg.norm(best.fun):best=fit
 q=best.x;pred=projection(q,world);errors=np.linalg.norm(pred-image,axis=1);eye=[float(q[1]),float(short-q[0]),float(q[2])]
 cam={'structure_id':'st_marys_church','source_id':source,'photo':str(photo),'image_px':size,'principal_px':[float(q[5]),float(q[6])],'focal_px':float(q[4]),'eye':eye,'yaw_deg':float(90+q[3]),'sky':'overcast','solve':f'RESEARCH-ONLY camera seed for the unchanged1835frame_1833phase geometry. Seven manually read sill/eave/apex landmarks fitted in yaw-only perspective to the unchanged10.668x7.62m footprint,3.2m plate and reconstructed30degree roof. Mean residual{errors.mean():.1f}px, max{errors.max():.1f}px; hand readings approximate and the drawing may not be perfectly projective. The picture is retrospective; its detailed form and belfry presence are adopted forJuly1835as a declared temporal reconstruction, not a proved installation date. No geographic placement is fitted. Separate camera from the other source view. Neutral overcast light because tonal hatching does not yield a calibrated common shadow direction. No render review yet.'}
 if math.hypot(*eye[:2])>100:cam['near_m']=max(1,math.hypot(*eye[:2])-50)
 path=HERE/'cameras'/f'{name}-original-site.json';path.parent.mkdir(exist_ok=True);path.write_text(json.dumps(cam,indent=2)+'\n')
 report.append({'view':name,'image_size':size,'mean_residual_px':float(errors.mean()),'max_residual_px':float(errors.max()),'camera':str(path),'points':[{'name':n,'image_px':a.tolist(),'fitted_px':b.tolist(),'error_px':float(e)} for n,a,b,e in zip(labels,image,pred,errors)]})
(HERE/'camera-landmarks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps([{k:v for k,v in row.items() if k!='points'} for row in report],indent=2))
