from pathlib import Path
import json,copy,difflib,hashlib,shutil,re
ROOT=Path('/workspace/chicago');HERE=Path(__file__).resolve().parent;TREE=HERE/'candidate';files={}
def _prose(v):
 if isinstance(v,str):
  v=v.replace('25x35ft','25 × 35 ft').replace('25x35','25 × 35')
  v=re.sub(r'(?<=[A-Za-z])(?=\d{4})|(?<=\d)(?=[A-Za-z])', ' ',v)
  return v.replace('4 d/', '4d/').replace('church25','church 25').replace('original25','original 25').replace('reconstructed9','reconstructed 9').replace('exactJuly','exact July').replace('localwest','local west').replace('the+north','the +north').replace('Gale1902', 'Gale 1902')
 if isinstance(v,list):return [_prose(x) for x in v]
 return v
PROSE={'citation','describes_date','locator','rights_note','what_it_supplies','what_it_does_not_supply','note','research_note'}
def _notes(v,prior=None):
 if v==prior:return v
 if isinstance(v,dict):return {k:(_prose(x) if k in PROSE else _notes(x,(prior or {}).get(k))) for k,x in v.items()}
 if isinstance(v,list):return [_notes(x,prior[i] if isinstance(prior,list) and i<len(prior) else None) for i,x in enumerate(v)]
 return v
def put(path,value):
 prior=json.loads((ROOT/path).read_text()) if isinstance(value,dict) and (ROOT/path).exists() else None
 value=_notes(value,prior) if isinstance(value,dict) else value
 text=json.dumps(value,indent=2,ensure_ascii=False)+'\n' if isinstance(value,dict) else value
 files[path]=text;p=TREE/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
param='chicago/4d/generators/archetypes/frame_dwelling_params.py';s=(ROOT/param).read_text();s=s.replace('"trim", "chimney_head",','"trim", "chimney_head", "chapel_profile", "tower",')
s=s.replace('    # ---------------------------------------------------------------- derived\n','    # Opt-in pictured chapel; keyword-only keeps every existing positional call.\n    chapel_profile: dict | None = field(default=None, kw_only=True)\n\n    # ---------------------------------------------------------------- derived\n',1)
s=s.replace('    def validate(self) -> None:\n','    def validate(self) -> None:\n        if self.chapel_profile is not None:\n            _validate_chapel_profile(self)\n',1)
s=s.replace('        confidence=confidences,\n','        confidence=confidences,\n        chapel_profile=(None if val("chapel_profile") is None else dict(val("chapel_profile"))),\n',1)
s=s.replace('    stories = float(val("stories", 1.5))', '''    raw_chapel = val("chapel_profile")
    if raw_chapel is not None:
        if not isinstance(raw_chapel, dict):
            raise ParamError("chapel_profile must be a dictionary")
        if any(k in form for k in ("plan", "bays", "glazing", "trim", "chimney_head", "knee_wall_m")):
            raise ParamError("chapel_profile owns its openings/trim; remove household facade or loft overrides")
    stories = float(val("stories", 1.5))''', 1)
s=s.replace('    p.resolve()\n    return p\n','    if p.chapel_profile is not None and val("tower") is not True:\n        raise ParamError("chapel_profile builds a belfry; the record must state tower=true")\n    p.resolve()\n    return p\n',1)
s+='''\n\ndef _validate_chapel_profile(p: FrameDwellingParams) -> None:
    """One explicit pictured chapel, never a silent substitute for a house."""
    q = p.chapel_profile
    keys = {"kind", "window_centres_from_far_m", "window_width_m", "window_height_m",
            "window_sill_m", "door_centre_from_far_m", "door_width_m", "door_height_m",
            "belfry_width_m", "belfry_near_setback_m", "belfry_plinth_above_ridge_m",
            "belfry_open_height_m", "belfry_cap_height_m", "cross_height_m",
            "chimney_from_far_xy_m", "chimney_width_m", "chimney_head_above_roof_m",
            "glazing_across", "glazing_rows"}
    if not isinstance(q, dict) or set(q) != keys or q.get("kind") != "st_marys_original_site":
        raise ParamError("chapel_profile needs the complete st_marys_original_site specification")
    if (p.stories != 1 or p.ell or p.roof_type != "gable" or p.porch or p.shutters
            or p.construction != "balloon_frame" or p.trim != DEFAULT_TRIM
            or p.stovepipes or p.chimneys != 1):
        raise ParamError("chapel_profile supports one plain rectangular storey, gable, one stack, no ell/porch/shutters/pipe")
    def number(v):
        return isinstance(v, (float, int)) and not isinstance(v, bool) and math.isfinite(v) and v > 0
    for k in keys - {"kind", "window_centres_from_far_m", "chimney_from_far_xy_m", "glazing_rows"}:
        if not number(q[k]):
            raise ParamError(f"chapel_profile {k} must be finite and positive")
    centres = q["window_centres_from_far_m"]
    if (not isinstance(centres, (tuple, list)) or len(centres) != 5
            or not all(number(v) for v in centres) or sorted(centres) != list(centres)):
        raise ParamError("chapel_profile needs five ordered sash centres")
    if q["window_sill_m"] + q["window_height_m"] >= p.wall_height_m - .05:
        raise ParamError("chapel sash must clear the plate")
    if q["door_height_m"] >= p.wall_height_m - .05:
        raise ParamError("chapel door must clear the plate")
    spans = [(c-q["window_width_m"]/2, c+q["window_width_m"]/2) for c in centres]
    spans.append((q["door_centre_from_far_m"]-q["door_width_m"]/2,
                  q["door_centre_from_far_m"]+q["door_width_m"]/2))
    if (any(a <= .12 or b >= p.width_m-.12 for a, b in spans)
            or any(b+.15 >= c for (_, b), (c, _) in zip(sorted(spans), sorted(spans)[1:]))):
        raise ParamError("chapel openings overlap or leave the north wall")
    side, near = q["belfry_width_m"], q["belfry_near_setback_m"]
    if side >= p.depth_m-.2 or not side/2+.05 <= near <= p.width_m-side/2-.05:
        raise ParamError("chapel belfry must sit entirely over its roof footprint")
    xy = q["chimney_from_far_xy_m"]
    if (not isinstance(xy, (tuple, list)) or len(xy) != 2 or not all(number(v) for v in xy)
            or not .2 < xy[0] < p.depth_m-.2 or not .2 < xy[1] < p.width_m-.2):
        raise ParamError("chapel stack position must lie over the roof")
    rows = q["glazing_rows"]
    if (not isinstance(q["glazing_across"], int) or q["glazing_across"] not in (1, 2, 3, 4)
            or not isinstance(rows, (tuple, list)) or len(rows) != 2
            or not all(isinstance(v, int) and not isinstance(v, bool) and 1 <= v <= 4 for v in rows)):
        raise ParamError("chapel glazing needs 1..4 columns and two 1..4-row sashes")
'''
# Shared entrance/signage readers describe exactly the profile's north wall.
s=s.replace('    w, n = p.width_m, p.bays\n', '\n'.join([
    '    if p.chapel_profile is not None:',
    '        q = p.chapel_profile',
    '        return sorted([(p.width_m-c, "window") for c in q["window_centres_from_far_m"]]',
    '                      + [(p.width_m-q["door_centre_from_far_m"], "door")])',
    '    w, n = p.width_m, p.bays', '']), 1)
s=s.replace('    w = float(p.width_m)\n    wall_z = float(p.wall_height_m)\n', '\n'.join([
    '    if p.chapel_profile is not None:',
    '        p.validate()',
    '        q = p.chapel_profile',
    '        out = []',
    '        for cx, kind in facade_bays(p):',
    '            width = q["door_width_m"] if kind == "door" else q["window_width_m"]',
    '            bottom = .05 if kind == "door" else q["window_sill_m"]',
    '            top = q["door_height_m"] if kind == "door" else bottom+q["window_height_m"]',
    '            out.append({"kind": kind, "u0": cx-width/2, "u1": cx+width/2,',
    '                        "z0": bottom, "z1": top})',
    '        return {"u0": 0.0, "u1": float(p.width_m),',
    '                "wall_height_m": float(p.wall_height_m), "openings": out}',
    '    w = float(p.width_m)',
    '    wall_z = float(p.wall_height_m)', '']), 1)
put(param,s)
builder='chicago/4d/generators/archetypes/frame_dwelling.py';s=(ROOT/builder).read_text();s=s.replace('    params.resolve()\n    b = MeshBuilder(name)\n','    params.resolve()\n    if params.chapel_profile is not None:\n        from archetypes.frame_dwelling_chapel import build as build_chapel\n        return build_chapel(params, name)\n    b = MeshBuilder(name)\n',1);put(builder,s)
mi='chicago/4d/generators/mesh_inputs.py';s=(ROOT/mi).read_text();anchor='    # T-1730: the high-detail Glessner build delegates to v4-only modules.\n';insert='''    # T-2384: only an explicitly selected chapel profile imports this family.
    # New helpers in that family remain watched by default, like Glessner v4.
    if archetype == "frame_dwelling" and getattr(params, "chapel_profile", None) is not None:
        chapel_modules = sorted((gen / "archetypes").glob("frame_dwelling_chapel*.py"))
        if not chapel_modules:
            raise InputsError("frame dwelling chapel helper modules are missing")
        wanted += chapel_modules
''';assert anchor in s;s=s.replace(anchor,insert+anchor,1);put(mi,s)
# Isolated prototype topology becomes a proper opt-in helper. It builds in a
# short-span/long-run frame, then maps that frame into the unchanged record axes:
# canonical east=run, north=depth-span. The door remains on the +north facade.
helper=Path('/tmp/chicago-next-model/T-2384-prototype/runs/v1/chapel_geometry.py').read_text()
helper=helper.replace('import math\n','import math\nfrom types import SimpleNamespace\n',1)
helper=helper.replace('def build_geometry(p,name):\n p.validate();b=MeshBuilder(name);w,l,h=p.width,p.length,p.height','def build_geometry(p,name):\n b=MeshBuilder(name);w,l,h=p.width,p.length,p.height')
helper=helper.replace("p.window_sill+p.window_height,C,kit,2,(1,1)","p.window_sill+p.window_height,C,kit,p.glazing_across,p.glazing_rows")
helper=helper.replace('b.add_box(0,0,0,w,l,h,C,WALL', 'b.add_box(0,0,0,w,l,h,p.mass_conf,WALL')
helper=helper[:helper.index('\ndef build(p,name):')]+'''

def _adapt(params):
    q = params.chapel_profile
    return SimpleNamespace(
        width=params.depth_m, length=params.width_m, height=params.wall_height_m,
        pitch=params.roof_pitch_deg, course=params.siding_exposure_m,
        window_centres=q["window_centres_from_far_m"], window_width=q["window_width_m"],
        window_height=q["window_height_m"], window_sill=q["window_sill_m"],
        door_centre=q["door_centre_from_far_m"], door_width=q["door_width_m"],
        door_height=q["door_height_m"], tower_width=q["belfry_width_m"],
        tower_setback=q["belfry_near_setback_m"], plinth_rise=q["belfry_plinth_above_ridge_m"],
        open_height=q["belfry_open_height_m"], cap_height=q["belfry_cap_height_m"],
        cross_height=q["cross_height_m"], chimney_xy=q["chimney_from_far_xy_m"],
        chimney_width=q["chimney_width_m"], chimney_head=q["chimney_head_above_roof_m"],
        glazing_across=q["glazing_across"], glazing_rows=tuple(q["glazing_rows"]),
        ridge=params.wall_height_m+params.depth_m/2*math.tan(math.radians(params.roof_pitch_deg)),
        mass_conf=params.worst_conf("stories", "construction"))


def chapel_mesh(params, name):
    """Pure accumulation; east/north footprint and +north door convention retained."""
    params.validate()
    p = _adapt(params)
    b = build_geometry(p, name)
    # Orthonormal change from short-span/long-run to record east/north axes.
    # This is geometry's local basis, never a scene rotation or moved footprint.
    b.verts = [(run, params.depth_m-span, z) for span, run, z in b.verts]
    return b


def build(params, name):
    b = chapel_mesh(params, name)
    finish = materials.wall_finish(params.paint, params.finish_key)
    wall_rgba, rough = materials.resolve(materials.wall_substrate(cladding="clapboard"), finish)
    roof = materials.roof_substrate("frame_dwelling")
    return b.to_object([
        simple_material("wall", wall_rgba, roughness=rough),
        simple_material(materials.roof_material_name(roof), materials.roof_finish(params.roof_condition).rgba, roughness=roof.roughness),
        simple_material("trim", materials.trim_rgba(finish), roughness=.85),
        simple_material("dark", materials.DARK.rgba, roughness=materials.DARK.roughness),
        simple_material("stack_reconstructed", (.45,.42,.36,1), roughness=.85),
        simple_material("bell_and_iron_reconstructed", (.12,.115,.10,1), roughness=.6)])
'''
helper=helper.replace('Research-only wooden chapel appearance; no product registry changes.','Opt-in St Mary\'s original-site chapel appearance (T-2384).').replace('The May 1844 diary establishes steeple,\nbell and cross presence. The undated Andreas engraving guides visible topology.','The original-site Gale1902 plate supports a reconstructed1835belfry; the\nundated Andreas engraving guides visible topology. Neither dates installation.').replace('May 1844','July 1835')
helper=helper.replace('including the engraving/1844 link.', 'including the temporal picture-to-1835 link.').replace('presence dated by diary; exact profile reconstructed.', 'presence reconstructed for 1835; exact profile reconstructed.')
put('chicago/4d/generators/archetypes/frame_dwelling_chapel.py',helper)
source='gale_1902_st_marys_original_site'
put('chicago/4d/data/sources/'+source+'.json',{'id':source,'type':'illustration','citation':"W. E. S. Trowbridge, drawing signed '02, The First Catholic Church, in Edwin O. Gale, Reminiscences of Early Chicago and Vicinity (Chicago: Fleming H. Revell, 1902), plate opposite printed p.49. Caption: The First Catholic Church. Erected in1834 on the Southwest Corner of State and Lake Streets. Adjacent printed pp.48–49 call the original church25x35ft, built1833 and finished the following year.",'author':'W. E. S. Trowbridge (1902 drawing); Edwin O. Gale (memoir)','date':'1902','describes_date':'Caption names erection in1834 and original State/Lake location; this is a1902retrospective depiction, not a tower installation date. Adjacent prose describes the original25x35ft church within an1835arrival walk.','repository':'Internet Archive, item reminiscencesofec00gale','url':'https://archive.org/details/reminiscencesofec00gale','archived_url':'https://archive.org/download/reminiscencesofec00gale/page/n70_large.jpg','locator':'Plate opposite printed p.49; full page copied to chicago/4d/data/sources/assets/gale_1902_st_marys_original_site.jpg. Adjacent p.48 at /page/n69_large.jpg and p.49 at /page/n72_large.jpg were visually read on2026-10-23.','tier':5,'rights_status':'public_domain','rights_note':'Published in the1902US book; the drawing is signed1902. Public domain in the United States.','asset_use':'geometry','verified':True,'what_it_supplies':['Positive retrospective assignment of the five-sash/end-door/blank-gable/open-belfry topology to the original State/Lake church, with a caption naming1834.','Visible three-column, three-row upper and lower sash pattern is used as reconstructed9-over-9glazing. Exact dimensions, profiles and unseen surfaces remain reconstructed.'],'what_it_does_not_supply':['No period notice dating tower/bell installation, and no proof of the exactJuly1835state.','No measured drawing, coordinate, surveyed bearing or enlarged church dimensions.','No independent corroboration of Andreas: the close shared topology may be dependent on the1884engraving or a common earlier model.'],'note':'Do not treat captioned erection year as a dated image exposure or installation year. The text says built1833and finished the following year; keep the existing1833built date. The source supports a declared1835temporal reconstruction, not an attested addition date. A no-tower earliest-state reconstruction remains an alternative; neither uncertainty nor filename1843proves post1835form.'})
recordpath='chicago/4d/data/structures/st_marys_church.json';d=json.loads((ROOT/recordpath).read_text());old=copy.deepcopy(d);p=d['phases'][0]
profile={'kind':'st_marys_original_site','window_centres_from_far_m':[2.4,4.0,5.6,7.2,8.8],'window_width_m':.65,'window_height_m':1.55,'window_sill_m':1.10,'door_centre_from_far_m':.85,'door_width_m':.85,'door_height_m':2.03,'belfry_width_m':2.05,'belfry_near_setback_m':1.20,'belfry_plinth_above_ridge_m':.24,'belfry_open_height_m':1.74,'belfry_cap_height_m':1.70,'cross_height_m':.72,'chimney_from_far_xy_m':[1.65,1.75],'chimney_width_m':.30,'chimney_head_above_roof_m':.60,'glazing_across':3,'glazing_rows':[3,3]}
p['form']['chapel_profile']={'value':profile,'confidence':'reconstructed','sources':[source,'andreas_1884_st_marys_engraving'],'note':'Original25x35ft footprint retained, with roof ridge parallel to the north long wall and the pictured blank near gable at localwest. Five sash and the door at the far/east end occupy the+north facade. Belfry presence onJuly1835is a declared temporal reconstruction supported by Gale\'s original-site1834caption and Andreas\'s undated subsequent tower, not an attested installation date. All metric setout, section sizes, cap/bell/rail profiles, pane pattern and hidden surfaces are reconstructed. No1844enlargement dimensions are transferred.'}
p['form']['tower']={'value':True,'confidence':'reconstructed','sources':[source,'andreas_1884_st_marys_engraving'],'geometry':'simplified','note':'POSITIVE1835RECONSTRUCTION,NOT A NEW INSTALLATION DATE. Gale1902\'s plate explicitly labels this open-belfry form as the original State/Lake church, erected1834; its adjacent text retains25x35ft and describes an1835walk. It may depend on Andreas1884and does not independently prove theJuly1835tower. Andreas dates no tower only to initial1833construction, then says some time afterwards. No held evidence forces the tower after1835or after relocation. The chapel profile adopts the pictured belfry/bell/cross form as reconstructed while preserving original footprint, phase dates, bearing and placement. May1844presence remains the strongest dated tower description.'}
p['form']['roof_pitch_deg']={'value':30.0,'confidence':'reconstructed','sources':['andreas_1884_st_marys_engraving',source],'note':'Initial reconstructed30degree roof prior read against the drawn gable in the fixed25x35ft footprint. It is a comparison choice, not a measured historical pitch; the two retrospective drawings receive separate cameras.'}
for key in ('plan','bays'):p['form'].pop(key,None)
p['footprint']['note']="The source states a church twenty-five by thirty-five feet in size (chicagology_prefire216, transcribing Andreas; collated at Andreas1884vol1 printed p290). The existing polygon converts35x25ft to10.668x7.62m. A plain rectangular plan is inferred; the source is not a surveyed plan. Polygon, coordinates and bearing are retained unchanged by T-2384. The opt-in pictured-chapel profile has its ridge parallel to the north long wall, with a side door near the east end, five sash, a blank west gable and a small open belfry. Both retrospective pictures show the door on a long wall, so an earlier generic assumption that the entrance must occupy the gable is withdrawn. The drawings do not calibrate the building's geographic bearing or lot. Orientation remains a reconstruction choice; the camera fit never moves it. No later doubled length is inferred from the five sash."
d['research_note']="T-2384 pictured-chapel reconstruction for the existing July1835 phase. Andreas1884vol1 printed p290 gives the original25x35ft frame church, initially unpainted and without a tower in1833, then a low open tower and small bell at only 'some time afterwards'. The exact Moss engraving on printed p291 has an undated caption; the downloaded filename1843is not evidence of its depicted year. Gale1902plate opposite p49, signed W.E.S.Trowbridge '02, captions the pictured open-belfry form at the original State/Lake site with erection in1834. Adjacent pp48-49 say built1833, finished the following year, and retain25x35ft inside a retrospective1835arrival walk. Gale may depend on Andreas or a common model; neither is a period installation record. This positive original-site attribution supports adopting the pictured belfry, five sash, end side-door and blank gable as a declared1835temporal reconstruction rather than treating the initial1833no-tower state as uniquely mandatory. May24,1835 Bruté correspondence, transmitted in Garraghan1921p84, says floor-area enlargement had been prevented by uncertain title; it supports retaining the original footprint but does not say a small tower was absent. Quarter's May1844 diary, transmitted in Garraghan p127, remains the strongest dated description of steeple, bell and cross; its later dimensions/occupancy are not transferred to1835. Original phase dates, polygon, position and bearing stay unchanged. All metric belfry/opening/cap/rail/bell profiles, concealed faces and detailed glazing are reconstructed. frame_dwelling now has an explicit opt-in chapel profile; its household plan/bay grammar is removed from this record, and shared facade readers use the same pictured openings as the mesh. Geographic orientation remains unresolved by the perspective drawings. See docs/RESEARCH/st-marys-T-2384-chronology.md and the follow-up evidence package. Original T-2384 remains open: separate Moss and Gale research comparisons were actually viewed and both still differ."
put(recordpath,d)
# Preserve already-approved picture and source files by copying only the new Gale image.
a='chicago/4d/data/sources/assets/gale_1902_st_marys_original_site.jpg';target=TREE/a;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile('/tmp/chicago-next-model/T-2384-belfry-followup/gale-n70.jpg',target)
patch=''
for path,new in files.items():
 oldtext=(ROOT/path).read_text() if (ROOT/path).exists() else ''
 patch+=''.join(difflib.unified_diff(oldtext.splitlines(True),new.splitlines(True),fromfile='a/'+path if oldtext else '/dev/null',tofile='b/'+path))
(HERE/'T-2384-1835.patch').write_text(patch)
(HERE/'input-snapshot.json').write_text(json.dumps({path:hashlib.sha256((ROOT/path).read_bytes()).hexdigest() if (ROOT/path).exists() else None for path in files},indent=2)+'\n')
print('Prepared',len(files),'text files plus new Gale source image; repository untouched.')
