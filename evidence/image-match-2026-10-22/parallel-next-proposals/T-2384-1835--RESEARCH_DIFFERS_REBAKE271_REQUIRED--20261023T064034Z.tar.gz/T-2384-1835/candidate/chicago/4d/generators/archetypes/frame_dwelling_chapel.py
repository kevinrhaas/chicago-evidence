"""Opt-in St Mary's original-site chapel appearance (T-2384).

All metric profiles are reconstructed. The original-site Gale1902 plate supports a reconstructed1835belfry; the
undated Andreas engraving guides visible topology. Neither dates installation.
Hidden faces are reconstructed plain; only the left long wall has openings.
"""
import math
from types import SimpleNamespace
from common.mesh import MeshBuilder,simple_material
from common import openings,materials
WALL,ROOF,TRIM,DARK,STACK,METAL=range(6)
C=1.0  # Explicitly reconstructed detailed form, including the temporal picture-to-1835 link.
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def scale(a,k):return tuple(x*k for x in a)
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def unit(a):return scale(a,1/math.sqrt(dot(a,a)))
def beam(b,a,c,width,mat=TRIM):
 d=unit(sub(c,a));u=unit(cross(d,(0,0,1) if abs(d[2])<.9 else (0,1,0)));v=cross(d,u);r=width/2
 rings=[[add(t,add(scale(u,s*r),scale(v,q*r))) for s,q in ((-1,-1),(1,-1),(1,1),(-1,1))] for t in (a,c)]
 b.add_poly(list(reversed(rings[0])),C,mat);b.add_poly(rings[1],C,mat)
 for i in range(4):j=(i+1)%4;b.add_poly([rings[0][i],rings[0][j],rings[1][j],rings[1][i]],C,mat)
def curve(b,points,width,mat=TRIM):
 for a,c in zip(points,points[1:]):beam(b,a,c,width,mat)
def lathe(b,cx,cy,levels,mat=METAL,n=16):
 for (z0,r0),(z1,r1) in zip(levels,levels[1:]):
  for i in range(n):
   a0,a1=2*math.pi*i/n,2*math.pi*(i+1)/n
   b.add_poly([(cx+r0*math.cos(a0),cy+r0*math.sin(a0),z0),(cx+r0*math.cos(a1),cy+r0*math.sin(a1),z0),(cx+r1*math.cos(a1),cy+r1*math.sin(a1),z1),(cx+r1*math.cos(a0),cy+r1*math.sin(a0),z1)],C,mat)
def siding(b,p):
 # Thin overlapping course edges follow every visible boarded wall. Gable courses
 # narrow toward the apex; unseen surfaces repeat the same reconstructed stock.
 w,l,h=p.width,p.length,p.height
 z=.12
 while z<h-.08:
  d=min(.018,p.course*.15)
  b.add_poly([(0,0,z),(w,0,z),(w,-d,z-.016),(0,-d,z-.016)],C,WALL)
  b.add_poly([(w,l,z),(0,l,z),(0,l+d,z-.016),(w,l+d,z-.016)],C,WALL)
  b.add_poly([(0,l,z),(0,0,z),(-d,0,z-.016),(-d,l,z-.016)],C,WALL)
  b.add_poly([(w,0,z),(w,l,z),(w+d,l,z-.016),(w+d,0,z-.016)],C,WALL)
  z+=p.course
 z=h+p.course
 while z<p.ridge-.05:
  inset=(z-h)/math.tan(math.radians(p.pitch))
  for y,sign in ((0,-1),(l,1)):
   b.add_poly([(inset,y,z),(w-inset,y,z),(w-inset,y+sign*.016,z-.016),(inset,y+sign*.016,z-.016)],C,WALL)
  z+=p.course

def belfry(b,p):
 cx,cy=p.width/2,p.tower_setback;r=p.tower_width/2
 base=p.ridge+p.plinth_rise;top=base+p.open_height
 b.add_box(cx-r,cy-r,p.ridge-.85,cx+r,cy+r,base,C,WALL)
 for z,t in ((base-.06,.12),(top,.14),(top+.14,.09)):
  b.add_box(cx-r-.12,cy-r-.12,z,cx+r+.12,cy+r+.12,z+t,C,TRIM)
 posts=[(cx-r+.08,cy-r+.08),(cx+r-.08,cy-r+.08),(cx+r-.08,cy+r-.08),(cx-r+.08,cy+r-.08)]
 for x,y in posts:
  b.add_box(x-.065,y-.065,base,x+.065,y+.065,top,C,TRIM)
  for z in (base+.06,top-.32):b.add_box(x-.095,y-.095,z,x+.095,y+.095,z+.065,C,TRIM)
 for i,(x0,y0) in enumerate(posts):
  x1,y1=posts[(i+1)%4]
  for z in (base+.16,base+.56):beam(b,(x0,y0,z),(x1,y1,z),.065)
  beam(b,(x0,y0,base+.16),(x1,y1,base+.56),.045);beam(b,(x0,y0,base+.56),(x1,y1,base+.16),.045)
  # An arched void with a curved upper timber, reconstructed as an eleven-segment
  # parabolic brace. Both unseen faces repeat this pattern and are not attested.
  pts=[]
  for j in range(13):
   t=j/12;pts.append((x0+(x1-x0)*t,y0+(y1-y0)*t,top-.11-.58*(2*t-1)**2))
  curve(b,pts,.105)
 # Small bell and hanging yoke, presence reconstructed for 1835; exact profile reconstructed.
 beam(b,(cx-.28,cy,top-.17),(cx+.28,cy,top-.17),.06,METAL)
 beam(b,(cx,cy,top-.17),(cx,cy,base+.77),.035,METAL)
 lathe(b,cx,cy,[(base+.65,.25),(base+.71,.26),(base+.81,.19),(base+1.02,.13),(base+1.10,.07),(base+1.12,.01)])
 beam(b,(cx,cy,base+.72),(cx,cy,base+.52),.045,METAL)
 capbase=top+.23;radius=r+.14
 profiles=[(0,1),(.12,.77),(.30,.54),(.50,.35),(.72,.17),(.90,.065),(1,.025)]
 for (t0,r0),(t1,r1) in zip(profiles,profiles[1:]):
  for s in range(4):
   xy=[(-1,-1),(1,-1),(1,1),(-1,1)];a=xy[s];c=xy[(s+1)%4]
   b.add_poly([(cx+a[0]*radius*r0,cy+a[1]*radius*r0,capbase+p.cap_height*t0),(cx+c[0]*radius*r0,cy+c[1]*radius*r0,capbase+p.cap_height*t0),(cx+c[0]*radius*r1,cy+c[1]*radius*r1,capbase+p.cap_height*t1),(cx+a[0]*radius*r1,cy+a[1]*radius*r1,capbase+p.cap_height*t1)],C,ROOF)
 ball=capbase+p.cap_height+.08
 lathe(b,cx,cy,[(ball-.14,.01),(ball-.10,.11),(ball,.15),(ball+.10,.11),(ball+.14,.01)],TRIM)
 z=ball+.11
 beam(b,(cx,cy,z),(cx,cy,z+p.cross_height),.065)
 beam(b,(cx-.23,cy,z+p.cross_height*.66),(cx+.23,cy,z+p.cross_height*.66),.065)

def build_geometry(p,name):
 b=MeshBuilder(name);w,l,h=p.width,p.length,p.height
 b.add_box(0,0,0,w,l,h,p.mass_conf,WALL,skip=('bottom',))
 # Two roof planes and wall-clad gable triangles. Roof overhang has its own
 # eave elevation so the wall's plate remains exactly the parameterized height.
 over=.18;ez=h-over*math.tan(math.radians(p.pitch));ridge=p.ridge
 b.add_poly([(-over,-over,ez),(w/2,-over,ridge),(w/2,l+over,ridge),(-over,l+over,ez)],C,ROOF)
 b.add_poly([(w/2,-over,ridge),(w+over,-over,ez),(w+over,l+over,ez),(w/2,l+over,ridge)],C,ROOF)
 b.add_poly([(0,0,h),(w,0,h),(w/2,0,ridge)],C,WALL)
 b.add_poly([(w,l,h),(0,l,h),(w/2,l,ridge)],C,WALL)
 siding(b,p)
 # Water table and frieze are plain boards, with no invented classical portico.
 for x in (0,w):
  b.add_box(x-.025,0,.02,x+.025,l,.12,C,TRIM)
  b.add_box(x-.025,0,h-.13,x+.025,l,h,C,TRIM)
 for y in (0,l):
  b.add_box(0,y-.025,.02,w,y+.025,.12,C,TRIM)
  for x in (0,w):b.add_box(x-.045,y-.045,.10,x+.045,y+.045,h,C,TRIM)
  beam(b,(-.10,y,h-.05),(w/2,y,ridge+.02),.10)
  beam(b,(w/2,y,ridge+.02),(w+.10,y,h-.05),.10)
 kit=openings.Mats(casing=TRIM,sash=TRIM,dark=DARK,glass=b.named_mat('glass',*openings.glass_material_spec()),door=b.named_mat('door',(.30,.272,.232,1),.86),panel=b.named_mat('door_panel',(.21,.19,.16,1),.86))
 wall=openings.Wall('x',0,-1,.018)
 for c in p.window_centres:
  c=l-c
  openings.window(b,wall,c-p.window_width/2,c+p.window_width/2,p.window_sill,p.window_sill+p.window_height,C,kit,p.glazing_across,p.glazing_rows)
 openings.panelled_door(b,wall,l-p.door_centre-p.door_width/2,l-p.door_centre+p.door_width/2,.05,p.door_height,C,kit,panels=4)
 # One visible small roof stack. Hidden heating provision remains unknown.
 x,far=p.chimney_xy;y=l-far;z=h+min(x,w-x)*math.tan(math.radians(p.pitch));r=p.chimney_width/2
 b.add_box(x-r,y-r,z-.15,x+r,y+r,z+p.chimney_head,C,STACK)
 b.add_box(x-r-.025,y-r-.025,z+p.chimney_head-.08,x+r+.025,y+r+.025,z+p.chimney_head,C,STACK)
 belfry(b,p)
 return b


def _adapt(params):
    q = params.chapel_profile
    return SimpleNamespace(
        width=params.depth_m, length=params.width_m, height=params.wall_height_m,
        pitch=params.roof_pitch_deg, course=params.siding_exposure_m,
        window_centres=q["window_centres_from_far_m"], window_width=q["window_width_m"],
        window_height=q["window_height_m"], window_sill=q["window_sill_m"],
        door_centre=q["door_centre_from_far_m"], door_width=q["door_width_m"],
        door_height=q["door_height_m"], tower_width=q["belfry_width_m"],
        tower_setback=q["belfry_near_setback_m"], plinth_rise=q["belfry_plinth_above_ridge_m"],
        open_height=q["belfry_open_height_m"], cap_height=q["belfry_cap_height_m"],
        cross_height=q["cross_height_m"], chimney_xy=q["chimney_from_far_xy_m"],
        chimney_width=q["chimney_width_m"], chimney_head=q["chimney_head_above_roof_m"],
        glazing_across=q["glazing_across"], glazing_rows=tuple(q["glazing_rows"]),
        ridge=params.wall_height_m+params.depth_m/2*math.tan(math.radians(params.roof_pitch_deg)),
        mass_conf=params.worst_conf("stories", "construction"))


def chapel_mesh(params, name):
    """Pure accumulation; east/north footprint and +north door convention retained."""
    params.validate()
    p = _adapt(params)
    b = build_geometry(p, name)
    # Orthonormal change from short-span/long-run to record east/north axes.
    # This is geometry's local basis, never a scene rotation or moved footprint.
    b.verts = [(run, params.depth_m-span, z) for span, run, z in b.verts]
    return b


def build(params, name):
    b = chapel_mesh(params, name)
    finish = materials.wall_finish(params.paint, params.finish_key)
    wall_rgba, rough = materials.resolve(materials.wall_substrate(cladding="clapboard"), finish)
    roof = materials.roof_substrate("frame_dwelling")
    return b.to_object([
        simple_material("wall", wall_rgba, roughness=rough),
        simple_material(materials.roof_material_name(roof), materials.roof_finish(params.roof_condition).rgba, roughness=roof.roughness),
        simple_material("trim", materials.trim_rgba(finish), roughness=.85),
        simple_material("dark", materials.DARK.rgba, roughness=materials.DARK.roughness),
        simple_material("stack_reconstructed", (.45,.42,.36,1), roughness=.85),
        simple_material("bell_and_iron_reconstructed", (.12,.115,.10,1), roughness=.6)])
