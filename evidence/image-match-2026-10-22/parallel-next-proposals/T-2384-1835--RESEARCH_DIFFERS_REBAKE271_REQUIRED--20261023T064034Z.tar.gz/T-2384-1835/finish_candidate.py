"""Small follow-up to the authoring script: shared-reader parity and clean notes."""
from pathlib import Path
p=Path('/tmp/chicago-next-model/T-2384-1835/prepare_proposal.py');s=p.read_text()
anchor="put(param,s)\nbuilder="
replacement='''# Shared entrance/signage readers describe exactly the profile's north wall.
s=s.replace('    w, n = p.width_m, p.bays\\n', '\\n'.join([
    '    if p.chapel_profile is not None:',
    '        q = p.chapel_profile',
    '        return sorted([(p.width_m-c, "window") for c in q["window_centres_from_far_m"]]',
    '                      + [(p.width_m-q["door_centre_from_far_m"], "door")])',
    '    w, n = p.width_m, p.bays', '']), 1)
s=s.replace('    w = float(p.width_m)\\n    wall_z = float(p.wall_height_m)\\n', '\\n'.join([
    '    if p.chapel_profile is not None:',
    '        p.validate()',
    '        q = p.chapel_profile',
    '        out = []',
    '        for cx, kind in facade_bays(p):',
    '            width = q["door_width_m"] if kind == "door" else q["window_width_m"]',
    '            bottom = .05 if kind == "door" else q["window_sill_m"]',
    '            top = q["door_height_m"] if kind == "door" else bottom+q["window_height_m"]',
    '            out.append({"kind": kind, "u0": cx-width/2, "u1": cx+width/2,',
    '                        "z0": bottom, "z1": top})',
    '        return {"u0": 0.0, "u1": float(p.width_m),',
    '                "wall_height_m": float(p.wall_height_m), "openings": out}',
    '    w = float(p.width_m)',
    '    wall_z = float(p.wall_height_m)', '']), 1)
put(param,s)
builder='''
assert anchor in s;s=s.replace(anchor,replacement,1)
s=s.replace('including the engraving/1844 link.', 'including the temporal picture-to-1835 link.')
# Original template contains these comments; neither must imply diary dating in 1835.
s=s.replace("put('chicago/4d/generators/archetypes/frame_dwelling_chapel.py',helper)","helper=helper.replace('including the engraving/1844 link.', 'including the temporal picture-to-1835 link.').replace('presence dated by diary; exact profile reconstructed.', 'presence reconstructed for 1835; exact profile reconstructed.')\nput('chicago/4d/generators/archetypes/frame_dwelling_chapel.py',helper)")
# Normalize prose only, leaving identifiers, paths, URLs, data values and code alone.
s=s.replace('def put(path,value):\n text=', '''def _prose(v):
 if isinstance(v,str):
  v=v.replace('25x35ft','25 × 35 ft').replace('25x35','25 × 35')
  v=re.sub(r'(?<=[A-Za-z])(?=\\d{4})|(?<=\\d)(?=[A-Za-z])', ' ',v)
  return v.replace('localwest','local west').replace('the+north','the +north').replace('Gale1902', 'Gale 1902')
 if isinstance(v,list):return [_prose(x) for x in v]
 return v
PROSE={'citation','describes_date','locator','rights_note','what_it_supplies','what_it_does_not_supply','note','research_note'}
def _notes(v):
 if isinstance(v,dict):return {k:(_prose(x) if k in PROSE else _notes(x)) for k,x in v.items()}
 if isinstance(v,list):return [_notes(x) for x in v]
 return v
def put(path,value):
 value=_notes(value) if isinstance(value,dict) else value
 text=''',1)
p.write_text(s)
