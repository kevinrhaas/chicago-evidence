"""Isolated existing-phase research export, no build CLI or manifests."""
from pathlib import Path
import sys,json,hashlib,datetime
HERE=Path(__file__).resolve().parent
ROOT=Path('/workspace/chicago/chicago/4d')
FIXTURE=Path('/tmp/chicago-next-model/T-2384-1835/hash-fixture')
sys.path.insert(0,str(FIXTURE/'generators'))
import mesh_inputs,code_inputs
import emit
assert emit.ROOT==FIXTURE and mesh_inputs.ROOT==FIXTURE,(emit.ROOT,mesh_inputs.ROOT)
assert Path(emit.frame_dwelling.__file__).resolve()==FIXTURE/"generators/archetypes/frame_dwelling.py",emit.frame_dwelling.__file__
record=json.loads((HERE/'candidate/chicago/4d/data/structures/st_marys_church.json').read_text())
phase=next(p for p in record['phases'] if p['id']=='frame_1833')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protected=[ROOT/'assets/manifest.json',ROOT/'data/structures/st_marys_church.json',*sorted((ROOT/'assets').glob('*manifest*.json')),*sorted((ROOT/'data/scenes').glob('*.json'))]
before={str(p):sha(p) for p in protected if p.exists()}
recipe=mesh_inputs.structure_inputs_doc(record,phase,'frame_dwelling')
input_sha=mesh_inputs.structure_inputs_sha(record,phase,'frame_dwelling')
out=HERE/'st_marys_church__frame_1833.glb'
assert not out.exists() and not out.is_relative_to(ROOT)
made=emit.emit_structure(record,phase,'frame_dwelling',out,bake=True,ao=False)
assert before=={str(p):sha(p) for p in protected if p.exists()}
receipt={'research_only':True,'canonical_phase':'frame_1833','review_date':'1835-07-04','review_date_note':'Project July1835 scene; not an attested belfry-installation day.','archetype':'frame_dwelling','glb_sha256':sha(out),'mesh_inputs_sha256':input_sha,'triangles':made.tris,'protected_canonical_metadata_unchanged':True,'export':'direct emit API, fresh GLB outside checkout, UV unwrap without AO','limits':'Appearance reconstruction from retrospective original-site drawing and undated Andreas image; independent source cameras remain research-only.'}
out.with_suffix('.recipe.json').write_text(json.dumps(recipe,indent=2)+'\n')
out.with_suffix('.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(HERE/'protected-metadata.json').write_text(json.dumps(before,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
