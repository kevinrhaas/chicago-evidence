# T-2384 — original-site St Mary's chapel proposal

This is an isolated, reviewable proposal. It changes no checkout files, canonical assets, manifests, scenes or ticket status. The existing `frame_1833` phase retains its dates, position, bearing and 10.668 × 7.62 m polygon. The project scene date is **1835-07-01**. No later enlargement dimensions are transferred.

The source reassessment supports a positive **reconstructed** belfry in July 1835, rather than making continued absence mandatory. Andreas's initial 1833 no-tower statement is followed only by “Some time afterwards.” Gale's 1902 original-site plate captions the pictured form at State/Lake with 1834 erection; adjacent text gives 1833 construction, following-year completion and 25 × 35 ft inside a retrospective 1835 arrival walk. The drawing may depend on Andreas/common earlier material and does not independently date installation. Quarter's May 1844 diary remains the strongest dated steeple/bell/cross description, not a lower bound. See `../T-2384-belfry-followup/README.md` for scan URLs, exact quotations and search limitations.

## Selective integration

`T-2384-1835.patch` contains six text files, relative to `/workspace/chicago`:

- `chicago/4d/generators/archetypes/frame_dwelling_params.py`: keyword-only `chapel_profile=None`, strict opt-in validation, and facade-reader parity.
- `chicago/4d/generators/archetypes/frame_dwelling.py`: one explicit profile dispatch; existing default build AST remains identical.
- `chicago/4d/generators/archetypes/frame_dwelling_chapel.py`: opt-in chapel geometry helper.
- `chicago/4d/generators/mesh_inputs.py`: hash every `frame_dwelling_chapel*.py` helper only for the opt-in profile.
- `chicago/4d/data/structures/st_marys_church.json`: pictured form on the unchanged dated original-site record; tower/profile/pitch explicitly reconstructed; household `plan`/`bays` removed.
- `chicago/4d/data/sources/gale_1902_st_marys_original_site.json`: attributed, verified, public-domain US1902 drawing, geometry use with explicit limits.

Also copy the **binary source plate**, which is not encoded in the text patch:
`candidate/chicago/4d/data/sources/assets/gale_1902_st_marys_original_site.jpg`.
It is the complete signed/captioned plate, not a cropped derivative. Source attribution and cached-page hashes are in `package-files.json`.

`git apply --check` passes against the parent tree snapshot in `input-snapshot.json`; check again if the parent tree changes. Do not copy the entire fixture or `runs/` into product metadata. Use the liberty and chronology fragments beside this README when integrating the model. Generated assets retain the project's existing generated-output license coverage; source-image provenance is in the new source record, not a borrowed image-store filename.

## Geometry and defaults

The new helper builds a blank near gable, five long-wall sash and side door near the far end, small far stack, open belfry with crossed rails and curved upper braces, curved pointed cap, finial/cross and small bell. Source dimensions establish the main plan; **all detailed metric setout/profiles are reconstructed**, as are unseen walls and nine-over-nine sash interpretation. A short-span/long-run basis is mapped orthonormally into the existing record axes. No scene placement, polygon or bearing is rotated to fit either picture.

The profile is refused with ell, porch, upper storey, alternate roof/construction, shutters, stovepipe, extra stack, household facade/loft overrides, malformed profile fields, overlapping/out-of-wall openings or out-of-roof belfry/stack. `tower=true` is required in a profile-bearing record. `front_wall` and `facade_bays` expose exactly the same six north-wall openings as the mesh, for entrance/signage consumers. Their defaults remain unchanged.

**Blast radius:** 271 existing frame-dwelling master assets and zero versions. The main builder's bytes change, so the established hash scheme truthfully requires the family rebuild, even though all 271 existing default parameter sets/readers remain identical and the default builder AST is preserved. No `emit.py`, shared `common/` producer or town-wide registry edit is made. Do not restamp old input recipes. No family bake was run by this agent.

## Validation and actual render review

`light-checks.json` records passing schemas, unchanged constructor positions, all 271 default parameter/readers, strict negative fixtures, helper dependency invalidation, valid pure mesh accumulation, and exact equality between frozen v1 and final candidate resolved parameters/mesh vertices/faces/confidence/material indices. The candidate's later reader/comment/prose changes do change recipe bytes; they do **not** authorize relabeling the v1 GLB with a final canonical hash.

Frozen research render: `runs/v1/st_marys_church__frame_1833.glb`, 2,186 triangles, SHA256 `5ab9c3f1e286ee72edb3765a130a7859fb1525864ef752a3946c9ce8ce48dd9b`. It was exported through the direct `emit_structure` API outside the checkout, not `build.py --out`. Protected canonical structure/manifest/scene bytes were unchanged. GLB v2 header, phase/structure extras and `_CONFIDENCE` on every primitive passed (`runs/v1/contract-checks.json`).

Both comparisons were actually viewed:

- `runs/v1/comparison/moss-original-site-side-by-side.jpg`: **differs**. Belfry and cap are broader/heavier, columns and rail/brace profiles need refinement, and plinth details do not align.
- `runs/v1/comparison/gale-original-site-side-by-side.jpg`: **differs**. Sash width and setout need calibration; tower/cap profiles remain simplified. This camera fit has larger residuals than Moss.

Cameras were fitted separately from seven hand-read sill/eave/apex points. Mean/max landmark residuals: Moss9.8/25.8px; Gale15.6/33.4px. They are research seeds, not accepted canonical cameras. Colours/hidden faces are not established by the monochrome prints. Terrain, people and path are outside the isolated structure study and remain listed as absent. Match records carry open differences; **original T-2384 remains open**.

The frozen wrapper accidentally labeled its receipt sample July4; the receipt was corrected to the actual scene July1 with the original label mistake explicitly retained in its note. Geometry and recipe never depended on that label. The preserved wrapper is historical run evidence; do not execute it to overwrite v1. Neither the frozen May1844 prototype nor its comparisons were modified.

All Blender/browser processes owned by this study exited before handing the slot back to the parent. Final work was light Python/docs only.
