from pathlib import Path
import importlib.util,sys,types,json,dataclasses,inspect,ast,copy,hashlib
import jsonschema
HERE=Path(__file__).resolve().parent;ROOT=Path('/workspace/chicago/chicago/4d');CAND=HERE/'candidate/chicago/4d'
sys.path[:0]=[str(ROOT/'generators')]
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
old=module('old_frame_params',ROOT/'generators/archetypes/frame_dwelling_params.py');new=module('new_frame_params',CAND/'generators/archetypes/frame_dwelling_params.py')
old_sig=inspect.signature(old.FrameDwellingParams);new_sig=inspect.signature(new.FrameDwellingParams)
assert [(k,v) for k,v in new_sig.parameters.items() if k!='chapel_profile']==list(old_sig.parameters.items())
assert new_sig.parameters['chapel_profile'].kind is inspect.Parameter.KEYWORD_ONLY
# The default build's actual AST is byte-for-byte equivalent after removing its
# single opt-in dispatch. No other default vertex/material statement is edited.
a=next(n for n in ast.parse((ROOT/'generators/archetypes/frame_dwelling.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='build')
b=next(n for n in ast.parse((CAND/'generators/archetypes/frame_dwelling.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='build')
assert isinstance(b.body[2],ast.If);del b.body[2];assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
count=0
for p in sorted((ROOT/'data/structures').glob('*.json')):
 d=json.loads(p.read_text())
 if d.get('archetype')!='frame_dwelling':continue
 for phase in d['phases']:
  x=dataclasses.asdict(old.from_phase(phase,d));y=dataclasses.asdict(new.from_phase(phase,d));assert y.pop('chapel_profile') is None
  assert x==y,(d['id'],phase['id'])
  assert old.front_wall(old.from_phase(phase,d))==new.front_wall(new.from_phase(phase,d))
  assert old.facade_bays(old.from_phase(phase,d))==new.facade_bays(new.from_phase(phase,d))
  count+=1
record=json.loads((CAND/'data/structures/st_marys_church.json').read_text());prior=json.loads((ROOT/'data/structures/st_marys_church.json').read_text());p,q=record['phases'][0],prior['phases'][0]
assert p['position']==q['position'] and p['footprint']['polygon']==q['footprint']['polygon'] and p['documented_range']==q['documented_range']
jsonschema.Draft202012Validator(json.loads((ROOT/'data/structures.schema.json').read_text())).validate(record)
for path in (CAND/'data/sources').glob('*.json'):jsonschema.Draft202012Validator(json.loads((ROOT/'data/source.schema.json').read_text())).validate(json.loads(path.read_text()))
params=new.from_phase(p,record);params.validate()
# Real shared MeshBuilder/openings accumulation without importing Blender API.
sys.modules['bpy']=types.ModuleType('bpy');helper=module('chapel_geometry',CAND/'generators/archetypes/frame_dwelling_chapel.py');mesh=helper.chapel_mesh(params,'st_marys_church__frame_1833')
assert len(mesh.verts)==len(mesh.conf) and len(mesh.faces)==len(mesh.mat_index)
assert all(len(f)>=3 and all(0<=i<len(mesh.verts) for i in f) for f in mesh.faces)
assert all(all(__import__('math').isfinite(c) for c in v) for v in mesh.verts)
# Body's first eight-corner faces still use exact canonical footprint axes.
assert set((round(v[0],6),round(v[1],6)) for v in mesh.verts[:20])<=set([(0,0),(10.668,0),(10.668,7.62),(0,7.62)])
refusals=[]
for name,mut in [('bad profile',lambda x:x['form']['chapel_profile']['value'].update(kind='unknown')),('extra key',lambda x:x['form']['chapel_profile']['value'].update(extra=2)),('empty profile',lambda x:x['form']['chapel_profile'].update(value={})),('tower absent',lambda x:x['form']['tower'].update(value=False)),('upper story',lambda x:x['form']['stories'].update(value=2)),('overlapping windows',lambda x:x['form']['chapel_profile']['value'].update(window_centres_from_far_m=[2.4,2.4,5.6,7.2,8.8])),('window above plate',lambda x:x['form']['chapel_profile']['value'].update(window_height_m=4)),('tower outside roof',lambda x:x['form']['chapel_profile']['value'].update(belfry_near_setback_m=.1)),('pipe',lambda x:x['form'].update(stovepipes={'value':1,'confidence':'reconstructed','note':'negative fixture'}))]:
 x=copy.deepcopy(p);mut(x)
 try:new.from_phase(x,record)
 except (new.ParamError,ValueError,TypeError):refusals.append(name)
 else:raise AssertionError('accepted '+name)
wall=new.front_wall(params)
assert len(wall['openings'])==6 and [x['kind'] for x in wall['openings']].count('door')==1
for opening in wall['openings']:
 cx=(opening['u0']+opening['u1'])/2
 if opening['kind']=='door':assert abs(cx-(params.width_m-params.chapel_profile['door_centre_from_far_m']))<1e-9
 else:assert any(abs(cx-(params.width_m-c))<1e-9 for c in params.chapel_profile['window_centres_from_far_m'])
for key,value in [('plan','hall_parlour'),('bays',6),('glazing','12_over_12_6x8'),('trim','plain'),('chimney_head','plain'),('knee_wall_m',.95)]:
 x=copy.deepcopy(p);x['form'][key]={'value':value,'confidence':'reconstructed','note':'negative fixture'}
 try:new.from_phase(x,record)
 except new.ParamError:refusals.append('household override '+key)
 else:raise AssertionError('accepted household '+key)
# Frozen rendered candidate versus current candidate: pure mesh and resolved
# parameters must be identical despite added shared-reader branches/doc cleanup.
frozen=HERE/'runs/v1/candidate/chicago/4d'
frozenparams=module('frozen_params',frozen/'generators/archetypes/frame_dwelling_params.py')
frozenrecord=json.loads((frozen/'data/structures/st_marys_church.json').read_text())
fp=frozenparams.from_phase(frozenrecord['phases'][0],frozenrecord)
assert dataclasses.asdict(fp)==dataclasses.asdict(params)
frozenhelper=module('frozen_chapel',frozen/'generators/archetypes/frame_dwelling_chapel.py')
fm=frozenhelper.chapel_mesh(fp,'st_marys_church__frame_1833')
assert (fm.verts,fm.faces,fm.conf,fm.mat_index)==(mesh.verts,mesh.faces,mesh.conf,mesh.mat_index)
# Every helper byte is included only for an opted-in profile. Build a minimal
# geometry-code fixture; symlinks are read-only references to current modules.
fixture=HERE/'hash-fixture';gen=fixture/'generators';arch=gen/'archetypes';arch.mkdir(parents=True,exist_ok=True)
for f in (ROOT/'generators').iterdir():
 if f.is_file() and not (gen/f.name).exists():(gen/f.name).symlink_to(f)
if not (gen/'common').exists():(gen/'common').symlink_to(ROOT/'generators/common',target_is_directory=True)
for f in (ROOT/'generators/archetypes').iterdir():
 if f.is_file() and not (arch/f.name).exists():(arch/f.name).symlink_to(f)
for f in (CAND/'generators/archetypes').glob('*.py'):
 target=arch/f.name
 if target.exists() or target.is_symlink():target.unlink()
 target.write_bytes(f.read_bytes())
(gen/'mesh_inputs.py').unlink();(gen/'mesh_inputs.py').write_bytes((CAND/'generators/mesh_inputs.py').read_bytes())
import code_inputs
oldroot,oldcommon=code_inputs.ROOT,code_inputs.COMMON
code_inputs.ROOT,code_inputs.COMMON=fixture,gen/'common'
mi=module('chapel_mesh_inputs',gen/'mesh_inputs.py')
x=mi._code_shas('frame_dwelling',new.from_phase(q,prior));y=mi._code_shas('frame_dwelling',params)
helperkeys=[k for k in y if k.startswith('archetypes/frame_dwelling_chapel')]
assert helperkeys==['archetypes/frame_dwelling_chapel.py'] and not any('chapel' in k for k in x)
h=arch/'frame_dwelling_chapel.py';raw=h.read_bytes();h.write_bytes(raw+b'\n# dependency probe\n');assert mi._code_shas('frame_dwelling',params)!=y;assert mi._code_shas('frame_dwelling',new.from_phase(q,prior))==x;h.write_bytes(raw)
code_inputs.ROOT,code_inputs.COMMON=oldroot,oldcommon
report={'legacy_constructor_positions':'unchanged','default_build_ast':'identical after explicit opt-in dispatch removal','all_existing_frame_phases_default_params_unchanged_excluding_new_none_field':count,'canonical_date_placement_bearing_polygon':'unchanged','schema':'pass','profile_geometry_vertices':len(mesh.verts),'profile_geometry_triangles':sum(len(f)-2 for f in mesh.faces),'refused_cases':refusals,'profile_helper_dependency':'hashed and mutation invalidates profile only','legacy_family_master_count':271,'version_master_count':0,'shared_readers':'all271 defaults unchanged; profile six opening rectangles match geometry','frozen_v1_render_equivalence':'resolved params and complete pure mesh accumulation identical','blender_browser':'isolated frozen v1 exported and both actual source renders viewed; see runs/v1 receipts/matches, both differs'}
(HERE/'light-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
