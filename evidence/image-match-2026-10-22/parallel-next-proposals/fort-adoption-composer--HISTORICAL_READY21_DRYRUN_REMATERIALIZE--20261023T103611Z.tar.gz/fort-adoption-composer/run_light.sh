#!/usr/bin/env bash
# Targeted pure-Python/Node-free checks only. No Blender/browser/full repository gate.
set -euo pipefail
fort_adoption_package="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONDONTWRITEBYTECODE=1
python3 "$fort_adoption_package/materialize.py"
python3 "$fort_adoption_package/check_light.py"
python3 "$fort_adoption_package/prepare_geometry_proof.py"
python3 "$fort_adoption_package/proofs/profile/check_light.py"
python3 "$fort_adoption_package/check_recipes.py"
python3 "$fort_adoption_package/check_consumers.py"
python3 "$fort_adoption_package/verify_current.py"
