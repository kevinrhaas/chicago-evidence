# Guarded next fort-family adoption: concrete dry run

FROZEN HISTORICAL CHECKPOINT: the passed dry run below records head`e41ae248f6eaad1ead26c93537a7d1c7b438d3c0` and21 exact input hashes. Root has since started a retained-stash/current-dev integration. Do not apply this historical patch to that later tree. Re-run run_light.sh only when the parent requests fresh materialization after its current work settles; hash guards deliberately refuse stale inputs. No re-run or canonical mutation followed the root transition notice.

This new composer preserves every frozen predecessor. It writes only under this/tmp directory. The current dirty root's sourceS/Hogan/frame work is the base; no old manifest, asset, sidecar, name-key file, grade file or whole ledger is restored. `apply.sh` defaults to a read-only dry run. The child has NEVER invoked `--apply`.

The current dry run emits21 candidate files and a directly applicable patch. It composes final shared-fort controls, five range face layouts, narrower physical lighthouse, and its profile/apertures. Actual profile preview is still pending: do not adopt that profile until the granted isolated run and actual picture review. No original image gate is closed or relabelled by this package.

Apply order is embodied in `materialize.py`:

1. Call the frozen selective planner in memory: exact module guards, per-leaf JSON merge keyed by phase IDs, current source/ledger/image-inventory preservation, exact25-family membership guard.
2. Add only five `face_openings` attributes, preserving current records and the pending double galleries.
3. Merge the narrow lighthouse's physical footprint/diameter, then the explicit profile and three shaft windows. Preserve nominal12.19 value, origin, world centre, UTM position, bearing and dates; only source-based notes are clarified.
4. Use the frozen composed final fort modules after the baseline module guard has passed; guard both existing facade/signboard reader files exactly before adding their fort resolver. No common geometry helper, emitter, Blender pin or frame generator is edited.
5. Upgrade Castelnau to the actual1842 publication source audit. Existing sourceS/frame changes in the two image ledgers survive the single guarded Currey attribution correction. Getty rights corrections remain separate and do not hold public-domain-based fort geometry.
6. Append normalized liberty drafts to the EXACT current ledger prefix. Add only missing name-pool read paths to the CURRENT declaration. Append one whole-lighthouse appearance ruling to CURRENT structure grades; no sourceS/frame ruling is overwritten, and no compound image automatically attests all30 first-fort parts.

Repairs are needed because the older drafts were proposals, not parser-ready admissions. The lake-house heading's uppercase slug is normalized. Cupola Covers now lists five exact attributes instead of free prose. Face/profile drafts gain proper bold fields, lowercase IDs and exact aspect tokens. All eight drafts are parsed under an explicit Per-subject section; existing history is unchanged. Superseded older dimensional liberties remain in the append-only ledger. Names/read paths follow the existing raw-pool policy, not an invented ignored-field exemption.

Actual targeted results:

- Full proposed ledger:712 entries,0 parser/readable-text problems. Eight new liberties,23 reverse-checked real reconstructed/inferred claims. Actual validator forward coverage for all25 family records has0 errors.
- Ten changed structure schemas and two source schemas pass.
- Actual unmodified name-pool CLI self-test passes all checks, including raw-text pool equals parsed pool. Nine note paths are declared read.14 words enter and cupolas leaves; no register candidate's surname-membership changes. This is not a claim that the pool's word set stayed identical.
- All25 CURRENT root records preserve the complete16-position constructor, existing field defaults and derived properties under disabled new options. All12 added fields are individually keyword-only.
- Copied geometry proof: all25 composed defaults; exact old tower face/material streams for three default profiles; five range fronts unchanged; profile total bounds/ground feet unchanged;1062 finite nondegenerate reconstructed triangles. Frozen original proof files are not rerun or rewritten.
- Actual proposed recipes differ from the current manifest for all25 fort masters. They require a real bake. No recipe restamping or artifact copying is proposed.
- Current21 input/candidate hashes,25 master hashes and `git apply --check` pass. Any later root/source/reader edit causes refusal; recompose and review against that later tree.

Commands for the parent, after current frame work settles:

    bash /tmp/chicago-next-model/fort-adoption-composer/run_light.sh
    bash /tmp/chicago-next-model/fort-adoption-composer/apply.sh --dry-run

After actual isolated profile review and the parent's integration decision:

    bash /tmp/chicago-next-model/fort-adoption-composer/apply.sh --apply

The second command is prepared for review; it has not run. It verifies all input/candidate/master hashes immediately before applying the patch. No automatic bake, compile, commit, claim, PR or image-match action follows.

Canonical next steps remain a REAL25-family bake with `--only` the supplied comma-separated IDs, no single-scene1835 filter (1812 phases are included). Ten records intentionally change: lighthouse, Lake House shell, second-fort blockhouse, two first-fort blockhouses and five ranges; the other15 must retain default geometry. Compare freshly rebuilt before/after under the same pinned environment. Five old master baselines previously differed only in UV generation (lighthouse plus four second-fort buildings); keep that caveat and compare positions/normals/topology/materials rather than claiming committed-byte parity that was not shown. The new module/parameter bytes make old preview recipes stale even where shape is equal.

Then derive licenses/sidecars/pictures/grades/liberties/source uses/entrances through the existing ordered tail, inspect actual per-case reference renders and contact/collision, update research/ROADMAP/STATUS/changelog honestly, and run the required repository gates/smokes. Source public text must not expose local paths. Canonical bake receipts must be new; none of the research fixtures is a final artifact.

Entrances: the five explicit fronts belong to1812. Their shared facade answer is truthful, but the existing1835-only entrance producer excludes them. Every1835 fort default remains unread, and the curved lighthouse's window-only layout does not fabricate a flat front or ground door. No new1835 apron/signboard output is expected from this fort increment. Radius, physical footprint, collision, Show Me, actual mesh feet and static bedding stay aligned; the profile changes no grade or foundation elevation.

Recovery inputs: retain this entire directory EXCEPT disposable shadow/ and generated driver-copies/ if size requires (both are recreated by check_light.py); retain proofs/reports/staged patch+manifest/normalized fragments. Predecessors required: fort-selective-integration, T-2387-face-layout-next, T-2373-narrow-trial, T-2373-profile-next. Their frozen baselines/candidates/manifests/scripts and source evidence must remain accessible at documented paths. Live runtime runs are not copied here. The latest narrow actual review remains20261023-092203-154696; the new profile run is still unrun.
