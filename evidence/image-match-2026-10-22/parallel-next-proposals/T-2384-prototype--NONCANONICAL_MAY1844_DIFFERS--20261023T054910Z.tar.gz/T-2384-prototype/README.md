# T-2384 isolated May 1844 chapel study

The first source-shaped study was exported and visually compared with the actual engraving. Its verdict is **differs**, with concrete open differences. Nothing has been registered as a canonical asset or camera, and no July 1835 geometry, source, phase, scene, manifest or sidecar was changed by this study.

- Frozen run: `runs/v1/`.
- Comparison: `runs/v1/comparison/study-view-side-by-side.jpg`.
- Actual exported mesh: `runs/v1/st_marys_church__frame_seen_1844.glb`.
- Authored later record: `runs/v1/study-record.json`.
- Camera and review: `runs/v1/study-view.json`, `runs/v1/study-view.match.json`.
- Exact input/output hashes: `runs/v1/st_marys_church__frame_seen_1844.recipe.json` and `.receipt.json`.
- Schema, pure mesh and date-bound checks: `light-checks.json`.
- GLB identity/phase and export verification: `runs/v1/export-verification.json`.

## Historical scope

The phase covers the bounds of **May 1844**, from the month in Quarter's diary, not construction or relocation days. The review date, 15 May, is only a sample inside those bounds. The actual caption of the Moss engraving in Andreas 1884 p. 291 gives no depicted year. Using its detailed form for the May 1844 diary state is a declared appearance reconstruction, not a dated picture identification.

The record has null site coordinates and a symbolic north-Madison location; zero rotation is only a local study frame. It does not carry St Cyr's 1835 occupancy forward, or assert an unknown May use. The dedicated `institutional` builder is registered only in the export process and refuses the original phase. The unchanged canonical record is saved separately as `canonical-original.json` for comparison.

## What was built

A long, low clapboard range, blank near gable, five tall sash and a far-end door on the visible long wall, one far-roof stack, solid belfry skirt, four posts with curved upper braces and crossed lower rails, curved pointed cap, ball, cross, and a small bell. The study has 2,156 triangles. All detailed shape vertices carry reconstructed confidence: the diary dates a small steeple/bell/cross, while the precise drawing-to-1844 shape assignment and metrics remain reconstructed.

The 7.62 × 21.336 m plan is a dimensional prior: original 25 ft width and twice the original 35 ft length, following Thompson's approximate rear-addition statement. The 3.2 m plate, 36° roof, sash sizes/setout, belfry/cap/rail profiles, bell shape, material colours, hidden surfaces and other dimensions are declared reconstructions. The five sash are initially simplified as two-over-two; their pane subdivision is not securely read from the drawing. The source shows a sidewalk and figures, which this first study has not built.

The visible topology now follows the reference, but the camera/massing alignment, taller window proportions, belfry width/setback/detail and surface treatment still differ. The match record retains those open issues. No picture-match acceptance or original ticket closure is claimed.

## Safe execution used

`export_study.py` calls **`emit.emit_structure` directly**, temporarily registering the study builder in its process. It never invokes `build.py`. The first run used the existing pinned Blender 4.5.3 LTS, unwrap enabled and AO disabled. Its receipt hashes the exact custom code, authored record, sources, shared geometry code, parameter values and pin; it does not misuse a canonical archetype input hash for a custom builder.

A tiny `/tmp` review root contains the exported GLB and read-only symlinks to existing reviewer tools/renderers. The existing `photo_match.mjs --glb` renderer ran against that explicit local study mesh, using the already-installed system Chromium. No install was performed. The product manifests, canonical church record and scene files were hash-checked unchanged across export. The GLB extras identify `st_marys_church` and `frame_seen_1844`.

The first browser attempt correctly failed because no Playwright-downloaded Chromium existed; the successful run explicitly selected the already-installed `/usr/bin/chromium`. Blender and the successful browser process have both exited. There are no active study jobs.

This research route cannot fulfill the original ticket's canonical image gate or an in-app later-phase inspection. The pipeline audit at `../offscene-phase-audit/README.md` records that missing capability. Keep this study isolated until an explicit reproducible phase-study route is implemented; do not backdate it into the July scene or write it into canonical manifests.
