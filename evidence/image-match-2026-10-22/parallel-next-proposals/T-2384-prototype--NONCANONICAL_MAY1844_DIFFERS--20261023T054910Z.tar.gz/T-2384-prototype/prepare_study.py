from pathlib import Path
import json,copy,hashlib,shutil
HERE=Path(__file__).resolve().parent;ROOT=Path('/workspace/chicago/chicago/4d')
original=json.loads((ROOT/'data/structures/st_marys_church.json').read_text())
(HERE/'canonical-original.json').write_text(json.dumps(original,indent=2)+'\n')
for p in Path('/tmp/chicago-next-model/T-2384/tree/chicago/4d/data/sources').glob('*.json'):shutil.copyfile(p,HERE/'sources'/p.name)
q='quarter_diary_may_1844_garraghan';pic='andreas_1884_st_marys_engraving';g='garraghan_1921_st_marys_chronology'
def a(value,note,sources=(),confidence='reconstructed'):
 d={'value':value,'confidence':confidence,'note':note}
 if sources:d['sources']=list(sources)
 return d
form={
 'stories':a(1,'Quarter calls the old building long, low and frame; one low occupied level is inferred, with no upper-storey facade drawn.',[q,pic],'inferred'),
 'construction':a('balloon_frame','The identity persists from the 1833 Taylor-built frame church. The exact enlarged framing is not exposed.','andreas_1884_v1'.split(),'inferred'),
 'wall_height_m':a(3.2,'Retains the original model\'s declared dimensional prior; no later plate height is measured.'),
 'roof_type':a('gable','Single ridge and triangular blank near end read from the undated engraving; applied to the May 1844 study by declared appearance reconstruction.',[pic]),
 'roof_pitch_deg':a(36.0,'Initial reconstructed roof angle, to be compared against the drawn silhouette; not a historical measurement.'),
 'siding_exposure_m':a(.114,'Retains the original phase\'s siding stock as a dimensional prior, not a claim that all enlarged fabric came from the same shipment.'),
 'paint':a('unpainted','Initial inference of bare-board continuity from 1833; the monochrome engraving cannot establish paint colour or absence of later paint.',['andreas_1884_v1'],'inferred'),
 'window_centres_m':a([4.0,7.5,11.0,14.5,18.0],'Five sash visible on the left long wall. Count/topology comes from the picture; Distances are measured from the far end toward the near blank gable; exact longitudinal setout is reconstructed on the proposed enlarged range.',[pic]),
 'window_width_m':a(1.05,'Initial reconstructed opening width; no metric scale is printed on the picture.'),
 'window_height_m':a(1.55,'Initial reconstructed tall sash height; every visible sash shows a meeting rail, while pane subdivision is not resolved confidently.'),
 'window_sill_m':a(1.15,'Reconstructed sill height; positions are compared to plate and sill, not claimed measured.'),
 'door_centre_m':a(1.15,'Door close to the far end of the left long wall, as pictured; distance is measured from the far end; exact offset reconstructed.',[pic]),
 'door_width_m':a(.90,'Reconstructed door opening width.'),
 'door_height_m':a(2.03,'Reconstructed door opening height.'),
 'tower':a(True,'Quarter\'s May 1844 diary explicitly gives the old frame church a small steeple, bell and cross; this dates presence, not installation.',[q],'attested'),
 'belfry_width_m':a(2.05,'Reconstructed square belfry width. The open four-post form and rail/braces follow the undated engraving, without dating its exact design.',[pic]),
 'belfry_near_setback_m':a(1.20,'Reconstructed distance from the near gable to belfry centre; no surveyed bearing or position asserted.'),
 'belfry_plinth_above_ridge_m':a(.24,'Reconstructed solid belfry pedestal above ridge. Its skirt intersects the roof to close the visible base.'),
 'belfry_open_height_m':a(1.74,'Initial reconstructed height from plinth to upper rail.'),
 'belfry_cap_height_m':a(1.70,'Curved pointed cap follows the drawing silhouette; profile dimensions are reconstructed.',[pic]),
 'cross_height_m':a(.72,'Cross is attested in May 1844; its exact dimensions/profile are reconstructed.',[q,pic]),
 'chimneys':a(1,'One stack visible near the far roof end. The hidden roof is not documented by this view.',[pic]),
 'chimney_xy_m':a([1.65,3.0],'Reconstructed stack x coordinate and distance from the far end, selected for the pictured silhouette rather than a historical plan.'),
 'chimney_width_m':a(.30,'Reconstructed small stack width.'),
 'chimney_head_above_roof_m':a(.60,'Reconstructed head height above local roof.'),
 'hidden_openings':a('none','The unseen long wall and far gable are deliberately plain reconstructed surfaces in this first study. Their appearance is not documented by the picture.'),
}
phase={'id':'frame_seen_1844','documented_range':{'from':'1844-05-01','to':'1844-05-31','confidence':'inferred','sources':[q],'note':'The diary is headed 1844, May with no day. These are bounds of the attested month, not construction, relocation, alteration or demolition dates. No from_is/to_is event is asserted. The engraving has no depicted year: using its detailed form for this dated study is an appearance reconstruction, not a dated picture identification.'},'position':{'utm_e':None,'utm_n':None,'rotation_deg':0,'symbolic_location':'North side of Madison Street, between Wabash and Michigan avenues; no measured lot or bearing supplied.','confidence':'inferred','sources':[g],'note':'Garraghan p.112 identifies the old frame building here at the June 1844 college opening, while p.106 describes the earlier move to north Madison west of Michigan. May placement continuity is inferred. Zero rotation defines only this isolated mesh\'s local frame and is not a geographical bearing. The camera remains local, with no town or site shown.','derivation':{'method':'not_derivable','reason':'No metric location is claimed in this isolated study.'}},'footprint':{'polygon':[[0,0],[7.62,0],[7.62,21.336],[0,21.336]],'confidence':'reconstructed','sources':['andreas_1884_v1','ichr_v4_thompson_illinois_vincennes'],'note':'Original short dimension 25 ft retained; total long dimension reconstructed as 2 × 35 ft, following Thompson\'s about-the-same-length rear addition as a dimensional prior. Neither total length nor width continuity is measured for the enlarged church. The local short blank gable is at y=0 and the depicted long wall at x=0; no site orientation follows from this convention.'},'form':form}
study={'id':'st_marys_church','name':"St Mary's old frame church — isolated May 1844 study",'aka':original.get('aka',[]),'archetype':'institutional','phases':[phase],'function':a('former church','The old building is distinguished from the new brick church in May 1844; exact current use during May is not established.',[q],'inferred'),'built':copy.deepcopy(original['built']),'occupants':a('Not established for the old frame building in May 1844','Do not carry St Cyr\'s 1835 occupancy into this later phase. Quarter describes the old church; the June 3 college opening is later than the study\'s May bounds.',[q,g]),'research_note':'RESEARCH-ONLY PROTOTYPE; not a canonical structure replacement. Exact May 1844 phase selected explicitly through emit.emit_structure with a process-local institutional builder. No manifest, city scene, canonical source/structure, accepted camera or match closure is written. Quarter supplies the dated belfry/bell/cross state; Andreas\'s undated engraving supplies a reconstructed detailed appearance. Source geometry, dimensions, hidden faces, materials and relationship to May 1844 retain their stated uncertainty. The July 1835 record and asset remain untouched.','review_required':True}
study.pop('function',None) # No closed vocabulary term asserts an unknown May 1844 use.
(HERE/'study-record.json').write_text(json.dumps(study,indent=2)+'\n')
(HERE/'study-inputs.json').write_text(json.dumps({'research_only':True,'review_date':'1844-05-15','review_date_note':'Mid-month review sample chosen only inside the attested May bounds, not a claimed event date.','canonical_record_sha256':hashlib.sha256((ROOT/'data/structures/st_marys_church.json').read_bytes()).hexdigest(),'source_files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (HERE/'sources').glob('*.json')},'limits':'No depicted year asserted for the engraving. No relocation day or metric site placement invented.'},indent=2)+'\n')
print(HERE/'study-record.json')
