"""One research-only direct emit export; no build.py, manifests or scene writes."""
import sys,json,hashlib,dataclasses,datetime,pathlib,argparse
HERE=pathlib.Path(__file__).resolve().parent
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else sys.argv[1:]
ap=argparse.ArgumentParser();ap.add_argument('--out',type=pathlib.Path,required=True);opt=ap.parse_args(args)
ROOT=pathlib.Path('/workspace/chicago/chicago/4d');out=opt.out.resolve()
if out.is_relative_to(ROOT) or out.suffix!='.glb' or out.exists():raise ValueError('require a fresh GLB outside the product checkout')
raw=(HERE/'study-record.json').read_bytes();record=json.loads(raw)
import importlib.util
spec=importlib.util.spec_from_file_location('phase_audit','/tmp/chicago-next-model/offscene-phase-audit/render_phase_study.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
phase=audit.exact_phase(record,'frame_seen_1844','1844-05-15')
sys.path[:0]=[str(HERE),str(ROOT/'generators')]
import chapel_params,chapel_geometry,emit,code_inputs
params=chapel_params.from_phase(phase,record)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protected=[ROOT/'assets/manifest.json',ROOT/'data/structures/st_marys_church.json',*sorted((ROOT/'assets').glob('*manifest*.json')),*sorted((ROOT/'data/scenes').glob('*.json'))]
before={str(p):sha(p) for p in protected if p.exists()}
recipe={'research_only':True,'canonical_input_scheme':False,'review_date':'1844-05-15','record_sha256':hashlib.sha256(raw).hexdigest(),'params':dataclasses.asdict(params),'source_files':{p.name:sha(p) for p in sorted((HERE/'sources').glob('*.json'))},'study_code':{p.name:sha(p) for p in (HERE/'chapel_params.py',HERE/'chapel_geometry.py',HERE/'export_study.py')},'shared_code':{str(p.relative_to(ROOT)):sha(p) for p in [ROOT/'generators/emit.py',*code_inputs.geometry_modules()]},'blender_pin':(ROOT/'generators/blender.pin').read_text().strip()}
# Only this process's registry receives the isolated study builder. Its input
# receipt is the explicit custom recipe above, not a canonical institutional hash.
old=emit.ARCHETYPES.get('institutional');emit.ARCHETYPES['institutional']=(chapel_params.from_phase,chapel_geometry.build)
try:
 out.parent.mkdir(parents=True,exist_ok=True)
 made=emit.emit_structure(record,phase,'institutional',out,bake=True,ao=False)
finally:
 if old is None:emit.ARCHETYPES.pop('institutional',None)
 else:emit.ARCHETYPES['institutional']=old
assert before=={str(p):sha(p) for p in protected if p.exists()},'protected product metadata changed during export'
receipt={'research_only':True,'structure_id':record['id'],'phase_id':phase['id'],'review_date':'1844-05-15','review_date_note':'A sample within May, not a source-attested day or event.','documented_range':phase['documented_range'],'record':str(HERE/'study-record.json'),'glb':str(made.path),'glb_sha256':sha(made.path),'research_inputs_sha256':hashlib.sha256(json.dumps(recipe,sort_keys=True).encode()).hexdigest(),'triangles':made.tris,'canonical_metadata_unchanged':True,'limits':'Undated Andreas engraving applied as reconstructed appearance to Quarter\'s dated May 1844 description. No site coordinates, new town scene, canonical asset or accepted match.'}
out.with_suffix('.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');out.with_suffix('.recipe.json').write_text(json.dumps(recipe,indent=2)+'\n');print(json.dumps(receipt,indent=2))
