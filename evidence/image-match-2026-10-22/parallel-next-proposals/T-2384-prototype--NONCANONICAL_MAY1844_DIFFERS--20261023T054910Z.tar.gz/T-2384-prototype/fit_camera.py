"""Light numerical seed for an undated drawing; no render or solved-view claim."""
from pathlib import Path
import json,math
import numpy as np
from scipy.optimize import least_squares
from chapel_params import from_phase
HERE=Path(__file__).resolve().parent
r=json.loads((HERE/'study-record.json').read_text());p=from_phase(r['phases'][0],r)
# Hand-read points in the displayed 1456x1696 reproduction; mapped back to the
# held2671x3110px image. +/-6displaypx reading uncertainty is not a survey.
labels=['near_left_sill','near_right_sill','far_left_sill','near_left_eave','near_right_eave','far_left_eave','near_gable_apex']
image=np.array([[578,1273],[1302,1240],[94,1188],[578,835],[1302,883],[94,945],[970,617]],dtype=float)*[2671/1456,3110/1696]
world=np.array([[0,0,0],[p.width,0,0],[0,p.length,0],[0,0,p.height],[p.width,0,p.height],[0,p.length,p.height],[p.width/2,0,p.ridge]])
def projection(q,xyz):
 ex,ey,ez,yaw,f,cx,cy=q;t=math.radians(yaw);delta=xyz-[ex,ey,ez]
 forward=delta[:,0]*math.sin(t)+delta[:,1]*math.cos(t)
 right=delta[:,0]*math.cos(t)-delta[:,1]*math.sin(t)
 return np.stack([cx+f*right/forward,cy-f*delta[:,2]/forward],axis=1)
def residual(q):return (projection(q,world)-image).ravel()
best=None
for ex in (-5,-15,-30):
 q=least_squares(residual,[ex,-20,2,25,3800,1335,1900],bounds=([-200,-300,.1,1,300,-10000,-10000],[-.1,-.5,20,89,40000,10000,10000]),max_nfev=500)
 if best is None or np.linalg.norm(q.fun)<np.linalg.norm(best.fun):best=q
q=best.x;pred=projection(q,world);errors=np.linalg.norm(pred-image,axis=1)
cam={'structure_id':'st_marys_church','source_id':'andreas_1884_st_marys_engraving','photo':'/workspace/chicago/chicago/reference/images/chicago/chicago_st_marys_church_1843.jpg','image_px':[2671,3110],'principal_px':[float(q[5]),float(q[6])],'focal_px':float(q[4]),'eye':[float(q[0]),float(q[1]),float(q[2])],'yaw_deg':float(q[3]),'sky':'overcast','solve':'RESEARCH-ONLY seed, not an accepted camera. Least-squares yaw-only perspective fit to seven manually read massing landmarks, using declared reconstructed7.62x21.336m footprint,3.2m plate and36deg roof. These metrics and the engraving-to-May1844 appearance assignment are reconstructed. No depicted year or metric site coordinate is inferred. Approximate reading uncertainty +/-11sourcepx; mean fitted landmark residual %.1fpx, max %.1fpx. Drawing verticals and edges are not perfectly projective. No rendered review has occurred. Neutral overcast lighting chosen because the engraving uses tonal hatching without a consistently measurable cast-shadow system.'%(errors.mean(),errors.max())}
(HERE/'camera-seed.json').write_text(json.dumps(cam,indent=2)+'\n')
(HERE/'camera-landmarks.json').write_text(json.dumps({'research_only':True,'fit_parameters':q.tolist(),'mean_residual_px':float(errors.mean()),'max_residual_px':float(errors.max()),'points':[{'name':name,'local_xyz':xyz.tolist(),'image_px':px.tolist(),'fitted_px':pr.tolist(),'error_px':float(err)} for name,xyz,px,pr,err in zip(labels,world,image,pred,errors)],'limits':'Drawing, reconstructed dimensions and hand readings; not a historical metric/camera attestation.'},indent=2)+'\n')
print('camera seed',q.tolist(),'mean/max residual',errors.mean(),errors.max())
