import sys,json,types,math,hashlib,dataclasses,copy
from pathlib import Path
import jsonschema
HERE=Path(__file__).resolve().parent;ROOT=Path('/workspace/chicago/chicago/4d')
sys.path[:0]=[str(HERE),str(ROOT/'generators')]
import chapel_params
record=json.loads((HERE/'study-record.json').read_text());phase=record['phases'][0]
jsonschema.Draft202012Validator(json.loads((ROOT/'data/structures.schema.json').read_text())).validate(record)
p=chapel_params.from_phase(phase,record);p.validate()
# No Blender API is used while accumulating the mesh; an import stub lets the
# exact shared accumulator/openings code run as a pure vertex exercise.
sys.modules['bpy']=types.ModuleType('bpy')
import chapel_geometry
b=chapel_geometry.build_geometry(p,'st_marys_church__frame_seen_1844')
assert b.verts and b.faces and len(b.faces)==len(b.mat_index)
assert all(len(f)>=3 and all(0<=v<len(b.verts) for v in f) for f in b.faces)
assert all(all(math.isfinite(t) for t in v) for v in b.verts)
assert all(c==1 for c in b.conf)
assert all(mi in range(6) or mi>=1000 for mi in b.mat_index)
# Near gable is blank; the profile only asks openings kit on the x=0 long wall.
assert len(p.window_centres)==5
for key,value in [('window_height',4),('door_centre',.05),('tower_setback',.1),('window_centres',(4,7,11,14,40))]:
 try:dataclasses.replace(p,**{key:value}).validate()
 except ValueError:pass
 else:raise AssertionError('unsupported '+key)
try:chapel_params.from_phase({'id':'frame_1833'},record)
except ValueError:pass
else:raise AssertionError('study must refuse original phase')
orig=(ROOT/'data/structures/st_marys_church.json').read_bytes();receipt=json.loads((HERE/'study-inputs.json').read_text());assert hashlib.sha256(orig).hexdigest()==receipt['canonical_record_sha256']
assert json.loads(orig)==json.loads((HERE/'canonical-original.json').read_text())
for source in (HERE/'sources').glob('*.json'):jsonschema.Draft202012Validator(json.loads((ROOT/'data/source.schema.json').read_text())).validate(json.loads(source.read_text()))
# The exact authored phase/date wrapper remains pure before importing Blender.
import importlib.util
spec=importlib.util.spec_from_file_location('phase_audit','/tmp/chicago-next-model/offscene-phase-audit/render_phase_study.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert m.exact_phase(record,'frame_seen_1844','1844-05-15') is phase
for bad in ('1835-07-01','1844-06-03'):
 try:m.exact_phase(record,'frame_seen_1844',bad)
 except ValueError:pass
 else:raise AssertionError('out-of-range review date')
report={'research_only':True,'schema':'pass','pure_params':'pass','shared_accumulator_geometry':'pass','vertices':len(b.verts),'faces':len(b.faces),'triangles':sum(len(f)-2 for f in b.faces),'bounds':[[min(v[i] for v in b.verts),max(v[i] for v in b.verts)] for i in range(3)],'unsupported_combinations':'refused','original_phase':'refused by study builder','review_date_bounds':'pass','canonical_record_unchanged':'pass','blender_or_browser_run':False}
(HERE/'light-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
