"""Pure parameters for one explicitly isolated May 1844 research study."""
from dataclasses import dataclass
import math
@dataclass(frozen=True)
class Params:
 width:float;length:float;height:float;pitch:float;course:float
 window_centres:tuple;window_width:float;window_height:float;window_sill:float
 door_centre:float;door_width:float;door_height:float
 tower_width:float;tower_setback:float;plinth_rise:float;open_height:float;cap_height:float;cross_height:float
 chimney_xy:tuple;chimney_width:float;chimney_head:float
 def validate(self):
  numbers=[self.width,self.length,self.height,self.pitch,self.course,self.window_width,self.window_height,self.window_sill,self.door_centre,self.door_width,self.door_height,self.tower_width,self.tower_setback,self.plinth_rise,self.open_height,self.cap_height,self.cross_height,self.chimney_width,self.chimney_head,*self.window_centres,*self.chimney_xy]
  if not all(isinstance(v,(float,int)) and math.isfinite(v) and v>0 for v in numbers):raise ValueError('all study dimensions must be finite and positive')
  if not 15<=self.pitch<=55:raise ValueError('unsupported roof pitch')
  if not self.length>self.width>=2:raise ValueError('study needs a long rectangular range')
  if not 0<self.window_sill<self.window_sill+self.window_height<self.height:raise ValueError('sash exceeds wall')
  if self.door_height>=self.height:raise ValueError('door exceeds plate')
  spans=[(self.door_centre-self.door_width/2,self.door_centre+self.door_width/2)]+[(v-self.window_width/2,v+self.window_width/2) for v in self.window_centres]
  if len(self.window_centres)!=5 or tuple(sorted(self.window_centres))!=self.window_centres:raise ValueError('this picture study requires five ordered sash')
  if any(a<=0 or b>=self.length for a,b in spans) or any(b+.15>c for (_,b),(c,_) in zip(sorted(spans),sorted(spans)[1:])):raise ValueError('openings overlap or leave the wall')
  if self.tower_width>=self.width or not self.tower_width/2<self.length-self.tower_setback<self.length-self.tower_width/2:raise ValueError('belfry outside roof')
  if not 0<self.chimney_xy[0]<self.width or not 0<self.chimney_xy[1]<self.length:raise ValueError('stack outside roof')
 @property
 def ridge(self):return self.height+self.width/2*math.tan(math.radians(self.pitch))
def from_phase(phase,record=None):
 if phase.get('id')!='frame_seen_1844':raise ValueError('study builder refuses any phase except authored May 1844 phase')
 f=phase['form'];v=lambda key:f[key]['value'];poly=phase['footprint']['polygon']
 if poly!=[[0,0],[poly[1][0],0],[poly[1][0],poly[2][1]],[0,poly[2][1]]]:raise ValueError('study footprint must be origin-based rectangle')
 if v('stories')!=1 or v('roof_type')!='gable' or not v('tower') or v('chimneys')!=1:raise ValueError('unsupported study topology')
 p=Params(poly[1][0],poly[2][1],v('wall_height_m'),v('roof_pitch_deg'),v('siding_exposure_m'),tuple(v('window_centres_m')),v('window_width_m'),v('window_height_m'),v('window_sill_m'),v('door_centre_m'),v('door_width_m'),v('door_height_m'),v('belfry_width_m'),v('belfry_near_setback_m'),v('belfry_plinth_above_ridge_m'),v('belfry_open_height_m'),v('belfry_cap_height_m'),v('cross_height_m'),tuple(v('chimney_xy_m')),v('chimney_width_m'),v('chimney_head_above_roof_m'))
 p.validate();return p
