"""Guarded final optional roof tone overlay after the reviewed baked-name overlay."""
from pathlib import Path
import argparse,json,hashlib,copy,os
H=Path(__file__).resolve().parent;CODE=['generators/archetypes/frame_tavern.py','generators/archetypes/frame_tavern_params.py','tools/test_frame_tavern_picture_features.py'];sha=lambda b:hashlib.sha256(b).hexdigest()
def atomic(p,data):
 p.parent.mkdir(parents=True,exist_ok=True);t=p.with_name('.'+p.name+'.roof-tone.tmp');t.write_bytes(data);os.replace(t,p)
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--apply',action='store_true');a=ap.parse_args();app=a.repo.resolve()/'chicago/4d';O=H/'post-apply-review';O.mkdir(exist_ok=True)
 if a.apply:
  plan=json.loads((H/'adoption-plan.json').read_text());assert plan['repo']==str(a.repo.resolve());view=json.loads((H/'actual-view-review.json').read_text());assert view['actual_side_by_sides_viewed'] and view['closer_without_new_regression'] and view['verdict']=='differs';assert view['export_receipt_sha256']==sha((H/'actual-export-receipt.json').read_bytes());assert view['reviewed_generator_sha256']==plan['payload_sha256'][CODE[0]]
  proof=json.loads((H/'compatibility-proof.json').read_text());assert proof['phase_count']==24 and len(proof['all_40_positional_parameters_defaults_order_preserved'])==40 and proof['reviewed_glyph_colour_absent_output_exact']
  for rel in CODE:
   assert sha((H/'fixture'/rel).read_bytes())==plan['payload_sha256'][rel]
   if '/archetypes/' in rel:assert proof['new_source_code_sha256'][Path(rel).name]==plan['payload_sha256'][rel]
  for f in plan['files']:assert sha((app/f['path']).read_bytes())==f['old_sha256'],f['path'];assert sha((O/f['path']).read_bytes())==f['new_sha256'],f['path']
  written=[]
  try:
   for f in plan['files']:
    p=app/f['path'];atomic(H/'apply-backup'/f['path'],p.read_bytes());atomic(p,(O/f['path']).read_bytes());written.append(f)
  except BaseException:
   for f in reversed(written):atomic(app/f['path'],(H/'apply-backup'/f['path']).read_bytes())
   raise
  (H/'apply-receipt.json').write_text(json.dumps({'applied':True,'plan':plan,'canonical_assets_copied':False},indent=2)+'\n');print('APPLIED final bounded tone overlay; real23bake/compile/app QA required');return
 result={};payload={}
 for rel in CODE:
  assert (app/rel).read_bytes()==(H/'baseline'/rel).read_bytes(),rel+': post-glyph source drift';result[rel]=(H/'fixture'/rel).read_bytes();payload[rel]=sha(result[rel])
 rel='data/structures/tremont_house_1.json';r=json.loads((app/rel).read_text());old=copy.deepcopy(r);ph=next(p for p in r['phases'] if p['id']=='frame_1833');f=ph['form'];assert f['gable_arch_text']['value']=='TREMONT' and f['gable_arch_text']['confidence']=='reconstructed';assert 'roof_colour' not in f;assert 'reconstruction' not in r
 proposed=json.loads((H/'fixture'/rel).read_text());f['roof_colour']=copy.deepcopy(proposed['phases'][0]['form']['roof_colour']);r['research_note']='CURRENT RECONSTRUCTED ROOF TONE: the named hotel now chooses the existing dark-brown stock colour as an appearance proxy to the dark roof/light walls in the monochrome Gifford view. Brown pigment, actual weather-blackening, age and damage are not attested. All affected roof material vertices retain reconstructed confidence. Roof geometry, flag, dates and geography are unchanged; comparisons remain differs.\n\n'+r['research_note'];restored=copy.deepcopy(r);restored['phases'][0]['form'].pop('roof_colour');restored['research_note']=old['research_note'];assert restored==old;result[rel]=(json.dumps(r,indent=2,ensure_ascii=False)+'\n').encode()
 rel='docs/LIBERTIES.md';ledger=(app/rel).read_bytes();fragment=(H/'liberty.md').read_bytes();assert b'### L-tremont-reconstructed-dark-roof-2385' not in ledger;result[rel]=ledger+b'\n\n'+fragment
 files=[]
 for rel,data in result.items():atomic(O/rel,data);files.append({'path':rel,'old_sha256':sha((app/rel).read_bytes()),'new_sha256':sha(data),'bytes':len(data)})
 (H/'adoption-plan.json').write_text(json.dumps({'repo':str(a.repo.resolve()),'files':files,'payload_sha256':payload,'new_parameter_fields':[],'new_cover':'tremont_house_1.frame_1833.form.roof_colour','canonical_assets_copied':False,'real23family_bake_required':True},indent=2)+'\n');print('REVIEW ONLY5files; actual viewed preview required before --apply')
if __name__=='__main__':main()
