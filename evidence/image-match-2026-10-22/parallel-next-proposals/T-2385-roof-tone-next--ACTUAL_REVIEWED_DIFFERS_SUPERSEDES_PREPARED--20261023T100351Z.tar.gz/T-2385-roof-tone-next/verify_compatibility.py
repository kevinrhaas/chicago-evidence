"""Actual pure mesh accumulator proof for the existing roof_colour enum extension."""
import sys,types,json,inspect,dataclasses,importlib.util,hashlib
from pathlib import Path
sys.dont_write_bytecode=True;sys.modules.setdefault('bpy',types.ModuleType('bpy'))
H=Path(__file__).resolve().parent;F=H/'fixture';R=Path('/workspace/chicago/chicago/4d');BASE=Path('/tmp/chicago-next-model/T-3055-selective-integration/review-tree/chicago/4d');sys.path[:0]=[str(F/'generators'),str(R/'generators')]
from archetypes import frame_tavern as new
from archetypes import frame_tavern_params as newparams
from common.mesh import MeshBuilder
MeshBuilder.to_object=lambda self,mats=None:(self,list(mats or []))
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
old=load('archetypes.frame_tavern_before_dark_stock',H/'baseline/generators/archetypes/frame_tavern.py');oldparams=load('archetypes.frame_tavern_params_before_dark_stock',H/'baseline/generators/archetypes/frame_tavern_params.py')
for m in [old,new]:m.simple_material=lambda n,*a,**kw:(n,a,kw)
def sig(r):
 b,m=r;return b.verts,b.faces,b.conf,b.mat_index,b.named,m
assert inspect.signature(oldparams.FrameTavernParams)==inspect.signature(newparams.FrameTavernParams)
assert oldparams.FrameTavernParams.__match_args__==newparams.FrameTavernParams.__match_args__;assert len(newparams.FrameTavernParams.__match_args__)==40
phases=[]
for p in sorted((R/'data/structures').glob('*.json')):
 rec=json.loads(p.read_text())
 if rec.get('archetype')!='frame_tavern':continue
 if (BASE/'data/structures'/p.name).exists():rec=json.loads((BASE/'data/structures'/p.name).read_text())
 for ph in rec['phases']:
  a=oldparams.from_phase(ph,rec);b=newparams.from_phase(ph,rec);assert dataclasses.asdict(a)==dataclasses.asdict(b)
  name=rec['id']+'__'+ph['id'];assert sig(old.build(a,name))==sig(new.build(b,name)),name;phases.append(name)
# The newly reviewed glyph opt-in also retains exact geometry/material/confidence
# when the proposed dark roof colour is absent.
r=json.loads((H/'baseline/data/structures/tremont_house_1.json').read_text());ph=r['phases'][0];assert sig(old.build(oldparams.from_phase(ph,r),'glyph'))==sig(new.build(newparams.from_phase(ph,r),'glyph'))
report={'old24record_phase_defaults_geometry_material_confidence_exact':phases,'phase_count':len(phases),'all_40_positional_parameters_defaults_order_preserved':list(newparams.FrameTavernParams.__match_args__),'all_existing_keywordonly_fields_preserved':True,'new_parameter_fields':[],'reviewed_glyph_colour_absent_output_exact':True,'new_source_code_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (F/'generators/archetypes').glob('*.py')},'canonical_writes':False,'actual_blender_browser':'UNRUN','official_recipe_action':'Real23familybake stillrequired; no restamp.'}
(H/'compatibility-proof.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS all24oldphase geometries/material/confidence +reviewedglyphdefault EXACT; all40positional and every existingkeyword/API unchanged')
