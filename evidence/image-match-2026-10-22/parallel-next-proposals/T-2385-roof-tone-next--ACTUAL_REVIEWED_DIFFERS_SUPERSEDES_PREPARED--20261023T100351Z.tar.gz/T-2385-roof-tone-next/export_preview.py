"""Pinned isolated emit_structure exports only; no build.py/manifests/canonical writes."""
from pathlib import Path
import json,sys,hashlib,math
import bpy
assert bpy.app.version[:3]==(4,5,3),bpy.app.version_string
H=Path(__file__).resolve().parent;R=Path('/workspace/chicago/chicago/4d');F=H/'fixture'
sys.path[:0]=[str(F/'generators'),str(R/'generators')]
import archetypes
archetypes.__path__.append(str(R/'generators/archetypes'))
from archetypes import frame_tavern as builder
from archetypes import frame_tavern_params as params
from common.mesh import reset_scene
import emit
assert Path(builder.__file__).resolve()==F/'generators/archetypes/frame_tavern.py'
assert emit.ARCHETYPES['frame_tavern']==(params.from_phase,builder.build)
receipt={'blender_version':bpy.app.version_string,'canonical_manifests_written':False,'actual_canonical_seed':True,'models':{}}
for label,outlabel in [('baseline','before'),('proposed','after')]:
 rec=json.loads(((H/'baseline/data/structures/tremont_house_1.json') if label=='baseline' else (F/'data/structures/tremont_house_1.json')).read_text());phase=rec['phases'][0];name=rec['id']+'__'+phase['id']
 reset_scene();out=F/f'assets/gltf/{outlabel}/{name}.glb';out.parent.mkdir(parents=True,exist_ok=True)
 result=emit.emit_structure(rec,phase,'frame_tavern',out,bake=True,ao=False)
 ob=bpy.data.objects[name];me=ob.data;assert all(math.isfinite(v) for p in me.vertices for v in p.co)
 conf=[v.value for v in me.attributes['_CONFIDENCE'].data];assert all(0<=v<=1 for v in conf)
 receipt['models'][label]={'glb':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'tris':result.tris,'bounds_xyz':[[min(v.co[i] for v in me.vertices) for i in range(3)],[max(v.co[i] for v in me.vertices) for i in range(3)]],'confidence_range':[min(conf),max(conf)]}
# The colour-absent new-code export must reproduce the already reviewed glyph
# bytes. Compare actual exported binary buffers to prove no hidden mesh change.
assert receipt['models']['baseline']['sha256']=='f01158ab86617239b297e3e35fd2ae9b40011130e95c4667b02afe6bfb616908',receipt['models']['baseline']
import struct
binary=[]
for label in ['baseline','proposed']:
 data=Path(receipt['models'][label]['glb']).read_bytes();offset=12;chunks={}
 while offset<len(data):
  length,kind=struct.unpack_from('<II',data,offset);chunks[kind]=data[offset+8:offset+8+length];offset+=8+length
 binary.append(chunks[0x004E4942])
assert binary[0]==binary[1],'actual GLB binary mesh buffers changed'
receipt['reviewed_glyph_baseline_sha256_exact']=True
receipt['actual_glb_binary_mesh_buffers_exact']=True
(H/'actual-export-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('ISOLATED TREMONT ROOF-TONE EXPORTS COMPLETE; no official freshness or image-match claim')
