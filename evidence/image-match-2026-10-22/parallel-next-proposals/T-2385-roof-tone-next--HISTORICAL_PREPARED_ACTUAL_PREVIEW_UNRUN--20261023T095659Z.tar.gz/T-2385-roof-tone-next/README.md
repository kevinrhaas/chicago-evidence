# First Tremont reconstructed roof-tone experiment — actual preview UNRUN

The Gifford image shows a dark roof against light walls, while the currently reviewed model roof is light tan. The source is monochrome, so it cannot establish brown pigment or actual weather-blackening. This isolated bounded experiment adds one reconstructed `dark_brown` choice to the EXISTING `roof_colour` form enum and reuses exactly `materials.roof_finish("darkened").rgba` (#4B4037 through the existing material-sheet conversion). It adds no palette, parameter field, common helper, runtime mechanism or infill metadata. Root `reconstruction` metadata was explicitly rejected because the schema reserves it for infill and consumers could retire the named building as anonymous stock.

All affected roof-material face vertices take the colour's reconstructed confidence, including appendages. The opt-in refuses attested/inferred grades. No legacy colour takes this new confidence path; all24 existing record-phase mesh/material/confidence outputs are exact, including moss_green, and the previously viewed baked-letter model is exact with dark_brown absent. All40 positional/API/defaults and every existing keyword-only field remain exact. `compatibility-proof.json` records the actual accumulator proof. `durable-tests.log`: all15 tests PASS, preserving14 previous tests and adding meaningful material-only geometry preservation, actual roof-confidence downgrade, non-roof preservation and invalid-claim/enum coverage.

`light-check.json` records actual structure-schema and full-liberty-ledger parse PASS; the existing `phases[].form.roof_colour.note` pool read is already declared. The actual raw/parsed name-pool CLI self-test on the fully staged layered copy also passed with0failures (`layered-namepool-self-test.log/json`). That is staged source/data validation, not an actual adopted or baked model result. No canonical writes occurred.

## Actual preview, only after parent grants heavy slot

```sh
bash /tmp/chicago-next-model/T-2385-roof-tone-next/run_preview.sh
```

Prepared runner: two pinned4.5.3 real `emit_structure` exports using the new code, with and without the colour; baseline must reproduce the viewed445040byte/5552triangle baked-letter GLB exactly. Then two actual same-source/camera/light browser comparisons. This isolates only material tone; shape, covering, glyphs, stacks, flag, geography and dates stay fixed. Current status is **actual Blender/browser UNRUN**. The apply tool requires an actual viewed `differs` progress receipt with matching reviewed generator/export hashes, so this package cannot currently be adopted.

## Guarded adoption, only if actual review approves

After sourceS, frozen final frame helper, note correction, Gale hotel sources, Sauganash roof, THEN baked Tremont glyph, run:

```sh
python /tmp/chicago-next-model/T-2385-roof-tone-next/adopt.py --repo /workspace/chicago
# Inspect adoption-plan.json and post-apply-review after an approved actual preview.
python /tmp/chicago-next-model/T-2385-roof-tone-next/adopt.py --repo /workspace/chicago --apply
```

Exactly5files: existing frame builder, params, durable test, firstTremontrecord and append-only liberty. Baseline guards require the exact reviewed glyph overlay bytes; source/export/default/API/current-file hashes are checked before apply. Current default plan points at the isolated layered-namepool copy for light review, not canonical. ALWAYS replan against canonical after prior overlays. No canonical GLBs/manifests/sidecars are copied. The real all23frame bake, compilation, published grouped QA and required gates remain owed; no restamping or accepted picture match is claimed.

If adopted, use THIS package's `composed-qa/promote.py --repo /workspace/chicago` default review then `--apply`, instead of the earlier glyph-only promotion. It includes all12cases/twoviewports/oracles plus reconstructed roof_colour, roof25.2/attic and known-name value/visible grade checks. Candidate syntax PASS; browser UNRUN. `T-3055.six-items.with-roof-name-tone.json` is a six-item candidate including the roof tone and name as reconstructed progress. All original picture-match tickets remain open.
