### L-tremont-reconstructed-dark-roof-2385 — A dark stock tone for the first Tremont’s pictured roof

**Covers:** `tremont_house_1.frame_1833.form.roof_colour`.

**Decision:** Consciously choose `dark_brown` as a reconstructed material-tone proxy to the dark roof against light walls in the monochrome Gifford view, preserving the pictured contrast while leaving actual pigment and weathering unknown. This reuses exactly `materials.roof_finish("darkened").rgba` from the existing material sheet; the material's stock name is not a claim that this hotel was weather-blackened. No new palette, infill reconstruction block, roof covering, source pixels or physical weather/fire/age history is asserted. The Gifford source remains owner-approved attributed project reference use with its existing rights limits.

The existing optional `roof_colour` enum receives this one consciously reconstructed choice. Its confidence must be reconstructed; every face using the roof material carries the colour's uncertainty. All24 legacy record-phase mesh/material/confidence outputs and all40 positional parameters/defaults/order remain exact, including the existing moss_green path. The previously reviewed baked-name model is also exact when the new colour is absent. Roof vertices, faces, dimensions, silhouette, openings, glyphs, stacks, flag, geography and phase dates remain unchanged. Roof colour from a black-and-white illustration remains an appearance decision, not a source-attested brown pigment or a complete picture match. Parent requires an actual viewed before/after preview before adoption; no execution or acceptance is claimed by this prepared fragment.

**Ticket:** T-2385 (shared controls T-3055).
**Recorded:** 2026-10-23.
