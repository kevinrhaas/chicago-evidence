import json,pathlib,hashlib
OUT=pathlib.Path(__file__).parent/'preview-root'
reviews={
 'tremont':[
  ('Three complete storeys and visible three-bay short gable/five-bay long elevation now follow the drawing; exact sizes and stations remain reconstructed.','fixed'),
  ('The previously blank gable now carries windows and a shallow arched dark feature; its formerly missing occurrence is built. Fine glazing/radial bars versus lettering/sign interpretation remains unresolved.','fixed'),
  ('Raised entries, platforms, steps/side guards, roof spar and four offset capped stack silhouettes now render where the first preview had none or only two simple ridge stacks. Occurrence is improved; exact shape and metric controls remain reconstructed.','fixed'),
  ('Near roof apex now projects near source y277 after the working32-degree change, improving the first preview ridge near y260. This is an appearance fit under a provisional envelope camera, not a historical pitch calibration.','fixed'),
  ('Flag cloth is still absent; the roof spar is bare. Existing app flag layer needs an explicit roof-staff anchor rather than the whole hotel bounds.','open'),
  ('The shallow arch is represented as a plain glazed fanlight with radial bars, while the source fine dark/lettered treatment is unresolved. Its exact outline, rim and interpretation must be reviewed further.','open'),
  ('Landing/step/guard layout and opening vertical stations/proportions are approximations. The source gable platform and long entrance/boardwalk relationships are not yet reproduced in detail.','open'),
  ('Stack shaft/cap proportions, precise roof junctions, eaves, sash divisions, shutter angles/joinery and material/tonal treatment still require comparison/refinement.','open'),
  ('Camera remains a provisional six-wall-corner fit to reconstructed15.24x9.14x7.8m envelope (3.546px point RMS,6.866max); source feature dating within1833-1839 and all other ticket views remain unresolved.','open'),
  ('Source street neighbours/walk/road/people are omitted from this single-mesh preview; they are context work, not missing geometry to fold into the hotel mesh.','open'),
  ('Monochrome source cannot establish original paint/shutter colours or concealed elevations. Four model entries and repeated hidden treatment remain declared reconstruction.','not shown')],
 'green-tree':[
  ('Pictured long/south elevation now renders seven upper sash, replacing its former six-bay default; opposite north stays six and both gables retain their previous treatment.','fixed'),
  ('Exact sash width/height, vertical bands and equal station spacing remain reconstructed; visible openings and facade proportions are not a detailed match.','open'),
  ('The model keeps a centred gable entry, while this Andreas view places the pictured entry differently. Gable ground/upper arrangement and attic-light depiction remain unresolved across the ticket pictures.','open'),
  ('Text-attested side entry remains at the middle ground-floor bay. This review does not reconcile its appearance with the drawing lower sash/entry arrangement.','open'),
  ('Source composition shows low buildings to the left; the current main mesh extension projects to the right. Identity, connection, wing massing and context must be resolved without moving geographic controls to fit a drawing.','open'),
  ('Roof shape/stacks, siding/trim, sign and street context/figures differ or are omitted by this bare-building review.','open'),
  ('Camera is an unsolved drawing fit: principal x=-3472.8px outside the source,6.11px coordinate RMS,12.65max point residual; two withheld roof picks disagree. No physical or geographic camera is accepted.','open'),
  ('Retrospective source form is not a dated1835 survey. Colours and hidden treatment cannot be established by this monochrome picture.','not shown')],
 'sauganash':[
  ('Previously blank pictured main +x gable now has two upper sash and one upright attic sash. The attic sash renders outside the overhanging gable plane instead of disappearing behind it.','fixed'),
  ('Exact sash widths/heights/stations and pane divisions remain reconstructed; count/occurrence improvement is not detailed alignment or full-image acceptance.','open'),
  ('Roof/main-gable silhouette is substantially too high in this framing: withheld near apex projects about(636,231) against approximate source(648,350). Current38-degree roof, envelope/cross-wing and camera need further work.','open'),
  ('The current cross-wing roof/massing at the left differs substantially from the source composition; this proposal deliberately leaves those existing forms unchanged.','open'),
  ('This preview contains the main hotel GLB only. The separately modelled log annex that occupies the source foreground is omitted context, not historically absent or unbuilt in the app. Full grouped comparison remains required.','open'),
  ('Main-front window/door proportions, surround, stack profiles, siding/roof treatment and detail still differ from the source. Blue shutters rest on separate written/coloured evidence and must be reconciled with derivative depictions rather than silently removed.','open'),
  ('Five-corner camera remains provisional (16.28px point RMS,30.15max), principal x about4129px outside image. Grade picks beside figures/walk are approximate and the obscured far lower end corner was excluded.','open'),
  ('Source street, people and ground are omitted from this bare review. All three local source pictures/date limits still require review before closing the ticket.','open'),
  ('Monochrome engraving cannot establish original wall/shutter/roof colours or hidden elevations. Existing separate evidence/provenance remains controlling for those choices.','not shown')]
}
for target,diffs in reviews.items():
 folder=OUT/'review'/target;p=next(folder.glob('*.match.json'));m=json.loads(p.read_text());m['verdict']='differs';m['differences']=[{'what':what,'status':status} for what,status in diffs];p.write_text(json.dumps(m,indent=2)+'\n')
 (folder/'observations.md').write_text('# '+target+' — actual proposal comparison\n\nReviewed the saved actual side-by-side and proposal render. Verdict: **differs**; prototype camera/mesh only, no original ticket closure.\n\n'+'\n'.join('- **'+status+'**: '+what for what,status in diffs)+'\n')
report=json.loads((OUT/'blender-previews-report.json').read_text());receipts=json.loads((OUT/'photo-match-receipts.json').read_text());assert len(receipts)==3 and all(x['exit_code']==0 for x in receipts)
report['actual_comparisons']={target:{'verdict':'differs','actual_side_by_side_inspected':True,'actual_mesh_broad_treatment_inspected':True,'files_sha256':{str(f.relative_to(OUT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in (OUT/'review'/target).iterdir() if f.is_file()}} for target in reviews};report['all_cpu_browser_work_finished']=True;report['original_tickets_closed']=False
(OUT/'reviewed-preview-receipt.json').write_text(json.dumps(report,indent=2)+'\n')
p=OUT.parent/'checkpoint.json';r=json.loads(p.read_text());r['state']='Isolated pinned4.5.3 exports and all3 actual comparisons complete; actual default Blender geometry/material/confidence unchanged for each target; all review verdicts differ; no official repository build/manifests or match acceptance';r['pending']=['Official family build/manifests/derivatives/licence provenance/grade/source sidecars','App/mobile credited-card checks','Remaining image differences and camera acceptance','Required full gates and PR/merge'];r['actual_preview_receipt']='preview-root/reviewed-preview-receipt.json';r['all_cpu_browser_work_finished']=True;r['released_to_second_fort_1835']=True;p.write_text(json.dumps(r,indent=2)+'\n')
print('Reviewed all3 actual comparisons as differs; all CPU/browser work closed; checkpoint updated')
