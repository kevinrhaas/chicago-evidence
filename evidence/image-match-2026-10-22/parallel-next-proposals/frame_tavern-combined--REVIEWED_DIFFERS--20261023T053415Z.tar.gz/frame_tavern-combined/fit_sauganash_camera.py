"""Light provisional camera preparation; no browser/Blender or repository edits."""
import json,math,pathlib
import numpy as np
from scipy.optimize import least_squares
OUT=pathlib.Path(__file__).parent/'preview-root/review/sauganash'
# Approximate manual wall-corner picks on inspected 2017x1296 Andreas image.
# Main lower gable is hidden by annex; its far grade corner is NOT fitted.
world=np.array([[9.92,8,0],[0,8,0],[9.92,8,5.5],[0,8,5.5],[9.92,0,5.5]],float)
pixels=np.array([[891,1027],[1686,1001],[891,505],[1696,562],[442,571]],float)
def project(p,points):
 eu,ev,ey,yaw,f,cx,cy=p;t=math.radians(yaw);d=points-np.array([eu,ev,ey]);dep=d[:,0]*math.sin(t)+d[:,1]*math.cos(t);right=d[:,0]*math.cos(t)-d[:,1]*math.sin(t)
 return np.column_stack([cx+f*right/dep,cy-f*d[:,2]/dep])
def residual(p):return (project(p,world)-pixels).ravel()
bounds=([10,8.1,.2,182,500,-5000,600],[500,500,6,268,20000,5000,1200])
fits=[]
for distance in [35,75,150]:
 for yaw in [215,235,250]:
  r=least_squares(residual,[9.92+distance,8+distance,1.7,yaw,min(19000,distance*75),1008,917.5],bounds=bounds,max_nfev=3000)
  fits.append(r)
r=min(fits,key=lambda r:np.linalg.norm(r.fun));eu,ev,ey,yaw,f,cx,cy=r.x;pred=project(r.x,world);res=pred-pixels
ridge=5.5+(8/2+.25)*math.tan(math.radians(38));withheld={'near_roof_apex':{'world':[10.17,4,ridge],'picked_pixel':[648,350],'predicted_pixel':project(r.x,np.array([[10.17,4,ridge]]))[0].tolist()}}
proof={'status':'provisional_not_solved_not_accepted','image_size':[2017,1296],'fit_scope':'Five approximate visible main-wall corners; obscured far gable grade corner excluded. Fixed model dimensions, not picture-derived metrics.','eye':r.x[:3].tolist(),'yaw_deg':yaw,'focal_px':f,'principal_px':[cx,cy],'point_rms_px':float(np.sqrt(np.mean(np.sum(res**2,axis=1)))),'coordinate_rms_px':float(np.sqrt(np.mean(res**2))),'max_point_residual_px':float(np.linalg.norm(res,axis=1).max()),'observations':[{'world_uvy':w.tolist(),'source_pixel':p.tolist(),'predicted_pixel':q.tolist(),'residual':d.tolist()} for w,p,q,d in zip(world,pixels,pred,res)],'withheld_roof':withheld,'at_bound':bool(np.any(abs(r.x-np.array(bounds[0]))<1e-3) or np.any(abs(r.x-np.array(bounds[1]))<1e-3))}
(OUT/'source-picks-and-fit.json').write_text(json.dumps(proof,indent=2)+'\n')
cam={'structure_id':'sauganash_hotel','source_id':'andreas_1884_sauganash_hotel_plate','photo':'/workspace/chicago/chicago/reference/images/chicago/chicago_sauganash_hotel_1831.jpg','image_px':[2017,1296],'principal_px':[cx,cy],'focal_px':f,'eye':[eu,ev,ey],'yaw_deg':yaw,'sky':'overcast','solve':f'PROVISIONAL COMPARISON FRAMING ONLY, NOT A SOLVED OR ACCEPTED CAMERA. Five manually picked main-wall corners in the inspected 2017x1296 Andreas/Braunhold image, fixed current 9.92 x 8 m rectangle and 5.5 m wall height. Far lower end corner is obscured by the annex and excluded; other grade picks are approximate beside figures/boardwalk. Point RMS {proof["point_rms_px"]:.2f} px, max {proof["max_point_residual_px"]:.2f} px. Picks/residuals and withheld roof apex are in source-picks-and-fit.json. Dimensions and viewpoint are reconstruction, not surveyed controls. The source is retrospective and cannot date every feature to 1835; preserve differs until actual review. Source hatching and no consistent cast shadow warrant provisional overcast review lighting; original colours are supplied by separate evidence, not this monochrome plate. Principal x is outside the source width and the withheld ridge residual is large: this is a poorly constrained perspective fit. Initial main-mesh review omits the separately modelled log annex; no absence claim.'}
(OUT/'andreas-main-gable.provisional.json').write_text(json.dumps(cam,indent=2)+'\n')
print(json.dumps({k:proof[k] for k in ['point_rms_px','max_point_residual_px','eye','yaw_deg','focal_px','principal_px','at_bound','withheld_roof']},indent=2))
