# green-tree — actual proposal comparison

Reviewed the saved actual side-by-side and proposal render. Verdict: **differs**; prototype camera/mesh only, no original ticket closure.

- **fixed**: Pictured long/south elevation now renders seven upper sash, replacing its former six-bay default; opposite north stays six and both gables retain their previous treatment.
- **open**: Exact sash width/height, vertical bands and equal station spacing remain reconstructed; visible openings and facade proportions are not a detailed match.
- **open**: The model keeps a centred gable entry, while this Andreas view places the pictured entry differently. Gable ground/upper arrangement and attic-light depiction remain unresolved across the ticket pictures.
- **open**: Text-attested side entry remains at the middle ground-floor bay. This review does not reconcile its appearance with the drawing lower sash/entry arrangement.
- **open**: Source composition shows low buildings to the left; the current main mesh extension projects to the right. Identity, connection, wing massing and context must be resolved without moving geographic controls to fit a drawing.
- **open**: Roof shape/stacks, siding/trim, sign and street context/figures differ or are omitted by this bare-building review.
- **open**: Camera is an unsolved drawing fit: principal x=-3472.8px outside the source,6.11px coordinate RMS,12.65max point residual; two withheld roof picks disagree. No physical or geographic camera is accepted.
- **not shown**: Retrospective source form is not a dated1835 survey. Colours and hidden treatment cannot be established by this monochrome picture.
