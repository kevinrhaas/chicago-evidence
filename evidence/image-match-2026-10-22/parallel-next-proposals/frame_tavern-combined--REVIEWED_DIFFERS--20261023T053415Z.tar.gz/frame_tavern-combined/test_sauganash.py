import ast,copy,dataclasses,importlib.util,json,math,pathlib,sys
B=pathlib.Path('/tmp/chicago-next-model/T-2383');R=pathlib.Path('/workspace/chicago/chicago/4d')
sys.path.insert(0,str(R/'generators'))
G=pathlib.Path('/tmp/chicago-next-model/frame_tavern-combined/proposed/generators/archetypes');spec=importlib.util.spec_from_file_location('sauganash_end_params',G/'frame_tavern_params.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
rel='chicago/4d/data/structures/sauganash_hotel.json';before=json.loads((B/'before'/rel).read_text());after=json.loads(pathlib.Path('/tmp/chicago-next-model/frame_tavern-combined/proposed/data/structures/sauganash_hotel.json').read_text());oldp=before['phases'][1];newp=after['phases'][1]
x=copy.deepcopy(after);x['phases'][1]['form'].pop('end_windows');assert x==before
p=m.from_phase(newp,after);p.validate();assert len(p.end_windows)==3
assert m.from_phase(oldp,before).end_windows==()
assert 'end_windows' in m.CONSUMED
import jsonschema
jsonschema.validate(after,json.loads((R/'data/structures.schema.json').read_text()))
# Extract only the new geometry function; its calls can be measured without bpy.
tree=ast.parse((G/'frame_tavern.py').read_text());fun=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_end_windows');calls=[]
ns={'MeshBuilder':object,'FrameTavernParams':m.FrameTavernParams,'ROOF_OVERHANG':.25,'LIP_M':.018,'_win':lambda *a,**kw:calls.append((a,kw))}
exec(compile(ast.Module(body=[fun],type_ignores=[]),str(G/'frame_tavern.py'),'exec'),ns)
ns['_end_windows'](object(),p,p.width_m,p.depth_m,p.wall_height_m)
assert len(calls)==3
assert [a[0][3] for a in calls]==[9.92,9.92,10.17]
assert all(a[0][2]=='x' and a[0][4]==1 for a in calls)
assert [round(a[0][8],6) for a in calls]==[4.925,4.925,7.3]
q=m.from_phase(oldp,before);calls.clear();ns['_end_windows'](object(),q,q.width_m,q.depth_m,q.wall_height_m);assert not calls
for mutate in [lambda q:setattr(q,'roof_type','hip'),lambda q:setattr(q,'end_windows',(('+x',.5,9.,.7,1.2),)),lambda q:setattr(q,'end_windows',(('+x',.5,5.5,.7,1.2),)),lambda q:setattr(q,'end_windows',(('+z',.5,4.25,.7,1.2),)),lambda q:setattr(q,'end_windows',(('+x',.5,float('nan'),.7,1.2),))]:
 q=m.from_phase(newp,after);mutate(q)
 try:q.validate()
 except m.ParamError:pass
 else:raise AssertionError('invalid end window accepted')
print('PASS: isolated record delta, schema, consumed opt-in/default, params, 3 geometry calls and valid attic plane, bad roof/silhouette/eave/end/nonfinite refusals')
print('No Blender, browser, output-byte equivalence, image matches or broad gate performed.')
spec=importlib.util.spec_from_file_location('sauganash_end_old_params',B/'before/chicago/4d/generators/archetypes/frame_tavern_params.py');old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
assets=json.loads((R/'assets/manifest.json').read_text())['assets'];names=[]
for name,v in assets.items():
 if v.get('archetype')!='frame_tavern':continue
 names.append(name);r=json.loads((R/'data/structures'/f"{v['structure_id']}.json").read_text());phase=next(p for p in r['phases'] if p['id']==v['phase_id'])
 a=dataclasses.asdict(old.from_phase(phase,r));b=dataclasses.asdict(m.from_phase(phase,r));assert b.pop('end_windows')==();assert a=={k:v for k,v in b.items() if k in a}
(pathlib.Path('/tmp/chicago-next-model/frame_tavern-combined')/'registered-frame-assets.json').write_text(json.dumps({'count':len(names),'assets':names},indent=2)+'\n')
print('PASS: all',len(names),'registered existing frame_tavern phases retain identical resolved fields after excluding new empty opt-in field. Byte hashes still change and require real revalidation.')
