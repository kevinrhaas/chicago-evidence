# T-2376 + T-2383 + T-2385 — compatible frame_tavern family proposal

State: copied-module implementation with **actual isolated pinned4.5.3 exports and reviewed comparisons**. All3 verdicts are `differs`. No tracked changes, manifests, publisher or accepted match. Parent integrates centrally after Hogan work. The first Tremont preview remains immutable.

Separate proposals are preserved:

- Sauganash: `/tmp/chicago-next-model/T-2383/` — empty-default `end_windows` tuple, adding only the pictured +x main-gable two upper sash and one attic sash. Existing public-domain Andreas source and separate liberty note retained. Wall/attic planes preserve the overhang distinction; all other faces remain unchanged.

- GreenTree: `/tmp/chicago-next-model/T-2376/` — sparse `eaves_bays` override, only pictured south/x_min=7; north remains6 and gables unchanged. Public-domain Andreas/Braunhold source and separate liberty note retained.
- Tremont: `/tmp/chicago-next-model/T-2385-next/` — three-storey corner treatment plus arched gable feature, raised entries,32° working roof, four slope-offset stacks and roof spar; all reconstructed metrics/hidden details and owner-approved Gifford attribution retained. Cloth/anchor integration remains open.

`proposed/` combines the final copied modules and all three data records. The GreenTree change occupies `_fenestration_gable_front`; Tremont uses separate `corner_gable` branches/helpers. Shared parameter additions have independent empty/false/None defaults and validation. Sauganash's `_end_windows` guard is frontage-only and does not alter either GreenTree's gable_front scheme or Tremont's corner scheme. `prepare_combined.py` reproducibly combines source packages; it does not modify either source package or repository.

`T-2376-T-2383-T-2385-combined.patch` is a complete standard unified diff for the chicago repository root: two generator/parameter files, three structure records and append-only liberty text. `git apply --check` passed from `/workspace/chicago`. Recheck before adoption, particularly the liberty EOF hunk. The patch includes no generated output, sidecar/grade/index, changelog, STATUS or ROADMAP; integration must provide those.

All three focused scripts pass against the combined modules:

- `test_tremont.py` / `test-tremont.log`: existing24 record-phase accumulated geometry/materials unchanged with opt-ins absent; Tremont schema/parameters, feature counts, bounds/type/finite/clearance handling and lunette winding pass.
- `test_green_tree.py` / `test-green-tree.log`: default opening calls unchanged; GreenTree south7/north6, opposite/gable calls unchanged; invalid override cases rejected and confidence applied only to its own face.

- `test_sauganash.py` / `test-sauganash.log`: isolated record delta/schema, three pictured end-sash calls and correct attic overhang plane, invalid roof/end/eave/nonfinite/silhouette cases rejected; empty-default parameters unchanged across all23 actual registered family phases.

The actual current asset family is **23 frame_tavern master recipes**; one of the24 CPU-tested record phases is Sauganash's non-manifest log phase. Changed generator bytes and new resolved fields require refresh of that entire family, even when default geometry is identical elsewhere. `staleness-scope.json` names every asset/phase. No shared/common module was edited and no frame_tavern version is currently registered.

`export_previews.py` and guarded `run_exports.sh` completed isolated pinned-Blender4.5.3 exports after parent local-gate release (`C4D_FAMILY_PARENT_RELEASED=1`). They compare each old target's actual Blender geometry/material/confidence treatment with disabled combined code, then export all three copied proposals using the project's actual UV/export functions. Outputs/reports stay under `preview-root/`; no `build.py` or manifest writer runs. These previews do not replace official family build/freshness acceptance.

`preview-root/review/tremont/` has the unchanged provisional six-wall-corner camera from the first7.8m envelope comparison (3.546px point RMS,6.866max). GreenTree's provisional camera and source-pick residuals are now under `preview-root/review/green-tree/`:6.11px per-coordinate RMS,12.65px maximum point residual. Its extreme principal x=-3472.8px is an unconstrained drawing-fit warning and two withheld roof points still differ; it is not a solved physical camera or accepted match. `preview-root/review/sauganash/` now contains a provisional five-main-wall-corner camera and preserved manual picks:16.28px point RMS,30.15px maximum residual, principal x≈4129px outside the source, and a large withheld roof-apex residual (~119px vertically). This is initial before/after framing only; current roof/camera remain substantially unresolved. The main hotel preview omits its separately modelled log annex, which remains context rather than an absence claim. The three-model export fixture explicitly selects Sauganash's `frame_1831`, avoiding its older `log_1829` phase.

Browser use must be coordinated separately after exports; no browser starts in `run_exports.sh`. Renderer helpers are copied and vendor-JS/Playwright symlinks read the existing shared workspace.

Actual preview receipt: `preview-root/reviewed-preview-receipt.json`. All3 targets proved actual disabled-default Blender geometry/material/confidence identical; all new meshes had finite vertices/confidence and zero degenerate polygons. Exported GLBs have normals, UVs, _CONFIDENCE and correct structure/phase extras. All3 browsers exited0 and closed. Per-target actual renders, source comparisons, standard differs records and observations are in `preview-root/review/`. CPU/browser slot was released to the fort agent.

Visible result: Tremont now has its arched feature, raised entries, four offset stacks, roof spar and improved working ridge, but lacks flag cloth and detail agreement; GreenTree now has7 pictured-side upper sash, with camera/gable/wing/detail differences still open; Sauganash now has its3 missing main-end sash, with major roof/cross-wing/camera/grouped-annex differences still open.

Next: official family content build, derivatives/manifests, licence provenance and derived data, app/card checks, required gates and one coherent PR group into dev. Original image-match tickets stay open until every picture actually matches.

Final corrected review: all three `review/*/source-before-after.jpg` panels were visually inspected after canonical `emit.emit_structure` regeneration. They compare pinned committed575 GLBs with the new proposals using byte-identical cameras, numeric intrinsics, light, source images and renderer helpers. See `preview-root/same-camera-before-after-proof.json`. `pinned-default-input-proof.json` verifies old module/record snapshots against pinned575, rather than the now-modified parent checkout. `canonical-door-material-proof.json` proves existing GreenTree/Sauganash door and panel PBR values match committed GLBs.

The original isolated fixture accidentally used structure_id rather than official structure_id__phase_id as its name seed, changing existing door choices. Those erroneous outputs/reports are preserved under `preview-root/superseded-structure-id-seed/` and explicitly superseded; generator/data patch bytes were unaffected. Current reports, GLBs and comparisons use the actual canonical emitter and seed. Every Blender/browser/server is closed; no further heavy work is planned.
