from pathlib import Path
import shutil
H=Path(__file__).resolve().parent;F=H/'fixture';BASE=Path('/tmp/chicago-next-model/T-3055-selective-integration/review-tree/chicago/4d');R=Path('/workspace/chicago/chicago/4d')
for sid in ['green_tree_tavern','sauganash_hotel']:shutil.copy2(BASE/f'data/structures/{sid}.json',F/f'data/structures/{sid}.json')
common=F/'generators/common'
if not common.exists():common.symlink_to(R/'generators/common',target_is_directory=True)
p=F/'tools/test_frame_tavern_picture_features.py';s=p.read_text();s=s.replace('"gable_arch_treatment": "fanlight", "corner_entry_surround": False,','"gable_arch_treatment": "fanlight", "gable_arch_text": "", "corner_entry_surround": False,')
anchor='    def test_green_tree_override_changes_only_named_eaves_face(self):';assert s.count(anchor)==1
new='''    def test_reconstructed_arch_word_is_inside_panel_and_only_pictured_gable(self):
        _, _, p = record_params("tremont_house_1", "frame_1833")
        self.assertEqual(p.gable_arch_text, "TREMONT")
        mesh = MeshBuilder("arch_name")
        builder._corner_arch_letters(mesh, p, p.depth_m, p.wall_height_m)
        self.assertEqual((len(mesh.faces), len(mesh.verts)), (24, 96))
        self.assertTrue(all(c == 1.0 for c in mesh.conf))
        self.assertTrue(all(abs(v[0] + builder.ROOF_OVERHANG + .030) < 1e-9 for v in mesh.verts))
        self.assertTrue(all(normal(mesh, face)[0] < 0 for face in mesh.faces))
        # From the x_min face, viewer-right is local negative-v: text must not mirror.
        first_t=sum(v[1] for v in mesh.verts[:8])/8
        last_t=sum(v[1] for v in mesh.verts[-8:])/8
        self.assertGreater(first_t,last_t)
        for _, u, z in mesh.verts:
            x = abs(u-p.depth_m/2)
            half = p.depth_m*.20-.09
            top = p.wall_height_m+.64+.56*math.sqrt(1-(x/half)**2)
            self.assertGreaterEqual(z, p.wall_height_m+.64)
            self.assertLess(z, top)
        self.assertEqual(mesh.named["gable_letter_paint"][1:], ((.65,.62,.55,1.),.95))
        self.assert_valid_mesh(mesh)

    def test_arch_name_default_is_off_and_invalid_claims_are_refused(self):
        _, _, p = record_params("tremont_house_1", "frame_1833")
        blank = MeshBuilder("no_arch_name")
        builder._corner_arch_letters(blank, dataclasses.replace(p,gable_arch_text=""),p.depth_m,p.wall_height_m)
        self.assertFalse(blank.verts)
        for value in (None,True,1,"TREMONT HOUSE","OTHER"):
            with self.subTest(value=value), self.assertRaises(ParamError):
                dataclasses.replace(p,gable_arch_text=value).validate()
        for change in ({"gable_arch_treatment":"fanlight"},{"gable_lunette":False},
                       {"confidence":{**p.confidence,"gable_arch_text":"attested"}},
                       {"confidence":{**p.confidence,"gable_arch_text":"inferred"}}):
            with self.subTest(change=change), self.assertRaises(ParamError):
                dataclasses.replace(p,**change).validate()

    def test_arch_name_is_consumed_as_exact_keyword_only_record_value(self):
        self.assertIn("gable_arch_text",CONSUMED)
        parameter=inspect.signature(FrameTavernParams).parameters["gable_arch_text"]
        self.assertEqual(parameter.kind,inspect.Parameter.KEYWORD_ONLY)
        self.assertEqual(parameter.default,"")
        record, phase, p = record_params("tremont_house_1","frame_1833")
        self.assertEqual(p.gable_arch_text,phase["form"]["gable_arch_text"]["value"])
        bad=copy.deepcopy(phase);bad["form"]["gable_arch_text"]["confidence"]="attested"
        with self.assertRaises(ParamError):from_phase(bad,record)

'''
s=s.replace(anchor,new+anchor);s=s.replace('"gable_arch_treatment", "corner_entry_surround"}','"gable_arch_treatment", "corner_entry_surround", "gable_arch_text"}');p.write_text(s)
