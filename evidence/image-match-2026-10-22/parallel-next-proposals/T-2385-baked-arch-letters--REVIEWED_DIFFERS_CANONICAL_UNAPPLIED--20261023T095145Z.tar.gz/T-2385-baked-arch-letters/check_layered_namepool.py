"""Exercise the ACTUAL raw/parsed name-pool self-test on all current data + M layers.

Thin isolated copy: links untouched files read-only in practice; all mutated
structure/pool/code/ledger paths are physical files under this package's root.
"""
from pathlib import Path
import json,shutil,subprocess,sys,hashlib,os
H=Path(__file__).resolve().parent;ROOT=Path('/workspace/chicago/chicago/4d');FRAME=Path('/tmp/chicago-next-model/T-3055-selective-integration/review-tree/chicago/4d');T=H/'layered-namepool-root';APP=T/'chicago/4d';APP.mkdir(parents=True,exist_ok=True);D=APP/'data';D.mkdir(exist_ok=True)
for child in ROOT.joinpath('data').iterdir():
 target=D/child.name
 if child.name in ('structures','reconstruction'):
  target.mkdir(exist_ok=True)
  for p in child.iterdir():
   q=target/p.name
   if p.name=='name_pool_keys.json' and child.name=='reconstruction':shutil.copy2(FRAME/'data/reconstruction/name_pool_keys.json',q)
   elif child.name=='structures' and p.name in ['tremont_house_1.json','green_tree_tavern.json','sauganash_hotel.json']:shutil.copy2(FRAME/'data/structures'/p.name,q)
   elif not q.exists():q.symlink_to(p,target_is_directory=p.is_dir())
 elif not target.exists():target.symlink_to(child,target_is_directory=child.is_dir())
for rel in ['generators/archetypes/frame_tavern.py','generators/archetypes/frame_tavern_params.py','tools/test_frame_tavern_picture_features.py','docs/LIBERTIES.md','assets/LICENSES.md']:
 p=APP/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(FRAME/rel,p)
p=APP/'tools/replace_invented_residents.py';shutil.copy2(ROOT/'tools/replace_invented_residents.py',p)
# Current final Tremont notes, using its actual guarded correction tool.
subprocess.run([sys.executable,'/tmp/chicago-next-model/T-3055-post-apply-note-review/correct_notes.py','--repo',str(T),'--apply'],check=True,capture_output=True,text=True)
# Apply the exact published-source operation spec's structure-only fields.
spec=json.loads(Path('/tmp/chicago-next-model/T-2383-shutter-audit/source-update-operations.json').read_text())
for op in spec['operations']:
 if op['kind']!='json_field' or '/data/structures/' not in op['path']:continue
 p=T/op['path'];obj=json.loads(p.read_text());parent=obj
 for k in op['field'][:-1]:parent=parent[k]
 key=op['field'][-1];assert parent[key]==op['old'];parent[key]=op['new'];p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
# Actual guarded roof then actual guarded glyph adoption, on isolated physical paths.
for tool in ['/tmp/chicago-next-model/T-2383-roof-next/adopt_after_review.py',str(H/'adopt.py')]:
 for extra in [[],['--apply']]:subprocess.run([sys.executable,tool,'--repo',str(T)]+extra,check=True,capture_output=True,text=True)
env=dict(os.environ,PYTHONPATH=str(ROOT/'tools')+':/workspace/shared/python')
command=[sys.executable,str(APP/'tools/replace_invented_residents.py'),'--self-test'];r=subprocess.run(command,cwd=APP,env=env,capture_output=True,text=True)
(H/'layered-namepool-self-test.log').write_text(r.stdout+r.stderr)
receipt={'actual_command':command,'exit_code':r.returncode,'root':str(T),'tool_sha256':hashlib.sha256((APP/'tools/replace_invented_residents.py').read_bytes()).hexdigest(),'layers':['currentrootSdata','frozenframehelper3hotelrecords+namepool','actualguardedTremontnotecorrection','exactGalehotelstructurefields','actualguardedSauganashroof+liberty','actualguardedbakedglyph+newpoolpaths+liberty'],'canonical_writes':False,'symlinked_data_never_modified':True,'real_source_self_test_including_raw_parsed_pool_equality':True}
(H/'layered-namepool-self-test.json').write_text(json.dumps(receipt,indent=2)+'\n');print(r.stdout[-2500:]);assert r.returncode==0,r.stderr
