# First Tremont baked known-name lettering — actual reviewed, canonical UNAPPLIED

The actual Gifford/Chicagology image shows light marks inside its dark gabled arch, but its native arch is only roughly70×20pixels. Inspection of the full-resolution1637×796held image and nearest-neighbour sourcecrop cannot independently establish a reliable full inscription. The proposed TREMONT comes from the documented house identity. Its word, font, pigment, size, station and date use are consciously reconstructed; this is not an attested transcription. Owner-approved reference use and the original credit remain disclosed.

The bounded opt-in adds `gable_arch_text="TREMONT"` as one **keyword-only/default-empty** parameter. It requires the corner-gable opaque lunette and reconstructed confidence, validates an analytic arch fit, and bakes24 local stroke quads into the real frame mesh, all confidence1. Six4×6capital shapes adapt existing project `prairie_draft.GLYPHS` geometry locally; no external font, sourcepixels, runtime overlay or signage-atlas entry is introduced. It paints the pictured x_min gable only, with correct viewer-reading direction and outward normals. Existing generic runtime postboard behaviour is unchanged; this package does not claim to remove it.

## Actual proof

Pinned Blender4.5.3 completed two actual exports through the real emitter; the unchanged baseline exactly reproduced the prior440624-byte/5504triangle GLB. The named variant is445040bytes/5552triangles. Both actual browser comparisons were viewed by this agent and the parent, including source/model nearest8×archcrops. Light marks improve the blank panel, without an observed regression elsewhere. The word's baseline/typeface/size/sourceperspective remain different; all original picture cases stay open and verdicts remain `differs`.

- Before: `fixture/review/before/gifford-baked-name-side-by-side.jpg`.
- After: `fixture/review/after/gifford-baked-name-side-by-side.jpg`.
- Native crops: `source-arch-nearest8x.png`, `baked-arch-nearest8x.png`.
- `actual-export-receipt.json` pins actual mesh bytes; `actual-view-review.json` records the actual visual verdict and reviewed generator hash.
- `durable-tests.log`: all14 old+new meaningful feature tests PASS.
- `compatibility-proof.json`: all24 existing record/phase default geometries/materials/confidence exact; all40 positional parameters/defaults/order and __match_args__ exact; previous10 keyword-only fields retained, newfield defaultoff.
- `layered-namepool-self-test.log/json`: ACTUAL CLI self-test on current data plus the guarded frame/note/Gale/roof/glyph record and pool layers PASS, including raw-text/parsed-pool equality and negative fixtures. Physical mutable files reside only in the isolated thin copy. The receipt's tool hash was corrected to the actual executed CLI file; execution/log unchanged.

## Guarded adoption order

Parent has approved the actual roof and glyph comparisons for progress adoption. After sourceS is committed, apply the original frozen frame helper, the separate guarded current-note correction, and the verified1902Gale hotel source adoption. Then:

```sh
python /tmp/chicago-next-model/T-2383-roof-next/adopt_after_review.py --repo /workspace/chicago
# Inspect that package's plan/review outputs; only then:
python /tmp/chicago-next-model/T-2383-roof-next/adopt_after_review.py --repo /workspace/chicago --apply
python /tmp/chicago-next-model/T-2385-baked-arch-letters/adopt.py --repo /workspace/chicago
# Inspect adoption-plan.json and post-apply-review; only then:
python /tmp/chicago-next-model/T-2385-baked-arch-letters/adopt.py --repo /workspace/chicago --apply
```

Roof MUST precede glyph: its proof intentionally guards the frozen generator bytes. The glyph overlay guards source/test payloads, reviewed actual exports,24/40proofs and every current target hash; it changes seven code/test/record/pool/ledger/license files. It adds actual note AND value name-pool read paths and a truthful reconstructed-only liberty. It copies no canonical GLB, manifest or sidecar. Real all23frame-family regeneration, compilation, published QA and required checks remain owed after source changes.

The latest adoption-plan/apply-receipt/post-apply-review are from the **isolated layered-namepool-root exercise**, not canonical application. ALWAYS replan against `/workspace/chicago` after preceding changes. No canonical assets or records have been written by this agent.

## Composed QA and changelog

`composed-qa/` preserves every existing12case/twoviewport grouped check, including Galejail/UCR, oldAndreascredits, page/networkoracle and actual normal/confidence flag draw. It adds the Sauganash lower roof/new attic and Tremont known-name values AND visible Sources grades. Syntax check passed; browser execution remains unrun. After actual canonical adoption:

```sh
python /tmp/chicago-next-model/T-2385-baked-arch-letters/composed-qa/promote.py --repo /workspace/chicago
# Inspect promotion-plan.json +promotion-review, then:
python /tmp/chicago-next-model/T-2385-baked-arch-letters/composed-qa/promote.py --repo /workspace/chicago --apply
```

This regenerates expected record hashes from actual adopted records, backs up current QA, and retains all prior oracles. Do not use either older single-overlay expected JSON in isolation. `T-3055.six-items.with-roof-and-name.json` is a concise six-item candidate retaining sourceS disclosures and explicitly naming reconstructed lettering. It does not replace any frozen historical changelog artifact.

The alternative runtime-lettering study remains historical/future and actual-browser UNRUN. A stock roof tone via root reconstruction metadata was rejected: the schema reserves that block for infill and other consumers reinterpret any truthy block. A separately authorized existing-form roof-colour extension is being prepared outside this frozen actual glyph packet; no dark roof result is claimed here.
