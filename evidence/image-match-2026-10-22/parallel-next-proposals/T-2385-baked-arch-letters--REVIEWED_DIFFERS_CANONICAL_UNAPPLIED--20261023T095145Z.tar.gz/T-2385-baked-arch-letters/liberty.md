### L-tremont-reconstructed-arch-name-2385 — A known name on the first Tremont’s unresolved arched inscription

**Covers:** `tremont_house_1.frame_1833.form.gable_arch_text`.

**Decision:** Consciously reconstruct **TREMONT** on the existing opaque arched panel, using the independently documented house name rather than claiming the native Gifford marks can be transcribed. The held and current remote image are byte-identical1637×796px; the arch is roughly70×20px. Light letter-like marks are visible, but the exact original wording, font and fine shapes remain unresolved. This choice follows the owner’s authority to reconstruct named signs and is explicitly reconstructed, not a public-domain or legible-inscription finding. Source `gifford_tremont_house_no_1` retains N.RoswellGifford/Chicagology attribution and owner-approved project use; `andreas_1884_v1` supplies the house identity.

Six existing project stroke-capital shapes from `prairie_draft.GLYPHS` are adapted locally through MeshBuilder for seven paint-proxy letters, without importing another archetype or source pixels. The one optional `gable_arch_text` field defaults empty, is keyword-only and supports only the explicit known-name choice; it requires the opaque corner-gable panel and refuses a claim above reconstructed. All96 new vertices/24 stroke quads carry confidence1 and matte light paint. Working width is2.68/9.14of the shortgable (2.68m here), height0.32m, bottom0.65m aboveeaves and the plane5mm outside the existing opaque field to avoidz-fighting. Typeface, colour, dimensions, paint-proxy thickness/station, word and date use are reconstructed. The entire word rectangle fits inside the existing innerellipse. Only the pictured localx_min gable is lettered; the concealedopposite stays blank. No geographic controls, phase dates, roof/window/entry/flag geometry or other building defaults change.

Actual pinned before/after exports and same-source-camera images were inspected: added light marks improve the empty panel, while the block font, exact baseline/wording, source perspective, chronology and remaining building/context details still differ. No original ticket closes or receives matches from this refinement. The existing runtime flag is outside this isolated baked-mesh comparison and retains separate app acceptance.

**Ticket:** T-2385 (shared controls T-3055).
**Recorded:** 2026-10-23.
