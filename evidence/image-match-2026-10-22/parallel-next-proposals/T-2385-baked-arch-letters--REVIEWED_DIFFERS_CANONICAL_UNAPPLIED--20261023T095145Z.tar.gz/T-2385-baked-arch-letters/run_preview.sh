#!/usr/bin/env bash
set -euo pipefail
name_root=/tmp/chicago-next-model/T-2385-baked-arch-letters
export PYTHONPATH="/workspace/shared/python${PYTHONPATH:+:$PYTHONPATH}"
export PW_EXECUTABLE=/usr/bin/chromium
cd "$name_root"
/workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender -b -noaudio --factory-startup --python "$name_root/export_preview.py" > "$name_root/blender-export.log" 2>&1
cd "$name_root/fixture"
for name_label in before after; do
 node tools/photo_match.mjs "review/$name_label/gifford-baked-name.json" --glb "assets/gltf/$name_label/tremont_house_1__frame_1833.glb" --out "review/$name_label" > "$name_root/photo-$name_label.log" 2>&1
done
