from pathlib import Path
import ast,json,shutil
H=Path(__file__).resolve().parent;BASE=Path('/tmp/chicago-next-model/T-3055-selective-integration/review-tree/chicago/4d');ROOT=Path('/workspace/chicago/chicago/4d');F=H/'fixture'
for rel in ['generators/archetypes/frame_tavern.py','generators/archetypes/frame_tavern_params.py','data/structures/tremont_house_1.json','tools/test_frame_tavern_picture_features.py']:
 p=F/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(BASE/rel,p)
 p=H/'baseline'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(BASE/rel,p)
(F/'generators/archetypes/__init__.py').touch()
p=F/'generators/archetypes/frame_tavern_params.py';s=p.read_text();s=s.replace('"gable_arch_treatment", "corner_entry_surround",','"gable_arch_treatment", "corner_entry_surround", "gable_arch_text",')
anchor='    corner_entry_surround: bool = field(default=False, kw_only=True)';assert s.count(anchor)==1;s=s.replace(anchor,'    # Optional known-name reconstruction, never a source transcription.\n    gable_arch_text: str = field(default="", kw_only=True)\n'+anchor)
anchor='        detailed = (self.first_story_height_m';i=s.index(anchor)
validation='''        if not isinstance(self.gable_arch_text, str) or self.gable_arch_text not in ("", "TREMONT"):
            raise ParamError("gable_arch_text supports only empty or reconstructed TREMONT")
        if self.gable_arch_text:
            if (self.elevation_scheme != "corner_gable" or not self.gable_lunette
                    or self.gable_arch_treatment != "opaque_panel"):
                raise ParamError("gable_arch_text needs the opaque corner-gable panel")
            if self.confidence.get("gable_arch_text", "reconstructed") != "reconstructed":
                raise ParamError("gable_arch_text is a conscious reconstruction, not a transcription")
            inner_half = self.depth_m * .20 - .09
            text_half = self.depth_m * (2.68 / 9.14) / 2
            if inner_half <= text_half:
                raise ParamError("gable_arch_text is wider than the inner arch")
            top = .64 + .56 * math.sqrt(1 - (text_half / inner_half) ** 2)
            if top < .65 + .32 + .005:
                raise ParamError("gable_arch_text breaks the inner arch outline")
'''
s=s[:i]+validation+s[i:];anchor='        gable_arch_treatment=val("gable_arch_treatment", "fanlight"),';assert s.count(anchor)==1;s=s.replace(anchor,anchor+'\n        gable_arch_text=val("gable_arch_text", ""),');p.write_text(s)
p=F/'generators/archetypes/frame_tavern.py';s=p.read_text();anchor='            _corner_lunettes(b, params, w, d, wall_z)';assert s.count(anchor)==1;s=s.replace(anchor,anchor+'\n        if params.gable_arch_text:\n            _corner_arch_letters(b, params, d, wall_z)')
# Adapt only the existing project stroke shapes; no import/dependency on another archetype.
tree=ast.parse((ROOT/'generators/archetypes/prairie_draft.py').read_text());node=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='GLYPHS' for t in n.targets));glyphs=ast.literal_eval(node.value);chosen={k:glyphs[k] for k in 'TREM ON'.replace(' ','')};literal=repr(chosen)
helper='''
# The six needed stroke-capital shapes are copied from this project's existing
# prairie_draft.GLYPHS (T-2399), adapted to MeshBuilder. No font/source pixels.
_ARCH_NAME_GLYPHS = GLYPH_LITERAL


def _corner_arch_letters(b: MeshBuilder, params: FrameTavernParams,
                         d: float, wall_z: float) -> None:
    """Known house-name reconstruction on the pictured x_min opaque panel only.

    Gifford's native inscription is unresolved. These are invented light paint
    strokes with reconstructed confidence, not an attested glyph transcription.
    """
    if not params.gable_arch_text:
        return
    quads, cursor = [], 0.0
    for char in params.gable_arch_text:
        strokes, advance = _ARCH_NAME_GLYPHS[char]
        for x0, y0, x1, y1 in strokes:
            ax, ay = cursor + x0 + .45, y0 + .45
            bx, by = cursor + x1 + .45, y1 + .45
            length = math.hypot(bx-ax, by-ay)
            dx, dy = (bx-ax)/length, (by-ay)/length
            ax, ay, bx, by = ax-dx*.45, ay-dy*.45, bx+dx*.45, by+dy*.45
            px, py = -dy*.45, dx*.45
            quads.append([(ax-px,ay-py),(bx-px,by-py),(bx+px,by+py),(ax+px,ay+py)])
        cursor += advance
    xs=[p[0] for q in quads for p in q];ys=[p[1] for q in quads for p in q]
    xmin,xmax,ymin,ymax=min(xs),max(xs),min(ys),max(ys)
    width=d*(2.68/9.14)
    mat=b.named_mat("gable_letter_paint",(.65,.62,.55,1.0),.95)
    for quad in quads:
        # Five millimetres in front of the existing .025m opaque field plane.
        pts=[(-ROOF_OVERHANG-.030,
              d/2+width/2-(x-xmin)/(xmax-xmin)*width,
              wall_z+.65+(y-ymin)/(ymax-ymin)*.32) for x,y in quad]
        # All strokes face x_min; every new vertex stays reconstructed.
        a,c,e=pts[:3]
        nx=(c[1]-a[1])*(e[2]-a[2])-(c[2]-a[2])*(e[1]-a[1])
        if nx>0:pts.reverse()
        b.add_poly(pts,1.0,mat)


'''.replace('GLYPH_LITERAL',literal)
anchor='def _corner_slope_stacks(';assert s.count(anchor)==1;s=s.replace(anchor,helper+anchor);p.write_text(s)
p=F/'data/structures/tremont_house_1.json';r=json.loads(p.read_text());f=r['phases'][0]['form'];f['gable_arch_text']={'value':'TREMONT','confidence':'reconstructed','sources':['andreas_1884_v1','gifford_tremont_house_no_1'],'note':'CONSCIOUS KNOWN-NAME RECONSTRUCTION, NOT A TRANSCRIPTION. The Gifford reproduction has light letter-like marks on the dark arched panel, but its native roughly70x20px feature does not independently resolve the whole inscription. TREMONT uses the independently documented house name as an explicit working choice. Six existing project stroke-capital shapes form seven matte light-paint letters; typeface, word, colour, spacing, exact1835presence and metricplacement are reconstructed. Only the pictured localx_min gable receives text; the concealedopposite stays blank. Working textwidth is2.68/9.14of the shortgable (2.68m here), height.32m and bottom.65m aboveeaves, entirely inside the existingopaqueinnerarch. The paintproxy lies5mm proud of the darkfield to avoidz-fighting; all addedvertices carryreconstructedconfidence1. Exactsourcelettering andfullimagematch remainopen.'};p.write_text(json.dumps(r,indent=2)+'\n')
print('Prepared bounded bakedletter candidate; frozenhelper/canonicalapp untouched')
