"""Review then adopt the bounded baked-name overlay after the frozen frame helper.

Always replan after source/roof/note changes. No apply without inspected actual
exports and exact default/API proof; no canonical preview GLBs are copied.
"""
from pathlib import Path
import argparse,copy,json,hashlib,os
H=Path(__file__).resolve().parent
CODE=['generators/archetypes/frame_tavern.py','generators/archetypes/frame_tavern_params.py','tools/test_frame_tavern_picture_features.py']
def sha(data):return hashlib.sha256(data).hexdigest()
def atomic(p,data):
 p.parent.mkdir(parents=True,exist_ok=True);t=p.with_name('.'+p.name+'.arch-name.tmp')
 try:t.write_bytes(data);os.replace(t,p)
 finally:t.unlink(missing_ok=True)
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--apply',action='store_true');a=ap.parse_args();root=a.repo.resolve()/'chicago/4d';out=H/'post-apply-review';out.mkdir(exist_ok=True)
 if a.apply:
  plan=json.loads((H/'adoption-plan.json').read_text());assert plan['repo']==str(a.repo.resolve())
  view=json.loads((H/'actual-view-review.json').read_text());assert view['actual_side_by_sides_viewed'] and view['closer_without_new_regression'] and view['verdict']=='differs';assert view['export_receipt_sha256']==sha((H/'actual-export-receipt.json').read_bytes())
  compat=json.loads((H/'compatibility-proof.json').read_text());assert compat['phase_count']==24 and len(compat['all_40_positional_parameters_defaults_order_preserved'])==40
  assert view['reviewed_generator_sha256']==plan['payload_sha256']['generators/archetypes/frame_tavern.py']
  for name in ['frame_tavern.py','frame_tavern_params.py']:
   assert compat['new_source_code_sha256'][name]==plan['payload_sha256']['generators/archetypes/'+name]
  for rel in CODE:
   assert sha((H/'fixture'/rel).read_bytes())==plan['payload_sha256'][rel]
  for f in plan['files']:
   assert sha((root/f['path']).read_bytes())==f['old_sha256'],f['path'];assert sha((out/f['path']).read_bytes())==f['new_sha256'],f['path']
  written=[]
  try:
   for f in plan['files']:
    p=root/f['path'];backup=H/'apply-backup'/f['path'];atomic(backup,p.read_bytes());atomic(p,(out/f['path']).read_bytes());written.append(f)
  except BaseException:
   for f in reversed(written):atomic(root/f['path'],(H/'apply-backup'/f['path']).read_bytes())
   raise
  (H/'apply-receipt.json').write_text(json.dumps({'applied':True,'review_plan':plan,'canonical_assets_copied':False},indent=2)+'\n');print('APPLIED bounded baked-name source/record/ledger/pool/test overlay; real23family bake and compilation remain required');return
 result={};payload={}
 for rel in CODE:
  old=(root/rel).read_bytes();expected=(H/'baseline'/rel).read_bytes();new=(H/'fixture'/rel).read_bytes();assert old==expected,f'{rel}: post-helper source drift';result[rel]=new;payload[rel]=sha(new)
 rel='data/structures/tremont_house_1.json';r=json.loads((root/rel).read_text());old=copy.deepcopy(r);phase=next(p for p in r['phases'] if p['id']=='frame_1833');f=phase['form'];assert 'gable_arch_text' not in f;assert f['gable_arch_treatment']['value']=='opaque_panel' and f['gable_lunette']['value'] is True
 proposed=json.loads((H/'fixture'/rel).read_text());f['gable_arch_text']=copy.deepcopy(proposed['phases'][0]['form']['gable_arch_text'])
 for key in ['gable_lunette','gable_arch_treatment']:
  f[key]['note']='CURRENT KNOWN-NAME RECONSTRUCTION: optional gable_arch_text now paints the documented house name TREMONT on this existing opaque panel. This is consciously reconstructed lettering, not a reliable transcription of the unresolved native Gifford inscription. Typeface, colour, exact station and date use remain reconstructed.\n\nPRIOR OPAQUE-PANEL DECISION (its blank/no-lettering status is superseded by this new opt-in):\n'+f[key]['note']
 r['research_note']='CURRENT RECONSTRUCTED ARCH NAME: the opaque panel now carries a consciously reconstructed TREMONT in light stroke capitals. The actual native Gifford marks do not independently resolve that full inscription; the word comes from the known house identity. All new glyph vertices are reconstructed, with font, pigment, dimensions, station and dated presence explicitly uncertain. Actual before/after comparison shows added light marks but still differs; no accepted match or historical transcription is claimed.\n\n'+r['research_note']
 restore=copy.deepcopy(r);rf=restore['phases'][0]['form'];rf.pop('gable_arch_text')
 for key in ['gable_lunette','gable_arch_treatment']:rf[key]['note']=old['phases'][0]['form'][key]['note']
 restore['research_note']=old['research_note'];assert restore==old
 result[rel]=(json.dumps(r,indent=2,ensure_ascii=False)+'\n').encode()
 rel='data/reconstruction/name_pool_keys.json';p=json.loads((root/rel).read_text());paths=p['read']['structures']
 for key in ['phases[].form.gable_arch_text.note','phases[].form.gable_arch_text.value']:
  assert key not in paths;paths.append(key)
 p['read']['structures']=sorted(paths);result[rel]=(json.dumps(p,indent=2,ensure_ascii=False)+'\n').encode()
 rel='docs/LIBERTIES.md';ledger=(root/rel).read_bytes();fragment=(H/'liberty.md').read_bytes();assert b'### L-tremont-reconstructed-arch-name-2385' not in ledger;result[rel]=ledger+b'\n\n'+fragment
 rel='assets/LICENSES.md';license=(root/rel).read_bytes();addition=b'\n\n## T-3055 first Tremont reconstructed arch name\n\nThe optional baked TREMONT paint strokes are original project GPL-3.0-or-later procedural geometry, adapting six existing prairie_draft.GLYPHS capitals locally through MeshBuilder. No external font, photograph or source-image pixels are baked. The independently known house name bounds the explicit reconstructed word; Gifford/Chicagology remains owner-approved attributed reference use, with no claim of a legible original inscription or public-domain finding. Exact glyph/colour/placement choices and source limits are recorded in L-tremont-reconstructed-arch-name-2385.\n';assert addition not in license;result[rel]=license+addition
 files=[]
 for rel,data in result.items():
  dest=out/rel;atomic(dest,data);files.append({'path':rel,'old_sha256':sha((root/rel).read_bytes()),'new_sha256':sha(data),'bytes':len(data)})
 plan={'repo':str(a.repo.resolve()),'files':files,'payload_sha256':payload,'new_pool_paths':['phases[].form.gable_arch_text.note','phases[].form.gable_arch_text.value'],'new_cover':'tremont_house_1.frame_1833.form.gable_arch_text','copied_canonical_assets':False,'real23family_bake_required':True};(H/'adoption-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
 expect=json.loads(Path('/tmp/frame-integration/group-card-expected.json').read_text());t=expect['hotels']['tremont_house_1'];t['record_sha256']=sha(result['data/structures/tremont_house_1.json']);t['attributes']['gable_arch_text']={'value':'TREMONT','confidence':'reconstructed'};(out/'group-card-expected.with-baked-name.json').write_text(json.dumps(expect,indent=2)+'\n')
 print('REVIEW ONLY',len(files),'source/data/ledger/pool/test files; inspect adoption-plan.json +post-apply-review, then --apply')
if __name__=='__main__':main()
