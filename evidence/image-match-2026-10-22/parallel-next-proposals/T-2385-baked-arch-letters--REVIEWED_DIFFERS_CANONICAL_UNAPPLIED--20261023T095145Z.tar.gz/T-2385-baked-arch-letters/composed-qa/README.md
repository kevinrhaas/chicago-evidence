# Composed grouped-card QA candidate — not yet activated

Generated from the fully layered isolated M records after actual guarded note/roof/glyph adoption and exact Gale hotel structure-field operations. It preserves all 12 grouped cases, both viewports, jail/Gale/UCR checks, old Andreas credits, actual normal/confidence flag drawing and the existing page/network oracle. It adds Sauganash roof_pitch_deg=25.2 (reconstructed), the adjusted attic sash, and Tremont gable_arch_text=TREMONT (reconstructed), including visible Sources fact grades. `node --check` passed. No browser run is claimed.

Do not copy a single-overlay expected JSON. After canonical M adoption, run the guarded promotion tool in this directory. It regenerates expected hashes against the actual adopted canonical records. Current QA remains unchanged until explicit --apply. The new generator uses canonical records, so it fails rather than silently reverting to the old frozen hotel records.
