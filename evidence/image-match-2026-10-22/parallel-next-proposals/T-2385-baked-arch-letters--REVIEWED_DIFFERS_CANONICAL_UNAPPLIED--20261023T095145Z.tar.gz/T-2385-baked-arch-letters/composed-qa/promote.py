"""Prepare or apply the composed QA only after the guarded M overlays are adopted."""
from pathlib import Path
import argparse,json,hashlib,subprocess,shutil,datetime,os
H=Path(__file__).resolve().parent;O=Path('/tmp/frame-integration')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def atomic(p,data):
 t=p.with_name('.'+p.name+'.m-qa.tmp');t.write_bytes(data);os.replace(t,p)
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--apply',action='store_true');a=ap.parse_args();app=a.repo.resolve()/'chicago/4d'
 if a.apply:
  plan=json.loads((H/'promotion-plan.json').read_text());assert plan['repo']==str(a.repo.resolve())
  for rel,digest in plan['canonical_record_sha256'].items():assert sha(app/rel)==digest,rel
  for name,v in plan['files'].items():assert sha(O/name)==v['old_sha256'],name;assert sha(H/'promotion-review'/name)==v['new_sha256'],name
  stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');backup=O/'group-card-history'/('pre-roof-glyph-'+stamp);backup.mkdir(parents=True)
  for name in plan['files']:shutil.copy2(O/name,backup/name)
  for name in ['group-card-check-checkpoint.json','group-card-check-README.md']:shutil.copy2(O/name,backup/name)
  for name in plan['files']:atomic(O/name,(H/'promotion-review'/name).read_bytes())
  receipt={'applied':True,'plan':plan,'backup':str(backup),'actual_browser_run':False};(O/'group-card-roof-glyph-update.json').write_text(json.dumps(receipt,indent=2)+'\n');(O/'group-card-check-README.md').open('a').write('\n\nComposed M roof/glyph QA promotion: guarded current canonical record values and hashes, Sauganash reconstructed25.2°/attic and Tremont reconstructedTREMONT visible grade checks, all12 prior cases retained. See group-card-roof-glyph-update.json. No actual browser execution is asserted by this promotion.\n')
  cp=json.loads((O/'group-card-check-checkpoint.json').read_text());cp['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();cp['status']='Composed M roof/glyph grouped QA promoted from actual canonical record values; syntax PASS, actualbrowserUNRUN';cp['required_cases']=12;cp['repository_writes']=False;cp['current_m_adopted_records_sha256']=plan['canonical_record_sha256'];cp['previous_checkpoint_backup']=str(backup/'group-card-check-checkpoint.json')
  for name in ['group-card-check.mjs','group-card-expected.json','prepare-group-card-check.py','group-card-check-README.md','group-card-roof-glyph-update.json']:cp['files_sha256'][name]=sha(O/name)
  (O/'group-card-check-checkpoint.json').write_text(json.dumps(cp,indent=2)+'\n')
  print('APPLIED QA only; actual grouped browser check remains required');return
 expected={}
 for sid in ['green_tree_tavern','sauganash_hotel','tremont_house_1']:
  rel='data/structures/'+sid+'.json';expected[rel]=sha(app/rel);r=json.loads((app/rel).read_text());ph=next(p for p in r['phases'] if p['documented_range']['from']<='1835-07-01'<=p['documented_range']['to']);f=ph['form']
  if sid=='sauganash_hotel':assert f['roof_pitch_deg']['value']==25.2 and f['roof_pitch_deg']['confidence']=='reconstructed';assert f['end_windows']['value'][2]['at']==.54
  if sid=='tremont_house_1':assert f['gable_arch_text']['value']=='TREMONT' and f['gable_arch_text']['confidence']=='reconstructed'
 out=H/'promotion-review';out.mkdir(exist_ok=True)
 for name in ['jail-gale-1902-assertions.txt','hotel-gale-1902-assertions.txt']:shutil.copy2(O/name,out/name)
 script=(H/'prepare-group-card-check.py').read_text();assert "R=Path('/workspace/chicago/chicago/4d')" in script
 script=script.replace("R=Path('/workspace/chicago/chicago/4d')",f"R=Path({str(app)!r})")
 trial=script.replace("O=Path('/tmp/frame-integration')",f"O=Path({str(out)!r})");(out/'generate.py').write_text(trial);subprocess.run(['python',str(out/'generate.py')],check=True);(out/'prepare-group-card-check.py').write_text(script);subprocess.run(['node','--check',str(out/'group-card-check.mjs')],check=True)
 assert (O/'group-card-check.mjs').read_text().count('hotel whole-picture grade basis missing')==1
 files={name:{'old_sha256':sha(O/name),'new_sha256':sha(out/name)} for name in ['prepare-group-card-check.py','group-card-check.mjs','group-card-expected.json']}
 (H/'promotion-plan.json').write_text(json.dumps({'repo':str(a.repo.resolve()),'files':files,'canonical_record_sha256':expected,'cases':12,'actual_browser_run':False},indent=2)+'\n');print('REVIEW ONLY; inspect promotion-plan.json +promotion-review, then repeat --apply')
if __name__=='__main__':main()
