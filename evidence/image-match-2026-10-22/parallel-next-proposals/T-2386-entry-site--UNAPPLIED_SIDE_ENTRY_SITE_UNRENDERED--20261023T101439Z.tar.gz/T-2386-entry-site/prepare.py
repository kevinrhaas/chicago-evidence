from pathlib import Path
import shutil,difflib,json,hashlib
H=Path(__file__).resolve().parent;R=Path('/workspace/chicago/chicago/4d');L=Path('/tmp/chicago-next-model/T-2386-topology/overlay/candidate/chicago/4d')
paths={'chicago/4d/generators/archetypes/log_dwelling_params.py':L/'generators/archetypes/log_dwelling_params.py','chicago/4d/tools/generate_entrances.py':R/'tools/generate_entrances.py'}
for rel,src in paths.items():
 for kind in ['baseline','candidate']:
  p=H/kind/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,p)
p=H/'candidate/chicago/4d/generators/archetypes/log_dwelling_params.py'
p.write_text(p.read_text()+'''

def side_access_faces(p: LogDwellingParams) -> list[dict]:
    """Explicit additional ground-access faces, never projected onto +Y frontage.

    The bounded elbow is the first declared side entry. Empty says this model
    states no additional face; it does not infer a door from a roof or blank wall.
    Rectangles are the exact ones read by the builder. Plane/along coordinates
    remain in footprint-local metres; callers compose placement once.
    """
    if p.compound_joint != "elbow":
        return []
    out=[]
    for wall,_roof,_axis,rects in p.compound_parts:
        doors=[{"kind":kind,"u0":u0,"u1":u1,"z0":z0,"z1":z1}
               for face,kind,u0,u1,z0,z1 in rects
               if face=="+x" and kind=="door" and z0<.30]
        if doors:
            out.append({"face":"+x","plane_m":wall[2],"u0":wall[1],"u1":wall[3],"openings":doors})
    return out
''')
p=H/'candidate/chicago/4d/tools/generate_entrances.py';s=p.read_text()
s=s.replace('## What is invented','''`front_doors` remains the primary +Y front-wall reader. A declared additional
side face is read separately through log_dwelling_params.side_access_faces;
the first is the elbow plan's +X ground-level entry. Its own wall coordinates,
outward bearing and apron feed the same entrance/clearance list. It is never
flattened onto the primary front or inferred for an unstated side wall.

## What is invented''')
s=s.replace('ENTRANCE_KINDS = ("door", "shop_door", "open_bay")', 'ENTRANCE_KINDS = ("door", "shop_door", "open_bay")\n# Door approaches ask where the visitor\'s travelled track is actually drawn.\n# They do not claim where the survey control places a platted street corridor.\nCORRIDOR_LINE = "drawn"\nCORRIDOR_LINE_WHY = ("Aprons use the committed1835 drawn travelled tracks; no survey-control recentering or historical coordinate is inferred.")')
needle='import generate_frontage_works as gfw  # noqa: E402';assert s.count(needle)==1;s=s.replace(needle,needle+'\nfrom archetypes.log_dwelling_params import side_access_faces as _log_side_access_faces  # noqa: E402')
needle='def merged_openings(sc: dict)';idx=s.index(needle)
s=s[:idx]+'''def side_access_faces(sc: dict) -> list[dict]:
    """Declared extra ground-door faces on the selected sidecar, or none.

    Sidecars already select the scene's phase and carry its actual form/physical
    footprint. Resolve the same geometry tuple as the builder; invalid data raises
    rather than silently losing an entry. No building-id special case.
    """
    if sc.get("archetype") != "log_dwelling":
        return []
    declared = (sc.get("form") or {}).get("compound_joint") or {}
    if declared.get("value") is None:
        return []
    params = gbs._log_dwelling_params(sc)
    return _log_side_access_faces(params)


'''+s[idx:]
needle='''    return {
        "id": "town_entrance_aprons",''';assert s.count(needle)==1
extra='''        # Additional declared faces use their own along-wall/outward basis.
        # Keep primary IDs/order and front_wall semantics unchanged.
        for face in side_access_faces(sc):
            if face["face"] != "+x":
                raise ValueError("entrance reader has no transform for " + face["face"])
            plane = face["plane_m"]
            bearing = (float(place.get("rotation_deg") or 0.0) + 90.0) % 360.0
            outward = (math.sin(math.radians(bearing)), math.cos(math.radians(bearing)))
            def side_to_enu(s_, t, plane=plane, place=place):
                return gbs._to_enu(plane + t, s_, place)
            face_doors = face["openings"]
            spec = [((d["u0"] + d["u1"]) / 2.0, (d["u1"] - d["u0"]) / 2.0,
                     path_depth(side_to_enu((d["u0"] + d["u1"]) / 2.0, 0), outward, streets))
                    for d in face_doors]
            if spec:
                # +Y along-wall / +X outward reverses the primary basis winding.
                rings.append(list(reversed(_front_ring(face["u0"], face["u1"], spec, side_to_enu))))
            for k, d in enumerate(sorted(face_doors, key=lambda o: o["u0"])):
                e, n = side_to_enu((d["u0"] + d["u1"]) / 2.0, 0)
                entrances.append({
                    "id": f"{sc['id']}__side_xp_{d['kind']}_{k + 1}",
                    "structure_id": sc["id"], "archetype": sc["archetype"],
                    "kind": d["kind"], "read_by": "log_dwelling.side_access_faces(+x)",
                    "at_local_enu_m": [_r(e), _r(n)], "bearing_deg": _r(bearing),
                    "width_m": _r(d["u1"] - d["u0"]),
                })
'''
s=s.replace(needle,extra+needle)
s=s.replace('    return {\n        "id": "town_entrance_aprons",','    result = {\n        "id": "town_entrance_aprons",')
needle2='\n\ndef main() -> int:'
assert s.count(needle2)==1
s=s.replace(needle2,"""
    if any("__side_xp_" in x["id"] for x in entrances):
        result["generated_from"].append("generators/archetypes/log_dwelling_params.py")
        result["research_note"] += " Explicit additional side faces use their declared wall line and outward bearing; primary-front APIs retain their original meaning."
    return result


def main() -> int:""")
p.write_text(s)
patch='' 
for rel in paths:patch+=''.join(difflib.unified_diff((H/'baseline'/rel).read_text().splitlines(True),(H/'candidate'/rel).read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(H/'side-entry-consumer.patch').write_text(patch)
(H/'inputs.json').write_text(json.dumps({'composition':'After frozen physical-L overlay; does not modify/overwrite it','files':[{'path':rel,'baseline_sha256':hashlib.sha256((H/'baseline'/rel).read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256((H/'candidate'/rel).read_bytes()).hexdigest()} for rel in paths]},indent=2)+'\n')
# Snapshot lightweight source/site inputs to keep the native measurement reproducible.
for rel in ['data/datum.json','data/streets/1835.json','data/traces/vectors/thompson_lots.json','data/traces/vectors/north_division_tier_lots.json','data/traces/vectors/school_section_tier_lots.json','tools/check_structure_corridors.py','tools/plat_occupancy.py','tools/generate_business_signboards.py','tools/generate_frontage_works.py']:
 dest=H/'site-inputs'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/rel,dest)
shutil.copytree(R/'data/sidecars/1835',H/'site-inputs/data/sidecars/1835',dirs_exist_ok=True)
shutil.copytree(R/'data/structures',H/'site-inputs/data/structures',dirs_exist_ok=True)
