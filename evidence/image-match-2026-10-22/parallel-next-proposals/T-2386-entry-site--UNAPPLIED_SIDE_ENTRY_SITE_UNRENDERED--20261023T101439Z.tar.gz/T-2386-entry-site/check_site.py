"""Focused native proposed-record geometry checks, no assets or source-coordinate fit."""
from pathlib import Path
from types import ModuleType
import json,math,ast,sys
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;S=H/'site-inputs'
CORRIDOR_LINE='drawn'
CORRIDOR_LINE_WHY='Compare physical proposal with actual committed street/lot geometry and visitor collision, not recenter the plat onto survey control. Stored lot grids are seated on drawn lines.'
def load(n,path):
 m=ModuleType(n);m.__file__=str(path);sys.modules[n]=m;exec(compile(path.read_text(),str(path),'exec'),m.__dict__);return m
c=load('site_corridors',S/'tools/check_structure_corridors.py')
ns={'math':math};tree=ast.parse((S/'tools/plat_occupancy.py').read_text());wanted={'_signed_area','area','_convex','overlap_area','inset'};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in wanted],type_ignores=[]),'actual_lot_geometry','exec'),ns)
datum=json.loads((S/'data/datum.json').read_text());streets=json.loads((S/'data/streets/1835.json').read_text());base=json.loads(Path('/tmp/chicago-next-model/T-2386-topology/overlay/baseline/chicago/4d/data/structures/wolf_point_tavern.json').read_text());prop=json.loads((Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/chicago-next-model/T-2386-topology/overlay/candidate/chicago/4d/data/structures/wolf_point_tavern.json')).read_text());old=c.world_polygon(base['phases'][0],datum);new=c.world_polygon(prop['phases'][0],datum)
# Exact Euclidean separation of finite polygon edges, for positive clearances.
def pointseg(p,a,b):
 dx,dy=b[0]-a[0],b[1]-a[1];l=dx*dx+dy*dy;t=0 if l==0 else max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/l));return math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)
def cross(a,b,p):return (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
def segdist(a,b,u,v):
 if cross(a,b,u)*cross(a,b,v)<=0 and cross(u,v,a)*cross(u,v,b)<=0 and max(min(a[0],b[0]),min(u[0],v[0]))<=min(max(a[0],b[0]),max(u[0],v[0]))+1e-9 and max(min(a[1],b[1]),min(u[1],v[1]))<=min(max(a[1],b[1]),max(u[1],v[1]))+1e-9:return 0.
 return min(pointseg(a,u,v),pointseg(b,u,v),pointseg(u,a,b),pointseg(v,a,b))
def edges(poly):return list(zip(poly,poly[1:]+poly[:1]))
def polydist(a,b):
 if any(c._inside(p,b) for p in a) or any(c._inside(p,a) for p in b):return 0.
 return min(segdist(p,q,u,v) for p,q in edges(a) for u,v in edges(b))
def rect_for(a,b,half):
 dx,dy=b[0]-a[0],b[1]-a[1];l=math.hypot(dx,dy)
 if l==0:return []
 nx,ny=-dy*half/l,dx*half/l
 return [(a[0]+nx,a[1]+ny),(b[0]+nx,b[1]+ny),(b[0]-nx,b[1]-ny),(a[0]-nx,a[1]-ny)]
def street_clear(poly,points,half):
 d=min(polydist(poly,r) for a,b in zip(points,points[1:]) if (r:=rect_for(a,b,half)))
 for p in points[1:-1]:d=min(d,max(0,min(pointseg(p,a,b) for a,b in edges(poly))-half))
 return d
corr=[]
for st in streets['streets']:
 pts=[tuple(x) for x in st['path_local_enu_m']];half=float(st.get('corridor_width_m',streets.get('corridor_width_m',24.384)))/2;track=float(st.get('track_width_m') or 7)/2
 corr.append({'street':st['id'],'corridor_width_m':half*2,'old_clearance_to_finite_drawn_corridor_m':street_clear(old,pts,half),'new_clearance_to_finite_drawn_corridor_m':street_clear(new,pts,half),'new_clearance_to_travelled_track_m':street_clear(new,pts,track),'actual_gate_new_depth_m':c.depth_into(new,pts,half)})
oldlaps=c.laps({'wolf_point_tavern':base},streets,datum);newlaps=c.laps({'wolf_point_tavern':prop},streets,datum)
lots=[];lot_gaps=[]
for path in sorted((S/'data/traces/vectors').glob('*.json')):
 doc=json.loads(path.read_text())
 for block in doc.get('blocks',[]):
  for idx,lot in enumerate(block.get('lots') or []):
   if not isinstance(lot,dict) or not lot.get('polygon'):continue
   poly=[tuple(p) for p in lot['polygon']];d=polydist(new,poly);lot_gaps.append({'layer':path.name,'block':block['id'],'lot_index_zero_based':idx,'minimum_separation_m':d})
   if d>20:continue
   overlap=ns['overlap_area'](new,poly);oldoverlap=ns['overlap_area'](old,poly);room=ns['inset'](poly,1.5);buildoverlap=ns['overlap_area'](new,room) if room else 0
   margin=min(pointseg(p,a,b) for p in new for a,b in edges(poly)) if all(c._inside(p,poly) for p in new) else None
   lots.append({'layer_file':path.name,'block':block['id'],'grid':block.get('grid'),'lot_index_zero_based':idx,'plat_lot_number':lot.get('plat_lot_number',lot.get('lot')),'separation_m':d,'old_overlap_m2':oldoverlap,'new_overlap_m2':overlap,'new_overlap_with_1_5m_inset_m2':buildoverlap,'full_body_inside_this_lot':all(c._inside(p,poly) for p in new),'full_body_minimum_lot_margin_m_if_inside':margin})
records={p.stem:json.loads(p.read_text()) for p in (S/'data/structures').glob('*.json')}
neighbours=[]
for sid,pid,phase in c.standing(records,'1835-07-01'):
 if sid=='wolf_point_tavern' or records[sid]['archetype'] in ['bridge_timber','pier_crib','camp'] or phase.get('drawn_by'):continue
 poly=c.world_polygon(phase,datum);dist=polydist(new,poly)
 if dist<40:neighbours.append({'structure':sid,'phase':pid,'old_separation_m':polydist(old,poly),'new_separation_m':dist})
extra=json.loads((H/'proposed-extra-door-apron.json').read_text());de=prop['phases'][0]['position']['utm_e']-base['phases'][0]['position']['utm_e'];dn=prop['phases'][0]['position']['utm_n']-base['phases'][0]['position']['utm_n'];apron=[(p[0]+de,p[1]+dn) for p in extra['apron']];zone=[(p[0]+de,p[1]+dn) for p in extra['doorway_zone']]
apron_obstacles=[]
for row in neighbours:
 other=records[row['structure']];ph=next(p for p in other['phases'] if p['id']==row['phase']);poly=c.world_polygon(ph,datum);apron_obstacles.append({'structure':row['structure'],'apron_clearance_m':polydist(apron,poly),'doorway_zone_clearance_m':polydist(zone,poly)})
water=json.loads((S/'data/terrain/epochs/e1834_harbor_cut/river.geojson').read_text());waters=[]
for feat in water['features']:
 if feat['geometry']['type']!='Polygon':continue
 ring=[(p[0]-datum['origin_utm_e'],p[1]-datum['origin_utm_n']) for p in feat['geometry']['coordinates'][0]]
 if ring[0]==ring[-1]:ring.pop()
 waters.append({'id':feat.get('id'),'old_body_separation_m':polydist(old,ring),'new_body_separation_m':polydist(new,ring),'new_side_apron_separation_m':polydist(apron,ring),'new_side_door_zone_separation_m':polydist(zone,ring)})
report={'status':'focused_native_site_geometry_complete','CORRIDOR_LINE':CORRIDOR_LINE,'CORRIDOR_LINE_WHY':CORRIDOR_LINE_WHY,'datum_origin_utm_m':[datum['origin_utm_e'],datum['origin_utm_n']],'proposed_physical_polygon_world_local_ENU_m':new,'old_actual_drawn_corridor_laps':oldlaps,'new_actual_drawn_corridor_laps':newlaps,'nearest_drawn_corridors':sorted(corr,key=lambda r:r['new_clearance_to_finite_drawn_corridor_m'])[:6],'nearby_lots_within20m':sorted(lots,key=lambda r:(-r['new_overlap_m2'],r['separation_m'])),'nearest_native_lot_boundaries':sorted(lot_gaps,key=lambda r:r['minimum_separation_m'])[:3],'nearby_structures_within40m':sorted(neighbours,key=lambda r:r['new_separation_m']),'new_side_apron_and_doorway_neighbour_clearances':sorted(apron_obstacles,key=lambda r:r['doorway_zone_clearance_m']),'actual_scene_terrain_epoch':'e1834_harbor_cut','native_river_polygon_separations':waters,'scope_limits':'Measured against frozen actual native drawn street corridors, stored lot lines, selected1835 phase polygons and scene river outline. No survey-coordinate inference, control-line recentering, assets, heightfield/slope, furniture/flora/route, app/browser/full-gate certification. Positive line clearances are geometric results of reconstructed placement, not historical precision.'}
(H/(sys.argv[2] if len(sys.argv)>2 else 'site-check.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['nearby_lots_within20m','scope_limits']},indent=2));print('Nearby lot rows',len(lots));print(json.dumps(sorted(lots,key=lambda r:(-r['new_overlap_m2'],r['separation_m']))[:3],indent=2))
