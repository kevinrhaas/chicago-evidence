from pathlib import Path
from types import SimpleNamespace
import ast,json,math,sys
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;S=H/'site-inputs'
# Reuse the actual copied front-ring and transform function bodies, no broad town loop.
def funcs(path,names,ns):
 tree=ast.parse(path.read_text());exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),str(path),'exec'),ns)
ns={'math':math};funcs(S/'tools/generate_business_signboards.py',{'_to_enu','_front_edge'},ns)
for key in ['STRIP_DEPTH_M','STRIP_PAST_CORNER_M','PATH_SIDE_AT_STRIP_M','PATH_SIDE_OUT_M','PATH_DEPTH_M','PATH_TO_STREET_M','PATH_INTO_TRACK_M','PATH_ROUND_M']:
 tree=ast.parse((H/'candidate/chicago/4d/tools/generate_entrances.py').read_text());node=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==key for t in n.targets));exec(compile(ast.Module(body=[node],type_ignores=[]),'actual_apron_constants','exec'),ns)
funcs(H/'candidate/chicago/4d/tools/generate_entrances.py',{'_r','_front_ring'},ns)
# Geometry routines shared verbatim with site audit, no top-level execution.
mathns={'math':math};funcs(S/'tools/check_structure_corridors.py',{'_inside','_ring_samples','world_polygon'},mathns)
g={'math':math,'c':SimpleNamespace(_inside=mathns['_inside'])};funcs(H/'check_site.py',{'pointseg','cross','segdist','edges','polydist'},g)
datum=json.loads((S/'data/datum.json').read_text());r=json.loads(Path('/tmp/chicago-next-model/T-2386-topology/overlay/candidate/chicago/4d/data/structures/wolf_point_tavern.json').read_text());ph=r['phases'][0];sc=json.loads((S/'data/sidecars/1835/wolf_point_tavern.json').read_text());place=sc['placement'];river=json.loads((S/'data/terrain/epochs/e1834_harbor_cut/river.geojson').read_text());water=[(p[0]-datum['origin_utm_e'],p[1]-datum['origin_utm_n']) for p in river['features'][0]['geometry']['coordinates'][0]];water=water[:-1] if water[0]==water[-1] else water
baseOrigin=[place['local_e'],place['local_n']]
def t(u,v):return ns['_to_enu'](u,v,place)
# With every street >44m away, path_depth's14m search necessarily returns3.4.
primary=ns['_front_ring'](0.,5.,[(3.55,.45,3.4)],lambda s,t_:t(s,10.1+t_))
native_doc=json.loads((S/'data/enclosures/town_entrance_aprons.json').read_text())
u0,u1,vmax=ns['_front_edge'](sc['footprint']['polygon']);ends=[t(u0-ns['STRIP_PAST_CORNER_M'],vmax),t(u1+ns['STRIP_PAST_CORNER_M'],vmax)]
matching=[ring for ring in native_doc['ground']['interior_local_enu_m'] if len(ring)>1 and all(math.dist(ring[k],ends[k])<.02 for k in range(2))]
assert len(matching)==1,'native old apron ring ambiguous';oldprimary=matching[0]
side=json.loads((H/'proposed-extra-door-apron.json').read_text())['apron'];body=mathns['world_polygon'](ph,datum)
def water_result(poly):
 samples=mathns['_ring_samples'](poly,.1);inside=[p for p in samples if mathns['_inside'](p,water)];dist=g['polydist'](poly,water);depth=max((min(g['pointseg'](p,a,b) for a,b in g['edges'](water)) for p in inside),default=0.)
 return {'minimum_separation_m':dist,'boundary_samples_inside_water':len(inside),'approx_sampled_boundary_intrusion_m':depth}
def translated(poly,de,dn):return [(x+de,y+dn) for x,y in poly]
records={p.stem:json.loads(p.read_text()) for p in (S/'data/structures').glob('*.json')}
# All nearest solid polygons from earlier native audit, no terrain/furniture assumptions.
site=json.loads((H/'site-check.json').read_text());neighbours=[]
for q in site['nearby_structures_within40m']:
 rr=records[q['structure']];p=next(p for p in rr['phases'] if p['id']==q['phase']);neighbours.append((q['structure'],mathns['world_polygon'](p,datum)))
options=[]
for label,de,dn in [('L_origin_retained',0,0),('two_metres_west',-2,0),('three_metres_west',-3,0),('bbox_centre_preserved',-1.55,-2.4)]:
 row={'option':label,'record_origin_shift_ENU_m':[de,dn],'physical_bbox_centre_shift_vs_old_ENU_m':[1.55+de,2.4+dn],'body_to_river':water_result(translated(body,de,dn)),'primary_apron_to_river':water_result(translated(primary,de,dn)),'side_apron_to_river':water_result(translated(side,de,dn)),'nearest_body_neighbours':sorted([{'structure':sid,'clearance_m':g['polydist'](translated(body,de,dn),poly)} for sid,poly in neighbours],key=lambda q:q['clearance_m'])[:2]}
 options.append(row)
report={'status':'native_river_apron_followup','CORRIDOR_LINE':'drawn','CORRIDOR_LINE_WHY':'Actual apron/shore relation at stored local datum; no control-line recentering. This does not establish historic coordinate precision.','old_primary_apron_native_river':water_result(oldprimary),'old_apron_source':'Exact committed town_entrance_aprons ring, matched by its wall-span endpoints','proposed_primary_apron':primary,'options':options,'finding':'Retained-originL body is dry but its actual primary apron touches/enters native1835river. Side-entry apron is clear. A bounded location correction or revised source-backed smaller gauge must be reviewed before official integration; do not silently publish submerged wear.','new_coordinate_provenance_rule':'Any shifted working origin is reconstruction to preserve consistency with the committed1835river, not a coordinate derived from the retrospective picture. Existing20m across/40m along uncertainty remains; disclose position grade/ledger consequences.','limits':'Polygon plan comparison only; no heightfield terrain/erosion/historical surveyed bank or app QA. First apron source/kits remain reconstructed.'}
(H/'apron-water-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'old_apron':report['old_primary_apron_native_river'],'options':options},indent=2))
