from pathlib import Path
from types import SimpleNamespace
import ast,json,math,sys
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;S=H/'site-inputs'
def extract(path,names,ns):
 tree=ast.parse(path.read_text());exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),str(path),'exec'),ns)
ns={'Path':Path,'DATA':S/'data','math':math,'json':json};extract(S/'tools/measure_doorways.py',{'_inside','_seg_inside','_load','objects'},ns)
objs=ns['objects']();g={'math':math,'c':SimpleNamespace(_inside=ns['_inside'])};extract(H/'check_site.py',{'pointseg','cross','segdist','edges','polydist'},g)
site=json.loads((H/'site-check.json').read_text());body=site['proposed_physical_polygon_world_local_ENU_m'];e=json.loads((H/'proposed-extra-door-apron.json').read_text());side=e['doorway_zone'];primary=[[-67.2,-49.4],[-67.2,-47.9],[-65.4,-47.9],[-65.4,-49.4]]
def moved(poly,de,dn):return [[p[0]+de,p[1]+dn] for p in poly]
def hits(ring,except_serves=None):
 out=[]
 for layer,oid,kind,point,seg,serves in objs:
  if serves and except_serves and serves==except_serves:continue
  inside=ns['_inside'](point,ring) if point is not None else ns['_seg_inside'](*seg,ring)
  if inside:out.append({'layer':layer,'id':oid,'kind':kind,'point':point,'segment':seg,'serves':serves})
 return out
rows=[]
for label,de,dn in [('retained_origin_L',0,0),('centre_preserving_rebase',-1.55,-2.4)]:
 b=moved(body,de,dn);rows.append({'option':label,'primary_doorway_hits':hits(moved(primary,de,dn),except_serves='wolf_point_tavern'),'side_doorway_hits':hits(moved(side,de,dn),except_serves='wolf_point_tavern'),'native_points_or_fence_lines_inside_new_body':hits(b)})
report={'status':'native_placed_object_precheck','actual_object_reader':'copied measure_doorways.objects/_inside/_seg_inside, selected new doorway zones only','objects_read':len(objs),'cases':rows,'limits':'Existing generated placements are expected to need regeneration when footprint/door/origin changes. This precheck reads item points/fence segments, not mesh extents, radii or heightfields. Own stoop exemption applies to doorway floor only; body-intersection rows still require review.'}
(H/'object-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
