from pathlib import Path
import copy,json,difflib
H=Path(__file__).resolve().parent;rel='chicago/4d/data/structures/wolf_point_tavern.json';src=Path('/tmp/chicago-next-model/T-2386-topology/overlay/candidate')/rel
r=json.loads(src.read_text());p=r['phases'][0];pos=p['position'];pos['utm_e']=round(pos['utm_e']-1.55,2);pos['utm_n']=round(pos['utm_n']-2.4,2);pos['confidence']='reconstructed'
pos['note']+=' T-2386 CENTRE-PRESERVING REBASE supersedes the retained-origin L trial in the preceding paragraph. The former12x7m placeholder bbox centre is kept at its old world position while replacing its outline with7.2x10.1m L. At the retained90degree bearing this changes only the model-origin coordinates by(-1.55E,-2.40N)m; it does not move that coarse old world centre or derive a historical coordinate from picture pixels. Exact new origin and plan are reconstructed, so this position attribute is explicitly reconstructed; west-bank/relative-order textual sources and40m along/20m across uncertainty remain. Numeric anchor becomesE446993.85,N4637348.30. Compared with the original rectangle, south extent is now2.4m north, max-east frontage1.55m east and max-north extent2.4m south. Checks against the committed e1834_harbor_cut river (not the modern bank cited earlier) keep body/apron dry at about3.69/2.18m; these are model-clearance diagnostics, not historical bank setbacks or surveyed precision. No source has established an exact1835 location, and terrain/contact/application checks still follow normally.'
p['footprint']['note']+=' T-2386 centre-preserving rebase supersedes the retained-origin trial above: physicalL dimensions stay, but origin is rebased so old world bbox centre remains; exact origin/shape remain reconstructed. See the current position note for coordinates, grade and clearances.'
r['research_note']+=' The physicalL also rebases its local origin to preserve the old coarse world bbox centre; the retained-origin analytic trial would put part of the primary worn apron into the committed river. This is an explicit reconstructed model-coherence correction, not a picture-derived world location.'
dest=H/'placement-candidate'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(r,indent=2)+'\n')
patch=''.join(difflib.unified_diff(src.read_text().splitlines(True),dest.read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel));(H/'centre-preserving-origin.patch').write_text(patch)
(H/'POSITION-LIBERTY-APPEND.md').write_text('''### L-wolfpoint-centre-preserving-origin-2386 — rebase a reconstructed model origin

**Building:** Wolf Point Tavern.
**Decision:** Changing the former12x7m placeholder to a physical7.2x10.1m L must not silently choose a new world centre or leave its primary worn apron in the river. Rebase the local origin by(-1.55E,-2.40N)m toE446993.85,N4637348.30 at the retained90degree bearing, keeping the old bbox centre exactly. This is an explicitly reconstructed model-origin/plan choice, not a coordinate derived from tier5picture pixels or a new survey. The old coarse source-supported west-bank/relative-order site and40m along/20m across uncertainty remain. Position confidence is reconstructed to expose the exact new choice; no source is promoted to metric control. Relative to the old rectangle the final bbox centre is unchanged, while the different concave outline and the ShowMe vertex-mean centre differ as recorded in geometry receipts.

The retained-origin L trial's primary apron enters the native1835river by about0.39m. With the centre-preserving rebase its body and primary apron clear that committed river outline by about3.69m and2.18m, with nearest stable/store separations about9.15m and9.60m. These are runtime model-coherence checks at the committed datum, not measured historic setbacks or newly verified1835banks. Keep the phase dates, bearing, source credits and historical uncertainty. Sidecar/contact/terrain/entrance/route and app checks must regenerate normally; no asset hash or derived grade is handwritten.

**Covers:** `wolf_point_tavern.log_frame_1828.position`.
**Ticket:** T-2386.
**Recorded:** 2026-10-23.
''')
print(dest)
