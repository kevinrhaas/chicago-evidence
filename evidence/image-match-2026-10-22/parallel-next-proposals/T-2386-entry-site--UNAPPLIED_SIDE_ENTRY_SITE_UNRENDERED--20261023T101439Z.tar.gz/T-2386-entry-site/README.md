# Wolf Point L: side-entry reader and centre-preserving origin

Status: **FROZEN / UNAPPLIED / UNRENDERED**. This bounded followup belongs after the frozen physical-L overlay and before a future parent-coordinated preview/integration. It does not replace or mutate earlier packages. No canonical files, assets, browser sessions, ticket states or accepted reference views were changed. T-2386 remains open and `differs`.

## Decisions

`generate_entrances.front_doors()` means the primary +Y front wall. Its contract, primary stoop readers, IDs and existing output remain unchanged. The entrance/doorway system nevertheless promises to read every declared access door. The explicit L's +X entry therefore receives a separate `side_access_faces()` descriptor from the exact room opening tuple consumed by the mesh. The entrance consumer gives it its real wall line, outward bearing, own apron and clearance zone. Nothing is projected onto +Y or inferred from an unstated wall. There is no building-ID special case. Unknown explicit joint data raises instead of disappearing.

The only new helper is appended to `log_dwelling_params.py`; no parameter, positional constructor, CONSUMED field or mesh builder changes here. Defaults return no extra face. `generate_entrances.py` adds the bounded +X transform and records its dependency only when such a face exists. Its explicit `CORRIDOR_LINE="drawn"` declaration states the existing use of committed drawn travelled tracks for apron depth; it introduces no control-line recentering.

The frozen L trial retained the old numeric origin and thereby moved its bbox centre. Native checks found its primary worn apron entering the committed 1835 river outline by approximately 0.39 m. The preferred followup instead preserves the old geographic bbox centre exactly: origin changes by **(-1.55 E, -2.40 N) m**, to **E446993.85, N4637348.30**, retaining the 90 degree bearing. The common bbox centre is UTM **[446998.9, 4637344.7]**. This origin/plan choice is explicitly **reconstructed**, with a position liberty. It derives from keeping an existing model centre, never picture pixels, surveyed parcel boundaries or a newly verified historic riverbank. Coarse west-bank/relative-order sources and the 40 m along / 20 m across uncertainty remain. Shape and vertex-mean ShowMe centre differ; “bbox centre preserved” does not mean every geometric centre is identical.

## Apply order and scope

Use selective current-checkout integration, not a wholesale old snapshot restoration:

1. After the parent finishes frame/fort and the latest Hogan/source-S work, rematerialize `/tmp/chicago-next-model/log81-materializer/05f6-sourceS-final` through its selective helper into a **new** temporary review tree against that checkout. Preserve current independent source credits, rights, Hogan values and other record edits; inspect conflicts. Its combined code plus six actual visible opt-ins remains one eventual prerequisite PR. No invisible code-only waiting PR is needed.
2. Adopt that final log81 candidate, including visible Miller joints and final Hogan continuation, with its documented 81-asset freshness scope.
3. Apply `/tmp/chicago-next-model/T-2386-topology/overlay/T-2386-L-overlay.patch` directly on that base. This replaces the first Wolf Point chimney-only increment with the physical concave L. **Do not apply `/tmp/chicago-next-model/T-2386-next`**, the superseded parallel-gable trial.
4. Apply `side-entry-consumer.patch` here: two files (`log_dwelling_params.py`, `generate_entrances.py`). A prior/current parent edit to either file needs a selective merge preserving this bounded helper/consumer behavior.
5. Apply `centre-preserving-origin.patch` here: one Wolf Point record delta against the frozen L record. Preserve any later independent record changes rather than replacing the record wholesale.
6. Append final helper `liberty-append.md` (8 entries / 28 Covers), frozen L `LIBERTY-APPEND.md` (1 / 10), then this `POSITION-LIBERTY-APPEND.md` (1 / 1). Retain the L package's two additional note-reader paths (`compound_joint.note`, `roof_pipe.note`) and the final helper's six note paths. Position notes are already read; this followup adds no note-reader path. Normal source/grade/liberty compilation follows. Do not add the tier-5 form picture to position sources.
7. Obtain a parent-granted isolated **actual L model preview** before accepting this proposed geometry. The reconstructed research camera and local mesh stay unchanged by the origin rebase. Its numerical corner fit is not a rendered match or a solved metric station.
8. If the actual preview supports adoption, perform one official pinned **all-81** log-family refresh and dependent regeneration, full gates and app QA under parent control. Original school, Cobweb, Miller, Carpenter, Wolf Point and Hogan image-match tickets remain open; only the shared-controls prerequisite may close.

No final-liberty name, source ID, camera or acceptance claim is invented here. The governing form source remains the credited 1867 NYPL sheet depicting 1833; the frozen L package records the other views and retrospective/chronology limits.

## Native-site findings

The preferred record's physical concave L, rather than its old rectangular bbox, was checked with copied native corridor/lot readers and scene geometry. Drawn street corridor laps remain empty. Nearest Lake legal corridor is 42.15 m away; its travelled track is 49.09 m away. No native lot lies within 20 m; the nearest actual stored lot boundary is 66.54 m away. **There is no assigned platted lot or historical parcel setback claim, and no fabricated 1.5 m lot-margin pass.**

Against the committed `e1834_harbor_cut` river polygon, body clearance is 3.69 m, primary apron 2.18 m, side apron 11.45 m and side doorway zone 12.56 m. Nearest stable/store body separations are 9.15 / 9.60 m. These positive distances are model-coherence diagnostics against committed geometry, not metric historical evidence or terrain/heightfield certification.

**Required integration followup:** existing generated `town_trade_goods.json` has four instances inside the new physical body: two barrel points at ENU [-69.75,-47.77] and [-69.75,-50.57], plus two crate instances sharing [-69.75,-51.90]. Do not whitelist or hand-move them. Regenerate normal yard goods after the sidecars/entrances update, then check actual mesh/wall/door clearances and app behavior. The precheck found no primary/side doorway hits among 3,529 current points/fence segments, but it does not test object radii, extents or heightfields.

`front_doors` continues to supply the main-front stoop/front-row selection. Global entrance aprons and doorway zones now include the side entry, automatically reaching the existing yard-outbuilding, woodpile, fence and doorway-measure readers. Confirm their normal regeneration/check results during integration. The walker still collides with the solid concave building footprint; this is an external access/ground/clearance reader, **not** an interior passage or walk-through doorway implementation. ShowMe/feet/collision already use the physical six-edge polygon, as tested in the frozen L package.

## Verification receipts and replay

- `consumer-check.json`: actual copied native town output exactly equal with the feature off (652 entries, 651 rings); all existing entries and primary IDs preserved under the L; exactly one added side door; +X transforms/outward bearing at four rotations, CCW apron, malformed explicit joint rejection. It executes actual copied function bodies plus actual current facade resolvers. The later test-only narrowing of the rotation fixture does not alter production code or these assertions.
- `params-check.json`: all 81 frozen final-log81 assets retain exact raw vertices/faces/material/confidence with this helper; L raw mesh unchanged; origin rebase changes no local parameters/mesh; whole consumer import and record schema passed.
- `position-liberty-check.json`: actual compiler parser accepts 8 + 1 + 1 entries / 28 + 10 + 1 Covers; position reconstructed; tier-5 form source absent from position sources; actual forward coverage reports zero errors.
- `site-check-rebased.json`, `apron-water-check.json`, `object-check.json`: native geometry/placed-object results and explicit limits. Retained-origin diagnostics remain for comparison, not an additional proposed variant.
- Both patches passed `git apply --check` against their exact copied/frozen baselines. `inputs.json` receipts bind the two side-entry baseline/candidate files. `ARTIFACTS.json` binds this package. No Blender, GLB export, browser, publisher, official manifest writes or full gate was run.

Recovery requires this directory plus the complete frozen `T-2386-topology` and `log81-materializer` packages at their recorded `/tmp/chicago-next-model` paths. Most site inputs are copied here. The lightweight module/default/consumer scripts also use read-only current support modules under `/workspace/chicago/chicago/4d` and the existing Python environment; inspect changes before replay against another checkout. `prepare.py` and `prepare_rebase.py` document construction and are **not replay-safe after freeze**: the first snapshots current checkout inputs. Replay the focused checks or materialize into a new directory instead of rerunning preparation here.

Patch dry runs:

```sh
cd /tmp/chicago-next-model/T-2386-entry-site/baseline
git apply --check ../side-entry-consumer.patch
cd /tmp/chicago-next-model/T-2386-topology/overlay/candidate
git apply --check /tmp/chicago-next-model/T-2386-entry-site/centre-preserving-origin.patch
```

Optional lightweight checks (write receipts only here): `python3 check_params.py`, `python3 check_consumer.py`, `python3 check_position_liberty.py`, `python3 check_site.py placement-candidate/chicago/4d/data/structures/wolf_point_tavern.json site-check-rebased.json`, `python3 check_apron_site.py`, `python3 check_objects.py` from this directory. No additional run is needed to preserve the existing receipts.

Future canonical commands belong to the parent-coordinated integration, not this proposal: normal `tools/compile_scene.py --all`, `tools/compile_liberties.py`, `tools/generate_entrances.py`, `tools/generate_yard_goods.py` and other affected generators, then normal checks including `tools/measure_doorways.py --gate` and `tools/check_structure_corridors.py --gate`, official pinned all-81 assets/derivatives, full gates and app QA. No hand-edited hashes or derived grades.
