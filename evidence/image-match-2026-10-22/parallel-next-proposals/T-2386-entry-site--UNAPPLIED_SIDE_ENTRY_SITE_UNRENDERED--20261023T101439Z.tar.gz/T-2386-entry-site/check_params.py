from pathlib import Path
from types import ModuleType
from dataclasses import asdict
import json,sys,hashlib,math
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;F=Path('/tmp/chicago-next-model/log81-materializer/05f6-sourceS-final');L=Path('/tmp/chicago-next-model/T-2386-topology/overlay/candidate/chicago/4d');N=H/'candidate/chicago/4d'
sys.path.insert(0,str(F/'review-tree/chicago/4d/generators'));sys.modules['bpy']=ModuleType('bpy')
def load(n,path):
 m=ModuleType(n);m.__file__=str(path);sys.modules[n]=m;exec(compile(path.read_text(),str(path),'exec'),m.__dict__);return m
old=load('old_consumer_params',L/'generators/archetypes/log_dwelling_params.py');new=load('new_consumer_params',N/'generators/archetypes/log_dwelling_params.py')
sys.modules['archetypes.log_dwelling_params']=old;a=load('old_consumer_mesh',L/'generators/archetypes/log_dwelling.py');sys.modules['archetypes.log_dwelling_params']=new;b=load('new_consumer_mesh',L/'generators/archetypes/log_dwelling.py')
from common.mesh import MeshBuilder
class Raw(MeshBuilder):
 def to_object(self,materials=None):self.materials=materials;return self
for m in [a,b]:m.MeshBuilder=Raw;m.simple_material=lambda *a,**kw:(a,kw)
def raw(q):return q.verts,q.faces,q.conf,q.mat_index,q.named,q.materials
scope=json.loads((F/'freshness-scope.json').read_text());count=0
for row in scope['assets']:
 r=json.loads((F/f"review-tree/chicago/4d/data/structures/{row['structure_id']}.json").read_text());ph=next(p for p in r['phases'] if p['id']==row['phase_id']);p=old.from_phase(ph,r);q=new.from_phase(ph,r);assert asdict(p)==asdict(q);name=Path(row['asset']).stem;assert raw(a.build(p,name))==raw(b.build(q,name));assert new.side_access_faces(q)==[];count+=1
r=json.loads((H/'placement-candidate/chicago/4d/data/structures/wolf_point_tavern.json').read_text());ph=r['phases'][0];p=old.from_phase(ph,r);q=new.from_phase(ph,r);assert asdict(p)==asdict(q) and raw(a.build(p,'wolf_point_tavern__log_frame_1828'))==raw(b.build(q,'wolf_point_tavern__log_frame_1828'))
faces=new.side_access_faces(q);assert len(faces)==1 and faces[0]['face']=='+x' and faces[0]['plane_m']==7.2 and faces[0]['openings'][0]['u0']==2.9
oldr=json.loads((L/'data/structures/wolf_point_tavern.json').read_text());assert asdict(new.from_phase(oldr['phases'][0],oldr))==asdict(q),'world rebase changed local mesh params'
# Preserve original world bbox centre arithmetically; this is not an image coordinate solve.
before=(446995.4+7/2,4637350.7-12/2);after=(ph['position']['utm_e']+10.1/2,ph['position']['utm_n']-7.2/2);assert math.dist(before,after)<1e-6
import jsonschema
jsonschema.validate(r,json.loads((F/'review-tree/chicago/4d/data/structures.schema.json').read_text()))
# Whole candidate consumer module import with normal current dependencies; __file__
# selects read-only checkout support, not a runnable copied tree. No main/generation.
sys.path.insert(0,'/workspace/chicago/chicago/4d/tools');sys.path.insert(0,'/workspace/chicago/chicago/4d/generators')
m=ModuleType('generate_entrances');m.__file__='/workspace/chicago/chicago/4d/tools/generate_entrances.py';sys.modules['generate_entrances']=m
exec(compile((N/'tools/generate_entrances.py').read_text(),str(N/'tools/generate_entrances.py'),'exec'),m.__dict__)
sc=json.loads((H/'site-inputs/data/sidecars/1835/wolf_point_tavern.json').read_text());sc['form']=ph['form'];sc['footprint']=ph['footprint'];assert m.side_access_faces(sc)==faces
report={'status':'passed','all81_final_log81_helper_only_raw_material_conf_parity':count,'physical_L_raw_mesh_unchanged_by_access_helper':True,'origin_rebase_changes_no_local_mesh_params_or_geometry':True,'original_world_bbox_centre_preserved_utm_m':after,'position_confidence':'reconstructed; exact model origin openly admitted','whole_consumer_module_import_with_current_read_only_support':'passed','declared_side_face_from_whole_import':faces,'record_schema':'passed','limits':'Focused raw/model/API/import checks only; no GLB/export/browser/canonical generation or full gate. Shared params bytes still require81recipe refresh within official integration.'}
(H/'params-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
