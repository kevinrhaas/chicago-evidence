from pathlib import Path
from types import ModuleType,SimpleNamespace
import sys,ast,json,math,re,copy,hashlib
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;S=H/'site-inputs';G=Path('/workspace/chicago/chicago/4d/generators');sys.path.insert(0,str(G))
def load(name,path):
 m=ModuleType(name);m.__file__=str(path);sys.modules[name]=m;exec(compile(path.read_text(),str(path),'exec'),m.__dict__);return m
p=load('side_contract_params',H/'candidate/chicago/4d/generators/archetypes/log_dwelling_params.py');sys.modules['archetypes.log_dwelling_params']=p
from archetypes import facade_openings as facade,frame_dwelling_params,frame_storefront_params,outbuilding_params
# All primary front calculations are actual facade_openings + actual archetype resolvers.
resolvers={'log_dwelling':p.from_phase,'frame_dwelling':frame_dwelling_params.from_phase,'frame_storefront':frame_storefront_params.from_phase,'outbuilding':outbuilding_params.from_phase}
source_overrides={}
def data_load(path):
 return source_overrides.get(path.stem) or json.loads(path.read_text())
gns={'json':json,'math':math,'Path':Path,'STRUCTURES':S/'data/structures','TARGET_DATE':'1835-07-01','_RESOLVERS':resolvers,'facade_openings':facade,'_load':data_load}
gtree=ast.parse((S/'tools/generate_business_signboards.py').read_text());names={'_front_wall','_front_edge','_to_enu','_nearest_on_path'}
exec(compile(ast.Module(body=[n for n in gtree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),'actual_gbs_helpers','exec'),gns)
gbs=SimpleNamespace(**{k:gns[k] for k in names},_log_dwelling_params=p.from_phase,facade_openings=facade)
gfw=SimpleNamespace(_nearest_on_path=gns['_nearest_on_path'])
constnames={'ENTRANCE_KINDS','GROUND_Z_M','TAVERN_DOOR_W_M','STRIP_DEPTH_M','STRIP_PAST_CORNER_M','PATH_SIDE_AT_STRIP_M','PATH_SIDE_OUT_M','PATH_DEPTH_M','PATH_TO_STREET_M','PATH_INTO_TRACK_M','PATH_ROUND_M','OPENING_GAP_M','SHOPFRONT','DOORWAY_SIDE_M','DOORWAY_OUT_M'}
def entrance_ns(path):
 tree=ast.parse(path.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in constnames for t in n.targets)]
 ns={'math':math,'json':json,'re':re,'Path':Path,'gbs':gbs,'gfw':gfw,'SIDECARS':S/'data/sidecars/1835','STREETS':S/'data/streets/1835.json','_log_side_access_faces':p.side_access_faces}
 exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),ns);return ns
old=entrance_ns(H/'baseline/chicago/4d/tools/generate_entrances.py');new=entrance_ns(H/'candidate/chicago/4d/tools/generate_entrances.py')
a=old['build']();b=new['build']();assert a==b,'native town record changed with no new side faces'
assert not new['side_access_faces']({'archetype':'bridge_timber'})
rec=json.loads(Path('/tmp/chicago-next-model/T-2386-topology/overlay/candidate/chicago/4d/data/structures/wolf_point_tavern.json').read_text());ph=rec['phases'][0];native=new['_sidecars']();sc=copy.deepcopy(next(s for s in native if s['id']=='wolf_point_tavern'));sc['form']=copy.deepcopy(ph['form']);sc['footprint']=copy.deepcopy(ph['footprint']);source_overrides['wolf_point_tavern']=rec
selected=[sc if q['id']==sc['id'] else q for q in native]
old['_sidecars']=new['_sidecars']=lambda:selected
before=old['build']();after=new['build']();prior=next(x for x in before['entrances'] if x['structure_id']==sc['id']);primary=next(x for x in after['entrances'] if x['id']==prior['id']);assert primary==prior
extra=[x for x in after['entrances'] if x['id'] not in {q['id'] for q in before['entrances']}];assert len(extra)==1
x=extra[0];assert x['id']=='wolf_point_tavern__side_xp_door_1' and x['bearing_deg']==180 and x['width_m']==.9
pos=sc['placement'];point=gbs._to_enu(7.2,3.35,pos);assert x['at_local_enu_m']==[round(v,2) for v in point]
assert len(after['ground']['interior_local_enu_m'])==len(before['ground']['interior_local_enu_m'])+1
assert all(q in after['entrances'] for q in before['entrances'])
assert after['ground']['interior_local_enu_m'][:-1] != []
# New ring lies along +X outward basis and has the same CCW winding as primary rings.
ring=after['ground']['interior_local_enu_m'][next(i for i,(u,v) in enumerate(zip(after['ground']['interior_local_enu_m'],before['ground']['interior_local_enu_m'])) if u!=v)] if False else None
newrings=[r for r in after['ground']['interior_local_enu_m'] if r not in before['ground']['interior_local_enu_m']];assert len(newrings)==1;ring=newrings[0]
def area(poly):return sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(poly,poly[1:]+poly[:1]))/2
assert area(ring)>0 and all(poly in after['ground']['interior_local_enu_m'] for poly in before['ground']['interior_local_enu_m'])
# Doorway sweep includes this exact real side entry, with outward clearance.
selected=[sc]
(H/'proposed-Wolf-entrance-record.json').write_text(json.dumps(new['build'](),indent=2)+'\n')
zones=dict(new['doorway_zones']());assert x['id'] in zones
zone=zones[x['id']];assert all(v[1]<=point[1]+.01 for v in zone),'south-facing doorway falsely extends east/into wall'
for rotation in [0,37,90,193]:
 sc['placement']={**pos,'rotation_deg':rotation};trial=new['build']();door=next(d for d in trial['entrances'] if d['id']==x['id']);expected=gbs._to_enu(7.2,3.35,sc['placement']);assert door['at_local_enu_m']==[round(v,2) for v in expected];assert door['bearing_deg']==round((rotation+90)%360,2)
sc['placement']=pos
# Invalid explicit joint cannot quietly disappear as unsupported.
bad=copy.deepcopy(sc);bad['form']['compound_joint']['value']='unknown'
try:new['side_access_faces'](bad)
except p.ParamError:pass
else:raise AssertionError('malformed explicit side joint silently accepted')
report={'status':'passed','actual_primary_front_function_contract':'front_wall +Y only, unchanged','consumer_scope':'town entrance/doorway ground/clearance promises every declared access door; extra +X must be read separately','native_default_generated_document_equal':True,'native_default_entries':len(a['entrances']),'native_default_rings':len(a['ground']['interior_local_enu_m']),'unchanged_primary_and_all_existing_entries_under_L':True,'new_side_entry':x,'new_side_apron_ring':ring,'new_side_doorway_zone':zone,'correct_plusX_transform_and_outward_bearing_at4rotations':True,'apron_CCW_winding':True,'unknown_explicit_joint_rejected':True,'no_id_special_case':True,'source_of_geometry':'actual shared params side_access_faces, same explicit room rectangle used by mesh','limits':'Copied entrance function AST bodies and actual current primary facade resolvers. No generated canonical file, assets, browser, full gate or placement claim.'}
(H/'consumer-check.json').write_text(json.dumps(report,indent=2)+'\n');(H/'proposed-extra-door-apron.json').write_text(json.dumps({'entrance':x,'apron':ring,'doorway_zone':zone},indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['new_side_apron_ring','new_side_doorway_zone']},indent=2))
