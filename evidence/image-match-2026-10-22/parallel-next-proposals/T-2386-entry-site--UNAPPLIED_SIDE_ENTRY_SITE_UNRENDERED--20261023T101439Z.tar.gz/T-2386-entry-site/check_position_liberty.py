from pathlib import Path
from types import ModuleType
import sys,json,ast
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent
F=Path('/tmp/chicago-next-model/log81-materializer/05f6-sourceS-final'); B=F/'review-tree/chicago/4d'
T=Path('/tmp/chicago-next-model/T-2386-topology')
def load(n,p):
 m=ModuleType(n);m.__file__=str(p);sys.modules[n]=m;exec(compile(p.read_text(),str(p),'exec'),m.__dict__);return m
lib=load('entry_site_liberty_compiler',B/'tools/compile_liberties.py')
names={sid:json.loads((B/f'data/structures/{sid}.json').read_text())['name'] for sid in ['chappel_infant_school','cobweb_castle','miller_house','philo_carpenter_log_shop','wolf_point_tavern','hogan_store']}
entries=[];counts=[]
for p in [F/'liberty-append.md',T/'LIBERTY-APPEND.md',H/'POSITION-LIBERTY-APPEND.md']:
 es,problems=lib.parse('## Per-subject liberties\n\n'+p.read_text(),names,sources={})
 assert not problems,problems
 entries+=es;counts.append({'file':str(p),'entries':len(es),'covers':sum(len(e['covers']) for e in es)})
assert len(entries[-1]['covers'])==1 and entries[-1]['covers'][0]=={'domain':'structure','structure':'wolf_point_tavern','phase':'log_frame_1828','aspect':'position'}
ledger=json.loads((B/'data/liberties.json').read_text());ledger['liberties']+=entries
nodes=[n for n in ast.parse((B/'tools/validate.py').read_text()).body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in {'Report','graded_values','inferred_values','unbuilt_values','check_liberties_coverage'}]
ns={'PHASE_ASPECTS':('footprint','position','documented_range'),'STRUCTURE_ASPECTS':('function','occupants','present_status','built'),'GEOMETRY_OWES_LIBERTY':('absent','simplified')};exec(compile(ast.Module(body=nodes,type_ignores=[]),'actual_contracts','exec'),ns)
p=load('entry_site_params_contract',H/'candidate/chicago/4d/generators/archetypes/log_dwelling_params.py')
r=json.loads((H/'placement-candidate/chicago/4d/data/structures/wolf_point_tavern.json').read_text())
assert r['phases'][0]['position']['confidence']=='reconstructed'
assert 'blanchard_shober_1867_wolf_point' not in r['phases'][0]['position'].get('sources',[])
rep=ns['Report']();ns['check_liberties_coverage']({'wolf_point_tavern':r},ledger,rep,{'log_dwelling':p.CONSUMED},forward_only=True)
assert not rep.errors,rep.errors
out={'status':'passed','liberty_inputs':counts,'position_cover':'wolf_point_tavern.log_frame_1828.position','position_confidence':'reconstructed','tier5_form_source_not_added_to_position_sources':True,'actual_forward_coverage_errors':0,'limits':'Actual parser/forward coverage against frozen final-log81 contracts. No canonical compiler outputs or full gate.'}
(H/'position-liberty-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
