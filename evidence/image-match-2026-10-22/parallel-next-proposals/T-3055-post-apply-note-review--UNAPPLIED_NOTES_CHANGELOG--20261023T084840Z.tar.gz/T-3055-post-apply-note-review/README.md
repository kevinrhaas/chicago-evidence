# Current Tremont note corrections after T-3055 helper

Review found six current-facing text contradictions in the frozen integration candidate.
The actual mesh uses 3.1/2.35/2.35 m storey divisions, a32-degree roof and an opaque arched panel without radial glazing; the app now mounts flag cloth with an explicit phase/date-local anchor. Older form notes/research still described equal2.6m floors,38degrees, glazing/radials and an unavailable cloth attachment.

Do not edit the frozen helper. After root applies it, validate then apply these exact-field corrections before the official23-family bake/compilation:

```sh
python /tmp/chicago-next-model/T-3055-post-apply-note-review/correct_notes.py --repo /workspace/chicago
python /tmp/chicago-next-model/T-3055-post-apply-note-review/correct_notes.py --repo /workspace/chicago --apply
```

The script guards old note text, phase identity and relevant actual values/grades. A drift refuses. Already corrected values are accepted. It changes five form notes and prepends a final-current Research paragraph while preserving the complete historical second-proposal snapshot. A structural comparison refuses any non-note mutation. It uses atomic single-file replacement. `review-check.json` validates the materialized final review tree; `temporary-apply-check.json` records a successful isolated temporary-copy apply and second apply was idempotent. No canonical repo or frozen helper input was changed, and no official bake/app/full gate is claimed.

`T-3055.six-items.json` is an optional replacement combined changelog candidate:10 title words,6items,141total words. It leads with visible model changes and preserves the fact that original picture comparisons still differ.
