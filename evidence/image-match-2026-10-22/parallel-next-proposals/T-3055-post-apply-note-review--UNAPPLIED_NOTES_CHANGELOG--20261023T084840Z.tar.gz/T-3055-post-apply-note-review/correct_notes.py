#!/usr/bin/env python3
"""Correct current Tremont notes after the frozen T-3055 helper is applied.

Default mode validates only. --apply changes only the six specified note values.
An already-corrected field is accepted; a different note/value/grade is refused.
"""
import argparse
import copy
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
REL = Path('chicago/4d/data/structures/tremont_house_1.json')


def at(obj, path):
    for key in path:
        obj = obj[key]
    return obj


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    spec = json.loads((HERE / 'note-changes.json').read_text())
    path = args.repo / REL
    original = json.loads(path.read_text())
    if original['id'] != spec['record_id'] or original['phases'][0]['id'] != spec['phase_id']:
        raise SystemExit('REFUSED: record/phase differs from reviewed Tremont')
    result = copy.deepcopy(original)
    changed = []
    for change in spec['changes']:
        guard = change.get('guard')
        if guard:
            attr = at(original, guard['path'])
            for key in ('value', 'confidence'):
                if attr.get(key) != guard[key]:
                    raise SystemExit(f"REFUSED: {guard['path']} {key} changed")
        current = at(original, change['path'])
        if current == change['new']:
            continue
        if current != change['old']:
            raise SystemExit(f"REFUSED: note drift at {change['path']}")
        parent = at(result, change['path'][:-1])
        parent[change['path'][-1]] = change['new']
        changed.append(change['path'])
    # No geometry, date, provenance grade or source-ID edits are permitted here.
    restored = copy.deepcopy(result)
    for change in spec['changes']:
        at(restored, change['path'][:-1])[change['path'][-1]] = at(original, change['path'])
    if restored != original:
        raise SystemExit('REFUSED: correction includes a non-note mutation')
    receipt = {'record': str(path), 'changed_note_paths': changed,
               'geometry_values_dates_grades_sources_unchanged': True,
               'applied': args.apply}
    if args.apply and changed:
        tmp = path.with_name('.' + path.name + '.note-correction.tmp')
        try:
            tmp.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
            os.chmod(tmp, path.stat().st_mode)
            os.replace(tmp, path)
        finally:
            tmp.unlink(missing_ok=True)
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
