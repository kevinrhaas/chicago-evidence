"""Proposal-local fault injection only; not part of durable repository patch."""
import pathlib,importlib.util,unittest,dataclasses
from unittest.mock import patch
path=pathlib.Path(__file__).parent/'proposed/chicago/4d/tools/test_frame_tavern_picture_features.py'
spec=importlib.util.spec_from_file_location('frame_picture_test_mutations',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def rejected(name,test,attribute,replacement,owner=None):
 with patch.object(owner or m.builder,attribute,replacement):
  result=unittest.TestResult();m.PictureFeatures(test).run(result)
 assert result.failures and not result.errors,(name,result.errors,result.failures)
 print('PASS expected assertion detected deliberate fault:',name)
rejected('roof-material gables instead of clapboard','test_gable_wall_cladding_both_axes_preserves_roof_planes','_wall_clad_gable_roof',lambda b,p,w,d,z,c,ridge_along_x:b.add_gable_roof(0,0,w,d,z,p.roof_pitch_deg,c,m.builder.M_ROOF,ridge_along_x=ridge_along_x))
rejected('missing Sauganash main-end sash','test_sauganash_only_states_three_main_end_sash','_end_windows',lambda *a,**kw:None)
original=m.from_phase
def no_override(phase,record):
 p=original(phase,record)
 return dataclasses.replace(p,eaves_bays={}) if record['id']=='green_tree_tavern' else p
rejected('ignored GreenTree face override','test_green_tree_override_changes_only_named_eaves_face','from_phase',no_override,owner=m)
rejected('missing Tremont shutter geometry','test_tremont_openings_shutters_and_raised_entries','_corner_shutters',lambda *a,**kw:None)
print('All four deliberate faults refused; no repository files modified.')
