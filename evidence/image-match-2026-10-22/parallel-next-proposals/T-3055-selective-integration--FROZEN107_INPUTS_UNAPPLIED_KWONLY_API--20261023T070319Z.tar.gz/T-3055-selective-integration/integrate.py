#!/usr/bin/env python3
"""Materialize a selective T-3055 review tree; writes the repo only with --apply.

No stash restore, git state mutation, bake, publisher, manifests or sidecars.
Inputs are frozen inside this package, so later dev/Hogan merges are supported.
"""
from __future__ import annotations
import argparse
import copy
import difflib
import hashlib
import json
from pathlib import Path
import re
import tempfile

PACKAGE = Path(__file__).resolve().parent
PAYLOAD = PACKAGE / 'payload'
PREFIX = 'chicago/4d/'
RESEARCH = PREFIX + 'docs/RESEARCH/frame-picture-match-T-2376-T-2385/'
MISSING = object()
NAME_PATHS = ['eaves_bays', 'end_windows', 'entry_raise_m', 'first_story_height_m',
              'flagstaff', 'flagstaff_height_m', 'gable_lunette', 'gable_wall_cladding',
              'gable_arch_treatment', 'corner_entry_surround', 'flag_anchor']
PROTECTED = [PREFIX+'data/structures/'+n+'.json' for n in
             ('hogan_store','st_marys_church','jb_beaubien_homestead','log_jail')]
STEPS = '''# T-2376/T-2383/T-2385: pictured frame controls on the real accumulator.
step "pictured frame taverns preserve defaults and build their opt-in details" \\
  python3 tools/test_frame_tavern_picture_features.py

# Roof cloth uses a phase-local staff, never an entire building box.
step "explicit flag anchors preserve fort defaults and reject stale roof mounts" \\
  node tools/test_flag_anchors.mjs

# Compiler/validator recognize real runtime consumption and honest card labels.
step "flag form values have an actual renderer and honest geometry labels" \\
  python3 tools/test_flag_form_contract.py

'''


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False)+'\n').encode()


def merge(old, final, current, path):
    """Apply only proposal differences, preserving unrelated current changes."""
    if old == final:
        return copy.deepcopy(current)
    if current == final:
        return copy.deepcopy(final)
    if isinstance(old, dict) and isinstance(final, dict) and isinstance(current, dict):
        out = copy.deepcopy(current)
        for key in sorted(old.keys() | final.keys()):
            a, b, c = old.get(key, MISSING), final.get(key, MISSING), current.get(key, MISSING)
            if a == b:
                continue
            if a is MISSING:
                if c is not MISSING and c != b:
                    raise RuntimeError(f'{path}.{key}: concurrent new value; review manually')
                out[key] = copy.deepcopy(b)
            elif b is MISSING:
                if c != a and c is not MISSING:
                    raise RuntimeError(f'{path}.{key}: concurrent value cannot be removed')
                out.pop(key, None)
            else:
                out[key] = merge(a, b, c, path+'.'+key)
        return out
    if (path.endswith('.phases') and all(isinstance(v, list) for v in (old, final, current))):
        oldmap, finalmap, curmap = ({p['id']:p for p in seq} for seq in (old, final, current))
        if oldmap.keys() != finalmap.keys() or not oldmap.keys() <= curmap.keys():
            raise RuntimeError(f'{path}: phase set changed; no automatic replacement')
        return [merge(oldmap[p['id']], finalmap[p['id']], p, path+'['+p['id']+']')
                if p['id'] in oldmap else copy.deepcopy(p) for p in current]
    if current != old:
        raise RuntimeError(f'{path}: current value differs from both frozen before and final')
    return copy.deepcopy(final)


def ledger_entry(text, identifier):
    found = re.search(r'^### '+re.escape(identifier)+r'\b.*?(?=^### |^## |\Z)', text, re.M|re.S)
    if not found:
        raise RuntimeError(f'Cannot locate ledger entry {identifier}')
    return found


def input_paths():
    paths = list(PACKAGE.glob('*.py'))
    for directory in ('payload', 'reference-patches'):
        paths.extend(p for p in (PACKAGE / directory).rglob('*') if p.is_file()
                     and '__pycache__' not in p.parts and p.suffix not in ('.pyc', '.pyo'))
    return {p.relative_to(PACKAGE).as_posix() for p in paths}


def frozen_inputs():
    manifest = json.loads((PACKAGE / 'package-inputs.json').read_text())
    if set(manifest) != input_paths():
        raise RuntimeError('Package gained/lost an unfrozen executable or payload input')
    for rel, expected in manifest.items():
        path = PACKAGE / rel
        if not path.is_file() or sha(path.read_bytes()) != expected:
            raise RuntimeError(f'Frozen package input changed: {rel}')
    return manifest


def apply_reviewed(root):
    """Two-phase staging plus rollback journal; consumes an unchanged review plan.

    Filesystem rename is atomic per file. A failed multi-file transaction rolls
    back already-renamed files; parent must remain the exclusive checkout writer.
    No git/index operation, bake, publish or other implicit follow-up is run.
    """
    import os
    inputs = frozen_inputs()
    plan_path = PACKAGE / 'integration-plan.json'
    plan_bytes = plan_path.read_bytes()
    if (PACKAGE / 'review-manifest.sha256').read_text().strip() != sha(plan_bytes):
        raise RuntimeError('Reviewed integration manifest changed; regenerate and review')
    plan = json.loads(plan_bytes)
    if Path(plan['repo']).resolve() != root or plan['frozen_inputs'] != inputs:
        raise RuntimeError('Review manifest targets a different repo/package; re-materialize and review')
    for rel, expected in plan['repo_inputs'].items():
        path = root / rel
        current = path.read_bytes() if path.exists() else None
        if (sha(current) if current is not None else None) != expected:
            raise RuntimeError(f'{rel}: repo input changed since review; regenerate the review plan')
    transaction = PACKAGE / 'apply-journal'
    transaction.mkdir(exist_ok=True)
    staged, applied = [], []
    try:
        # Validate every path/hash and write every replacement before changing
        # a single tracked target. The backup journal survives for recovery.
        for row in plan['writes']:
            rel = row['path']
            if Path(rel).is_absolute() or '..' in Path(rel).parts:
                raise RuntimeError('Unsafe reviewed target')
            target = root / rel
            if not target.resolve().is_relative_to(root):
                raise RuntimeError(f'{rel}: resolved outside repository')
            source = PACKAGE / 'review-tree' / rel
            data = source.read_bytes()
            if sha(data) != row['new_sha256']:
                raise RuntimeError(f'{rel}: reviewed replacement hash changed')
            before = target.read_bytes() if target.exists() else None
            backup = transaction / rel
            if before is not None:
                backup.parent.mkdir(parents=True, exist_ok=True)
                backup.write_bytes(before)
            target.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(prefix='.t3055-stage-', dir=target.parent, delete=False) as stream:
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
                temp = Path(stream.name)
            mode = target.stat().st_mode if target.exists() else 0o644
            temp.chmod(mode)
            staged.append((target, temp, before, mode))
        (transaction / 'transaction.json').write_bytes(json_bytes({'plan_sha256':sha(plan_bytes),'state':'fully staged, no targets renamed','writes':plan['writes']}))
        for target, temp, before, mode in staged:
            current = target.read_bytes() if target.exists() else None
            if current != before:
                raise RuntimeError(f'{target.relative_to(root)} changed during apply')
            temp.replace(target)
            applied.append((target, before, mode))
        for row in plan['writes']:
            assert sha((root / row['path']).read_bytes()) == row['new_sha256']
        for rel in plan['sourceS_and_Hogan_records_untouched']:
            path = root / rel
            value = path.read_bytes() if path.exists() else None
            assert (sha(value) if value is not None else None) == plan['repo_inputs'][rel]
        (transaction / 'transaction.json').write_bytes(json_bytes({'plan_sha256':sha(plan_bytes),'state':'all targets renamed and verified','writes':plan['writes']}))
    except BaseException:
        for target, before, mode in reversed(applied):
            if before is None:
                target.unlink(missing_ok=True)
            else:
                with tempfile.NamedTemporaryFile(prefix='.t3055-rollback-', dir=target.parent, delete=False) as stream:
                    stream.write(before)
                    restored = Path(stream.name)
                restored.chmod(mode)
                restored.replace(target)
        raise
    finally:
        for _, temp, _, _ in staged:
            temp.unlink(missing_ok=True)
    receipt = {'state':'all reviewed replacements committed; no bake/publish/manifests/sidecars',
               'plan_sha256':sha(plan_bytes),'files':len(applied),'frozen_inputs':inputs,
               'sourceS_and_Hogan_protected_records_untouched':plan['sourceS_and_Hogan_records_untouched']}
    (PACKAGE / 'apply-receipt.json').write_bytes(json_bytes(receipt))
    print(f'APPLIED {len(applied)} reviewed selective files; parent owns all build/QA/PR follow-up')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--apply', action='store_true', help='Apply only the freshly reviewed allowlist; default is package review-tree only')
    args = parser.parse_args()
    root = args.repo.resolve()
    if not (root / '.git').exists():
        raise SystemExit('--repo must be the chicago repository root')
    if args.apply:
        apply_reviewed(root)
        return
    inputs = frozen_inputs()
    output = PACKAGE / 'review-tree'
    planned = {}
    repo_inputs = {}
    def read(rel):
        path = root / rel
        data = path.read_bytes() if path.exists() else None
        fingerprint = sha(data) if data is not None else None
        if rel in repo_inputs and repo_inputs[rel] != fingerprint:
            raise RuntimeError(f'{rel}: input changed during review preparation')
        repo_inputs[rel] = fingerprint
        return data
    def put(rel, data, reason):
        if Path(rel).is_absolute() or '..' in Path(rel).parts:
            raise RuntimeError('Unsafe output path')
        before = read(rel)
        if before != data:
            planned[rel] = {'before':before, 'after':data, 'reason':reason}
    protected_before = {p:read(p) for p in PROTECTED}
    # Modules/tests are guarded exact replacements. No anonymous live branch
    # can silently become an old baseline, and no unrelated module is touched.
    finals = PAYLOAD / 'final'
    for path in sorted(finals.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or path.suffix in ('.pyc', '.pyo'):
            continue
        rel = path.relative_to(finals).as_posix()
        if rel.startswith(PREFIX+'data/structures/'):
            continue
        target, current = path.read_bytes(), read(rel)
        oldpath = PAYLOAD / 'old' / rel
        old = oldpath.read_bytes() if oldpath.exists() else None
        allowed = (old, target, None) if rel.endswith("/tools/test_frame_tavern_picture_features.py") else (old, target)
        if current not in allowed:
            raise RuntimeError(f'{rel}: concurrent code/test differs; no blind overwrite')
        put(rel, target, 'final frame/runtime source or durable focused test')
    # Field-level three-way merge on only these three records. The untouched
    # StMary/Beaubien/Jail/Hogan records are never opened for writing.
    for name in ('green_tree_tavern','sauganash_hotel','tremont_house_1'):
        rel = PREFIX+'data/structures/'+name+'.json'
        old = json.loads((PAYLOAD/'old'/rel).read_text())
        final = json.loads((finals/rel).read_text())
        current = json.loads(read(rel))
        for phase in old['phases']:
            cur = next(p for p in current['phases'] if p['id']==phase['id'])
            for key in ('position','footprint','documented_range'):
                if cur.get(key) != phase.get(key):
                    raise RuntimeError(f'{name}/{phase["id"]}.{key}: geographic/date baseline changed; review first')
        put(rel, json_bytes(merge(old, final, current, name)), 'only frozen final frame form/note deltas, retaining current unrelated keys')
    rel = PREFIX+'tools/check.sh'
    current = read(rel).decode()
    additions = []
    # Whole command identity makes re-running idempotent without replacing
    # other pending gate additions or sourceS checks.
    for block in STEPS.strip().split('\n\n'):
        command = block.splitlines()[-1].strip()
        if command not in current:
            additions.append(block+'\n\n')
    if additions:
        anchor = "# W1's forge stack, and the reason it is gated here rather than only on the baked\n"
        if current.count(anchor) != 1:
            raise RuntimeError('check.sh archetype anchor moved; insert the reviewed steps manually')
        current = current.replace(anchor, ''.join(additions)+anchor, 1)
        put(rel, current.encode(), 'three focused no-Blender steps; preserve all existing source/Hogan steps')
    rel = PREFIX+'data/reconstruction/name_pool_keys.json'
    pools = json.loads(read(rel))
    entries = pools['read']['structures']
    for field in NAME_PATHS:
        key = f'phases[].form.{field}.note'
        if key not in entries:
            index = next((i for i, value in enumerate(entries) if value > key), len(entries))
            entries.insert(index, key)
    put(rel, json_bytes(pools), 'declare all11 new source/reconstruction note paths; no undeclared capitalized names')
    rel = PREFIX+'data/structure_grades.json'
    grades = json.loads(read(rel));before_pictured = copy.deepcopy(grades['pictured'])
    grade = json.loads((PAYLOAD/'tremont-grade.json').read_text())
    matching = [g for g in grades['pictured'] if (g['scene'],g['structure'],g['picture']) == (grade['scene'],grade['structure'],grade['picture'])]
    if not matching:
        grades['pictured'].append(grade)
    # Existing StMary/sourceS and every other grade ruling are retained exactly.
    assert grades['pictured'][:len(before_pictured)] == before_pictured
    put(rel, json_bytes(grades), 'add Tremont whole-picture ruling only; retain sourceS and all other rulings')
    rel = PREFIX+'docs/LIBERTIES.md';text = read(rel).decode()
    original = (PAYLOAD/'ledger/L74-original.md').read_text()
    resolved = (PAYLOAD/'ledger/L74-resolved.md').read_text()
    actual = ledger_entry(text,'L74')
    if actual.group(0).rstrip() != resolved.rstrip():
        if actual.group(0).rstrip() != original.rstrip():
            raise RuntimeError('L74 has concurrent wording; refusing a non-verbatim move')
        oldbody = actual.group(0)
        text = text[:actual.start()]+text[actual.end():]
        anchor = '## Per-subject liberties'
        if not text.startswith('## Resolved', text.index('## Resolved')) or anchor not in text:
            raise RuntimeError('Resolved ledger section not found')
        text = text.replace(anchor, resolved.rstrip()+'\n\n'+anchor, 1)
        assert original.rstrip() in resolved
    for identifier in json.loads((PAYLOAD/'ledger/order.json').read_text()):
        block = (PAYLOAD/'ledger'/f'{identifier}.md').read_text().rstrip()
        try:
            existing = ledger_entry(text,identifier).group(0).rstrip()
        except RuntimeError:
            text = text.rstrip()+'\n\n'+block+'\n'
        else:
            if existing != block:
                raise RuntimeError(f'{identifier}: existing ledger wording differs; preserve append-only contract and review')
    put(rel,text.encode(),'verbatim L74 move to Resolved; five selected stash frame entries + two exact reconstructed-only follow-ups')
    rel=PREFIX+'assets/LICENSES.md';text=read(rel).decode();row=(PAYLOAD/'gifford-license-row.md').read_text().strip()
    if row not in text:
        anchor="Held out of the published tree entirely, by the user's instruction:"
        if anchor not in text:
            raise RuntimeError('Licence insertion anchor moved')
        text=text.replace(anchor,row+'\n\n'+anchor,1)
        put(rel,text.encode(),'only Gifford owner-approved attributed-use row; no public-domain assertion')
    for path in sorted((PAYLOAD/'research').rglob('*')):
        if path.is_file():
            rel=path.relative_to(PAYLOAD/'research').as_posix()
            existing=read(rel)
            if existing is not None and existing != path.read_bytes():
                raise RuntimeError(f'{rel}: existing research evidence differs; do not overwrite')
            put(rel,path.read_bytes(),'archived inspected prototype receipt/image, not canonical asset or accepted reference view')
    research_readme='''# T-3055 — Green Tree, Sauganash and first Tremont picture increments

All archived picture comparisons remain **differs**; no original ticket is closed,
no provisional camera is accepted and no research camera is placed in reference_views.
The old first-increment README and receipts remain under first-increment/ and the
per-target folders. They describe their own earlier frozen proposal, including its
then-bare roof spar. The new third-tremont/ archive adds opaque arch/plain entry
outlines and a separately labelled actual proposed app-flag diagnostic, held time0.

The source, previous and proposed standard captures use identical numeric/byte
cameras, source pictures, intrinsics/light and helpers. The fourth diagnostic
imports the actual proposed flags.js runtime layer rather than baking cloth. Its
explicit roof-spar mount draws one24-star flag with reconstructed confidence1 and
no runtime problems. The existing shared breeze presents it nearly edge-on; the
source flag projects left, so pose remains unresolved. All captures are isolated
prototypes, not an official bake/freshness acceptance or full app/mobile proof.

GreenTree gains seven pictured-side upper bays and main-gable wall cladding;
Sauganash gains two upper plus one attic main-end sash in white gable clapboard;
Tremont gains three shuttered storeys, raised entries, bounded opaque arch, four
stacks and a roof spar. Metric controls, hidden repeats, colour/finish choices
and chronology/camera/wing/context details stay explicit reconstruction or open.
The current footprints, geographic controls and building phase dates are retained.
The flag anchor's1836-07-03 limit bounds its24-star pattern and does not end the
building phase. Whole-building grade differs from per-attribute evidence.

Sources: public-domain US1884 Andreas/Braunhold retrospective plates for GreenTree
and Sauganash; N.Roswell Gifford first Tremont drawing reproduced by Chicagology,
https://chicagology.com/prefire/prefire021/. Owner-approved attributed project use
2026-10-22; original publication/collection/copyright unresolved, no public-domain
claim for Gifford. Source records and assets/LICENSES.md retain the limitations.

All ten new dataclass fields are keyword-only to preserve the original forty
positional parameters/defaults. The API follow-up proof records exact equality
of resolved params and accumulated geometry/material/confidence across24phases
against the executed preview proposal. Parameter source bytes changed: this
requires fresh recipes, never restamping the earlier GLBs or manifests.

The final source still requires a fresh canonical pinned23-family build, current
web derivatives/manifests/licences/grades/compiled sidecars and full local/remote
app/mobile/card checks. No old canonical GLBs, manifests or sidecars are restored
from a stash or copied from prototype outputs by this integration package.
'''
    put(RESEARCH+'README.md',research_readme.encode(),'current honest research overview; prior first-increment README preserved separately')
    status='''\n\n## T-3055 — bounded first frame-building picture increments (2026-10-23)

GreenTree's pictured seven-bay south wall and main-gable siding, Sauganash's main-end
upper/attic sash in white clapboard, and Gifford's three-storey shuttered first Tremont
are implemented as source-bounded first increments. Tremont's raised entries now
have plain outlines and its arch an opaque working field without invented lettering.
An explicit phase/date-local roof flag anchor and its compiler/validator contract
avoid hanging cloth from a whole hotel bounding box. Existing fort defaults remain.
Existing footprints, geographic controls and building phase dates are retained.

Actual isolated pinned emitter and unchanged-camera comparisons were inspected;
all verdicts remain **differs**. The actual held app-layer diagnostic draws one
reconstructed24-star flag on the roof spar with no reported problems, but shared
breeze makes it nearly edge-on instead of the source-left pose. Letters, joinery,
openings/roof/landing/stack/wing/context details and all full multi-view matches stay
open. No original image-match ticket closes. See RESEARCH/frame-picture-match-T-2376-T-2385.
Official23-family refresh, source/grade/sidecar provenance, published mobile/card
checks and required full gates must be recorded by integration before landing.
'''
    for file in ['docs/STATUS.md','docs/ROADMAP.md']:
        rel=PREFIX+file;text=read(rel).decode('utf-8', errors='surrogateescape')
        if '## T-3055 — bounded first frame-building picture increments' not in text:
            put(rel,read(rel)+status.encode()+b'\n','append frame-only honest progress; preserve current sourceS/Hogan notes')
    manifest=json.loads(read(PREFIX+'assets/manifest.json'))
    family=[{'asset':key,**entry} for key,entry in manifest['assets'].items() if entry.get('archetype')=='frame_tavern']
    ids=sorted({r['structure_id'] for r in family})
    plan={'repo':str(root),'frozen_inputs':inputs,'repo_inputs':repo_inputs,'base_head':'not pinned; preserves current sourceS/Hogan or later dev changes',
          'writes':[{'path':rel,'old_sha256':sha(v['before']) if v['before'] is not None else None,
                     'new_sha256':sha(v['after']),'bytes':len(v['after']),'reason':v['reason']}
                    for rel,v in sorted(planned.items())],
          'canonical_assets_restored':False,'manifests_sidecars_written':False,
          'sourceS_and_Hogan_records_untouched':PROTECTED,
          'name_pool_paths_added_or_retained':[f'phases[].form.{f}.note' for f in NAME_PATHS],
          'grade_addition_only':grade,'family_refresh':{'count':len(family),'structure_ids':ids},
          'changelog_auto_written_or_removed':False}
    output.mkdir(exist_ok=True)
    patchtext=''
    for rel,v in sorted(planned.items()):
        destination=output/rel;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(v['after'])
        try:
            before=(v['before'] or b'').decode();after=v['after'].decode()
        except UnicodeDecodeError:
            continue
        patchtext+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel if v['before'] is not None else '/dev/null',tofile='b/'+rel))
    (PACKAGE/'selective-review.patch').write_text(patchtext)
    (PACKAGE/'family-refresh.json').write_bytes(json_bytes({'assets':family,'structure_ids':ids,'count':len(family)}))
    (PACKAGE/'fresh-build-command.txt').write_text('From chicago/4d after parent adoption and slot release:\nBLENDER_CACHE=<verified-pinned-cache> tools/bake.sh --only '+','.join(ids)+'\n\nThen run canonical licence/grade/sidecar/derived-data compilers and full required checks. Never copy preview GLBs/manifests as official outputs.\n')
    # Changelog is reviewed separately so an already-folded sourceS/Hogan entry
    # cannot be duplicated, rewritten or silently deleted by source integration.
    frame_items=["GreenTree's pictured side gains seven upper windows and clapboard gables; Sauganash gains its pictured main-end sash.","The first Tremont follows Gifford's three shuttered storeys, raised entries, opaque working arch and roof spar, with an explicit graded roof-flag mount.","These picture comparisons still differ; hidden details, metric choices, chronology and the flag's wind pose remain disclosed and the original cases stay open."]
    candidates=PACKAGE/'changelog-candidates';candidates.mkdir(exist_ok=True)
    candidate={'title':'Early Chicago buildings move closer to their pictures','kind':'change','items':frame_items}
    (candidates/'T-3055.frame-only.json').write_bytes(json_bytes(candidate))
    source_s=read(PREFIX+'changelog.d/T-3056.json')
    if source_s:
        source_items=[i for i in json.loads(source_s)['items'] if i != 'These source corrections preserve existing July 1835 forms. The original picture-match cases remain open.']
        merged={**candidate,'title':'Early Chicago buildings gain closer forms and clearer picture evidence','items':source_items+frame_items}
        (candidates/'T-3055.with-pending-sourceS.json').write_bytes(json_bytes(merged))
    else:
        (candidates/'T-3055.with-pending-sourceS.json').unlink(missing_ok=True)
    assert not set(PROTECTED).intersection(planned)
    manifest_bytes = json_bytes(plan)
    (PACKAGE/'integration-plan.json').write_bytes(manifest_bytes)
    (PACKAGE/'review-manifest.sha256').write_text(sha(manifest_bytes)+'\n')
    print('REVIEW ONLY'+f': {len(planned)} selective files; family refresh {len(family)} masters; no canonical assets/manifests/sidecars touched')
    print(f'Review {PACKAGE / "integration-plan.json"} and {PACKAGE / "selective-review.patch"}')


if __name__ == '__main__':
    main()
