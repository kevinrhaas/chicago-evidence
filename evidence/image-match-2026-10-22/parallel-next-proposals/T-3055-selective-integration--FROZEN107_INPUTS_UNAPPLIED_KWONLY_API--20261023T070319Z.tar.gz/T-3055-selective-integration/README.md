# T-3055 selective final frame integration

This package is self-contained. `payload/final` is authoritative final code/data;
`payload/old` is the guarded old baseline, and `payload/executed` preserves the
parameter module used by the inspected prototypes. Do not restore a stash or
replay historical patches over the live checkout. `reference-patches/` and the
one-off prepare/fix scripts document history; they are not integration commands.

From this directory, with the chicago repository root as the argument:

```sh
python integrate.py --repo /workspace/chicago
PYTHONPATH=/workspace/shared/python python audit.py /workspace/chicago
python check_api_geometry.py /workspace/chicago
python test_integrator.py
```

Review `integration-plan.json`, `review-manifest.sha256`, `selective-review.patch`
and `review-tree/`. Then, as the exclusive checkout writer:

```sh
python integrate.py --repo /workspace/chicago --apply
```

Default mode writes this package's review artifacts only. Apply consumes the exact
review manifest, checks all106+ frozen executable/payload/reference inputs, every
recorded current repo input and every replacement hash, then stages every file
before any target rename. Per-file renames are atomic; an exception rolls already
renamed files back from the backup journal. `apply-journal/` records recovery data
and `apply-receipt.json` records success. Multi-file filesystem replacement cannot
promise crash-wide atomicity; retain the journal and checkpoint the completed
transaction in GitHub. Five synthetic-root tests cover successful application,
second-rename failure/rollback, input drift, replacement drift and selective JSON
merge conflict behavior. No tests or apply have been run against the real app tree.

A sourceS commit changing HEAD alone does not invalidate a review: guards pin file
bytes, not a branch/commit name. If a merge, sourceS correction or manifest change
alters a recorded input, apply refuses and asks for a fresh review. Re-run the four
review commands; materialization is idempotent and preserves current unrelated
JSON, ledger, licence, status/roadmap and check-step additions. No old Hogan entry
is copied or removed. Existing STATUS bytes are retained as an exact prefix; its
inherited non-UTF8 byte is neither silently recoded nor repaired.

The materializer directly assembles the final overlap of these historical steps:

1. Combined frame controls: two modules, GreenTree/Sauganash/Tremont form records.
2. Main-gable wall cladding on GreenTree/Sauganash, with unchanged slope geometry.
3. Durable CPU geometry/material/confidence/default checks and check.sh step.
4. Tremont opaque arch/plain entry outlines and its durable test follow-up.
5. Runtime flag layer plus bounded three-field compiler/validator contract/tests.
6. Actual Tremont flag opt-in, explicit phase/date-local anchor and source bounds.
7. API compatibility: **all ten new dataclass fields are keyword-only**, preserving
   every original forty positional parameter/default/order and a full40argument call.

Overlapping historical module/record/ledger patches are not blindly replayed.
`api-compatibility-followup.patch` documents the final constructor repair; current
payload already includes it. Parent should never copy old canonical outputs or
restamp freshness hashes after these changed recipe bytes.

The20 non-research target files are listed in `TARGET-FILES.txt`;59 additional
files archive inspected prototype research/receipts/images. No canonical GLB, web
derivative, manifest, sidecar, sourceS structure record or current Hogan record is
restored. Three target records receive field-level guarded deltas; footprints,
positions and building phase dates must match the documented baseline or the
script stops. New runtime flag validity ends1836-07-03; the building phase itself
stays unchanged. Grade edits add **Tremont only**, preserving StMary's/sourceS and
all other rulings. Eleven new name-pool note paths are declared without importing
an old whole-file pool configuration.

The ledger moves L74's original text verbatim into Resolved with its prior
resolution note, preserves unrelated/current entries, appends five selected frame
entries from stash42e0ea4b7 plus the two third/flag entries with proper Decision
labels. Full ledger parsing, exact reconstructed-only Covers, target coverage and
L74 placement are audited. The Gifford licence row retains owner-approved
attributed use and does not assert public-domain status. No StMary chronology or
Beaubien/jail source edits are restored from the old stash.

`light-audit.json`:11 durable frame tests,5 Node anchor groups,6 Python runtime
consumer/card tests pass; full ledger parse and34 target admissions have no missing
coverage; all20 new Covers name reconstructed actual values; new target name-pool
paths have no undeclared names. `api-geometry-proof.json`: the cached executed
module and final keyword-only module resolve identical params and accumulate
identical geometry/material/confidence across24 record-phases. Historical preview
sources stay unchanged. These CPU proofs do not replace a fresh official build.

`family-refresh.json` and `fresh-build-command.txt` select all23 current canonical
frame_tavern master recipes. Parent runs the verified pinned canonical bake after
source adoption, then licences/grades/compiled sidecars/derivatives and required
published desktop/mobile/card/full gates. No common generator helper is changed.
The runtime flag layer changes the app, not baked cloth; new form confidence keys
also affect resolved recipe bytes. The official producer must recompute them.

All original image-match tickets remain open. Source/before/after evidence is
archived as provisional research, outside accepted reference_views. Opaque arch
lettering remains unresolved; roof cloth mounts correctly but the inspected shared
breeze makes it nearly edge-on, unlike the source-left pose. No match, official
freshness, full app/mobile verification or final source-date resolution is claimed.

Changelog candidates are **outside** the app. Use `T-3055.frame-only.json` when
sourceS already merged/folded separately, or review the combined pending-sourceS
candidate if its entry is still pending and one group is desired. Parent owns
that final consolidation; the script never edits/deletes T3056/Hogan entries.
