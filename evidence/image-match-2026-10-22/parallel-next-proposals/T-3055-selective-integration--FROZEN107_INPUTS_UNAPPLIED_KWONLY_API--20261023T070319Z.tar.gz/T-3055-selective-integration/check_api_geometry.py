"""Light proof that keyword-only compatibility repair changes no resolved shape."""
import pathlib,sys,types,importlib.util,dataclasses,inspect,json,hashlib
sys.dont_write_bytecode=True
P=pathlib.Path(__file__).parent;D=P/'payload/final/chicago/4d';R=pathlib.Path(sys.argv[1])/'chicago/4d';EXECUTED=P/'payload/executed/frame_tavern_params.py'
sys.path[:0]=[str(P/'validation-fixture/generators'),str(R/'generators')];sys.modules.setdefault('bpy',types.ModuleType('bpy'))
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
legacy=load('original_positional_parameters',P/'payload/old/chicago/4d/generators/archetypes/frame_tavern_params.py')
executed=load('executed_picture_parameters',EXECUTED)
final=load('kw_only_picture_parameters',D/'generators/archetypes/frame_tavern_params.py')
a=inspect.signature(legacy.FrameTavernParams).parameters;b=inspect.signature(final.FrameTavernParams).parameters
pos={k:v for k,v in b.items() if v.kind==inspect.Parameter.POSITIONAL_OR_KEYWORD};assert list(pos.items())==list(a.items())
extra={k:v for k,v in b.items() if k not in a};assert len(extra)==10 and all(v.kind==inspect.Parameter.KEYWORD_ONLY for v in extra.values())
from archetypes import frame_tavern as builder
from common.mesh import MeshBuilder
MeshBuilder.to_object=lambda self,mats=None:(self,list(mats or []));builder.simple_material=lambda n,*a,**kw:(n,a,kw)
def signature(res):
 mesh,mats=res;return mesh.verts,mesh.faces,mesh.conf,mesh.mat_index,mesh.named,mats
phases=[]
for path in sorted((R/'data/structures').glob('*.json')):
 record=json.loads(path.read_text())
 if record.get('archetype')!='frame_tavern':continue
 proposed=D/'data/structures'/path.name
 if proposed.exists():record=json.loads(proposed.read_text())
 for phase in record['phases']:
  oldp=executed.from_phase(phase,record);newp=final.from_phase(phase,record);assert dataclasses.asdict(oldp)==dataclasses.asdict(newp)
  name=record['id']+'__'+phase['id'];assert signature(builder.build(oldp,name))==signature(builder.build(newp,name));phases.append(name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt={'original_positional_parameters_preserved_exactly':list(pos),'all_ten_new_fields_keyword_only':list(extra),'executed_parameter_sha256':sha(EXECUTED),'final_keyword_only_parameter_sha256':sha(D/'generators/archetypes/frame_tavern_params.py'),'resolved_params_and_accumulated_geometry_material_confidence_equal_to_executed_proposal':phases,'phase_count':len(phases),'blender_rerun':False,'official_recipe_action':'fresh23family canonical rebuild required because parameter source bytes changed; do not restamp old hashes','historical_preview_sources_unchanged':True}
(P/'api-geometry-proof.json').write_text(json.dumps(receipt,indent=2)+'\n');print('PASS original40positional parameter signatures/defaults exact; all10new fields keyword-only;',len(phases),'executed/final parameter+geometry/material/confidence outputs exact; recipe bytes changed, fresh bake required')
