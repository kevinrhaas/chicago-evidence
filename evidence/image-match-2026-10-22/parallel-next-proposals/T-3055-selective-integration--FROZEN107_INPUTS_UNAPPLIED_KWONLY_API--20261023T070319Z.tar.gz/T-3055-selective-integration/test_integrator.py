"""Light transaction/fail-closed tests in temporary synthetic roots only."""
import importlib.util,json,pathlib,tempfile,unittest,os
from unittest.mock import patch
P=pathlib.Path(__file__).parent
spec=importlib.util.spec_from_file_location('selective_integrator',P/'integrate.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class Integrator(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.base=pathlib.Path(self.temp.name);self.package=self.base/'package';self.package.mkdir();self.repo=self.base/'repo';self.repo.mkdir()
  self.original={'src/a.txt':b'old a\n','src/b.txt':b'old b\n','src/sourceS.txt':b'sourceS unchanged\n'}
  for rel,data in self.original.items():p=self.repo/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
  writes=[]
  for rel,data in [('src/a.txt',b'new a\n'),('src/b.txt',b'new b\n')]:
   p=self.package/'review-tree'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);writes.append({'path':rel,'old_sha256':m.sha(self.original[rel]),'new_sha256':m.sha(data)})
  plan={'repo':str(self.repo),'frozen_inputs':{'synthetic':'guard'},'repo_inputs':{k:m.sha(v) for k,v in self.original.items()},'writes':writes,'sourceS_and_Hogan_records_untouched':['src/sourceS.txt']}
  (self.package/'integration-plan.json').write_text(json.dumps(plan));(self.package/'review-manifest.sha256').write_text(m.sha((self.package/'integration-plan.json').read_bytes()));self.pkgpatch=patch.object(m,'PACKAGE',self.package);self.pkgpatch.start();self.addCleanup(self.pkgpatch.stop);self.freezepatch=patch.object(m,'frozen_inputs',return_value={'synthetic':'guard'});self.freezepatch.start();self.addCleanup(self.freezepatch.stop)
 def contents(self):return {rel:(self.repo/rel).read_bytes() for rel in self.original}
 def test_success_commits_all_and_preserves_unrelated(self):
  m.apply_reviewed(self.repo);self.assertEqual((self.repo/'src/a.txt').read_bytes(),b'new a\n');self.assertEqual((self.repo/'src/b.txt').read_bytes(),b'new b\n');self.assertEqual((self.repo/'src/sourceS.txt').read_bytes(),self.original['src/sourceS.txt']);self.assertEqual(json.loads((self.package/'apply-receipt.json').read_text())['files'],2)
 def test_failure_during_second_rename_rolls_back_first(self):
  replace=os.replace
  def fail_second(src,dst):
   if pathlib.Path(src).name.startswith('.t3055-stage-') and pathlib.Path(dst).name=='b.txt':raise OSError('deliberate second-target failure')
   return replace(src,dst)
  with patch.object(os,'replace',side_effect=fail_second),self.assertRaises(OSError):m.apply_reviewed(self.repo)
  self.assertEqual(self.contents(),self.original);self.assertFalse((self.package/'apply-receipt.json').exists());self.assertFalse(list(self.repo.rglob('.t3055-stage-*')))
 def test_repo_drift_refused_before_mutation(self):
  (self.repo/'src/sourceS.txt').write_bytes(b'new sourceS\n');before=self.contents()
  with self.assertRaises(RuntimeError):m.apply_reviewed(self.repo)
  self.assertEqual(self.contents(),before)
 def test_reviewed_replacement_drift_refused_before_mutation(self):
  (self.package/'review-tree/src/b.txt').write_bytes(b'tampered\n')
  with self.assertRaises(RuntimeError):m.apply_reviewed(self.repo)
  self.assertEqual(self.contents(),self.original)
 def test_nested_merge_preserves_other_live_notes_and_refuses_overlap(self):
  old={'phases':[{'id':'p','form':{'existing':{'value':1}}}],'sourceS':'old'};final={'phases':[{'id':'p','form':{'existing':{'value':1},'new':{'value':True}}}],'sourceS':'old'};current={'phases':[{'id':'p','form':{'existing':{'value':1}}}],'sourceS':'new evidence'}
  result=m.merge(old,final,current,'record');self.assertEqual(result['sourceS'],'new evidence');self.assertTrue(result['phases'][0]['form']['new']['value']);current['phases'][0]['form']['new']={'value':'different'}
  with self.assertRaises(RuntimeError):m.merge(old,final,current,'record')

if __name__=='__main__':unittest.main()
