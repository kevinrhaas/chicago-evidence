"""Light checks of the review tree in an isolated dependency fixture; no app writes."""
import pathlib,sys,shutil,subprocess,json,re,importlib.util
P=pathlib.Path(__file__).parent;R=pathlib.Path(sys.argv[1]).resolve();F=P/'validation-fixture';S=P/'review-tree/chicago/4d';F.mkdir(exist_ok=True)
for rel in ['tools','generators/archetypes','renderers/web/js','data/structures','data/reconstruction','docs']:(F/rel).mkdir(parents=True,exist_ok=True)
plan=json.loads((P/'integration-plan.json').read_text());prefix='chicago/4d/'
for row in plan['writes']:
 rel=row['path']
 if not rel.startswith(prefix):continue
 rel=rel.removeprefix(prefix)
 if rel.startswith(('tools/','generators/','renderers/web/js/','data/structures/','data/reconstruction/')):
  dest=F/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(S/rel,dest)
# Read-only dependency links belong only to this throwaway validation fixture;
# integrate.py applies only its manifest and never copies this directory.
for f in (R/'chicago/4d/tools').glob('*.py'):
 if not (F/'tools'/f.name).exists():(F/'tools'/f.name).symlink_to(f)
(F/'generators/archetypes/__init__.py').touch()
if not (F/'generators/common').exists():(F/'generators/common').symlink_to(R/'chicago/4d/generators/common',target_is_directory=True)
for name in ['fort_dearborn_flagstaff','first_fort_dearborn_flagstaff']:
 f=F/f'data/structures/{name}.json'
 if not f.exists():f.symlink_to(R/f'chicago/4d/data/structures/{name}.json')
commands=[['python','tools/test_frame_tavern_picture_features.py'],['node','tools/test_flag_anchors.mjs'],['python','tools/test_flag_form_contract.py']]
receipts=[]
for c in commands:
 r=subprocess.run(c,cwd=F,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);receipts.append({'command':c,'exit_code':r.returncode,'output':r.stdout});assert r.returncode==0,r.stdout
sys.path[:0]=[str(F/'tools'),str(R/'chicago/4d/tools'),str(F/'generators')]
import validate,compile_liberties,replace_invented_residents as names
from archetypes.frame_tavern_params import CONSUMED
records={name:json.loads((F/f'data/structures/{name}.json').read_text()) for name in ['green_tree_tavern','sauganash_hotel','tremont_house_1']}
validate.ROOT=F
report=validate.Report();validate.check_geometry_declarations(records,{'frame_tavern':CONSUMED},report);assert not report.errors,report.errors
ledger=(S/'docs/LIBERTIES.md').read_text();known={p.stem:json.loads(p.read_text()).get('name','') for p in (R/'chicago/4d/data/structures').glob('*.json')}
entries,problems=compile_liberties.parse(ledger,known);assert not problems,problems
report2=validate.Report();validate.check_liberties_coverage(records,{'liberties':entries},report2,{'frame_tavern':CONSUMED},forward_only=True);assert not report2.errors,report2.errors
newids=json.loads((P/'payload/ledger/order.json').read_text());graded={(sid,pid,aspect):block for sid,pid,aspect,where,block in validate.graded_values(records)};claims=0
for entry in entries:
 if entry['id'] not in newids:continue
 for cover in entry['covers']:
  key=(cover['structure'],cover['phase'],cover['aspect']);assert graded[key]['confidence']=='reconstructed',key;claims+=1
l74=next(e for e in entries if e['id']=='L74');assert l74['section']=='resolved'
original=(P/'payload/ledger/L74-original.md').read_text().rstrip();assert original in ledger
names.DATA=F/'data';pooldoc=json.loads((F/'data/reconstruction/name_pool_keys.json').read_text());pool,unknown=names.harvest_names(pooldoc,{'structures':[F/f'data/structures/{n}.json' for n in records]});assert not unknown,unknown
# The actual sidecar/flag suites already prove both compiler recognition and
# old fort attribute shape; no full scene compiler or official output runs here.
receipt={'state':'light isolated selective integration checks passed; no official build/fullgate','focused_suites':receipts,'geometry_declarations':report.notes,'liberty_coverage':report2.notes,'new_reconstructed_cover_count':claims,'L74_original_text_verbatim_in_resolved_section':True,'new_target_name_pool_undeclared':unknown,'canonical_assets_or_sidecars_written':False}
(P/'light-audit.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('PASS11 frame tests,5 Node groups,6 consumer tests; geometry contract/ledger parse/target coverage/name-pool paths; verbatim ResolvedL74; no official writes')
