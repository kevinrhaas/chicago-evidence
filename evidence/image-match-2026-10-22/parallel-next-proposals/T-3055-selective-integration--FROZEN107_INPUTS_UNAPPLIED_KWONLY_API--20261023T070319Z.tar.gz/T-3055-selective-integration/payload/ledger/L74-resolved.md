### L74 — Tremont House I: a hotel built two storeys tall because three rests on one modern sentence
**Decision:** the first Tremont House is built at the north-west corner of Lake and Dearborn as a
**two-storey** braced-frame block 50 × 30 ft, unpainted, gable-roofed and without a gallery. The
storey count, the wall height, the roof, the paint, the gallery and the footprint are all tagged
`conjectural`.
**Why, and the storey count is the whole entry.** What is documented about this building is
unusually good: the corner three times over, frame construction three times over, Alanson Sweet
as builder, Ira Couch as proprietor from 1834, and destruction by fire on 27 October 1839. What
is not documented is its height. `chicagology_prefire021` prints an uncredited modern "Building
Summary" — "a three-story wooden building" — beside two period texts that count no storeys at
all: the Chicago *Tribune* letter of 2 February 1874 ("an unpretending frame structure") and
*Chicago Illustrated* of January 1866 ("a wooden structure"). Andreas, who gives the building a
builder, a corner, a material, four proprietors and a death date, gives it no height. So the
three-storey Tremont has exactly one witness and it is a modern editor;
`docs/research/04-structures-south.md` line 155 weighs it twice by citing "chicagology and
Wikipedia". **Two is adopted and is still a guess**, on three arguments that are not evidence:
Chicago in 1833 held about 350 people and *Wau-Bun* found the Sauganash's TWO storeys remarkable
two years earlier; the *Chicago American*'s "Improvements in 1836", quoted by Andreas, counts
"about twenty large two to three-story wooden buildings" among that year's NEW work; and this
project already excludes the Saloon Building of 1836 partly as the town's first three-storey
structure.
**Consequence:** if the three-storey reading is right the building stands about 2.6 m taller than
the model shows, and it would be the tallest thing in the 1835 scene. Everything else here is the
usual: no source measures the house, describes its roof, names its finish or mentions a porch,
and the confidence view renders the whole block as massing. **One documented thing about this
building IS carried and is not built**: Ira Couch's "a mere shell, without any sidewalk around
it". This project builds no plank walks anywhere, so the record states `sidewalk: false` as
`record_only` — a negative finding about the ground, not an omission.
**How to resolve:** the *Daily American*'s account of the 27 October 1839 fire, which Andreas
quotes for the merchants' stock losses and which itemised insurance building by building; or any
*Chicago American* or *Chicago Democrat* advertisement of the house, which in the period counted
rooms.
**Covers:** `tremont_house_1.frame_1833.footprint`, `tremont_house_1.frame_1833.form.stories`, `tremont_house_1.frame_1833.form.wall_height_m`, `tremont_house_1.frame_1833.form.roof_type`, `tremont_house_1.frame_1833.form.paint`, `tremont_house_1.frame_1833.form.gallery`.
**Recorded:** 2026-08-11.
**Resolved:** 2026-10-23 (T-2385): Gifford’s newly adopted whole-building drawing supersedes this text-only two-storey/roof reading. The historical entry is retained verbatim here. Unsettled footprint, height, paint and gallery decisions continue in L-tremont-corner-elevations-2385; this resolves no image-match ticket.


