### L-sauganash-end-sash-2383 — the pictured main gable's sash

**What is read:** `andreas_1884_sauganash_hotel_plate`, inspected as the committed Braunhold sheet `chicago/reference/images/chicago/chicago_sauganash_hotel_1831.jpg`. The exposed main gable above the log annex has two upper-storey sash and an upright attic sash. The existing measured reading in tools/sauganash_plate_baseline.json records upper centres at image x564.8 and783.7 and an attic centre at628.3; these are a picture reading, not a solved model camera. Petford and Trowbridge repeat this composition rather than independently corroborating it.
**What is reconstructed:** the upper pair use the frontage builder's retained0.85 ×1.35 m sash, with centres at30% and70% of the retained8 m depth and centre height4.25 m (the existing front's3.575–4.925 m upper band). The attic sash uses0.70 ×1.20 m, at mid-depth, centre6.70 m. These stations and sizes are first-comparison model choices; no metric historic window dimension or station is claimed. The +x end follows the record's existing east-annex relationship, not geographic inversion of a retrospective drawing. The front/back openings, main massing, reconstructed cross-wing, paint/shutters, other gable and annex remain as previously modelled. New end sash use the existing generic glazing proxy without extra shutters; full sash divisions, shutters in derivative pictures, rake/cornice, roof and grouped model/camera differences remain open.
**How to resolve:** rebuild with the pinned toolchain, render the original and refined GLBs from the same provisional joint Sauganash/annex camera, compare every visible feature against all three local pictures, then refine the geometry and solve. Do not mark matches or close T-2383 from this increment alone.
**Covers:** `sauganash_hotel.frame_1831.form.end_windows`.
**Ticket:** T-2383.
**Recorded:** 2026-10-23.


