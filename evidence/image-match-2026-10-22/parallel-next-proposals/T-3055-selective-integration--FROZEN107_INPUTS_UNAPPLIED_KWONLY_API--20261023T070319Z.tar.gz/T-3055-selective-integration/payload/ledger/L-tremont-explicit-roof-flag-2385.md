### L-tremont-explicit-roof-flag-2385 — First Tremont roof cloth on an explicit phase-local staff

**Covers:** `tremont_house_1.frame_1833.form.flag`, `tremont_house_1.frame_1833.form.flag_flying`, `tremont_house_1.frame_1833.form.flag_anchor`.

**Decision:** The owner-approved Gifford/Chicagology reproduction shows a roof spar with a striped flag/canton. It does not recover its star count, original colour, precise flag construction, staff/cloth dimensions or whether it flew at the1835 scene's forenoon. A24-star/13-stripe United States flag is a reconstructed hotel identity/pattern choice using the existing period library. It is legally current for1835-07-01; the explicit anchor interval ends1836-07-03 to avoid carrying that pattern beyond its supported date. The image is not a dated1835 observation. Flag flying, layout, wear, app breeze/pose and all dimensions are reconstructed, retaining Gifford/Chicagology attribution and owner-approved use without a public-domain assertion.

Approximate source picks: spar head(1034,192), base(1034,279); cloth outline x1000..1034,y197..224. Raw projected fly/staff~0.39 and hoist/staff~0.31 only bound appearance: folds, perspective and the reconstructed camera do not yield metres. Relative working brackets fly0.35..0.50 and hoist0.25..0.40 of the already reconstructed4.25m spar allow a working1.85m fly and1.30m hoist. Its proportions and exact source/wind alignment remain open. Existing app wind/cloth wear are not claimed to match this particular drawing.

The pole anchor is phase-local footprint metres[east,north,up] mapped to glTF[east,up,south] before the building's placement matrix. Head/foot follow the current reconstructed wall/roof/spar parameters, radius0.035m follows the square spar half-width, and both coordinates and dimensions have reconstructed confidence. The cloth's grade is the worst of pattern/flying/anchor. Wrong phase/date/frame, malformed coordinates, non-upright or out-of-bounds mounts refuse cloth explicitly instead of falling back to whole-hotel bounds. Legacy fort staffs retain their original bounds mount/dimensions unchanged. Cloth is an app layer, never baked into the hotel master.

**Ticket:** T-2385.
**Recorded:** 2026-10-23 (T-3055).
