### L-green-tree-seven-bays-T-2376 — Green Tree's pictured south eaves rhythm, with unchanged stock sash and reconstructed spacing

**Subjects:** `green_tree_tavern`. The bay count itself is inferred from the picture; the inherited stock/spacing remains reconstruction, described here without claiming the inferred count as an invented value.
**Decision:** The public-domain retrospective Andreas/Braunhold illustration
(`andreas_1884_green_tree_hotel_plate`; local reproduction
`chicago/reference/images/chicago/chicago_green_tree_inn_1838.jpg`) depicts seven upper
sash on the long elevation. The existing model's six came from rounding its 12.19 m
length into 2.2 m modules. The south wall (`x_min` under the existing west-facing
placement) takes seven bay stations without changing the footprint, geographic
placement, height or roof. **Inferred from the picture:** seven visible upper bays
and their assignment to the south elevation by the existing Lake Street frontage
reading. The plate is a retrospective form witness, not proof of the 1 July 1835
state, and its reproduced 1838 caption does not date the original undated Andreas
plate. **Reconstructed:** exactly even station spacing (12.19 / 7 = 1.7414 m), the
existing 0.85 by 1.35 m sash stock and storey bands, and the hidden parts of each
opening. These widths and heights are preserved rather than measured from the
picture. The attested side entrance continues to replace the middle ground-floor
bay; this proposal does not pretend that a picture drawing lower sash establishes
that door's exact appearance. The opposite north wall retains its existing six-bay
reconstruction; no mirrored seven-bay claim is made. Gable opening arrangements and attic lights, and the disputed low wing, remain unresolved; main-gable wall cladding is corrected by the following decision.
**How to resolve:** solve the picture's camera and inspect baseline/rebuilt renders;
resolve gable and wing differences and compare every other ticket picture. A dated
period image or dimensional description would replace the uncertain elevation and
opening sizes. Neither this count correction nor its emitted-opening checks is a
`matches` verdict.
**Ticket:** T-2376.
**Recorded:** 2026-10-23.

