"""Freeze all executable/source/payload/reference inputs before review/apply."""
import pathlib,hashlib,json
P=pathlib.Path(__file__).parent
paths=list(P.glob('*.py'))
for folder in ['payload','reference-patches']:
 paths.extend(p for p in (P/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc', '.pyo'))
manifest={p.relative_to(P).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
(P/'package-inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Frozen',len(manifest),'package input files')
