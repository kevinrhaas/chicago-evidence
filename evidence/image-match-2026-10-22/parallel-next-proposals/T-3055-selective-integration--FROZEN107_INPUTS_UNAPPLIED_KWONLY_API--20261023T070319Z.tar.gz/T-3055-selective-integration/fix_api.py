"""Keep all ten new frame parameters keyword-only; legacy positional API stays intact."""
from pathlib import Path
import re,difflib
P=Path(__file__).parent;D=P/'payload/final/chicago/4d';params=D/'generators/archetypes/frame_tavern_params.py';before=params.read_text();s=before
fields={'gable_wall_cladding':'False','first_story_height_m':'None','entry_raise_m':'0.0','gable_lunette':'False','gable_arch_treatment':'"fanlight"','corner_entry_surround':'False','flagstaff':'False','flagstaff_height_m':'4.25','end_windows':'()'}
for name,default in fields.items():
 pattern=rf'^(    {name}: [^=\n]+)= {re.escape(default)}$';s,n=re.subn(pattern,rf'\1= field(default={default}, kw_only=True)',s,flags=re.M);assert n==1,name
s,n=re.subn(r'^(    eaves_bays: [^=\n]+)= field\(default_factory=dict\)$',r'\1= field(default_factory=dict, kw_only=True)',s,flags=re.M);assert n==1
params.write_text(s)
f=D/'tools/test_frame_tavern_picture_features.py';old=f.read_text();s=old.replace('import json\n','import json\nimport inspect\n',1)
marker='    def test_small_legacy_fixture_keeps_old_roof_and_empty_opt_ins(self):'
test='''    def test_original_positional_constructor_and_defaults_are_preserved(self):
        # These are the original forty positional parameters, before picture
        # opt-ins. A new field inserted among them must not change caller meaning.
        legacy = (
            "width_m", "depth_m", "stories", "wall_height_m", "roof_type",
            "roof_pitch_deg", "construction", "paint", "shutters", "shutter_type",
            "gallery", "entrance_frontispiece", "siding_exposure_m", "chimneys",
            "elevation_scheme", "chimney_material", "roof_colour", "chimney_placement",
            "side_entrance_face", "rear_ell", "rear_ell_width_m", "rear_ell_depth_m",
            "rear_ell_wall_m", "rear_ell_door", "upper_windows", "stovepipes",
            "log_wing", "log_wing_width_m", "log_wing_depth_m", "log_wing_height_m",
            "log_wing_door", "log_wing_porch_hood", "cross_wing", "cross_wing_depth_m",
            "cross_wing_end", "finish_key", "roof_condition", "siding_lay_m",
            "siding_seed", "confidence",
        )
        signature = inspect.signature(FrameTavernParams)
        positional = tuple(name for name, p in signature.parameters.items()
                           if p.kind == inspect.Parameter.POSITIONAL_OR_KEYWORD)
        self.assertEqual(positional, legacy)
        self.assertTrue(all(p.kind == inspect.Parameter.KEYWORD_ONLY
                            for name, p in signature.parameters.items() if name not in legacy))
        values = (
            12., 8., 2, 5.5, "gable", 37., "braced_frame", "unpainted", "green", None,
            False, False, .127, 2, "frontage", "brick", None, "frontage", None,
            False, 4., 3., 2.4, "carriage", 4, 1, False, 4., 3., 2.35, False, False,
            False, 7., "x_max", None, None, .002, "legacy-positional", {"stories": "attested"},
        )
        p = FrameTavernParams(*values)
        p.validate()
        self.assertEqual(tuple(getattr(p, name) for name in legacy), values)
        defaults = FrameTavernParams(12., 8., 2, 5.5)
        expected = {"paint": "white", "chimney_material": None, "stovepipes": 0,
                    "siding_seed": "", "confidence": {}, "gable_wall_cladding": False,
                    "first_story_height_m": None, "entry_raise_m": 0., "gable_lunette": False,
                    "gable_arch_treatment": "fanlight", "corner_entry_surround": False,
                    "flagstaff": False, "flagstaff_height_m": 4.25,
                    "eaves_bays": {}, "end_windows": ()}
        for name, value in expected.items():
            self.assertEqual(getattr(defaults, name), value)
        with self.assertRaises(TypeError):
            FrameTavernParams(*values, True)  # a new opt-in cannot occupy slot41

'''
assert marker in s;s=s.replace(marker,test+marker,1);f.write_text(s)
patch=''.join(difflib.unified_diff(before.splitlines(True),params.read_text().splitlines(True),fromfile='a/chicago/4d/generators/archetypes/frame_tavern_params.py',tofile='b/chicago/4d/generators/archetypes/frame_tavern_params.py'))+''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/chicago/4d/tools/test_frame_tavern_picture_features.py',tofile='b/chicago/4d/tools/test_frame_tavern_picture_features.py'))
(P/'api-compatibility-followup.patch').write_text(patch)
# Plain prose after Covers is still inside that parsed field. Give each new
# entry a Decision label so the full ledger parser never swallows its body.
for name in ['L-tremont-opaque-arch-entry-2385','L-tremont-explicit-roof-flag-2385']:
 f=P/'payload/ledger'/f'{name}.md';t=f.read_text();lines=t.splitlines(True);i=next(i for i,l in enumerate(lines) if l.startswith('**Covers:**'));j=next(j for j in range(i+1,len(lines)) if lines[j].strip());lines[j]='**Decision:** '+lines[j];f.write_text(''.join(lines))
print('Ten new fields keyword-only; original40positional API guarded; new full-ledger labels bounded')
