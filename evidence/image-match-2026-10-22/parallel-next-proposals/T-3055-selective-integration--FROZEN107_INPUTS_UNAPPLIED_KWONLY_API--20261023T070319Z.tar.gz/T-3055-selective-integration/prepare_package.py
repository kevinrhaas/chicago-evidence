"""Capture final proposals and selected historical text into a self-contained package."""
import pathlib,shutil,subprocess,json,re
P=pathlib.Path(__file__).parent;R=pathlib.Path('/workspace/chicago');B=P.parent/'frame_tavern-combined';G=P.parent/'frame-gable-cladding';T=P.parent/'T-2385-third';F=P.parent/'T-2385-roof-flag-anchor';S='42e0ea4b7'
def git(path,ref=S):return subprocess.check_output(['git','show',ref+':'+path],cwd=R)
def put(rel,data):
 p=P/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
code={}
for rel in ['generators/archetypes/frame_tavern.py','generators/archetypes/frame_tavern_params.py','tools/test_frame_tavern_picture_features.py']:
 src=T/'proposed'/rel;code['chicago/4d/'+rel]=src
for rel in ['renderers/web/js/flags.js','renderers/web/js/flag-anchors.js','tools/test_flag_anchors.mjs','tools/flag_form_contract.py','tools/validate.py','tools/compile_scene.py','tools/test_flag_form_contract.py']:
 code['chicago/4d/'+rel]=F/'proposed/chicago/4d'/rel
for rel,src in code.items():put('payload/final/'+rel,src.read_bytes())
for rel in ['generators/archetypes/frame_tavern.py','generators/archetypes/frame_tavern_params.py']:
 put('payload/old/chicago/4d/'+rel,(B/'baseline'/rel).read_bytes())
put('payload/old/chicago/4d/tools/test_frame_tavern_picture_features.py',(P.parent/'frame-durable-tests/proposed/chicago/4d/tools/test_frame_tavern_picture_features.py').read_bytes())
for name in ['flags.js','validate.py','compile_scene.py']:
 rel=('renderers/web/js/' if name=='flags.js' else 'tools/')+name;put('payload/old/chicago/4d/'+rel,(F/'baseline'/name).read_bytes())
for name in ['green_tree_tavern','sauganash_hotel','tremont_house_1']:
 rel='chicago/4d/data/structures/'+name+'.json';put('payload/old/'+rel,(B/'baseline/data/structures'/f'{name}.json').read_bytes());put('payload/final/'+rel,((F/'proposed/chicago/4d/data/structures' if name=='tremont_house_1' else G/'proposed/data/structures')/f'{name}.json').read_bytes())
ledger=git('chicago/4d/docs/LIBERTIES.md').decode();original=git('chicago/4d/docs/LIBERTIES.md',S+'^1').decode()
def entry(text,id):
 m=re.search(r'^### '+re.escape(id)+r'\b.*?(?=^### |^## |\Z)',text,re.M|re.S);assert m,id;return m.group(0)
ids=['L-tremont-corner-elevations-2385','L-tremont-entry-roof-details-2385','L-green-tree-seven-bays-T-2376','L-sauganash-end-sash-2383','L-main-gable-wall-cladding-2376-2383']
for id in ids:put('payload/ledger/'+id+'.md',entry(ledger,id).encode())
put('payload/ledger/L74-original.md',entry(original,'L74').encode());put('payload/ledger/L74-resolved.md',entry(ledger,'L74').encode())
for name,id,title in [('T-2385-third','L-tremont-opaque-arch-entry-2385','First Tremont opaque arch and plain entry outlines'),('T-2385-roof-flag-anchor','L-tremont-explicit-roof-flag-2385','First Tremont roof cloth on an explicit phase-local staff')]:
 text=(P.parent/name/'liberty.md').read_text();text=re.sub(r'^### .*?\n',f'### {id} — {title}\n',text,count=1);text+='\n**Ticket:** T-2385.\n**Recorded:** 2026-10-23 (T-3055).\n';put('payload/ledger/'+id+'.md',text.encode());ids.append(id)
put('payload/ledger/order.json',json.dumps(ids,indent=2).encode())
stashed=json.loads(git('chicago/4d/data/structure_grades.json'));grade=next(p for p in stashed['pictured'] if p['structure']=='tremont_house_1' and p['scene']=='1835');put('payload/tremont-grade.json',json.dumps(grade,indent=2,ensure_ascii=False).encode())
license=git('chicago/4d/assets/LICENSES.md').decode();row=next(l for l in license.splitlines() if l.startswith('| `gifford_tremont_house_no_1`'));put('payload/gifford-license-row.md',(row+'\n').encode())
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',S+'^3'],cwd=R,text=True).splitlines();prefix='chicago/4d/docs/RESEARCH/frame-picture-match-T-2376-T-2385/'
for rel in paths:
 if rel.startswith(prefix):
  dest=rel
  if rel==prefix+'README.md':dest=prefix+'first-increment/README.md'
  put('payload/research/'+dest,git(rel,S+'^3'))
# Archive current inspected third increment with output receipts, not its GLBs.
base=prefix+'third-tremont/'
for rel in ['FINAL-HANDOFF.md','execution-freeze.json','check.log','durable-check.log','liberty.md','checkpoint.json']:
 put('payload/research/'+base+rel,(T/rel).read_bytes())
for rel in ['blender-previews-report.json','glb-contract-inspection.json','reviewed-preview-receipt.json','photo-match-receipts.json','review/tremont/gifford-provisional.json','review/tremont/gifford-provisional.match.json','review/tremont/observations.md','review/tremont/source-before-after.jpg','review/tremont-flag/gifford-provisional.json','review/tremont-flag/gifford-provisional.match.json','review/tremont-flag/flag-layer-diagnostic.json','review/tremont-flag/observations.md','review/tremont-flag/source-before-after-and-flag.jpg','review/tremont-flag/source-before-after-and-flag-detail.jpg']:
 put('payload/research/'+base+rel,(T/'preview-root'/rel).read_bytes())
for rel in ['README.md','liberty.md','check.log','form-contract-check.log','checkpoint.json','flag-layer.patch','T-2385-flag-opt-in.patch','check-step.txt']:
 put('payload/research/'+prefix+'roof-flag-contract/'+rel,(F/rel).read_bytes())
put('payload/research/'+prefix+'third-tremont/incremental.patch',(T/'incremental.patch').read_bytes())
# Actual standalone patches stay available for reviewers, without replaying them.
for name,src in [('01-combined.patch',B/'T-2376-T-2383-T-2385-combined.patch'),('02-main-gable.patch',G/'incremental.patch'),('03-durable-tests.patch',P.parent/'frame-durable-tests/durable-tests.patch'),('04-third-tremont.patch',T/'incremental.patch'),('05-flag-layer.patch',F/'flag-layer.patch'),('06-flag-opt-in.patch',F/'T-2385-flag-opt-in.patch')]:put('reference-patches/'+name,src.read_bytes())
print('Self-contained final source, old guards, selected ledger/license/grade/research captured; no canonical assets')
