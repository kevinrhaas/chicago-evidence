# Lighthouse profile and three tiny shaft apertures: bounded next trial

This is a NEW proposal after the actually reviewed narrow trial. Frozen narrow inputs/previews and five-range controls are untouched. No Blender/browser has run this package; `run-preview.sh` is prepared but MUST wait for the parent's next heavy slot. No canonical write or image-match verdict is included.

Baseline composition: final shared-fort helper + narrow3.04m physical tower + five-range explicit face controls. `prepare.py` extracts those independent fields/functions into a compatible baseline, preserving the16 positional arguments and10 existing keyword fields. Candidate adds individually keyword-only `tower_profile` and `tower_openings`. Its three-file patch targets that composed baseline, not canonical HEAD or an older helper. Five range fronts are identical before/after this overlay. Real canonical deployment still requires a25-family bake and gates; an isolated trial is not that bake.

The actual narrow render had outer endpoints both about17px low, but gallery underside near84 versus source89. This supports a framing/profile hypothesis, not a terrain move. PrincipalY becomes174.540605 from191.988064, derived from weak source toe200±8; the physical source datum remains uncertain. Square pixels, focal length, eye position, world placement and bearing are unchanged. At this framing, keeping the old profile makes the gallery about22px too high. The explicit reconstructed profile lowers the gallery underside from10.4834m to8.719767m, puts the drum/cap break at11.0m and raises the gallery rail to1.0m. The many decimals reproduce a diagnostic, not historical metric precision.

Nominal `wall_height_m` remains literal12.19m, with its attested source/value retained and a datum-caution note appended. Overall physical bounds remain EXACTLY1.28..4.32m horizontally and0..12.84968m vertically. Cap rise and finial are repartitioned within that existing maximum; ground feet are identical. We do not assert that Andreas's40ft measured the shaft, lantern break or total finial. `tower_shaft_height_m` is the shared derived answer for both mesh and aperture reader, so future profile changes cannot leave the window heights reading the old split.

Predicted diagnostic controls, not a rendered verdict:

| Feature | Source y pixels | Proposed axis prediction |
|---|---:|---:|
| Weak, occluded foot proxy |200±8|200.00|
| Gallery underside/lower band |89±2|89.00|
| Gallery top |within thick lower band|87.85|
| Upper rail |75±2|75.12|
| Drum/cap break |about60±3|59.97|
| Faint finial |38±3|36.43|

The camera is explicitly uncalibrated: principal point, eye height and foundation elevation are degenerate in a lone view, and the foot is occluded. These controls are a bounded hypothesis for actual rendering, not a historic camera station. No physical foundation lift is added to force a match.

The small shaft marks were inspected in the actual1842 plate and Commons reproduction (source details/picks under the sibling `T-2373-openings-next/source/`, source-picks.json). Two narrow apertures on the light/front-left face are clear; a third dark mark on the upper shaded right face is less certain. No unequivocal ground door is visible. Lower masonry marks and platform shadows are not made into a door. The candidate draws three reconstructed single-light small windows, with existing shared openings-kit casing/glass, on existing shaft facets8/10/7 (normal azimuths255/315/225), widths0.24/0.30/0.30m. Metric widths, normalized heights, glazing and facet assignments remain reconstructed. Source circa1838 appearance is not direct proof of July1835 detail.

Planar `face_openings` supports unjettied quarters/barracks, so it is not stretched to pretend a round tower has one flat facade. The bounded tower-only `tower_opening_layout` exposes actual facet rectangles. A private adapter maps the existing openings kit to the exact existing twelve-sided tapered facet plane and corrects winding; no shared-kit framework is changed. No ground door means no new entrance/apron is claimed. Default fronts stay unread; polygon collision, ground contact, physical radius, origin and sidecar placement remain unchanged.

Light verification passed:25 actual composed defaults/API; exact default tower face streams/materials for legacy/no-lantern/birdcage; five range fronts preserved; unchanged total bounds and ground feet;1062 proposed triangles, all finite/nondegenerate/reconstructed; actual window kit on exact facet planes; schema/patch checks. New profile has not been exported or visually reviewed. The original T-2373 image gate remains open.

Ground audit uses actual prior exported masters and real app `addFeet`/`Heightfield`: broad anchor2.472863m, narrow anchor2.474625m, change+0.001761m. The1834 harbor-cut epoch covers both1835 and1838. `photo_match` instead uses a flat plane at−0.01m and zero object height, so its apparent low foot is not an app terrain/bedding diagnosis. Do not raise the app foundation by the apparent1.37m framing offset. See sibling `T-2373-openings-next/grade-check.json` and `vertical-check.json`.

Recovery requirements: this full package's baseline/candidate/scripts/camera/source/inputs, the frozen final-fort/narrow/five-range packages, and the actual prior narrow review directory20261023-092203-154696. `inputs.json` pins the three patched files. Any concurrent module/record integration must merge guarded per-field deltas; do not wholesale restore stale modules or manifests. Prepared fixture uses only one lighthouse asset per baseline/proposed run, same NEW diagnostic camera for both, and no canonical writes. Rendering, actual image review, full25 bake, contact checks and repository gates remain pending.
