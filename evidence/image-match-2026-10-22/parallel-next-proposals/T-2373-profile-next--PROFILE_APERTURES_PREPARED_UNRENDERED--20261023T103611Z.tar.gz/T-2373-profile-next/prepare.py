from pathlib import Path
import ast,hashlib,json,difflib,shutil
H=Path(__file__).resolve().parent;B=H/'baseline';C=H/'candidate';N=Path('/tmp/chicago-next-model/T-2373-narrow-trial/candidate');F=Path('/tmp/chicago-next-model/T-2387-face-layout-next/candidate');O=Path('/tmp/chicago-next-model/T-2373-openings-next/candidate');root='chicago/4d/';pr=root+'generators/archetypes/fort_structure_params.py';gr=root+'generators/archetypes/fort_structure.py';rr=root+'data/structures/chicago_lighthouse_1832.json'
def nodes(text):return {n.name:n for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def segment(text,node):return ast.get_source_segment(text,node)
def replace_node(text,name,new):
 n=nodes(text)[name];lines=text.splitlines(True);lines[n.lineno-1:n.end_lineno]=[new+'\n'];return ''.join(lines)
def classnode(text,name):return next(n for n in nodes(text)['FortStructureParams'].body if getattr(n,'name',None)==name)
def first_guard(text,field):
 n=next(n for n in classnode(text,'validate').body if isinstance(n,ast.If) and ast.unparse(n.test)==f'self.{field} is not None');return '        '+segment(text,n)+'\n'
def fieldseg(text,name):
 n=next(n for n in nodes(text)['FortStructureParams'].body if isinstance(n,ast.AnnAssign) and n.target.id==name);return '    '+segment(text,n)+'\n\n'
def addfield(text,feature,name):
 text=text.replace('    # per-attribute confidence, keyed by the attribute name in the record',fieldseg(feature,name)+'    # per-attribute confidence, keyed by the attribute name in the record',1)
 text=text.replace('    def validate(self) -> None:\n','    def validate(self) -> None:\n'+first_guard(feature,name),1)
 text=text.replace('        confidence=confidences,',f'        {name}=val("{name}", None),\n        confidence=confidences,',1)
 return text
# Compose face controls into NARROW baseline via scoped feature extraction, not whole-module restoration.
np=(N/pr).read_text();fp=(F/pr).read_text();basep=addfield(np,fp,'face_openings').replace('"tower_diameter_m",','"tower_diameter_m", "face_openings",',1)
for name in ['wall_openings','front_wall']:basep+='\n\n'+segment(fp,nodes(fp)[name])+'\n'
ng=(N/gr).read_text();fg=(F/gr).read_text();baseg=replace_node(ng,'_openings',segment(fg,nodes(fg)['_openings']));baseg+='\n\n'+segment(fg,nodes(fg)['_explicit_openings'])+'\n';baseg=baseg.replace('import FortStructureParams  # noqa: E402','import FortStructureParams, wall_openings  # noqa: E402')
basefiles={pr:basep,gr:baseg,rr:(N/rr).read_text()}
for p in F.rglob('*'):
 if p.is_file() and p.suffix in ['.py','.json']:
  rel=str(p.relative_to(F))
  if rel not in [pr,gr]:basefiles[rel]=p.read_text()
for rel,text in basefiles.items():
 for d in [B,C]:(d/rel).parent.mkdir(parents=True,exist_ok=True);(d/rel).write_text(text)
# Add bounded tower-only apertures, sharing the frozen source-evidence choice.
op=(O/pr).read_text();og=(O/gr).read_text();t=addfield(basep,op,'tower_openings').replace('"tower_diameter_m",','"tower_diameter_m", "tower_openings", "tower_profile",',1);t+='\n\n'+segment(op,nodes(op)['tower_opening_layout'])+'\n'
# New profile is a dictionary so all three reconstructed vertical controls travel together.
t=t.replace('    # per-attribute confidence, keyed by the attribute name in the record','''    # Explicit reconstructed partition; overall max still uses the old nominal
    # height/cap formula. None preserves every legacy tower vertex.
    tower_profile: dict | None = field(default=None, kw_only=True)

    # per-attribute confidence, keyed by the attribute name in the record''',1)
validation='''        if self.tower_profile is not None:
            if self.kind != "tower" or not self.lantern or self.lantern_profile != "birdcage_dome":
                raise ParamError("tower_profile requires a lit birdcage_dome tower")
            profile = self.tower_profile
            if not isinstance(profile, dict) or set(profile) != {
                    "gallery_underside_m", "cap_base_m", "gallery_rail_height_m"}:
                raise ParamError("tower_profile needs gallery_underside_m/cap_base_m/gallery_rail_height_m")
            if any(isinstance(v, bool) or not isinstance(v, (float, int))
                   or not math.isfinite(v) for v in profile.values()):
                raise ParamError("tower_profile dimensions must be finite numbers")
            radius = (self.tower_diameter_m if self.tower_diameter_m is not None else self.width_m)/2
            maximum = self.wall_height_m+radius*self.taper*.7
            floor, cap, rail = (profile["gallery_underside_m"],profile["cap_base_m"],
                                profile["gallery_rail_height_m"])
            if not (1 <= floor < cap-.6 and .3 <= rail <= 1.4
                    and floor+.09+rail < cap and cap < maximum-.1):
                raise ParamError("tower_profile gallery/rail/cap do not fit the unchanged overall max")
'''
t=t.replace('    def validate(self) -> None:\n','    def validate(self) -> None:\n'+validation,1)
t=t.replace('        confidence=confidences,','        tower_profile=val("tower_profile", None),\n        confidence=confidences,',1)
# One shared shaft-height property drives both geometry and aperture/source reader.
t=t.replace('    def validate(self) -> None:', '''    @property
    def tower_shaft_height_m(self) -> float:
        return (self.wall_height_m*.86 if self.tower_profile is None
                else self.tower_profile["gallery_underside_m"])

    def validate(self) -> None:''',1)
t=t.replace('shaft = self.wall_height_m*.86','shaft = self.tower_shaft_height_m').replace('shaft = p.wall_height_m * .86','shaft = p.tower_shaft_height_m')
(C/pr).write_text(t)
# Existing tower is changed only by guarded dispatch + shared partition height.
t=baseg.replace('import FortStructureParams, wall_openings','import FortStructureParams, wall_openings, tower_opening_layout',1)
s=t.index('def _tower(');idx=t.index('    if not p.lantern:',s);t=t[:idx]+'''    if p.tower_openings:
        _tower_apertures(b, p, cx, cy, r0, shaft)

'''+t[idx:]
# Retain exact old default arithmetic and enter new height only on explicit opt-in.
s=t.index('def _tower(');idx=t.index('    shaft = h * 0.86',s);end=idx+len('    shaft = h * 0.86');t=t[:end]+'''\n    if p.tower_profile is not None:
        shaft = p.tower_shaft_height_m'''+t[end:]
s=t.index('def _birdcage_lantern(');idx=t.index('    # All emitted members',s);t=t[:idx]+'''    if p.tower_profile is not None:
        _birdcage_partitioned(b, p, cx, cy, r1, shaft, h)
        return
'''+t[idx:]
for name in ['_TowerFacetBuilder','_tower_apertures']:t+='\n\n'+segment(og,nodes(og)[name])+'\n'
# Isolate new partition helper: the frozen default body remains verbatim after its dispatch guard.
oldbird=segment(ng,nodes(ng)['_birdcage_lantern']);helper=oldbird.replace('def _birdcage_lantern(', 'def _birdcage_partitioned(',1)
helper=helper.replace('    # All emitted members', '''    cap_base = p.tower_profile["cap_base_m"]
    rail = p.tower_profile["gallery_rail_height_m"]
    maximum = h+r1*.7
    cap_total = maximum-cap_base
    # All emitted members''',1)
helper=helper.replace('floor + 0.65','floor + rail').replace('floor + 0.60','floor + rail - 0.05')
helper=helper.replace('y + 0.0275, h, c, M_DARK','y + 0.0275, cap_base, c, M_DARK')
helper=helper.replace('ring(lantern_r, h)','ring(lantern_r, cap_base)').replace('floor, h, c, M_DARK','floor, cap_base, c, M_DARK').replace('h - 0.06, h, M_DARK','cap_base - 0.06, cap_base, M_DARK')
helper=helper.replace('rise = lantern_r * 1.06, r1 * 0.55','rise = lantern_r * 1.06, cap_total*.55/.7')
helper=helper.replace('ring(cap_r, h, 24)','ring(cap_r, cap_base, 24)').replace('h + rise','cap_base + rise').replace('r1 * 0.15','cap_total*.15/.7')
# Replace misleading inherited docstring by an explicit reconstruction note.
helper=replace_node(helper,'_birdcage_partitioned',ast.unparse(nodes(helper)['_birdcage_partitioned']))
node=nodes(helper)['_birdcage_partitioned'];doc=segment(helper,node.body[0]);helper=helper.replace(doc,'''"""Reconstructed partition from Castelnau controls; same overall envelope.

    Nominal40ft datum remains unresolved. New shaft/cage/cap/rail subdivision
    changes no ground height, footprint, origin, bearing or overall maximum.
    """''',1)
t+='\n\n'+helper+'\n';(C/gr).write_text(t)
r=json.loads((O/rr).read_text());r['phases'][0]['form']['tower_profile']={'value':{'gallery_underside_m':8.719767307057847,'cap_base_m':11.0,'gallery_rail_height_m':1.0},'confidence':'reconstructed','sources':['castelnau_1842_chicago_harbor'],'note':'Bounded image trial after actual narrow-tower review: existing total maximum12.84968m and nominal wall_height_m literal12.19 are preserved. Reconstructed gallery underside8.719767m, cap/drum break11.0m and1.0m rail partition the same overall envelope to source floor89±2px, cap/drum break~60±3px and upper rail75±2px under the separately recorded evidence-based framing diagnostic. The many decimals reproduce a diagnostic, not historical measurement. Shaft/lantern subdivision, exact vertical proportions and1838-to1835 continuity are reconstructed/inferred; Andreas40ft has no proven datum and is not asserted as shaft-only or overall here. No foundation elevation or app terrain change. This is not an accepted camera or image match.'}
r['phases'][0]['form']['wall_height_m']['note']+=' PROFILE TRIAL CAUTION: this literal12.19m remains the nominal40ft control; its historical datum is unresolved. Do not read the reconstructed profile as proof that40ft measured the shaft, cage top or overall finial.'
r['research_note']+=' SOURCE-PROFILE TRIAL: actual Castelnau source controls support a lower shaft/gallery divide and taller lantern assembly within the unchanged reconstructed total envelope. Ground, georeference and nominal40ft literal stay fixed; a source-bounded framing diagnostic is separate from physical foundation height. Three small apertures are proposed; a visible ground door is not identified.'
(C/rr).write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
camera=json.loads(Path('/tmp/chicago-next-model/T-2373-camera-audit/camera-corrected-controls-diagnostic.json').read_text());camera['principal_px'][1]=174.54060502046752;camera['solve']={'status':'provisional_reconstructed_NOT_SOLVED','method':'Framing shift from actual source weak toe200±8 and finial38±3, retains square pixels/focal/distance; physical profile adjusts gallery to89±2. This is an evidence-bounded framing diagnostic, not a measured camera station or a change to app elevation.','outstanding':'Source foot is occluded; principal/eyeheight/object-grade degeneracy remains. Nominal40ft datum unresolved; source circa1838-to1835 continuity not proved.'};(H/'camera-profile-research.json').write_text(json.dumps(camera,indent=2)+'\n')
patch=[];inputs=[]
for rel in [pr,gr,rr]:
 old=(B/rel).read_text();new=(C/rel).read_text();patch+=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel));inputs.append({'path':rel,'baseline_sha256':hashlib.sha256(old.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(new.encode()).hexdigest()})
(H/'profile-and-openings-next.patch').write_text(''.join(patch));(H/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');print('Composed narrow+five-range baseline;3file profile/window overlay and diagnosticcamera; no exports or canonical writes')
