#!/usr/bin/env python3
"""Prepare isolated1-ID baseline/trial fixture; run only after parent slot release."""
from pathlib import Path
import datetime,hashlib,json,shutil
H=Path(__file__).resolve().parent;REPO=Path('/workspace/chicago/chicago/4d');SELECTIVE=Path('/tmp/chicago-next-model/fort-selective-integration/staged/candidate')
meta=json.loads((H/'inputs.json').read_text())
for row in meta:
 assert hashlib.sha256((H/'baseline'/row['path']).read_bytes()).hexdigest()==row['baseline_sha256']
 assert hashlib.sha256((H/'candidate'/row['path']).read_bytes()).hexdigest()==row['candidate_sha256']
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S-%f');run=H/'runs'/stamp;assert not run.exists();run.mkdir(parents=True)
sid='chicago_lighthouse_1832';asset='chicago_lighthouse_1832__tower_1832.glb'
manifest=json.loads((REPO/'assets/manifest.json').read_text());assert asset in manifest['assets']
for kind in ['baseline','proposed']:
 root=run/kind;root.mkdir();shutil.copytree(REPO/'generators',root/'generators',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 for rel in ['data/scenes','renderers/web/vendor/three-0.185.1']:shutil.copytree(REPO/rel,root/rel)
 for rel in ['data/datum.json','renderers/web/js/keith-stone.js','tools/photo_match.mjs','tools/photo_match_group.mjs']:
  dest=root/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(REPO/rel,dest)
 for row in meta:
  source=H/('baseline' if kind=='baseline' else 'candidate')/row['path'];dest=root/source.relative_to(H/('baseline' if kind=='baseline' else 'candidate')/'chicago/4d');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
 photo=Path(json.loads((H/'camera-profile-research.json').read_text())['photo']);dest=root/'data/sources/assets'/photo.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(photo,dest)
 source=root/'data/sources/castelnau_1842_chicago_harbor.json';shutil.copy2(H/'source-next-research.json',source)
 camera=json.loads((H/'camera-profile-research.json').read_text());camera['photo']='../../../data/sources/assets/'+photo.name;dest=root/'docs/RESEARCH/profile-trial/camera.json';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(camera,indent=2)+'\n')
 (root/'assets/gltf').mkdir(parents=True,exist_ok=True);shutil.copy2(REPO/'assets/gltf'/asset,root/'assets/gltf'/asset)
 isolated={**manifest,'assets':{asset:manifest['assets'][asset]}};(root/'assets/manifest.json').write_text(json.dumps(isolated,indent=2)+'\n')
 dependencies=Path('/workspace/node_modules').resolve();assert dependencies.is_dir();(root/'node_modules').symlink_to(dependencies,target_is_directory=True)
 (root/'FIXTURE-ONLY.txt').write_text('Research1-ID fixture, not a complete town or canonical recipe refresh.\n')
(run/'scope.json').write_text(json.dumps({'assets':[{'asset':asset,'structure_id':sid,'phase_id':'tower_1832','archetype':'fort_structure'}]})+'\n');(H/'latest-run.txt').write_text(str(run)+'\n');print(run)
