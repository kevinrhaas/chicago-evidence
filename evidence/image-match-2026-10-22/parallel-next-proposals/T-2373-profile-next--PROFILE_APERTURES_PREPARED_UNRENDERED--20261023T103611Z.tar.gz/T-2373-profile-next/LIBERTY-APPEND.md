### L-lighthouse-profile-apertures-T2373-next — explicit vertical partition and tiny windows

Covers: `chicago_lighthouse_1832` phase`tower_1832`.

The actual Castelnau1842 publication (`castelnau_1842_chicago_harbor`) shows a lower gallery band, upper rail, tall lantern assembly, faint finial and small dark shaft apertures. We reconstruct gallery underside8.719767m, cap break11.0m, rail1.0m and three small single-light windows on selected existing facets. Their exact metrics, framing/glazing and facet assignment are not measured facts. The shaded third mark is less certain, and a ground door has not been identified. A source-based framing diagnostic changes principalY; no physical georeference or foundation is moved. Existing total envelope and nominal12.19m/40ft literal are preserved, while the source's height datum remains unresolved. The circa1838 depiction's continuity back to July1835 remains an inference. All new geometry is reconstructed. This is a trial, not an image match.
