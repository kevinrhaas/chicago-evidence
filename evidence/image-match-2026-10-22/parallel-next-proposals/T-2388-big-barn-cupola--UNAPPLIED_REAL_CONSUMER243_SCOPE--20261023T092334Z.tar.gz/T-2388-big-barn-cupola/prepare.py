from pathlib import Path
import json,difflib,hashlib
R=Path('/workspace/chicago/chicago/4d');P=Path(__file__).resolve().parent
out={}
s=(R/'generators/archetypes/outbuilding_params.py').read_text()
s=s.replace('"open_sides", "loft", "board_gap_m", "paint", "chimneys",','"open_sides", "loft", "board_gap_m", "paint", "chimneys", "cupola",')
s=s.replace('    def __post_init__(self) -> None:', '''    # Occurrence may be attested; every emitted section/dimension is reconstructed.
    # Keyword-only preserves all existing positional constructor arguments.
    cupola: bool = field(default=False, kw_only=True)

    def __post_init__(self) -> None:''',1)
s=s.replace('    def validate(self) -> None:\n','''    def validate(self) -> None:
        if type(self.cupola) is not bool:
            raise ParamError("cupola must be a boolean")
        if self.cupola and (self.roof_type != "gable" or min(self.width_m, self.depth_m) < 3.0):
            raise ParamError("cupola requires a gable roof with both spans at least3m")
        if self.cupola:
            from archetypes.outbuilding_cupola import top_z
            if top_z(self) > MAX_HEIGHT_M:
                raise ParamError("cupola exceeds the outbuilding9m total-height ceiling")
''',1)
s=s.replace('        loft=bool(val("loft", False)),','        loft=bool(val("loft", False)),\n        cupola=val("cupola", False),',1)
out['generators/archetypes/outbuilding_params.py']=s
s=(R/'generators/archetypes/outbuilding.py').read_text()
s=s.replace('    _roof(b, p, c_roof)\n','''    _roof(b, p, c_roof)
    if p.cupola:
        # Loaded only by opted-in records; mesh_inputs hashes this geometry helper.
        from archetypes.outbuilding_cupola import build_cupola
        build_cupola(b, p, board_mat=M_BOARD, roof_mat=M_ROOF, dark_mat=M_DARK)
''',1)
out['generators/archetypes/outbuilding.py']=s
out['generators/archetypes/outbuilding_cupola.py']='''"""Optional barn cupola; all exact geometry is reconstructed (T-2388).

Harrison's plan, reproduced in Andreas1884p113, names BigBarnwithCupola.
It supplies no elevation, section, material, glazing, vent count or dimensions.
This modest unglazed timber vent is an explicitly chosen representation of the
word, not a measured picture match. The second-fort blockhouse cupola is separate.
"""
from __future__ import annotations
import math

WIDTH_M = 1.6
DRUM_ABOVE_RIDGE_M = 1.0
CAP_OVERHANG_M = 0.10
CAP_PITCH_DEG = 35.0
VENT_HEIGHT_M = 0.20
VENT_MARGIN_M = 0.20


def top_z(p):
    return p.apex_z_m + DRUM_ABOVE_RIDGE_M + (WIDTH_M/2.0+CAP_OVERHANG_M)*math.tan(math.radians(CAP_PITCH_DEG))


def build_cupola(b, p, *, board_mat, roof_mat, dark_mat):
    """Append a centred square drum and pyramid cap to an existing gable roof.

    The solid drum extends below the roof intersection so no daylight seam appears.
    The existing roof remains intact beneath it; no interior/working ventilation
    is claimed. Four inset dark faces suggest an unglazed vent, not sash/glazing.
    """
    if not p.cupola:
        return
    c = 1.0  # all sections, heights, profiles and pattern are reconstructed
    cx, cy = p.width_m/2.0, p.depth_m/2.0
    half = WIDTH_M/2.0
    x0, x1, y0, y1 = cx-half, cx+half, cy-half, cy+half
    ridge = p.apex_z_m
    base = ridge-half*math.tan(math.radians(p.roof_pitch_deg))-0.03
    top = ridge+DRUM_ABOVE_RIDGE_M
    ring = [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]
    for i in range(4):
        a,z=ring[i],ring[(i+1)%4]
        b.add_poly([(a[0],a[1],base),(z[0],z[1],base),
                    (z[0],z[1],top),(a[0],a[1],top)],c,board_mat)
        # Panels are 1cm proud of the face (as existing outbuilding openings).
        ux,uy=(z[0]-a[0])/WIDTH_M,(z[1]-a[1])/WIDTH_M
        nx,ny=uy,-ux
        aa=(a[0]+ux*VENT_MARGIN_M+nx*0.01,a[1]+uy*VENT_MARGIN_M+ny*0.01)
        zz=(z[0]-ux*VENT_MARGIN_M+nx*0.01,z[1]-uy*VENT_MARGIN_M+ny*0.01)
        lo,hi=top-0.35-VENT_HEIGHT_M,top-0.35
        b.add_poly([(aa[0],aa[1],lo),(zz[0],zz[1],lo),
                    (zz[0],zz[1],hi),(aa[0],aa[1],hi)],c,dark_mat)
    caphalf=half+CAP_OVERHANG_M
    eaves=[(cx-caphalf,cy-caphalf,top),(cx+caphalf,cy-caphalf,top),
           (cx+caphalf,cy+caphalf,top),(cx-caphalf,cy+caphalf,top)]
    apex=(cx,cy,top_z(p))
    for i in range(4):
        b.add_poly([eaves[i],eaves[(i+1)%4],apex],c,roof_mat)
'''
s=(R/'generators/mesh_inputs.py').read_text()
s=s.replace('    # T-1730: an archetype that', '    # T-1730: an archetype that')
anchor='    out = {}\n    for p in wanted:'
assert anchor in s
s=s.replace(anchor,'''    # T-2388: the optional barn cupola is loaded only for this opted-in path.
    # Subsequent helper-only changes must stale every reader of that helper.
    if archetype == "outbuilding" and getattr(params, "cupola", False):
        wanted += [gen / "archetypes" / "outbuilding_cupola.py"]
    out = {}
    for p in wanted:''',1)
out['generators/mesh_inputs.py']=s
rel='data/structures/fort_dearborn_big_barn.json';data=json.loads((R/rel).read_text())
for ph in data['phases']:
 if ph.get('form',{}).get('cupola',{}).get('value') is True:
  ph['form']['cupola']['note']='The Harrison plan reproduced in Andreas1884p113 explicitly names "Big Barn with Cupola". The optional outbuilding helper now represents that word with a central1.6m square timber drum,1.0m rise above the existing ridge and a35degree pyramid cap with0.10m overhang. Occurrence is attested on this memory-amended1830plan reproduction; every dimension, exact profile, unglazed dark vent treatment, central position and material is reconstructed. No image identifies the barn elevation securely, and no source proves this cupola persisted unchanged to1835. This is an evidence-bounded representation, not a picture match.'
out[rel]=json.dumps(data,indent=2)+'\n'
patch=[];manifest=[]
for rel,s in out.items():
 f=P/'payload'/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
 old=(R/rel).read_text() if (R/rel).exists() else ''
 patch += difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/chicago/4d/'+rel if old else '/dev/null',tofile='b/chicago/4d/'+rel)
 manifest.append({'path':rel,'old_sha256':hashlib.sha256(old.encode()).hexdigest() if old else None,'new_sha256':hashlib.sha256(s.encode()).hexdigest()})
(P/'T-2388-big-barn-cupola.patch').write_text(''.join(patch));(P/'payload-hashes.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Prepared',len(out),'files; repository unchanged')
