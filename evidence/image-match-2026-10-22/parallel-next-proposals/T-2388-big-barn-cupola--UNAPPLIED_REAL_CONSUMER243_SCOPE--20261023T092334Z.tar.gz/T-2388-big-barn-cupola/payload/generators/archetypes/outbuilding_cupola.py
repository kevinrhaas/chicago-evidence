"""Optional barn cupola; all exact geometry is reconstructed (T-2388).

Harrison's plan, reproduced in Andreas1884p113, names BigBarnwithCupola.
It supplies no elevation, section, material, glazing, vent count or dimensions.
This modest unglazed timber vent is an explicitly chosen representation of the
word, not a measured picture match. The second-fort blockhouse cupola is separate.
"""
from __future__ import annotations
import math

WIDTH_M = 1.6
DRUM_ABOVE_RIDGE_M = 1.0
CAP_OVERHANG_M = 0.10
CAP_PITCH_DEG = 35.0
VENT_HEIGHT_M = 0.20
VENT_MARGIN_M = 0.20


def top_z(p):
    return p.apex_z_m + DRUM_ABOVE_RIDGE_M + (WIDTH_M/2.0+CAP_OVERHANG_M)*math.tan(math.radians(CAP_PITCH_DEG))


def build_cupola(b, p, *, board_mat, roof_mat, dark_mat):
    """Append a centred square drum and pyramid cap to an existing gable roof.

    The solid drum extends below the roof intersection so no daylight seam appears.
    The existing roof remains intact beneath it; no interior/working ventilation
    is claimed. Four inset dark faces suggest an unglazed vent, not sash/glazing.
    """
    if not p.cupola:
        return
    c = 1.0  # all sections, heights, profiles and pattern are reconstructed
    cx, cy = p.width_m/2.0, p.depth_m/2.0
    half = WIDTH_M/2.0
    x0, x1, y0, y1 = cx-half, cx+half, cy-half, cy+half
    ridge = p.apex_z_m
    base = ridge-half*math.tan(math.radians(p.roof_pitch_deg))-0.03
    top = ridge+DRUM_ABOVE_RIDGE_M
    ring = [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]
    for i in range(4):
        a,z=ring[i],ring[(i+1)%4]
        b.add_poly([(a[0],a[1],base),(z[0],z[1],base),
                    (z[0],z[1],top),(a[0],a[1],top)],c,board_mat)
        # Panels are 1cm proud of the face (as existing outbuilding openings).
        ux,uy=(z[0]-a[0])/WIDTH_M,(z[1]-a[1])/WIDTH_M
        nx,ny=uy,-ux
        aa=(a[0]+ux*VENT_MARGIN_M+nx*0.01,a[1]+uy*VENT_MARGIN_M+ny*0.01)
        zz=(z[0]-ux*VENT_MARGIN_M+nx*0.01,z[1]-uy*VENT_MARGIN_M+ny*0.01)
        lo,hi=top-0.35-VENT_HEIGHT_M,top-0.35
        b.add_poly([(aa[0],aa[1],lo),(zz[0],zz[1],lo),
                    (zz[0],zz[1],hi),(aa[0],aa[1],hi)],c,dark_mat)
    caphalf=half+CAP_OVERHANG_M
    eaves=[(cx-caphalf,cy-caphalf,top),(cx+caphalf,cy-caphalf,top),
           (cx+caphalf,cy+caphalf,top),(cx-caphalf,cy+caphalf,top)]
    apex=(cx,cy,top_z(p))
    for i in range(4):
        b.add_poly([eaves[i],eaves[(i+1)%4],apex],c,roof_mat)
