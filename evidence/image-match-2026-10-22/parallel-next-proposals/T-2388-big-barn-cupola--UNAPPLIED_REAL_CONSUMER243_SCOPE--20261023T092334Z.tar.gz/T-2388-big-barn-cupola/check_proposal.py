from pathlib import Path
import ast,dataclasses,hashlib,importlib.util,inspect,json,math,sys,types,copy
P=Path(__file__).resolve().parent;R=Path('/workspace/chicago/chicago/4d');sys.path.insert(0,str(R/'generators'))
def load(name,path):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m);return m
old=load('barn_old_params',R/'generators/archetypes/outbuilding_params.py');new=load('barn_new_params',P/'payload/generators/archetypes/outbuilding_params.py');helper=load('archetypes.outbuilding_cupola',P/'payload/generators/archetypes/outbuilding_cupola.py')
def normal(x):
 if dataclasses.is_dataclass(x):
  d=dataclasses.asdict(x);d.pop('cupola',None);return d
 if isinstance(x,(tuple,list)):return [normal(v) for v in x]
 if isinstance(x,dict):return {k:normal(v) for k,v in x.items()}
 return x
class B:
 def __init__(self,name):self.events=[];self.polys=[]
 def add_poly(self,pts,c,mat):self.polys.append((pts,c,mat))
legacy_names=['_log_walls','_core_walls','_boarded_walls','_open_bays','_interior','_roof','_forge_stack','_doorway','_loft_door','_vent']
def build_prefix(path):
 tree=ast.parse(path.read_text());f=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='build');body=[]
 for n in f.body:
  if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='finish' for t in n.targets):break
  body.append(n)
 f.body=body+[ast.Return(value=ast.Name(id='b',ctx=ast.Load()))];f.args.args[0].annotation=None
 ns={'MeshBuilder':B,'M_BOARD':2,'M_ROOF':3,'M_DARK':4,'M_CHIMNEY':6,'boarding_holes':new.boarding_holes,'vent_rect':new.vent_rect}
 for name in legacy_names:
  def stub(b,*args,_name=name,**kw):
   b.events.append((_name,normal(args),normal(kw)))
   return args[0].apex_z_m if _name=='_roof' else None
  ns[name]=stub
 exec(compile(ast.fix_missing_locations(ast.Module(body=[f],type_ignores=[])),str(path),'exec'),ns);return ns['build']
ob=build_prefix(R/'generators/archetypes/outbuilding.py');nb=build_prefix(P/'payload/generators/archetypes/outbuilding.py')
# All functions other than build must be exactly unchanged AST, including defaults.
def funcs(path):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name!='build'}
assert funcs(R/'generators/archetypes/outbuilding.py')==funcs(P/'payload/generators/archetypes/outbuilding.py')
a=inspect.signature(old.OutbuildingParams);b=inspect.signature(new.OutbuildingParams)
assert [(k,v) for k,v in b.parameters.items() if k!='cupola']==list(a.parameters.items());assert b.parameters['cupola'].kind is inspect.Parameter.KEYWORD_ONLY
masters=json.load(open(R/'assets/manifest.json'))['assets'];family={n:d for n,d in masters.items() if d.get('archetype')=='outbuilding'}
results=[];changed=[]
for name,d in sorted(family.items()):
 rec=json.load(open(R/'data/structures'/f"{d['structure_id']}.json"));ph=next(x for x in rec['phases'] if x['id']==d['phase_id']);x=old.from_phase(ph,rec);y=new.from_phase(ph,rec)
 assert normal(x)==normal(y),(name,'legacyparameterdrift')
 before,after=ob(x,'fixture'),nb(y,'fixture');assert before.events==after.events,(name,'legacybuildpathdrift')
 if after.polys:changed.append(name)
 assert bool(after.polys)==y.cupola,(name,'readerdoesnotdrivegeometry')
 if y.cupola:
  assert d['structure_id']=='fort_dearborn_big_barn';pts=[]
  for poly,c,mat in after.polys:
   assert c==1.0 and all(math.isfinite(v) for q in poly for v in q)
   # Every polygon has nonzero cross product and expected outward/upward winding.
   aa,bb,cc=poly[:3];u=[bb[i]-aa[i] for i in range(3)];v=[cc[i]-aa[i] for i in range(3)];cross=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];assert sum(t*t for t in cross)>1e-10
   if mat==3:assert cross[2]>0
   pts+=poly
  bounds=[[min(q[i] for q in pts),max(q[i] for q in pts)] for i in range(3)]
  assert bounds[0][0]>0 and bounds[0][1]<y.width_m and bounds[1][0]>0 and bounds[1][1]<y.depth_m
  assert bounds[2][0]<y.apex_z_m<bounds[2][1]
  geom={'polygons':len(after.polys),'face_vertices':len(pts),'raw_triangles':sum(len(v[0])-2 for v in after.polys),'bounds_blender_m':bounds,'confidence':1.0,'actual_build_prefix_read_cupola':True}
 results.append({'asset':name,'phase_id':d['phase_id'],'structure_id':d['structure_id'],'legacy_parameters_equal':True,'legacy_helper_calls_equal':True,'new_polygons':len(after.polys)})
assert len(changed)==1
invalid=0
for val in (1,0,'true',None,[],{}):
 try:new.OutbuildingParams(14.4,9.4,cupola=val).validate()
 except new.ParamError:invalid+=1
 else:raise AssertionError(('invalidcupola',val))
for kw in ({'roof_type':'shed'},{'width_m':2.9},{'wall_height_m':4.8}):
 args={'width_m':14.4,'depth_m':9.4,'cupola':True};args.update(kw)
 try:new.OutbuildingParams(**args).validate()
 except new.ParamError:invalid+=1
 else:raise AssertionError('invalidcupolaroof')
# Conditional geometry input must include helper only when production reader can run it.
T=P/'hash-fixture';(T/'generators/archetypes').mkdir(parents=True,exist_ok=True)
for rel in ('generators/emit.py','generators/archetypes/outbuilding.py','generators/archetypes/outbuilding_cupola.py'):
 f=T/rel;src=P/'payload'/rel
 if not src.exists():src=R/rel
 if not f.exists():f.symlink_to(src)
tree=ast.parse((P/'payload/generators/mesh_inputs.py').read_text());func=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_code_shas')
ns={'ROOT':T,'code_inputs':types.SimpleNamespace(geometry_modules=lambda:[]),'PURE_PYTHON':{},'PURE_PYTHON_HELPERS':{},'InputsError':ValueError,'Path':Path,'_sha_file':lambda p:hashlib.sha256(p.read_bytes()).hexdigest()}
exec(compile(ast.Module(body=[func],type_ignores=[]),'actual_mesh_inputs_function','exec'),ns)
no=ns['_code_shas']('outbuilding',new.OutbuildingParams(14.4,9.4));yes=ns['_code_shas']('outbuilding',new.OutbuildingParams(14.4,9.4,cupola=True));key='archetypes/outbuilding_cupola.py';assert key not in no and key in yes
receipt={'status':'PASS_lightweight_only','existing_positional_parameters':len(a.parameters),'new_keyword_only_fields':['cupola'],'manifest_family_master_count':len(family),'initial_full_family_freshness_scope':[x['asset'] for x in results],'intended_geometry_changes':changed,'unchanged_legacy_helpers_exact_AST':True,'all_legacy_parameter_and_build_call_sequences_equal':True,'geometry':geom,'invalid_cases_rejected':invalid,'conditional_helper_fingerprint_test':'actual production _code_shas extracted; minimal isolated fixture','cupola_helper_present_only_for_opt_in':True,'official_bake_glb_comparison_browser_full_preflight':'UNRUN','per_master':results}
(P/'lightweight-checks.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in ('initial_full_family_freshness_scope','per_master')},indent=2))
