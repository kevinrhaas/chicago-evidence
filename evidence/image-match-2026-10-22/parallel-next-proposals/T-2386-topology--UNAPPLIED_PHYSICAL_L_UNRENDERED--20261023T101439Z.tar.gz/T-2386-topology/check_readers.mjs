import fs from 'node:fs';
import assert from 'node:assert/strict';
const H=new URL('.',import.meta.url),read=p=>JSON.parse(fs.readFileSync(new URL(p,H),'utf8'));
function extract(file,n){const s=fs.readFileSync(new URL('readers/'+file,H),'utf8');const m=s.match(new RegExp('export function '+n+'\\([^]*?\\n}'));assert(m,'missing real reader '+n);return m[0].replace(/^export /,'');}
const footprintsFrom=new Function('DEG',extract('walker.js','footprintsFrom')+';return footprintsFrom;')(Math.PI/180);
const inside=new Function(extract('show-me.js','inside')+';return inside;')();
const footprintCentre=new Function(extract('show-me.js','footprintCentre')+';return footprintCentre;')();
const wallDistance=new Function('inside',extract('show-me.js','wallDistance')+';return wallDistance;')(inside);
const addFeet=new Function('FOOT_Y','FOOT_STEP_M','FOOT_CELL_M',extract('building-feet.js','addFeet')+';return addFeet;')(.05,1.,.5);
const p=read('overlay/candidate/chicago/4d/data/structures/wolf_point_tavern.json').phases[0].footprint.polygon;
const notch=[6,8],bodyA=[2.5,8],bodyB=[6,2.5];
assert(!inside(notch,p));assert(inside(bodyA,p));assert(inside(bodyB,p));
const centre=footprintCentre(p);assert(inside([centre.e,centre.n],p));
for(const angle of [0,37,90,193]){
 const placement={rotation_deg:angle,local_e:100,local_n:200};const fp=footprintsFrom(new Map([['wolf',{id:'wolf',sidecar:{archetype:'log_dwelling',placement,footprint:{polygon:p}}}]]))[0];
 const t=angle*Math.PI/180,c=Math.cos(t),s=Math.sin(t),world=([u,v])=>[100+u*c+v*s,200-u*s+v*c];
 assert(!inside(world(notch),fp.pts));assert(inside(world(bodyA),fp.pts));assert(inside(world(bodyB),fp.pts));assert.equal(fp.pts.length,6);
}
assert(wallDistance(centre,p,-1,0)<1);assert(wallDistance(centre,[[0,0],[7.2,0],[7.2,10.1],[0,10.1]],-1,0)>2);
const raw=read('overlay-raw-geometry.json'),v=raw.verts.map(([u,w,z])=>[u,z,-w]),indices=[];
for(const f of raw.faces)for(let i=1;i<f.length-1;i++)indices.push(f[0],f[i],f[i+1]);
const pos={count:v.length,getX:i=>v[i][0],getY:i=>v[i][1],getZ:i=>v[i][2]};const geo={getAttribute:n=>n==='position'?pos:null,getIndex:()=>({count:indices.length,getX:i=>indices[i]})};
const feet=addFeet(new Map(),geo);assert(feet.size>0);assert(![...feet.values()].some(([x,z])=>Math.hypot(x-notch[0],-z-notch[1])<1.));
assert([...feet.values()].some(([x,z])=>Math.abs(x-5)<.1&&-z>5&&-z<10.1),'inside L wall actual feet absent');
const result={status:'passed',actual_function_bodies_from_regular_copied_sources:true,no_Three_browser_or_renderer:true,real_walker_retains6vertex_concave_polygon:true,notch_open_and_both_arms_blocked_at4_rotations:true,real_ShowMe_wall_rays_use_concave_polygon:true,ShowMe_vertex_mean_local:centre,bbox_centre_local:[3.6,5.05],old_bbox_centre_local:[6,3.5],ShowMe_centre_shift_local:[centre.e-6,centre.n-3.5],real_feet_samples:feet.size,no_mesh_foot_samples_in_empty_notch:true,source_pole_still_inherited_position_outside_core_front:true,limits:'Pure reader functions executed, not whole app/terrain/performance/export/GLB proof. Official compilation/contact/application QA remain.'};
fs.writeFileSync(new URL('reader-check.json',H),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
