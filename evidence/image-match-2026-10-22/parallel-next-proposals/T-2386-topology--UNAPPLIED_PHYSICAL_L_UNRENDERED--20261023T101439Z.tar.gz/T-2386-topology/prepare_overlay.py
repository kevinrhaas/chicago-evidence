from pathlib import Path
import json,shutil,difflib,hashlib
H=Path(__file__).resolve().parent/'overlay';B=Path('/tmp/chicago-next-model/log81-materializer/05f6-sourceS-final/review-tree');H.mkdir(exist_ok=True)
paths=['chicago/4d/generators/archetypes/log_dwelling_params.py','chicago/4d/generators/archetypes/log_dwelling.py','chicago/4d/data/structures/wolf_point_tavern.json','chicago/4d/data/sources/blanchard_shober_1867_wolf_point.json']
for rel in paths:
 for k in ['baseline','candidate']:
  p=H/k/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(B/rel,p)
def edit(rel,a,b):
 p=H/'candidate'/rel;s=p.read_text();assert s.count(a)==1,(rel,a[:55],s.count(a));p.write_text(s.replace(a,b))
p=paths[0]
edit(p,'ADDITION_SIDES = ("front", "end")','ADDITION_SIDES = ("front", "end", "elbow")')
edit(p,'"roof_condition", "compound_parts", "front_door_state",','"roof_condition", "compound_parts", "front_door_state", "compound_joint", "roof_pipe",')
edit(p,'    compound_parts: tuple = field(default=(), kw_only=True)','''    compound_parts: tuple = field(default=(), kw_only=True)
    # None retains the first independent-room roof path. Elbow joins two equal
    # gable spans at an inside corner; its physical concave union is validated.
    compound_joint: str | None = field(default=None, kw_only=True)
    # (fraction along elbow core ridge, diameter, head above ridge), reconstructed.
    roof_pipe: tuple | None = field(default=None, kw_only=True)''')
edit(p,'        if self.compound_parts:\n            _validate_compound(self)','''        if self.compound_joint not in (None, "elbow"):
            raise ParamError("compound_joint is None or elbow")
        if self.compound_joint is not None and not self.compound_parts:
            raise ParamError("compound_joint needs compound_parts")
        if self.roof_pipe is not None:
            if self.compound_joint != "elbow":
                raise ParamError("roof_pipe requires the elbow joint")
            if (not isinstance(self.roof_pipe, tuple) or len(self.roof_pipe) != 3 or
                    any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in self.roof_pipe)):
                raise ParamError("roof_pipe needs three finite numbers")
            at,diameter,head=self.roof_pipe
            if not (0.15 <= at <= 0.85 and 0.08 <= diameter <= 0.25 and 0.3 <= head <= 1.5):
                raise ParamError("roof_pipe fraction/diameter/head outside bounds")
        if self.frame_addition_side == "elbow" and self.compound_joint != "elbow":
            raise ParamError("elbow addition needs the bounded joined compound")
        if self.compound_parts:
            _validate_compound(self)''')
edit(p,'        if self.frame_addition_side == "end":\n            if self.width_m - self.frame_addition_width_m < 2.0:','        if self.frame_addition_side in ("end", "elbow"):\n            if self.width_m - self.frame_addition_width_m < 2.0:')
edit(p,'        roof_ridge_axis=(None if val("roof_ridge_axis") is None','''        compound_joint=val("compound_joint"),
        roof_pipe=(None if val("roof_pipe") is None else tuple(val("roof_pipe"))),
        roof_ridge_axis=(None if val("roof_ridge_axis") is None''')
edit(p,'    if p.frame_addition_side == "end":\n        return 0.0, 0.0, w - p.frame_addition_width_m, d','    if p.frame_addition_side in ("end", "elbow"):\n        return 0.0, 0.0, w - p.frame_addition_width_m, d')
edit(p,'    if p.frame_addition_side == "end":\n        return w - fw, max(d - fd, 0.0), w, d','''    if p.frame_addition_side == "elbow":
        return w - fw, 0.0, w, fd
    if p.frame_addition_side == "end":
        return w - fw, max(d - fd, 0.0), w, d''')
edit(p,'    result=[]\n    for (x0,y0,x1,y1),_roof,_axis,opening in p.compound_parts:\n        if opening:','''    result=[]
    for (x0,y0,x1,y1),_roof,_axis,opening in p.compound_parts:
        if p.compound_joint == "elbow":
            # The front-wall API means +Y only: never flatten a +X side entry here.
            for item in opening or ():
                face,kind,u0,u1,z0,z1=item
                if face == "+y":result.append((y1,kind,u0,u1,z0,z1))
            continue
        if opening:''')
edit(p,'    if not 2 <= len(p.compound_parts) <= 8:','''    if p.compound_joint == "elbow":
        return _validate_elbow(p)
    if not 2 <= len(p.compound_parts) <= 8:''')
# Explicit plan/feature guard. It doesn't weaken the old independent-room branch.
pth=H/'candidate'/p
pth.write_text(pth.read_text()+'''

def _validate_elbow(p: LogDwellingParams) -> None:
    """Only the physically concave two-room, equal-span first elbow is supported."""
    if (len(p.compound_parts) != 2 or p.stories != 1 or p.roof_type != "gable" or
            not p.frame_addition or p.frame_addition_side != "elbow" or p.frame_addition_stories != 1 or
            p.frame_addition_cladding != "clapboard" or p.lean_to or p.piazza or p.loft or
            p.end_openings or p.front_set_out is not None or p.roof_ridge_axis is not None or
            p.hip_end is not None or p.front_door_state != "closed" or p.chimneys != 1 or
            p.chimney_ridge_at is None or p.chimney_end != "min" or p.chimney_head_m is not None or
            p.chimney_cross_m != 0 or p.door_w_m is not None or p.door_h_m is not None or
            p.window_w_m is not None or p.window_h_m is not None or p.front_shutters is not None or
            p.front_windows_per_side != 1):
        raise ParamError("elbow needs exactly two stated one-storey rooms, one ridge head and no unsupported facade/additions")
    if abs(p.addition_height_m-p.wall_height_m)>1e-9:
        raise ParamError("elbow eaves must agree")
    core=core_extent(p);add=addition_extent(p);cw=core[2]
    if (not 2 <= cw <= 8 or abs(add[3]-cw)>1e-9 or
            not 1 <= add[2]-add[0] <= 12 or p.depth_m <= add[3]+1):
        raise ParamError("elbow needs equal2..8m gable spans and two positive arms")
    expected=[(core,core,"y"),(add,(cw/2,0.,p.width_m,cw),"x")]
    for (wall,roof,axis,openings),(ew,er,ea) in zip(p.compound_parts,expected):
        if wall != ew or roof != er or axis != ea:
            raise ParamError("elbow room/roof extent differs from declared physical plan")
        if not isinstance(openings,(tuple,list)):
            raise ParamError("elbow openings must be explicit face/rectangle tuples")
        for item in openings:
            if len(item)!=6 or item[0] not in ("+x","+y") or item[1] not in ("door","window"):
                raise ParamError("elbow opening needs face,kind,u0,u1,z0,z1")
            face,kind,u0,u1,z0,z1=item
            if (face != ("+y" if axis == "y" else "+x") or
                    not all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) for v in (u0,u1,z0,z1))):
                raise ParamError("elbow opening lies on its own outward gable")
            lo,hi=(wall[0],wall[2]) if face=="+y" else (wall[1],wall[3])
            if not (lo+.15 <= u0 < u1 <= hi-.15 and 0 <= z0 < z1 <= p.wall_height_m-.15):
                raise ParamError("elbow opening outside its wall")
        ordered=sorted(openings,key=lambda a:a[2])
        if any(a[3]+.15>b[2] for a,b in zip(ordered,ordered[1:])):
            raise ParamError("elbow openings overlap")
''')
p=paths[1]
edit(p,'    if params.compound_parts:\n        _compound(b, params)','''    if params.compound_joint == "elbow":
        _elbow(b, params)
    elif params.compound_parts:
        _compound(b, params)''')
# p remains file path. Append helpers; all primitives are reconstructed.
pth=H/'candidate'/p
pth.write_text(pth.read_text()+'''

def _clip_plan(poly, a, c, bound, keep_less=True):
    """Clip a convex XY roof cell by a*x+c*y<=bound (or its opposite)."""
    out=[]
    for u,v in zip(poly,poly[1:]+poly[:1]):
        du=a*u[0]+c*u[1]-bound;dv=a*v[0]+c*v[1]-bound
        iu=du<=1e-10 if keep_less else du>=-1e-10
        iv=dv<=1e-10 if keep_less else dv>=-1e-10
        if iu:out.append(u)
        if iu!=iv:
            t=du/(du-dv);out.append((u[0]+t*(v[0]-u[0]),u[1]+t*(v[1]-u[1])))
    clean=[]
    for pt in out:
        if not clean or abs(pt[0]-clean[-1][0])+abs(pt[1]-clean[-1][1])>1e-9:clean.append(pt)
    if len(clean)>1 and abs(clean[0][0]-clean[-1][0])+abs(clean[0][1]-clean[-1][1])<1e-9:clean.pop()
    return clean


def _elbow_roof(b,p):
    """Upper envelope at a true L corner; no buried intersecting roof planes.

    First trial uses flush roof edges at the declared walls. Equal spans keep
    both ridges equal. Eave/valley/flashing details remain reconstructed.
    """
    cw=core_extent(p)[2];D=p.depth_m;W=p.width_m;h=p.wall_height_m;t=math.tan(math.radians(p.roof_pitch_deg))
    def emit(poly,z):
        if len(poly)>=3:b.add_poly([(x,y,z(x,y)) for x,y in poly],1.,M_ROOF)
    def rect(x0,y0,x1,y1):return [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]
    emit(rect(0,0,cw/2,D),lambda x,y:h+x*t)
    emit(rect(cw/2,cw,cw,D),lambda x,y:h+(cw-x)*t)
    # Core right slope survives above each cross-roof half.
    emit(_clip_plan(rect(cw/2,0,cw,cw/2),1,1,cw),lambda x,y:h+(cw-x)*t)
    emit(_clip_plan(rect(cw/2,cw/2,cw,cw),1,-1,0),lambda x,y:h+(cw-x)*t)
    # Cross roof starts at core ridge and ends at its outward +X gable.
    emit(_clip_plan(rect(cw/2,0,cw,cw/2),1,1,cw,False),lambda x,y:h+y*t)
    emit(rect(cw,0,W,cw/2),lambda x,y:h+y*t)
    emit(_clip_plan(rect(cw/2,cw/2,cw,cw),1,-1,0,False),lambda x,y:h+(cw-y)*t)
    emit(rect(cw,cw/2,W,cw),lambda x,y:h+(cw-y)*t)
    z=h+cw/2*t
    # +Y and +X pictured ends plus unseen rear core cap; CCW outward.
    b.add_poly([(cw,D,h),(0,D,h),(cw/2,D,z)],1.,M_ROOF)
    b.add_poly([(0,0,h),(cw,0,h),(cw/2,0,z)],1.,M_ROOF)
    b.add_poly([(W,0,h),(W,cw,h),(W,cw/2,z)],1.,M_ROOF)
    return z


def _elbow(b,p):
    """Bounded source-backed L massing; exact plan and all set-out reconstructed."""
    for i,(r,roof,axis,openings_) in enumerate(p.compound_parts):
        if i==0:hewn_log_wall(b,*r,0.,p.wall_height_m,1.,M_LOG,M_CHINK,skip=("bottom","top"))
        else:
            b.add_box(r[0],r[1],0.,r[2],r[3],p.wall_height_m,1.,M_FRAME,skip=("bottom","top"))
            _clapboard(b,*r,p.wall_height_m,1.)
        for face,kind,u0,u1,z0,z1 in openings_:
            axis_="x" if face=="+x" else "y";plane=r[2] if axis_=="x" else r[3]
            _opening(b,axis_,plane,u0,u1,z0,z1,1,1.,kind=kind,frame_wall=i==1,relief=.026 if i else RELIEF_M)
    ridge=_elbow_roof(b,p)
    _ridge_stack(b,p,*core_extent(p),ridge,p.chimney_ridge_at[0],1.,M_CHIMNEY_AFTER_PAINT if p.sign and p.sign_device else M_CHIMNEY_AFTER_SIGN)
    if p.roof_pipe is not None:
        at,diameter,head=p.roof_pipe;x=core_extent(p)[2]/2;y=at*p.depth_m;r=diameter/2
        low=ridge-r*math.tan(math.radians(p.roof_pitch_deg))-.1;top=ridge+head
        ring=[(x+r*math.cos(k*math.tau/8),y+r*math.sin(k*math.tau/8)) for k in range(8)]
        for (xa,ya),(xb,yb) in zip(ring,ring[1:]+ring[:1]):b.add_poly([(xa,ya,low),(xb,yb,low),(xb,yb,top),(xa,ya,top)],1.,M_DARK)
        b.add_poly([(xa,ya,top) for xa,ya in ring],1.,M_DARK)
    if p.sign:
        # Existing kit retained; its source position/height/lean still differs.
        if p.sign_mount == "sapling_pole":_sign_pole(b,p,ridge,p.worst_conf("sign","sign_mount"),p.conf("sign"),p.conf("sign_device"))
        else:_sign(b,p,p.conf("sign"))
''')
# Existing ridge helper resolves default core axisY from its5x10.1 plan.
rp=H/'candidate'/paths[2];r=json.loads(rp.read_text());ph=r['phases'][0];f=ph['form'];src=['blanchard_shober_1867_wolf_point']
ph['footprint']['polygon']=[[0,0],[7.2,0],[7.2,5],[5,5],[5,10.1],[0,10.1]]
ph['footprint']['note']+=' T-2386 L trial supersedes the former12x7 placeholder with a physical concaveL union. The NYPL sheet supports two outward gable ends meeting at an inside corner; exact5m spans,7.2x10.1m extents and absolute scale remain reconstructed. This is a5m gauge shape/camera hypothesis, not a traced survey. Geographic record origin/bearing remain, while bbox centre moves(-2.4,+1.55)m in local plan and actual occupied ground changes.'
ph['position']['note']+=' T-2386 physical-L trial retains this numericUTM origin and90degree bearing. The old40m south-face placement and approximate11/19m modern-bank setbacks describe the former12x7m placeholder, not a newly verified contact after the plan change. The new7.2m localX span moves the former south extent4.8m north and the10.1m localY span moves the max-east frontage3.1m east; bbox centre changes(+1.55E,+2.4N)m. These are consequences of reconstructed geometry, not new surveyed coordinates; existing40m along-bank/20m across-bank uncertainties remain. Normal scene/contact/terrain/route compilation and actual app review are still required.'

def attr(k,v,c,n):f[k]={'value':v,'confidence':c,'sources':src,'note':n}
attr('frame_addition_side','elbow','reconstructed','T-2386 L trial: a rear corner cross-wing replaces the unsupported inline/parallel reading. The inspected NYPL left roof recedes rightward and right roof leftward, with an inside wall corner. L disposition is inferred from those cues, while which pen was frame, its partition and every metric dimension remain reconstructed. Source does not establish July1835 continuity.')
attr('frame_addition_width_m',2.2,'reconstructed','T-2386 L trial:2.2m is the non-overlapping extension beyond the5m-wide core, within the reconstructed7.2m total span; the full cross-roof pen is5m deep. No source measures this partition or identifies hidden frame fabric.')
attr('frame_addition_depth_m',5.,'reconstructed','T-2386 L trial: reconstructed5m cross-pen depth is equal to the nominal5m core span to give a bounded simple joined roof; neither metre dimension is evidence.')
attr('frame_addition_height_m',2.6,'reconstructed','T-2386 L trial retains the core eave2.6m and gives the cross piece equal eaves. This is a construction/scale choice, not a measured or attested height.')
attr('roof_pitch_deg',42.,'reconstructed','T-2386 L trial rounds the analytic shape/camera hypothesis to42degrees on a nominal5m span. Source bounds its silhouette, not an exact angle, scale or camera. The numeric12-corner fit is within manual pick uncertainty; actual model comparison remains unrun.')
attr('compound_joint','elbow','reconstructed','T-2386 L trial uses exactly two connected non-overlapping rooms, a true concave physical polygon and clipped upper-envelope orthogonal roofs. Flush eaves, simple closed gable caps and unmeasured valley construction remain reconstructed. It does not reuse the old intersecting independent-roof approximation.')
rooms=[{'wall_rect':[0,0,5,10.1],'roof_rect':[0,0,5,10.1],'ridge_axis':'y','front_opening':[['+y','door',3.1,4.0,.02,1.8],['+y','window',1.1,1.8,1.1,1.7]]},{'wall_rect':[5,0,7.2,5],'roof_rect':[2.5,0,7.2,5],'ridge_axis':'x','front_opening':[['+x','door',2.9,3.8,.02,1.7]]}]
attr('compound_parts',rooms,'reconstructed','T-2386 L trial records the actual two-room physicalL and two outward gable entries. All rectangles, roof extents, face assignment, door/window stations/widths/heights and closed kit states are reconstructed proxies from the NYPL sheet, not surveyed dimensions or a proven frame/log partition. The+X entry is not falsely reported on the+Y front-wall API. Secondary-entry metadata still requires explicit consumer review; log gable courses, clapboard versus logs, roof/eave detail and pole remain different.')
attr('chimney_ridge_at',[.29],'reconstructed','T-2386 L trial places the broad head near the inside junction on the core ridge at0.29of its10.1m length. This supersedes0.58 on the incompatible inline core; exact host/fraction and hidden flue remain reconstructed. Existing0.45m shaft/0.5m head and one masonry-stack count stay.')
attr('roof_pipe',[.74,.14,.55],'reconstructed','T-2386 L trial gives the separate slender roof projection a core-ridge fraction0.74,0.14m diameter and0.55m exposed head. Dark eight-sided uncapped proxy, all sections/stations/finish/absence of cap are reconstructed; metal/stove/interior is not identified and it is not silently counted as another masonry stack.')
f['stories']['note']+=' T-2386 L review has now inspected all eight ticket views. Its one-storey interpretation is supported by the pictured low gable ends, but the retrospective views do not establish the exactJuly1835 state.'
f['roof_type']['note']+=' T-2386 L review now cites the inspected1867 NYPL sheet for the visible gable category; roof plan, scale and chosen angle remain reconstructed.'
r['research_note']+=' T-2386 L review has now inspected those retrospective pictures. The new physicalL is a bounded image-supported hypothesis, not a surveyed plan or accepted match; the original request remains open.'
rp.write_text(json.dumps(r,indent=2)+'\n')
sp=H/'candidate'/paths[3];d=json.loads(sp.read_text());d['note']=d['note'].replace('The current inline core/frame-addition model still does not match its twin-gable massing, so this source does not warrant a matches verdict.','The pre-refinement inline model did not reproduce these two gable fronts. Neither the earlier parallel-gable trial nor the new L hypothesis warrants a matches verdict without actual rendered review.');d['note']+=' T-2386 L re-reading corrects the earlier parallel-gable interpretation: the NYPL left gable roof recedes rightward, the right one leftward, and their inside walls meet at an apparent corner. An orthogonalL is a supported form hypothesis, not an attested plan or scale. The physical polygon and all metric choices remain reconstructed; alternate views/chronology and actual render remain open. The1892-labelled poster is corroborative inspection only: fresh Newberry Poole27 metadata instead says1935/Copyright Not Evaluated, so its reproduction is not a new cleared modelling source. Source credit,1867 rights basis and Miller reading are unchanged.';sp.write_text(json.dumps(d,indent=2)+'\n')
patch=''
for rel in paths:patch+=''.join(difflib.unified_diff((H/'baseline'/rel).read_text().splitlines(True),(H/'candidate'/rel).read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(H/'T-2386-L-overlay.patch').write_text(patch)
(H/'inputs.json').write_text(json.dumps({'basis':str(B),'files':[{'path':p,'baseline_sha256':hashlib.sha256((H/'baseline'/p).read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256((H/'candidate'/p).read_bytes()).hexdigest()} for p in paths]},indent=2)+'\n')
