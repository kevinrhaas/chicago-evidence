"""Light numeric hypotheses. No Blender/browser or checkout writes."""
from pathlib import Path
import json,math,hashlib,shutil
import numpy as np
from scipy.optimize import least_squares
H=Path(__file__).resolve().parent
FULL=Path('/tmp/chicago-next-model/T-2386-next/evidence/source-full.jpg')
shutil.copy2(FULL,H/'evidence/nypl-full.jpg')
# Native manual controls; re-reading, not a new historical unit or metric control.
labels=['left_outer_eave','left_inner_eave','left_outer_base','left_inner_base','left_gable_apex','right_outer_eave','right_inner_eave','right_outer_base','right_inner_base','right_gable_apex','inside_corner_eave','inside_corner_base']
obs=np.array([[153,832],[264,834],[152,910],[264,910],[210,767],[513,833],[424,831],[513,908],[424,909],[468,767],[305,833],[305,905]],float)
# Ground picks have soft3px tolerance; inside corner is occluded/textured,6px.
sigma=np.array([3]*10+[6,6],float)
f=6000.;WA=5.;EAVE=2.6
# x=(other pen width,totalX,totalY,pitch,distance,yaw,eyeheight,cx,cy)
def project(pts,p):
 wb,lx,ly,pitch,d,yaw,h,cx,cy=p;t=math.radians(yaw);sn,cs=math.sin(t),math.cos(t)
 eye=np.array([-sn*d,-cs*d,h]);q=np.array(pts)-eye
 dep=q[:,0]*sn+q[:,1]*cs;hor=q[:,0]*cs-q[:,1]*sn
 return np.array([cx+f*hor/dep,cy-f*q[:,2]/dep]).T

def pts_L(p):
 wb,lx,ly,pitch,*_=p;za=EAVE+WA/2*math.tan(math.radians(pitch));zb=EAVE+wb/2*math.tan(math.radians(pitch))
 return [[lx,0,EAVE],[lx,wb,EAVE],[lx,0,0],[lx,wb,0],[lx,wb/2,zb], [0,ly,EAVE],[WA,ly,EAVE],[0,ly,0],[WA,ly,0],[WA/2,ly,za], [WA,wb,EAVE],[WA,wb,0]]
# Constrained fair neighbouring-parallel-pens hypothesis; same number of dims.
# totalX = total occupied width; other pen width wb; totalY depth; x spans0..WA andWA..WA+wb.
def pts_adj(p):
 wb,lx,ly,pitch,*_=p;za=EAVE+WA/2*math.tan(math.radians(pitch));zb=EAVE+wb/2*math.tan(math.radians(pitch))
 # Both gable fronts shareY=ly. The inside vertical seam is the common pen edge.
 return [[WA+wb,ly,EAVE],[WA,ly,EAVE],[WA+wb,ly,0],[WA,ly,0],[WA+wb/2,ly,zb], [0,ly,EAVE],[WA,ly,EAVE],[0,ly,0],[WA,ly,0],[WA/2,ly,za], [WA,ly,EAVE],[WA,ly,0]]
# U with equally oriented wings spaced by gap lx; both front planes sameY.
# Corner eave/base belongs to recessed rear connector atY=0, x=WA.
def pts_U(p):
 wb,gap,ly,pitch,*_=p;za=EAVE+WA/2*math.tan(math.radians(pitch));zb=EAVE+wb/2*math.tan(math.radians(pitch));x0=WA+gap
 return [[x0+wb,ly,EAVE],[x0,ly,EAVE],[x0+wb,ly,0],[x0,ly,0],[x0+wb/2,ly,zb], [0,ly,EAVE],[WA,ly,EAVE],[0,ly,0],[WA,ly,0],[WA/2,ly,za], [WA,0,EAVE],[WA,0,0]]
# OrthogonalL camera is in its notch/NE, so both normal+X,+Y ends face it.
# Parallel/U camera alsoNE; broader yaw bounds allow a centred view down the court.
configs={
 'orthogonal_L':(pts_L,[5,7.3,10.4,43,210,231,5,283,767],[3.5,6,7,25,70,200,2,-400,400],[6.5,15,20,50,430,250,8,1000,1000]),
 'adjacent_parallel':(pts_adj,[5,7.3,10.4,43,210,231,5,283,767],[3.5,1,2,25,70,185,2,-400,400],[6.5,15,20,50,430,275,8,1000,1000]),
 'parallel_U':(pts_U,[5,7,10.4,43,210,231,5,283,767],[3.5,0,2,25,70,185,2,-400,400],[6.5,15,30,50,430,275,8,1000,1000]),
}
results={}
for name,(fn,initial,lower,upper) in configs.items():
 fit=least_squares(lambda p:((project(fn(p),p)-obs)/sigma[:,None]).ravel(),initial,bounds=(lower,upper),max_nfev=500,xtol=1e-11,ftol=1e-11,gtol=1e-11)
 q=project(fn(fit.x),fit.x);res=q-obs;rows=[]
 for lab,source,pred,rr,ss in zip(labels,obs,q,res,sigma):rows.append({'feature':lab,'source_px':source.tolist(),'uncertainty_px':float(ss),'projected_px':pred.tolist(),'residual_px':rr.tolist()})
 results[name]={'success':bool(fit.success),'params':fit.x.tolist(),'rms_all_points_px':float(np.sqrt(np.mean(np.sum(res*res,axis=1)))),'maximum_point_residual_px':float(np.max(np.linalg.norm(res,axis=1))),'weighted_cost':float(fit.cost),'rows':rows,'controls_count':len(rows),'free_parameters':len(fit.x)}
# Additional edge-direction audit, excluded from all fits.
# A common roof-ridge meeting estimate is obscured by pole/head; broad tolerance.
p=results['orthogonal_L']['params'];wb,lx,ly,pitch,d,yaw,h,cx,cy=p;za=EAVE+WA/2*math.tan(math.radians(pitch));zb=EAVE+wb/2*math.tan(math.radians(pitch))
roof_pts={'left_front_apex':[lx,wb/2,zb],'left_back_ridge':[WA/2,wb/2,zb],'right_front_apex':[WA/2,ly,za],'right_back_ridge':[WA/2,wb/2,za]}
qp=project(list(roof_pts.values()),p)
results['orthogonal_L']['held_out_ridge_points']={k:v.tolist() for k,v in zip(roof_pts,qp)}
results['orthogonal_L']['held_out_direction_result']='Left ridge recedes rightwards; right ridge recedes leftwards, meeting near the inside junction. This qualitative check was not fitted.'
u=results['parallel_U']['params'];uw,ug,ud,up,*_=u;uz=EAVE+uw/2*math.tan(math.radians(up));upts={'left_front_apex':[WA+ug+uw/2,ud,uz],'left_back_ridge':[WA+ug+uw/2,0,uz],'right_front_apex':[WA/2,ud,EAVE+WA/2*math.tan(math.radians(up))],'right_back_ridge':[WA/2,0,EAVE+WA/2*math.tan(math.radians(up))]}
results['parallel_U']['held_out_ridge_points']={k:v.tolist() for k,v in zip(upts,project(list(upts.values()),u))}
results['parallel_U']['held_out_direction_result']='Both ridges recede leftwards under this low-residual courtyard-corner fit; the left one conflicts with the observed rightward ridge on the left pen. The withheld line-direction test rejects this particular U fit, not every possible skewed/unequal historic compound.'
result={'status':'numeric_topology_hypotheses_only_not_rendered_or_metric','not_a_reading':'Re-reading existing NYPL/Blanchard source for image geometry; no new historical reading count','source':'blanchard_shober_1867_wolf_point','source_image_sha256':hashlib.sha256(FULL.read_bytes()).hexdigest(),'image_px':[1920,1697],'source_date':'published1867; depicts1833; not contemporaryJuly1835','metric_gauge':'Core pen width fixed5m and existing eave2.6m as reconstruction exemplars. Neither is attested by image. Absolute scale/focal-distance degeneracy remains. focal6000px fixed; this is a distant upright camera hypothesis, square pixels.','fit_scope':'12 manually picked corners/apices; no doors, stacks, sign, silhouettes or textures fitted. Inside corner has6px tolerance. Same controls/sigmas/eave/pitch model and camera family for three hypotheses, but different topology bounds. U/adjacent best fit is constrained to stated finite period-scale bounds, not a proof against every staggered/compound possibility.','parameter_order':['other_pen_width_m','total_X_or_gap_m','total_Y_m','pitch_deg','camera_distance_m','yaw_deg','eyeheight_m','principal_x_px','principal_y_px'],'results':results,'match':'differs; no actual render or match judgement'}
(H/'topology-fit.json').write_text(json.dumps(result,indent=2)+'\n')
cam={'structure_id':'wolf_point_tavern','source_id':'blanchard_shober_1867_wolf_point','photo':'evidence/nypl-full.jpg','image_px':[1920,1697],'principal_px':[cx,cy],'focal_px':f,'eye':[-math.sin(math.radians(yaw))*d,-math.cos(math.radians(yaw))*d,h],'yaw_deg':yaw,'near_m':150.0,'sky':'overcast','solve':{'status':'provisional_reconstructed_L_topology_numeric_fit_not_rendered','metric_control':'None;5m pen/2.6m eave are reconstructed scale choices. Fixed6000px focal leaves metric/focal-distance degeneracy.','controls':'12 approximate source corners/apices with3–6px uncertainty, recorded in topology-fit.json. Orthogonal L model; compare constrained U and adjacent alternatives.','residuals_px':{'rms':results['orthogonal_L']['rms_all_points_px'],'max':results['orthogonal_L']['maximum_point_residual_px']},'near_plane':'150m is before the nearest proposed model point (~212m), chosen for distant-camera depth precision only; retain for both comparison fixtures.','limits':'Fitted analytic points, not GLB/render evidence or solved historical camera. Retrospective1867 drawing labelled1833; hidden topology/fabric/date remain uncertain. Research-only; no accepted reference view.'}}
(H/'L-provisional-camera.json').write_text(json.dumps(cam,indent=2)+'\n')
poly=[[0,0],[lx,0],[lx,wb],[WA,wb],[WA,ly],[0,ly]]
layout={'status':'provisional_source_bounded_layout_reconstruction_not_canonical','units':'metres; reconstructed gauge only','physical_polygon':poly,'core_wall_rect':[0,0,WA,ly],'extension_wall_rect':[WA,0,lx,wb],'core_roof':{'ridge_axis':'y','whole_pen_rect':[0,0,WA,ly]},'cross_roof':{'ridge_axis':'x','wall_pen_rect':[WA,0,lx,wb],'roof_projection_rect':[WA/2,0,lx,wb]},'roof_junction':'Cross roof projects only to core ridge x=2.5, not through the whole back core to create a second exterior west gable. In this junction domain external roof is the upper envelope of both slopes, clipped to L footprint. Exact valleys/eaves/joinery remain reconstructed.','wall_eave_m':EAVE,'pitch_deg':pitch,'gauge_limits':'Physical polygon replaces old12x7 placeholder. No source establishes its dimensions, absolute scale, frame/core identification or corner location. Existing geographicorigin/rotation/date should be retained provisionally, while all footprint readers/derived mesh/contact/entrances must see new actual polygon. Do not label old footprint attested.','source_features':'Two outward gable ends with different ridge directions, inner sidewall corner between them. This is an inferred interpretation of actual image features; not a surveyed historical plan.'}
(H/'L-layout.json').write_text(json.dumps(layout,indent=2)+'\n')
# Research SVG: manual observations black circles; projected roof/vertical edges red.
def line_svg(a,b,color,width=1.2):return f'<line x1="{a[0]:.2f}" y1="{a[1]:.2f}" x2="{b[0]:.2f}" y2="{b[1]:.2f}" stroke="{color}" stroke-width="{width}"/>'
q=project(pts_L(p),p);svg=['<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1000" height="700" viewBox="110 640 440 310">','<image href="evidence/nypl-full.jpg" x="0" y="0" width="1920" height="1697"/>']
for a,b in [(0,1),(0,2),(1,3),(0,4),(1,4),(5,6),(5,7),(6,8),(5,9),(6,9),(1,10),(6,10),(3,11),(8,11),(10,11)]:svg.append(line_svg(q[a],q[b],'#ff3030'))
for a,b in [('left_front_apex','left_back_ridge'),('right_front_apex','right_back_ridge')]:svg.append(line_svg(results['orthogonal_L']['held_out_ridge_points'][a],results['orthogonal_L']['held_out_ridge_points'][b],'#00c9ff',1.4))
for xy in obs:svg.append(f'<circle cx="{xy[0]}" cy="{xy[1]}" r="2.2" fill="none" stroke="#ffff00" stroke-width="1"/>')
svg.append('</svg>');(H/'L-source-projection.svg').write_text('\n'.join(svg)+'\n')
print(json.dumps({k:{kk:vv for kk,vv in v.items() if kk in ['params','rms_all_points_px','maximum_point_residual_px']} for k,v in results.items()},indent=2))
