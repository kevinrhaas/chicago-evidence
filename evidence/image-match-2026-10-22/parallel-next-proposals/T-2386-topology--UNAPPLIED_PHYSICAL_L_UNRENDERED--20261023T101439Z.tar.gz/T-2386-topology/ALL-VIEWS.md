# Re-reading all eight T-2386 pictures — 2026-10-23

This is a geometry re-reading of existing cited images, **not a newly counted
historical research unit**. Every listed file was actually opened with view_image.
The subject in the close NYPL sheet is the left-bank building identified by its
wolf pole; Miller's tall building is across the river. The topological uncertainty
concerns the tavern's plan, not that basic subject identification.

| Ticket picture | Existing inventory dates | Actual reading / limit for L hypothesis |
| --- | --- | --- |
| chicago_wolf_point_1833.jpg | Justin Herriott1902; labelled1833 | Bird's-eye/context view. Named tavern subject is not positively located at this small reproduction; it cannot fix our pen subdivision. Do not borrow the clearly foreground Sauganash form. It remains an identity/camera/context review case. |
| chicago_wolf_point_1830.jpg | Andreas1884; labelled1830 | Two low gable ends on the left-bank tavern with a wall/roof range between. Qualitatively compatible with elbow/oblique masses; drawing is faint and not a metric plan. Ground, roof proportions and opening treatment differ from the NYPL sheet. |
| chicago_wolf_point_1830_and_1833_engravings.jpg | Composite; individual original publication not established here | Left oval has two low end masses and the central recess/junction, but simplifies walls/roofs and shows a covered bridge. Right panel is a tight crop of one gable/sign and excludes the other end. Neither is an independent measured corroboration of an exact L. |
| chicago_wolf_point_1832.jpg | Chicago Magazine1857; labelled1832; Miller engraver after George Davis per inventory | Foliage vignette has the two left-bank roof/end masses and tall sign. Much of the connecting wall is dark. Compatible with the broad L category but too coarse for exact topology. The same Davis-source family is not independent confirmation. |
| chicago_wolf_tavern_miller_house_1832.jpg | Inventory says1892; labelled1832 | Sharp poster makes two outward gable ends, inner wall corner and opposed roof directions particularly legible. Caption identifies left tavern and right Miller and credits George Davis. It corroborates the visual hypothesis only; rights/publication discrepancy below prevents adopting it as a new cleared modelling asset. Door count/placement, roof height/covering, bridge and contextual figures differ from NYPL. |
| chicago_town_view_1833_colbert.jpg | Colbert/Chamberlin1871; labelled1833 | Tavern is cropped at left: only its right gable, side wall and part of the other roof appear. The exposed roof recedes to the left and broad head/narrow projection remain distinct. Compatible with the right arm of the L, not a full plan test. Clearly coursed logs and doorway/window details still differ from model kits. |
| chicago_wolf_point_1833_hammon.jpg | Widney painting reproduced on V.O.Hammon postcard, early1900s per inventory | One gable/long roof part is visible at the left bank. A second end is not clearly drawn; trees/crop/obliquity may hide it, but this is an unresolved composition difference, not an automatic excuse. A dedicated actual camera/render must decide visibility. Broader scale, boats/context and Miller composition differ. |
| chicago_wolf_point_1833_nypl.jpg | Actual sheet prints1867; depicts1833 | Governing source for proposed model. Left gable ridge runs rightward toward junction, right ridge runs leftward; inside wall corner lies between. Twelve native corner/apex picks fit an orthogonalL within their manual uncertainties. Coordinates, absolute scale, hidden fabric/plan and exactJuly1835 state are not supplied. |

The views are retrospective and several repeat George Davis-derived compositions.
Do not turn agreement into eight independent historical attestations. There is no
source here establishing that the1832/1833 form remained completely unchanged on
1July1835. Existing phase/date confidence and disagreements remain. An L is the
next bounded model hypothesis; each picture still needs its own actual perspective,
mesh/render review and honest differences. No picture is dismissed or marked
matches by this re-reading.

## Poster publication and rights check — no fresh1892 clearance

Actual local sheet: title *Chicago in1832—Wolfs Point*, publisherRufus Blanchard,
171RandolphStreet, Chicago; World's Columbian Exposition tribute and population
table through1891. Those marks do **not** by themselves print a legible1892
publication/copyright year, identify a later reprint's date or clear colorisation.

Fresh GET200,2026-10-23, Newberry [Poole27/NL11OCIR](https://collections.newberry.org/asset-management/2KXJ8ZS8068IZ):

> Date1935. Rights StatusCopyright Not Evaluated.

It also warns the file has not been fully processed and may contain minimal or
incorrect metadata/unlinked catalog data. This is a conflict requiring resolution,
not proof that1935 is the original publication or permission to override it with
our earlier inventory's1892 date. Fresh Chicagology200 calls it a souvenir poster
for the1893 Exposition, without independent publication evidence in the inspected
text. It names GeorgeR.Davis as authorizer and JohnR.Kay as color director; those
are editorial claims, not a newly inspected signed colorisation record.

Saved public responses: evidence/newberry.html, chicagology.html and
publication-fetch-receipt.json. No new cleared poster source record is created.
The uncertain poster image/crop is **excluded from this parcel's portable assets**;
its existing repository reference was viewed for comparison only. All proposed
geometry, analytic controls and exported source-overlay plots use the separately
inspected/public-domain-by1867-publication NYPL sheet. Source credits and the
NyPL/Commons access/holding limitations remain unchanged. This conflict does not
block that independently sourced geometry work.
