# Wolf Point physical-L hypothesis and compatible preview overlay — UNAPPLIED / UNRENDERED

The previous `/tmp/chicago-next-model/T-2386-next` parallel trial remains frozen
and unchanged. **Do not layer it onto this proposal.** This new overlay applies
directly to the final log81 helper, including visible Miller joints and final Hogan
continuation, at `log81-materializer/05f6-sourceS-final/review-tree`.
No tracked files, ticket state, branches, publisher, Blender or browser were touched.

## Evidence and materially closer projected geometry

The actual1867 NYPL sheet and all seven other ticket pictures were opened.
`ALL-VIEWS.md` records their agreements, contradictions, subject limits and dates.
The source is the left-bank tavern with wolf pole, not Miller across the water.
The two pictured gable ends face different directions. Their inside walls meet at
a corner. The left roof recedes rightwards and right roof leftwards; a simple
adjacent parallel pair cannot produce that topology.

`topology-source-projections.png` overlays manual native picks and actual numeric
hypothesis lines on the NYPL source. Red: fitted corners/edges. Cyan: roof-ridge
directions withheld from fitting. These are **analytic diagrams, not model renders**.
`topology-fit.json` records every pick, uncertainty, parameter/bound and residual:

| Hypothesis |12-corner/apex RMS | Main finding |
| --- | --- | --- |
| Orthogonal L |1.53px | Opposed roof-ridge directions also agree. |
| Adjacent parallel pens |51.51px | Common inner edge contradicts two separated source corners. |
| Parallel wings with courtyard |2.26px | Fits corners but left ridge recedes left, contrary to source; this constrained U fit fails the withheld direction check. |

This comparison is evidence for the next bounded topology, not proof excluding
every staggered historic compound. The image is retrospective/hand-drawn; neither
camera nor metres are known. A5m core span and retained2.6m eave fix a reconstructed
scale gauge. Focal6000px/distance212.33m, level eye2m and principal point are joint
shape/camera choices; the eye-height lower bound is active and must not be reported
as a solved historical station. Pixel aspect stays1. No stretching of the source
or forced preservation of its old placeholder polygon is used.

The actual proposed **rounded**5m spans,7.2x10.1m extents and42degree roof give
1.60px RMS/3.77px max at the unchanged fitted-L camera. See
`rounded-overlay-projection.json`, including withheld door/window/head projections.
Those checks also are analytic. `L-provisional-camera.json` is research-only, with
near150m for distant-camera depth precision. Keep it out of accepted reference views.

## Physical layout and world movement

The old12x7m rectangle was reconstructed. Replace it with the physical wall polygon:

```
(0,0),(7.2,0),(7.2,5),(5,5),(5,10.1),(0,10.1)
```

It is the exact union of core[0,0,5,10.1] and cross extension[5,0,7.2,5], area61.5m²
versus84m² before. Two equal gable spans create a real concave L. The cross roof
projects only back to the core ridge; a clipped upper envelope closes the junction,
without buried intersecting roof surfaces, an invisible box or invented passage.
Flush eaves/simple gable caps are first-trial reconstructions, not final detailing.

Record UTM origin and90degree rotation stay, but **occupied ground and centre move**.
BBox centre shifts local(-2.4,+1.55)m =(+1.55E,+2.4N)m. ShowMe's vertex-mean centre
shifts local(-1.933,+1.533)m. The former south extent moves4.8m north and max-east frontage3.1m east; the
position note records that old40m/11–19m face/setback prose describes the previous
placeholder. These are disclosed consequences of the changed reconstructed plan, within the existing much wider placement uncertainty; they are
not a new measured coordinate or a claim that every world-space point is unchanged.

## Compatible code/data overlay

`overlay/T-2386-L-overlay.patch` changes two shared modules, Wolf Point record and
an explicitly historical source-model note. Only Wolf Point geometry changes
relative to frozen final log81. No Hogan data, current sourceS record or source
credit is restored from an old snapshot. Apply hunks selectively after the parent
rematerializes final log81 against its then-current branch; stop on overlaps.
Never copy the whole candidate modules/record/source over independent new work.

Existing `compound_parts` is reused for connected-room geometry and exact footprint
union. Two new keyword-only fields, `compound_joint=None|elbow` and `roof_pipe=None`,
leave every old constructor/default untouched. Existing addition-side enum gains
`elbow`; its extents describe the actual back corner. The original independent-room
path/guards remain. Elbow is a separately constrained two-room/equal-span branch;
unsupported additions, heights, roof axes, facade overrides, stories and features
fail. Explicit opening rectangles name each room's outward face. No+X entry is
falsely put on the single+Y front-wall/signage API.

The two door proxies/right-front light, near-junction broad head and independent
narrow projection are reconstructed, using the NYPL sheet only. Broad stack count
stays one; the narrow projection does not prove a stove or hidden flue. New room/roof/opening/head/pipe primitives carry reconstructed confidence; the
inherited sign kit retains its existing occurrence-confidence policy. Existing frame
assignment and material kits remain an acknowledged limit. The original pole kit
is retained and will visibly differ in station/height/lean/board; do not hide that
in a topology/camera solve.

**Secondary entry integration limit:** current generate_entrances.front_doors is
explicitly a+Y-frontage API. The new+X doorway is real emitted geometry but is not
an enumerated front entrance. Review an explicit multi-face consumer extension if
required for entrance clearance/ground metadata. Do not manufacture a+Y entrance
at its projection. This and actual canonical source cards/terrain/clearance remain
part of parent integration review, not certified by these light contracts.

## Light checks already passed

```sh
python /tmp/chicago-next-model/T-2386-topology/check_overlay.py
node /tmp/chicago-next-model/T-2386-topology/check_readers.mjs
python /tmp/chicago-next-model/T-2386-topology/check_projection.py
```

- Actual raw geometry/material/confidence parity on all81 frozen final-log81 inputs,
  including Miller joints and Hogan recess/hatch, with the new option off.
- Original positional constructor signature unchanged; two fields keyword-only;
 21 invalid/unsupported combinations reject, including a fake full rectangle.
- Actual joined roof samples match the clipped upper envelope at58 interior points;
  no duplicate surfaces there. Geometry finite/nondegenerate;1661vertices/895triangles.
- Actual record/source schemas, liberty parser10Covers and forward coverage0errors.
- Actual copied walker function keeps all6polygon vertices: empty corner open and
  both arms blocking at4rotations. Actual ShowMe wall ray sees the notch, not bbox.
- Actual copied building-feet function reads47mesh-ground samples, with no fabricated
  ground foot inside the empty notch. Actual contact-outline function keeps6edges
  and both notch edges. No terrain, whole app, GLB/export or browser claim follows.

`readers/` contains regular copied source. Pure function bodies execute in the Node
check; no THREE/browser module startup. `L-debug.obj`/raw JSON are debug geometry,
not glTF deliverables or supported export proof.

## Provenance and next integration requirements

Append `LIBERTY-APPEND.md` and compile with the real ledger tool. It records the
new footprint, gauge, room/roof/door/projection choices, source/date limits and
world-centre changes. Two new name-pool read paths are required:
`phases[].form.compound_joint.note` and `phases[].form.roof_pipe.note`.
Existing compound_parts.note is retained. Nested opening arrays are machine enums
and numbers, not hidden research prose. Preserve old liberties and grade rulings.
No whole-building grade or accepted camera is added; T-2386 remains open.

The1892-labelled poster's rights/publication date is **not newly proved**. Fresh
NewberryPoole27 saysDate1935/CopyrightNotEvaluated with an incorrect-metadata warning;
Chicagology calls it an1893 souvenir. See saved public receipts/ALL-VIEWS.md. No new
cleared poster source or portable poster image is included. Governing NYPL source
has its actual printed1867publication, attribution, PD-age reasoning and existing
access limitations unchanged; Miller-specific shared source reading is preserved.

All81 log recipe hashes change when shared builder/params bytes and two resolved
fields change. If parent accepts the **actual focused preview**, compose this
instead of the old parallel trial before the one coordinated official81 rebake.
Do not restamp freshness, copy old generated meshes or bake one canonical asset
while leaving80stale. Re-run parity against then-current input/modules after merge.

Wait for parent heavy slot. Make regular-copied isolated final-log81 baseline and
L-candidate fixtures. Use actual build.py and seed `wolf_point_tavern__log_frame_1828`,
pinned Blender4.5.3, identical `L-provisional-camera.json`, source copy and camera
near/aspect. Export/capture one master per fixture, inspect actual GLB contracts,
roof junctions, entry faces, contact, materials and source|baseline|trial. Parent
then decides further pole/gable/finish/door refinements before an official family
refresh. No automatic heavy runner is provided during the reserved gate slot.

Remaining differences are explicit: pole/sign, horizontal gable/log/board treatment,
roof covering/eaves/valley details, exact opening/joinery states, projection profiles,
unseen fabric, July1835 continuity, ground/context and other-view cameras. Nothing
in the analytic fit authorizes a matches verdict or original-ticket completion.
