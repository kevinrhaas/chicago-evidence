from pathlib import Path
from types import ModuleType
from dataclasses import asdict,replace
import sys,json,inspect,math,hashlib
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;O=H/'overlay';F=Path('/tmp/chicago-next-model/log81-materializer/05f6-sourceS-final');B=F/'review-tree/chicago/4d';N=O/'candidate/chicago/4d'
sys.path.insert(0,str(B/'generators'));sys.modules['bpy']=ModuleType('bpy')
def load(n,p):
 m=ModuleType(n);m.__file__=str(p);sys.modules[n]=m;exec(compile(p.read_text(),str(p),'exec'),m.__dict__);return m
old=load('Loldp',B/'generators/archetypes/log_dwelling_params.py');new=load('Lnewp',N/'generators/archetypes/log_dwelling_params.py')
sys.modules['archetypes.log_dwelling_params']=old;a=load('Lold',B/'generators/archetypes/log_dwelling.py');sys.modules['archetypes.log_dwelling_params']=new;b=load('Lnew',N/'generators/archetypes/log_dwelling.py')
from common.mesh import MeshBuilder
class Raw(MeshBuilder):
 def to_object(self,materials=None):self.materials=materials;return self
for m in [a,b]:m.MeshBuilder=Raw;m.simple_material=lambda *a,**kw:(a,kw)
def raw(q):return q.verts,q.faces,q.conf,q.mat_index,q.named,q.materials
extra={'compound_joint':None,'roof_pipe':None};osig=inspect.signature(old.LogDwellingParams);nsig=inspect.signature(new.LogDwellingParams)
assert [v for k,v in nsig.parameters.items() if k not in extra]==list(osig.parameters.values());assert all(nsig.parameters[k].kind==inspect.Parameter.KEYWORD_ONLY for k in extra)
scope=json.loads((F/'freshness-scope.json').read_text());defaults=[]
for row in scope['assets']:
 r=json.loads((B/f"data/structures/{row['structure_id']}.json").read_text());ph=next(p for p in r['phases'] if p['id']==row['phase_id']);x=old.from_phase(ph,r);y=new.from_phase(ph,r);d=asdict(y)
 for k,v in extra.items():assert d.pop(k)==v
 assert d==asdict(x)
 key=Path(row['asset']).stem;assert raw(a.build(x,key))==raw(b.build(y,key)),row['asset'];defaults.append(row['asset'])
assert len(defaults)==81
r=json.loads((N/'data/structures/wolf_point_tavern.json').read_text());p=new.from_phase(r['phases'][0],r);obj=b.build(p,'wolf_point_tavern__log_frame_1828')
assert new.core_extent(p)==(0.,0.,5.,10.1) and new.addition_extent(p)==(5.,0.,7.2,5.)
assert len(new.compound_front_rects(p))==2 and len(new.core_front_rects(p))==2
assert new.front_wall(p)['u1']==5. and all(o['u1']<=5 for o in new.front_wall(p)['openings'])
for pt in obj.verts:assert all(math.isfinite(v) for v in pt)
for face in obj.faces:
 pts=[obj.verts[k] for k in face];normal=[0.,0.,0.]
 for u,v in zip(pts,pts[1:]+pts[:1]):
  for k in range(3):i,j=(k+1)%3,(k+2)%3;normal[k]+=(u[i]-v[i])*(u[j]+v[j])
 assert sum(v*v for v in normal)>1e-16
roof=Raw('roof');z=b._elbow_roof(roof,p);assert abs(z-(2.6+2.5*math.tan(math.radians(42))))<1e-9
# Sample actual emitted top faces: exactly one surface, equal to clipped analytical envelope.
def contains(poly,x,y):
 inside=False
 for u,v in zip(poly,poly[1:]+poly[:1]):
  if (u[1]>y)!=(v[1]>y) and x<(v[0]-u[0])*(y-u[1])/(v[1]-u[1])+u[0]:inside=not inside
 return inside
checked=0
for x in [.17,.83,1.9,2.8,3.9,4.8,5.7,6.8]:
 for y in [.23,1.13,2.1,3.3,4.7,5.9,8.1,9.8]:
  hits=[]
  for face in roof.faces:
   pts=[roof.verts[k] for k in face]
   if contains(pts,x,y):
    u,v,w=pts[:3];normal=[(v[1]-u[1])*(w[2]-u[2])-(v[2]-u[2])*(w[1]-u[1]),(v[2]-u[2])*(w[0]-u[0])-(v[0]-u[0])*(w[2]-u[2]),(v[0]-u[0])*(w[1]-u[1])-(v[1]-u[1])*(w[0]-u[0])]
    if normal[2]>1e-10:hits.append(u[2]-(normal[0]*(x-u[0])+normal[1]*(y-u[1]))/normal[2])
  occupied=(0<x<5 and 0<y<10.1) or (5<x<7.2 and 0<y<5)
  assert len(hits)==int(occupied),(x,y,hits)
  if occupied:
   t=math.tan(math.radians(42));za=2.6+min(x,5-x)*t if x<5 else -math.inf;zb=2.6+min(y,5-y)*t if x>=2.5 and y<5 else -math.inf
   assert abs(hits[0]-max(za,zb))<1e-8;checked+=1
invalid=[replace(p,compound_joint='bad'),replace(p,compound_parts=()),replace(p,frame_addition=False),replace(p,frame_addition_side='end'),replace(p,roof_ridge_axis='y'),replace(p,frame_addition_stories=2),replace(p,stories=2),replace(p,frame_addition_height_m=3.),replace(p,frame_addition_depth_m=4.9),replace(p,lean_to=True),replace(p,piazza=True),replace(p,loft=True),replace(p,front_door_state='recess'),replace(p,chimneys=2,chimney_ridge_at=(.2,.7)),replace(p,roof_pipe=(float('nan'),.14,.55)),replace(p,roof_pipe=(.5,0,.55)),replace(p,roof_pipe=(True,.14,.55)),replace(p,window_w_m=.9),replace(p,front_shutters=False),replace(p,chimney_cross_m=.2)]
for q in invalid:
 try:q.validate()
 except new.ParamError:pass
 else:raise AssertionError('bad combination accepted')
# Footprint union must be actual L, not hidden old rectangle.
bad=json.loads(json.dumps(r));bad['phases'][0]['footprint']['polygon']=[[0,0],[7.2,0],[7.2,10.1],[0,10.1]]
try:new.from_phase(bad['phases'][0],bad)
except new.ParamError:pass
else:raise AssertionError('false bounding rectangle accepted')
import jsonschema
jsonschema.validate(r,json.loads((B/'data/structures.schema.json').read_text()));src=json.loads((N/'data/sources/blanchard_shober_1867_wolf_point.json').read_text());jsonschema.validate(src,json.loads((B/'data/source.schema.json').read_text()))
base=json.loads((B/'data/structures/wolf_point_tavern.json').read_text());assert r['phases'][0]['documented_range']==base['phases'][0]['documented_range'];assert all(r['phases'][0]['position'][k]==v for k,v in base['phases'][0]['position'].items() if k!='note');assert r['phases'][0]['position']['note'].startswith(base['phases'][0]['position']['note']);assert all(r[k]==v for k,v in base.items() if k not in ('phases','research_note'));assert r['research_note'].startswith(base['research_note'])
baseSrc=json.loads((B/'data/sources/blanchard_shober_1867_wolf_point.json').read_text());assert all(src[k]==v for k,v in baseSrc.items() if k!='note')
# Real liberty parser/coverage; existing final entries retained.
import ast
lib=load('Llib',B/'tools/compile_liberties.py');names={sid:json.loads((B/f'data/structures/{sid}.json').read_text())['name'] for sid in ['chappel_infant_school','cobweb_castle','miller_house','philo_carpenter_log_shop','wolf_point_tavern','hogan_store']}
newentries,problems=lib.parse('## Per-subject liberties\n\n'+(H/'LIBERTY-APPEND.md').read_text(),names,sources={});assert not problems and len(newentries)==1 and len(newentries[0]['covers'])==10 and newentries[0]['subjects']
prior,_=lib.parse('## Per-subject liberties\n\n'+(F/'liberty-append.md').read_text(),names,sources={})
ledger=json.loads((B/'data/liberties.json').read_text());ledger['liberties']+=prior+newentries
nodes=[n for n in ast.parse((B/'tools/validate.py').read_text()).body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in {'Report','graded_values','inferred_values','unbuilt_values','check_liberties_coverage','_contact_outline'}]
ns={'PHASE_ASPECTS':('footprint','position','documented_range'),'STRUCTURE_ASPECTS':('function','occupants','present_status','built'),'GEOMETRY_OWES_LIBERTY':('absent','simplified')};exec(compile(ast.Module(body=nodes,type_ignores=[]),'actual_contracts','exec'),ns)
rep=ns['Report']();ns['check_liberties_coverage']({'wolf_point_tavern':r},ledger,rep,{'log_dwelling':new.CONSUMED},forward_only=True);assert not rep.errors,rep.errors
outline=ns['_contact_outline'](r['phases'][0]['footprint']['polygon'],'perimeter');assert len(outline)==6 and ((7.2,5),(5,5)) in outline and ((5,5),(5,10.1)) in outline
(H/'overlay-raw-geometry.json').write_text(json.dumps({'verts':obj.verts,'faces':obj.faces,'conf':obj.conf,'mat_index':obj.mat_index,'roof_verts':roof.verts,'roof_faces':roof.faces}))
with (H/'L-debug.obj').open('w') as f:
 for v in obj.verts:f.write('v '+' '.join(map(str,v))+'\n')
 for face in obj.faces:f.write('f '+' '.join(str(i+1) for i in face)+'\n')
report={'status':'passed','all81_frozen_final_log81_raw_material_conf_default_parity':81,'keyword_only_fields':list(extra),'unsupported_guards':len(invalid)+1,'physical_polygon':'concaveL exact union; full bbox rejected','actual_core_plus_cross_extents':[new.core_extent(p),new.addition_extent(p)],'roof_ridge_z_m':z,'roof_upper_envelope_sample_points':checked,'no_internal_duplicate_surfaces_at_sample_points':True,'front_wall_only_reports_real_plusY_core':True,'actual_plusX_entry_emitted_not_falsely_flattened_to_front':True,'actual_vertices':len(obj.verts),'actual_triangles':sum(len(f)-2 for f in obj.faces),'source_record_schemas':'passed','existing_numeric_world_origin_rotation_dates_and_source_credits_rights_preserved':True,'physical_bbox_centre_shift_local_m':[-2.4,1.55],'actual_liberty_covers':10,'actual_forward_coverage_errors':0,'actual_contact_outline_preserves6edges_and_notch':True,'matches':'differs; analytic numeric only; no Blender/browser/publish/gate','secondary_entry_consumer_limit':'Current front_doors API only enumerates +Y frontage; +X entry needs explicit integration review rather than false +Y projection.'}
(H/'overlay-light-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
