from pathlib import Path
import json,math
H=Path(__file__).resolve().parent;d=json.loads((H/'topology-fit.json').read_text());c=json.loads((H/'L-provisional-camera.json').read_text());e=c['eye'];t=math.radians(c['yaw_deg']);sn,cs=math.sin(t),math.cos(t)
def project(pt):
 du,dv,dz=[pt[k]-e[k] for k in range(3)];depth=du*sn+dv*cs
 return [c['principal_px'][0]+c['focal_px']*(du*cs-dv*sn)/depth,c['principal_px'][1]-c['focal_px']*dz/depth]
W=7.2;D=10.1;span=5;h=2.6;ridge=h+span/2*math.tan(math.radians(42))
pts=[[W,0,h],[W,span,h],[W,0,0],[W,span,0],[W,span/2,ridge],[0,D,h],[span,D,h],[0,D,0],[span,D,0],[span/2,D,ridge],[span,span,h],[span,span,0]]
rows=[]
for pt,row in zip(pts,d['results']['orthogonal_L']['rows']):
 q=project(pt);s=row['source_px'];rr=[q[k]-s[k] for k in range(2)];rows.append({'feature':row['feature'],'actual_overlay_point_local_m':pt,'source_px':s,'projected_px':q,'residual_px':rr})
features={'left_entry_centre':{'point':[W,3.35,.86],'source_approx':[229,885]},'right_entry_centre':{'point':[3.55,D,.91],'source_approx':[448,879]},'right_window_centre':{'point':[1.45,D,1.4],'source_approx':[485,859]},'broad_head_top':{'point':[2.5,.29*D,ridge+.5],'source_approx':[306,750]},'thin_projection_top':{'point':[2.5,.74*D,ridge+.55],'source_approx':[406,752]}}
for row in features.values():row['projected_px']=project(row['point']);row['residual_px']=[row['projected_px'][k]-row['source_approx'][k] for k in range(2)]
rms=math.sqrt(sum(sum(v*v for v in row['residual_px']) for row in rows)/len(rows));mx=max(math.hypot(*row['residual_px']) for row in rows)
report={'status':'actual_round-number_overlay_analytic_projection_only','camera_file':'L-provisional-camera.json','camera_changed_from_fitted_L':False,'pixel_aspect':1,'rounded_geometry_rms_px':rms,'rounded_geometry_max_px':mx,'rows':rows,'secondary_features_not_fit_to_camera':features,'physical_polygon_area_m2':61.5,'former_placeholder_area_m2':84,'world_anchor_disclosure':{'record_origin_UTM_and_rotation':'unchanged','bbox_centre_shift_local_m':[-2.4,1.55],'bbox_centre_shift_ENU_at90deg_m':[1.55,2.4],'ShowMe_vertex_mean_shift_local_m':[-1.9333333333333336,1.533333333333334]},'limits':'12-pick point fit and analytic checks only, not actual source/render metric validation. Roof-edge details, gable/log/clapboard textures, pole/sign, hidden plan, scene-date continuity and every other source view remain open.'}
(H/'rounded-overlay-projection.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['rows','secondary_features_not_fit_to_camera']},indent=2))
