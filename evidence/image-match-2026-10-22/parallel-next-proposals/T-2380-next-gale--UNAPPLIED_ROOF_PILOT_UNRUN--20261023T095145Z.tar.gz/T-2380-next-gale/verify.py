from pathlib import Path
import json,copy,sys,hashlib,dataclasses,subprocess,math,py_compile
from PIL import Image,ImageChops
B=Path(__file__).resolve().parent;R=Path('/workspace/chicago');D=R/'chicago/4d';sys.path.insert(0,str(D/'generators'))
from archetypes.outbuilding_params import from_phase,vent_rect,CONSUMED
import mesh_inputs,jsonschema
rel='chicago/4d/data/structures/log_jail.json';a=json.loads((B/'before'/rel).read_text());b=json.loads((B/'roof-only'/rel).read_text());c=json.loads((B/'raised-diagnostic'/rel).read_text());schema=json.loads((D/'data/structures.schema.json').read_text())
for r in [a,b,c]:jsonschema.validate(r,schema);from_phase(r['phases'][0],r).validate()
x=copy.deepcopy(b);x['research_note']=a['research_note']
for k in ['construction','roof_type','roof_pitch_deg','wall_height_m']:x['phases'][0]['form'][k]=a['phases'][0]['form'][k]
assert x==a
x=copy.deepcopy(c);x['phases'][0]['form']['wall_height_m']=b['phases'][0]['form']['wall_height_m'];assert x==b
p=from_phase(a['phases'][0],a);q=from_phase(b['phases'][0],b);r=from_phase(c['phases'][0],c)
assert {'roof_pitch_deg','wall_height_m','roof_type'}<=CONSUMED
assert p.wall_height_m==q.wall_height_m==2.66 and r.wall_height_m==4.2
assert p.roof_pitch_deg==12 and q.roof_pitch_deg==r.roof_pitch_deg==22
assert p.width_m==q.width_m==r.width_m==6.096 and p.depth_m==q.depth_m==r.depth_m==4.572
assert p.door_spans_m==q.door_spans_m==r.door_spans_m and vent_rect(p)==vent_rect(q)==vent_rect(r)
assert not q.loft and not r.loft and p.chimneys==q.chimneys==r.chimneys==0
for key in ['construction','roof_type','roof_pitch_deg','wall_height_m']:
 if key!='construction':assert 'trowbridge_first_jail_gale_1902' in str(b['phases'][0]['form'][key]) or key=='wall_height_m'
source=json.loads((D/'data/sources/trowbridge_first_jail_gale_1902.json').read_text());assert source['rights_status']=='public_domain' and source['verified']
# No hidden extra components, phases, person actions, date/source substitutions.
assert len(a['phases'])==len(b['phases'])==len(c['phases'])==1
for key in ['position','documented_range','footprint','change_note']:assert a['phases'][0][key]==b['phases'][0][key]==c['phases'][0][key]
meta=json.loads((B/'input-snapshot.json').read_text())
for rel,want in meta['input_sha256'].items():assert hashlib.sha256((R/rel).read_bytes()).hexdigest()==want,rel
for rel,want in meta['proposal_sha256'].items():assert hashlib.sha256((B/rel).read_bytes()).hexdigest()==want,rel
assert meta['baseline_asset_entry']['inputs_sha256']==meta['mesh_sha_before']==mesh_inputs.structure_inputs_sha(a,a['phases'][0])
assert hashlib.sha256((D/'assets/gltf'/meta['asset_name']).read_bytes()).hexdigest()==meta['baseline_asset_sha256']
assert meta['baseline_asset_entry']['bytes']==(D/'assets/gltf'/meta['asset_name']).stat().st_size
assert mesh_inputs.structure_inputs_doc(a,a['phases'][0])['code']==mesh_inputs.structure_inputs_doc(b,b['phases'][0])['code']
original=Image.open(B.parent/'T-2380-rights-next/gale-n79.jpg');upright=Image.open(B/'gale-plate-upright-analysis.png');assert upright.size==(2741,1853)
assert ImageChops.difference(original.transpose(Image.Transpose.ROTATE_270).convert('RGB'),upright.convert('RGB')).getbbox() is None
cam=json.loads((B/'camera-gale-core-pilot.json').read_text());fit=json.loads((B/'roof-fit.json').read_text());assert cam['source_id']==source['id'] and cam['structure_id']==a['id'];assert cam['image_px']==list(upright.size);assert 0<fit['rms_euclidean_px']<20
for n in ['prepare.py','prepare_fixture.py','run_preview.py','fit_camera.py']:py_compile.compile(str(B/n),doraise=True)
subprocess.run(['git','apply','--check',str(B/'T-2380-roof-only.patch')],cwd=R,check=True,capture_output=True)
print('PASS structure schema; exact original footprint/place/date/use/doors/defaultvent retained; roof-only22degrees/eave2.66m, raised4.2m diagnostic separate')
print('PASS source independently public_domain; obsolete low/hewn-authoritative prose corrected; source-state/date/cell conflicts explicit')
print('PASS no shared code/defaults changed; one master+derivative blast; baseline manifest recipe matches current inputs and bytes hash')
print('PASS source orientation is exact lossless quarter-turn of actual Gale1902page; provisional roof-camera RMS',fit['rms_euclidean_px'],'px')
print('PASS frozen proposal/input hashes, runner syntax, git apply --check; runner dry-run does not execute Blender/browser')
print('Before ridge:',p.apex_z_m,'roof-only ridge:',q.apex_z_m,'raised diagnostic ridge:',r.apex_z_m)
print('UNRUN actual proposed export/render/bake, real visible-improvement verdict, fullgate or matches; ticket remains open')
