# T-2380 — first geometry comparison against the verified Gale plate

**Ready for an isolated preview; not yet rendered or applied.** The proposed patch uses existing `outbuilding` parameters, corrects the obsolete form-attribute explanations, and retains the current model’s footprint, eave value, placement and dates. It changes the roof pitch from12° to a reconstructed22°. The separately retained4.2m wall variant is diagnostic only.

## Selected proposal

`T-2380-roof-only.patch` changes only `data/structures/log_jail.json`:

- `roof_type=gable` remains inferred, now citing the independently verified public-domain source `trowbridge_first_jail_gale_1902`, with explicit1836/July1835continuity and original-cell/later-cell limits.
- `roof_pitch_deg=22`, reconstructed. This is a first trial guided by the picture, not an archival angle measurement.
- `wall_height_m=2.66` remains numerically unchanged, now correctly labeled reconstructed. The exact picture hides the core’s base and does not corroborate the old brief’s “low” metric reading. It does not independently justify the former4.2m guess either.
- `construction=log` stays attested by Andreas’s text. The note withdraws the old claim that the exact drawing attests hewn fabric: it visibly has rounded log ends, while the retained hewn/notched kit is a reconstruction.
- Research text states this increment and remaining limits. No generic vent/hay door is relabeled as the pictured barred gable aperture, and no forge chimney is substituted for the pictured stacks.

The roof-only ridge rises3.1459→3.5836m. The optional raised variant reaches5.1236m, but its absolute eave is not source-anchored and it is **not** the selected patch. Do not apply it by default.

## Actual source and provisional camera

The source is the actual1902published full plate, independently verified by actual title/copyright pages. It is not a model derived from the unresolved1930copy’s creation/issuance date. `gale-plate-upright-analysis.png` is an exact clockwise quarter-turn of the original page image: no crop, resample, retouch or generated content. `verify.py` checks full pixel equality after the same quarter-turn. Both source hashes are frozen in `input-snapshot.json`.

`camera-gale-core-pilot.json` uses this full2741×1853page. Four manually read visible outer roof-plane vertices are retained in `roof-fit.json`: near+x ridge[1242,648], near+x/+y eave[1446,774], far-x/+y eave[2041,789], far-x ridge[1857,708]. A level pilot holds the existing20×15ft reconstructed plan,2.66m eave,22° trial and conventional1.7m eye. Numerical fitting gives14.37px RMS and20.60px maximum roof-corner residual; it does not solve hidden ground/base, absolute scale or a historic lens.

`pitch-trials.json` uses identical points, held plan/eave/eye and fitting bounds for12°,22°,32° numerical trials: RMS28.43px,14.37px,32.25px respectively. This supports selecting22° for a first comparison, not a measured original pitch. The trials refit pose only for numerical study. **Actual before/after rendering uses one unchanged22° pilot camera for every asset**, including the optional raised diagnostic. It must not hide changes by refitting each image.

The source’s+x gable is lighter than its long+y side, and figures cast shadows; `sun_uvy=[6,-2,7]` is a provisional reading of that direction. Tone, roof boards and rounded log profiles still need work. The renderer’s plain grade plane is not a calibrated historic street.

## Date and identity remain explicit

Gale’s plate says1836. His actual p51 town-walk prose, within a narrative framed by arrival25May1835, names a small log jail concealed by a high palisade and Beach’s house partly in that enclosure, facing Randolph. This broadly supports the components’ relationship in his1835recollection, but supplies no measurements or dated alteration sequence. It does not prove every drawn1836detail existed on1July1835.

Andreas p175 distinguishes original log jail from a later separate oaken cell without dating the addition. His1884courthouse plate gives the rear log block a shallow hip/pyramidal cap, and the courthouse itself is dated fall1835. That conflict is preserved. No stockade, keeper house, extra cell, internal floor/storey or compound completion date is added. The original ticket remains open.

## Ready runner and resource boundary

No Blender/browser has run for this proposal. Only light source/numerical/schema/input checks were performed. Parent must coordinate the shared compute slot before execution.

Dry run (already checked; performs no export/browser):

```sh
python /tmp/chicago-next-model/T-2380-next-gale/run_preview.py
```

After parent coordinates the slot, run with its already verified pinned Blender executable:

```sh
python /tmp/chicago-next-model/T-2380-next-gale/run_preview.py --execute --blender /absolute/path/to/blender-4.5.3-linux-x64/blender
```

Add `--with-raised-diagnostic` only to inspect that separate hypothesis. The runner verifies Blender4.5.3, validates frozen inputs/proposal/source/committed-asset hashes, then creates timestamped `/tmp` fixtures. It copies the actual committed baseline GLB and builds only the selected proposed master using the official `log_jail__log_1833` name/seed. `--no-bake` exports a preview without AO. It renders both under the exact same camera using the real `photo_match.mjs`, closes its browser/server normally, and leaves review images and unreviewed match records entirely in the isolated fixture. No canonical app/ticket path is written.

The optional fixture preparation script also runs no Blender/browser. The fixture is not a complete development checkout; it exists only for these frozen exports and reviews. If parent changes any frozen source/generator/record or the committed GLB, it refuses rather than silently switching baseline. Refresh/review the package first.

## Focused checks and blast radius

`verify.py` / `verify.log` pass source rights, structure schema, exact isolated form delta, retained phase/footprint/date/placement/use/door/default vent, no new components, unchanged generator-code hashes, correct baseline recipe and asset bytes hash, lossless source orientation, finite camera parameters, frozen input/proposal hashes, runner syntax and `git apply --check`.

Current committed baseline recipe matches the actual record/code: `daf789e64dede9497de8d144326e728980e2e0e484f9797cfc03ec7e4c74b6f9`.

**Blast radius: one existing `log_jail__log_1833` master plus its web derivative/metadata.** No shared generator, parameter default, common material, other outbuilding record, grade ruling or scene camera is changed. The camera is a proposal file under `/tmp`, not a canonical solved-view claim. Its adoption, actual GLB/image comparison, remaining-difference ledger, app validation and full gates belong to the next reviewed integration. No `matches` verdict, export acceptance, bake or ticket closure is claimed here.
