"""Run only after parent coordinates an exclusive Blender/browser slot."""
from pathlib import Path
import argparse,subprocess,sys,json,hashlib
B=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute',action='store_true',help='execute after resource coordination; omission only prints planned scope');ap.add_argument('--blender',type=Path,help='session-verified pinned Blender4.5.3 executable');ap.add_argument('--with-raised-diagnostic',action='store_true');a=ap.parse_args()
if not a.execute:
 print('NOT EXECUTED. Planned scope: frozen committed baseline plus one official-name roof-only export, same-camera full-Gale before/after photo_match. Optional third raised diagnostic only with flag. Parent must coordinate Blender/browser slot first.');sys.exit(0)
if not a.blender or not a.blender.is_file():raise SystemExit('--blender must name existing pinned executable')
v=subprocess.run([str(a.blender),'--version'],check=True,text=True,capture_output=True).stdout
if 'Blender 4.5.3' not in v:raise SystemExit('Wrong Blender version; use session-verified pinned4.5.3')
r=subprocess.run([sys.executable,str(B/'prepare_fixture.py')],text=True,capture_output=True,check=True);run=Path(r.stdout.strip().splitlines()[-1]);print('Fixture:',run,flush=True)
labels=['baseline','roof-only']+(['raised-diagnostic'] if a.with_raised_diagnostic else [])
for label in labels:
 root=run/label
 if label!='baseline':
  cmd=[str(a.blender),'-b','-noaudio','--factory-startup','--threads','2','--python','generators/build.py','--','--only','log_jail','--scene','1835','--no-bake','--out','assets/gltf','--wrote','wrote.txt']
  with (root/'export.log').open('w') as log:subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
  assert (root/'wrote.txt').read_text().splitlines()==['log_jail__log_1833.glb']
 cmd=['node','tools/photo_match.mjs','data/reference_views/log_jail/gale-core-pilot.json','--glb','assets/gltf/log_jail__log_1833.glb','--out','reviews']
 with (root/'photo-match.log').open('w') as log:subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(label,'captured; inspect actual reviews/gale-core-pilot-side-by-side.jpg before assigning any verdict',flush=True)
print('Done; all subprocesses exited. No canonical/ticket edits. Existing ticket remains open. No matches verdict written.',flush=True)
