"""Create disposable fixtures only. Does not run Blender or a browser."""
from pathlib import Path
import json,hashlib,datetime,shutil
B=Path(__file__).resolve().parent;R=Path('/workspace/chicago');D=R/'chicago/4d';meta=json.loads((B/'input-snapshot.json').read_text())
for rel,want in meta['input_sha256'].items():
 if hashlib.sha256((R/rel).read_bytes()).hexdigest()!=want:raise RuntimeError('Frozen input drifted; refresh/review before export: '+rel)
if hashlib.sha256((D/'assets/gltf'/meta['asset_name']).read_bytes()).hexdigest()!=meta['baseline_asset_sha256']:raise RuntimeError('baseline GLB drifted')
if hashlib.sha256((B/'gale-plate-upright-analysis.png').read_bytes()).hexdigest()!=meta['source_photo_sha256']:raise RuntimeError('source photo changed')
for rel,want in meta['proposal_sha256'].items():
 if hashlib.sha256((B/rel).read_bytes()).hexdigest()!=want:raise RuntimeError('proposal artifact changed: '+rel)
run=B/'runs'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S-%f');run.mkdir(parents=True)
for label in ['baseline','roof-only','raised-diagnostic']:
 root=run/label;root.mkdir();shutil.copytree(D/'generators',root/'generators',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 for rel in ['data/scenes','renderers/web/vendor/three-0.185.1']:shutil.copytree(D/rel,root/rel)
 for rel in ['data/datum.json','renderers/web/js/keith-stone.js','tools/photo_match.mjs','tools/photo_match_group.mjs']:
  dst=root/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(D/rel,dst)
 (root/'node_modules').symlink_to('/workspace/node_modules',target_is_directory=True)
 rel='chicago/4d/data/structures/log_jail.json';record=(B/('before' if label=='baseline' else label)/rel);dest=root/'data/structures/log_jail.json';dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(record,dest)
 asset=root/'assets/gltf'/meta['asset_name'];asset.parent.mkdir(parents=True);shutil.copy2(D/'assets/gltf'/meta['asset_name'],asset)
 (root/'assets/manifest.json').write_text(json.dumps({'assets':{meta['asset_name']:meta['baseline_asset_entry']}},indent=2)+'\n')
 source_ids={'trowbridge_first_jail_gale_1902'}
 def collect(v):
  if isinstance(v,dict):
   for k,x in v.items():
    if k=='sources' and isinstance(x,list):source_ids.update(i for i in x if isinstance(i,str))
    else:collect(x)
  elif isinstance(v,list):
   for x in v:collect(x)
 collect(json.loads(record.read_text()))
 for sid in source_ids:
  dst=root/'data/sources'/f'{sid}.json';dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(D/'data/sources'/f'{sid}.json',dst)
 photo=root/'data/sources/assets/gale-first-jail-1902-upright.png';photo.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(B/'gale-plate-upright-analysis.png',photo)
 cam=json.loads((B/'camera-gale-core-pilot.json').read_text());cam['photo']='../../sources/assets/'+photo.name
 dst=root/'data/reference_views/log_jail/gale-core-pilot.json';dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(json.dumps(cam,indent=2)+'\n')
 (root/'FIXTURE-ONLY.txt').write_text('Disposable jail review fixture; canonical app/ticket untouched. Baseline is committed GLB; proposed generator builds use official log_jail__log_1833 name. No source-state date is asserted by the renderer.\n')
(run/'snapshot.json').write_text(json.dumps(meta,indent=2)+'\n');(B/'latest-run.txt').write_text(str(run)+'\n');print(run)
