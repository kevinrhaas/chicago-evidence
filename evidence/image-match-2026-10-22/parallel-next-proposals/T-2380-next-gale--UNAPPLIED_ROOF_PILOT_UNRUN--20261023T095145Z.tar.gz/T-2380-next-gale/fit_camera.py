from pathlib import Path
import json,math,sys
import numpy as np
from scipy.optimize import least_squares
B=Path(__file__).resolve().parent;R=Path('/workspace/chicago/chicago/4d');sys.path.insert(0,str(R/'generators'))
from archetypes.outbuilding_params import from_phase,eave_overhang_m
st=json.loads((R/'data/structures/log_jail.json').read_text());ph=st['phases'][0]
# Selected roof-only pilot, NOT a solved historic dimension. The drawing cannot locate the hidden wall base.
ph=json.loads(json.dumps(ph));ph['form']['roof_pitch_deg']['value']=22.;ph['form']['wall_height_m']['value']=2.66
p=from_phase(ph,st);w,d=p.width_m,p.depth_m;oh=eave_overhang_m(w,d);z=float(p.wall_height_m);rise=p.roof_rise_m
# Four visible boundaries manually read in the losslessly quarter-turned full Gale1902 plate.
# near+x ridge, near+x/+y eave, far-x/+y eave, far-x ridge. Outer roof planes, not wall corners.
xyz=np.array([[w+oh,d/2,z+rise],[w+oh,d+oh,z-rise*oh/(d/2)],[-oh,d+oh,z-rise*oh/(d/2)],[-oh,d/2,z+rise]])
observed=np.array([[1242,648],[1446,774],[2041,789],[1857,708]],dtype=float)
# Level provisional view; a free principal-y acknowledges the historical drawing's framing.
cx=1370.5
# u,v,yaw,focal,cy; eye height is a conventional1.7m. No scene coordinates or building footprint are fitted.
def project(x):
 u,v,yaw,f,cy=x;h=1.7;t=np.deg2rad(yaw);right=np.array([np.cos(t),-np.sin(t),0]);forward=np.array([np.sin(t),np.cos(t),0]);delta=xyz-np.array([u,v,h]);dep=delta@forward
 return np.column_stack([cx+f*(delta@right)/dep,cy-f*delta[:,2]/dep])
def loss(x):return (project(x)-observed).ravel()
res=least_squares(loss,[25,30,217,4000,900],bounds=([8,8,190,500,500],[80,80,260,10000,1600]),max_nfev=250)
result={'method':'Provisional level roof-plane fit; reconstructed plan/eave/pitch held, manual pixel uncertainty several pixels, not a surveyed scene camera. No ground/eave height is independently identified by partly hidden lower walls.','variables':dict(zip(['eye_u','eye_v','yaw_deg','focal_px','principal_y_px'],res.x.tolist())),'roof_points_model_m':xyz.tolist(),'roof_points_source_px':observed.tolist(),'projected_px':project(res.x).tolist(),'residual_px':(project(res.x)-observed).tolist(),'rms_euclidean_px':float(np.sqrt(np.mean(np.sum((project(res.x)-observed)**2,axis=1)))),'max_euclidean_px':float(np.max(np.linalg.norm(project(res.x)-observed,axis=1))),'near_m':.1,'assumed_reconstructed_eave_m':2.66,'assumed_reconstructed_pitch_deg':22.,'assumed_eye_height_m':1.7,'fitting_succeeded':bool(res.success),'fitting_status':res.message}
(B/'roof-fit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
