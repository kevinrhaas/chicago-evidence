"""Light numerical source study only; not a rendered comparison or angle measurement."""
from pathlib import Path
import json,sys,copy,math
import numpy as np
from scipy.optimize import least_squares
B=Path(__file__).resolve().parent;R=Path('/workspace/chicago/chicago/4d');sys.path.insert(0,str(R/'generators'))
from archetypes.outbuilding_params import from_phase,eave_overhang_m
st=json.loads((R/'data/structures/log_jail.json').read_text());observed=np.array([[1242,648],[1446,774],[2041,789],[1857,708]],float);out=[]
for pitch in [12.,22.,32.]:
 ph=copy.deepcopy(st['phases'][0]);ph['form']['roof_pitch_deg']['value']=pitch;p=from_phase(ph,st);w,d,z=p.width_m,p.depth_m,p.wall_height_m;oh=eave_overhang_m(w,d);rise=p.roof_rise_m
 xyz=np.array([[w+oh,d/2,z+rise],[w+oh,d+oh,z-rise*oh/(d/2)],[-oh,d+oh,z-rise*oh/(d/2)],[-oh,d/2,z+rise]])
 def project(x):
  u,v,yaw,f,cy=x;t=np.deg2rad(yaw);delta=xyz-[u,v,1.7];dep=delta@np.array([np.sin(t),np.cos(t),0]);return np.column_stack([1370.5+f*(delta@np.array([np.cos(t),-np.sin(t),0]))/dep,cy-f*delta[:,2]/dep])
 res=least_squares(lambda x:(project(x)-observed).ravel(),[25,30,217,4000,900],bounds=([8,8,190,500,500],[80,80,260,10000,1600]),max_nfev=250)
 out.append({'pitch_deg':pitch,'fixed_reconstructed_eave_m':z,'eye_height_m':1.7,'principal_x_px':1370.5,'pose_variables':['eye_u','eye_v','yaw_deg','focal_px','principal_y_px'],'fit_variables':res.x.tolist(),'rms_euclidean_px':float(np.sqrt(np.mean(np.sum((project(res.x)-observed)**2,axis=1)))),'max_euclidean_px':float(np.max(np.linalg.norm(project(res.x)-observed,axis=1))),'projected_px':project(res.x).tolist(),'success':bool(res.success)})
(B/'pitch-trials.json').write_text(json.dumps({'caution':'Identical four manual roof-plane vertices/held reconstructed plan/eave/conventional eye/bounds; each trial permits its own provisional pose for numerical study only. Actual before/after captures use ONE SAME selected camera. This is not a measured pitch or render acceptance.','trials':out},indent=2)+'\n');print([(t['pitch_deg'],t['rms_euclidean_px']) for t in out])
