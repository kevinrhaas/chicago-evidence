# T-2380: independent Andreas public-domain route

The actual Andreas pages establish a usable public-domain picture of the jail ensemble. They do **not** establish a safe existing-parameter correction to the original 1833 core in the July 1835 scene. No geometry patch was manufactured; the distinct Keystone/Tribune-derived proposal remains held and unbaked.

## Actual pages read

1. **History of Chicago vol.1 (1884), printed p175**, actual `chicago-n366.jpg`: “During the fall of 1833 ... The log jail was therefore built on the northwest corner of the square.” Contractors initially failed; it was finally completed. It then says: “As offenders against the laws increased, an addition, in the form of an oaken cell, or jail, was built, separate from the first structure.” This is a distinct building, not an upper storey. The paragraph gives no date, dimensions, roof or opening specification for that addition. It reports the small building held as many as twenty-eight prisoners; that is not a survey.
2. **Same volume, p176**, actual `chicago-n368.jpg`: “During the fall of the year (1835), a one-story and basement brick court-house was erected on the northeast corner of the square, on Clark and Randolph streets.” This is after 1 July. It supplies no jail alteration date.
3. **Same volume, p177**, actual `chicago-n372.jpg`: plate caption **THE FIRST COURT-HOUSE**, with the visible credit **Copyright secured by A. T. Andreas, 1884**. The plate matches the project's committed `chicago_first_courthouse_1835.jpg` at greater local detail.
4. **History of Cook County, Illinois (1884), p353**, actual `cook-n336.jpg`: the identical plate is explicitly captioned **FIRST COURT HOUSE AND JAIL**, with the visible **Copyright, A. T. Andreas, 1884** credit. The title is decisive for the background ensemble's identification as the jail; it does not label each building within it.
5. **History of Chicago vol.1, p605**, actual `chicago-n1242.jpg`: an account explicitly dated 1842 locates the log jail at the northwest corner of the courthouse square and the Grecian-columned brick courthouse at the eastern corner. This corroborates identity/location of the ensemble at a later date, without describing the roof or tracing either cell back to July 1835. Its account of Edwin Heathcock's confinement and forced sale is historical evidence, not a source for model dimensions or a scene to add.

The original volume citations and the plate's own 1884 imprint establish public-domain status by age. This rights basis is independent of the detailed image catalogued in 1930 and reproduced in 1947.

## What the plate actually shows

At right: a low gabled house, a tall palisade, and a higher rear log block under a shallow **four-sided hipped/pyramidal cap**. The rear cap has sloping roof edges around its visible corners; this is not the high triangular gable in the detailed held picture. The visible log block is part of the jail ensemble, but neither caption labels it as the original 1833 cell. The separate later oaken cell named on p175 is an unresolved alternative identification.

The stockade and low house conceal the rear block's lower walls, entrance and most possible openings. There is no pictured barred rear-core opening in this plate that can independently support copying the held image's gable aperture. The plate gives no absolute height or pitch. The adjacent house is also undimensioned, so its presence cannot anchor a metric eave height without a reconstruction chain. Counting visible log lines cannot determine hidden wall extent or log-course thickness.

Because the brick courthouse itself is dated to fall 1835, the setting shown is later than the target scene. That does not prove the jail changed in autumn, but it also cannot establish that the rear log block or entire stockade existed by 1 July. A selected earlier continuity would have to be explicit, not folded into the caption's date.

## Existing generator constraint

The current jail is `outbuilding` with `roof_type=gable`, pitch 12 degrees and 2.66m eave. Its 20×15ft footprint and all metrics are existing reconstruction. Existing `ROOF_TYPES` is exactly `('gable', 'shed')`; the light check confirms `hip` is refused. Neither reducing pitch nor choosing shed reproduces the four-sided cap. The default small vent is not an explicitly positioned gable window; the loft option is a hay door, not an escape hatch for a jail opening.

Thus no independent roof-type correction is expressible through existing values. No absolute eave/pitch update is sufficiently bounded here to be preferable to retaining the declared proxy. No source-supported opening change can be read through the occlusion. Altering those numbers merely to have a patch would replace one unmeasured convention with another.

## Concrete retained outputs and bounded next route

- `proposed-source.json` is a schema-checked, unapplied public-domain plate source, with exact page-image locators, image reading and date/component limits. It is available to parent for source/provenance work, without a `matches` claim.
- `light-checks.log` validates that source, the current jail parameters and the exact missing hip vocabulary.
- A meaningful roof correction would require a guarded opt-in hip/pyramid path in `outbuilding`, plus an explicit inference assigning the pictured rear block to this record's original core before July. A shape-only branch could retain the current footprint/eave/pitch rather than invent dimensions, but it would still need that identity/date decision and actual paired review. Adding the new roof affects shared source hashes for all 243 registered outbuilding masters even if their defaults remain identical. It is not included as a data-only patch here.
- Alternatively, a dated county order/contract can distinguish the original cell, later separate oaken cell and keeper's dwelling. The actual p175 construction sequence is now verified at page level and gives precise terms for that search.

No repo edits, Blender, browser, bake, image verdict or closure. The earlier rights-held proposal remains separately frozen. No owner question was sent.

## Locator caution

The downloaded scandata's printed-page labels are wrong for these service endpoints. A supposed leaf213/p175 fetch actually displays p100 or its blank verso; Cook leaf339 actually displays p356. Misresolved images are retained under `rejected-locators/`, not cited as the desired pages. The filenames n366/n368/n372/n1242 and n336 above are tied to the **visible printed numbers** read on actual images. Do not adopt an inferred scan offset for unseen pages.
