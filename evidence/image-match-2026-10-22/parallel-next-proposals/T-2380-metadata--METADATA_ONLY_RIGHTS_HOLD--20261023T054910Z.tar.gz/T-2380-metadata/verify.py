import copy,dataclasses,json,pathlib,sys,hashlib,subprocess
B=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/workspace/chicago/chicago/4d');repo=R.parent.parent
sys.path[:0]=[str(R/'tools'),str(R/'generators')]
import mesh_inputs,compile_pictures as cp,grade_structures as gs,jsonschema
rel='chicago/4d/data/structures/log_jail.json'
a=json.loads((B/'before'/rel).read_text());b=json.loads((B/'after'/rel).read_text())
x=copy.deepcopy(b);x['research_note']=a['research_note'];assert x==a
assert a['phases']==b['phases'] and a['archetype']==b['archetype']
jsonschema.validate(b,json.loads((R/'data/structures.schema.json').read_text()))
srel='chicago/4d/data/sources/calisphere_ucr_first_jail_catalogue_1930.json'
s=json.loads((B/'after'/srel).read_text());jsonschema.validate(s,json.loads((R/'data/source.schema.json').read_text()))
assert s['type']=='website' and s['asset_use']=='text_only' and s['rights_status']=='check_required'
assert s['id'] not in json.dumps(b['phases'])
p=mesh_inputs.structure_inputs_doc(a,a['phases'][0]);q=mesh_inputs.structure_inputs_doc(b,b['phases'][0]);assert p==q
ph=mesh_inputs.structure_inputs_sha(a,a['phases'][0]);qh=mesh_inputs.structure_inputs_sha(b,b['phases'][0]);assert ph==qh
images,tsv,sources,texts,scenes,cams=cp.read_tree()
old_sources=copy.deepcopy(sources);new_sources=copy.deepcopy(sources);new_sources[s['id']]=s
old_texts={'log_jail':(B/'before'/rel).read_text()};new_texts={'log_jail':(B/'after'/rel).read_text()}
focused={'1835':['log_jail']}
oldpics=cp.derive(images,tsv,old_sources,old_texts,focused,cams);newpics=cp.derive(images,tsv,new_sources,new_texts,focused,cams)
assert oldpics==newpics
rulings=gs.load_rulings();exist=a['phases'][0]['documented_range']['confidence']
g0=gs.grade_structure('log_jail',exist,oldpics['1835']['by_structure'].get('log_jail',[]),cams.get('log_jail',[]),rulings,'1835')
g1=gs.grade_structure('log_jail',exist,newpics['1835']['by_structure'].get('log_jail',[]),cams.get('log_jail',[]),rulings,'1835');assert g0==g1
for r in ['chicago/reference/images/IMAGE_SOURCES.md','chicago/reference/planning/images/IMAGE_SOURCES.md']:
 text=(B/'after'/r).read_text();block=text.split('#### `chicago_cook_county_jail_1836.jpg`')[1].split('#### ')[0]
 assert 'check_required' in block and 'copy catalogued September 19, 1930' in block
 assert 'Public domain (faithful reproduction of pre-1930 artwork)' not in block
 allowed={x['path'] for x in json.loads((B/'base.json').read_text())}
 assert all(not r.startswith(('chicago/4d/assets/','chicago/4d/generators/','chicago/4d/data/reference_views/','chicago/4d/data/sidecars/')) for r in allowed)
subprocess.run(['git','apply','--check',str(B/'T-2380-metadata.patch')],cwd=repo,check=True,capture_output=True)
(B/'recipe-before.json').write_text(json.dumps(p,indent=2,sort_keys=True)+'\n');(B/'recipe-after.json').write_text(json.dumps(q,indent=2,sort_keys=True)+'\n')
print('PASS: structure/source schema; only research_note differs in structure; all phase/form/source/confidence/date/place values identical')
print('PASS: textual website source check_required/text_only; no form-source linkage or automatic picture entry')
print('PASS: exact current mesh input document and SHA unchanged:',ph)
print('PASS: focused actual picture join and pure grade unchanged:',json.dumps(g1))
print('PASS: inventory corrections in both copies; no asset/generator/camera/sidecar changed; git apply --check')
print('UNRUN: compile/release/full gate; no derived asset, browser or bake performed')
