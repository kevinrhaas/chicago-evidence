#!/usr/bin/env node
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {register} from 'node:module';
const root='/workspace/chicago/chicago/4d/';
const h=new URL('.',import.meta.url);
const vendor=new URL('file://'+root+'renderers/web/vendor/three-0.185.1/').href;
register(`data:text/javascript,${encodeURIComponent(`export function resolve(s,c,next){if(s==='three')return {url:'${vendor}three.module.js',shortCircuit:true};if(s.startsWith('three/addons/'))return {url:'${vendor}addons/'+s.slice(13),shortCircuit:true};return next(s,c);}`)}`,import.meta.url);
const {footprintsFrom}=await import('file://'+root+'renderers/web/js/walker.js');
const {footprintCentre,inside,wallDistance}=await import('file://'+root+'renderers/web/js/show-me.js');
const {addFeet}=await import('file://'+root+'renderers/web/js/building-feet.js');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const trial=read(new URL('candidate/chicago/4d/data/structures/chicago_lighthouse_1832.json',h));
const baseline=read(new URL('baseline/chicago/4d/data/structures/chicago_lighthouse_1832.json',h));
const existing=read(root+'data/sidecars/1835/chicago_lighthouse_1832.json');
const sc={...existing,footprint:trial.phases[0].footprint};
const oldfp=footprintsFrom(new Map([[trial.id,{id:trial.id,sidecar:{...existing,footprint:baseline.phases[0].footprint}}]]))[0];
const newfp=footprintsFrom(new Map([[trial.id,{id:trial.id,sidecar:sc}]]))[0];
const c=footprintCentre(newfp.pts),oldc=footprintCentre(oldfp.pts);
assert(Math.hypot(c.e-oldc.e,c.n-oldc.n)<1e-9);
assert(Math.abs(Math.max(...newfp.pts.map(p=>p[0]))-Math.min(...newfp.pts.map(p=>p[0]))-3.04)<1e-6);
assert(!inside([existing.placement.local_e+2.8,existing.placement.local_n+0.5],newfp.pts),'old empty strip must not remain an invisible wall');
assert(inside([existing.placement.local_e+2.8,existing.placement.local_n+0.5],oldfp.pts));
for(const angle of [0,37,90,193]){
 const placement={...existing.placement,rotation_deg:angle};
 const q=(poly)=>footprintsFrom(new Map([[trial.id,{id:trial.id,sidecar:{...existing,placement,footprint:{polygon:poly}}}]]))[0];
 const before=footprintCentre(q(baseline.phases[0].footprint.polygon).pts),after=footprintCentre(q(trial.phases[0].footprint.polygon).pts);
 assert(Math.hypot(before.e-after.e,before.n-after.n)<1e-9);
}
const local=trial.phases[0].footprint.polygon,lc=footprintCentre(local);
assert(Math.hypot(lc.e-2.8,lc.n-2.8)<1e-12);
assert(wallDistance(lc,local,0,1)<1.6);
const raw=read(new URL('raw-trial-geometry.json',h));
const vertices=[],indices=[];
for(const [face] of raw.faces){const start=vertices.length;for(const p of face)vertices.push([p[0],p[2],-p[1]]);for(let i=1;i<face.length-1;i++)indices.push(start,start+i,start+i+1);}
const pos={count:vertices.length,getX:i=>vertices[i][0],getY:i=>vertices[i][1],getZ:i=>vertices[i][2]};
const geo={getAttribute:n=>n==='position'?pos:null,getIndex:()=>({count:indices.length,getX:i=>indices[i]})};
const feet=addFeet(new Map(),geo);assert(feet.size>0);
for(const [x,z] of feet.values()){assert(x>=1.28-1e-6&&x<=4.32+1e-6&&z>=-4.32-1e-6&&z<=-1.28+1e-6);const r=Math.hypot(x-2.8,-z-2.8);assert(r>=1.46&&r<=1.521);}
console.log(JSON.stringify({status:'passed',real_walker_collision_uses_narrow_physical_polygon:true,real_show_me_centre_unchanged:true,old_empty_strip_no_longer_blocks:true,real_building_feet_reads_narrow_actual_mesh:true,foot_sample_count:feet.size,world_centre_enu:[c.e,c.n],no_browser_or_repository_writes:true},null,2));
