#!/usr/bin/env bash
# PREPARED ONLY: wait for parent's explicit Blender/browser execution slot.
set -euo pipefail
lighthouse_package="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$lighthouse_package/prepare_fixture.py"
lighthouse_run="$(cat "$lighthouse_package/latest-run.txt")"
source "$lighthouse_run/proposed/generators/blender.pin"
lighthouse_archive="/workspace/shared/blender-dl/$(basename "$BLENDER_URL")"
lighthouse_binary="/workspace/shared/blender-dl/$BLENDER_DIR/blender"
printf '%s  %s\n' "$BLENDER_SHA256" "$lighthouse_archive" | sha256sum -c -
python3 - "$lighthouse_binary" "$BLENDER_VERSION" <<'PY'
import subprocess,sys
r=subprocess.run([sys.argv[1],'--version'],text=True,capture_output=True,check=True);assert r.stdout.splitlines()[0].split()[1]==sys.argv[2]
PY
for lighthouse_kind in baseline proposed; do
  cd "$lighthouse_run/$lighthouse_kind"
  BLENDER_USER_CONFIG="$lighthouse_run/blender-config" "$lighthouse_binary" -b -noaudio --factory-startup --python generators/build.py -- --only chicago_lighthouse_1832 --wrote "$lighthouse_run/$lighthouse_kind-wrote.txt" > "$lighthouse_run/$lighthouse_kind-export.log" 2>&1
  PW_EXECUTABLE="${PW_EXECUTABLE:-/usr/bin/chromium}" node tools/photo_match.mjs docs/RESEARCH/narrow-trial/camera.json --out "$lighthouse_run/reviews/$lighthouse_kind" > "$lighthouse_run/$lighthouse_kind-review.log" 2>&1
done
python3 "$lighthouse_package/glb_contracts.py" "$lighthouse_run"
