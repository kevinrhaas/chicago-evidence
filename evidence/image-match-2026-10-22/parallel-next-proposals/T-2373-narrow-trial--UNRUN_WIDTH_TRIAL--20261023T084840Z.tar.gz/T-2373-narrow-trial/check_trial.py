#!/usr/bin/env python3
"""Parameter/API, emitted tower face and exact placement proofs; no bpy/browser."""
from pathlib import Path
from dataclasses import asdict,replace
from types import ModuleType,SimpleNamespace
import ast,copy,inspect,json,math,sys
H=Path(__file__).resolve().parent;REPO=Path('/workspace/chicago');BASE=H/'baseline';NEW=H/'candidate';SELECTIVE=Path('/tmp/chicago-next-model/fort-selective-integration/staged/candidate');ROOT='chicago/4d/'
def load(path,name):
 m=ModuleType(name);sys.modules[name]=m;exec(compile(path.read_text(),str(path),'exec'),m.__dict__);return m
p_rel=ROOT+'generators/archetypes/fort_structure_params.py';g_rel=ROOT+'generators/archetypes/fort_structure.py';r_rel=ROOT+'data/structures/chicago_lighthouse_1832.json'
a=load(BASE/p_rel,'lighthouse_trial_before');b=load(NEW/p_rel,'lighthouse_trial_after')
added={'tower_diameter_m','footprint_min_u_m','footprint_min_v_m'}
assert b.CONSUMED==a.CONSUMED|{'tower_diameter_m'}
assert a.FortStructureParams.__match_args__==b.FortStructureParams.__match_args__
for key,p in inspect.signature(b.FortStructureParams).parameters.items():
 if key in added:assert p.kind==inspect.Parameter.KEYWORD_ONLY
 else:assert p==inspect.signature(a.FortStructureParams).parameters[key]
scope=json.loads(Path('/tmp/chicago-next-model/fort-selective-integration/staged/review-manifest.json').read_text())['family_refresh']['assets'];phases=[]
for row in scope:
 rel=ROOT+'data/structures/'+row['structure_id']+'.json';path=SELECTIVE/rel
 record=json.loads((path if path.exists() else REPO/rel).read_text());ph=next(p for p in record['phases'] if p['id']==row['phase_id'])
 old=a.from_phase(ph,record);new=b.from_phase(ph,record);d=asdict(new)
 for key in added:assert d.pop(key)==(None if key=='tower_diameter_m' else 0)
 assert d==asdict(old)
 legacy_names=a.FortStructureParams.__match_args__
 existing_kw={key:getattr(old,key) for key,param in inspect.signature(a.FortStructureParams).parameters.items() if param.kind==inspect.Parameter.KEYWORD_ONLY}
 positional=b.FortStructureParams(*[getattr(old,key) for key in legacy_names],**existing_kw)
 posdict=asdict(positional)
 for key in added:posdict.pop(key)
 assert posdict==asdict(old)
 phases.append((record,ph,old,new))
oldrec=json.loads((BASE/r_rel).read_text());newrec=json.loads((NEW/r_rel).read_text());oldph=oldrec['phases'][0];newph=newrec['phases'][0];selected=b.from_phase(newph,newrec)
assert selected.tower_diameter_m==3.04 and selected.footprint_min_u_m==1.28 and selected.footprint_min_v_m==1.28
for key in ['position','documented_range']:assert oldph[key]==newph[key]
for key,value in oldph['form'].items():assert newph['form'][key]==value
assert oldph['footprint']['confidence']==newph['footprint']['confidence']=='reconstructed'
assert oldph['position']['rotation_deg']==newph['position']['rotation_deg']
assert selected.width_m==selected.depth_m==3.04
assert (selected.footprint_min_u_m+selected.width_m/2,selected.footprint_min_v_m+selected.width_m/2)==(2.8,2.8)
assert selected.wall_height_m==12.19
# Fail unsafe/ambiguous dimensions and all undeclared nonzero-bbox paths.
invalid=[True,False,0,-1,float('nan'),float('inf'),'3.04',3.05]
for value in invalid:
 try:replace(selected,tower_diameter_m=value).validate()
 except b.ParamError:pass
 else:raise AssertionError(('invalid diameter accepted',value))
for params in [replace(selected,kind='quarters'),replace(selected,tower_diameter_m=None),replace(selected,footprint_min_u_m=float('nan'))]:
 try:params.validate()
 except b.ParamError:pass
 else:raise AssertionError('unsafe explicit params accepted')
for mutate in ['no_optin','non_tower']:
 rec=copy.deepcopy(newrec);ph=rec['phases'][0]
 if mutate=='no_optin':del ph['form']['tower_diameter_m']
 else:ph['form']['kind']['value']='quarters'
 try:b.from_phase(ph,rec)
 except b.ParamError:pass
 else:raise AssertionError('offset polygon accepted without proper tower opt-in')
class Collect:
 def __init__(self):self.faces=[];self.named={}
 def add_poly(self,points,confidence,mat=0):self.faces.append((tuple(tuple(float(v) for v in p) for p in points),float(confidence),mat));return []
 def named_mat(self,name,*spec):self.named.setdefault(name,(1000+len(self.named),spec));return self.named[name][0]
mesh_tree=ast.parse((REPO/(ROOT+'generators/common/mesh.py')).read_text());mesh_class=next(n for n in mesh_tree.body if isinstance(n,ast.ClassDef) and n.name=='MeshBuilder');node=next(n for n in mesh_class.body if isinstance(n,ast.FunctionDef) and n.name=='add_box');ns={};exec(compile(ast.fix_missing_locations(ast.Module(body=[copy.deepcopy(node)],type_ignores=[])),'actual_add_box','exec'),ns);Collect.add_box=ns['add_box']
def extract(path,params):
 t=ast.parse(path.read_text());f=[copy.deepcopy(n) for n in t.body if isinstance(n,ast.FunctionDef) and n.name in ['_tower','_birdcage_lantern']];ns={'math':math,'MeshBuilder':Collect,'FortStructureParams':params.FortStructureParams,'M_WALL':0,'M_ROOF':1,'M_DARK':2,'M_TRIM':3,'openings':SimpleNamespace(glass_material_spec=lambda:((.1134,.1164,.1144,1),.065))};exec(compile(ast.fix_missing_locations(ast.Module(body=f,type_ignores=[])),str(path),'exec'),ns);return ns
fa=extract(BASE/g_rel,a);fb=extract(NEW/g_rel,b)
for record,ph,old,new in phases:
 if old.kind!='tower':continue
 for profile,lantern in [('birdcage_dome',True),('legacy',True),('legacy',False)]:
  x,y=Collect(),Collect();fa['_tower'](x,replace(old,lantern_profile=profile,lantern=lantern));fb['_tower'](y,replace(new,lantern_profile=profile,lantern=lantern));assert x.faces==y.faces
# The previous near-square tolerance also preserves old default geometry.
old=a.FortStructureParams(5.6,5.4,kind='tower',wall_height_m=12.19);new=b.FortStructureParams(5.6,5.4,kind='tower',wall_height_m=12.19);old.validate();new.validate();x,y=Collect(),Collect();fa['_tower'](x,old);fb['_tower'](y,new);assert x.faces==y.faces
# Every non-tower helper remains text/AST-identical.
def functions(path):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef)}
af,bf=functions(BASE/g_rel),functions(NEW/g_rel);assert af.keys()==bf.keys();assert [k for k in af if af[k]!=bf[k]]==['_tower']
geo=Collect();fb['_tower'](geo,selected);vs=[p for points,_,_ in geo.faces for p in points];bounds={'min':[min(p[i] for p in vs) for i in range(3)],'max':[max(p[i] for p in vs) for i in range(3)]}
assert abs(bounds['min'][0]-1.28)<1e-10 and abs(bounds['max'][0]-4.32)<1e-10
assert abs(bounds['min'][1]-1.28)<1e-10 and abs(bounds['max'][1]-4.32)<1e-10
assert bounds['min'][2]==0 and abs(bounds['max'][2]-12.84968)<1e-8
for points,c,mat in geo.faces:
 assert c==1.0 and all(math.isfinite(v) for p in points for v in p)
 normal=[0.,0.,0.]
 for p,q in zip(points,points[1:]+points[:1]):normal[0]+=(p[1]-q[1])*(p[2]+q[2]);normal[1]+=(p[2]-q[2])*(p[0]+q[0]);normal[2]+=(p[0]-q[0])*(p[1]+q[1])
 assert sum(v*v for v in normal)>1e-18
feet=[p for p in vs if abs(p[2])<1e-8];assert feet and all(abs(math.hypot(p[0]-2.8,p[1]-2.8)-1.52)<1e-10 for p in feet)
# Same fixed camera and no aspect: width improvement isolated from camera changes.
cam=json.loads((H/'camera-same-framing.json').read_text());assert cam['pixel_aspect']==1
f,d=cam['focal_px'],102.8
project=lambda p:(cam['principal_px'][0]+f*(p[0]-2.8)/(p[1]+100),cam['principal_px'][1]-f*(p[2]-2)/(p[1]+100))
def width(r,z):
 ps=[project((2.8+r*math.cos(i*math.pi/600),2.8+r*math.sin(i*math.pi/600),z)) for i in range(1200)];return max(p[0] for p in ps)-min(p[0] for p in ps)
shaft_width=width(1.52*.62,12.19*.86);gallery_width=width(1.52*.62*1.34,12.19*.86)
assert abs(shaft_width-24)<=3 and abs(gallery_width-31)<=3
(H/'raw-trial-geometry.json').write_text(json.dumps({'faces':geo.faces,'bounds':bounds})+'\n')
report={'status':'passed','all25_final_selective_default_parameter_parity':len(phases),'legacy16_argument_order_and_existing_kw_only_fields_preserved':True,'three_new_fields_keyword_only':True,'tower_only_explicit_nonzero_bbox_support':True,'all_old_form_values_position_bearing_dates_equal':True,'world_centre_equal_local_m':[2.8,2.8],'physical_footprint_bounds_m':[1.28,4.32],'mesh_bounds_m':bounds,'ground_feet_radius_m':1.52,'old_default_tower_and_no_lantern_face_stream_parity':True,'near_square_legacy_tolerance_parity':True,'all_other_helpers_AST_identical':True,'all_geometry_reconstructed_confidence':True,'same_camera_prediction':{'shaft_head_width_px':shaft_width,'gallery_floor_width_px':gallery_width,'finial_y':project((2.8,2.8,bounds['max'][2]))[1]},'unresolved':'Numeric prediction only. Actual rendered review, cap/shaft vertical mismatch, footing, historic height datum and1835continuity remain open.','blender_browser_or_repository_writes':False}
(H/'light-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
