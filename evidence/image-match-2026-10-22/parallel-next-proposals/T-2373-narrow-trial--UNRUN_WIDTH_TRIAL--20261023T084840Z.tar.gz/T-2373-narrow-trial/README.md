# T-2373 narrower physical tower trial — prepared, not rendered

This is a three-file research delta **on top of the final fort-selective-integration
payload**, not on canonical HEAD and not on the earlier fort-combined preview.
Nothing in either older package or in the repository was changed. The original
T-2373 match remains open. No Blender/browser job has run for this trial.

## Actual visible change and fixed camera

The reconstructed tower diameter becomes3.04m. At the unchanged square-pixel
corrected-control camera this predicts **23.99px shaft-head /32.15px gallery-floor**,
against coarse source controls24±3 /31±3px. The final-selective broad profile
predicts44.20 /59.24px from that same camera. No camera or aspect value was adjusted
to make this width comparison work. Source gallery FLOOR is y88–90; y75–76 is the
upper rail and cannot be substituted as the floor. The actual1842 Castelnau plate
was inspected in the prior audit, including its printed panel4/prose Fig1 conflict.

All existing form values, including attested nominal12.19m, are retained. Because
cap rise/finial remain proportional to the reconstructed shaft-head radius, total
height changes13.4052→12.84968m. The finial therefore moves to predicted y53.87
instead of46.80 and still differs from the faint source tip near38±3. This is
explicitly a width trial, not a solved vertical silhouette or a new interpretation
of forty feet. Andreas and Lighthousefriends do not specify the forty-foot datum.
The stepped footing, vertical profile, material/colour and1838-to1835 continuity
remain unresolved. Do not compensate by stretching the attested height.

## Centre-preserving physical footprint

A retained5.6m envelope was considered and rejected by the reader audit: walker
collision and Show Me treat the polygon as an actual wall, not arbitrary grounds.
No such exemption is introduced. Instead the reconstructed physical bounding square
becomes[1.28,4.32]² relative to the **unchanged record origin**. Its side is3.04m;
its centre is exactly the old(2.8,2.8). UTM position, rotation, phase dates and all
existing form values are unchanged. Current world centre remains approximately
E1058.39,N175.34 in the1835 local frame. A new surveyed location is not inferred.

GLB-CONTRACT explicitly says the mesh origin is polygon-coordinate(0,0), and need
not be the bbox corner. The old fort resolver nonetheless assumed min=0. This
trial implements the missing case ONLY for a tower with explicit
`tower_diameter_m` matching both physical polygon spans. Two internal, keyword-only
bbox-min parameters feed its actual centre; they are derived from the polygon,
not separately authored form claims. All other builders retain the zero-min
refusal. The diameter is also keyword-only and CONSUMED. Defaults keep all old
constructor arguments and geometry unchanged. Invalid/ambiguous/non-tower offsets
or diameters fail rather than dropping the offset.

The physical mesh min/max in both plan axes is1.28..4.32; its twelve-sided base
vertices lie on the1.52m radius about(2.8,2.8). Collision/static contact conservatively
use its bounding square, the same circle-versus-square approximation as before.
Rendered terrain bedding samples actual mesh feet plus the explicitly declared
origin reference, as buildings.js already does. No invisible5.6m box remains.

## Reader/contract audit

| Reader | Finding and trial behaviour |
| --- | --- |
| `fort_structure._tower` and `_birdcage_lantern` | Only tower path changes. Radius drives shaft, gallery, cage, cap and finial; all are narrowed. Centre uses derived polygon offset. All other helper ASTs remain identical. Existing radius-dependent total-height change is disclosed. New radial/body confidence becomes reconstructed. |
| `walker.footprintsFrom` | Real function tested with new polygon. Blocking box becomes3.04m; the old empty strip no longer blocks. No camp/drawn_by/water exemption is invented. |
| `show-me.footprintCentre/wallDistance` | Real functions tested. World centre remains unchanged at0,37,90,193degree test rotations; distance to physical wall shrinks with polygon. |
| `building-feet.addFeet` / `buildings.groundUnder` | Real feet reader tested on emitted triangles. Samples lie on the narrowed twelve-sided ring, within physical bounds. groundUnder reads those feet, not old bbox corners; its existing origin reference sample remains. Canonical terrain/contact and slope checks still required. |
| `validate._contact_outline` | Existing perimeter check uses actual phase polygon with its local coordinates, so it sees the new narrowed bounding square and unchanged phase origin; no contact-policy exception needed. |
| Sidecars, route clearance, plant/fort-tree keep-out | Existing compilers/readers use the polygon and placement, so normal regeneration propagates the physical shrink. Their result is not manually copied/restored from old fixtures. |
| Entrances | Existing `generate_entrances.front_doors` returns([],None) for the lighthouse; fort_structure is UNREAD in facade_openings. `_tower` builds no door. No helper falsely retains a5.6m entrance position, and this trial invents no doorway. |
| Wright glyph / Chappel town geometry / fort-tree relation tools | Read unchanged record/sidecar position and nominal height; do not independently measure a5.6m physical disk. Source raster detector's broad gallery label is not reused as a floor control; its old banked source reading is untouched. |
| Schema / GLB coordinate contract | Schema permits local polygon coordinates relative to the phase origin; docs explicitly distinguish origin from bbox corner. Only this tested tower path adds real offset support; no new generic framework or false metadata marker. |

## Files, tests and exact blast radius

`candidate/` contains the three trial files; `baseline/` freezes the corresponding
final-selective files. `narrow-trial.patch` applies to that baseline only. `inputs.json`
records both hashes and refuses drift before fixture preparation. Do not apply this
patch directly to current HEAD or overwrite the final selective package. Integration
must deliberately compose the delta after reviewing the actual preview.

`LIBERTY-APPEND.md` supersedes L44's reconstructed diameter only, with Covers for
physical footprint and consumed diameter. Keep previous historical liberties and
source/date limits. `source-next-research.json` is the separate actual-publication
source upgrade, used in the fixture; it does not edit old sourceS or old source files.
The source remains public_domain/cross_check with explicit publication and dating
limits. No whole-building grade is typed and no camera enters accepted views.

Cheap checks already pass:

```sh
python3 /tmp/chicago-next-model/T-2373-narrow-trial/check_trial.py
node /tmp/chicago-next-model/T-2373-narrow-trial/check_contracts.mjs
```

Proofs cover all25 actual final-selective default parameter sets, full legacy16
positional constructions plus existing keyword options, all new fields keyword-only,
invalid dimensions/types/offsets, old tower/no-lantern face streams, near-square old
tolerance, unchanged non-tower helper ASTs, finite nondegenerate reconstructed trial
geometry, exact mesh/footprint bounds/centre, same-camera widths, and actual walker/
Show Me/feet consumers. Record schema and Python/shell syntax also pass. These are
not export, normals/materials, compressed derivative, full gate or match reviews.

Shared module bytes/new dataclass fields stale all25 fort recipes. Compared with
the final-selective proposal, intended changed geometry is ONLY this lighthouse;
compared with canonical pre-fort work, the original ten-master changed scope is
still ten. Every final family asset still needs its supported canonical25 refresh.
Do not restamp hashes or copy isolated registries/GLBs. The existing five UV-only
baseline differences remain documented in the older fort review.

## Prepared short preview runner — WAIT for parent slot

```sh
bash /tmp/chicago-next-model/T-2373-narrow-trial/run-preview.sh
```

This has NOT run. It will create new disposable1-ID baseline/proposed fixtures,
copy only read-only dependencies, overlay the frozen respective modules/record,
verify the cached pinned Blender archive and exact binary version, export the
single lighthouse in each fixture, and capture both from the exact same corrected
camera. It creates no canonical files. The runner stops on any export/browser
failure. GLB contracts check both masters afterwards. A1-ID fixture is not a full
town, final25-recipe refresh, derivative proof or historical camera solve.

After the slot is explicitly released, inspect the actual source|render pairs and
record widths, finial/floor, cap/cage, footing, normals/materials and remaining
differences. Keep both actual images and their asset/camera hashes; mark differs
until every visible requirement is actually reviewed and met. Only then decide
whether this radial trial belongs in the shared-control prerequisite or needs a
further profile revision. No matches verdict is justified by the calculations.
