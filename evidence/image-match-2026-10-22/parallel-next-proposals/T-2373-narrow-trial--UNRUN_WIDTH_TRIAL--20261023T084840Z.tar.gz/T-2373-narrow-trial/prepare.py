#!/usr/bin/env python3
"""One conditional diameter trial atop final selective fort payload; /tmp only."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,shutil
H=Path(__file__).resolve().parent
BASE=Path('/tmp/chicago-next-model/fort-selective-integration/staged/candidate')
rels=['chicago/4d/generators/archetypes/fort_structure_params.py','chicago/4d/generators/archetypes/fort_structure.py','chicago/4d/data/structures/chicago_lighthouse_1832.json']
texts={r:(BASE/r).read_text() for r in rels};before=dict(texts)
def replace(rel,old,new):
 assert texts[rel].count(old)==1,(rel,old[:70],texts[rel].count(old));texts[rel]=texts[rel].replace(old,new)
p,g,r=rels
replace(p,'    "cupola_height_m", "cupola_roof_pitch_deg",','    "cupola_height_m", "cupola_roof_pitch_deg", "tower_diameter_m",')
replace(p,'    # per-attribute confidence, keyed by the attribute name in the record\n','''    # Explicit narrow-tower trial: a physical diameter matching its shifted
    # footprint bounds, preserving the surveyed coordinate origin and centre.
    tower_diameter_m: float | None = field(default=None, kw_only=True)
    # Derived from the polygon, never independently authored form attributes.
    footprint_min_u_m: float = field(default=0.0, kw_only=True)
    footprint_min_v_m: float = field(default=0.0, kw_only=True)

    # per-attribute confidence, keyed by the attribute name in the record
''')
replace(p,'    def validate(self) -> None:\n','''    def validate(self) -> None:
        offsets = (self.footprint_min_u_m, self.footprint_min_v_m)
        if any(isinstance(v, bool) or not isinstance(v, (int, float)) or
               not math.isfinite(v) for v in offsets):
            raise ParamError("footprint offsets must be finite numbers")
        if self.tower_diameter_m is not None:
            diameter = self.tower_diameter_m
            if (isinstance(diameter, bool) or not isinstance(diameter, (int, float))
                    or not math.isfinite(diameter) or diameter <= 0):
                raise ParamError("tower_diameter_m must be a positive finite number")
            if self.kind != "tower":
                raise ParamError("tower_diameter_m is only valid on a tower")
            if (abs(diameter - self.width_m) > 1e-6 or
                    abs(diameter - self.depth_m) > 1e-6):
                raise ParamError("tower_diameter_m must match both physical footprint spans")
        elif any(abs(v) > 1e-6 for v in offsets):
            raise ParamError("offset polygon bounds require explicit tower_diameter_m")
''')
old='''    # The contract pins the mesh origin to polygon coordinate (0, 0); see the same
    # refusal in frame_tavern_params for the argument.
    if abs(min(xs)) > 1e-6 or abs(min(ys)) > 1e-6:
        raise ParamError(
            f"footprint polygon starts at ({min(xs)}, {min(ys)}), not the origin. "
            f"docs/GLB-CONTRACT.md pins the mesh origin to polygon coordinate (0, 0); "
            f"re-anchor the polygon and put the offset in position.")
'''
new='''    # GLB-CONTRACT pins the coordinate origin, not necessarily the bbox corner.
    # Existing builders assume min=0; only an explicitly dimensioned tower
    # resolves polygon offsets and actually uses them to preserve its centre.
    min_u, min_v = min(xs), min(ys)
    diameter = val("tower_diameter_m", None)
    if (abs(min_u) > 1e-6 or abs(min_v) > 1e-6) and not (
            str(val("kind", "quarters")) == "tower" and diameter is not None):
        raise ParamError(
            f"footprint polygon starts at ({min_u}, {min_v}), not the origin. "
            f"Only an explicit tower_diameter_m resolves this offset; other "
            f"builders require a zero-min polygon.")
'''
replace(p,old,new)
replace(p,'        confidence=confidences,','        tower_diameter_m=diameter,\n        footprint_min_u_m=min_u,\n        footprint_min_v_m=min_v,\n        confidence=confidences,')
# Change only the tower path, leaving other fort builders byte-identical.
tree=ast.parse(texts[g]);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_tower');lines=texts[g].splitlines(keepends=True);tower=''.join(lines[node.lineno-1:node.end_lineno]);changed=tower.replace('    r0 = p.width_m / 2.0\n','    r0 = (p.tower_diameter_m if p.tower_diameter_m is not None else p.width_m) / 2.0\n').replace('    cx, cy = r0, r0\n','    # Keep polygon-origin coordinates; narrowing the disk must not move its centre.\n    cx = p.footprint_min_u_m + p.width_m / 2.0\n    cy = p.footprint_min_v_m + p.width_m / 2.0\n')
changed=changed.replace('    c = p.worst_conf("kind", "wall_height_m", "construction")','    c = p.worst_conf("kind", "wall_height_m", "construction")\n    if p.tower_diameter_m is not None:\n        c = max(c, p.conf("tower_diameter_m"), p.conf("footprint"))')
assert changed!=tower;replace(g,tower,changed)
record=json.loads(texts[r]);ph=next(p for p in record['phases'] if p['id']=='tower_1832');ph['footprint']['polygon']=[[1.28,1.28],[4.32,1.28],[4.32,4.32],[1.28,4.32]]
ph['footprint']['note']="RECONSTRUCTED NARROW-TOWER TRIAL, not a measured plan. The former5.6m diameter was explicitly invented. A3.04m physical bounding square replaces it, shifted to local bounds[1.28,4.32] in each axis so that the mesh and polygon retain centre(2.8,2.8) relative to the UNCHANGED surveyed record origin. Position, bearing, dates and nominal12.19m height stay unchanged. Width was chosen conditionally from the square-pixel Castelnau framing study:shaft head24±3px and gallery floor31±3px at y88–90. The camera and40ft height datum remain unresolved, so this is a reconstructed metric trial, not a survey. The physical circle is still conservatively represented by its bounding square for collision/ground-contact/Show Me, as before; no5.6m invisible envelope is retained. L-lighthouse-narrow-trial-2373 owns the change."
ph['form']['tower_diameter_m']={'value':3.04,'confidence':'reconstructed','sources':['castelnau_1842_chicago_harbor'],'note':"Conditional visible-width trial, not an attested historic diameter. At the retained corrected square-pixel camera,3.04m predicts approximately24px shaft-head and32px gallery-floor widths, within the coarse24±3/31±3 controls. Taper.62 and gallery multiplier1.34 remain reconstructed. Shifted physical footprint bounds retain centre(2.8,2.8) and unchanged surveyed origin. Nominal12.19m(40ft rounded) remains unchanged; existing radius-dependent cap becomes shorter as a declared consequence, and whether40ft includes that cap remains unresolved. No image match is claimed. L-lighthouse-narrow-trial-2373."}
record['research_note']+=' NARROW-TOWER TRIAL: the prior5.6m shaft was reconstructed rather than attested. The opt-in3.04m diameter and shifted3.04m physical footprint preserve the old world centre and surveyed origin, and test the Castelnau width controls without pixel-aspect distortion. This does not resolve vertical profile, height datum, footing, finish or1835 continuity, and remains a research candidate until actual rendered review.'
texts[r]=json.dumps(record,ensure_ascii=False,indent=2)+'\n'
patch='';manifest=[]
for rel,text in texts.items():
 for kind,content in [('baseline',before[rel]),('candidate',text)]:
  dest=H/kind/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(content)
 if rel.endswith('.py'):compile(text,rel,'exec')
 patch+='diff --git a/'+rel+' b/'+rel+'\n'+''.join(difflib.unified_diff(before[rel].splitlines(keepends=True),text.splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel))
 manifest.append({'path':rel,'final_selective_baseline_sha256':hashlib.sha256(before[rel].encode()).hexdigest(),'trial_sha256':hashlib.sha256(text.encode()).hexdigest()})
(H/'narrow-trial.patch').write_text(patch);(H/'inputs.json').write_text(json.dumps({'baseline':'final fort-selective-integration staged payload, NOT current repository or old fort-combined previews','files':manifest,'repository_changed':False,'intended_changed_geometry_vs_final_selective':['chicago_lighthouse_1832'],'all25_fort_recipes_require_supported_final_bake':True},indent=2)+'\n')
shutil.copy2('/tmp/chicago-next-model/T-2373-camera-audit/camera-corrected-controls-diagnostic.json',H/'camera-same-framing.json')
shutil.copy2('/tmp/chicago-next-model/T-2373-camera-audit/castelnau-source-next-research.json',H/'source-next-research.json')
print('Prepared3-file width/origin trial under/tmp, no repository writes')
