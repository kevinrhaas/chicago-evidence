"""Focused actual raw contracts. No Blender/browser, gate or canonical writes."""
from pathlib import Path
from types import ModuleType
from dataclasses import asdict,replace
import ast,copy,hashlib,inspect,json,math,re,sys
sys.dont_write_bytecode=True
O=Path(sys.argv[1]).resolve();B=O/'baseline/chicago/4d';N=O/'review-tree/chicago/4d'
sys.path.insert(0,str(B/'generators'));sys.modules['bpy']=ModuleType('bpy')
def load(name,p):
 m=ModuleType(name);m.__file__=str(p);sys.modules[name]=m;exec(compile(p.read_text(),str(p),'exec'),m.__dict__);return m
old=load('log81_old',B/'generators/archetypes/log_dwelling_params.py');new=load('log81_new',N/'generators/archetypes/log_dwelling_params.py')
sys.modules['archetypes.log_dwelling_params']=old;before=load('log81_before',B/'generators/archetypes/log_dwelling.py')
sys.modules['archetypes.log_dwelling_params']=new;after=load('log81_after',N/'generators/archetypes/log_dwelling.py')
from common.mesh import MeshBuilder
class Raw(MeshBuilder):
 def to_object(self,mats=None):self.materials=mats;return self
for m in [before,after]:m.MeshBuilder=Raw;m.simple_material=lambda *a,**kw:(a,kw)
def raw(b):return (b.verts,b.faces,b.conf,b.mat_index,b.named,b.materials)
extra={'compound_parts':(),'roof_ridge_axis':None,'frame_addition_cladding':'clapboard','front_door_state':'closed'}
old_sig=inspect.signature(old.LogDwellingParams);new_sig=inspect.signature(new.LogDwellingParams)
assert [v for k,v in new_sig.parameters.items() if k not in extra]==list(old_sig.parameters.values())
assert all(new_sig.parameters[k].kind==inspect.Parameter.KEYWORD_ONLY for k in extra)
assert old.CONSUMED<=new.CONSUMED and set(new.END_OPENING_KINDS)==set(old.END_OPENING_KINDS)|{'hatch'}
scope=json.loads((O/'freshness-scope.json').read_text());defaults=[];changed=[];selected={};original={}
for row in scope['assets']:
 sid=row['structure_id'];r=json.loads((B/f'data/structures/{sid}.json').read_text());original[sid]=r
 ph=next(p for p in r['phases'] if p['id']==row['phase_id']);a=old.from_phase(ph,r);b=new.from_phase(ph,r);d=asdict(b)
 for k,v in extra.items():assert d.pop(k)==v
 assert d==asdict(a)
 name=Path(row['asset']).stem;x,y=before.build(a,name),after.build(b,name);assert raw(x)==raw(y),row['asset']
 defaults.append({'asset':row['asset'],'raw_sha256':hashlib.sha256(json.dumps(raw(y),sort_keys=True).encode()).hexdigest()})
 target=json.loads((N/f'data/structures/{sid}.json').read_text());tp=next(p for p in target['phases'] if p['id']==row['phase_id']);p=new.from_phase(tp,target);z=after.build(p,name)
 if raw(z)!=raw(x):changed.append(sid);selected[sid]=(target,p,z)
 for key in ['position','documented_range','existence','use','occupants']:assert tp.get(key)==ph.get(key),(sid,key)
 assert tp['footprint']['polygon']==ph['footprint']['polygon']
assert len(defaults)==81 and sorted(changed)==sorted(scope['intended_geometry_changes']) and len(changed)==6
# Second boundary: the Hogan overlay must preserve the five future opt-ins.
midroot=Path(__file__).resolve().parent/'proposal-inputs/T-2377-continuation/before/chicago/4d'
midparams=load('log81_mid_params',midroot/'generators/archetypes/log_dwelling_params.py');sys.modules['archetypes.log_dwelling_params']=midparams
mid=load('log81_mid',midroot/'generators/archetypes/log_dwelling.py');mid.MeshBuilder=Raw;mid.simple_material=lambda *a,**kw:(a,kw)
sys.modules['archetypes.log_dwelling_params']=new
for row in scope['assets']:
 sid=row['structure_id'];r=json.loads((N/f'data/structures/{sid}.json').read_text()) if sid!='hogan_store' else original[sid];ph=next(p for p in r['phases'] if p['id']==row['phase_id']);name=Path(row['asset']).stem
 assert raw(mid.build(midparams.from_phase(ph,r),name))==raw(after.build(new.from_phase(ph,r),name)),sid+' changed under disabled Hogan overlay'
for sid,(r,p,obj) in selected.items():
 assert all(math.isfinite(v) for pt in obj.verts for v in pt)
 for face in obj.faces:
  pts=[obj.verts[i] for i in face];n=[0.,0.,0.]
  for a,b in zip(pts,pts[1:]+pts[:1]):
   for k in range(3):i,j=(k+1)%3,(k+2)%3;n[k]+=(a[i]-b[i])*(a[j]+b[j])
  assert sum(v*v for v in n)>1e-16,sid+' degenerate face'
school=selected['chappel_infant_school'][1];castle=selected['cobweb_castle'][1];miller=selected['miller_house'][1];hogan=selected['hogan_store'][1]
assert new.resolved_core_ridge_axis(school)=='y' and school.window_w_m==.85
assert len(castle.compound_parts)==5 and set(selected['cobweb_castle'][2].conf)=={1.}
assert new.front_wall(castle)['u0']==4 and new.front_wall(castle)['u1']==9
assert miller.frame_addition_cladding=='log_lower_vertical_upper'
assert hogan.front_door_state=='recess' and hogan.end_openings==(('+x','hatch',.5,3.35),) and hogan.ridge_stack_head_m==.75
invalid=[replace(castle,roof_ridge_axis='x'),replace(castle,roof_ridge_axis='y'),replace(castle,piazza=True),replace(castle,stories=2),replace(castle,compound_parts=castle.compound_parts+(castle.compound_parts[0],)),replace(school,roof_ridge_axis='z'),replace(school,roof_type='shed'),replace(school,lean_to=True),replace(school,hip_end='min'),replace(school,end_openings=(('+x','window',.5,None),)),replace(school,chimney_end='max'),replace(miller,frame_addition=False),replace(miller,frame_addition_stories=1),replace(miller,frame_addition_cladding='unknown'),replace(hogan,front_door_state='open'),replace(hogan,front_set_out=None),replace(hogan,stories=2),replace(hogan,frame_addition=True),replace(hogan,end_openings=(('+x','hatch',.5,None),)),replace(hogan,end_openings=(('+x','hatch',.5,2.5),))]
for p in invalid:
 try:p.validate()
 except new.ParamError:pass
 else:raise AssertionError('invalid combined feature accepted')
# Actual clipping/hatch invariants from the continuation, in the final composed module.
p=hogan;_,u0,u1,z0,z1=next(r for r in new.core_front_rects(p) if r[0]=='door');wall_y=new.core_extent(p)[3]
wall=Raw('wall');after.hewn_log_wall(wall,*new.core_extent(p),0.,p.wall_height_m,.5,after.M_LOG,after.M_CHINK,skip=('bottom','top'));after._cut_front_door_recess(wall,p,wall_y)
def contains(poly,x,z):
 inside=False
 for a,b in zip(poly,poly[1:]+poly[:1]):
  if (a[2]>z)!=(b[2]>z) and x<(b[0]-a[0])*(z-a[2])/(b[2]-a[2])+a[0]:inside=not inside
 return inside
samples=[(u0+(u1-u0)*fx,z0+(z1-z0)*fz) for fx in [.1,.5,.9] for fz in [.1,.3,.5,.7,.9]]
for f in wall.faces:
 poly=[wall.verts[i] for i in f]
 if all(v[1]>=wall_y-1e-9 for v in poly):assert not any(contains(poly,x,z) for x,z in samples),'wall/chink still covers recess'
kit=Raw('recess');after._opening(kit,'y',wall_y,u0,u1,z0,z1,1,1.,kind='door',door_state='recess')
back=[f for f,m in zip(kit.faces,kit.mat_index) if m==after.M_DARK];assert len(back)==1 and all(abs(kit.verts[i][1]-(wall_y-.3))<1e-9 for i in back[0])
hatch=Raw('hatch');after._end_openings(hatch,p,*new.core_extent(p),p.wall_height_m);assert hatch.NAMED_BASE+hatch.named['glass'][0] not in hatch.mat_index and set(hatch.conf)=={1.}
# Real liberty parser, actual coverage routines extracted without whole-tree imports.
sys.path.insert(0,str(B/'tools'));cl=load('log81_liberties',B/'tools/compile_liberties.py')
entries,problems=cl.parse('## Per-subject liberties\n\n'+(O/'liberty-append.md').read_text(),{sid:r[0]['name'] for sid,r in selected.items()},sources={})
assert not problems,problems
assert all(e['subjects'] for e in entries),'new liberty missing card subject'
tree=ast.parse((B/'tools/validate.py').read_text());wanted={'Report','graded_values','inferred_values','unbuilt_values','check_liberties_coverage'}
nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in wanted]
ns={'PHASE_ASPECTS':('footprint','position','documented_range'),'STRUCTURE_ASPECTS':('function','occupants','present_status','built'),'GEOMETRY_OWES_LIBERTY':('absent','simplified')}
exec(compile(ast.Module(body=nodes,type_ignores=[]),'actual_coverage_routines','exec'),ns)
existing=json.loads((B/'data/liberties.json').read_text());existing['liberties']+=entries;rep=ns['Report']();ns['check_liberties_coverage']({sid:r[0] for sid,r in selected.items()},existing,rep,{'log_dwelling':new.CONSUMED},forward_only=True);assert not rep.errors,rep.errors
# No new over-claims: inferred consumed categories aren't invented numeric values.
for e in entries:
 for c in e['covers']:
  r=selected[c['structure']][0];block=next(p for p in r['phases'] if p['id']==c['phase'])
  for key in c['aspect'].split('.'):block=block[key]
  assert block.get('confidence')=='reconstructed' or block.get('geometry') in ('absent','simplified') and block.get('value'),(e['id'],c)
import jsonschema
for r,p,obj in selected.values():jsonschema.validate(r,json.loads((B/'data/structures.schema.json').read_text()))
for sid in ['eliza_chappel_school_shore_view','blanchard_shober_1867_wolf_point']:
 d=json.loads((N/f'data/sources/{sid}.json').read_text());jsonschema.validate(d,json.loads((B/'data/source.schema.json').read_text()));assert d['rights_status'] in ('cleared','public_domain')
before=json.loads((B/'data/structure_grades.json').read_text());aftergrades=json.loads((N/'data/structure_grades.json').read_text());assert all(row in aftergrades['pictured'] for row in before['pictured'])
for key in set(before)-{'pictured'}:assert before[key]==aftergrades[key]
for sid in ['cameron_c1900_first_post_office','andreas_1884_sauganash_hotel_plate']:
 assert (B/f'data/sources/{sid}.json').read_bytes()==(N/f'data/sources/{sid}.json').read_bytes()
schoolsource=json.loads((B/'data/sources/eliza_chappel_school_shore_view.json').read_text());schoolafter=json.loads((N/'data/sources/eliza_chappel_school_shore_view.json').read_text())
for key in set(schoolsource)-{'note','what_it_supplies'}:assert schoolsource[key]==schoolafter[key]
pool=json.loads((N/'data/reconstruction/name_pool_keys.json').read_text());declared=set(pool['read']['structures'])|set(pool['ignored']['structures'])
def leaves(v,path=''):
 if isinstance(v,dict):
  for key,item in v.items():yield from leaves(item,path+'.'+key if path else key)
 elif isinstance(v,list):
  for item in v:yield from leaves(item,path+'[]')
 elif isinstance(v,str):yield path,v
assert all(path in declared for r,p,obj in selected.values() for path,value in leaves(r) if re.search(r'\b[A-Z][a-z]{2,}\b',value))
report={'status':'passed','current_default_official_key_raw_parity':len(defaults),'hogan_overlay_future_five_optins_parity':81,'new_fields_keyword_only':list(extra),'invalid_guards_rejected':len(invalid),'actual_changed_optin_records':changed,'new_liberties_parsed':len(entries),'new_liberty_covers':sum(len(e['covers']) for e in entries),'actual_forward_coverage_notes':rep.notes,'sourceS_grade_rows_and_Hogan_sources_preserved':True,'new_name_pool_paths_declared':True,'schemas_passed':True,'defaults':defaults,'limits':'Light copied-module/raw contracts only. No current combined export/bake, derivatives, source-card/app QA, full gate or accepted image match. One future code+visible-data PR, six original cases stay open.'}
# The materializer must preserve independent present-day Hogan edits and refuse
# a coupled opening change rather than silently restoring the old snapshot.
tree=ast.parse((Path(__file__).resolve().parent/'materialize.py').read_text());func=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='delta');ns={'copy':copy,'MISSING':object()};exec(compile(ast.Module(body=[func],type_ignores=[]),'actual_selective_delta','exec'),ns)
parcel=Path(__file__).resolve().parent/'proposal-inputs/T-2377-continuation';a=json.loads((parcel/'before/chicago/4d/data/structures/hogan_store.json').read_text());b=json.loads((parcel/'candidate/chicago/4d/data/structures/hogan_store.json').read_text())
cur=copy.deepcopy(a);cur['research_note']+=' Independent current research retained.';cur['phases'][0]['form']['door_w_m']['value']=1.55;cur['phases'][0]['form']['door_w_m']['note']+=' Independent present width choice.'
merged=ns['delta'](cur,a,b,'hogan_store');assert merged['research_note']==cur['research_note'] and merged['phases'][0]['form']['door_w_m']==cur['phases'][0]['form']['door_w_m'];assert merged['phases'][0]['form']['front_door_state']['value']=='recess'
bad=copy.deepcopy(a);bad['phases'][0]['form']['end_openings']['value'][0]['z']=3.4
try:ns['delta'](bad,a,b,'hogan_store')
except ValueError:pass
else:raise AssertionError('independent coupled opening overwritten')
report['selective_preservation_and_overlap_refusal']=True
assert ns['delta']('Original history. New independent source research.','Original history.','New use ledger. Original history. Roof scope.','source.note')=='New use ledger. Original history. New independent source research. Roof scope.'
assert ns['delta'](['nothing yet','independent source fact'],['nothing yet'],['new declared reference use'],'source.what_it_supplies')==['new declared reference use','independent source fact']
report['independent_source_note_and_supply_preservation']=True
(O/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='defaults'},indent=2))
