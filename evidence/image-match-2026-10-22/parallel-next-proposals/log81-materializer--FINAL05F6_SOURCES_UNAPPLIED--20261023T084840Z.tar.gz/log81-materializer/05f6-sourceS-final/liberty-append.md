### L-school-pictured-openings-roof-2372 — provisional doorway gable and higher lights

**Decision:** The owner-approved attributed school-shore reproduction guides a reconstructed
doorway-gable roof direction and opening treatment without identifying its subject
as this school or establishing original copyright/publication or a July 1835 state.
The existing footprint, 90-degree placement and 35-degree pitch remain. Sash
0.85 m square, doorway 1.20 m wide with 2.05 m clear height, common 2.07 m head,
rounded inherited front centres, no external front shutters and a local-Y core
ridge are chosen model dimensions/directions. The unseen rear light follows the
same new band; roof, loft/gable classification and rear stack follow one declared
axis. These are not metric evidence. The former eave-front roof assumption is
superseded only for this record. Open door state, covering, massing/proportions,
subject identity, historical function and camera remain unresolved; T-2372 stays
open. The source credit, URL and project-specific owner clearance are retained,
without claiming public domain or copyright-holder permission.
**Covers:** `chappel_infant_school.log_1833.form.front_set_out`, `chappel_infant_school.log_1833.form.window_w_m`, `chappel_infant_school.log_1833.form.window_h_m`, `chappel_infant_school.log_1833.form.door_w_m`, `chappel_infant_school.log_1833.form.door_h_m`, `chappel_infant_school.log_1833.form.roof_ridge_axis`, `chappel_infant_school.log_1833.form.front_shutters`.
**Ticket:** T-2372.
**Recorded:** 2026-10-23.


### L-cobweb-compound-2374 — five log rooms instead of one bounding box

**What was done:** Cobweb Castle opts into compound_parts, partitioning its existing
reconstructed 20-vertex footprint into a centre, two wings and two rear tails.
Existing placement, polygon, nominal eave, pitch, finishes and inferred two-stack
count stay unchanged. Orthogonal gables replace the single bounding-box roof.
**Evidence:** Wau-Bun (kinzie_waubun_1856) describes the 1831 composition and an
"odd-shaped roof". It establishes neither dimensions nor the precise roof layout.
**Chosen:** every room dimension remains the old footprint's invention. Equal
2.6 m eaves, ridge directions, wing roofs extended to the centre ridge, overlapping
roof surfaces rather than detailed valleys, a centred front door and one window on
each wing, and stacks against the outer wing ends are reconstructed. Shared room
walls remain internal geometry; no interior, exact junction joinery or clapboarding
is recovered. New compound faces carry reconstructed confidence. Partial siding
remains simplified and its presence by July 1835 uncertain.
**Limits:** the phase applies the 1831 form back to 1820 and infers survival to
July 1835; neither issue is resolved. The later Wau-Bun panorama remains an
uncalibrated comparison whose tiny agency-house subject needs positive identification.
This is a text-bounded first massing increment, not a picture match. After a pinned
bake, compare the actual silhouette, roof junctions, openings and finishes and keep
T-2374 open until its acceptance is demonstrated.
**Recorded:** 2026-10-23.
**Covers:** `cobweb_castle.log_1820.form.plan_composition`, `cobweb_castle.log_1820.form.roof_type`, `cobweb_castle.log_1820.form.compound_parts`, `cobweb_castle.log_1820.footprint`.


### L-miller-mixed-cladding-2381 — logs below, vertical boards above

**What is read:** the tall Miller House at the right of `blanchard_shober_1867_wolf_point`, inspected as the NYPL lithograph `chicago/reference/images/chicago/chicago_wolf_point_1833_nypl.jpg`. Its ground storey is drawn as horizontal log courses, its upper storey and gable as vertical boards. The sharper Colbert reproduction and the1892 Blanchard chromolithograph repeat that general mixed treatment; retrospective agreement is not promoted to a contemporary construction record. The earlier inference that 'partly sided' meant horizontal clapboard on both storeys is superseded by the actual depicted form.
**What is reconstructed:** the retained5.2 m addition height is split at its2.6 m midpoint for the lower/upper cladding break. Lower walls use the existing hewn-log/chinking/notching kit; upper walls retain the existing unpainted frame material but receive vertical board-edge relief. The nominal0.24 m board rhythm,0.012 m-wide edges,0.012 m wall relief,0.004 m gable face separation and plain joint representation are modelling choices, not historic board dimensions or evidence for a particular board-and-batten joint. Both unseen rear surfaces follow the same reconstructed finish. The gable overlays are on the roof builder's0.25 m overhang plane so they remain visible rather than hidden behind the old roof-material triangles; that is the existing roof's graphical convention, not an altered footprint. Source courses, board count, texture/tone and exact joinery are not completely reproduced.
**What remains:** the low cabin is still behind the main block rather than alongside as in the clearest pictures; the main upper front still has two windows instead of the pictured three; exterior chimneys are not the pictured ridge stack; glazing/doors, camera and roof/material details remain open. Existing coordinates, footprint, documented range, identities and uses have not been changed. The retrospective1833 scene does not prove an unchanged1 July1835 state.
**How to resolve:** perform the pinned family rebuild and actual same-camera before/after comparison, then refine the remaining composition, openings, chimney and material differences against all listed pictures. This first visible finish correction is not a completed image match.
**Covers:** `miller_house.log_frame_1827.form.cladding`.
**Ticket:** T-2381.

**Revision:** Combined confidence ruling: wall/gable finish category faces remain inferred; chosen narrow board-edge sections and rhythm emit reconstructed confidence (1.0).
**Recorded:** 2026-10-23.


### L-carpenter-pictured-sash-2382 — upright sash on the Sauganash's log annex

**What is read:** `andreas_1884_sauganash_hotel_plate`, the public-domain Braunhold engraving inspected as `chicago/reference/images/chicago/chicago_sauganash_hotel_1831.jpg`. The cabin already identified by `drloih_beaubien` as Carpenter's former shop has a doorway between two tall, bare sash, their heads approximately aligned. The Petford and Trowbridge copies are not independent corroboration. The retrospective picture bounds appearance, not geographic coordinates or proof of the cabin's use/survival on 1 July 1835.
**What is reconstructed:** 0.70 m sash width and 1.40 m height under the retained 1.95 m door head, making the sill 0.55 m and the sash proportion 2:1 rather than the former generic almost-square 0.62 by 0.72 m light. Opening centres remain the archetype's former 28-percent flank rule on the retained attested 6.096 m frontage: 1.341, 3.048 and 4.755 m, rounded to millimetres. These are provisional model dimensions/stations, not measurements from a solved camera. The existing archetype propagates the sash band to its unseen rear light; that height and the rear's narrower default width are reconstructed. Default glazing divisions remain a proxy and do not reproduce every drawn muntin. The end-wall chimney, roof, logs and material tones remain under their earlier bounds and still differ from the picture.
**How to resolve:** fit a joint Sauganash/annex review camera, rebuild the annex, compare the actual before/after GLBs with the original engraving and both derivative pictures, then iterate on all remaining visible differences. No completed image match or T-2382 closure is claimed by these data changes.
**Covers:** `philo_carpenter_log_shop.log_1832.form.front_set_out`, `philo_carpenter_log_shop.log_1832.form.window_w_m`, `philo_carpenter_log_shop.log_1832.form.window_h_m`, `philo_carpenter_log_shop.log_1832.form.chimney_ridge_at`, `philo_carpenter_log_shop.log_1832.form.ridge_stack_w_m`, `philo_carpenter_log_shop.log_1832.form.ridge_stack_head_m`.
**Ticket:** T-2382.

**Revision:** T-2382 next increment below supersedes this first entry’s generic end-stack description.
**Recorded:** 2026-10-23.


### L-carpenter-pictured-stack-2382 — the annex's roof-piercing chimney

**What is read:** the annex chimney in `andreas_1884_sauganash_hotel_plate`, inspected as the committed Braunhold engraving `chicago/reference/images/chicago/chicago_sauganash_hotel_1831.jpg`. One small shaft breaks the roof near the cabin's exposed outer gable. The cabin is the existing `drloih_beaubien` caption identification, and the hotel/cabin placement has not been rederived from the drawing.
**What is reconstructed:** a ridge station of 0.80 on the existing 6.096 m cabin frontage, 4.8768 m from minimum-u and 1.2192 m short of the exposed local +x gable; a square 0.55 m shaft; and a head 0.65 m over the ridge. The roof-piercing disposition is pictured; those exact dimensions and station are first comparison choices requiring actual paired review, not a solved camera or measurements of the historical chimney. The existing ridge-stack builder supplies plain sides and its existing embedded foot. Its hardcoded stick-and-clay tone remains an unresolved proxy for the picture's masonry stack. No geographic position, footprint, scene date, use or occupancy changes.
**How to resolve:** render the rebuilt cabin and compare its chimney against the full original sheet using the same before/after camera; refine the shaft station, silhouette, head/cap and masonry treatment. Inspect the Petford/Trowbridge derivatives separately while preserving the Braunhold governing-sheet choice. This increment does not claim the annex or hotel matches the picture.
**Covers:** `philo_carpenter_log_shop.log_1832.form.chimney_ridge_at`, `philo_carpenter_log_shop.log_1832.form.ridge_stack_w_m`, `philo_carpenter_log_shop.log_1832.form.ridge_stack_head_m`.
**Ticket:** T-2382.
**Recorded:** 2026-10-23.


### L-wolf-point-pictured-stack-2386 — smaller roof-piercing head

**Decision:** The 1867 Blanchard/Shober lithograph depicting 1833 draws a head through the tavern
roof rather than the former full-height exterior gable stack. This is an inferred
disposition from a retrospective picture, not a dated 1835 construction record.
Exact core ridge station 0.58, 0.45 m square shaft and 0.50 m head rise are
reconstructed first-comparison choices. The original one-stack count, coordinates,
footprint, dimensions, roof pitch and use remain. The separate slender pipe,
parallel-gable massing, second entrance and camera remain unresolved; T-2386 is open.
**Covers:** `wolf_point_tavern.log_frame_1828.form.chimney_ridge_at`, `wolf_point_tavern.log_frame_1828.form.ridge_stack_w_m`, `wolf_point_tavern.log_frame_1828.form.ridge_stack_head_m`.
**Ticket:** T-2386.
**Recorded:** 2026-10-23.


### L-miller-visible-joints-2381 — readable vertical joint cues

**Decision:** The first actual neutral review showed that same-material 12 mm edges with
12 mm relief were effectively invisible. This supersedes those first-proposal
sections only: joint proxies now use 24 mm width, 4 mm relief and the existing
darker log material, retaining nominal 0.24 m board rhythm and every room, roof,
opening, cladding break and surveyed placement. Broad wall/gable finish faces
remain inferred; chosen contrast-strip geometry remains reconstructed (1.0).
The source supports vertical boards and their visible joint rhythm, not these
exact widths, relief, colour, board gaps or an applied board-and-batten joint.
This is a readable joint depiction, not a measured physical gap or paint claim.
Unseen surfaces inherit the reconstructed treatment. Existing palette slots are
reused; no new material is introduced. Same-camera export/review must demonstrate
that the joints read while source textures, three upper windows, ridge stack,
side-cabin arrangement and camera remain open differences. T-2381 stays open.

**Recorded:** 2026-10-23.
**Building:** Miller House.


### L-hogan-pictured-recess-hatch-2377 — pictured doorway and unresolved gable closure

**Decision:** Source: `cameron_c1900_first_post_office`, Edgar S. Cameron's retrospective *Chicago's First Postoffice in 1833*, halftone credited to the Chicago Historical Society. The local surrogate and printed caption were inspected. The committed inventory attributes public-domain status to pre-1930 publication; original publication and holding remain independently unverified, and the failed Commons access is not fresh clearance. This continuation preserves those limits and the existing source credit.

The picture's long elevation has a dark doorway occupied by a figure. The opt-in `front_door_state: recess` cuts the actual front skin/chinking and uses framed returns to a dark blind back 0.30 m inside. That depth, casing dimensions and dark material are reconstructed visual proxies, not measured joinery, an interior, a surviving July 1835 door state, or an attested leaf/hinge position. No figure is inserted or identified. Generic doors remain closed without this option.

The visible gable rectangle is trialled as `end_openings.kind: hatch` at the existing reconstructed station and 0.7 × 0.8 m size. The existing board-shutter kit provides a closure proxy. Boards, ledges, material, closure and absence of glass are not attested by the unresolved infill; the depiction is explicitly reconstructed. It adds no loft occupancy or unseen opening. The existing ridge-stack head control is trialled at 0.75 m rather than the generic 0.95 m to bound the short depicted silhouette, without claiming scale, cap detail or material identification.

The documented 45 × 20 ft footprint, geographic position, bearing, dates, use, eave, roof pitch, opening stations/sizes and chimney station/width remain unchanged. No image pixels become a texture. Roof texture/tone, gable cladding, sash pattern, chimney details, source perspective and omitted scene remain unresolved. The original image gate stays open and the provisional view remains `differs`; this proposal is not a match ruling.
**Recorded:** 2026-10-23.
**Covers:** `hogan_store.log_1831.form.end_openings`, `hogan_store.log_1831.form.ridge_stack_w_m`, `hogan_store.log_1831.form.front_door_state`, `hogan_store.log_1831.form.ridge_stack_head_m`.
