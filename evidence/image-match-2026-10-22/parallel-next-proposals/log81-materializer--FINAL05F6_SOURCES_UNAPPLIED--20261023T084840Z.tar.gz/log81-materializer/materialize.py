"""Selective integration preparation. Writes only a new /tmp output tree."""
from pathlib import Path
import argparse,ast,copy,difflib,hashlib,json,re,shutil,subprocess
HERE=Path(__file__).resolve().parent;P=HERE/'proposal-inputs'
args=argparse.ArgumentParser();args.add_argument('--checkout',default='/workspace/chicago');args.add_argument('--output',required=True);a=args.parse_args()
repo=Path(a.checkout).resolve();app=repo/'chicago/4d';out=Path(a.output).resolve()
assert out.is_relative_to(Path('/tmp')) and not out.exists(),'use a NEW /tmp output directory'
out.mkdir(parents=True);baseline=out/'baseline/chicago/4d';candidate=out/'candidate/chicago/4d';inputs={};changes={};ops=[];preserved=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
for rel,want in json.loads((HERE/'proposal-inputs.json').read_text()).items():assert sha(P/rel)==want,'frozen proposal input changed: '+rel
def read(rel):
 p=app/rel;inputs[rel]=sha(p)
 if p.exists():
  q=baseline/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 return p.read_text() if p.exists() else ''
def get(rel):return json.loads(read(rel))
def put(rel,text):
 if rel not in inputs:read(rel)
 target=candidate/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
 before=(baseline/rel).read_text() if (baseline/rel).exists() else ''
 if text!=before:changes[rel]=text
def putjson(rel,obj):put(rel,json.dumps(obj,indent=2,ensure_ascii=True)+'\n')
MISSING=object()
def delta(cur,old,new,path=''):
 if old==new:return copy.deepcopy(cur)
 if old is MISSING:
  if cur is MISSING:return copy.deepcopy(new)
  if cur==new:return copy.deepcopy(cur)
  raise ValueError('new field already has independent value: '+path)
 if new is MISSING:
  if cur!=old:raise ValueError('independent deletion overlap: '+path)
  return MISSING
 if cur==old or cur==new:return copy.deepcopy(new)
 if isinstance(old,dict) and isinstance(new,dict) and isinstance(cur,dict):
  result=copy.deepcopy(cur)
  for key in sorted(set(old)|set(new)):
   before=old.get(key,MISSING);after=new.get(key,MISSING)
   if before==after:continue
   if key=='note' and old.get('value',MISSING)!=cur.get('value',MISSING):
    raise ValueError('note depends on a changed value: '+path)
   value=delta(cur.get(key,MISSING),before,after,path+'.'+key)
   if value is MISSING:result.pop(key,None)
   else:result[key]=value
  return result
 if path.endswith('.phases') and all(isinstance(v,list) for v in [cur,old,new]):
  assert all(isinstance(item,dict) and 'id' in item for seq in [cur,old,new] for item in seq),'phase ids required'
  om={v['id']:v for v in old};nm={v['id']:v for v in new};cm={v['id']:v for v in cur};result=[]
  for pid in dict.fromkeys([v['id'] for v in cur]+[v['id'] for v in new]):
   value=delta(cm.get(pid,MISSING),om.get(pid,MISSING),nm.get(pid,MISSING),path+'.'+pid)
   if value is not MISSING:result.append(value)
  return result
 if isinstance(old,str) and isinstance(new,str) and isinstance(cur,str) and new.startswith(old):
  tail=new[len(old):]
  return cur if tail in cur else cur+tail
 if isinstance(old,str) and old and isinstance(new,str) and isinstance(cur,str) and old in new:
  prefix,suffix=new.split(old,1);result=cur
  if prefix and prefix not in result:result=prefix+result
  if suffix and suffix not in result:result+=suffix
  return result
 if path.endswith(('.sources','.what_it_supplies','.what_it_does_not_supply')) and all(isinstance(v,list) for v in [cur,old,new]):
  return copy.deepcopy(new+[item for item in cur if item not in old and item not in new])
 raise ValueError('independent semantic overlap, review instead of restoring snapshot: '+path)
def apply_record(sid,old,new,stage):
 rel=f'data/structures/{sid}.json'
 cur=records[sid];records[sid]=delta(cur,old,new,sid);ops.append({'stage':stage,'record':sid})
def j(p):return json.loads(p.read_text())
# Freeze actual current log-family records; sources/grades and unrelated sourceS records
# are never restored from a prior complete tree.
records={};original={}
for path in sorted((app/'data/structures').glob('*.json')):
 r=json.loads(path.read_text())
 if r.get('archetype')=='log_dwelling':original[r['id']]=get(f'data/structures/{r["id"]}.json');records[r['id']]=copy.deepcopy(original[r['id']])
alternates=[sid for sid in records if (app/f'data/structures/versions/{sid}').exists()]
assert not alternates,'selected alternate versions require explicit scope review: '+str(alternates)
oldroot=P/'log-combined/runs/20261023-050224-069556/baseline';combined=P/'log-combined/candidate/chicago/4d';boarding=P/'log-combined/boarding-refinement/candidate/chicago/4d';hogan=P/'T-2377-continuation'
five=['chappel_infant_school','cobweb_castle','miller_house','philo_carpenter_log_shop','wolf_point_tavern'];targets=five+['hogan_store']
for sid in five:apply_record(sid,j(oldroot/f'data/structures/{sid}.json'),j(combined/f'data/structures/{sid}.json'),'log-combined')
apply_record('miller_house',j(combined/'data/structures/miller_house.json'),j(boarding/'data/structures/miller_house.json'),'visible-boarding')
apply_record('hogan_store',j(hogan/'before/chicago/4d/data/structures/hogan_store.json'),j(hogan/'candidate/chicago/4d/data/structures/hogan_store.json'),'final-hogan-three-file-overlay')
for sid in targets:putjson(f'data/structures/{sid}.json',records[sid])
for name in ['log_dwelling.py','log_dwelling_params.py']:
 rel=f'generators/archetypes/{name}';cur=read(rel);old=(oldroot/rel).read_text();final=(hogan/'candidate/chicago/4d'/rel).read_text()
 assert (hogan/'before/chicago/4d'/rel).read_text()==(boarding/rel).read_text(),'Hogan overlay order/base changed'
 work=out/'merge';work.mkdir(exist_ok=True)
 paths=[]
 for label,text in [('current',cur),('old-base',old),('ordered-final',final)]:
  p=work/f'{name}.{label}';p.write_text(text);paths.append(str(p))
 result=subprocess.run(['git','merge-file','-p',*paths],capture_output=True,text=True)
 if result.returncode:raise ValueError(f'{rel}: manual code overlap, no wholesale snapshot restoration\n'+result.stdout)
 ast.parse(result.stdout);put(rel,result.stdout)
# Source edits: school delta only, with rights and credit fields left untouched.
rel='data/sources/eliza_chappel_school_shore_view.json';cur=get(rel)
# Recover the original source by reversing only its complete original unified-diff
# section in a private tree; the frozen render baseline intentionally carried the
# reference-use source and is therefore not a historical source-record baseline.
patch=(P/'log-combined/log-combined.patch').read_text();sections=re.split(r'(?=^--- (?:a/|/dev/null))',patch,flags=re.M)
source_section=next(s for s in sections if re.search(r'^\+\+\+ b/chicago/4d/'+re.escape(rel)+r'$',s,re.M))
recover=out/'source-recovery';p=recover/'chicago/4d'/rel;p.parent.mkdir(parents=True);p.write_text((combined/rel).read_text())
subprocess.run(['git','apply','--reverse','-'],cwd=recover,input=source_section,text=True,check=True,capture_output=True)
old=j(p);new=j(combined/rel);source=delta(cur,old,new,rel)
for key in ['citation','author','url','rights_status','rights_checked','rights_note','verified']:assert source.get(key)==cur.get(key),'school clearance/credit changed'
putjson(rel,source)
rel='data/sources/blanchard_shober_1867_wolf_point.json';text=read(rel);desired=j(combined/rel)
if not text:source=desired
else:
 source=json.loads(text);assert source['id']==desired['id']
 for key in ['note','what_it_supplies','what_it_does_not_supply']:
  if key=='note':
   if desired[key] not in source.get(key,''):source[key]=source.get(key,'')+' '+desired[key]
  else:source[key]=source.get(key,[])+[v for v in desired.get(key,[]) if v not in source.get(key,[])]
 for key in set(source)-{'note','what_it_supplies','what_it_does_not_supply'}:
  if source.get(key)!=desired.get(key):preserved.append({'source':desired['id'],'field':key,'decision':'current independent metadata preserved'})
putjson(rel,source)
# Preserve the sourceS/Hogan grade register; append only three reviewed picture rows.
rel='data/structure_grades.json';grades=get(rel);proposed=j(P/'log-combined/proposed-grade-rulings.json')
for row in proposed['pictured']:
 existing=next((v for v in grades['pictured'] if all(v.get(k)==row[k] for k in ['scene','structure','picture'])),None)
 if not existing:grades['pictured'].append(row)
putjson(rel,grades)
# Retain all existing name-pool policy; new form-note paths are research prose,
# following the register's existing read policy rather than hiding names.
rel='data/reconstruction/name_pool_keys.json';pool=get(rel)
def leaves(node,path=''):
 if isinstance(node,dict):
  for k,v in node.items():yield from leaves(v,f'{path}.{k}' if path else k)
 elif isinstance(node,list):
  for v in node:yield from leaves(v,path+'[]')
 elif isinstance(node,str):yield path,node
declared=set(pool['read']['structures'])|set(pool['ignored']['structures']);added=[]
for sid in targets:
 for path,text in leaves(records[sid]):
  if re.search(r'\b[A-Z][a-z]{2,}\b',text) and path not in declared:
   if not re.fullmatch(r'phases\[\]\.form\.[a-z0-9_]+\.note',path):raise ValueError('unreviewed name-pool path '+path)
   added.append(path);declared.add(path)
pool['read']['structures']+=sorted(added);putjson(rel,pool)
# Normalize proposal prose to actual compile_liberties grammar, add precise
# Covers for every newly edited weak/omitted form claim, and retain date limits.
frags=[(P/'log-combined/liberty-fragments'/f'{ticket}.md').read_text() for ticket in ['T-2372','T-2374','T-2381','T-2382','T-2386']]
frags.append((P/'log-combined/boarding-refinement/liberty-supplement.md').read_text())
body=(hogan/'LIBERTY-entry.md').read_text();body=re.sub(r'^### .+\n','### L-hogan-pictured-recess-hatch-2377 — pictured doorway and unresolved gable closure\n',body,count=1);frags.append(body)
weak={sid:[] for sid in targets}
for sid in targets:
 for before,after in zip(original[sid]['phases'],records[sid]['phases']):
  for key,attr in after['form'].items():
   if attr!=before['form'].get(key) and (attr.get('confidence')=='reconstructed' or attr.get('geometry') in ('absent','simplified') and attr.get('value')):weak[sid].append(f'{sid}.{after["id"]}.form.{key}')
  if before['footprint']!=after['footprint'] and after['footprint'].get('confidence') in ('inferred','reconstructed'):weak[sid].append(f'{sid}.{after["id"]}.footprint')
normal=[];owned=set()
def legitimate(token):
 parts=token.split('.');sid,pid=parts[:2]
 phase=next(p for p in records[sid]['phases'] if p['id']==pid)
 block=phase
 for key in parts[2:]:block=block[key]
 return block.get('confidence')=='reconstructed' or block.get('geometry') in ('absent','simplified') and bool(block.get('value'))
for raw in frags:
 for block in re.split(r'(?=^### )',raw.strip(),flags=re.M):
  if not block.strip():continue
  head,body=block.split('\n',1);body=body.strip()
  if not body.startswith('**'):body='**Decision:** '+body
  body=re.sub(r'(\*\*Ticket:\*\*[^\n]*\n)\n+(Combined confidence ruling:[^\n]*|T-2382 next[^\n]*)',r'\1\n**Revision:** \2',body)
  if '**Recorded:**' not in body:body+='\n**Recorded:** 2026-10-23.'
  sid=next((sid for sid in targets if sid in body or {'chappel_infant_school':'L-school-','cobweb_castle':'L-cobweb-','miller_house':'L-miller-','wolf_point_tavern':'L-wolf-','philo_carpenter_log_shop':'L-carpenter-','hogan_store':'L-hogan-'}[sid] in head),None)
  extra=weak.get(sid,[]) if sid not in owned else []
  if extra:owned.add(sid)
  m=re.search(r'\*\*Covers:\*\*\s*(.*?)(?=\n\*\*|\Z)',body,re.S)
  tokens=[] if not m else [v.strip().strip('.').strip('`') for v in re.split('[,;]',m.group(1)) if v.strip()]
  tokens=[v for v in dict.fromkeys(tokens+extra) if legitimate(v)]
  if tokens:
   line='**Covers:** '+', '.join('`'+v+'`' for v in tokens)+'.'
   body=body[:m.start()]+line+body[m.end():] if m else body+'\n'+line
  elif m:body=body[:m.start()]+body[m.end():]
  if sid and sid not in body and records[sid]['name'] not in body:body+='\n**Building:** '+records[sid]['name']+'.'
  normal.append(head+'\n\n'+body+'\n')
rel='docs/LIBERTIES.md';current=read(rel)
for entry in normal:
 lid=entry.splitlines()[0].split(' — ')[0].removeprefix('### ')
 if re.search(r'^###\s+'+re.escape(lid)+r'\s*[—-]',current,re.M):raise ValueError('liberty already exists: '+lid+'; review duplicate instead of overwriting')
put(rel,current+'\n\n'+'\n\n'.join(normal));(out/'liberty-append.md').write_text('\n\n'.join(normal))
# The dossier append is appended to the current research file, never restored.
rel='docs/RESEARCH/cobweb_castle.md';old=(oldroot/rel).read_text() if (oldroot/rel).exists() else ''
current=read(rel);suffix='''\n\n## Future log picture-controls increment\n\nCompound parts build the already reconstructed centre/wings/tails polygon rather\nthan its bounding box. Wau-Bun supports composition, not the exact plan/roof.\nDimensions, openings, intersections and stack positions remain reconstructed;\npartial siding, 1835 survival and the tiny panorama subject remain unresolved.\nThe original T-2374 image match remains open.\n''';put(rel,current+suffix)
# Copy current helper dependencies for pure Python checks only.
shutil.copytree(app/'generators/common',baseline/'generators/common',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for p in (baseline/'generators/common').glob('*.py'):
 rel=str(p.relative_to(baseline));inputs[rel]=sha(p);assert sha(app/rel)==inputs[rel],'common helper drift'
for rel in ['data/liberties.json','tools/compile_liberties.py','tools/readable_text.py','tools/compile_summaries.py','tools/validate.py','data/structures.schema.json','data/source.schema.json']:
 read(rel)
for sid in ['cameron_c1900_first_post_office','andreas_1884_sauganash_hotel_plate','kinzie_waubun_1856']:read(f'data/sources/{sid}.json')
# Fixture current/future data with copied common kits; no assets/exporters/browser.
review=out/'review-tree/chicago/4d';shutil.copytree(baseline,review)
for p in candidate.rglob('*'):
 if p.is_file():dest=review/p.relative_to(candidate);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
manifest=get('assets/manifest.json');assets=manifest.get('assets',manifest);scope=[]
for asset,row in assets.items():
 sid=row.get('structure_id')
 if sid in records:scope.append({'asset':asset,'structure_id':sid,'phase_id':row['phase_id'],'baseline_sha256':sha(app/'assets/gltf'/asset),'intended_geometry_change':sid in targets})
assert len(scope)==81
(out/'freshness-scope.json').write_text(json.dumps({'assets':scope,'count':81,'intended_geometry_changes':targets,'original_cases_open':['T-2372','T-2374','T-2381','T-2382','T-2386','T-2377']},indent=2)+'\n')
(out/'structure-ids.txt').write_text(','.join(sorted(records))+'\n')
full='';code='';data=''
for rel,after in changes.items():
 before=(baseline/rel).read_text() if (baseline/rel).exists() else ''
 patch=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/chicago/4d/'+rel if before else '/dev/null',tofile='b/chicago/4d/'+rel))
 full+=patch
 if rel.startswith('generators/'):code+=patch
 else:data+=patch
(out/'integration.patch').write_text(full);(out/'review-code-section.patch').write_text(code);(out/'review-data-section.patch').write_text(data)
receipt={'head':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'checkout':str(repo),'inputs':inputs,'changed_files':list(changes),'ordered_model_operations':ops,'new_name_pool_read_paths':sorted(added),'preserved_independent_source_metadata':preserved,'completion_scope':'Future shared picture-controls prerequisite only; six original image matches stay open. One code+visible-data PR with official81 rebuild/appQA, not an invisible code-only PR.'}
for rel,want in inputs.items():assert sha(app/rel)==want,'input changed during preparation: '+rel
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'output':str(out),'changed_files':len(changes),'code_files':2,'target_records':6,'new_name_pool_note_paths':sorted(added),'full_family_rebuild':81,'repository_writes':False},indent=2))
