# Future shared log picture-controls integration — selective, light preparation

Authoritative prepared output: **05f6-sourceS-final/**. Earlier draft/ready/portable
directories are superseded preparation checkpoints. Nothing was applied to the
checkout. No Blender, browser, supported bake, publisher or full gate ran here.

The intended delivery is **one code + actual visible opt-in increment PR**, after
the parent's frame M integration. The future ticket concerns shared log picture
controls and their validated adoption. It is a prerequisite, not a completion
child for each pictured building. Parent will mint the ticket and review scope.
Do not create six progress tickets or an invisible code-only PR waiting for use.
The original T-2372, T-2374, T-2381, T-2382, T-2386 and T-2377 stay open; every
actual historical comparison still differs. No image-gate bypass is proposed.

## Correct order and selective semantics

The 32 small inputs under proposal-inputs/ preserve the already reviewed proposals:

1. Combined log controls and five opt-ins.
2. Miller's actually visible 24 mm / 4 mm dark joint refinement.
3. The final three-file Hogan continuation: two shared modules and the selective
   record changes for blind recess, reconstructed hatch and 0.75 m ridge head.

materialize.py checks the bundled input SHA manifest, reads the **current working
tree**, and writes a NEW /tmp output only. It does not check out an old branch,
apply a patch, restore a whole old record or copy old manifests/sidecars into the
repository. Shared code is a three-way merge against the original baseline;
unresolved overlaps stop. Record deltas merge by phase id and attribute, preserving
unrelated current fields/values/research. Coupled opening changes stop for review.
Source note/supply deltas preserve independent text; current credits, clearance
and other metadata remain. Existing sourceS grade rows stay; three picture rows
are appended. Current LIBERTIES and Cobweb research receive append-only text.

The captured checkout HEAD was 05f6b886e with sourceS's working-tree edits present.
receipt.json hashes the exact actual inputs, not merely HEAD. No current Hogan
position, documented 45 x 20 ft polygon, eave/pitch, doorway/window station/size,
chimney station/width, source credit, earlier pictured ruling or existing research
is reverted. Only the reviewed continuation changes its door state, gable closure
proxy, head rise and related explanatory notes. Independent sourceS church/jail/
Beaubien records, new source records and grade decisions are retained.

## Materialize again after frame M

Use a new output path; existing outputs are immutable preparation evidence:

```sh
python /tmp/chicago-next-model/log81-materializer/materialize.py \
  --checkout /workspace/chicago --output /tmp/log81-after-frame-M-review
python /tmp/chicago-next-model/log81-materializer/verify.py \
  /tmp/log81-after-frame-M-review
git -C /workspace/chicago apply --check /tmp/log81-after-frame-M-review/integration.patch
```

integration.patch is the **primary combined 14-file proposal**. The two
review-*-section.patch files separate code and data for review only; do not make
separate PRs or apply them in addition to integration.patch. candidate/ contains
changed files; baseline/ and review-tree/ are test snapshots, not restore sources.
The materializer refuses any selected alternate versions or a scope differing
from the current 81 masters; such a change requires explicit scope review.

## Feature contracts and lightweight evidence

verification.json records actual copied-module/raw mesh checks using the current
common kits and **official structure_id__phase_id names/seeds**:

- All 81 current/default parameter sets and complete emitted vertices, faces,
  confidence, material indices/specifications and named materials remain exact.
- All 81 future-five-opt-in outputs remain exact when adding the disabled Hogan
  option; the Hogan overlay does not perturb the previous five refinements.
- Four added fields are keyword-only, preserving all legacy positional arguments:
  compound_parts=(), roof_ridge_axis=None, frame_addition_cladding=clapboard,
  front_door_state=closed. END_OPENING_KINDS adds hatch without changing old kinds.
- Twenty invalid combinations reject. Explicit core axis cannot combine with
  compound parts, shed/hip conflicts reject, Y-axis end/lean-to guards remain,
  mixed cladding needs a two-storey frame addition, and recess needs a stated
  single-storey front without compound rooms/frame addition. Hatch height is
  checked. No permissive fallback or gate weakening is introduced.
- Exactly six opt-in records actually change raw geometry. Their polygons,
  placements, documented ranges, use and occupants remain. Geometry is finite
  and nondegenerate. The actual front log/chink cut leaves the doorway clear;
  its blind back sits 0.30 m inside, and the hatch emits no glazing.
- Schemas, source rights/credits and existing grade rows pass. Regressions prove
  independent Hogan width/research survives and a coupled opening drift is
  refused. Independent source note/supply text is retained.

These are light contracts, not a fresh combined canonical export, app QA or full
gate. Earlier isolated pinned exports/comparisons remain evidence: school,
Carpenter and Wolf Point category improvements; Miller's visible lower logs and
upper joints; Hogan's cut recess/hatch/shorter head. Cobweb implements Wau-Bun's
text plan, not proven resemblance to its tiny unresolved panorama subject.

## Provenance, Covers and name-pool requirements

The combined proposal includes two source changes. School modifies its declared
reference-use ledger only, retaining the complete historical note and all journal
credit, URL, project-specific owner approval and rights_checked. No public-domain
or copyright-holder permission claim is added. Blanchard/Shober's single source
identity covers Wolf Point and Miller, preserving its publisher/lithographer,
1867 publication / 1833 depicted-date distinction, public-domain age reasoning
and retrospective/metric limits. Cameron and Braunhold sources remain current.

The eight liberty entries were normalized to the **actual parser**: proper named
fields, Recorded dates, card subjects and 28 precise Covers claims. The actual
coverage routines report **45 owed values, zero unclaimed** across the six cases.
An inferred consumed finish category is not falsely claimed as a reconstructed
attribute; its chosen code sections/rhythm are admitted in prose. Existing broad
cladding simplification and reconstructed controls receive valid claims.
The parent still compiles the canonical liberty ledger in the official pipeline.

Six new name-pool read paths are included, following the register's established
research-prose policy rather than hiding names:

```
phases[].form.compound_parts.note
phases[].form.frame_addition_cladding.note
phases[].form.front_door_state.note
phases[].form.front_shutters.note
phases[].form.ridge_stack_head_m.note
phases[].form.roof_ridge_axis.note
```

The grade delta appends reasonable whole-picture rulings for Miller, Wolf Point
and the annex under its existing Beaubien-caption identity. Existing Hogan and
sourceS rows remain. School and Cobweb remain inferred pending identity/subject
resolution; no camera enters data/reference_views. Picture availability does not
attest numeric choices or establish an accepted match. New joint geometry and
compound layout remain reconstructed; pictured finish categories stay inferred.

## Required official integration and one full 81 rebuild

After frame M, mint/review the genuine prerequisite ticket; rematerialize against
that checkout and inspect all overlaps and preserved-source receipts. Apply the
one combined proposal only after parent review. Add the normal changelog/status
for shared controls and visible increments, explicitly keeping all six original
match tickets open. Do not copy old generated files from these snapshots.

freshness-scope.json lists the exact 81 assets/phases/baseline hashes and six
intended geometry changes; structure-ids.txt selects every distinct family id.
All 81 recipes change because builder bytes and four resolved fields change.
The other 75 meshes should preserve geometry. No freshness hash may be restamped.
Use the official copied/current build.py + emit.py with exact asset-key names,
all scene dates and pinned Blender 4.5.3. Verify cached archive SHA and version.

OFFICIAL-PLAN.md gives coordinated commands for a single family export, exact
written-set/recipe verification, web derivatives, canonical liberty/source/scene/
grade metadata, entrances/signage and coordinated local publication. Inspect real
before/after pictures, actual GLB confidence/materials/normals/indices/bounds,
recess cuts, roof/tail joints, source cards and desktop/mobile application. Measure
draw/triangle/performance changes, run normal check.sh and strict preflight, then
publish the reviewable PR under the ordinary project workflow.

Prior pinned rebuilding found UV-only committed-byte drift in Kinzie stable;
a fresh original-code control matched the proposal, with all non-UV/material/
index/confidence fields identical. Preserve and classify actual future drift;
this is evidence, not an asset whitelist or permission to ignore a failure.

Unresolved work remains in every original case: school identity/gable logs/open
door/covering and proportions; Cobweb subject/date/tails/siding; Miller windows,
stack, cabin, board texture and camera; Carpenter sash divisions/door/masonry/
joint camera; Wolf Point twin gables/second entrance/pipe; Hogan gable infill,
roof/log texture, chimney detail and painted perspective. The future shared
controls ticket can complete its own verified scope; it does not close those
building-image matches or manufacture matches verdicts.
