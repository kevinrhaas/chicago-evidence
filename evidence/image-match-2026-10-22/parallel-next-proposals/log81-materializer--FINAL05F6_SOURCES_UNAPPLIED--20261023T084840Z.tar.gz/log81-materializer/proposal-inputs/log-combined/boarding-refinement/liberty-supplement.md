

### L-miller-visible-joints-2381 — readable vertical joint cues

The first actual neutral review showed that same-material 12 mm edges with
12 mm relief were effectively invisible. This supersedes those first-proposal
sections only: joint proxies now use 24 mm width, 4 mm relief and the existing
darker log material, retaining nominal 0.24 m board rhythm and every room, roof,
opening, cladding break and surveyed placement. Broad wall/gable finish faces
remain inferred; chosen contrast-strip geometry remains reconstructed (1.0).
The source supports vertical boards and their visible joint rhythm, not these
exact widths, relief, colour, board gaps or an applied board-and-batten joint.
This is a readable joint depiction, not a measured physical gap or paint claim.
Unseen surfaces inherit the reconstructed treatment. Existing palette slots are
reused; no new material is introduced. Same-camera export/review must demonstrate
that the joints read while source textures, three upper windows, ridge stack,
side-cabin arrangement and camera remain open differences. T-2381 stays open.
**Covers:** miller_house.log_frame_1827.form.frame_addition_cladding.
**Recorded:** 2026-10-23.
