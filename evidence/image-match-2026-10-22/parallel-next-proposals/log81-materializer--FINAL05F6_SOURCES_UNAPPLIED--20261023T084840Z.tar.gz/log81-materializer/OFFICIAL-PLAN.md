# Coordinated official plan — not executed by this package

Run after frame M and parent scope/ticket review. The following uses the reviewed,
fresh materialized output, never the old frozen proposal tree. Parent supplies the
new package path and retains the canonical pre-export meshes for comparison.

1. Apply integration.patch, add the ordinary prerequisite changelog, and compile
   the appended canonical ledger with `python3 tools/compile_liberties.py`.
2. Coordinate a heavy slot and verify the cached pin explicitly. From chicago/4d:

```sh
source generators/blender.pin
log_cache=/workspace/shared/blender-dl
log_binary="$log_cache/$BLENDER_DIR/blender"
log_archive="$log_cache/$(basename "$BLENDER_URL")"
printf '%s  %s\n' "$BLENDER_SHA256" "$log_archive" | sha256sum -c -
"$log_binary" --version
```

3. Read the exact reviewed structure-ids.txt into a task-specific variable, then
   invoke the official producer once. All scene dates are included by default:

```sh
log_review=/tmp/log81-after-frame-M-review
log_ids="$(cat "$log_review/structure-ids.txt")"
"$log_binary" -b -noaudio --factory-startup --python generators/build.py -- \
  --only "$log_ids" --wrote /tmp/log81-official-wrote.txt
```

4. Check that the wrote set equals the materialized 81 asset names exactly; require
   each new manifest inputs_sha256 to equal mesh_inputs.structure_inputs_sha on
   current canonical data. Compare the 75 intended-default exports with retained
   masters; decode any difference rather than blind-restamping. Explicitly inspect
   all six changed GLBs and their true asset-key seeds. The prior stable UV control
   is a research receipt, not a future ignore rule.
5. Derive only the 81 actual written masters through the supported tool:

```sh
tools/web_derivatives.sh --only "$(paste -sd, /tmp/log81-official-wrote.txt)"
python3 tools/compile_scene.py --all
python3 tools/generate_entrances.py
python3 tools/generate_business_signboards.py
```

6. Inspect generated diffs/grade/source/licence coverage and any downstream normal
   rederivations. Name-pool declarations are already in the patch; run the normal
   check and investigate any genuine pool collision rather than silently rewriting
   households. Do not overwrite sourceS independent edits or frame M outputs.
7. Coordinate the shared local publisher once data/derivatives are ready. The
   repository's `tools/bake.sh --only ...` includes derivatives, scene compilation,
   local publish and a gate; use that full route instead of the split above only
   when those shared effects are intentionally coordinated. Do not run both export
   routes or duplicate the family rebuild.
8. Capture controlled original/after views and inspect actual pixels; leave all
   historical verdicts differs. Review source credits and model/card behavior at
   desktop/mobile on the published local derivative path. Check doorway recess,
   hatch, compound roof/tails, visible boarding, materials/draw counts and budgets.
9. Run the required full check.sh and strict preflight and review their final tails.
   Parent creates the single code+data PR and follows ordinary review/merge policy.
   Only the real shared-controls prerequisite is eligible for completion; original
   T-2372/2374/2381/2382/2386/2377 remain open under their image gates.

No command in this plan was executed here. This package performed only selective
/tmp preparation, schema/parser/raw contracts and read-only apply checks.
