# Miller visible boarding follow-up — unapplied, actual capture reviewed

The first actual mixed-cladding render showed lower logs but its same-material
12 mm board edges were effectively invisible upstairs. This bounded follow-up
makes the vertical joints read in the **identical** NYPL camera, using the existing
darker log material for 24 mm joint proxies with 4 mm relief. The nominal 0.24 m
board rhythm is retained. No room, roof, opening, cladding break, stack, placement,
date or use changes. No new material or parameter is introduced.

The joint strips are a reconstructed readable depiction, **not measured historic
gaps, applied battens or paint**. Broad pictured wall/gable finish faces remain
inferred; the chosen strip geometry remains reconstructed (1.0). Existing source
limits, confidence notes and the append-only liberty supplement are retained.

## Reviewable result

- `reviews/miller-joint-progression.png`: source / committed before / first
  ineffective joints / new visible joints, cropped from the actual captures.
- `reviews/T-2381-miller-nypl-side-by-side.jpg`: full exact-camera final comparison.
- `export-review.json`: actual pinned GLB contract/count/material/recipe checks.
- `combined-focused-check.json`: all 81 legacy raw outputs/parameters/materials
  remain identical with options absent; positional signature preserved; 14 guards.

The actual final image now visibly reads vertical boards, improving on the blank
upper wall. The source's irregular/weathered boards, exact count/spacing and tone
are not reproduced. Two rather than three upper windows, the large exterior
stack, cabin-behind-main arrangement, generic glazing/door, roof and provisional
camera remain open. T-2381 stays open and the research match record is `differs`.

Source credit: *Wolf's Point in 1833*, published by **Rufus Blanchard**, lithographed
by **Chas. Shober & Co.**, Chicago, **1867**, under the auspices of the Chicago
Historical Society. NYPL I.N. Phelps Stokes Collection surrogate:
<https://commons.wikimedia.org/wiki/File:Wolf%27s_Point_in_1833_(NYPL_Hades-118496-54620).tif>.
The actual printed 1867 deposit line supports the existing public-domain age
finding. It is a retrospective scene dated 1833, not direct July 1835 observation
or metric evidence. Full source JSON and photo are copied inside `preview/`.

## Patch choices — apply exactly one route

`visible-joints.patch` is a **three-file overlay** on the original combined
candidate: builder helpers, Miller's explanatory note and appended liberty.
Use this if the original combined proposal is already integrated.

`log-combined-visible-joints.patch` is the **cumulative 11-file version** including
all five original tickets and this follow-up. Use this instead of the original
log-combined.patch when starting from its frozen original baseline. Do not apply
both full variants or both routes. `candidate/` contains the new complete files;
the canonical parent candidate and original run remain immutable, so parent must
select this refinement explicitly. The original prepare.py does not regenerate
this refinement and should not be run over it.

Both patch routes were apply-checked in private copies: the original combined
patch was reversed to recover its original texts, then the new cumulative diff
checked; the overlay was checked against an untouched combined candidate. No live
checkout reads/changes were needed. Parent's current frame LIBERTIES additions
must still be merged centrally rather than overwritten from this snapshot.

## Actual execution and scope

The parent authorised one brief heavy slot. A regular-file clone of the completed
frozen proposal received this overlay; official copied build.py/emit.py exported
only `miller_house`, using `miller_house__log_frame_1827` as the seed/name. Cached
pinned Blender 4.5.3 and archive were verified in the preceding frozen family run;
the same binary was used. One exact-camera photo_match capture completed exit 0.
Blender, browser and ephemeral server all closed, and the slot was returned.
No publisher, official manifest, asset, branch or ticket was written.

The actual final GLB has 8 materials, 8 primitives, 4,946 vertices and 2,470
triangles, exactly the first proposal's counts. Material specifications and overall
bounds are unchanged. Decoded finite attributes, unit normals, valid indices and
SCALAR float confidence pass. The Miller recipe matches its copied manifest.

**All 81 family recipes still require an official batch rebuild** after adopting
this helper change. Only Miller is rebuilt/current in this diagnostic preview;
the other 80 copied log masters still correspond to the earlier helper. The full
81-name scope remains `freshness-scope.json`, with five intended geometry changes.
No recipe hash was blindly restamped. The independent 81-default raw comparison
uses the preserved original generator snapshot and current refined candidate.

No derivative, full app/source-card check, scene/grade/liberty compilation, full
gate or accepted match was run for this follow-up. Hogan merge remains a dependency
for official integration; all five original image-match tickets stay open.
