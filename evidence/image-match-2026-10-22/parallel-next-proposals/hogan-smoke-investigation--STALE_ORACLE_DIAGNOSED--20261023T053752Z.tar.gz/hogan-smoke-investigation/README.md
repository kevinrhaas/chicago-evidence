# Hogan PR #1229 mobile stages 14–15 — exact-head diagnosis

## Cause: deterministic stale smoke oracle

Run 39903339626, job 120249605678, tested exact commit
`6156a0367a2379f0d986b88c7c8236c4ebec0e55`.
At 2026-10-23 05:11:29.4598566 UTC the 1904 layer-isolation assertion failed.
The job finished 160 passed / 1 failed, zero page errors.

The code's literal `PLACED_1904` array contains **195** IDs. The actual registry
contains **222**: all 195 expected IDs plus exactly 27 legitimate Indiana Avenue
context records omitted from the literal oracle. No expected ID is absent. The
captured actual registry exactly equals the 1904 sidecar index in that same
commit. None of the 27 extras appears in that commit's 1835 sidecar index.
Every prohibited 1835 layer's reported mesh count is zero.

`structures:219` in the failure log is a traversed **mesh count**, not registry
size; it is not evidence that 3 registry IDs failed to load. The test captures
`at.registry` as `registry.size` and `at.placed` as the registry's keys.

This is not demonstrated flakiness. The exact assertion can be reproduced as
false from the logged IDs without any browser or timing behavior. An unchanged
rerun cannot fix the 195-versus-222 comparison.

## Origin and independent verification

All 27 omitted records were added together by **T-3009 / PR #1198**, commit
`a40a4af4006a9bc81b3b500b22b08b39ed2d212d`:
“Indiana Avenue's east frontage 20th-22nd drafted as background, with First
Presbyterian.” That commit did not change the smoke oracle.

The 1904 index grew from 174 records immediately before that commit to 201 in it,
adding exactly these 27. Later district work grew the index to 222; the constant
correctly gained the other 21 but still omitted T-3009's entire cohort. Thus the
fault predates the Hogan model change.

The 27 IDs are verified individually in `verified-indiana-records.json` against
canonical structure records and 1904 sidecars from the **exact failing head**.
Each has phase `draft_1904`, is in scene 1904 at target date 1904-07-01, covers
that date in its authored range, and does not cover 1835-07-01. Their actual map
source resolves to `sanborn_1911_chicago_v3_sheet_35`: verified, public domain,
tier 1. The records explicitly grade the 1904 back-reading as inferred; this
investigation does not promote it to a contemporaneous 1904 survey.

The same-head structural evidence therefore supports an expected-ID correction,
not deleting buildings, changing their date ranges, tolerating unknown extras or
weakening the layer isolation check.

## Prepared minimal correction

`restore-1904-indiana-oracle.patch` changes only the literal expected array in
`tools/smoke_renderer.mjs`: append the 27 verified IDs under a T-3009 comment.
No assertion, loader, dataset, timing, workflow or test-selection change is made.
No repository file was edited. The parent owns the independent repair PR/ticket
handling and whether to apply or adapt this patch after rebasing Hogan.

`regression-proof.mjs` extracts and executes the original and patched **actual
assertion expression**, rather than restating it. It confirms:

- the exact-head oracle fails on the captured 222 IDs;
- the corrected 222-ID oracle passes on those same IDs;
- deleting either a new Indiana ID or existing Glessner still fails;
- inserting the 1835 `hogan_store` still fails;
- introducing a prohibited 1835 layer still fails;
- a disagreeing registry count still fails;
- the assertion's text is unchanged.

All proof checks passed in under 0.1 s. Results are in regression-proof.json.
No browser rerun or heavy process was started. After landing/integrating the
repair, run the affected mobile 14–15 slice on the new exact head, with the normal
full preflight and any additional checks required by the final diff. The proof
here diagnoses the failed check; it is not a substitute for that browser check.

## Evidence files

- `failure-line.txt`: exact failed line from the supplied job log.
- `expected-vs-actual.json`: counts, exact ID differences, layer counters and
  equality with the same-head sidecar index.
- `origin-history.txt`, `origin-counts.json`: the originating cohort commit and
  before/after index counts.
- `verified-indiana-records.json`, `verified-sources.json`: per-record phase,
  range, source and scene evidence.
- `smoke_renderer.exact-head.mjs`, `smoke_renderer.fixed.mjs`: source snapshots
  used for the narrow, no-browser proof; temporary audit files only.
- `restore-1904-indiana-oracle.patch`: one source-file correction.
- `regression-proof.mjs`, `regression-proof.json`: executed proof and results.

Existing issue linkage: T-3009 / chicago PR #1198. No new ticket was minted.
