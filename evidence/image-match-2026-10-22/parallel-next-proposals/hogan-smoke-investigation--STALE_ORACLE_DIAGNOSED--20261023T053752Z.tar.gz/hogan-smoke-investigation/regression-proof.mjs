// Run the exact check expression on captured IDs, then deliberately break its inputs.
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import path from 'node:path';
const here=path.dirname(new URL(import.meta.url).pathname);
const original=fs.readFileSync(path.join(here,'smoke_renderer.exact-head.mjs'),'utf8');
const fixed=fs.readFileSync(path.join(here,'smoke_renderer.fixed.mjs'),'utf8');
const failure=fs.readFileSync(path.join(here,'failure-line.txt'),'utf8');
const actual=JSON.parse(failure.split('structures placed ')[1]);
function pieces(src){
 const list=/const PLACED_1904\s*=\s*(\[[\s\S]*?\]\.sort\(\))/.exec(src)?.[1];
 const expr=/check\(`\$\{label\}: the 1904 scene draws none[\s\S]*?`,\s*([\s\S]*?),\s*`meshes:/.exec(src)?.[1];
 assert(list&&expr,'capture the real expected array and closing assertion');return {list,expr};
}
const a=pieces(original),b=pieces(fixed);assert.equal(a.expr,b.expr,'do not weaken or replace the isolation assertion');
function run(p,placed,stray=[],registry=placed.length){return vm.runInNewContext(`const PLACED_1904=${p.list}; ${p.expr}`,{at:{placed,registry},stray,JSON});}
assert.equal(run(a,actual),false,'exact HEAD reproduces the logged assertion failure');
assert.equal(run(b,actual),true,'the narrowly corrected source oracle accepts all captured legitimate 1904 IDs');
assert.equal(run(b,actual.filter(x=>x!=='house_2007_indiana')),false,'missing a new 1904 structure still fails');
assert.equal(run(b,actual.filter(x=>x!=='glessner_house')),false,'missing an existing 1904 structure still fails');
assert.equal(run(b,[...actual,'hogan_store']),false,'an extra 1835 structure still fails');
assert.equal(run(b,actual,['signage']),false,'an 1835-only layer still fails');
assert.equal(run(b,actual,[],actual.length+1),false,'registry count disagreement still fails');
const result={head:'6156a0367a2379f0d986b88c7c8236c4ebec0e55',originalFailureReproduced:true,correctedCapturedDataPasses:true,assertionUnchanged:true,missingNewIdRefused:true,missingOldIdRefused:true,extra1835IdRefused:true,legacyLayerRefused:true,registryCountMismatchRefused:true,browserRun:false};
fs.writeFileSync(path.join(here,'regression-proof.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
