# Five first-fort range fronts: next source-shaped geometry increment

Prepared as a separate overlay AFTER the frozen shared-fort controls proposal in `/tmp/chicago-next-model/fort-selective-integration`. Those packages and their previews are untouched. No repository files were written, no Blender/browser ran, no ticket was closed, and no view is labelled `matches`.

The actual Whistler1808 plan reproduced in Quaife1913 includes folded elevations, not merely floor rectangles. The previous procedural `width / 3.4` pattern misses clear front opening counts:

| Range | Source front rectangles per storey | Existing procedural bays | Proposed two-storey front total |
|---|---:|---:|---:|
| North soldiers/contractor range |4|2|8|
| Southwest soldiers range |4|2|8|
| Southeast soldiers range |4|2|8|
| West officers range |5|4|10|
| East commanding-officers range |4|3|8|

Actual source/crops: `/tmp/chicago-next-model/T-2387-coverage-audit/whistler-1808.png`, `whistler-garrison-detail.png`, `whistler-south-elevations-detail.png`. Existing registered source is `whistler_1808_fort_dearborn_draught`; no new source or rights exemption is needed. This primary1808 evidence supports occurrence/count, not exact metric joinery or proof that every rectangle is a glazed window. The date carried into1812 is an inference of continuity before destruction, not a claim of an1812 photograph.

The patch introduces one opt-in `face_openings` form value and individually keyword-only dataclass field. Each rectangle names front/back/left/right, window/door, and local-metre `u0/u1/z0/z1`. `None` preserves the old geometry; `[]` deliberately means blank walls on this supported range. It supports only unjettied quarters/barracks, refuses invalid dimensions/types/unknown keys, and requires0.15m wall between simultaneous holes. It neither changes plan orientation nor invents a new facade coordinate system.

All explicit faces are emitted from `wall_openings` in the params module; `facade_openings.front_wall` reads the SAME front rectangles and distinguishes unread legacy fronts from explicit blanks. The existing signboard resolver is registered for fort_structure, then still applies its existing phase/date selection. The actual entrance and merged-opening readers consume that facade answer unchanged. Their1835 producer excludes the1812 ranges and writes no new1835 ground aprons; this patch does not pretend it creates a complete1812 entrance layer. Future1812 producers can use the truthful shared answer directly.

Metric/type liberties are deliberately reconstructed: front bays are evenly spaced, windows retain0.72m width and existing storey-height arithmetic; one lower bay is a1.1m×2.03m closed panelled door, nearest centre (left inner bay in even-count ranges). Upper rectangles are windows, not asserted gallery-access doors. Existing rear windows are copied exactly as reconstructed controls, without turning an unpictured rear elevation into attested fact. All explicit opening geometry carries confidence1.0. No measured ink opening width is misrepresented as metres. See `LIBERTY-APPEND.md`.

Ground-contact/collision audit: range polygon, local origin, UTM position, bearing, documented dates, wall heights, gallery structure and all pre-existing form attributes are byte-equivalent data. Existing perimeter feet/static bedding and walker collision continue to consume that same physical wall footprint. Openings remain applied closed surfaces under the existing no-interiors contract, so there is no new promise of walk-through holes. Sidecars keep the same footprint/form provenance pipeline; no hand-edited sidecar or manifest is included.

`python check_light.py` passed: all25 actual family defaults and emitted legacy opening calls equal; all16 positional plus6 existing keyword-only parameters preserved; only this new field is keyword-only; every other generator function is AST-identical; all five records add ONLY the new form attribute; rear rectangles exact; all four wall-plane signs checked; facade/signboard/actual entrance readers agree; invalid/merged openings fail. This is a meaningful lightweight code/call proof, not a new exported mesh or visual match.

Integration is intentionally guarded. `inputs.json` pins each nine-file baseline and candidate hash. `face-layout-next.patch` is for the final shared-fort candidate, NOT current canonical HEAD. Merge by field/guarded code delta if other controls land meanwhile (the lighthouse narrow-diameter trial also edits fort params). Do not restore whole old records or modules over later work. The helper byte change requires a real25-family canonical bake and default geometry review, even though only five records opt in; it must not hash-restamp frozen old previews. Existing UV nondeterminism caveats remain applicable.

Next actual review: render the five fronts and Currey courtyard compound with unchanged surveyed placement, compare counted source rectangles, identify door/type disagreements and gallery occlusion, then work the differences down. All original T-2387/T-3041 image gates stay open. No exact match is claimed from the count change alone.

Roof candidates remain separate unsupported capability gaps: magazine has strong Whistler/Currey arched/barrel appearance but no barrel roof helper; northeast small house appears hipped but outbuilding accepts only gable/shed. Neither is a safe data-only roof edit, and no exact new roof dimension is proposed.
