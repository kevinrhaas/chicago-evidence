from pathlib import Path
import json,hashlib,difflib,ast
H=Path(__file__).resolve().parent; R=Path('/workspace/chicago'); F=Path('/tmp/chicago-next-model/fort-selective-integration/staged/candidate'); B=H/'baseline';C=H/'candidate'
rels=['chicago/4d/generators/archetypes/fort_structure_params.py','chicago/4d/generators/archetypes/fort_structure.py','chicago/4d/generators/archetypes/facade_openings.py','chicago/4d/tools/generate_business_signboards.py']
counts={'north_range':4,'soldiers_barracks_sw':4,'soldiers_barracks_se':4,'officers_barracks':5,'commanding_officers_barracks':4}
rels += ['chicago/4d/data/structures/first_fort_dearborn_'+n+'.json' for n in counts]
for rel in rels:
 p=F/rel if (F/rel).exists() else R/rel
 for root in [B,C]:
  (root/rel).parent.mkdir(parents=True,exist_ok=True);(root/rel).write_bytes(p.read_bytes())
p=C/rels[0];t=p.read_text();t=t.replace('"cupola_height_m", "cupola_roof_pitch_deg",','"cupola_height_m", "cupola_roof_pitch_deg", "face_openings",')
t=t.replace('    # per-attribute confidence, keyed by the attribute name in the record','''    # Explicit wall-plane rectangles. None retains legacy procedural fronts/backs.
    # Empty list explicitly means no openings on these range walls. Each entry is
    # {face, kind, u0, u1, z0, z1}; coordinates are local metres, not image pixels.
    face_openings: list | None = field(default=None, kw_only=True)

    # per-attribute confidence, keyed by the attribute name in the record''')
t=t.replace('    def validate(self) -> None:\n','''    def validate(self) -> None:
        if self.face_openings is not None:
            if self.kind not in ("quarters", "barracks") or self.overhang_m:
                raise ParamError("face_openings currently supports unjettied quarters/barracks")
            if not isinstance(self.face_openings, list) or len(self.face_openings) > 128:
                raise ParamError("face_openings must be a list of at most 128 rectangles")
            for o in self.face_openings:
                if not isinstance(o, dict) or set(o) != {"face", "kind", "u0", "u1", "z0", "z1"}:
                    raise ParamError("each face_openings rectangle needs face/kind/u0/u1/z0/z1")
                if o["face"] not in ("front", "back", "left", "right"):
                    raise ParamError("face_openings face must be front/back/left/right")
                if o["kind"] not in ("window", "door"):
                    raise ParamError("face_openings kind must be window/door")
                if any(isinstance(o[k], bool) or not isinstance(o[k], (int, float))
                       or not math.isfinite(o[k]) for k in ("u0", "u1", "z0", "z1")):
                    raise ParamError("face_openings dimensions must be finite numbers")
                span = self.width_m if o["face"] in ("front", "back") else self.depth_m
                if not (0 <= o["u0"] < o["u1"] <= span
                        and 0 <= o["z0"] < o["z1"] <= self.wall_height_m):
                    raise ParamError("face_openings rectangle must lie within its wall")
            for i, a in enumerate(self.face_openings):
                for b in self.face_openings[i+1:]:
                    if a["face"] != b["face"] or a["z0"] >= b["z1"] or b["z0"] >= a["z1"]:
                        continue
                    if max(b["u0"]-a["u1"], a["u0"]-b["u1"]) < 0.15-1e-9:
                        raise ParamError("face_openings must leave at least 0.15 m between openings")
''')
t=t.replace('        confidence=confidences,','        face_openings=val("face_openings", None),\n        confidence=confidences,')
t+='''

def wall_openings(p: FortStructureParams, face: str) -> list[dict] | None:
    """The explicit rectangles on one wall; None means this wall is unread.

    Both mesh and front-wall reader consume this exact layout. Legacy procedural
    layouts remain unread here rather than being falsely declared empty.
    """
    if p.face_openings is None:
        return None
    return [{k: o[k] for k in ("kind", "u0", "u1", "z0", "z1")}
            for o in p.face_openings if o["face"] == face]


def front_wall(p: FortStructureParams) -> dict | None:
    openings = wall_openings(p, "front")
    if openings is None:
        return None
    return {"u0": 0.0, "u1": p.width_m, "wall_height_m": p.wall_height_m,
            "openings": openings}
''';p.write_text(t)
p=C/rels[1];t=p.read_text();s=t.index('    """Door and windows on the facade and the back.',t.index('def _openings('));e=t.index('    conf = ',s)
t=t[:s]+'''    """Use explicit range rectangles when present, otherwise retain legacy layout.

    The 1808 folded elevations show range bay counts. Their exact metric set-out,
    doorway identities and unpictured rear layouts remain reconstructed choices.
    """
    if p.face_openings is not None:
        _explicit_openings(b, p)
        return
'''+t[e:]
insert=t.index('\ndef _magazine_door(')
t=t[:insert]+'''
def _explicit_openings(b: MeshBuilder, p: FortStructureParams) -> None:
    """The same rectangles returned by the Blender-free facade reader."""
    planes = {"front": ("y", p.depth_m, 1), "back": ("y", 0.0, -1),
              "left": ("x", 0.0, -1), "right": ("x", p.width_m, 1)}
    conf = max(p.conf("face_openings"), 1.0)
    for face, (axis, plane, outward) in planes.items():
        for o in wall_openings(p, face):
            _opening(b, axis, plane, o["u0"], o["u1"], o["z0"], o["z1"],
                     outward, conf, kind=o["kind"])

'''+t[insert:]
# The builder imports selected names from params; append shared reader there.
node=next(n for n in ast.parse(t).body if isinstance(n,ast.ImportFrom) and any(a.name=='FortStructureParams' for a in n.names))
lines=t.splitlines(True);end=node.end_lineno-1
# Existing import is multiline, safely replace its closing line.
chunk=''.join(lines[node.lineno-1:node.end_lineno]);newchunk=chunk.replace('import FortStructureParams','import FortStructureParams, wall_openings',1)
if newchunk==chunk:raise ValueError(chunk)
lines[node.lineno-1:node.end_lineno]=[newchunk];p.write_text(''.join(lines))
p=C/rels[2];t=p.read_text().replace('from archetypes import outbuilding_params as _outbuilding','from archetypes import outbuilding_params as _outbuilding\nfrom archetypes import fort_structure_params as _fort');t=t.replace('    "outbuilding": _outbuilding_front,','    "outbuilding": _outbuilding_front,\n    # Explicit range layouts only; legacy fort fronts still return None.\n    "fort_structure": _fort.front_wall,');t=t.replace('UNREAD = ("bridge_timber", "fort_structure", "frame_tavern",','UNREAD = ("bridge_timber", "frame_tavern",');p.write_text(t)
p=C/rels[3];t=p.read_text().replace('from archetypes.outbuilding_params import from_phase as _outbuilding_params  # noqa: E402','from archetypes.outbuilding_params import from_phase as _outbuilding_params  # noqa: E402\nfrom archetypes.fort_structure_params import from_phase as _fort_params  # noqa: E402');t=t.replace('    "outbuilding": _outbuilding_params,','    "outbuilding": _outbuilding_params,\n    "fort_structure": _fort_params,');p.write_text(t)
for name,count in counts.items():
 rel='chicago/4d/data/structures/first_fort_dearborn_'+name+'.json';p=C/rel;rec=json.loads(p.read_text());ph=rec['phases'][0];f=ph['form'];poly=ph['footprint']['polygon'];w=max(x[0] for x in poly);h=f['wall_height_m']['value'];sh=h/2;ops=[]
 for floor in range(2):
  for i in range(count):
   u=w*(i+.5)/count;door=floor==0 and i==(count-1)//2
   half=.55 if door else .36;z0=.02 if door else floor*sh+sh*.3;z1=2.05 if door else z0+min(1.05,sh*.42)
   ops.append(dict(face='front',kind='door' if door else 'window',u0=round(u-half,6),u1=round(u+half,6),z0=round(z0,6),z1=round(z1,6)))
 # Preserve the previous rear rectangles; their count/layout remain reconstructed.
 oldb=max(2,min(8,round(w/3.4)));backn=max(1,oldb-1)
 for floor in range(2):
  for i in range(backn):
   u=w*(i+.5)/backn;z0=floor*sh+sh*.3
   ops.append(dict(face='back',kind='window',u0=u-.33,u1=u+.33,z0=z0,z1=z0+min(1.05,sh*.42)))
 f['face_openings']={'value':ops,'confidence':'reconstructed','sources':['whistler_1808_fort_dearborn_draught'],'note':f'Actual 1808 folded facade shows {count} rectangular openings on each of two storeys. Count/face assignment is inferred from that drawing; exact metric set-out, sash/window interpretation and one lower doorway nearest centre are reconstructed, not measured. Even-count ranges choose the left of the two central bays for the door in local facade coordinates; that choice is not asserted historical. Existing rear-window set-out is retained as reconstructed; no primary rear elevation exists. Upper rectangles remain reconstructed windows, not attested gallery doors. Whole explicit attribute is reconstructed because it drives these liberties. Existing local origin, plan, position, bearing, dates, wall heights and gallery geometry unchanged.'}
 p.write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n')
patch=[];ledger=[]
for rel in rels:
 old=(B/rel).read_text();new=(C/rel).read_text();patch+=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel));ledger.append({'path':rel,'baseline_sha256':hashlib.sha256(old.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(new.encode()).hexdigest()})
(H/'face-layout-next.patch').write_text(''.join(patch));(H/'inputs.json').write_text(json.dumps(ledger,indent=2)+'\n');print('Prepared9file overlay after final frozen fort controls; no canonical writes')
