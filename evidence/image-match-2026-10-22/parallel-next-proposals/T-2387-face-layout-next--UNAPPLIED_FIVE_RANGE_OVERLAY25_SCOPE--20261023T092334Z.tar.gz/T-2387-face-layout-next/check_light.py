#!/usr/bin/env python3
from pathlib import Path
from types import ModuleType
from dataclasses import asdict,replace
import ast,copy,inspect,json,sys,hashlib
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;R=Path('/workspace/chicago');S=Path('/tmp/chicago-next-model/fort-selective-integration/staged/candidate');rel='chicago/4d/'
def load(path,name):
 m=ModuleType(name);sys.modules[name]=m;exec(compile(path.read_text(),str(path),'exec'),m.__dict__);return m
pr=rel+'generators/archetypes/fort_structure_params.py';gr=rel+'generators/archetypes/fort_structure.py';a=load(H/'baseline'/pr,'face_old_params');b=load(H/'candidate'/pr,'face_new_params')
assert b.CONSUMED==a.CONSUMED|{'face_openings'}
assert a.FortStructureParams.__match_args__==b.FortStructureParams.__match_args__
for key,p in inspect.signature(b.FortStructureParams).parameters.items():
 if key=='face_openings':assert p.kind==inspect.Parameter.KEYWORD_ONLY and p.default is None
 else:assert p==inspect.signature(a.FortStructureParams).parameters[key]
def functions(p):return {n.name:n for n in ast.parse(p.read_text()).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
af=functions(H/'baseline'/gr);bf=functions(H/'candidate'/gr)
assert set(bf)==set(af)|{'_explicit_openings'}
for name in af:
 if name!='_openings':assert ast.dump(af[name],include_attributes=False)==ast.dump(bf[name],include_attributes=False),name
# Every original non-docstring statement is byte-for-byte AST-identical following the new opt-in return.
assert [ast.dump(n) for n in af['_openings'].body[1:]]==[ast.dump(n) for n in bf['_openings'].body[2:]]
def captures(nodes,p):
 out=[]
 def opening(_builder,axis,plane,u0,u1,z0,z1,outward,conf,kind='window'):
  out.append({'axis':axis,'plane':plane,'u0':u0,'u1':u1,'z0':z0,'z1':z1,'outward':outward,'confidence':conf,'kind':kind})
 namespace={'_opening':opening,'wall_openings':b.wall_openings};tree=ast.Module(body=[nodes[n] for n in ['_openings','_explicit_openings'] if n in nodes],type_ignores=[])
 exec(compile('from __future__ import annotations\n'+ast.unparse(tree),'<actual generator opening functions>','exec'),namespace)
 namespace['_openings'](None,p,p.wall_height_m if not p.overhang_m else p.storey_height_m,p.overhang_m)
 return out
scope=json.loads(Path('/tmp/chicago-next-model/fort-selective-integration/staged/review-manifest.json').read_text())['family_refresh']['assets'];records=[]
for row in scope:
 rr=rel+'data/structures/'+row['structure_id']+'.json';path=S/rr;record=json.loads((path if path.exists() else R/rr).read_text());ph=next(p for p in record['phases'] if p['id']==row['phase_id']);old=a.from_phase(ph,record);new=b.from_phase(ph,record)
 d=asdict(new);assert d.pop('face_openings') is None;assert d==asdict(old)
 assert captures(af,old)==captures(bf,new)
 assert b.front_wall(new) is None
 positional=b.FortStructureParams(*[getattr(old,k) for k in old.__match_args__],**{k:getattr(old,k) for k,p in inspect.signature(a.FortStructureParams).parameters.items() if p.kind==inspect.Parameter.KEYWORD_ONLY});positional.validate();dd=asdict(positional);dd.pop('face_openings');assert dd==asdict(old)
 records.append(row['structure_id'])
counts={'north_range':4,'soldiers_barracks_sw':4,'soldiers_barracks_se':4,'officers_barracks':5,'commanding_officers_barracks':4};changed=[]
for name,count in counts.items():
 rr=rel+'data/structures/first_fort_dearborn_'+name+'.json';oldrec=json.loads((H/'baseline'/rr).read_text());rec=json.loads((H/'candidate'/rr).read_text());ph=rec['phases'][0];oldph=oldrec['phases'][0]
 stripped=copy.deepcopy(rec);del stripped['phases'][0]['form']['face_openings'];assert stripped==oldrec
 p=b.from_phase(ph,rec);before=a.from_phase(oldph,oldrec);capt=captures(bf,p);back=[o for o in capt if o['axis']=='y' and o['outward']==-1];oldback=[o for o in captures(af,before) if o['outward']==-1];assert back==oldback
 front=[o for o in capt if o['outward']==1];wall=b.front_wall(p)
 assert len(front)==2*count==len(wall['openings'])
 for floor in [0,1]:assert sum(floor*2.5<=o['z0']<(floor+1)*2.5 for o in front)==count
 assert sum(o['kind']=='door' for o in front)==1
 assert all(o['confidence']==1.0 for o in capt)
 assert [{k:o[k] for k in ['kind','u0','u1','z0','z1']} for o in front]==wall['openings']
 changed.append({'id':rec['id'],'front_openings_per_storey':count,'front_total':len(front),'back_rectangles_preserved':len(back),'ground_door_width_m':next(o['u1']-o['u0'] for o in front if o['kind']=='door')})
 selected=p
# Invalid/missing/extra keys, geometry, bounds, types and overlaps fail closed.
valid=selected.face_openings[0];invalid=[None,True,{},[{}],[dict(valid,u0=True)],[dict(valid,u0=float('nan'))],[dict(valid,u1=999)],[dict(valid,z1=99)],[dict(valid,face='south')],[dict(valid,kind='windowish')],[valid,dict(valid)], [dict(valid,extra=1)]]
for val in invalid[1:]:
 try:replace(selected,face_openings=val).validate()
 except b.ParamError:pass
 else:raise AssertionError(('invalid accepted',val))
# All four physical face axes are consumed in corresponding local planes, not mirrored aliases.
ops=[dict(face=face,kind='window',u0=.5,u1=1.2,z0=.8,z1=1.8) for face in ['front','back','left','right']]
p=replace(selected,face_openings=ops);p.validate();cc=captures(bf,p)
assert [(x['axis'],x['plane'],x['outward']) for x in cc]==[('y',p.depth_m,1),('y',0.,-1),('x',0.,-1),('x',p.width_m,1)]
# The actual facade dispatcher and signboard phase reader consume the shared function.
sys.path.insert(0,str(R/'chicago/4d/generators'));import archetypes
sys.modules['archetypes.fort_structure_params']=b
fac=load(H/'candidate/chicago/4d/generators/archetypes/facade_openings.py','face_next_facade')
assert fac.front_wall('fort_structure',selected)==b.front_wall(selected)
assert fac.front_wall('fort_structure',b.FortStructureParams(5,5)) is None
assert fac.front_wall('fort_structure',replace(selected,face_openings=[]))['openings']==[]
# Actual signboard _front_wall with temporary data root verifies dates and exact resolver contract.
gbsfunctions=functions(H/'candidate/chicago/4d/tools/generate_business_signboards.py');ns={'STRUCTURES':H/'candidate/chicago/4d/data/structures','_RESOLVERS':{'fort_structure':b.from_phase},'_load':lambda p:json.loads(p.read_text()),'facade_openings':fac,'TARGET_DATE':'1812-07-01'}
exec(compile('from __future__ import annotations\n'+ast.unparse(gbsfunctions['_front_wall']),'<actual signboard phase reader>','exec'),ns)
for row in changed:assert ns['_front_wall'](row['id']) is not None
ns['TARGET_DATE']='1835-07-01'
for row in changed:assert ns['_front_wall'](row['id']) is None
# Actual entrance/overlap readers, with the same front-wall lookup and opening kinds.
from types import SimpleNamespace
entrance_fns=functions(R/'chicago/4d/tools/generate_entrances.py')
ens={'gbs':SimpleNamespace(_front_wall=ns['_front_wall'],facade_openings=fac),'ENTRANCE_KINDS':('door','shop_door','open_bay'),'GROUND_Z_M':.30,'OPENING_GAP_M':.15,'SHOPFRONT':frozenset({'shop_door','show_window'})}
for name in ['front_doors','merged_openings']:
 exec(compile('from __future__ import annotations\n'+ast.unparse(entrance_fns[name]),'<actual entrance reader>','exec'),ens)
ns['TARGET_DATE']='1812-07-01'
for row in changed:
 sc={'id':row['id'],'archetype':'fort_structure'}
 doors,reader=ens['front_doors'](sc)
 assert len(doors)==1 and reader=='facade_openings.fort_structure'
 assert abs(doors[0]['u1']-doors[0]['u0']-1.1)<1e-8
 assert ens['merged_openings'](sc)==[]
ns['TARGET_DATE']='1835-07-01'
for row in changed:
 assert ens['front_doors']({'id':row['id'],'archetype':'fort_structure'})==([],None)
# New front makes source choice explicit; collision/feet/sidecars retain exact bounds and origin.
report={'status':'passed','actual_family_default_params_and_opening_calls_equal':len(records),'legacy16positional_and_existing6keyword_fields_preserved':True,'new_field_keyword_only':True,'all_other_generator_functions_AST_identical':True,'five_records_only_added_face_openings':changed,'all_four_wall_plane_mappings_verified':True,'facade_dispatch_reads_actual_shared_rectangles':True,'legacy_fronts_remain_unread':True,'actual_signboard_phase_reader_1812_reads_and_1835_excludes':True,'actual_entrance_reader_one_ground_door_and_no_overlap_for_each_1812_front':True,'existing1835_entrance_reader_excludes_all5':True,'ground_footprint_position_bearing_dates_and_height_unchanged':True,'new_opening_geometry_confidence_reconstructed':True,'invalid_inputs_and_merged_holes_rejected':True,'default_geometry_equality_is_light_function_proof_not_new_GLB_export':True,'canonical25_recipe_rebake_required_due_module_bytes':True,'blender_or_browser_run':False}
(H/'light-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
