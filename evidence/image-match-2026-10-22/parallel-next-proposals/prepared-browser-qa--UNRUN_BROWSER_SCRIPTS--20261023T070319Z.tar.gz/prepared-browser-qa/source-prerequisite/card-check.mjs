// Prepared only. Parent runs after compile/publish and after the shared browser slot is free.
// One real published-app page per viewport, reused for all three source-only cards.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire('/workspace/node_modules/playwright/package.json');
const {chromium}=require('playwright');
const root=path.resolve(process.env.QA_SITE_ROOT||'/workspace/chicago/site');
const out=path.resolve(process.env.QA_OUT||'/tmp/source-prerequisite/card-check');
fs.mkdirSync(out,{recursive:true});
const cards=['st_marys_church','jb_beaubien_homestead','log_jail'];
const viewports=[['mobile',390,780,true],['desktop',1280,800,false]];
const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.css':'text/css','.wasm':'application/wasm','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.glb':'model/gltf-binary','.ico':'image/x-icon'};
const serverErrors=[];
const server=http.createServer((req,res)=>{
 try {
  const url=new URL(req.url,'http://localhost');
  let file=path.resolve(root,'.'+decodeURIComponent(url.pathname));
  if(file!==root&&!file.startsWith(root+path.sep)){res.writeHead(403).end();return;}
  if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');
  if(!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404).end();return;}
  res.setHeader('Content-Type',types[path.extname(file)]||'application/octet-stream');
  const stream=fs.createReadStream(file);stream.on('error',e=>{serverErrors.push({file,message:e.message});if(!res.headersSent)res.writeHead(500);res.end();});stream.pipe(res);
 }catch(e){serverErrors.push({url:req.url,message:e.message});if(!res.headersSent)res.writeHead(500);res.end();}
});
let browser=null;
const results=[],failures=[];
const write=(name,value)=>fs.writeFileSync(path.join(out,name),typeof value==='string'?value:JSON.stringify(value,null,2)+'\n');
async function pane(page,key){
 await page.locator(`#nav-app-inspect [data-insp-tab="${key}"]`).click();
 await page.waitForFunction(k=>document.querySelector(`#nav-app-inspect [data-insp-pane="${k}"]`)?.dataset.filled==='yes',key,{timeout:45_000,polling:250});
 const target=page.locator(`#nav-app-inspect [data-insp-pane="${key}"]`);assert(await target.isVisible(),`${key} pane not visible`);return target;
}
async function expand(target){
 // Native summaries are clicked. No HTML, citations, grades or content are injected.
 await target.evaluate(p=>{for(const d of p.querySelectorAll('details'))if(!d.open)d.querySelector(':scope > summary')?.click();});
}
async function snapshotPane(page,target,prefix,key){
 const observed=await target.evaluate(p=>({text:p.innerText,links:[...p.querySelectorAll('a')].filter(a=>a.checkVisibility()).map(a=>({text:a.innerText,url:a.href})),visible:p.checkVisibility(),pageOverflow:document.documentElement.scrollWidth>innerWidth+1,paneOverflow:p.clientWidth>0&&p.scrollWidth>p.clientWidth+1}));
 write(`${prefix}-${key}.txt`,observed.text);write(`${prefix}-${key}.json`,observed);
 assert.equal(observed.visible,true);assert.equal(observed.pageOverflow,false,`${prefix} page overflow`);assert.equal(observed.paneOverflow,false,`${prefix} ${key} horizontal overflow`);
 await page.screenshot({path:path.join(out,`${prefix}-${key}.png`)});return observed;
}
async function focusText(target,re){
 await target.evaluate((p,{source,flags})=>{const r=new RegExp(source,flags);const el=[...p.querySelectorAll('p,li,dd,.src-body,.ph-link-list')].find(n=>n.checkVisibility()&&r.test(n.innerText));el?.scrollIntoView({block:'center'});},{source:re.source,flags:re.flags});
}
function checkLoader(data){
 assert.equal(data.scene,'1835');
 const reviews=data.problems.filter(p=>/review_required is set/.test(p));
 assert.deepEqual(reviews.map(p=>p.split(':',1)[0]).sort(),data.expectedReviews,'declared review warning oracle differs');
 const unexpected=data.problems.filter(p=>!/provisional|PLACEHOLDER|placeholder|review_required is set/i.test(p));
 assert.deepEqual(unexpected,[],'unexpected loader problems');return unexpected;
}
try {
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']});
 for(const [label,width,height,touch] of viewports){
  if(process.env.QA_VIEWPORT&&process.env.QA_VIEWPORT!==label)continue;
  const context=await browser.newContext({viewport:{width,height},hasTouch:touch,deviceScaleFactor:1});
  const page=await context.newPage(),errors=[],network=[];
  page.setDefaultTimeout(90_000);
  // The app reads its real persisted Expert research preference at startup.
  await context.addInitScript(()=>localStorage.setItem('chicago4d.researcher','on'));
  page.on('pageerror',e=>errors.push(e.message));
  page.on('response',r=>{if(r.status()>=400)network.push({url:r.url(),status:r.status()});});
  page.on('requestfailed',r=>network.push({url:r.url(),failure:r.failure()}));
  try {
   const response=await page.goto(`http://127.0.0.1:${server.address().port}/4d/walk/index.html?year=1835&keep-geometry=1`);assert.equal(response.status(),200);
   await page.waitForFunction(()=>window.__chicago4d?.ready===true,null,{timeout:240_000,polling:1000});
   await page.evaluate(async()=>{const a=window.__chicago4d,deadline=Date.now()+90_000;while(a.welcome?.state!=='world'&&Date.now()<deadline){if(a.welcome?.state==='welcome')a.welcome.enter('spawn');await new Promise(r=>setTimeout(r,100));}if(a.welcome&&a.welcome.state!=='world')throw Error('welcome did not enter world');document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();});
   assert(await page.locator('html').evaluate(n=>n.hasAttribute('data-researcher-mode')),'real Expert research preference did not initialize');
   for(const sid of cards){
    const prefix=`${label}-${sid}`;let data=null;
    try {
     await page.evaluate(async id=>{const a=window.__chicago4d;a.frame(id);a.pick(id);await a.navigator.select('inspect');a.navigator.open(2);},sid);
     await page.waitForFunction(id=>document.querySelector('#nav-app-inspect')?.dataset.structure===id&&!!document.querySelector('#nav-app-inspect [data-insp-tab="photos"]'),sid,{timeout:45_000,polling:250});
     data=await page.evaluate(id=>{const a=window.__chicago4d,s=a.registry.get(id)?.sidecar;return {grade:s?.grade,attributes:s?.attributes,problems:a.problems??[],expectedReviews:[...a.registry.values()].filter(r=>r.sidecar?.review_required).map(r=>r.sidecar.id).sort(),scene:a.scene?.id};},sid);
     const unexpected=checkLoader(data);
     await page.locator('#nav-app-inspect [data-insp-tab="overview"]').click();
     const overview=await snapshotPane(page,page.locator('#nav-app-inspect [data-insp-pane="overview"]'),prefix,'overview');
     const story=await snapshotPane(page,await pane(page,'story'),prefix,'story');
     const photosPane=await pane(page,'photos');await expand(photosPane);
     const photos=await snapshotPane(page,photosPane,prefix,'photos');
     const sourcesPane=await pane(page,'sources');await expand(sourcesPane);
     const sources=await snapshotPane(page,sourcesPane,prefix,'sources');
     const researchPane=await pane(page,'research');
     // Open the record fold and its real research-note disclosure only; enormous
     // unrelated liberties stay folded. This is rendered reader-copy content.
     await researchPane.evaluate(p=>{for(const d of p.querySelectorAll('details.insp-fold'))if(d.querySelector(':scope > summary')?.innerText.trim()==='Record'&&!d.open)d.querySelector(':scope > summary').click();for(const d of p.querySelectorAll('details.research'))if(!d.open)d.querySelector(':scope > summary')?.click();});
     const research=await snapshotPane(page,researchPane,prefix,'research');
     assert.match(research.text,/The record.s own account/i,'real Research disclosure missing');
     if(sid==='st_marys_church'){
      assert.equal(data.grade?.value,'attested');assert(data.grade.pictures?.length>0,'whole-building picture basis missing');
      assert.equal(data.attributes?.tower?.value,false);assert.equal(data.attributes?.tower?.confidence,'inferred');
      const tower=await sourcesPane.evaluate(p=>{const l=[...p.querySelectorAll('.src-label')].find(n=>n.innerText.trim()==='Tower');const d=l?.closest('details.src-fact');return d?{grade:d.dataset.grade,text:d.innerText}:null;});
      assert.equal(tower?.grade,'inferred','Sources must display tower as inferred');
      assert.match(research.text,/Grade\s+Attested\b/i,'whole-building grade not actually visible');
      assert.match(photos.text,/Moss\s+Engraving/i,'Images Moss credit missing');assert.match(photos.text,/Andreas/i,'Images Andreas credit missing');assert.match(photos.text,/1884/,'Images publication credit missing');
      assert(photos.links.some(a=>/chicagology\.com\/prefire\/prefire216|archive\.org\/(?:details|download)\/historyofchicago01andr/i.test(a.url)),'Images must expose real reproduction/original source link');
      assert.match(research.text,/some\s*time\s*afterwards/i);assert.match(research.text,/inferred|conservative/i);
      await focusText(researchPane,/SOURCE REASSESSMENT|CONSERVATIVE 1835|tower absence/i);
     }else if(sid==='jb_beaubien_homestead'){
      assert.equal(data.grade?.value,'inferred');
      assert.match(story.text,/no date for when it was built/i,'Story must preserve unknown construction date');
      assert.doesNotMatch(story.text,/built\s+(?:in\s+)?1817|oldest\s+(?:house|building)/i,'Story invents old construction rationale');
      assert.match(research.text,/precise building identity and construction year remain unresolved|exact identity and construction date remain unresolved|identity.*unresolved/i);
      assert.match(research.text,/1817 purchase belongs to the Dean house|1817 purchase concerned the separate Dean house/i);
      assert.match(research.text,/1822 is an earliest allowed date|1822 is.*lower bound|1822.*not.*(?:built|building date|construction date)/i);
      assert.match(photos.text,/unresolved.*Beaubien|Beaubien.*unresolved/i,'Images context identity limit missing');
      assert.match(photos.text,/Kinzie|Wau.?Bun/i,'Images context credit missing');
      assert(photos.links.some(a=>/commons\.wikimedia\.org\/wiki\/File:Fort_Dearborn.*Chicago_in_1831/i.test(a.url)),'existing contextual panorama link missing');
      await focusText(researchPane,/CURRENT IDENTITY AND IMAGE LIMIT|precise building identity/i);
     }else{
      assert.equal(data.grade?.value,'inferred');
      assert.match(research.text,/Keystone.Mast Collection/i,'collection credit not visible in Research');
      assert.match(research.text,/UCR\s*\/\s*California Museum of Photography/i,'UCR credit not visible');
      assert.match(research.text,/University of California at Riverside/i,'required institution credit not visible');
      assert.match(research.text,/19 September 1930|September 19,? 1930/i,'catalogued copy date not visible');
      assert.match(research.text,/does not establish publication in 1930|not.*(?:prove|establish).*publication/i,'copy date/publication limit missing');
      assert.match(research.text,/reuse licen[cs]e|rights.*(?:unresolved|research|hold)|rights status.*check/i,'rights limit missing');
      assert.match(research.text,/No new geometry or asset is derived|no.*(?:geometry|asset).*derived/i,'text-only/no-new-derivation limit missing');
      assert.match(research.text,/FALL 1835|fall of 1835/i,'courthouse chronology missing');
      // Catalogue facts are currently disclosed in Research, not a fabricated
      // typed source/context anchor. Actual Photos links are recorded verbatim.
      await focusText(researchPane,/IMAGE RESEARCH.*RIGHTS CORRECTION|Keystone.Mast Collection/i);
     }
     await page.screenshot({path:path.join(out,`${prefix}-research-focused.png`)});
     assert.deepEqual(errors,[],'page errors');assert.deepEqual(network,[],'failed HTTP/network requests');assert.deepEqual(serverErrors,[],'local serving errors');
     results.push({status:'PASS',structure_id:sid,viewport:label,width,height,grade:data.grade,tower:sid==='st_marys_church'?data.attributes.tower:null,declared_review_records:data.expectedReviews,unexpected_loader_problems:unexpected,page_errors:[...errors],network_errors:[...network],visible_overview:overview.text,visible_story:story.text,images_links:photos.links,source_links:sources.links,research_credit_checked:true,screenshot_prefix:prefix});
     write(`${prefix}-result.json`,results.at(-1));console.log(`${label}: ${sid} actual source/grade/card disclosures passed`);
    }catch(e){
     const failed={status:'FAIL',structure_id:sid,viewport:label,message:e.message,stack:e.stack,data,page_errors:[...errors],network_errors:[...network]};failures.push(failed);write(`${prefix}-failure.json`,failed);await page.screenshot({path:path.join(out,`${prefix}-failure.png`)}).catch(()=>{});console.error(`${label}: ${sid}: ${e.message}`);
    }
   }
  }finally{await context.close();}
 }
 const expected=cards.length*viewports.filter(([label])=>!process.env.QA_VIEWPORT||process.env.QA_VIEWPORT===label).length;
 assert.equal(results.length+failures.length,expected,'not all selected card/viewport cases executed');
 write('results.json',{status:failures.length?'FAIL':'PASS',scope:'Three source-prerequisite cards in the actual published 1835 app; one reused page per viewport. Not full renderer smoke or model/image acceptance.',root,expected_cases:expected,passed:results.length,failed:failures.length,results,failures,serverErrors});
 if(failures.length)throw new AggregateError(failures.map(f=>Error(`${f.viewport}/${f.structure_id}: ${f.message}`)),`${failures.length} card checks failed; see results.json`);
}catch(e){
 write('runner-failure.json',{status:'FAIL',message:e.message,stack:e.stack,passed_cases:results.length,failed_cases:failures.length,serverErrors});
 throw e;
}finally{
 try{if(browser)await browser.close();}
 finally{server.closeAllConnections?.();if(server.listening)await new Promise(resolve=>server.close(resolve));}
}
