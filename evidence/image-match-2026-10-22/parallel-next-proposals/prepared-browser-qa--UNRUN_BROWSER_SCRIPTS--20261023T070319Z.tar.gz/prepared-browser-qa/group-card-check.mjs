// Prepared only. Parent runs after compile/publish and after the shared browser slot is free.
// One real published-app page per viewport, reused for all three source-only cards.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire('/workspace/node_modules/playwright/package.json');
const {chromium}=require('playwright');
const root=path.resolve(process.env.QA_SITE_ROOT||'/workspace/chicago/site');
const out=path.resolve(process.env.QA_OUT||'/tmp/frame-integration/group-card-check');
fs.mkdirSync(out,{recursive:true});
const cards=['st_marys_church','jb_beaubien_homestead','log_jail','green_tree_tavern','sauganash_hotel','tremont_house_1'];
const expectedHotels=JSON.parse(fs.readFileSync(new URL('./group-card-expected.json',import.meta.url),'utf8')).hotels;
const viewports=[['mobile',390,780,true],['desktop',1280,800,false]];
assert(!process.env.QA_VIEWPORT,'Grouped acceptance requires both viewports; unset QA_VIEWPORT');
const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.css':'text/css','.wasm':'application/wasm','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp','.glb':'model/gltf-binary','.ico':'image/x-icon'};
const serverErrors=[];
const server=http.createServer((req,res)=>{
 try {
  const url=new URL(req.url,'http://localhost');
  let file=path.resolve(root,'.'+decodeURIComponent(url.pathname));
  if(file!==root&&!file.startsWith(root+path.sep)){res.writeHead(403).end();return;}
  if(fs.existsSync(file)&&fs.statSync(file).isDirectory())file=path.join(file,'index.html');
  if(!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404).end();return;}
  res.setHeader('Content-Type',types[path.extname(file)]||'application/octet-stream');
  const stream=fs.createReadStream(file);stream.on('error',e=>{serverErrors.push({file,message:e.message});if(!res.headersSent)res.writeHead(500);res.end();});stream.pipe(res);
 }catch(e){serverErrors.push({url:req.url,message:e.message});if(!res.headersSent)res.writeHead(500);res.end();}
});
let browser=null;
const results=[],failures=[];
const write=(name,value)=>fs.writeFileSync(path.join(out,name),typeof value==='string'?value:JSON.stringify(value,null,2)+'\n');
async function pane(page,key){
 await page.locator(`#nav-app-inspect [data-insp-tab="${key}"]`).click();
 await page.waitForFunction(k=>document.querySelector(`#nav-app-inspect [data-insp-pane="${k}"]`)?.dataset.filled==='yes',key,{timeout:45_000,polling:250});
 const target=page.locator(`#nav-app-inspect [data-insp-pane="${key}"]`);assert(await target.isVisible(),`${key} pane not visible`);return target;
}
async function expand(target){
 // Native summaries are clicked. No HTML, citations, grades or content are injected.
 await target.evaluate(p=>{for(const d of p.querySelectorAll('details'))if(!d.open)d.querySelector(':scope > summary')?.click();});
}
async function snapshotPane(page,target,prefix,key){
 const observed=await target.evaluate(p=>({text:p.innerText,links:[...p.querySelectorAll('a')].filter(a=>a.checkVisibility()).map(a=>({text:a.innerText,url:a.href})),visible:p.checkVisibility(),pageOverflow:document.documentElement.scrollWidth>innerWidth+1,paneOverflow:p.clientWidth>0&&p.scrollWidth>p.clientWidth+1}));
 write(`${prefix}-${key}.txt`,observed.text);write(`${prefix}-${key}.json`,observed);
 assert.equal(observed.visible,true);assert.equal(observed.pageOverflow,false,`${prefix} page overflow`);assert.equal(observed.paneOverflow,false,`${prefix} ${key} horizontal overflow`);
 await page.screenshot({path:path.join(out,`${prefix}-${key}.png`)});return observed;
}
async function focusText(target,re){
 await target.evaluate((p,{source,flags})=>{const r=new RegExp(source,flags);const el=[...p.querySelectorAll('p,li,dd,.src-body,.ph-link-list')].find(n=>n.checkVisibility()&&r.test(n.innerText));el?.scrollIntoView({block:'center'});},{source:re.source,flags:re.flags});
}
function checkLoader(data){
 assert.equal(data.scene,'1835');
 const reviews=data.problems.filter(p=>/review_required is set/.test(p));
 assert.deepEqual(reviews.map(p=>p.split(':',1)[0]).sort(),data.expectedReviews,'declared review warning oracle differs');
 const unexpected=data.problems.filter(p=>!/provisional|PLACEHOLDER|placeholder|review_required is set/i.test(p));
 assert.deepEqual(unexpected,[],'unexpected loader problems');return unexpected;
}
async function captureScene(page,sid,prefix){
 await page.evaluate(async id=>{const a=window.__chicago4d;a.navigator.dock();a.setConfidenceView(false);a.setAnimationHold(true);if(!a.frame(id))throw Error(`cannot frame ${id}`);await a.capture(1);},sid);
 await page.screenshot({path:path.join(out,`${prefix}-scene-normal.png`)});
 if(sid!=='tremont_house_1')return;
 const probe=async on=>page.evaluate(async({id,on})=>{
  const a=window.__chicago4d,need=(v,msg)=>{if(!v)throw Error(msg);};
  const record=a.registry.get(id),anchor=record?.sidecar?.attributes?.flag_anchor?.value;
  need(anchor,'real sidecar flag anchor missing');
  const layer=a.flags,mesh=a.scene3d.getObjectByName(`flag:${id}`);
  need(layer?.group&&mesh?.isMesh,'actual flag mesh/layer missing');
  need(layer.group.getObjectByName(mesh.name)===mesh,'flag mesh is outside actual flag layer');
  let attached=false;for(let node=mesh;node;node=node.parent)if(node===a.scene3d)attached=true;
  need(attached,'flag mesh is detached from rendered scene');
  for(let node=mesh;node;node=node.parent)need(node.visible!==false,`hidden flag ancestor: ${node.name}`);
  need(mesh.material.visible!==false,'flag material hidden');
  const matrix=a.buildings.matrixOf(id),box=a.buildings.instanceBounds()[id];need(matrix&&box,'actual built Tremont placement/bounds missing');
  const v=()=>a.camera.position.clone();
  const map=p=>v().set(p[0],p[2],-p[1]);
  const head=map(anchor.head).applyMatrix4(matrix),foot=map(anchor.foot).applyMatrix4(matrix);
  const expected=head.clone();expected.y-=.18;
  need(mesh.parent.position.distanceTo(expected)<1e-6,'actual cloth holder disagrees with transformed explicit staff head');
  need(Math.abs(mesh.position.x-anchor.radius_m)<1e-8,'actual cloth does not stand off spar by explicit radius');
  for(const p of [anchor.head,anchor.foot]){
   const q=[p[0],p[2],-p[1]];need(q.every((value,i)=>value>=box.min[i]-.03&&value<=box.max[i]+.03),'explicit staff anchor outside actual model bounds');
  }
  const drawn=layer.drawn.filter(f=>f.id===id);need(drawn.length===1,'Tremont flag layer has missing/duplicate drawn entry');
  need(drawn[0].pattern==='us_flag_24_star'&&drawn[0].confidence===1,'drawn pattern/grade differs');
  need(drawn[0].fly_m===anchor.fly_m&&drawn[0].hoist_m===anchor.hoist_m,'drawn cloth dimensions differ');
  const geo=mesh.geometry,conf=geo.getAttribute('_confidence'),pos=geo.getAttribute('position');
  need(conf&&conf.count===pos.count&&conf.itemSize===1,'actual cloth confidence stream invalid');
  const values=new Set();for(let i=0;i<conf.count;i++)values.add(conf.getX(i));
  need(values.size===1&&values.has(1),'cloth stream promotes reconstructed colour to a better grade');
  a.scene3d.updateMatrixWorld(true);a.camera.updateMatrixWorld(true);
  const projected=[];
  for(let i=0;i<pos.count;i++){
   const point=v().fromBufferAttribute(pos,i);mesh.localToWorld(point);point.project(a.camera);
   projected.push([point.x,point.y,point.z]);
  }
  const visible=projected.filter(p=>p[0]>=-1&&p[0]<=1&&p[1]>=-1&&p[1]<=1&&p[2]>=-1&&p[2]<=1);
  need(visible.length>0,'actual flag geometry is outside the live camera');
  const min=[0,1].map(k=>Math.min(...projected.map(p=>p[k]))),max=[0,1].map(k=>Math.max(...projected.map(p=>p[k])));
  const projectedPx={width:(max[0]-min[0])*innerWidth/2,height:(max[1]-min[1])*innerHeight/2};
  need(projectedPx.width>=1&&projectedPx.height>=1,'actual roof cloth projects below one pixel; review framing rather than accepting metadata alone');
  const observations=[],prior=mesh.onAfterRender;
  mesh.onAfterRender=function(renderer,scene,camera,geometry,material,group){
   if(typeof prior==='function')prior.call(this,renderer,scene,camera,geometry,material,group);
   // Observe the actual draw's compiled GPU program, without invoking a fake
   // hook/program or changing the app material. Errors are thrown outside the
   // render loop so a failed probe cannot stop the application renderer.
   try{
    const gl=renderer.getContext(),program=renderer.properties.get(material).currentProgram;
    const uniform=name=>{const location=gl.getUniformLocation(program.program,name);if(location===null)throw Error(`actual flag GPU uniform missing: ${name}`);const value=gl.getUniform(program.program,location);return ArrayBuffer.isView(value)?[...value]:value;};
    const vertex=gl.getShaderSource(program.vertexShader)||'',fragment=gl.getShaderSource(program.fragmentShader)||'';
    observations.push({linked:gl.getProgramParameter(program.program,gl.LINK_STATUS),confidenceMode:uniform('uConfMode'),gradeModes:uniform('uGradeMode'),gradeOpacity:uniform('uGradeOpacity'),hiddenLevels:uniform('uHideLevel'),actualVertexConfidence:/_confidence/.test(vertex)&&/vConfidence/.test(vertex),actualFragmentConfidence:/vConfidence/.test(fragment)&&/discard/.test(fragment),flagTime:renderer.properties.get(material).uniforms?.uFlagTime?.value??null});
   }catch(e){observations.push({error:e.message});}
  };
  try{a.setConfidenceView(on);await a.capture(1);}finally{mesh.onAfterRender=prior;}
  need(observations.length>0,'actual flag mesh was not drawn by the application');
  const rendered=observations.at(-1);need(!rendered.error,rendered.error);need(rendered.linked,'actual flag shader did not link');
  need(rendered.actualVertexConfidence&&rendered.actualFragmentConfidence,'actual rendered flag shader omitted confidence controls');
  need(rendered.confidenceMode===(on?1:0),'actual flag GPU confidence mode disagrees with view');
  if(on){need(rendered.gradeModes[2]===2,'reconstructed cloth is not actually dithered');need(Math.abs(rendered.gradeOpacity[2]-.34)<1e-5,'reconstructed cloth opacity differs from default By grade');need(rendered.hiddenLevels[2]===0,'reconstructed cloth hidden instead of honestly shown');}
  return {source:'actual published app scene graph, material draw hook and actual linked GPU uniforms',mode:on?'bygrade':'normal',drawn:drawn[0],anchor,actual_model_bounds:box,expected_world_staff_head:head.toArray(),expected_world_staff_foot:foot.toArray(),actual_holder:mesh.parent.position.toArray(),cloth_confidence_values:[...values],cloth_vertices:pos.count,projected_px:projectedPx,draw_observations:observations,limits:'Projected static mesh bounds omit shader flutter. Actual draw callback and linked GPU uniforms prove app drawing/control integration; screenshots still require visual review and do not constitute source-image acceptance.'};
 },{id:sid,on});
 try{
  const normal=await probe(false);write(`${prefix}-flag-normal.json`,normal);
  await page.screenshot({path:path.join(out,`${prefix}-flag-normal.png`)});
  const confidence=await probe(true);write(`${prefix}-flag-confidence.json`,confidence);
  await page.screenshot({path:path.join(out,`${prefix}-scene-confidence.png`)});
 }finally{await page.evaluate(async()=>{const a=window.__chicago4d;a.setConfidenceView(false);await a.capture(1);});}
}

try {
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader']});
 for(const [label,width,height,touch] of viewports){
  if(process.env.QA_VIEWPORT&&process.env.QA_VIEWPORT!==label)continue;
  const context=await browser.newContext({viewport:{width,height},hasTouch:touch,deviceScaleFactor:1});
  const page=await context.newPage(),errors=[],network=[];
  page.setDefaultTimeout(90_000);
  // The app reads its real persisted Expert research preference at startup.
  await context.addInitScript(()=>localStorage.setItem('chicago4d.researcher','on'));
  page.on('pageerror',e=>errors.push(e.message));
  page.on('response',r=>{if(r.status()>=400)network.push({url:r.url(),status:r.status()});});
  page.on('requestfailed',r=>network.push({url:r.url(),failure:r.failure()}));
  try {
   const response=await page.goto(`http://127.0.0.1:${server.address().port}/4d/walk/index.html?year=1835&keep-geometry=1`);assert.equal(response.status(),200);
   await page.waitForFunction(()=>window.__chicago4d?.ready===true,null,{timeout:240_000,polling:1000});
   await page.evaluate(async()=>{const a=window.__chicago4d,deadline=Date.now()+90_000;while(a.welcome?.state!=='world'&&Date.now()<deadline){if(a.welcome?.state==='welcome')a.welcome.enter('spawn');await new Promise(r=>setTimeout(r,100));}if(a.welcome&&a.welcome.state!=='world')throw Error('welcome did not enter world');document.exitPointerLock?.();document.getElementById('control-help-gotit')?.click();});
   assert(await page.locator('html').evaluate(n=>n.hasAttribute('data-researcher-mode')),'real Expert research preference did not initialize');
   for(const sid of cards){
    const prefix=`${label}-${sid}`;let data=null;
    try {
     await captureScene(page,sid,prefix);
     await page.evaluate(async id=>{const a=window.__chicago4d;a.pick(id);await a.navigator.select('inspect');a.navigator.open(2);},sid);
     await page.waitForFunction(id=>document.querySelector('#nav-app-inspect')?.dataset.structure===id&&!!document.querySelector('#nav-app-inspect [data-insp-tab="photos"]'),sid,{timeout:45_000,polling:250});
     data=await page.evaluate(id=>{const a=window.__chicago4d,s=a.registry.get(id)?.sidecar;return {phase:s?.phase,grade:s?.grade,attributes:s?.attributes,problems:a.problems??[],expectedReviews:[...a.registry.values()].filter(r=>r.sidecar?.review_required).map(r=>r.sidecar.id).sort(),scene:a.scene?.id};},sid);
     const unexpected=checkLoader(data);
     await page.locator('#nav-app-inspect [data-insp-tab="overview"]').click();
     const overview=await snapshotPane(page,page.locator('#nav-app-inspect [data-insp-pane="overview"]'),prefix,'overview');
     const story=await snapshotPane(page,await pane(page,'story'),prefix,'story');
     const photosPane=await pane(page,'photos');await expand(photosPane);
     const photos=await snapshotPane(page,photosPane,prefix,'photos');
     const sourcesPane=await pane(page,'sources');await expand(sourcesPane);
     const sources=await snapshotPane(page,sourcesPane,prefix,'sources');
     const researchPane=await pane(page,'research');
     // Open the record fold and its real research-note disclosure only; enormous
     // unrelated liberties stay folded. This is rendered reader-copy content.
     await researchPane.evaluate(p=>{for(const d of p.querySelectorAll('details.insp-fold'))if(d.querySelector(':scope > summary')?.innerText.trim()==='Record'&&!d.open)d.querySelector(':scope > summary').click();for(const d of p.querySelectorAll('details.research'))if(!d.open)d.querySelector(':scope > summary')?.click();});
     const research=await snapshotPane(page,researchPane,prefix,'research');
     assert.match(research.text,/The record.s own account/i,'real Research disclosure missing');
     if(sid==='st_marys_church'){
      assert.equal(data.grade?.value,'attested');assert(data.grade.pictures?.length>0,'whole-building picture basis missing');
      assert.equal(data.attributes?.tower?.value,false);assert.equal(data.attributes?.tower?.confidence,'inferred');
      const tower=await sourcesPane.evaluate(p=>{const l=[...p.querySelectorAll('.src-label')].find(n=>n.innerText.trim()==='Tower');const d=l?.closest('details.src-fact');return d?{grade:d.dataset.grade,text:d.innerText}:null;});
      assert.equal(tower?.grade,'inferred','Sources must display tower as inferred');
      assert.match(research.text,/Grade\s+Attested\b/i,'whole-building grade not actually visible');
      assert.match(photos.text,/Moss\s+Engraving/i,'Images Moss credit missing');assert.match(photos.text,/Andreas/i,'Images Andreas credit missing');assert.match(photos.text,/1884/,'Images publication credit missing');
      assert(photos.links.some(a=>/chicagology\.com\/prefire\/prefire216|archive\.org\/(?:details|download)\/historyofchicago01andr/i.test(a.url)),'Images must expose real reproduction/original source link');
      assert.match(research.text,/some\s*time\s*afterwards/i);assert.match(research.text,/inferred|conservative/i);
      await focusText(researchPane,/SOURCE REASSESSMENT|CONSERVATIVE 1835|tower absence/i);
     }else if(sid==='jb_beaubien_homestead'){
      assert.equal(data.grade?.value,'inferred');
      assert.match(story.text,/no date for when it was built/i,'Story must preserve unknown construction date');
      assert.doesNotMatch(story.text,/built\s+(?:in\s+)?1817|oldest\s+(?:house|building)/i,'Story invents old construction rationale');
      assert.match(research.text,/precise building identity and construction year remain unresolved|exact identity and construction date remain unresolved|identity.*unresolved/i);
      assert.match(research.text,/1817 purchase belongs to the Dean house|1817 purchase concerned the separate Dean house/i);
      assert.match(research.text,/1822 is an earliest allowed date|1822 is.*lower bound|1822.*not.*(?:built|building date|construction date)/i);
      assert.match(photos.text,/unresolved.*Beaubien|Beaubien.*unresolved/i,'Images context identity limit missing');
      assert.match(photos.text,/Kinzie|Wau.?Bun/i,'Images context credit missing');
      assert(photos.links.some(a=>/commons\.wikimedia\.org\/wiki\/File:Fort_Dearborn.*Chicago_in_1831/i.test(a.url)),'existing contextual panorama link missing');
      await focusText(researchPane,/CURRENT IDENTITY AND IMAGE LIMIT|precise building identity/i);
     }else if(sid==='log_jail'){
      assert.equal(data.grade?.value,'inferred');
      assert.match(research.text,/Keystone.Mast Collection/i,'collection credit not visible in Research');
      assert.match(research.text,/UCR\s*\/\s*California Museum of Photography/i,'UCR credit not visible');
      assert.match(research.text,/University of California at Riverside/i,'required institution credit not visible');
      assert.match(research.text,/19 September 1930|September 19,? 1930/i,'catalogued copy date not visible');
      assert.match(research.text,/does not establish publication in 1930|not.*(?:prove|establish).*publication/i,'copy date/publication limit missing');
      assert.match(research.text,/reuse licen[cs]e|rights.*(?:unresolved|research|hold)|rights status.*check/i,'rights limit missing');
      assert.match(research.text,/No new geometry or asset is derived|no.*(?:geometry|asset).*derived/i,'text-only/no-new-derivation limit missing');
      assert.match(research.text,/FALL 1835|fall of 1835/i,'courthouse chronology missing');
      // Catalogue facts are currently disclosed in Research, not a fabricated
      // typed source/context anchor. Actual Photos links are recorded verbatim.
      await focusText(researchPane,/IMAGE RESEARCH.*RIGHTS CORRECTION|Keystone.Mast Collection/i);
     }else{
      const wanted=expectedHotels[sid];assert(wanted,'hotel expectation missing');
      assert.equal(data.phase,wanted.phase);assert.equal(data.grade?.value,wanted.grade);assert(data.grade.pictures?.length>0,'hotel whole-picture grade basis missing');
      for(const [key,claim] of Object.entries(wanted.attributes)){
       assert.deepEqual(data.attributes?.[key]?.value,claim.value,`${sid} ${key} value`);
       assert.equal(data.attributes?.[key]?.confidence,claim.confidence,`${sid} ${key} confidence`);
      }
      const displayed=await sourcesPane.evaluate(p=>[...p.querySelectorAll('details.src-fact')].map(d=>({label:d.querySelector('.src-label')?.innerText.trim(),grade:d.dataset.grade})));
      write(`${prefix}-displayed-source-grades.json`,displayed);
      const plain=key=>key.replaceAll('_',' ').toLowerCase();
      const normalized=label=>String(label||'').toLowerCase().replace(/[()]/g,'').trim();
      for(const key of sid==='green_tree_tavern'?['eaves_bays','gable_wall_cladding']:sid==='sauganash_hotel'?['end_windows','gable_wall_cladding']:['flag','flag_anchor','flag_flying','flagstaff','entry_raise_m','gable_arch_treatment']){
       const fact=displayed.find(f=>normalized(f.label)===plain(key));
       assert(fact,`${sid} actual Sources fact missing: ${key}`);assert.equal(fact.grade,wanted.attributes[key].confidence,`${sid} visible Sources grade ${key}`);
      }
      assert.match(research.text,/Grade\s+Attested\b/i,'hotel whole-building grade not visible');
      if(sid==='tremont_house_1'){
       assert.match(photos.text,/Gifford/i,'actual Gifford image credit missing');
       assert(photos.links.some(a=>/chicagology\.com\/prefire\/prefire021/i.test(a.url)),'actual Tremont source link missing');
       for(const key of ['flag','flag_anchor','flag_flying'])assert(!['record_only','absent','simplified'].includes(data.attributes[key].geometry),`${key} falsely marked unbuilt`);
       await focusText(researchPane,/Gifford|flag|reconstruct/i);
      }else{
       assert.match(photos.text,/Andreas/i,'actual Andreas image credit missing');assert.match(photos.text,/1884/,'actual 1884 publication credit missing');
       assert(photos.links.some(a=>/archive\.org\/(?:details|download)\/historyofchicago01andr/i.test(a.url)),'actual Andreas plate source link missing');
       await focusText(researchPane,/reconstruct|Andreas/i);
      }
     }
     await page.screenshot({path:path.join(out,`${prefix}-research-focused.png`)});
     assert.deepEqual(errors,[],'page errors');assert.deepEqual(network,[],'failed HTTP/network requests');assert.deepEqual(serverErrors,[],'local serving errors');
     results.push({status:'PASS',structure_id:sid,viewport:label,width,height,grade:data.grade,tower:sid==='st_marys_church'?data.attributes.tower:null,declared_review_records:data.expectedReviews,unexpected_loader_problems:unexpected,page_errors:[...errors],network_errors:[...network],visible_overview:overview.text,visible_story:story.text,images_links:photos.links,source_links:sources.links,research_credit_checked:true,hotel_expected_attributes:sid in expectedHotels?expectedHotels[sid].attributes:null,screenshot_prefix:prefix});
     write(`${prefix}-result.json`,results.at(-1));console.log(`${label}: ${sid} actual source/grade/card disclosures passed`);
    }catch(e){
     const failed={status:'FAIL',structure_id:sid,viewport:label,message:e.message,stack:e.stack,data,page_errors:[...errors],network_errors:[...network]};failures.push(failed);write(`${prefix}-failure.json`,failed);await page.screenshot({path:path.join(out,`${prefix}-failure.png`)}).catch(()=>{});console.error(`${label}: ${sid}: ${e.message}`);
    }
   }
  }finally{await context.close();}
 }
 const expected=cards.length*viewports.filter(([label])=>!process.env.QA_VIEWPORT||process.env.QA_VIEWPORT===label).length;
 assert.equal(results.length+failures.length,expected,'not all selected card/viewport cases executed');
 write('results.json',{status:failures.length?'FAIL':'PASS',scope:'Six grouped source/frame prerequisite cards in the actual published 1835 app; one reused page per viewport. Not full renderer smoke or model/image acceptance.',root,expected_cases:expected,passed:results.length,failed:failures.length,results,failures,serverErrors});
 if(failures.length)throw new AggregateError(failures.map(f=>Error(`${f.viewport}/${f.structure_id}: ${f.message}`)),`${failures.length} card checks failed; see results.json`);
}catch(e){
 write('runner-failure.json',{status:'FAIL',message:e.message,stack:e.stack,passed_cases:results.length,failed_cases:failures.length,serverErrors});
 throw e;
}finally{
 try{if(browser)await browser.close();}
 finally{server.closeAllConnections?.();if(server.listening)await new Promise(resolve=>server.close(resolve));}
}
