# Prepared browser QA scripts — UNRUN

This is a script-only recovery packet. No browser was launched, no app content
was snapshotted and no claim/ticket changed. The grouped script, frozen expected
values, exact README/checkpoint, scene helper and prepare source are preserved.
The separate source-only card script is retained under source-prerequisite/.
Every copied source byte/hash matches its original at freeze time.

Grouped checks cover six cases at both mobile 390×780 and desktop 1280×800, with
actual Photos/Sources/Research and rendered flag GPU confidence/anchor checks.
Read group-card-check-README.md before execution; restore/adapt the documented
absolute paths in a separate review environment. Execute only after final
source/feature adoption, official build, compilation/publishing and parent slot
release. A prepared script is not a completed browser acceptance result.

Parent reports source-S's prior gate had one stale loading-fact failure among 1049
checks. The card fact and focused tests were corrected; its current ordered tail
and final full gate remain pending. This packet copies no live source-S app files
or midproducer output. Parent will checkpoint actual source code after its gate.
