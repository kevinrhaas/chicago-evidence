"""Freeze reviewable diffs from package baselines; does not read the live checkout."""
import pathlib,difflib
P=pathlib.Path(__file__).parent;D=P/'proposed/chicago/4d'
rels=['renderers/web/js/flag-anchors.js','renderers/web/js/flags.js','tools/test_flag_anchors.mjs','tools/flag_form_contract.py','tools/validate.py','tools/compile_scene.py','tools/test_flag_form_contract.py']
patch=''
for rel in rels:
 b=P/'baseline'/pathlib.Path(rel).name;before=b.read_text().splitlines(True) if b.exists() else []
 patch+=''.join(difflib.unified_diff(before,(D/rel).read_text().splitlines(True),fromfile='a/chicago/4d/'+rel if before else '/dev/null',tofile='b/chicago/4d/'+rel))
(P/'flag-layer.patch').write_text(patch)
rel='data/structures/tremont_house_1.json'
(P/'T-2385-flag-opt-in.patch').write_text(''.join(difflib.unified_diff((P/'baseline/tremont_house_1.json').read_text().splitlines(True),(D/rel).read_text().splitlines(True),fromfile='a/chicago/4d/'+rel,tofile='b/chicago/4d/'+rel)))
print('Frozen flag-layer/consumer-contract and after-third opt-in patches refreshed')
