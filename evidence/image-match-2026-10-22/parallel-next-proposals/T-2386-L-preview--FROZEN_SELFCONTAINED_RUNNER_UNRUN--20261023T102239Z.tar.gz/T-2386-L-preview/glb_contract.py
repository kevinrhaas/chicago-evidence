"""Frozen decoded GLB contract essentials; no file IO at import."""
import json,math,struct

def read(path):
 raw=path.read_bytes();magic,version,total=struct.unpack_from('<III',raw)
 assert magic==0x46546c67 and version==2 and total==len(raw),path
 at=12;doc=None;binary=None
 while at<len(raw):
  size,kind=struct.unpack_from('<II',raw,at);chunk=raw[at+8:at+8+size]
  if kind==0x4e4f534a:doc=json.loads(chunk)
  if kind==0x004e4942:binary=chunk
  at+=8+size
 assert doc['asset']['version']=='2.0' and binary is not None
 return doc,binary

arity={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}

formats={5120:'b',5121:'B',5122:'h',5123:'H',5125:'I',5126:'f'}

def payload(doc,binary,index):
 a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']]
 assert v.get('buffer',0)==0 and not a.get('sparse')
 n=arity[a['type']];fmt=formats[a['componentType']];width=struct.calcsize('<'+fmt)*n
 stride=v.get('byteStride',width);offset=v.get('byteOffset',0)+a.get('byteOffset',0)
 assert offset+(a['count']-1)*stride+width<=len(binary)
 return b''.join(binary[offset+i*stride:offset+i*stride+width] for i in range(a['count']))

def values(doc,binary,index):
 a=doc['accessors'][index];fmt=formats[a['componentType']]
 data=payload(doc,binary,index);return list(struct.unpack('<'+fmt*(len(data)//struct.calcsize(fmt)),data))

def summary(doc,binary):
 triangles=draws=verts=0;confs=set();positions=[]
 for mesh in doc.get('meshes',[]):
  for p in mesh['primitives']:
   draws+=1;assert p.get('mode',4)==4
   attrs=p['attributes'];assert 'POSITION' in attrs and 'NORMAL' in attrs and '_CONFIDENCE' in attrs
   pos=doc['accessors'][attrs['POSITION']];count=pos['count'];verts+=count
   assert pos['componentType']==5126 and pos['type']=='VEC3'
   for attr,index in attrs.items():
    a=doc['accessors'][index];assert a['count']==count
    vals=values(doc,binary,index);assert all(math.isfinite(v) for v in vals)
    if attr=='NORMAL':
     assert all(abs(sum(v*v for v in vals[i:i+3])-1)<1e-4 for i in range(0,len(vals),3))
    if attr=='_CONFIDENCE':
     assert a['componentType']==5126 and a['type']=='SCALAR'
     confs.update(vals);assert set(vals)<={0.,.5,1.}
    if attr=='POSITION':positions.extend(tuple(vals[i:i+3]) for i in range(0,len(vals),3))
   ind=values(doc,binary,p['indices']);assert len(ind)%3==0 and all(0<=v<count for v in ind)
   triangles+=len(ind)//3
   if 'material' in p:assert 0<=p['material']<len(doc['materials'])
 for m in doc.get('materials',[]):
  pbr=m.get('pbrMetallicRoughness',{})
  assert all(0<=v<=1 for v in pbr.get('baseColorFactor',[1,1,1,1]))
 return dict(primitives=draws,vertices=verts,triangles=triangles,materials=len(doc.get('materials',[])),confidence_values=sorted(confs),local_gltf_bounds={'min':[min(p[i] for p in positions) for i in range(3)],'max':[max(p[i] for p in positions) for i in range(3)]})
