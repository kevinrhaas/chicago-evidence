"""ONE-TIME light snapshot constructor. Does not launch Blender/browser/generation."""
from pathlib import Path
import shutil,json,hashlib,subprocess,ast
H=Path(__file__).resolve().parent;R=Path('/workspace/chicago/chicago/4d')
F=Path('/tmp/chicago-next-model/log81-materializer/05f6-sourceS-final/review-tree/chicago/4d')
L=Path('/tmp/chicago-next-model/T-2386-topology'); E=Path('/tmp/chicago-next-model/T-2386-entry-site')
assert str(H).startswith('/tmp/') and not (H/'templates').exists(),'Never overwrite a frozen fixture'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Support code must still agree with the actual raw parity proof's frozen helpers.
for p in (F/'generators/common').glob('*.py'):assert sha(p)==sha(R/'generators/common'/p.name),p
inputs={}
def copy(src,dst):
 assert src.is_file();dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);inputs[str(src)]=sha(src)
def tree(src,dst):
 shutil.copytree(src,dst,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.DS_Store'))
 for p in src.rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':inputs[str(p)]=sha(p)
for label in ['before','after']:
 root=H/'templates'/label
 tree(R/'generators',root/'generators')
 # Only the two official final log-family modules, never restore old shared code.
 for name in ['log_dwelling.py','log_dwelling_params.py']:copy(F/'generators/archetypes'/name,root/'generators/archetypes'/name)
 for rel in ['data/datum.json','data/scenes/1835.json','tools/photo_match.mjs','tools/photo_match_group.mjs','renderers/web/js/keith-stone.js']:
  copy(R/rel,root/rel)
 tree(R/'renderers/web/vendor/three-0.185.1',root/'renderers/web/vendor/three-0.185.1')
 copy(F/'data/structures/wolf_point_tavern.json',root/'data/structures/wolf_point_tavern.json')
 copy(L/'overlay/candidate/chicago/4d/data/sources/blanchard_shober_1867_wolf_point.json',root/'data/sources/blanchard_shober_1867_wolf_point.json')
 copy(L/'evidence/nypl-full.jpg',root/'data/sources/assets/nypl-full.jpg')
 if label=='after':
  copy(L/'overlay/candidate/chicago/4d/generators/archetypes/log_dwelling.py',root/'generators/archetypes/log_dwelling.py')
  copy(E/'candidate/chicago/4d/generators/archetypes/log_dwelling_params.py',root/'generators/archetypes/log_dwelling_params.py')
  copy(E/'candidate/chicago/4d/tools/generate_entrances.py',root/'tools/generate_entrances.py')
  copy(E/'placement-candidate/chicago/4d/data/structures/wolf_point_tavern.json',root/'data/structures/wolf_point_tavern.json')
 cam=json.loads((L/'L-provisional-camera.json').read_text());cam['photo']='../../../data/sources/assets/nypl-full.jpg';cam['pixel_aspect']=1
 cam['solve']['comparison']='Same numeric square-pixel camera in before/after, fitted to proposed analytic L corners only. Before is the final log81 initial chimney increment, not committed/current town geometry. Single-anchor render ignores world origin; no site/props/terrain clearance proof.'
 cp=root/'docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.json';cp.parent.mkdir(parents=True,exist_ok=True);cp.write_text(json.dumps(cam,indent=2)+'\n')
 (root/'assets/gltf').mkdir(parents=True,exist_ok=True)
 (root/'assets/manifest.json').write_text('{"assets": {}}\n')
 (root/'FIXTURE-ONLY.txt').write_text('ISOLATED RESEARCH SHAPE REVIEW. No official scene/sidecar/prop outputs or accepted reference views. Only wolf_point_tavern, no context, props, water, terrain or flora. Use official build.py seed structure_id__phase_id.\n')
 # Builder owns correct seed; no custom mesh exporter or hand-manifest stamps.
 assert 'name = f"{structure[\'id\']}__{phase[\'id\']}"' in (root/'generators/emit.py').read_text()
 assert not list((root/'assets/gltf').glob('*.glb'))
 assert len(list((root/'data/structures').glob('*.json')))==1
 assert not list(root.rglob('*.match.json'))
photo_sha=sha(H/'templates/before/data/sources/assets/nypl-full.jpg')
assert photo_sha=='d53dfb2f7110484d488f4c5329aad60cd53b5f408df44e273cc87406c5a58b50'
assert (H/'templates/before/docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.json').read_bytes()==(H/'templates/after/docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.json').read_bytes()
for p in H.glob('templates/*/generators/**/*.py'):ast.parse(p.read_text())
meta={'status':'PREPARED_NOT_RUN','source_id':'blanchard_shober_1867_wolf_point','source_sha256':photo_sha,'source_rights':'actual US printed1867 deposit line; public domain by age; credits retained','untrusted_poster_used':False,'labels':{'before':'final log81 first chimney increment; fresh pinned export, not committed old GLB','after':'final log81 + physicalL + explicit side-entry reader + reconstructed centre-preserving origin'},'support_snapshot_head':subprocess.check_output(['git','-C',str(R.parent.parent),'rev-parse','HEAD'],text=True).strip(),'source_input_sha256':inputs,'templates':{label:{str(p.relative_to(H/'templates'/label)):sha(p) for p in sorted((H/'templates'/label).rglob('*')) if p.is_file()} for label in ['before','after']},'node_dependency':'/workspace/node_modules only; external installed dependency, never a live checkout source input','expected_asset':'wolf_point_tavern__log_frame_1828.glb','expected_exports_per_label':1}
(H/'snapshot.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps({'status':meta['status'],'files_per_template':{k:len(v) for k,v in meta['templates'].items()},'source_sha256':photo_sha},indent=2))
