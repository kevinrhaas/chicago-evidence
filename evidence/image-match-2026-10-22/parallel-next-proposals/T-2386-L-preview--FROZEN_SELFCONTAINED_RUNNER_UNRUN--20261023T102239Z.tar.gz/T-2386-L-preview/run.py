"""Prepared only. Explicit root grant required before launching heavy jobs."""
from pathlib import Path
import argparse,datetime,json,hashlib,shutil,subprocess,sys,os,re,signal
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--execute-after-root-grant',action='store_true');ap.add_argument('--grant-note');args=ap.parse_args()
subprocess.run([sys.executable,str(H/'check_light.py')],check=True)
if not args.execute_after_root_grant:
 print('PREPARED ONLY: no Blender or browser launched. Root must grant heavy slot before explicit execution.');raise SystemExit(0)
if not args.grant_note:ap.error('--grant-note must record the parent grant used for this heavy slot')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((H/'snapshot.json').read_text())
# Resolve pin without shell sourcing or network download/install.
pin={}
for line in (H/'templates/after/generators/blender.pin').read_text().splitlines():
 if line.startswith('BLENDER_'):k,v=line.split('=',1);pin[k]=v
archive=Path('/workspace/shared/blender-dl')/pin['BLENDER_URL'].split('/')[-1]
binary=archive.parent/pin['BLENDER_DIR']/'blender'
assert archive.is_file() and sha(archive)==pin['BLENDER_SHA256'],'Pinned cached archive unavailable/drifted; stop, never download automatically'
version=subprocess.check_output([str(binary),'--version'],text=True).splitlines()[0];assert version.split()[1]==pin['BLENDER_VERSION'],version
node_modules=Path('/workspace/node_modules').resolve();assert node_modules.is_dir()
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S-%f');run=H/'runs'/stamp;run.mkdir(parents=True)
receipt={'status':'running','grant_note':args.grant_note,'blender_version':version,'blender_archive_sha256':sha(archive),'snapshot_sha256':sha(H/'snapshot.json'),'camera_sha256':sha(H/'templates/after/docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.json'),'source_sha256':meta['source_sha256'],'isolated_root':str(run),'live_checkout_reads_after_snapshot':False,'shared_external_dependencies':[str(binary),str(node_modules)],'stages':[],'matches':'unreviewed; no automatic acceptance'}
receipt_path=run/'receipt.json'
def save():receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
def command(cmd,cwd,log,timeout):
 save()
 with log.open('w') as f:
  p=subprocess.Popen(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PW_EXECUTABLE':'/usr/bin/chromium'})
  try:
   p.wait(timeout=timeout)
  except BaseException:
   # Kill only this runner-owned process group on timeout/interruption.
   try:os.killpg(p.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    p.wait()
   raise
 if p.returncode:raise RuntimeError(f'Command failed ({p.returncode}); see {log}')
try:
 for label in ['before','after']:
  root=run/label;shutil.copytree(H/'templates'/label,root)
  (root/'node_modules').symlink_to(node_modules,target_is_directory=True)
  # No GLB seeds copied: both outputs must be actual fresh exports.
  assert not list((root/'assets/gltf').glob('*.glb'))
  command([str(binary),'-b','-noaudio','--factory-startup','--python','generators/build.py','--','--only','wolf_point_tavern','--scene','1835','--wrote',str(root/'wrote.txt')],root,root/'export.log',600)
  command([sys.executable,str(H/'verify_export.py'),str(root),label],root,root/'contract.log',60)
  receipt['stages'].append({'label':label,'export_contract':'passed','export_sha256':sha(root/'assets/gltf/wolf_point_tavern__log_frame_1828.glb')});save()
 # All CPU exports close before sequential ephemeral browser captures.
 for label in ['before','after']:
  root=run/label;camera=root/'docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.json';review=run/'reviews'/label;review.mkdir(parents=True)
  command(['node','tools/photo_match.mjs',str(camera),'--out',str(review)],root,root/'photo-match.log',600)
  text=(root/'photo-match.log').read_text();paths=[Path(x.strip()) for x in text.splitlines() if x.strip().endswith('-render.png')]
  assert len(paths)==1 and paths[0].is_relative_to('/tmp') and paths[0].is_file()
  shutil.copyfile(paths[0],review/'render.png')
  match=json.loads(camera.with_suffix('.match.json').read_text());assert match['verdict']=='unreviewed' and not match['differences']
  assert match['photo_sha256']==meta['source_sha256'] and match['camera_sha256']==receipt['camera_sha256']
  assert match['glb_sha256']==sha(root/'assets/gltf/wolf_point_tavern__log_frame_1828.glb')
  receipt['stages'].append({'label':label,'capture':'passed','match_verdict':match['verdict'],'side_by_side_sha256':sha(review/'nypl-1867-L-provisional-side-by-side.jpg'),'render_sha256':sha(review/'render.png')});save()
 command([sys.executable,str(H/'assemble_detail.py'),str(run)],H,run/'detail.log',60)
 # Production inputs must remain the frozen bytes; only outputs may change.
 for label,files in meta['templates'].items():
  for rel,want in files.items():
   if rel=='assets/manifest.json':continue
   assert sha(run/label/rel)==want,(label,rel,'input mutated during build/review')
 receipt['status']='completed_two_actual_exports_and_two_same_camera_captures_UNREVIEWED'
 receipt['limits']='Building-only neutral-plane shape comparison; no stale props/context; world-origin/site consumers and full canonical81 refresh remain owed. Actual images need human/agent visual inspection and honest differs record.'
 save();(H/'latest-run.txt').write_text(str(run)+'\n');print(run)
except BaseException as exc:
 receipt['status']='FAILED';receipt['error']=str(exc);save();raise
