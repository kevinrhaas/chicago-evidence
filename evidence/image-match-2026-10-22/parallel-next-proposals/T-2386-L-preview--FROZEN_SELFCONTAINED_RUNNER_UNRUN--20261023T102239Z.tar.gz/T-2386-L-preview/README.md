# Prepared Wolf Point actual L preview

**FROZEN / PREPARED ONLY / NOT EXECUTED.** The light preparation and dry runner passed. No Blender, browser, GLB export, publisher, canonical writes or accepted image-gate records have run. T-2386 remains open and `differs`. This package makes the next actual shape comparison executable immediately after the parent grants the shared heavy slot.

## Exactly two fresh exports and comparisons

- **Before:** final selective log81 proposal's first Wolf Point chimney increment, including the final log-family code (Miller visible joints and Hogan continuation). This is a fresh pinned export of a proposed baseline, **not** a committed town master or evidence that the whole log81 family has shipped.
- **After:** the same final code support with the frozen physical-L builder, its separate +X side-entry helper/consumer, and the centre-preserving origin record. No parallel-gable trial or new geometry variant is applied.

The templates contain complete regular-copied generator/viewer/source inputs and just the Wolf Point record. Execution needs no source files from the live checkout or other `/tmp` proposals. The only shared runtime dependencies are the existing pinned Blender cache, installed Python/Pillow, Node and `/workspace/node_modules`. The latter is linked only into each new disposable execution tree. No dependency is installed or fetched by this runner.

Both exports use the **actual copied `generators/build.py` → `emit.emit_structure`**, selected with `--only wolf_point_tavern --scene 1835`. Both start with empty GLB directories/manifests. The real official asset-key seed is `wolf_point_tavern__log_frame_1828`; there is no custom mesh exporter, structure-ID-only seed or copied master masquerading as a fresh build. Normal UV unwrap is enabled; AO is not requested, matching the ordinary default producer. The cached archive SHA256 and binary version must match copied `blender.pin` before execution.

Both cameras have exactly the same bytes. They reproduce the reconstructed square-pixel upright camera from the frozen L analysis: 1920×1697, focal 6000 px, principal [284.32875966,850.23931519], eye [164.92075454,133.74014104,2], yaw 230.96016719°, near 150 m and overcast light. This was fitted to approximate analytic L corners only. Fixed scale/focal-distance degeneracy, an eye-height bound, retrospective depiction and hidden topology remain unresolved; it is **not** a solved historical station or an accepted reference view. A before model can fit poorly in the deliberately unchanged proposed-L framing.

The sole photographic source is the copied, full **1867 Rufus Blanchard / Chas. Shober & Co. sheet, NYPL I. N. Phelps Stokes Collection, depicting 1833**. Its actual printed US deposit year supports public-domain status by age. Citation, source record and full sheet are preserved. Source image SHA256 is `d53dfb2f7110484d488f4c5329aad60cd53b5f408df44e273cc87406c5a58b50`. The metadata-conflicted Newberry poster is neither copied nor used.

## Scope and exclusions

This is a building-only neutral-plane **shape** comparison. Stable/store context is unnecessary to assess the opposing gables and connected-roof topology, so no neighbours, water, heightfield, trees, roads or town props are rendered. This deliberately excludes the four known stale trade-goods instances inside the new body. They remain an explicit canonical regeneration obligation, not an accepted collision exception.

The after record includes the reconstructed origin shift [-1.55 E,-2.40 N] m preserving the old geographic bbox centre. Single-anchor `photo_match` renders in local mesh coordinates and ignores that world placement. Therefore these pictures cannot prove site, river, consumer or prop clearance. The separate side-entry/site package retains those native geometry checks and their limits; official regenerated scene/entrance/prop/contact/walker checks and full app QA remain owed. The consumer helper is included as an input, but `generate_entrances.py` is not run by this shape fixture. No false claim of interior walker passage is made.

## Run only after the parent grants the heavy slot

Light verification only, safe without a grant:

```sh
python3 /tmp/chicago-next-model/T-2386-L-preview/run.py
```

After an explicit parent heavy-slot grant:

```sh
python3 /tmp/chicago-next-model/T-2386-L-preview/run.py \
  --execute-after-root-grant \
  --grant-note 'Root granted the isolated Wolf Point L export and browser slot'
```

The runner creates a fresh `runs/<UTC timestamp>/` directory; it never mutates templates or the live checkout. It performs before export, after export, decoded contracts, then before/after browser captures sequentially. Each tool owns an ephemeral server/browser. On timeout/interruption it terminates only its own command process group. A failed stage leaves a failed receipt and logs and cannot silently advance to acceptance. Notify the parent after actual execution and process closure; this prepared state has no active jobs.

Expected successful outputs:

- `before/` and `after/assets/gltf/wolf_point_tavern__log_frame_1828.glb`, each with real build manifest, wrote list, log and decoded `export-contract.json`.
- `reviews/before/nypl-1867-L-provisional-side-by-side.jpg` and `reviews/after/...`: full original sheet beside the respective actual GLB render.
- `reviews/{before,after}/render.png`: portable copies of the bare actual renders.
- `reviews/source-before-after-detail.png`: identical [30,540,570,950] source-pixel crop for source/before/after, displayed at integer 2× nearest-neighbour scale; no warp, camera change, feature fit or visual acceptance. Full comparisons remain available.
- `receipt.json`: explicit grant note, frozen snapshot/source/camera/pinned archive hashes, stage outcomes and output hashes. `latest-run.txt` appears only on complete success.

The after and before research `.match.json` files are written only inside disposable execution trees and deliberately remain **unreviewed**. The runner never writes `matches`. Actual visual inspection must state improvements and remaining differences before any acceptance decision. Expected open review subjects include inherited pole/sign size/station/lean, wall/gable/roof fabrication, roof junction/eaves, opening details, inferred plan/gauge, 1833-to-1835 continuity and other retrospective views. Numerical corner residuals alone do not fix these.

## Guards and receipts

`check_light.py` verifies every frozen template hash, no template symlinks, single cleared photo/source, identical square-pixel camera and no context/prop inputs. Its separate raw-builder process checks actual mesh vertices in the camera: before has 2056 vertices /1092 triangles, after 1661 /895; all vertices are inside the image and near/far depth planes. The +X side helper yields one declared entry on the after record. `light-check.json` records the result; these are raw calculations, not renders.

`verify_export.py` checks the actual wrote list and singleton manifest, recomputes the fixture's real input hash, inspects GLB structure/accessors/indices/material ranges/finite values/unit normals and `_CONFIDENCE`, and compares triangle counts with the actual raw builder. These are focused contract essentials, not a replacement for the canonical validator, web derivative checks or app QA. `run.py` rechecks immutable inputs after captures and binds all image records to the exact source/camera/GLB hashes.

`prepare.py` documents the already completed one-time snapshot. **Do not rerun it into this frozen directory.** It refuses to overwrite templates. `snapshot.json` records original source-file hashes and the support snapshot HEAD, but future execution does not reread those live source paths. `ARTIFACTS.json` binds the complete prepared package excluding future execution outputs.

Canonical adoption remains: rematerialize selective final log81 against the parent's then-current frame/fort/Hogan/source-S checkout, preserve independent edits, physical-L overlay, side-entry consumer, centre-preserving origin, append 8+1+1 liberty entries and existing note-reader registrations; obtain actual preview review; then, if accepted, one normal official all81 pinned refresh plus dependent source/grade/liberty/scene/contact/entrance/prop regeneration, full gates and app QA. This runner neither bypasses the image gate nor closes an original image-match ticket.
