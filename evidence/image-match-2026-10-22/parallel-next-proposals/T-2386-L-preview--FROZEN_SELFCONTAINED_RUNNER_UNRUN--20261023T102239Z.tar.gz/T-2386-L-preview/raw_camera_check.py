from pathlib import Path
from types import ModuleType
import json,math,sys
sys.dont_write_bytecode=True
R=Path(sys.argv[1]);sys.path.insert(0,str(R/'generators'));sys.modules['bpy']=ModuleType('bpy')
from archetypes import log_dwelling as g,log_dwelling_params as p
from common.mesh import MeshBuilder
class Raw(MeshBuilder):
 def to_object(self,materials=None):return self
g.MeshBuilder=Raw;g.simple_material=lambda *a,**kw:None
r=json.loads((R/'data/structures/wolf_point_tavern.json').read_text());ph=r['phases'][0];q=p.from_phase(ph,r);o=g.build(q,'wolf_point_tavern__log_frame_1828')
c=json.loads((R/'docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.json').read_text());e=c['eye'];t=math.radians(c['yaw_deg']);sn,cs=math.sin(t),math.cos(t);projected=[];depths=[]
for v in o.verts:
 du,dv,dz=[v[k]-e[k] for k in range(3)];d=du*sn+dv*cs;depths.append(d);assert c['near_m']<d<500
 projected.append([c['principal_px'][0]+c['focal_px']*(du*cs-dv*sn)/d,c['principal_px'][1]-c['focal_px']*dz/d])
bounds={'min':[min(v[k] for v in projected) for k in range(2)],'max':[max(v[k] for v in projected) for k in range(2)]}
assert all(0<=bounds['min'][k]<=bounds['max'][k]<=c['image_px'][k] for k in range(2)),bounds
print(json.dumps({'raw_vertices':len(o.verts),'raw_triangles':sum(len(f)-2 for f in o.faces),'physical_polygon_vertices':len(ph['footprint']['polygon']),'side_entries':len(p.side_access_faces(q)) if hasattr(p,'side_access_faces') else 0,'camera_depth_bounds_m':[min(depths),max(depths)],'actual_raw_projected_bounds_px':bounds,'all_raw_vertices_inside_view_and_near_far_planes':True}))
