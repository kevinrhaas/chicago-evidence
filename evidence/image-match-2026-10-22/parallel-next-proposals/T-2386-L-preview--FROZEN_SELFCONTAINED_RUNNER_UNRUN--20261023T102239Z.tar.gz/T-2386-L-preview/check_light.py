"""Verify frozen snapshots and actual raw camera depth/framing without Blender."""
from pathlib import Path
from types import ModuleType
import hashlib,json,sys,math,subprocess
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((H/'snapshot.json').read_text());rows={}
for label,files in meta['templates'].items():
 root=H/'templates'/label
 assert not any(p.is_symlink() for p in root.rglob('*'))
 actual={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
 assert actual==files,label+' snapshot changed'
 cam=json.loads((root/'docs/RESEARCH/wolf-L-preview/nypl-1867-L-provisional.json').read_text())
 assert cam['pixel_aspect']==1 and not cam.get('also_render') and cam['source_id']==meta['source_id']
 src=json.loads((root/'data/sources/blanchard_shober_1867_wolf_point.json').read_text());assert src['date']=='1867' and src['rights_status']=='public_domain'
 # Separate process avoids common-module or archetype cross-contamination.
 result=subprocess.run([sys.executable,str(H/'raw_camera_check.py'),str(root)],check=True,capture_output=True,text=True)
 rows[label]=json.loads(result.stdout)
assert rows['after']['physical_polygon_vertices']==6 and rows['after']['side_entries']==1
out={'status':'passed_LIGHT_ONLY','source_id':meta['source_id'],'same_camera_bytes':True,'only_cleared_source_photo':True,'no_context_or_stale_trade_props':True,'official_producer_seed':'wolf_point_tavern__log_frame_1828','all_template_inputs_regular_copied_and_hash_bound':True,'raw_camera_checks':rows,'Blender_browser_export_executed':False,'limits':'No GLB, export contract, source-render comparison or acceptance established. Numeric projection includes actual raw vertices, not viewport render.'}
(H/'light-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
