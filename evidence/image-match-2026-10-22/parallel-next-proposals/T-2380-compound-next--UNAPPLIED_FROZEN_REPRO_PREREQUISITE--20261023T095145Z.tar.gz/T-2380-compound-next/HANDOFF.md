# T-2380 — genuine compound context proposal

**Prepared, unapplied, not rendered.** `T-2380-compound-next.patch` adds the two actual missing establishment components pictured with the jail. It preserves the separately frozen22°core package and does not move or resize the current core.

## What exists and what is new

Read-only searches of current structure records found no keeper-house or jail-palisade record. Only `log_jail` and `estray_pen` mention John Beach/jail keeper relationships. This proposal therefore creates:

| ID | What it represents | Builder |
|---|---|---|
| `log_jail_keeper_house` | The partly enclosed, Randolph-facing house named by Gale | Existing `frame_dwelling` |
| `log_jail_palisade` | The high enclosing curtain and adjacent low gate | Guarded `palisade` opt-in |

Both are explicitly `part_of=log_jail`, and both remain in the original ticket’s picture acceptance. No child ticket, fake blank asset or independent `matches` shortcut is created. John Beach remains a source name on a house; there is no person_id, occupants, resident or household link.

`gale_1902_jail_walk_text` is a separate source for the actual memoir passage, graded compiled retrospective text (tier3). It preserves the distinction between the walk framed in1835 and the plate captioned1836. The actual1902title/copyright pages independently establish public-domain publication. The existing illustration record supplies appearance; it is not used to trace new scene coordinates.

## First geometry and exact known limitations

The new house uses a reconstructed20×14ft plan,2.4m eave and30°roof, offset6.25m east/0.8048m north from the unchanged core origin. The long facade faces north toward Randolph, as the text says, but exact offset/bearing is reconstructed. Existing3-bay/end-biased-door framing provides a first dwelling mass and frontage category. Its attic light and second visible gable ground light are **both missing** in this first kit result. The code only emits an attic light at stories≥1.5, where it requires at least2.9m eaves; the proposal does not inflate an unmeasured house merely to obtain that feature. A small attic window is not proof of habitable half-storey rooms. Door/sash/shutter/chimney details remain approximate.

The curtain’s7.85×5.622m envelope starts0.35m west/south of the fixed core. Its reconstructed2.8m height/0.18m faces/0.20m rhythm/0.25m pointed heads are first-comparison choices. Runs stop at the adjoining house rather than passing through its open interior. Unseen returns are reconstructed. The source’s low gate near the house is represented by a bounded0.9×1.0m rail/brace gate. Its exact role—keeper forecourt or prison access—is unresolved; the proposed topology is explicitly reconstruction.

The core stays fixed. With a tall curtain and a generic low house added, its current eave may be hidden too much; do not treat a mismatch caused by these chosen dimensions as new independent proof that the core must be4.2m tall. The full group must be compared before selecting/refining those proxies.

The current palisade builder can only draw full rectangles and centered tall military gateways, which cannot honestly express this partial-house join and low off-centre gate. The proposal adds empty-default keyword-only `curtain_runs`/`wickets`. Runs are finite, non-overlapping axial portions of the stated perimeter. Custom runs cannot mix with ordinary gate/bastion parameters or worm fences. Low gates have bounded widths/heights and reconstructed stock, no military lintel. No common material or global emitter changes.

## Date, street and collision boundary

The two new phases use1835scene-year housekeeping bounds, not invented construction/removal dates. Presence by1July is inferred from Gale’s retrospective arrival/town-walk context. The actual illustration keeps its1836caption. Andreas’s original jail/separate later oaken cell and contrasting shallow hip/pyramidal cap remain unresolved; no original1833compound completion is asserted.

Every new placement is reconstructed relative to the existing jail anchor, inheriting its roughly20m uncertainty. No core, street or grid coordinate moves. The proposed north curtain is0.70m beyond the current core’s north wall; applying the core’s stated1.5m frontage margin leaves roughly0.8m, not a certified margin pass. Before integration, parent must:

1. Recompute both new footprint/envelope edges against the **drawn** Randolph/LaSalle frontage/corridor, using the project’s current street controls. Do not substitute the control centreline or recut the block.
2. Check the actual generated curtain/house geometry and eave extents against street boards, the original core, the keeper door/stoop, gate posts and walker paths. The light check proves no centerline curtain segment crosses the house’s open footprint; it is not a full mesh clearance verdict.
3. Resolve any minimum-lot-margin requirement and gate-access path in the reconstructed arrangement. A full1.5m margin is not established here. If the arrangement needs changing, keep that choice explicit and review the source group again.

The original core’s phase `change_note` is updated only to withdraw its literal “only county roof” compound census now that a source names the keeper’s house. Its forms/position/footprint/date and mesh recipe remain exactly unchanged by this patch. The frozen roof-only patch touches other fields, so the two increments are compatible in scope.

## Acceptance and next isolated preview

`group-camera-proposal.json` extends the existing actual-Gale pilot with `scene=1835` and `also_render=[log_jail_keeper_house,log_jail_palisade]`. It retains the source image and all optical parameters. It is a proposal, not a solved/matched canonical view.

A disposable full-source fixture must actually compile the new records’1835sidecars and build real official-name GLBs before calling the group renderer. Do **not** hand-author fake sidecars, insert blank context GLBs, silently drop a missing member, or accept the bare core while its pictured context is absent. `photo_match_group.mjs` correctly refuses missing/wrong-date members.

For an increment comparison, the old app baseline can be captured as the honestly incomplete bare core, with identical camera optics and no `also_render`; the after capture uses all three actual members. That member-list difference is intentional new geometry, not a camera refit. The group review and original T-2380 gate remain open until all pictured building/enclosure differences are resolved. No camera/grade verdict is written by this package.

## Checks, blast and files

`verify.py` / `verify.log` pass:

- New source and all three structure schemas; existing frame-house parameters.
- All15 registered palisade masters’ default parameters and exact raw polygon/material/confidence/tone output parity;0 registered versions.
- Custom finite curtain/gate geometry and14 meaningful refusal cases, including overlap, off-perimeter/out-of-bounds, ordinary gate/bastion mixing, wrong fence kind, oversized gates and malformed booleans/strings/NaN.
- No John Beach person/occupant assignment, unchanged core mesh recipe, no curtain centerline through the house’s open interior, and `git apply --check` against current canonical sources.

Shared hashes stale15 existing palisade masters;2 new masters are added. Existing frame-dwelling masters are not stale because their builder/params remain untouched. No global emit/common/schema-enum edits. `palisade-family.json` lists every registered affected asset, including first-fort covered-way/garden walls and second-fort stockade. These must be rebuilt under the approved materializer/gates if the shared branch is integrated; default raw parity is not freshness by itself.

The patch has6 files: new book source;2 new structure records; core change-note correction; palisade builder and params. `proposed-liberty.md` is separately reviewable text to append on an accepted integration. Exact before/after hashes are in `files.json`.

No Blender, browser, export, bake, canonical edit or ticket write was performed. This is a concrete first context proposal, not a claim that the full picture matches. Outer street rail/plankwalk, flagstaff, figures/animals/camp and landscape remain separately disclosed context differences.
