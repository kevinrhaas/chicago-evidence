from pathlib import Path
import sys,json,ast,math,zlib,copy,dataclasses,importlib.util,hashlib,subprocess
B=Path(__file__).resolve().parent;R=Path('/workspace/chicago');D=R/'chicago/4d';G=D/'generators';sys.path.insert(0,str(G))
import jsonschema,mesh_inputs
from archetypes.frame_dwelling_params import from_phase as house_params

def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
p0=module('jail_pali_before',B/'before/chicago/4d/generators/archetypes/palisade_params.py');p1=module('jail_pali_after',B/'after/chicago/4d/generators/archetypes/palisade_params.py')
def functions(path):
 tree=ast.parse(path.read_text());nodes=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0)]
 for node in tree.body:
  if isinstance(node,ast.FunctionDef) and node.name!='build':nodes.append(node)
  elif isinstance(node,ast.Assign):
   try:ast.literal_eval(node.value)
   except (ValueError,TypeError):continue
   nodes.append(node)
 ns={'math':math,'zlib':zlib};exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(path),'exec'),ns);return ns
n0=functions(B/'before/chicago/4d/generators/archetypes/palisade.py');n1=functions(B/'after/chicago/4d/generators/archetypes/palisade.py')
class Collector:
 def __init__(self,name):self.name=name;self.tone_fn=None;self.polys=[]
 def add_poly(self,points,confidence,mat=0):
  points=tuple(tuple(p) for p in points);centre=tuple(sum(p[k] for p in points)/len(points) for k in range(3));tones=tuple(self.tone_fn(p,centre,mat) if self.tone_fn else 1.0 for p in points);self.polys.append((points,confidence,mat,tones));return []
def capture(ns,p,name):
 c=Collector(name);ns['_worm_fence' if p.wall_kind=='worm_fence' else '_stockade'](c,p);return c.polys
family=json.loads((B/'palisade-family.json').read_text());assert family['existing_master_count']==15
for row in family['registered_existing_masters']:
 rec=json.loads((D/'data/structures'/f"{row['structure_id']}.json").read_text());phase=next(ph for ph in rec['phases'] if ph['id']==row['phase_id']);a=p0.from_phase(phase,rec);b=p1.from_phase(phase,rec)
 aa=dataclasses.asdict(a);bb=dataclasses.asdict(b);assert bb.pop('curtain_runs')==();assert bb.pop('wickets')==();assert aa==bb
 assert capture(n0,a,Path(row['asset']).stem)==capture(n1,b,Path(row['asset']).stem),row['asset']
print('PASS all15 registered palisade defaults exact parameter parity and raw polygon/material/confidence/tone streams; versions0')
schema=json.loads((D/'data/structures.schema.json').read_text());records={}
for sid in ['log_jail_keeper_house','log_jail_palisade','log_jail']:
 rec=json.loads((B/'after/chicago/4d/data/structures'/f'{sid}.json').read_text());jsonschema.validate(rec,schema);records[sid]=rec
 assert 'occupants' not in rec or sid=='log_jail'
source=json.loads((B/'after/chicago/4d/data/sources/gale_1902_jail_walk_text.json').read_text());jsonschema.validate(source,json.loads((D/'data/source.schema.json').read_text()));assert source['rights_status']=='public_domain' and source['verified']
hp=house_params(records['log_jail_keeper_house']['phases'][0],records['log_jail_keeper_house']);hp.validate();assert hp.stories==1 and hp.wall_height_m==2.4
pal=records['log_jail_palisade'];pp=p1.from_phase(pal['phases'][0],pal);pp.validate();polys=capture(n1,pp,'log_jail_palisade__context_1835');assert polys and pp.picket_count>40
assert all(math.isfinite(v) for points,*_ in polys for point in points for v in point)
assert all(c==1.0 for _,c,_,_ in polys) # this new curtain's guessed height and custom joinery are reconstructed
old=json.loads((B/'before/chicago/4d/data/structures/log_jail.json').read_text());new=records['log_jail'];x=copy.deepcopy(new);x['phases'][0]['change_note']=old['phases'][0]['change_note'];assert x==old
assert mesh_inputs.structure_inputs_doc(old,old['phases'][0])==mesh_inputs.structure_inputs_doc(new,new['phases'][0])
# Every drawn custom boundary lies outside house's open interior in anchor frame.
housebox=(6.25,.8048,12.346,5.072)
for r in pp.curtain_runs:
 a=(r[0]-.35,r[1]-.35);z=(r[2]-.35,r[3]-.35)
 for t in [0,.25,.5,.75,1]:
  x,y=a[0]+(z[0]-a[0])*t,a[1]+(z[1]-a[1])*t
  assert not (housebox[0]+1e-8<x<housebox[2]-1e-8 and housebox[1]+1e-8<y<housebox[3]-1e-8)
# meaningful refusals, including JSON parser bool/string guards.
base=pal['phases'][0]
mutations=[('worm-fence',lambda f:f.update(wall_kind={'value':'worm_fence'})),('ordinarygate',lambda f:f.update(gate_sides={'value':['n']})),('bastion',lambda f:f.update(bastion_corners={'value':['nw']})),('off-boundary',lambda f:f.update(curtain_runs={'value':[[1,1,2,1]]})),('outofbounds',lambda f:f.update(curtain_runs={'value':[[-1,0,2,0]]})),('zero',lambda f:f.update(curtain_runs={'value':[[0,0,0,0]]})),('overlap',lambda f:f.update(curtain_runs={'value':[[0,0,4,0],[2,0,6,0]]})),('wicketthroughcurtain',lambda f:f.update(wickets={'value':[[0,0,1,0,1]]})),('tallwicket',lambda f:f.update(wickets={'value':[[6.6,5.622,7.5,5.622,2.5]]})),('widewicket',lambda f:f.update(wickets={'value':[[0,5.622,5,5.622,1]]})),('bool',lambda f:f.update(curtain_runs={'value':[[False,0,4,0]]})),('string',lambda f:f.update(curtain_runs={'value':[['0',0,4,0]]})),('nan',lambda f:f.update(curtain_runs={'value':[[float('nan'),0,4,0]]})),('noruns',lambda f:f.update(curtain_runs={'value':[]}))]
for name,mut in mutations:
 ph=copy.deepcopy(base);mut(ph['form'])
 try:p1.from_phase(ph,pal)
 except (ValueError,TypeError):pass
 else:raise AssertionError('missing refusal '+name)
subprocess.run(['git','apply','--check',str(B/'T-2380-compound-next.patch')],cwd=R,check=True,capture_output=True)
print('PASS new source/structure schemas, existing house params, custom curtain/wicket finite geometry,14refusal guards')
print('PASS no JohnBeach person/occupant link; unchanged core recipe/position; no curtain through house open interior')
print('PASS git apply --check. OPEN: absolute/relative source scale; at-least1.5m-lot-margin/street/collision/app/gate checks; missing house lights/complete image match')
print('New custom pickets:',pp.picket_count,'raw polys:',len(polys),'house facade:',hp.bays,'bays')
print('UNRUN actual Blender/browser/export/bake. No canonical writes; T-2380 remains open.')
