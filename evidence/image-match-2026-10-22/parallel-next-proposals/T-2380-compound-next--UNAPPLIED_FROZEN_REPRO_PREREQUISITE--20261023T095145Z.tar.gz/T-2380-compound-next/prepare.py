from pathlib import Path
import json,copy,difflib,hashlib
B=Path(__file__).resolve().parent;R=Path('/workspace/chicago');D=R/'chicago/4d';changes={};anchor=json.loads((D/'data/structures/log_jail.json').read_text());ap=anchor['phases'][0];src='gale_1902_jail_walk_text';plate='trowbridge_first_jail_gale_1902'
source={'id':src,'type':'book','citation':'Edwin O.Gale, Reminiscences of Early Chicago and Vicinity (Chicago: Fleming H.Revell Company,1902), pp25,43,51–55; especially p51, small log jail, high plank palisade and John Beach’s house partly in the enclosure, facing Randolph.','author':'Edwin O.Gale','date':'1902, actual title MCMII and copyright1902/October','describes_date':'1835arrival/town-walk recollection, framed by arrival25May1835; plate facingp53 separately captioned1836','url':'https://archive.org/details/reminiscencesofe00ingale/page/n76/mode/1up','archived_url':'https://archive.org/download/reminiscencesofe00ingale/page/n76.jpg','repository':'Internet Archive, reminiscencesofe00ingale, Allen County Public Library volume','locator':'Actual printedp25/service n40; p43/n66; p51/n76; pp52–55/n77,n80,n81,n82. Actual title n12 and copyright n13. These pages were actually read, not only OCR searched.','tier':3,'rights_status':'public_domain','rights_note':'Actually inspected US1902title/copyright pages establish public-domain book by age. This textual record is independent of the later1930copy and1947newspaper surrogate.','asset_use':'inventory','verified':True,'note':'A retrospective memoir, written decades after the recollected walk, not a contemporary jail contract or measured plan. P25 dates arrival25May1835; chapterIII begins an early-breakfast stroll onp43, without independently specifying the walk’s exact day. P51 says the brick courthouse is just started, the small log jail is concealed within a high plank palisade, and John Beach occupies a house partly in the same enclosure, facing Randolph. Pp52–55 continue the walk and supply no cell alteration sequence. This supports presence/relationship in the1835recollection, not metric positions or exact construction dates. The separately captioned1836plate remains1836. No person identity, birth/death record or existing personID is established by the keeper’s name alone.','what_it_supplies':['Retrospective1835narrative of a jail, high plank palisade and John Beach’s house partly within the enclosure facing Randolph.','Coarse public-square/Randolph relationship, with independent1902publication proof.'],'what_it_does_not_supply':['Metric footprints, eave heights, enclosure heights, wall/gate station coordinates or measured construction plans.','Proof every detail in the separately captioned1836plate existed on1July1835.','An exact walk date, dated original-cell/later-cell alteration sequence, or resolved John Beach person identity.']}
rel='chicago/4d/data/sources/'+src+'.json';assert not (R/rel).exists();changes[rel]=('',json.dumps(source,indent=2,ensure_ascii=False)+'\n')
def attr(value,confidence,note,sources=None):
 x={'value':value,'confidence':confidence,'note':note}
 if sources:x['sources']=sources
 return x
def position(dx,dy,label):
 return {'utm_e':round(ap['position']['utm_e']+dx,4),'utm_n':round(ap['position']['utm_n']+dy,4),'rotation_deg':ap['position']['rotation_deg'],'symbolic_location':label,'confidence':'reconstructed','sources':[src,'andreas_1884_v1'],'note':f'RECONSTRUCTED context relative to the unchanged log_jail anchor: Δeast={dx}m, Δnorth={dy}m in the current zero-bearing footprint frame. Gale names the NW public-square compound and Randolph-facing house, not coordinates. These offsets are a first group-model arrangement chosen on that textual anchor and existing invented core plan, never a trace of the retrospective image into geospatial coordinates. Inherit the anchor’s roughly20m placement uncertainty; exact offsets/bearing are not survey evidence. The north edge must be checked against the committed drawn Randolph frontage/corridor before integration. No street/grid or original core position is moved.','derivation':{'method':'not_derivable','reason':'New reconstructed relative arrangement; text fixes only compound/corner/facing. No independent surveyed or traced coordinate is claimed.'}}
def phase(sid,dx,dy,poly,form,label):
 return {'id':'context_1835','documented_range':{'from':'1835-01-01','to':'1835-12-31','confidence':'inferred','sources':[src,plate],'note':'1835-01-01 and1835-12-31 are housekeeping bounds for the target-year phase, not building or removal dates. Gale’s walk is framed by arrival25May1835 and names these components; the illustration explicitly depicts1836. Presence by1July1835 is an inference from that retrospective1835narrative, not proof that all drawn details were complete. No exact construction/addition/removal date is reached. The1836caption is retained and not silently converted into aJulydate.'},'position':position(dx,dy,label),'footprint':{'polygon':poly,'confidence':'reconstructed','note':'RECONSTRUCTED plan and metric size, not measured historical dimensions. Context is provisionally seated relative to the existing20×15ft invented core. The source supplies composition/textual relationship only; no scene coordinate or footprint outline is traced from it.'},'form':form,'change_note':'First contextual component of the same pictured jail compound; no separate image-match acceptance or person identity is asserted.'}
house_form={
 'construction':attr('braced_frame','reconstructed','Horizontal clapboard exterior is pictured; concealed braced-versus-balloon framing is an unobserved kit choice, not a source finding.'),
 'stories':attr(1,'reconstructed','One full storey is a provisional first mass. The pictured small attic light does not prove habitable half-storey rooms. The current frame_dwelling kit cannot emit that light at stories1; do not inflate unmeasured eaves to its1.5-storey2.9m minimum merely to buy an opening.'),
 'wall_height_m':attr(2.4,'reconstructed','2.4m first-comparison eave, a small dwelling convention, not a measured source height. The jail core’s existing height stays fixed.'),
 'roof_type':attr('gable','inferred','The house has a triangular end beneath a two-slope roof in the exact1902plate, captioned1836; Julycontinuity remains the phase inference.',[plate]),
 'roof_pitch_deg':attr(30,'reconstructed','30degree first-comparison gable; the source has no surveyed angle or solved metric camera. Test the whole compound before refining.'),
 'plan':attr('single_pen','reconstructed','Generator frontage scheme for an end-biased door with two lights, not a claim to one historic room or a known internal plan.'),
 'bays':attr(3,'inferred','The visible long wall has two main sash and a door. Exact kit station/door position remains an approximation, not a solved facade.',[plate]),
 'porch':attr('stoop','reconstructed','Small threshold proxy only. The source shows frontage boards/rail near the house; this does not model their full run as a porch.'),
 'chimneys':attr(1,'inferred','One brick-looking stack is visible on the low house. Count is pictured; existing kit location/section/head are reconstructed.',[plate]),
 'paint':attr('unpainted','reconstructed','Sepia/monochrome reproduction supplies no historic paint colour; retain a generic unpainted kit finish.'),
 'shutters':attr('unpainted','reconstructed','Source sash have shutters; board shutter geometry and this generic finish are proxies for unmeasured source details.'),
 'glazing':attr('12_over_12_6x8','reconstructed','Existing small-pane sash proxy, not an attested light count or6×8inch purchase for this house.'),
}
house={'id':'log_jail_keeper_house','name':"The jail keeper’s house (John Beach, as named by Gale)",'aka':["the jailer’s house partly within the first jail enclosure"],'archetype':'frame_dwelling','part_of':attr('log_jail','inferred','Gale explicitly places the keeper’s house partly in the jail enclosure. This is a component of that establishment, not a newly identified person or resident seat.',[src]),'phases':[phase('log_jail_keeper_house',6.25,.8048,[[0,0],[6.096,0],[6.096,4.2672],[0,4.2672]],house_form,'NW public-square jail compound; house partly within the enclosure, facing north toward Randolph.')],'function':attr('dwelling','inferred','The jailer John Beach occupies a house partly in the enclosure, in Gale’s retrospective walk. No automated link to an existing person record is made.',[src]),'research_note':'NEW PICTURED COMPOUND MEMBER, not an independent acceptance shortcut. The house is named by function and Gale’s keeper name only; no occupants/person_id/household link is invented.20×14ft,2.4m eave, roof angle and relative offsets are reconstructed first-group choices. The frame_dwelling first mass has only one near-gable ground light and no attic light at stories1: the source shows two ground lights plus an attic light, so TWO lights remain missing. Front-door station, sash/shutters, stack location and roof proportion also need actual review. The original T-2380 camera must show core+house+palisade together and its ticket stays open while any pictured component differs.'}
pali_form={
 'wall_kind':attr('picket_stockade','inferred','Gale calls a high plank palisade; the plate depicts close upright pointed timbers. This uses the existing stockade family, not a military-fort identity.',[src,plate]),
 'construction':attr('hewn_log','inferred','Rough split/squared upright curtain is the kit proxy for the pictured high plank palisade; exact sections and joinery are not measured.',[plate]),
 'picket_height_m':attr(2.8,'reconstructed','2.8m trial enclosure height. Source says high and shows it above the low house’s main wall; no metric figure is stated. Test occlusion with the unchanged core, do not raise core automatically.'),
 'picket_width_m':attr(.18,'reconstructed','0.18m first-comparison post/plank face width, not measured timber stock.'),
 'picket_spacing_m':attr(.20,'reconstructed','0.20m centre spacing, a dense curtain proxy; exact drawn rhythm remains to compare.'),
 'picket_head_m':attr(.25,'reconstructed','0.25m sharpened cap proxy; source has pointed/uneven tops but no dimension.'),
 'curtain_runs':attr([[0,0,7.85,0],[7.85,0,7.85,1.1548],[7.85,5.422,7.85,5.622],[7.85,5.622,7.5,5.622],[6.6,5.622,0,5.622],[0,5.622,0,0]],'reconstructed','Explicit perimeter runs stop at the partly embedded house rather than cutting a full rectangular fence through its walls. Closed/unseen returns and all offsets are reconstructed. The north-wall gap is a0.9m low wicket near the house, not the family’s centered fort gateway.'),
 'wickets':attr([[6.6,5.622,7.5,5.622,1.0]],'reconstructed','Low0.9m-wide/1.0m-high first-comparison rail/brace wicket beside the house; counts/category are pictured, exact width/height/station/opening detail remain reconstructed. It is shut as a modeling instant, not a source-proved daily condition.'),
}
pali={'id':'log_jail_palisade','name':'The first jail’s enclosing palisade and wicket','aka':['the high plank palisade around the log jail'],'archetype':'palisade','part_of':attr('log_jail','inferred','The source explicitly describes the jail as concealed by this palisade, with the house partly in the same enclosure. This boundary remains part of the original ticket’s grouped picture.',[src]),'phases':[phase('log_jail_palisade',-.35,-.35,[[0,0],[7.85,0],[7.85,5.622],[0,5.622]],pali_form,'NW public-square jail compound; reconstructed boundary tied to the fixed log_jail anchor.')],'function':attr('jail','inferred','Confinement enclosure of the county jail; no military use is implied by the shared palisade archetype.',[src]),'research_note':'NEW BOUNDARY MEMBER OF THE SAME PICTURED JAIL. No claim this exact enclosure was built in1833or completely finished by1July1835. Public-domain1902plate caption1836and Gale’s retrospective1835text are distinct. The footprint envelope is about7.85×5.622m, chosen relative to the existing invented core, not traced or surveyed. The house partly overlaps the nominal envelope; curtain runs deliberately stop where its walls complete that boundary. A low off-centre wicket replaces the generic centered fort gate only in this opt-in path. Street-facing north edge is0.70m beyond the fixed core’s north wall: based on the anchor’s stated1.5m setback this leaves about0.8m to the drawn frontage, which is NOT a certified street/lot-margin pass. Exact corridor and walking clearances must be checked before integration. Outer street rail, plankwalk, flagstaff, people, animals and background camp are not built here and remain context differences.'}
for d in [house,pali]:
 rel='chicago/4d/data/structures/'+d['id']+'.json';assert not (R/rel).exists();changes[rel]=('',json.dumps(d,indent=2,ensure_ascii=False)+'\n')
# Replace the obsolete only-roof claim without touching core geometry or its frozen next-pitch package.
rel='chicago/4d/data/structures/log_jail.json';old=(R/rel).read_text();a=json.loads(old);prior=a['phases'][0]['change_note'];new='The original log jail, at the northwest corner of the public square, remains on its unchanged scene date/footprint/position. Gale’s1902town-walk narrative framed in1835also names a high palisade and John Beach’s house partly in it facing Randolph; new proposed records log_jail_palisade and log_jail_keeper_house represent those actual pictured components, with inferred Julycontinuity and reconstructed plans/offsets. Thus the earlier assertion that this jail is the only county roof on the block is not retained as a literal census of its compound. The courthouse remains excluded until fall1835and the engine house until later; no worship/school building is added to the square. The1836plate caption and Andreas’s original/later separate cell and contrasting hip-cap evidence remain explicit. No core geometry is changed by the compound-record increment.'
changes[rel]=(old,old.replace(json.dumps(prior),json.dumps(new),1))
# Bounded shared-archetype opt-in; old calls and positional parameters remain intact.
rel='chicago/4d/generators/archetypes/palisade_params.py';old=(R/rel).read_text();s=old.replace('"rail_courses", "panel_length_m", "panel_offset_m", "fence_height_m",','"rail_courses", "panel_length_m", "panel_offset_m", "fence_height_m",\n    "curtain_runs", "wickets",')
helper='''def _boundary_rows(value, size, name):
    if value is None:
        return ()
    if not isinstance(value, (tuple, list)):
        raise ParamError(name + " must be an array")
    out=[]
    for row in value:
        if not isinstance(row, (tuple,list)) or len(row)!=size or any(
                isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v)
                for v in row):
            raise ParamError(name + " requires finite numeric tuples")
        out.append(tuple(float(v) for v in row))
    return tuple(out)


'''
s=s.replace('@dataclass\nclass PalisadeParams:',helper+'@dataclass\nclass PalisadeParams:',1)
marker='    def conf(self, attr: str, default: str = "reconstructed") -> float:';assert marker in s
s=s.replace(marker,'    # Opt-in boundary portions joined by a real adjoining building. Empty preserves\n    # every old rectangular curtain/gate/bastion path and positional constructor.\n    curtain_runs: tuple = field(default=(), kw_only=True)\n    wickets: tuple = field(default=(), kw_only=True)\n\n'+marker,1)
s=s.replace('        return int(math.floor(self.perimeter_m / max(self.picket_spacing_m, 1e-6)))','        if self.curtain_runs:\n            return sum(max(1, int(round(math.dist(r[:2], r[2:]) / self.picket_spacing_m)))\n                       for r in self.curtain_runs)\n        return int(math.floor(self.perimeter_m / max(self.picket_spacing_m, 1e-6)))',1)
s=s.replace('        if self.wall_kind == "picket_stockade":\n            self._validate_stockade()','        self._validate_custom_runs()\n        if self.wall_kind == "picket_stockade":\n            self._validate_stockade()',1)
insert='''    def _validate_custom_runs(self) -> None:
        if not self.curtain_runs and not self.wickets:
            return
        if not self.curtain_runs or self.wall_kind != "picket_stockade":
            raise ParamError("custom wickets need explicit stockade curtain_runs")
        if self.gate_sides or self.bastion_corners:
            raise ParamError("curtain_runs cannot combine with ordinary gates/bastions")
        if len(self.curtain_runs) > 32 or len(self.wickets) > 4:
            raise ParamError("custom boundary exceeds bounded32runs/4wickets")
        segments = []
        for kind, rows, size in (("curtain", self.curtain_runs, 4),
                                 ("wicket", self.wickets, 5)):
            for row in rows:
                if not isinstance(row, (tuple, list)) or len(row) != size or any(
                        isinstance(v, bool) or not isinstance(v, (int, float)) or
                        not math.isfinite(v) for v in row):
                    raise ParamError("custom boundary requires finite numeric tuples")
                x0,y0,x1,y1 = row[:4]
                if any(x < 0 or x > self.width_m for x in (x0,x1)) or any(
                        y < 0 or y > self.depth_m for y in (y0,y1)):
                    raise ParamError("custom boundary leaves footprint bounds")
                horizontal = abs(y1-y0) < 1e-8 and (abs(y0)<1e-8 or abs(y0-self.depth_m)<1e-8)
                vertical = abs(x1-x0) < 1e-8 and (abs(x0)<1e-8 or abs(x0-self.width_m)<1e-8)
                length = math.dist((x0,y0),(x1,y1))
                if not (horizontal or vertical) or length < .08:
                    raise ParamError("custom boundary must be nonempty axial perimeter runs")
                axis = "x" if horizontal else "y"
                fixed = y0 if horizontal else x0
                lo,hi = sorted((x0,x1) if horizontal else (y0,y1))
                for ax,at,a,z in segments:
                    if axis==ax and abs(fixed-at)<1e-8 and min(hi,z)-max(lo,a)>1e-8:
                        raise ParamError("custom curtains/wickets overlap")
                segments.append((axis,fixed,lo,hi))
                if kind=="wicket" and not (.6<=length<=2.0 and .6<=row[4]<=min(1.6,self.picket_height_m)):
                    raise ParamError("wicket width/height outside bounded low pedestrian gate")

'''
s=s.replace('    def _validate_fence(self) -> None:',insert+'    def _validate_fence(self) -> None:',1)
s=s.replace('        confidence=confidences,','        confidence=confidences,\n        curtain_runs=_boundary_rows(val("curtain_runs"),4,"curtain_runs"),\n        wickets=_boundary_rows(val("wickets"),5,"wickets"),',1);assert s!=old;changes[rel]=(old,s)
rel='chicago/4d/generators/archetypes/palisade.py';old=(R/rel).read_text();s=old
needle='    c_wall = p.worst_conf("wall_kind", "picket_height_m", "construction")\n';assert needle in s
s=s.replace(needle,needle+'    if p.curtain_runs:\n        for x0,y0,x1,y1 in p.curtain_runs:\n            _picket_run(b, p, (x0,y0), (x1,y1), c_wall)\n        for wicket in p.wickets:\n            _low_wicket(b, wicket, 1.0)\n        return\n',1)
newhelper='''
def _low_wicket(b: MeshBuilder, row, conf: float) -> None:
    """Reconstructed low rail/brace gate, opt-in; no military lintel or two-leaf claim."""
    x0,y0,x1,y1,height = row
    length = math.dist((x0,y0),(x1,y1));ux,uy=(x1-x0)/length,(y1-y0)/length
    nx,ny=-uy,ux
    for x,y in ((x0,y0),(x1,y1)):
        _post(b,x,y,ux,uy,nx,ny,.055,.045,height+.10,conf,M_TIMBER)
    for z in (.08,height*.48,height-.10):
        _beam(b,(x0,y0),(x1,y1),nx,ny,.025,z,z+.07,conf,M_TIMBER)
    # One closed diagonal plank: exact section/height/station are reconstruction.
    a=(x0,y0,.15);z=(x1,y1,height-.15)
    dx,dy,dz=z[0]-a[0],z[1]-a[1],z[2]-a[2];norm=math.sqrt(dx*dx+dy*dy+dz*dz)
    ax,ay,az=dx/norm,dy/norm,dz/norm
    # normal to the plank within its vertical gate plane
    vx,vy,vz=ny*az,-nx*az,nx*ay-ny*ax
    def ring(p):
        return [(p[0]+sv*vx*.035+sn*nx*.025,p[1]+sv*vy*.035+sn*ny*.025,
                 p[2]+sv*vz*.035) for sv,sn in ((-1,-1),(1,-1),(1,1),(-1,1))]
    lo,hi=ring(a),ring(z)
    b.add_poly(list(reversed(lo)),conf,M_TIMBER);b.add_poly(hi,conf,M_TIMBER)
    for i in range(4):
        j=(i+1)%4;b.add_poly([lo[i],lo[j],hi[j],hi[i]],conf,M_TIMBER)

'''
s=s.replace('\ndef _gate(b: MeshBuilder, p: PalisadeParams, side: str, conf: float) -> None:',newhelper+'\ndef _gate(b: MeshBuilder, p: PalisadeParams, side: str, conf: float) -> None:',1);changes[rel]=(old,s)
# Plain spacing in newly authored descriptive fields; never alter IDs/URLs/metrics.
fixes={'O.Gale':'O. Gale','H.Revell':'H. Revell','Company,1902':'Company, 1902','copyright1902':'copyright 1902','US1902title':'US 1902 title','arrival25May1835':'arrival 25 May 1835','facingp53':'facing p53','captioned1836':'captioned 1836','printedp25':'printed p25','the1835':'the 1835','later1930':'later 1930','and1947':'and 1947','onp43':'on p43','retrospective1835':'retrospective 1835','independent1902':'independent 1902','on1July1835':'on 1 July 1835','by1July1835':'by 1 July 1835','The1836':'The 1836','the1836':'the 1836','caption1836':'caption 1836','aJulydate':'a July date','roughly20m':'roughly 20m','existing20×15ft':'existing 20×15ft','stories1;':'stories 1;','its1.5-storey2.9m':'its 1.5-storey 2.9m','exact1902plate':'exact 1902 plate','Julycontinuity':'July continuity','or6×8inch':'or 6×8inch','link is made.20×14ft':'link is made. 20×14ft','invented.20×14ft':'invented. 20×14ft','at stories1:':'at stories 1:','a0.9m':'a 0.9m','Low0.9m':'Low 0.9m','in1833or':'in 1833 or','Public-domain1902plate':'Public-domain 1902 plate','about7.85×5.622m':'about 7.85×5.622m','edge is0.70m':'edge is 0.70m','stated1.5m':'stated 1.5m','about0.8m':'about 0.8m','Gale’s1902town':'Gale’s 1902 town','in1835also':'in 1835 also','fall1835and':'fall 1835 and'}
def clean(v,key=''):
    if isinstance(v,dict):return {k:clean(x,k) for k,x in v.items()}
    if isinstance(v,list):return [clean(x,key) for x in v]
    if isinstance(v,str) and key in {'note','research_note','citation','author','date','describes_date','locator','rights_note','repository','what_it_supplies','what_it_does_not_supply'}:
        for x,y in fixes.items():v=v.replace(x,y)
    return v
for rel,(a,z) in list(changes.items()):
    if not a and rel.endswith('.json'):
        d=clean(json.loads(z))
        if d.get('id')=='log_jail_palisade':
            d['phases'][0]['form']['wickets']['note']+=' Whether the pictured low gate opens into a keeper forecourt or the secured jail itself is unresolved; this first boundary topology is reconstructed, not an archival prison-access plan.'
            d['name']='The first jail’s palisade and adjacent low gate'
        changes[rel]=(a,json.dumps(d,indent=2,ensure_ascii=False)+'\n')
patch=[];meta=[]
for rel,(a,z) in changes.items():
 for side,text in [('before',a),('after',z)]:
  if side=='before' and not a:continue
  dst=B/side/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(text)
 patch.extend(difflib.unified_diff(a.splitlines(True),z.splitlines(True),fromfile='a/'+rel if a else '/dev/null',tofile='b/'+rel))
 meta.append({'path':rel,'before_sha256':hashlib.sha256(a.encode()).hexdigest() if a else None,'after_sha256':hashlib.sha256(z.encode()).hexdigest()})
(B/'T-2380-compound-next.patch').write_text(''.join(patch));(B/'files.json').write_text(json.dumps(meta,indent=2)+'\n')
manifest=json.loads((D/'assets/manifest.json').read_text());assets=[{'asset':k,**v} for k,v in manifest['assets'].items() if v.get('archetype')=='palisade'];(B/'palisade-family.json').write_text(json.dumps({'registered_existing_masters':assets,'existing_master_count':len(assets),'registered_versions_count':0,'new_masters':['log_jail_keeper_house__context_1835.glb','log_jail_palisade__context_1835.glb'],'common_or_emit_change':False},indent=2)+'\n')
print('Prepared separate compound proposal:',len(changes),'files;',len(assets),'existing palisade masters hash affected; no app writes')
