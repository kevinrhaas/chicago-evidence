# previous final-gable proposal

Actual saved output visually inspected. Verdict: **differs**.

- **open**: Arched gable retains the previous glass/radial-fanlight working interpretation; source lettering-like fine marks remain unresolved.
- **open**: The existing entry has the prior narrow kit casing; the source broad plain entry outlines are not represented by the follow-up boards yet.
