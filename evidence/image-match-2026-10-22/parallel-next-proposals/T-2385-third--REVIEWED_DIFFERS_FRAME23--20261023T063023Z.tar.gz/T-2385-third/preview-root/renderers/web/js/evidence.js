/**
 * evidence.js — Guide › About this destination (T-2667): the old Evidence panel as four
 * cards of topics rather than one scroll.
 *
 * T-2667 (design doc section 12, NAV-1002) folded the hub's topics into four cards —
 * How we grade, Sources, Liberties, What lived and grew here (`CARDS` below) — and put
 * the order book behind Researcher mode. The section keeps its `evidence` key, and every
 * topic, mount and tile keeps its id and class, because main.js, sources.js and the smoke
 * address them by those. What follows is the hub as it was built (T-0710); a "tile" is
 * still a topic's button, now inside its card.
 *
 * The panel used to be seven lists and their explanatory paragraphs stacked into
 * a single column: everything in it was worth reading and none of it could be
 * found. This module leaves that markup where it is — the mounts `#liberties`,
 * `#ground`, `#fauna`, `#plants`, `#exclusions`, `#uncertain` and their `-note`
 * paragraphs keep their ids, because liberties.js, ground.js, fauna.js,
 * plants.js and exclusions.js render into them from main.js and the smoke reads
 * them by id — and shows ONE topic at a time behind a grid of tiles. A tile is
 * the topic's icon, its title, how many entries its mount holds, and one line
 * saying what the list is; a topic is its entries, a search box that narrows
 * them by text, pills built from whatever `.lib-scope` chips the entries
 * carry, and the long prose folded under "About this list" so the entries come
 * first.
 *
 * Nothing here knows the shape of a topic's data. Counts, pills and search all
 * read the DOM the mounting modules produce (`details` children of the mount,
 * `.lib-scope` chip texts), so a list that grows or gains a category is
 * reflected without this file changing — and because those modules fill their
 * mounts asynchronously after boot, the counts are re-read on every show and
 * whenever a mount mutates.
 *
 * Contract (main.js): createEvidenceHub({ root, onTitle, omit }) ->
 *   { showHub({ keep }), showTopic(id), showCard(id), get topic, get cards }
 * `onTitle(text, onBack)` is the drawer head (hud.setTitle): a topic pushes its
 * title and a back action; `onTitle(null)` restores the section's own name.
 * `omit` (T-1740) names topics the scene does not carry — the 1835 town's
 * wildlife, plants, residents and research record in a scene of another date:
 * they get no tile, their container stays hidden, and `showTopic` refuses them.
 * `showHub({ keep: true })` is what the tab re-selection sends: an open topic
 * stays open (the head title is re-pushed, because selecting a tab resets it).
 */
import { t as str } from './strings/index.js';
import './strings/hud.js';
import './strings/guide-about.js';
import { escapeHtml } from './citations.js';

const SVG = (paths) => `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor"`
  + ` stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths}</svg>`;

/** The topics, in the order the tiles read. Titles are NOT here: they are
 *  read from each topic's own `h3.legend-h`, so the tile and the head can never
 *  say two different things. `facet` turns one entry into the pill it belongs
 *  under (null = no pill for this entry; a topic whose entries yield fewer than
 *  two distinct facets gets no pills at all). */
const TOPICS = [
  {
    id: 'grades',
    gloss: str('hud.sources.grades'),
    icon: SVG('<circle cx="12" cy="12" r="8.5"/><path d="M8.5 12.2l2.3 2.3 4.7-5"/>'),
    entries: (topic) => [...topic.querySelectorAll('.legend-list > li')],
    facet: () => null,
  },
  {
    id: 'city',
    gloss: str('guide-about.topic.city'),
    icon: SVG('<path d="M4 20V8l4-3 4 3v12"/><path d="M12 20V5l4-2 4 2v15"/><path d="M2 20h20"/>'),
    mount: '#city',
    entries: (topic) => [...topic.querySelectorAll('#city .gc-row')],
    facet: () => null,
  },
  {
    id: 'sources', gloss: str('guide-about.topic.sources'),
    icon: SVG('<path d="M4 3h16v18H4zM8 7h8M8 11h8M8 15h5"/>'),
    mount: '#sources', entries: () => [], facet: () => null,
  },
  {
    id: 'liberties',
    gloss: str('guide-about.topic.liberties'),
    icon: SVG('<path d="M4 20l4.5-1 10-10a2.1 2.1 0 0 0-3-3l-10 10z"/><path d="M13.5 8l3 3"/>'),
    facet: scopeFacet,
  },
  {
    id: 'ground',
    gloss: str('guide-about.topic.ground'),
    icon: SVG('<path d="M3 8c3 2 6 2 9 0s6-2 9 0"/><path d="M3 13c3 2 6 2 9 0s6-2 9 0"/>'
      + '<path d="M3 18c3 2 6 2 9 0s6-2 9 0"/>'),
    facet: scopeFacet,
  },
  {
    id: 'fauna',
    gloss: str('guide-about.topic.fauna'),
    icon: SVG('<circle cx="7.5" cy="9" r="1.6"/><circle cx="12" cy="6.5" r="1.6"/><circle cx="16.5" cy="9" r="1.6"/>'
      + '<path d="M12 11.5c-3 0-5.5 2.6-5.5 5.2 0 1.6 1.2 2.6 2.6 2.6 1.1 0 1.8-.6 2.9-.6s1.8.6 2.9.6c1.4 0 2.6-1 2.6-2.6 0-2.6-2.5-5.2-5.5-5.2z"/>'),
    facet: () => null,
  },
  {
    id: 'plants',
    gloss: str('guide-about.topic.plants'),
    icon: SVG('<path d="M12 21v-9"/><path d="M12 12c0-4.5 3.2-7.5 8-7.5 0 5.2-3.2 8.2-8 7.5z"/>'
      + '<path d="M12 16c0-3-2.6-5-6-5 0 3.6 2.6 5.6 6 5z"/>'),
    facet: () => null,
  },
  {
    id: 'exclusions',
    gloss: str('guide-about.topic.exclusions'),
    icon: SVG('<circle cx="12" cy="12" r="8.5"/><path d="M6 6l12 12"/>'),
    // The chip is the record's own `earliest_scene`; an entry without one had
    // already come down. Two findings, one list — the pills tell them apart.
    facet: (entry) => (scopeFacet(entry) ? 'not until' : 'came down'),
  },
  {
    id: 'uncertain',
    gloss: str('guide-about.topic.uncertain'),
    icon: SVG('<circle cx="12" cy="12" r="8.5"/><path d="M9.5 9.6a2.6 2.6 0 1 1 4.1 2.1c-1 .8-1.6 1.4-1.6 2.6"/>'
      + '<path d="M12 17.4h.01"/>'),
    facet: scopeFacet,
  },
  {
    id: 'population',
    gloss: str('guide-about.topic.population'),
    icon: SVG('<circle cx="9" cy="8.5" r="3"/><path d="M3.5 19.5c0-3 2.5-5 5.5-5s5.5 2 5.5 5"/>'
      + '<path d="M16 6.2a3 3 0 0 1 0 5.6"/><path d="M17.5 14.9c1.9.6 3 2.4 3 4.6"/>'),
    // The chip is the section's own row count: an axis is as big as the table
    // under it, and a pill per axis would be a pill per entry.
    facet: () => null,
  },
  {
    id: 'orderbook',
    gloss: str('guide-about.researcher.topic.orderbook'),
    icon: SVG('<path d="M4 5.5h6.5a2 2 0 0 1 2 2V19a2 2 0 0 0-2-2H4z"/>'
      + '<path d="M20 5.5h-5.5a2 2 0 0 0-2 2V19a2 2 0 0 1 2-2H20z"/>'
      + '<path d="M12.5 7.5V19"/>'),
    // The chip is the family's own filled/to-do count, which the summary row
    // already carries — a pill per bucket would be a pill per cell of the town.
    facet: () => null,
  },
];

/**
 * T-2667 (NAV-1002; design doc section 12): the topics fold into four cards, in this
 * order — How we grade, Sources, Liberties, What lived and grew here — and the order
 * book, internal language (the quota, the work still owed), goes behind Researcher mode
 * (owner ruling 2026-10-16). Every topic is in exactly one card. A card a scene leaves
 * with no topic is not drawn; the four visitor cards each keep one in 1835 and in 1904
 * (How we grade, Sources, Liberties and the ground are in every scene). `inspect` cards
 * say that one building's own share of them is on Inspect's Sources tab (T-2644).
 */
export const CARDS = [
  { id: 'grading', topics: ['grades', 'city'] },
  { id: 'sources', topics: ['sources'], inspect: true },
  { id: 'liberties', topics: ['liberties', 'exclusions', 'uncertain'], inspect: true },
  { id: 'living', topics: ['ground', 'fauna', 'plants', 'population'] },
  { id: 'research', topics: ['orderbook'], researcher: true },
];
export const TOPIC_IDS = TOPICS.map((t) => t.id);
export const VISITOR_CARDS = CARDS.filter((c) => !c.researcher).map((c) => c.id);

/** The card a topic is filed under. */
export function cardOf(topicId) {
  return CARDS.find((c) => c.topics.includes(topicId))?.id ?? null;
}

/** The cards a scene shows, with their words and the topics it carries, in order. */
export function hubPlan(omit = []) {
  return CARDS.map((c) => ({
    id: c.id,
    researcher: !!c.researcher,
    topics: c.topics.filter((id) => !omit.includes(id)),
    title: str(c.researcher ? 'guide-about.researcher.card' : `guide-about.card.${c.id}`),
    line: str(c.researcher ? 'guide-about.researcher.card.line' : `guide-about.card.${c.id}.line`),
    hint: c.inspect ? str(`guide-about.card.${c.id}.inspect`) : '',
  })).filter((c) => c.topics.length);
}

/** The hub's markup: a section per card (the researcher's marked `data-researcher`), each
 *  a heading, its line, its topics' tiles and, for Sources and Liberties, the pointer to
 *  Inspect. `topics` maps a topic id to { id, title, gloss, icon }. */
export function hubHtml(plan, topics) {
  // T-2657: a topic that is Researcher mode's (`researcher`, or its markup's `data-researcher`)
  // marks its own tile too, so it stays off a visitor's screen whichever card it is filed under.
  const mine = (t) => !!(t.researcher || t.el?.hasAttribute?.('data-researcher'));
  const tile = (t) => `<button class="ev-tile" type="button" data-topic="${t.id}"`
    + `${mine(t) ? ' data-researcher' : ''} aria-label="${escapeHtml(t.title)}">`
    + `<span class="ev-tile-head">${t.icon}<b class="ev-count" aria-label="entries">…</b></span>`
    + `<span class="ev-tile-title">${escapeHtml(t.title)}</span>`
    + `<span class="ev-gloss">${escapeHtml(t.gloss)}</span></button>`;
  return plan.map((c) => `<section class="ev-card" data-card="${c.id}"${c.researcher ? ' data-researcher' : ''}`
    + ` aria-labelledby="ev-card-${c.id}">`
    + `<h3 class="ev-card-title" id="ev-card-${c.id}" tabindex="-1">${escapeHtml(c.title)}</h3>`
    + `<p class="ev-card-line">${escapeHtml(c.line)}</p>`
    + `<div class="ev-card-tiles">${c.topics.filter((id) => topics.has(id)).map((id) => tile(topics.get(id))).join('')}</div>`
    + (c.hint ? `<p class="ev-card-hint">${escapeHtml(c.hint)}</p>` : '')
    + '</section>').join('');
}

/** A topic's tile words and icon, for hubHtml: its gloss and icon from TOPICS. */
export function topicSpec(id) {
  const t = TOPICS.find((x) => x.id === id);
  return t ? { id: t.id, gloss: t.gloss, icon: t.icon } : null;
}

/** Researcher mode is on when the root carries `data-researcher-mode` (T-2657's switch
 *  sets it; css/skins.css hides every `[data-researcher]` element until it does). */
export function researcherOn(doc = globalThis.document) {
  return !!doc?.documentElement?.hasAttribute?.('data-researcher-mode');
}

/** The chip text on an entry's own summary row — not a nested entry's. */
function scopeFacet(entry) {
  const chip = entry.querySelector(':scope > summary .lib-scope');
  return chip ? chip.textContent.trim() : null;
}

const norm = (s) => (s || '').replace(/\s+/g, ' ').trim().toLowerCase();

export function createEvidenceHub({ root, onTitle = () => {}, onTopic = () => {}, omit = [] } = {}) {
  if (!root) return { showHub() {}, showTopic() {}, showCard() { return false; }, get topic() { return null; }, get cards() { return []; } };

  const hub = root.querySelector('#evidence-hub');
  const topics = new Map();
  for (const spec of TOPICS) {
    const el = root.querySelector(`.ev-topic[data-topic="${spec.id}"]`);
    if (!el) continue;
    if (omit.includes(spec.id)) { el.hidden = true; continue; }
    const mount = el.querySelector(spec.mount || '.liberties') || el.querySelector('.legend-list');
    const title = el.querySelector('.ev-topic-title')?.textContent.trim() || spec.id;
    const entries = spec.entries || ((topic) => [...(mount?.querySelectorAll(':scope > details') ?? [])]);
    topics.set(spec.id, { ...spec, facetOf: spec.facet, el, mount, title, entries: () => entries(el), query: '', facet: null });
  }

  let current = null;

  // ---- cards, and the tiles inside them ------------------------------------
  // T-2667: the hub is four cards, each a heading, one plain line and its topics'
  // tiles; the order book's card carries `data-researcher`, so it is off a visitor's
  // screen until Researcher mode is on. The tiles are the same buttons as before.
  const plan = hubPlan(omit).map((c) => ({ ...c, topics: c.topics.filter((id) => topics.has(id)) }))
    .filter((c) => c.topics.length);
  const researcherTopics = new Set(plan.filter((c) => c.researcher).flatMap((c) => c.topics));
  if (hub) {
    hub.innerHTML = hubHtml(plan, topics);
    hub.addEventListener('click', (e) => {
      const tile = e.target.closest('.ev-tile');
      if (tile) showTopic(tile.dataset.topic, { focus: true });
    });
  }

  /** The count on a tile is the mount's entries, read now. A mount still marked
   *  `aria-busy` (the module has not filled it) shows an ellipsis rather than a
   *  zero, because zero would be a claim. */
  function paintCounts() {
    for (const t of topics.values()) {
      const chip = hub?.querySelector(`.ev-tile[data-topic="${t.id}"] .ev-count`);
      if (!chip) continue;
      const busy = t.mount?.hasAttribute('aria-busy');
      const n = t.id === 'sources' ? Number(t.mount?.dataset.count || 0) : t.entries().length;
      chip.textContent = busy && n === 0 ? '…' : String(n);
      chip.classList.toggle('is-busy', !!busy && n === 0);
    }
  }

  // The modules fill their mounts after boot, each on its own fetch; the tiles
  // follow the mounts rather than any of those promises.
  let raf = 0;
  const schedule = () => {
    if (raf) return;
    raf = requestAnimationFrame(() => {
      raf = 0;
      paintCounts();
      if (current) applyFilter(topics.get(current), { rebuildPills: true });
    });
  };
  if (typeof MutationObserver === 'function') {
    const mo = new MutationObserver(schedule);
    for (const t of topics.values()) if (t.mount) mo.observe(t.mount, { childList: true, subtree: false, attributes: true, attributeFilter: ['aria-busy'] });
  }

  // ---- per-topic tools: search, pills, status -----------------------------
  for (const t of topics.values()) {
    if (t.id === 'grades' || t.id === 'city' || t.id === 'sources') continue; // compact summaries need no search box
    const tools = document.createElement('div');
    tools.className = 'ev-tools';
    tools.innerHTML = `<div class="ev-search-row"><input class="ev-search" type="search" autocomplete="off" spellcheck="false"`
      + ` placeholder="Search ${escapeHtml(t.title.toLowerCase())}…" aria-label="Search ${escapeHtml(t.title.toLowerCase())}">`
      + `<span class="ev-status" aria-live="polite"></span></div>`
      + `<div class="ev-pills" role="group" aria-label="Narrow by kind" hidden></div>`
      + `<p class="ev-empty" hidden></p>`;
    // First in the topic, after its (head-duplicated) title: the tools are what
    // a visitor reaches for before the note, and the mount stays the last child
    // so the `-note` → list sibling walk the smoke does still spans the block.
    const title = t.el.querySelector('.ev-topic-title');
    if (title) title.after(tools); else t.el.prepend(tools);
    t.tools = tools;
    t.search = tools.querySelector('.ev-search');
    t.status = tools.querySelector('.ev-status');
    t.pills = tools.querySelector('.ev-pills');
    t.empty = tools.querySelector('.ev-empty');
    // The empty state sits with the entries, where the entries would be.
    if (t.mount) t.mount.before(t.empty);
    t.search.addEventListener('input', () => { t.query = t.search.value; applyFilter(t); });
    t.pills.addEventListener('click', (e) => {
      const pill = e.target.closest('.ev-pill');
      if (!pill) return;
      const v = pill.dataset.facet ?? null;
      t.facet = (v === '' || t.facet === v) ? null : v;
      applyFilter(t);
    });
  }

  /** Pills are the distinct facets the entries carry right now, single-select,
   *  with "All" first. Rebuilt only when asked (a mount mutated) so the pressed
   *  one keeps its identity across filtering. */
  function buildPills(t) {
    if (!t.pills) return;
    const facets = new Map();
    for (const en of t.entries()) {
      const f = t.facetOf(en);
      if (f) facets.set(f, (facets.get(f) || 0) + 1);
    }
    if (facets.size < 2 || facets.size > 12) {
      t.pills.hidden = true; t.pills.innerHTML = ''; t.facet = null; return;
    }
    if (t.facet && !facets.has(t.facet)) t.facet = null;
    const items = [['', 'All', t.entries().length], ...[...facets.entries()].map(([f, n]) => [f, f, n])];
    t.pills.innerHTML = items.map(([v, label, n]) => `<button class="ev-pill" type="button" data-facet="${escapeHtml(v)}"`
      + ` aria-pressed="${String((t.facet ?? '') === v)}">${escapeHtml(label)} <small>${n}</small></button>`).join('');
    t.pills.hidden = false;
  }

  /** Show the entries whose text carries the query and whose facet is the
   *  pressed pill. Entries that hold entries (a habitat with its animals, a
   *  community with its plants) are opened around their matching children while
   *  a query stands, and closed again when it clears — the visitor's own opens
   *  are left alone. */
  function applyFilter(t, { rebuildPills = false } = {}) {
    if (!t || !t.tools) return;
    if (rebuildPills) buildPills(t);
    else t.pills?.querySelectorAll('.ev-pill').forEach((p) => p.setAttribute('aria-pressed', String((t.facet ?? '') === (p.dataset.facet ?? ''))));
    const q = norm(t.query);
    const all = t.entries();
    let shown = 0;
    for (const en of all) {
      const facetOk = !t.facet || t.facetOf(en) === t.facet;
      const textOk = !q || norm(en.textContent).includes(q);
      const on = facetOk && textOk;
      en.toggleAttribute('hidden', !on);
      if (on) shown += 1;
      const nested = [...en.querySelectorAll(':scope > * details, :scope > details')];
      if (!nested.length) continue;
      if (on && q) {
        const hits = nested.filter((d) => norm(d.textContent).includes(q));
        // A match on the parent's own words alone leaves its children as they were.
        const narrow = hits.length > 0 && hits.length < nested.length;
        nested.forEach((d) => d.toggleAttribute('hidden', narrow && !hits.includes(d)));
        if (hits.length && !en.open) { en.open = true; en.dataset.evOpened = '1'; }
      } else {
        nested.forEach((d) => d.removeAttribute('hidden'));
        if (en.dataset.evOpened) { delete en.dataset.evOpened; en.open = false; }
      }
    }
    const total = all.length;
    const filtered = !!q || !!t.facet;
    t.status.textContent = total === 0 ? '' : filtered ? `${shown} of ${total} shown` : `${total} entries`;
    const none = filtered && total > 0 && shown === 0;
    t.empty.hidden = !none;
    if (none) {
      t.empty.textContent = q
        ? `Nothing here carries “${t.query.trim()}”. Try a shorter word, a name, or clear the search.`
        : 'Nothing under this pill yet. Choose another, or All.';
    }
  }

  // ---- views ---------------------------------------------------------------
  function scrollTop() {
    const sc = root.closest('.panel-scroll') || root.parentElement;
    if (sc) sc.scrollTop = 0;
  }

  function showTopic(id, { focus = false } = {}) {
    const t = topics.get(id);
    if (!t) return;
    // The order book opens only in Researcher mode: its topic is hidden without it.
    if (researcherTopics.has(id) && !researcherOn(root.ownerDocument)) return;
    current = id;
    if (hub) hub.hidden = true;
    for (const o of topics.values()) o.el.hidden = o !== t;
    paintCounts();
    applyFilter(t, { rebuildPills: true });
    onTitle(t.title, () => showHub({ focusTile: id }));
    scrollTop();
    onTopic(id);
    if (focus) {
      t.el.setAttribute('tabindex', '-1');
      t.el.focus({ preventScroll: true });
    }
  }

  function showHub({ keep = false, focusTile = null } = {}) {
    if (keep && current) {
      // The tab was re-selected: stay where the visitor was, and re-push the
      // head title the tab change just reset.
      const t = topics.get(current);
      paintCounts();
      applyFilter(t, { rebuildPills: true });
      onTitle(t.title, () => showHub({ focusTile: current }));
      onTopic(current);
      return;
    }
    const left = focusTile ?? current;
    current = null;
    for (const o of topics.values()) o.el.hidden = true;
    if (hub) hub.hidden = false;
    paintCounts();
    onTitle(null);
    scrollTop();
    if (focusTile && hub) hub.querySelector(`.ev-tile[data-topic="${left}"]`)?.focus({ preventScroll: true });
  }

  /** Open the hub at one card (Guide's About this destination block asks for it). */
  function showCard(id, { focus = true } = {}) {
    const card = hub?.querySelector(`.ev-card[data-card="${id}"]`);
    if (!card || (card.hasAttribute('data-researcher') && !researcherOn(root.ownerDocument))) return false;
    showHub();
    card.scrollIntoView?.({ block: 'start' });
    if (focus) card.querySelector('.ev-card-title')?.focus({ preventScroll: true });
    return true;
  }

  showHub();

  return {
    showHub,
    showTopic,
    showCard,
    get topic() { return current; },
    get cards() { return plan.map((c) => c.id); },
  };
}
