/**
 * The drawer's sections, held by Navigator apps (T-2620, NAV-206; DESIGN §14 "App
 * registry": goto, people, businesses, evidence and settings mount inside apps and keep
 * their element ids).
 *
 * The drawer is gone, and its parts are not rebuilt: the one `#panel` element — its head
 * (back, title, close), its section tabs and its scroll column, with every section inside
 * it — moves into whichever app's screen is open, and that app shows only its own
 * sections' tabs. So every id the page, its modules and the smoke read still resolves,
 * every listener stays where it was bound, and `hud.setPanel` / `hud.selectTab` keep
 * their meaning (open a section, close it) through the adapter `install()` gives the HUD.
 *
 *   Move      Travel
 *   People    People · Businesses         (1835; 1904 has its own People screen)
 *   Guide     Controls · Evidence         (Evidence is About this destination, T-2667)
 *   Settings  Settings · What's new       (What's new's dot rides the Settings icon)
 *
 * Go to is not among them: it is the Jaunts app's own segment (T-2630), the arrival's
 * search lent to the device, so the drawer's Go to list retires with the drawer. Asking
 * the HUD for it (G, or hud.selectTab('goto')) opens that segment instead (`openGoTo`).
 *
 * Each redesign is its own ticket (Jaunts/Go to E4, People, Settings T-2656, Evidence →
 * Guide › About this destination T-2667, done: four cards, the section keeps its `evidence`
 * key); this moves the sections as they are.
 */

/** Which app holds each of the drawer's sections. */
export const SECTION_HOME = Object.freeze({
  travel: 'move', people: 'people', businesses: 'people',
  controls: 'guide', evidence: 'guide', settings: 'settings', whatsnew: 'settings',
});
export const APP_SECTIONS = Object.freeze(Object.entries(SECTION_HOME).reduce((m, [tab, app]) => {
  (m[app] ??= []).push(tab);
  return m;
}, {}));

const panelEl = (doc) => doc.getElementById('panel');

/** The tabs this app shows; the others are left in place but out of sight. */
function paintTabs(doc, appId) {
  const mine = new Set(APP_SECTIONS[appId] ?? []);
  let shown = 0;
  for (const tab of doc.querySelectorAll('.panel-tab[data-tab]')) {
    const here = mine.has(tab.dataset.tab);
    tab.classList.toggle('is-elsewhere', !here);
    if (here && !tab.hidden) shown++;
  }
  // One section needs no tab row of its own: the app's header already names it.
  panelEl(doc)?.classList.toggle('has-one-section', shown < 2);
}

/**
 * The part of an app that holds sections: `shown` moves #panel into this app's screen and
 * opens its section; `hidden` closes it when the app leaves the screen or the device docks.
 */
export function sectionScreen(appId, { lead = null } = {}) {
  return {
    mount(el, ctx) {
      const doc = el.ownerDocument;
      if (lead) {
        const row = lead(doc, ctx);
        if (row) el.append(row);
      }
      void doc;
    },
    shown(el, ctx) {
      const doc = el.ownerDocument;
      const panel = panelEl(doc);
      const hud = ctx.api?.hud;
      if (!panel || !hud) return;
      if (panel.parentElement !== el) el.append(panel);
      paintTabs(doc, appId);
      const mine = (APP_SECTIONS[appId] ?? []).filter((t) => !doc.querySelector(`.panel-tab[data-tab="${t}"]`)?.hidden);
      if (!mine.includes(hud.tab) && mine.length) hud.selectTab(mine[0], { fromHost: true });
      if (!hud.panelOpen()) hud.setPanel(true, { fromHost: true });
    },
    hidden(_el, ctx) {
      const hud = ctx.api?.hud;
      if (hud?.panelOpen()) hud.setPanel(false, { fromHost: true });
    },
  };
}

/**
 * What a Go to pick does (T-2620). The arrival's search is lent to the Navigator's Jaunts
 * app as its Go to (T-2630), and with the drawer's Go to list retired it is the only Go to
 * in the town. From the gate a pick is the way in (enterWorld). In the town the gate is
 * shut and enterWorld refuses, so a pick goes there as the retired list did: goToTarget,
 * in the visitor's travel mode, to the place's card. Then the device is pocketed.
 */
export function goToPick({ inTown, goTo, enterWorld, dock, entered }) {
  return (target) => {
    if (inTown()) {
      const ok = !!target && !!goTo(target);
      if (ok) dock?.();
      return ok;
    }
    const ok = enterWorld(target);
    if (ok) entered?.();
    return ok;
  };
}

/**
 * Hand the HUD its adapter, and move What's new's dot onto the Settings icon. Called once
 * main.js has both the HUD and the Navigator.
 */
export function install({ hud, navigator, doc = globalThis.document, openGoTo = null }) {
  if (!hud || !navigator) return null;
  // The drawer's Go to list retires with the drawer: its tab leaves the row for good, and
  // any call for it opens the Jaunts app's Go to segment.
  const gotoTab = doc.querySelector('.panel-tab[data-tab="goto"]');
  if (gotoTab) gotoTab.hidden = true;
  doc.querySelector('.panel-body[data-panel="goto"]')?.setAttribute('hidden', '');
  // The HUD's opening section was Go to; with Go to gone, a bare "open the sections" (H,
  // hud.setPanel(true)) opens the Guide's first, how to get about.
  if (hud.tab === 'goto') hud.selectTab('controls', { fromHost: true });
  const goTo = () => {
    if (hud.panelOpen()) hud.setPanel(false, { fromHost: true });
    openGoTo?.();
  };
  const appFor = (tab) => SECTION_HOME[tab] ?? null;
  // An app opened for the first time may mount asynchronously (People loads a module): a
  // close that arrives before it has finished must still win, so every open and close
  // is counted, and an open that finishes after a later close is put away again.
  let closes = 0;
  const openApp = (app) => {
    const before = closes;
    void Promise.resolve(navigator.select(app)).then(() => {
      if (before === closes) return;
      if (hud.panelOpen()) hud.setPanel(false, { fromHost: true });
      if (APP_SECTIONS[navigator.app]) navigator.dock();
    });
  };
  const adapter = {
    open(tab) {
      if (tab === 'goto') return goTo();
      const app = appFor(tab);
      if (app) openApp(app);
    },
    close() {
      closes++;
      if (APP_SECTIONS[navigator.app]) navigator.dock();
    },
    show(tab) {
      if (tab === 'goto') return goTo();
      const app = appFor(tab);
      if (app && app !== navigator.app) openApp(app);
      else if (app) paintTabs(doc, app);
    },
  };
  hud.setHost(adapter);
  // What's new's dot: the HUD keeps setting #help-dot; it now sits on the Settings icon.
  const dot = doc.getElementById('help-dot');
  const settings = doc.querySelector('#nav-rail [data-app="settings"]');
  if (dot && settings) {
    settings.querySelector('.nav-app-dot')?.remove();
    dot.className = 'nav-app-dot';
    settings.append(dot);
  }
  return adapter;
}
