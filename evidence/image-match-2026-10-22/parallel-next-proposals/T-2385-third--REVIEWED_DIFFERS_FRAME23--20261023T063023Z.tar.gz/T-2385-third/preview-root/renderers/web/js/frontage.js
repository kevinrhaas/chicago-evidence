/**
 * frontage.js — the plank walks, the board crossings, the hitching posts and the
 * named boards on posts that stand between a building and the street it fronts
 * on. Written for the Green Tree Tavern (T-0082) and made a town layer by the
 * Sauganash Hotel (T-0090), which brought the second record and the first post
 * with nothing hanging on it. T-0119 brought the first record that is not a
 * building's frontage at all — the river plank walk, which rides a committed
 * bridge deck at the slough mouth (`deck_m`), runs on polyline centrelines in
 * culling-sized chunks, registers its over-water planks with the walker
 * (`walkableDecks`), and answers a pick with its own card.
 *
 * T-0069 MADE IT THE STREET'S EDGE. The owner, of the first Cook County jail
 * engraving: *"note the fences lining the street and what appears to be plank
 * sidewalks. all of the streets should be updated like this... at least south of
 * the river or near the river."* The record that answers it
 * (`data/frontage/town_street_edge.json`) is a town's worth of the same two
 * things this file already drew, laid on the platted block faces rather than on
 * a wall, and it brings three additions — all of them additive, and the two
 * inns' and the river walk's geometry comes out byte for byte unchanged:
 *
 *  * **`chunk`.** A walk, a crossing and a fence that carry the same `chunk` id
 *    build ONE mesh with one bounding sphere. That is culling AND draw calls at
 *    once: a block face's sidewalk, the crossing at its corner and the fence
 *    behind it are one street edge and one draw call, so a town's worth of them
 *    costs meshes by the block face rather than by the object.
 *  * **`stringer_pitch_m`.** The stringers under a walk used to be two boxes
 *    under EVERY board — three quarters of a walk's triangles for the strip of
 *    shadow under its edge. A record may now lay them in BAYS instead, and the
 *    generator only sets it where it has audited the ground flat enough for a
 *    bay-length stringer to meet it (see `tools/generate_frontage_works.py`).
 *  * **`fences`.** A board fence at the frontage line, with the walk at its
 *    foot, which is what the jail engraving shows. It is drawn HERE and not by
 *    `enclosures.js` for two reasons that are the same reason: an enclosure
 *    takes a closed PERIMETER and encloses ground that gets its own treatment
 *    (`yards.js`), and a street-lining run is an open line that encloses
 *    nothing — it is the street edge, which is this layer's whole subject. And
 *    sharing the walk's chunk is what keeps the pair inside the draw-call
 *    budget the scene actually has.
 *
 * WHY THIS IS A LAYER AND NOT MORE YARD GOODS. A barrel or a wagon stands on a
 * building's own ground and is derived from its walls alone, which is what
 * `yard.js` draws. A walk and a crossing stand in the STREET, and the number
 * that decides where they may lie belongs to the street — the travelled track's
 * own half-width out of `data/streets/1835.json`. This is the first thing in
 * the project derived from a building and a street at once.
 *
 * WHAT IT WILL AND WILL NOT DO.
 *
 *  * Every board sits on the TERRAIN, sampled under its own centre, exactly as
 *    a barrel does. A walk laid on one height would float at one end of a
 *    frontage and be buried at the other, and this ground is not flat.
 *  * It draws LETTERING, and it is the only thing in this renderer that does.
 *    `docs/LIBERTIES.md` L25 leaves the town's one documented board blank
 *    because nobody described the painting on it; this board's subject is a
 *    NAME that the reference view states in as many words, so the wording is
 *    the plate's and only the letterform is invented (L135). The record carries
 *    the text and the argument; this file only draws what the record says, and
 *    a record with no `text` gets a blank board.
 *  * The timber is ONE draw call for the whole layer, the way the fences and
 *    the signboards are. The lettering is a second, because a painted name is a
 *    texture and timber is not — and it exists only when a board carries text.
 *  * It marks itself. Every vertex carries its grade, so the whole layer
 *    disappears when a visitor hides `reconstructed` and the frontage goes back
 *    to bare ground. That is the truthful behaviour: no source record in this
 *    repository states that a walk stood here on 1 July 1835.
 *  * It answers a pick. A walk, a crossing and a post all belong to the building
 *    they were derived from, so aiming at any of them opens that building's card
 *    — which is what a sign is FOR.
 *  * A post carries a board only where the building's own reference views show
 *    one. The Sauganash's posts are hitching posts: chest-high timber under a
 *    capped head, no arm, no board and nothing lettered, because none of its
 *    three views shows a name board at this hotel (its record's
 *    `board_on_a_post` block states that reading rather than leaving it silent).
 */

import * as THREE from 'three';
import { resolveBases } from './scene-loader.js';
import { gateBoxes } from './gates.js';
import { packGrain } from './relief-pack.js';
import { ktx2State, loadSheet } from './ktx2.js';
import { layerPick } from './gpu-pick.js';
import { compactStreams, COLOR_LANE_CONFIDENCE } from './compact-streams.js';

const {
  compactNormals, setColorsAndConfidence, quantizeMeshPositions, createBoxTable, packPositionBoxes,
  adoptPositionBoxes, boxedPositionAt, patchBoxTable, boxDepthMaterial, raycastBoxed,
} = compactStreams(THREE);

/** attested · inferred · reconstructed, as the confidence view reads them. */
const LEVEL = { attested: 0, documented: 0, inferred: 0.5, reconstructed: 1 };

/**
 * The two tones this layer needs, and why they are converted rather than picked.
 * `THREE.Color.setHex` reads sRGB with `ColorManagement.enabled` on, so these are
 * the sRGB hexes that land on the weathered-board linear triples the signage
 * layer and the yard already use — copying a glTF `baseColorFactor` straight
 * across would draw this walk two stops darker than the boards beside it.
 */
const TIMBER = 0xcbc2b1;        // sawn board, weathered — the signboard's own tone
const PAINT = '#2f2013';        // the letterform's paint: L135 claims the colour

/**
 * THE WALK'S OWN TIMBER (T-1800). Until this ticket every walk and crossing was
 * drawn in `TIMBER` above — the signboard's tone, L* 78.7, brighter than the
 * library's whitewashed clapboard — and that constant, not the light, is the
 * "white boards" the owner reported twice (T-1795 § 2; T-1770's and T-1211's
 * plank-colour correction, 2026-09-30). The fences and posts keep `TIMBER`: they
 * share it with the yard and the signboards, and are not this ticket's.
 *
 * Four LINEAR tones — the vertex stream is linear, so no sRGB decode applies —
 * one per weathering the owner named: dark grey-brown, brown, grey-brown and
 * silvered grey. The bound is T-1795 § 6's: from the library's
 * `plank_walk_weathered` (L* 33–40 across its spread, mean 36.6) up to the sheet's
 * `weathered_board` (L* 62). The tones sit at L* ≈ 38, 45, 51 and 52, and the
 * stretch scale and the board jitter below keep every board inside 33–62. They
 * lean warm on purpose: measured in the browser at 1280×800, the sky and grass
 * light cast the first, cooler set (2026-10-01) to a green-grey, and the owner
 * asked for brown as well as grey.
 * RECONSTRUCTED (L320): no source gives the tone of any one walk in 1835.
 */
const WALK_TONES = [
  [0.120, 0.095, 0.070],        // dark grey-brown — old, damp, trodden
  [0.200, 0.140, 0.085],        // brown — the newer boards, not yet silvered
  [0.225, 0.185, 0.135],        // grey-brown — a season or two of weather
  [0.215, 0.205, 0.185],        // silvered grey — sun-bleached softwood
];
/** How far one stretch of walk is lighter or darker than its tone, at most. */
const WALK_OWNER_SPAN = 0.12;
/** How far one board differs from the next, at most, in luminance and in hue. */
const WALK_BOARD_SPAN = 0.14;
const WALK_BOARD_HUE = 0.03;
/** The L* bound above, as linear luminance: L* 33 and L* 62. */
const WALK_Y_MIN = 0.0754;
const WALK_Y_MAX = 0.3040;

/** FNV-1a over a string: the same owner draws the same walk on every load. */
function hash32(s) {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i += 1) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h >>> 0;
}

/** A float in [-1, 1) from a 32-bit integer, for the bounded jitters. */
const signed = (h) => ((h >>> 0) / 0x80000000) - 1;

/** Linear luminance, the Y the L* bound is stated in. */
const lum = (c) => 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];

/** Scale a tone so its luminance lands inside the walk's bound. */
function clampTone(c) {
  const y = lum(c);
  const k = y < WALK_Y_MIN ? WALK_Y_MIN / y : (y > WALK_Y_MAX ? WALK_Y_MAX / y : 1);
  return [c[0] * k, c[1] * k, c[2] * k];
}

/**
 * The tone of one stretch of walk: one weathering along a whole stretch, and a
 * neighbouring stretch may differ, which is how a street of separately laid
 * walks reads. Keyed on the block face first (`chunk` — the town street edge
 * lays one per face, and its 87 walks all name one record as `belongs_to`), then
 * on the owner (the Sauganash's walks and crossing, the river walk), then on the
 * walk's own id. When T-1211 names the business each walk serves, that owner is
 * the better key and this order is where it goes.
 */
function walkTone(walk) {
  const h = hash32(String(walk.chunk ?? walk.belongs_to ?? walk.id ?? ''));
  const base = WALK_TONES[h % WALK_TONES.length];
  const k = 1 + WALK_OWNER_SPAN * signed(Math.imul(h, 0x9e3779b1));
  return clampTone([base[0] * k, base[1] * k, base[2] * k]);
}

/**
 * One board's colour: its owner's tone, nudged by a hash of where the board
 * lies, so neighbouring boards differ by a little and never by a lot. Keyed on
 * position (to the centimetre) rather than on order, so a walk cut into pieces
 * differently by a later generator keeps its boards' colours.
 */
function boardTone(tone, cx, cz) {
  const h = hash32(`${Math.round(cx * 100)},${Math.round(cz * 100)}`);
  const k = 1 + WALK_BOARD_SPAN * signed(h);
  const warm = WALK_BOARD_HUE * signed(Math.imul(h, 0x85ebca6b));
  return clampTone([tone[0] * k * (1 + warm), tone[1] * k, tone[2] * k * (1 - warm)]);
}

/** `TIMBER` as the linear triple the vertex stream carries for fences and posts. */
const TIMBER_LINEAR = new THREE.Color(TIMBER).toArray();

/**
 * A GROWING TYPED ARRAY with the two things the builders ask of a plain array,
 * `push` (of one to three values) and `length` (T-2152). The buffers were JS
 * number arrays, and growing a town's worth of them by doubling copied about a
 * gigabyte through the heap while the walks were laid — garbage that held a
 * phone's heap near 500 MB mid-load. `plainTimber` hands a harness the plain
 * arrays back.
 *
 * T-2158: the store is 32-bit, the width of the attribute it becomes, so the
 * geometry is built straight from it (`float32()`) rather than copied out of a
 * 64-bit store twice its size — a town's walks held about 290 MB of 64-bit
 * scratch at once while they were laid. Each value is rounded to float32 when
 * it is pushed instead of when it is uploaded, which is the same rounding.
 */
class Grow {
  constructor(Type) { this.Type = Type; this.a = new Type(1024); this.length = 0; }

  push(x, y, z) {
    const n = arguments.length;
    if (this.length + n > this.a.length) {
      let cap = this.a.length * 2;
      while (cap < this.length + n) cap *= 2;
      const b = new this.Type(cap);
      b.set(this.a.subarray(0, this.length));
      this.a = b;
    }
    const a = this.a;
    const i = this.length;
    a[i] = x;
    if (n > 1) a[i + 1] = y;
    if (n > 2) a[i + 2] = z;
    this.length = i + n;
    return this.length;
  }

  /** The values pushed, as a view onto the store (no copy). */
  view() { return this.a.subarray(0, this.length); }

  /** The values pushed as an exactly sized Float32Array, handed over: the
   *  store itself when it is already that, so nothing is copied twice. */
  float32() {
    const a = this.a;
    const out = a instanceof Float32Array
      ? (a.length === this.length ? a : a.slice(0, this.length))
      : Float32Array.from(this.view());
    this.a = out;
    return out;
  }
}

/** An empty timber buffer: positions, normals, confidence and colour. A check
 *  that asserts the builders' arithmetic below float32 asks for Float64Array. */
const timberBuf = (Type = Float32Array) => ({ pos: new Grow(Type), nrm: new Grow(Type),
  conf: new Grow(Type), col: new Grow(Type), uv: new Grow(Type),
  seam: new Grow(Type), walkTopRanges: [], tone: TIMBER_LINEAR, vary: false });

/** The streams of a built buffer as plain arrays, for a check that indexes them. */
function plainTimber(buf) {
  for (const k of ['pos', 'nrm', 'conf', 'col', 'uv', 'seam']) {
    if (buf[k]?.view) buf[k] = Array.from(buf[k].view());
  }
  return buf;
}

/**
 * DROP A BUFFER'S SCRATCH ONCE ITS GEOMETRY HOLDS A COPY (T-2063). The arrays
 * above are plain JS number arrays — 8 bytes a component plus growth slack,
 * twice what the Float32Array three copies them into costs — and they did not
 * die with the build: `pickAt` and `dispose` close over this function's scope,
 * and the inline builder arrows put `buf` and `named` in that same scope, so
 * every board ever laid stayed reachable for the life of the page. Measured at
 * 390x780 on 1835: about 190 MB of live JS heap, which is what pushed an
 * iPhone's tab past the memory it is allowed and got it killed. Only
 * `walkTopRanges` is read after this, so only it survives.
 */
function releaseTimberBuf(buf) {
  buf.pos = buf.nrm = buf.conf = buf.col = buf.uv = buf.seam = null;
}

/**
 * Lay `build` into `buf` in `walk`'s tone, board by board, and hand the buffer
 * back in the fences' and posts' `TIMBER` afterwards.
 */
function inWalkTone(buf, walk, build) {
  const from = buf.pos.length / 3;
  buf.tone = walkTone(walk);
  buf.vary = true;
  try {
    return build();
  } finally {
    if ((walk.kind === 'plank_walk' || walk.kind === 'board_crossing' || walk.kind === 'decked_walk')
        && buf.pos.length / 3 > from) {
      buf.walkTopRanges.push({ from, to: buf.pos.length / 3 });
    }
    buf.tone = TIMBER_LINEAR;
    buf.vary = false;
  }
}

/**
 * THE BUSINESS'S OWN TIMBER (T-1815). A stoop, a mounting block, a tie rail, a
 * wagon apron and a hitching post were laid in `TIMBER` — the signboard's L* 79
 * board — so the owner's "white planks" survived T-1800 at every business door
 * after it left the walks: from Lake Street at 1280x800, Dole's wagon apron and
 * the Mansion House stoop were the two palest things in the frame. They now
 * take the walk's weathered palette, keyed on the business they SERVE, which is
 * the per-business key T-1800 left to T-1211: one house's stoop and its tie
 * rail are one man's timber, and the next door's may differ.
 * RECONSTRUCTED (L320, extended): no source gives the tone of any one stoop.
 */
function inOwnerTone(buf, owner, build) {
  return inWalkTone(buf, { belongs_to: owner }, build);
}

/**
 * THE GRAIN (T-1815) — what a board's surface is made of, at the scale of the
 * board, bound as relief rather than painted as colour.
 *
 * Glessner v4's rule, carried over whole: SHAPE IS GEOMETRY, SURFACE IS MAP. The
 * boards, their seams, the string pieces and the treads are boxes; the map
 * carries only what lies inside one board — grain, raised grain, drying checks,
 * the broad weathering across it. So the substrate is the library's
 * `clapboard_board_face`, the board face T-1801 regenerated with NO course line
 * (a map with seams in it doubles the modelled ones — the fabric proof's
 * `courses-close` showed it, and `plank_walk_weathered` carries eleven).
 *
 * WHY THE UV IS LAID HERE AND NOT DERIVED IN THE SHADER. `roof-relief.js`
 * derives its UV from the face's own frame, and the fabric proof's defect 4 is
 * where that stops: a horizontal face has no frame, and a grain axis is
 * something a position and a normal cannot know. Here every timber is a box the
 * layer itself lays, so it KNOWS: a board's grain runs along its longest side —
 * across the walk for a deck board, along it for a string piece, up a post. So
 * `pushBox` writes a metric UV per face, `u` along the grain, and the faces
 * across the grain (the board's ENDS) take the end-grain reading below. Each
 * board starts the tile at its own seeded offset, so two neighbours never show
 * the same figure and no 4.48 m period lines up down a street.
 *
 * Four stock texture slots — the relief needs no shader patch and composes
 * with the confidence overlay and subpixel plank-gap filter:
 *   normalMap      `normal_gl`, the grain's relief
 *   roughnessMap   the packed `orm`'s G, scaled so its mean is the layer's 0.9
 *   aoMap          the same `orm`'s R, the checks' and the grain's occlusion
 *   map            the basecolor's LUMINANCE RATIO to its own mean, derived at
 *                  load (Strategy A's albedo modulation, 1835_fabric_proof § 3):
 *                  the vertex keeps the owner's tone as the mean, and the wood's
 *                  figure is the variation around it.
 *
 * GPU-COMPRESSED WHERE THE GPU TAKES IT (T-2589). `tools/ktx2_sheets.py` writes all
 * three as KTX2 beside the WebPs — the grain derived there from the lossless
 * basecolor with this file's GRAIN_STRENGTH and GRAIN_HEADROOM, byte for byte what
 * `packGrain` makes — so a phone neither decodes the basecolor nor walks its million
 * texels on the main thread, and holds the three at about a byte a texel instead of
 * four. The files are written bottom row first, so the unflipped compressed upload
 * puts every texel where the flipY'd image put it. All three or none: a mixed set
 * would pair maps of two orientations, so any failure takes the image path whole.
 */
const RELIEF_DIR = 'textures/chicago_1835_pbr/walls/clapboard_board_face';
/** How much of the wood's own figure reaches the colour: bare timber, so most of it. */
const GRAIN_STRENGTH = 0.65;
/**
 * A colour map multiplies, and an 8-bit texel cannot exceed 1 — so the ratio is
 * stored divided by this and the material's colour carries it back. 1.6 holds
 * the board face's brightest figure at strength 0.65 with room over.
 */
const GRAIN_HEADROOM = 1.6;
/**
 * END GRAIN reads darker than face grain: the cut tubes drink the weather and
 * hold the dirt. 0.72 puts a board's end about half a stop under its face.
 * RECONSTRUCTED (L320).
 */
const END_GRAIN_K = 0.72;
/**
 * CONTACT: where a timber meets the mud it carries the mud — splash, damp and
 * the shade of the earth it stands in. The lower edge of every upright face is
 * darkened by up to this much, less on a tall timber (a post's foot is not its
 * whole length). It seats a stoop, a board and a string piece on the ground at
 * the distance where the shadow map's texels are too coarse to.
 * RECONSTRUCTED (L320).
 */
const CONTACT_K = 0.4;
/** The face nobody sees, kept dark so a gap between boards reads as depth. */
const UNDERSIDE_K = 0.5;

/** Corner signs of `pushBox`'s eight corners, along (length, width, height). */
const CORNER = [[-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1],
  [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]];
/** The box axis each of `pushBox`'s six faces looks along. */
const FACE_AXIS = [0, 0, 1, 1, 2, 2];
/**
 * `pushBox`'s faces as fixed tables (T-2152): the two triangles of each face as
 * six corner indices, and its outward normal as weights on (u, v, up). They
 * were array literals rebuilt on every call, and with the per-call corner
 * arrays that was about a gigabyte of short-lived garbage across the town's
 * walks, fences and posts — enough to hold the heap near 500 MB mid-load on a
 * phone before the collector caught up. Same faces, same order, same values.
 */
const BOX_FACE_TRIS = [[1, 5, 6, 1, 6, 2], [4, 0, 3, 4, 3, 7], [3, 2, 6, 3, 6, 7],
  [0, 4, 5, 0, 5, 1], [4, 7, 6, 4, 6, 5], [0, 1, 2, 0, 2, 3]];
const BOX_FACE_NORMAL = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
const BOX_P = new Float64Array(24);
const BOX_HALF = [0, 0, 0];
/** The eight corners of a box into `out` as x,y,z triples, in `CORNER` order. */
function boxCorners(out, cx, cy, cz, ux, uz, vx, vz, halfLen, halfW, halfH) {
  for (let i = 0; i < 8; i += 1) {
    const [a, b, c] = CORNER[i];
    out[i * 3] = cx + ux * a * halfLen + vx * b * halfW;
    out[i * 3 + 1] = cy + c * halfH;
    out[i * 3 + 2] = cz + uz * a * halfLen + vz * b * halfW;
  }
  return out;
}

/**
 * The three KTX2 sheets, or null where any of them cannot serve (no block format,
 * `?ktx2=0`, a file that would not load) — the caller then takes the image path.
 */
async function timberKtx2(here, id) {
  if (!ktx2State.enabled) return null;
  const imageless = { loadAsync: () => Promise.reject(new Error('the image path is the caller\'s')) };
  const got = await Promise.allSettled(['normal_gl', 'orm', 'grain'].map((m) =>
    loadSheet(new URL(`${id}_${m}.ktx2`, here).href, null, imageless)));
  if (got.every((r) => r.status === 'fulfilled' && r.value.userData.ktx2)) return got.map((r) => r.value);
  for (const r of got) if (r.status === 'fulfilled') r.value.dispose();
  return null;
}

/**
 * Load the board face's relief and derive its albedo modulation. Resolves to
 * `{ id, apply(material) }`, or to `{ problem }` if anything did not arrive.
 *
 * IT DEGRADES RATHER THAN THROWS, as `roof-relief.js` does: a missing map is a
 * street edge in its weathered tones without grain, which is the state this
 * ticket improves on, not a boot failure.
 */
async function readTimberRelief(assetBase) {
  try {
    const here = new URL(`${RELIEF_DIR}/`, assetBase);
    const res = await fetch(new URL('material.json', here), { cache: 'no-cache' });
    if (!res.ok) throw new Error(`${res.status} — ${new URL('material.json', here)}`);
    const sheet = await res.json();
    const tileM = Number(sheet.span_m);
    const meanRough = Number(sheet.mean_roughness);
    if (!(tileM > 0) || !(meanRough > 0)) {
      throw new Error(`${sheet.id}: material.json states no span_m or mean_roughness`);
    }
    const tiled = (tex) => {
      tex.wrapS = THREE.RepeatWrapping;
      tex.wrapT = THREE.RepeatWrapping;
      tex.colorSpace = THREE.NoColorSpace;    // data, never decoded as colour
      tex.anisotropy = 8;                     // a walk is a grazing surface
      tex.repeat.set(1 / tileM, 1 / tileM);   // the UV is in metres
      tex.needsUpdate = true;
      return tex;
    };
    let normalMap;
    let ormMap;
    let modMap;
    const ktx = await timberKtx2(here, sheet.id);
    if (ktx) {
      [normalMap, ormMap, modMap] = ktx.map(tiled);
    } else {
      const image = (name) => new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = () => reject(new Error(`map did not load — ${name}`));
        img.src = new URL(name, here).href;
      });
      const [nrm, orm, base] = await Promise.all([
        image(`${sheet.id}_normal_gl.webp`), image(`${sheet.id}_orm.webp`),
        image(`${sheet.id}_basecolor.webp`)]);

      // The albedo modulation: each texel's linear luminance over the map's mean,
      // pulled toward 1 by the grain strength, stored under the headroom — packed
      // bottom row first, so it lies the way the flipY'd normal and orm beside it
      // do (relief-pack.js, T-2300).
      const w = base.naturalWidth;
      const hgt = base.naturalHeight;
      const cv = document.createElement('canvas');
      cv.width = w;
      cv.height = hgt;
      const ctx = cv.getContext('2d', { willReadFrequently: true });
      ctx.drawImage(base, 0, 0);
      const mod = packGrain(ctx.getImageData(0, 0, w, hgt).data, w, hgt, GRAIN_STRENGTH, GRAIN_HEADROOM);
      normalMap = tiled(new THREE.Texture(nrm));
      ormMap = tiled(new THREE.Texture(orm));
      modMap = new THREE.DataTexture(mod, w, hgt, THREE.RGBAFormat);
      modMap.generateMipmaps = true;
      modMap.minFilter = THREE.LinearMipmapLinearFilter;
      modMap.magFilter = THREE.LinearFilter;
      tiled(modMap);
    }
    // Named, because the smoke tells this map from a painted one by its name:
    // the timber may carry its grain and never a board's lettering (L135).
    modMap.name = `frontage-grain:${sheet.id}`;
    return {
      id: sheet.id,
      problem: null,
      // The raw maps, for a layer that binds the same grain on a uv of its own
      // (the yard goods, T-2121) instead of through `apply`.
      normalMap, ormMap, modMap, tileM, meanRough, headroom: GRAIN_HEADROOM,
      apply(material) {
        material.normalMap = normalMap;
        // One file in two slots, as the roofs bind it: R is AO, G roughness.
        material.roughnessMap = ormMap;
        material.aoMap = ormMap;
        // three multiplies roughness by the map's G, so the scalar is the
        // layer's 0.9 over the map's own mean and the mean lands back on 0.9.
        material.roughness = 0.9 / meanRough;
        material.map = modMap;
        material.color.setRGB(GRAIN_HEADROOM, GRAIN_HEADROOM, GRAIN_HEADROOM);
        material.needsUpdate = true;
      },
      dispose() {
        normalMap.dispose();
        ormMap.dispose();
        modMap.dispose();
      },
    };
  } catch (err) {
    return { problem: `board-face relief not bound — ${err.message}`, apply: () => null };
  }
}

/**
 * ONE COPY OF THE GRAIN FOR EVERY LAYER THAT WEARS IT (T-2121). The yard goods carry
 * the walks' board face too, and a second load would be a second 1024² modulation
 * texture and a second upload on a phone that was killed for memory once already
 * (T-2063). So the load is shared per asset base and counted: each caller's
 * `dispose` releases its hold, and the last one out frees the maps.
 */
const reliefShared = new Map();
export function loadTimberRelief(assetBase) {
  const key = String(assetBase);
  let entry = reliefShared.get(key);
  if (!entry) {
    entry = { holds: 0, p: readTimberRelief(assetBase) };
    reliefShared.set(key, entry);
  }
  entry.holds += 1;
  return entry.p.then((relief) => {
    if (relief.problem) return relief;
    let held = true;
    return {
      ...relief,
      dispose() {
        if (!held) return;
        held = false;
        entry.holds -= 1;
        if (entry.holds > 0) return;
        reliefShared.delete(key);
        relief.dispose();
      },
    };
  });
}


/** How far a plank's box reaches below the deck: enough to meet the ground. */
const SKIRT_M = 0.02;
/** Daylight between two boards — a plank walk is not a slab. */
const PLANK_GAP_M = 0.02;
/** Physical framebuffer pixels, not CSS pixels. Resolvable gaps stay exact. */
const PLANK_GAP_CLOSE_PX = 0.35;
const PLANK_GAP_OPEN_PX = 1.0;

/** Four bytes per vertex; the signed XZ pair is in half-gap units. Its maximum
 * quantization error is 0.31 micrometres, far below a visible geometric seam. */
function plankGapAttribute(seams) {
  const packed = new Int16Array((seams.length / 3) * 2);
  const scale = 32767 / (PLANK_GAP_M / 2);
  for (let i = 0, j = 0; i < seams.length; i += 3, j += 2) {
    packed[j] = Math.round(seams[i] * scale);
    packed[j + 1] = Math.round(seams[i + 2] * scale);
  }
  return new THREE.BufferAttribute(packed, 2, true);
}

/**
 * T-2037. Filter a walk's unresolved board gaps without adding a deck above it.
 *
 * At a grazing distance the 20 mm gaps become a subpixel comb: moving the eye
 * alternately samples timber and the ground between boards. Each deck-board
 * vertex carries at most half a gap, directed along the run. Only when that
 * gap is smaller than a framebuffer pixel does the existing box expand into
 * it, smoothly meeting its neighbour. Y, the walk's width and its endpoints
 * stay put; the kerbs already reach each segment's full length. Close boards,
 * posts, fences, crossings and lettering keep their original geometry.
 *
 * No new faces, material or render pass; no depth bias. Ground and buildings
 * still occlude the filtered walk. Far merging copies this attribute with the
 * other vertex streams, and writes the merged positions in the parent's frame
 * (a quantized chunk's matrix applied, T-2687). Reach culling remains a
 * separate policy.
 */
function filterPlankGaps(material) {
  const viewport = new THREE.Vector4();
  const uniforms = {
    uChiPlankGapViewport: { value: new THREE.Vector2(1, 1) },
    uChiPlankGapEnabled: { value: 1 },
  };
  // A diagnostic control for paired captures, not a visitor setting.
  material.userData.plankGapFilter = {
    enabled: uniforms.uChiPlankGapEnabled,
    closePx: PLANK_GAP_CLOSE_PX, openPx: PLANK_GAP_OPEN_PX,
    units: 'framebuffer pixels',
  };
  const beforeRender = material.onBeforeRender;
  material.onBeforeRender = function (renderer, ...args) {
    beforeRender?.call(this, renderer, ...args);
    // getCurrentViewport is already multiplied by DPR and also honours an
    // offscreen target's viewport. getSize/getViewport would read CSS pixels.
    renderer.getCurrentViewport(viewport);
    uniforms.uChiPlankGapViewport.value.set(viewport.z, viewport.w);
  };
  const beforeCompile = material.onBeforeCompile;
  material.onBeforeCompile = function (shader, renderer) {
    beforeCompile?.call(this, shader, renderer);
    Object.assign(shader.uniforms, uniforms);
    shader.vertexShader = /* glsl */`
attribute vec2 aChiPlankGap;
uniform vec2 uChiPlankGapViewport;
uniform float uChiPlankGapEnabled;
` + shader.vertexShader.replace('#include <begin_vertex>', /* glsl */`
#include <begin_vertex>
if (uChiPlankGapEnabled > 0.0 && dot(aChiPlankGap, aChiPlankGap) > 0.0) {
  // Metres in the mesh's frame; a quantized mesh (T-2687) carries its scale in
  // the model matrix, and a float one a scale of 1.
  vec3 chiGapDelta = vec3(aChiPlankGap.x, 0.0, aChiPlankGap.y)
    * (${(PLANK_GAP_M / 2).toFixed(6)} / length(modelMatrix[0].xyz));
  vec4 chiGap0 = projectionMatrix * (modelViewMatrix * vec4(transformed, 1.0));
  vec4 chiGap1 = projectionMatrix
    * (modelViewMatrix * vec4(transformed + 2.0 * chiGapDelta, 1.0));
  if (chiGap0.w > 0.0 && chiGap1.w > 0.0) {
    float chiGapPx = length((chiGap1.xy / chiGap1.w - chiGap0.xy / chiGap0.w)
      * uChiPlankGapViewport * 0.5);
    float chiGapClose = 1.0 - smoothstep(${PLANK_GAP_CLOSE_PX.toFixed(2)},
      ${PLANK_GAP_OPEN_PX.toFixed(2)}, chiGapPx);
    transformed += chiGapDelta * chiGapClose;
  }
}
`);
  };
}
/** A crossing is subdivided this often ALONG its run so it follows the ground. */
const CROSSING_STEP_M = 0.9;
/**
 * The ground one rigid crossing board may span before it is cut shorter
 * (T-1955) — the same 0.04 m the generator audits a walk's stringer bay flat to
 * (`EDGE_STRINGER_ROLL_M`), and for the same reason: it is the daylight a
 * visitor may see under the low end of a board seated on the high one.
 */
const CROSSING_ROLL_M = 0.04;
/** The shortest piece a crossing is cut into on a shoulder (T-1955). */
const CROSSING_MIN_STEP_M = 0.3;
/** How far a fence board's stock reaches across the line it stands on. */
const FENCE_BOARD_T_M = 0.022;
/** A fence rail's section — the same sawn stuff `enclosures.js` hangs. */
const FENCE_RAIL_W_M = 0.09;
const FENCE_RAIL_H_M = 0.13;
/** A drop this steep between two fence posts is a bank, not a street line. */
const FENCE_MAX_STEP_M = 1.0;
/** The longest piece of walk deck handed to the planting block-list at once. */
const KEEPOUT_PIECE_M = 12;
/**
 * THE STRING PIECE (T-0460), and the stock it is cut from.
 *
 * A plank walk laid as boards alone ends, at each side, in a row of board ENDS:
 * at a 0.32 m pitch with a 0.02 m gap between them and a deck standing 0.11 m
 * over the road, the outer edge of the walk was ten thousand short end-grain
 * faces with daylight between them, each casting its own shadow onto the dirt.
 * That is the jagged sawtooth the owner reported, and it is why the walk read as
 * a row of loose boards rather than as a made footway.
 *
 * A plank sidewalk is not laid that way. Its boards are held between two string
 * pieces — the edge timbers that run ALONG the walk, take the board ends and
 * make the face a passer-by actually sees. So this layer lays them: one down
 * each side, its top flush with the boards it holds, its foot reaching the
 * lowest ground under its own length. The boards stop at its inner face, so the
 * walk's overall width does not move.
 *
 * The stock is 0.09 m, which is the section the bay stringers were already cut
 * from — this timber IS those stringers, moved out to the walk's own edge and
 * brought up flush with the deck instead of stopping under it, so the layer
 * gains a made edge without gaining a box.
 */
const KERB_STOCK_M = 0.09;

/**
 * One box, 12 triangles, flat-shaded from its own face normals. `u` is the
 * horizontal unit vector along the box's length; up is world Y always.
 * Deliberately the same helper shape as `signage.js` and `enclosures.js` — three
 * layers drawing small timber the same way is one thing to reason about.
 */
function pushBox(buf, cx, cy, cz, ux, uz, halfLen, halfW, halfH, level,
                 skipUnderside = false, seamHalfM = 0) {
  const vx = -uz;
  const vz = ux;
  const p = boxCorners(BOX_P, cx, cy, cz, ux, uz, vx, vz, halfLen, halfW, halfH);
  // `skipUnderside` drops the last pair, which is the buried face of a fence
  // board standing in the ground — the same two triangles `enclosures.js`
  // drops off a pale, for the same reason: at a town's worth of boards it is
  // thousands of triangles nobody can ever see.
  // A walk's boards vary one from the next (T-1800); everything else is laid in
  // the buffer's one tone.
  const c = buf.vary ? boardTone(buf.tone, cx, cz) : (buf.tone ?? TIMBER_LINEAR);
  // THE GRAIN (T-1815): the longest side is the grain; see `RELIEF_DIR`.
  const half = BOX_HALF;
  half[0] = halfLen; half[1] = halfW; half[2] = halfH;
  const g = halfLen >= halfW ? (halfLen >= halfH ? 0 : 2) : (halfW >= halfH ? 1 : 2);
  // The board's own place on the tile, seeded on where it lies (to the cm), so
  // a walk cut into pieces differently by a later generator keeps its figure.
  const h = (Math.imul(Math.round(cx * 100), 73856093)
    ^ Math.imul(Math.round(cy * 100), 19349663)
    ^ Math.imul(Math.round(cz * 100), 83492791)) >>> 0;
  const ou = ((h & 0xffff) / 0x10000) * 4.48;
  const ov = ((h >>> 16) / 0x10000) * 4.48;
  // Full contact on anything up to 0.3 m tall, fading to a third on a post.
  const contact = 1 - CONTACT_K * Math.min(1, Math.max(0.35, 0.15 / halfH));
  const faceCount = skipUnderside ? 5 : 6;
  for (let f = 0; f < faceCount; f += 1) {
    const tris = BOX_FACE_TRIS[f];
    const s = BOX_FACE_NORMAL[f];
    const n0 = s[0] * ux + s[1] * vx;
    const n1 = s[2];
    const n2 = s[0] * uz + s[1] * vz;
    const ax = FACE_AXIS[f];
    const endGrain = ax === g;
    const ua = endGrain ? (ax === 0 ? 1 : 0) : g;
    const va = 3 - ax - ua;
    const kFace = (endGrain ? END_GRAIN_K : 1) * (f === 5 ? UNDERSIDE_K : 1);
    for (let q = 0; q < 6; q += 1) {
      const i = tris[q];
      buf.pos.push(p[i * 3], p[i * 3 + 1], p[i * 3 + 2]);
      buf.nrm.push(n0, n1, n2);
      buf.conf.push(level);
      buf.seam.push(vx * CORNER[i][1] * seamHalfM, 0,
        vz * CORNER[i][1] * seamHalfM);
      buf.uv?.push(CORNER[i][ua] * half[ua] + ou, CORNER[i][va] * half[va] + ov);
      const k = kFace * (ax < 2 && CORNER[i][2] < 0 ? contact : 1);
      buf.col?.push(c[0] * k, c[1] * k, c[2] * k);
    }
  }
}

/** The ground under a point, or null where the heightfield has nothing to say. */
function groundAt(terrain, e, n) {
  const y = terrain.surfaceHeight(e, n);
  return Number.isFinite(y) ? y : null;
}

/**
 * One straight run of boards laid ACROSS the way a foot travels, pushed into
 * `buf`, held between two string pieces that run ALONG it and take the board
 * ends (T-0460 — see `KERB_STOCK_M`). Each string piece's top is flush with the
 * boards it holds and its foot reaches the lowest ground under its own length,
 * so the walk presents ONE made face to the road at every point of its length
 * rather than a comb of board ends standing over it.
 *
 * WHERE A BOARD'S TOP COMES FROM, and it moved with this ticket. A board used to
 * sample the terrain under its own centre, which put a fresh height on the deck
 * every 0.32 m; a walk laid in stringer bays does not do that, because the bay
 * is what carries the boards and the bay is one piece of timber. So on a record
 * that states a bay, every board in a bay takes THAT BAY's height — the ground
 * under the bay's own centre plus the walk's rise — which is what makes the top
 * of the string piece and the top of the boards it holds the same line to the
 * millimetre. What is left of the old jitter is one butted joint per bay, and
 * the generator has already audited the ground under a bay flat to
 * `EDGE_STRINGER_ROLL_M` (0.04 m). A record with no bay keeps sampling per
 * board, and its string piece is cut to the same pitch and butted end to end.
 *
 * `deckY` (T-0119) is the committed deck a walk may RIDE — the Slough Log
 * Bridge's own `walk_surface_m`, carried onto the record as `deck_m`. Where the
 * deck stands above the ground (over the carved channel), the boards take the
 * deck and the string piece is cut to the board's own thickness with no foot,
 * because boards on a deck lie on the deck and nothing has to reach the mud;
 * where the ground stands higher (the graded approaches), the ground wins,
 * exactly as the walker's own surface rule decides it.
 *
 * `stats` accumulates the two numbers the edge rule is reported on (T-0460):
 * how many string pieces were laid, and the largest step between two
 * consecutive ones — which is the whole of what is left of the sawtooth. That a
 * board is flush with the piece holding it is not reported, because on this
 * code path it is true by construction; the gate proves the edge GEOMETRICALLY
 * instead, by walking the outer edge line of a named walk in the loaded page
 * and asking for timber from the deck down to the ground at every station.
 */
function laySegment(buf, walk, ax, ay, bx, by, terrain, level, stats = null) {
  const az = -ay;
  const bz = -by;                 // local ENU (E, N) to the renderer's (E, up, -N)
  const dx = bx - ax;
  const dz = bz - az;
  const len = Math.hypot(dx, dz);
  if (len < 0.5) return 0;
  const rx = dx / len;
  const rz = dz / len;            // along the run
  const wx = -rz;
  const wz = rx;                  // across it
  const halfW = (walk.width_m ?? 1.83) / 2;
  const rise = walk.rise_m ?? 0.11;
  const thick = walk.plank_thickness_m ?? 0.055;
  const pitch = walk.plank_pitch_m ?? 0.26;
  const deckY = Number.isFinite(walk.deck_m) ? walk.deck_m : null;
  // The string piece takes the outermost 0.09 m of the walk's own width on each
  // side and the boards stop at its inner face, so the walk stays 1.83 m wide
  // and no two faces are coincident.
  const stock = Math.min(KERB_STOCK_M, halfW / 3);
  const boardHalf = halfW - stock;
  const kerbAt = halfW - stock / 2;
  // THE STRINGER BAY (T-0069). Without `stringer_pitch_m` the string pieces are
  // cut to the board pitch and butted, which is what this layer has done since
  // T-0082 and is exactly right for a walk a few metres long on ground that
  // tilts. A record that states a bay cuts them at that pitch instead — one
  // piece of timber carrying several boards — and the generator sets it only
  // where it has audited the ground flat enough across a bay for the piece to
  // still reach it.
  const bay = Number.isFinite(walk.stringer_pitch_m) && walk.stringer_pitch_m > pitch
    ? walk.stringer_pitch_m : null;
  // A record may say its boards carry no underside (T-0069). Two triangles a
  // board, facing the earth they are laid on, on a town's worth of them.
  const bare = walk.plank_underside === false;
  const n = Math.max(1, Math.round(len / pitch));
  const step = len / n;

  /** The lowest ground under one length of string piece: its ends and middle. */
  const footUnder = (cx, cz, ox, oz, halfLen) => {
    let low = null;
    for (const d of [-halfLen, 0, halfLen]) {
      const gs = groundAt(terrain, cx + ox + rx * d, -(cz + oz + rz * d));
      if (gs !== null && (low === null || gs < low)) low = gs;
    }
    return low;
  };

  /**
   * One length of string piece down each side: top flush with `top`, foot at the
   * lowest ground under its own line (or cut to the board thickness where the
   * boards ride a committed deck and there is no mud to reach).
   */
  const layKerb = (cx, cz, halfLen, top, onDeck) => {
    for (const s of [-1, 1]) {
      const ox = wx * s * kerbAt;
      const oz = wz * s * kerbAt;
      const low = onDeck ? null : footUnder(cx, cz, ox, oz, halfLen);
      const depth = low === null ? thick : Math.max(thick, top - low + SKIRT_M);
      pushBox(buf, cx + ox, top - depth / 2, cz + oz, rx, rz,
        halfLen, stock / 2, depth / 2, level, true);
      if (stats) stats.kerb += 1;
    }
  };

  // THE BAY LINE. On a record that states a bay, the height of every board in a
  // bay is the bay's own, so the boards and the string piece holding them are
  // one line. A bay whose centre finds no ground leaves its boards to fall back
  // on their own sample, the same way they always did.
  const bays = bay === null ? 0 : Math.max(1, Math.round(len / bay));
  const bstep = bays ? len / bays : 0;
  const bayTop = [];
  for (let i = 0; i < bays; i += 1) {
    const t = (i + 0.5) * bstep;
    const g = groundAt(terrain, ax + rx * t, -(az + rz * t));
    bayTop.push(g === null ? null : g + rise);
  }
  if (stats) {
    for (let i = 1; i < bayTop.length; i += 1) {
      if (bayTop[i] === null || bayTop[i - 1] === null) continue;
      stats.kerbStep = Math.max(stats.kerbStep, Math.abs(bayTop[i] - bayTop[i - 1]));
    }
  }

  let drawn = 0;
  for (let i = 0; i < n; i += 1) {
    const t = (i + 0.5) * step;
    const cx = ax + rx * t;
    const cz = az + rz * t;
    const g = groundAt(terrain, cx, -cz);
    if (g === null && deckY === null) continue;
    const onDeck = deckY !== null && (g === null || deckY > g);
    const bi = bays ? Math.min(bays - 1, Math.max(0, Math.floor(t / bstep))) : -1;
    const held = !onDeck && bi >= 0 && bayTop[bi] !== null ? bayTop[bi] : null;
    const top = held !== null ? held : (onDeck ? deckY : g) + rise;
    // The board itself, its long axis ACROSS the run, stopping at the inner
    // face of the string piece that holds its ends.
    pushBox(buf, cx, top - thick / 2, cz, wx, wz,
      boardHalf, Math.max(0.02, (step - PLANK_GAP_M) / 2), thick / 2, level, bare,
      Math.min(PLANK_GAP_M / 2, Math.max(0, step / 2 - 0.02)));
    // A board whose bay carries it is held by that bay's string piece, laid
    // once below; every other board carries its own, cut to the board pitch and
    // butted against its neighbours so the face stays unbroken.
    if (held === null) layKerb(cx, cz, step / 2, top, onDeck);
    drawn += 1;
  }
  // The bay-laid string pieces, marched on their own pitch. Each one is a box,
  // so its underside is FLAT: it takes the LOWEST ground under its own line —
  // its two ends and its middle — so the timber reaches the land everywhere
  // along the bay rather than leaving the downhill half of it open to daylight.
  if (bays && deckY === null) {
    for (let i = 0; i < bays; i += 1) {
      if (bayTop[i] === null) continue;
      const t = (i + 0.5) * bstep;
      layKerb(ax + rx * t, az + rz * t, bstep / 2, bayTop[i], false);
    }
  }
  return drawn;
}

/**
 * A plank walk: one straight run for a two-point centreline, or a connected
 * chain of them for a polyline (T-0119 — the river walk is the first record to
 * carry one; a 400 m run pinned as a list of two-point records would be nine
 * ids for one claim).
 */
function buildWalk(buf, walk, terrain, level, problems, stats = null) {
  const line = walk.centreline_local_enu_m;
  if (!Array.isArray(line) || line.length < 2) {
    problems.push(`frontage: ${walk.id} carries no centreline — nothing is laid`);
    return false;
  }
  let drawn = 0;
  for (let i = 0; i + 1 < line.length; i += 1) {
    drawn += laySegment(buf, walk, line[i][0], line[i][1],
      line[i + 1][0], line[i + 1][1], terrain, level, stats);
  }
  if (!drawn) {
    problems.push(`frontage: ${walk.id} found no ground under any board — nothing is laid`);
    return false;
  }
  return true;
}

/**
 * A crossing: boards laid ALONG the way a foot travels, which is what a crossing
 * is FOR — it spans the ruts instead of lying in them. Subdivided along the run
 * so that a board fifteen metres long still follows the camber of the road it
 * crosses.
 *
 * T-1955 — A GRADED STREET HAS SHOULDERS, and a rigid board sat on the ground
 * under its own centre buries its uphill end in one. T-1812 cut the opened
 * streets below their walks, so a crossing now steps down a shoulder falling
 * about 0.08 m in a metre; the 1.8 m stride the generator states for level
 * ground put each board's ends 0.07 m above and below its centre, and the
 * lower face of the uphill end went up to 0.12 m into the ground (measured on
 * the Washington crossing between Wells and La Salle). So each stride is now
 * cut in half, down to `CROSSING_MIN_STEP_M`, while the ground under any one
 * board's footprint — both ends, the middle, both edges — rolls more than
 * `CROSSING_ROLL_M`, and every board is seated on the HIGHEST of its own
 * samples, which is the generator's own rule for the walking deck over it
 * (`phigh + rise`). Per board and not per piece, because where a crossing
 * runs over a street that falls along its own length the ground tilts ACROSS
 * the crossing too — 0.12 m over its 1.83 m at Washington and Clark — and one
 * height for all six boards lifts the downhill one clear of the grade. On level
 * ground no stride rolls, nothing is cut, and the crossing is the pieces it
 * always was.
 */
function buildCrossing(buf, walk, terrain, level, problems) {
  const line = walk.centreline_local_enu_m;
  if (!Array.isArray(line) || line.length < 2) {
    problems.push(`frontage: ${walk.id} carries no centreline — nothing is laid`);
    return false;
  }
  const [a, b] = line;
  const ax = a[0];
  const az = -a[1];
  const dx = b[0] - ax;
  const dz = -b[1] - az;
  const len = Math.hypot(dx, dz);
  if (len < 0.5) {
    problems.push(`frontage: ${walk.id} is ${len.toFixed(2)} m long — nothing is laid`);
    return false;
  }
  const rx = dx / len;
  const rz = dz / len;
  const wx = -rz;
  const wz = rx;
  const width = walk.width_m ?? 1.22;
  const boards = Math.max(1, walk.plank_count ?? 4);
  const bw = width / boards;
  const rise = walk.rise_m ?? 0.06;
  const thick = walk.plank_thickness_m ?? 0.055;
  // How often the crossing is cut along its run so it follows the camber. The
  // default is a board's own length; a record laid on ground its generator has
  // audited flat may state a longer one, which is the same trade the walk's
  // stringer bay makes and for the same reason (T-0069).
  const stride = Number.isFinite(walk.plank_step_m) && walk.plank_step_m > CROSSING_STEP_M
    ? walk.plank_step_m : CROSSING_STEP_M;
  const segs = Math.max(1, Math.round(len / stride));
  const step = len / segs;
  // The ground under each board of a piece [t0, t1] of the run: the highest and
  // lowest of nine samples across that board's own footprint — both ends, the
  // middle, both edges. `null` when the run's centre has no ground there, which
  // is the one case the old loop skipped a piece for.
  const footing = (t0, t1) => {
    const tm = (t0 + t1) / 2;
    if (groundAt(terrain, ax + rx * tm, -(az + rz * tm)) === null) return null;
    const out = [];
    for (let j = 0; j < boards; j += 1) {
      const mid = (j + 0.5) * bw - width / 2;
      let lo = Infinity;
      let hi = -Infinity;
      for (const t of [t0, tm, t1]) {
        for (const off of [mid - bw / 2, mid, mid + bw / 2]) {
          const y = groundAt(terrain, ax + rx * t + wx * off, -(az + rz * t + wz * off));
          if (y === null) continue;
          lo = Math.min(lo, y);
          hi = Math.max(hi, y);
        }
      }
      out.push(Number.isFinite(hi) ? { lo, hi } : null);
    }
    return out;
  };
  const rolls = (f) => f !== null && f.some((b) => b && b.hi - b.lo > CROSSING_ROLL_M);
  const pieces = [];
  const cut = (t0, t1) => {
    const f = footing(t0, t1);
    if (rolls(f) && (t1 - t0) / 2 >= CROSSING_MIN_STEP_M) {
      cut(t0, (t0 + t1) / 2);
      cut((t0 + t1) / 2, t1);
    } else {
      pieces.push([t0, t1, f]);
    }
  };
  for (let i = 0; i < segs; i += 1) cut(i * step, (i + 1) * step);
  let drawn = 0;
  for (const [t0, t1, f] of pieces) {
    if (!f) continue;
    const t = (t0 + t1) / 2;
    const cx = ax + rx * t;
    const cz = az + rz * t;
    for (let j = 0; j < boards; j += 1) {
      if (!f[j]) continue;
      const off = (j + 0.5) * bw - width / 2;
      pushBox(buf, cx + wx * off, f[j].hi + rise - thick / 2, cz + wz * off, rx, rz,
        (t1 - t0) / 2, Math.max(0.02, (bw - PLANK_GAP_M) / 2), thick / 2, level,
        walk.plank_underside === false);
    }
    drawn += 1;
  }
  if (!drawn) {
    problems.push(`frontage: ${walk.id} found no ground under any board — nothing is laid`);
    return false;
  }
  return true;
}

/**
 * A FENCE LINING THE STREET (T-0069): posts on the frontage line, two stringers
 * between them and boards butted across, which is the fence the first Cook County
 * jail engraving puts at the lot line with a plank walk at its foot.
 *
 * Construction, dimensions and refusals are deliberately the same as
 * `enclosures.js` draws a `board` fence with — the same posts, the same courses
 * inside the height, the same butted stock, the same refusal of a post whose
 * foot is in the water and of a bay that drops like a bank. What is NOT the same
 * is which layer owns it, and the header says why: an enclosure is a closed
 * perimeter whose interior gets a ground treatment, and this is an open line at
 * the street's edge that encloses nothing. It shares its walk's chunk, so a
 * block face's whole street edge is one mesh.
 */
function buildFence(buf, fence, terrain, level, problems) {
  const path = fence.path_local_enu_m;
  if (!Array.isArray(path) || path.length < 2) {
    problems.push(`frontage: ${fence.id} carries no line — no fence is set`);
    return false;
  }
  const height = fence.height_m ?? 1.37;
  const courses = Math.max(1, Math.round(fence.rail_courses ?? 2));
  const spacing = Math.max(1, fence.post_spacing_m ?? 2.44);
  const postHalf = (fence.post_square_m ?? 0.12) / 2;
  const boardW = Math.max(0.05, fence.board_width_m ?? 0.254);
  const boardPitch = boardW + Math.max(0, fence.board_gap_m ?? 0.006);
  let posts = 0;
  for (let seg = 0; seg + 1 < path.length; seg += 1) {
    const a = path[seg];
    const b = path[seg + 1];
    const de = b[0] - a[0];
    const dn = b[1] - a[1];
    const len = Math.hypot(de, dn);
    if (len < 0.5) continue;
    const ux = de / len;
    const uz = -dn / len;            // local ENU to the renderer's (E, up, -N)
    // T-2112 — THE GATEWAYS ON THIS LINE. An opening whose stated centre lies on
    // this segment takes its width out of the fence, and what hangs in it is
    // drawn after the timber.
    const gaps = [];
    for (const o of fence.openings ?? []) {
      const c = o.at_local_enu_m;
      if (!Array.isArray(c)) continue;
      const t = ((c[0] - a[0]) * de + (c[1] - a[1]) * dn) / (len * len);
      const off = Math.abs((c[0] - a[0]) * (dn / len) - (c[1] - a[1]) * (de / len));
      if (t < 0 || t > 1 || off > 1.0) continue;
      gaps.push({ d: t * len, width: o.width_m ?? 1.07, o });
    }
    let spans = [[0, len]];
    for (const g of gaps) {
      const lo = g.d - g.width / 2;
      const hi = g.d + g.width / 2;
      const next = [];
      for (const [p0, p1] of spans) {
        if (hi <= p0 || lo >= p1) { next.push([p0, p1]); continue; }
        if (lo > p0) next.push([p0, lo]);
        if (hi < p1) next.push([hi, p1]);
      }
      spans = next;
    }
    const footAt = (d) => {
      const e = a[0] + ux * d;
      const n = a[1] + (dn / len) * d;
      const y = terrain.isWater?.(e, n) ? null : groundAt(terrain, e, n);
      return y === null ? null : { e, n, y };
    };
    for (const g of gaps) {
      const ja = footAt(g.d - g.width / 2);
      const jb = footAt(g.d + g.width / 2);
      if (!ja || !jb) continue;
      for (const bx of gateBoxes(g.o.gate, ja, jb, height, g.o.opens_into_local_enu_m)) {
        pushBox(buf, bx.cx, bx.cy, bx.cz, bx.ux, bx.uz, bx.halfLen, bx.halfW, bx.halfH,
          level, bx.part !== 'rail');
      }
    }
    for (const [lo, hi] of spans) {
      if (hi - lo < 0.3) continue;
      const bays = Math.max(1, Math.round((hi - lo) / spacing));
      const feet = [];
      for (let i = 0; i <= bays; i += 1) feet.push(footAt(lo + (hi - lo) * (i / bays)));
      for (let i = 0; i <= bays; i += 1) {
        const f = feet[i];
        if (!f) continue;
        pushBox(buf, f.e, f.y + height / 2, -f.n, ux, uz,
          postHalf, postHalf, height / 2, level, true);
        posts += 1;
      }
      for (let i = 0; i < bays; i += 1) {
        const p = feet[i];
        const q = feet[i + 1];
        if (!p || !q || Math.abs(p.y - q.y) > FENCE_MAX_STEP_M) continue;
        const bayLen = Math.hypot(q.e - p.e, q.n - p.n);
        if (bayLen < 0.05) continue;
        for (let c = 1; c <= courses; c += 1) {
          const f = courses > 1 ? 0.22 + 0.58 * ((c - 1) / (courses - 1)) : 0.55;
          pushBox(buf,
            (p.e + q.e) / 2, (p.y + q.y) / 2 + height * f - FENCE_RAIL_H_M / 2,
            -(p.n + q.n) / 2, ux, uz,
            bayLen / 2, FENCE_RAIL_W_M / 2, FENCE_RAIL_H_M / 2, level, true);
        }
        const count = Math.max(1, Math.floor(bayLen / boardPitch));
        const first = (bayLen - (count - 1) * boardPitch) / 2;
        for (let k = 0; k < count; k += 1) {
          const t = (first + k * boardPitch) / bayLen;
          pushBox(buf,
            p.e + (q.e - p.e) * t, p.y + (q.y - p.y) * t + height / 2,
            -(p.n + (q.n - p.n) * t), ux, uz,
            boardW / 2, FENCE_BOARD_T_M / 2, height / 2, level, true);
        }
      }
    }
  }
  if (!posts) {
    problems.push(`frontage: ${fence.id} found no dry ground under any post `
      + '— no fence is set');
    return false;
  }
  return true;
}

/**
 * The post, its cross-arm, two hangers and the board hanging under them. Returns
 * the board's own frame so the lettering can be laid on its two faces without
 * re-deriving any of this arithmetic.
 *
 * The frame, against docs/GLB-CONTRACT.md: `facade_bearing_deg` is a compass
 * bearing, so the outward normal is (sin b, cos b) in ENU and the along-wall
 * direction is (cos b, −sin b). The renderer's world is (E, up, −N), which is
 * where every negated north below comes from — the same three lines
 * `signage.js` composes.
 */
function buildPost(buf, post, terrain, level, problems) {
  const at = post.at_local_enu_m;
  if (!Array.isArray(at) || at.length !== 2) {
    problems.push(`frontage: ${post.id} carries no stand — no post is set`);
    return null;
  }
  const g = groundAt(terrain, at[0], at[1]);
  if (g === null) {
    problems.push(`frontage: ${post.id} has no ground under it — no post is set`);
    return null;
  }
  const b = ((post.facade_bearing_deg ?? 0) * Math.PI) / 180;
  const ox = Math.sin(b);
  const oz = -Math.cos(b);       // out of the facade, toward the street
  const wx = Math.cos(b);
  const wz = Math.sin(b);        // along the wall, away from the corner
  const px = at[0];
  const pz = -at[1];
  const h = post.post_height_m ?? 3.6;
  const sq = (post.post_square_m ?? 0.18) / 2;

  // A HITCHING POST IS A POST AND NOTHING ELSE (T-0090). The Sauganash's three
  // views put posts at its road edge and a horse tied to one; none of them puts
  // a board on any of them, so this branch draws chest-high timber under a
  // capped head and returns a frame carrying no text — the lettering pass never
  // sees it, and the record says in as many words why there is nothing to letter.
  if (post.kind === 'hitching_post') {
    const cap = (post.cap_square_m ?? 0.22) / 2;
    const capT = post.cap_thickness_m ?? 0.07;
    pushBox(buf, px, g + (h - capT) / 2, pz, wx, wz, sq, sq, (h - capT) / 2, level);
    pushBox(buf, px, g + h - capT / 2, pz, wx, wz, cap, cap, capT / 2, level);
    return { cx: px, cy: g + h, cz: pz, ox, oz, wx, wz, bw: 0, bh: 0, bt: 0, text: '' };
  }
  const arm = post.arm_m ?? 1.55;
  const armT = 0.09;
  const drop = post.hanger_drop_m ?? 0.18;
  const bw = post.board_w_m ?? 1.3;
  const bh = post.board_h_m ?? 0.55;
  const bt = post.board_thickness_m ?? 0.055;

  // The pole. One box standing on the ground the record's stand samples.
  pushBox(buf, px, g + h / 2, pz, wx, wz, sq, sq, h / 2, level);
  // The cross-arm at its head, running along the wall away from the corner.
  const armY = g + h - armT;
  pushBox(buf, px + wx * (arm / 2), armY, pz + wz * (arm / 2), wx, wz,
    arm / 2, armT / 2, armT / 2, level);
  // A knee brace under it, so the arm reads as carried rather than glued.
  pushBox(buf, px + wx * 0.30, armY - 0.30, pz + wz * 0.30, wx, wz,
    0.30, armT * 0.35, armT * 0.35, level);
  // Two hangers dropping from the arm, and the board under them. The board's
  // long axis runs along the arm and its face looks out of the facade, which is
  // how it is read from the street the inn fronts on.
  const hang = arm * 0.55;
  for (const s of [-1, 1]) {
    pushBox(buf,
      px + wx * (hang + s * bw * 0.36), armY - drop / 2, pz + wz * (hang + s * bw * 0.36),
      ox, oz, 0.022, 0.018, drop / 2, level);
  }
  const cy = armY - drop - bh / 2;
  const cx = px + wx * hang;
  const cz = pz + wz * hang;
  pushBox(buf, cx, cy, cz, wx, wz, bw / 2, bt / 2, bh / 2, level);
  return { cx, cy, cz, ox, oz, wx, wz, bw, bh, bt, text: post.text || '' };
}

/**
 * A FITTING AT A BUSINESS'S FRONT (T-1813) — a stoop, a mounting block, a tie
 * rail or a wagon apron. The generator has already done all the arithmetic: a
 * fitting is a list of `parts`, each a timber box centred at `at_local_enu_m`,
 * `len_m` along the facade and `depth_m` out of it, its top `top_m` over the
 * ground under it. A part with no `thick_m` STANDS on that ground — its foot
 * reaches the lowest ground under its four corners, so nothing floats on a
 * slope — and one with `thick_m` (a tie rail's rail) is carried at its height.
 * The top is taken over the HIGHEST corner, so no corner of a step is buried.
 */
function buildFitting(buf, fit, terrain, level, problems) {
  const parts = Array.isArray(fit.parts) ? fit.parts : [];
  if (!parts.length) {
    problems.push(`frontage: ${fit.id} carries no parts — nothing is laid`);
    return false;
  }
  const b = ((fit.facade_bearing_deg ?? 0) * Math.PI) / 180;
  const ae = Math.cos(b);
  const an = -Math.sin(b);       // along the face, ENU
  const oe = Math.sin(b);
  const on = Math.cos(b);        // out of the face, ENU
  for (const part of parts) {
    const at = part.at_local_enu_m;
    const hl = part.len_m / 2;
    const hd = part.depth_m / 2;
    const gs = [];
    for (const [sa, so] of [[-1, -1], [1, -1], [1, 1], [-1, 1], [0, 0]]) {
      const g = groundAt(terrain, at[0] + ae * sa * hl + oe * so * hd,
        at[1] + an * sa * hl + on * so * hd);
      if (g !== null) gs.push(g);
    }
    if (!gs.length) {
      problems.push(`frontage: ${fit.id} ${part.part} has no ground under it`);
      return false;
    }
    const top = Math.max(...gs) + part.top_m;
    const foot = part.thick_m != null ? top - part.thick_m : Math.min(...gs) - 0.03;
    if (TREADED.has(fit.kind) && part.thick_m == null && top - foot > TREAD_T_M * 2) {
      layTreads(buf, at, ae, an, oe, on, hl, hd, top, foot, level);
      continue;
    }
    pushBox(buf, at[0], (top + foot) / 2, -at[1], ae, -an, hl, hd, (top - foot) / 2,
      level);
  }
  return true;
}

/**
 * THE STOOP'S JOINERY (T-1815). A stoop and a mounting block were each one
 * solid box per step — a block of timber with no top, no edge and no seam,
 * which from the walk read as a pale crate. A board step is built: a carcass of
 * framing, and on it a tread of boards laid along the face, their front edge
 * standing proud of the riser as a NOSING, which is the one line that makes a
 * step read as a step from across a street — it throws its own shadow down the
 * riser under it. So each part is now the carcass, set back under the nosing,
 * plus its tread boards with a seam between each.
 *
 * Nothing here moves a record: the part's footprint, top and foot are the
 * generator's, the tread lies inside the footprint, and the carcass inside that.
 * The board width and the nosing are RECONSTRUCTED (L320) at sawn-plank stock.
 */
const TREADED = new Set(['stoop', 'mounting_block']);
/** A tread board's thickness: two-inch plank. */
const TREAD_T_M = 0.045;
/** The widest a tread board is sawn: eight inches. */
const TREAD_BOARD_M = 0.2;
/** The seam between two tread boards. */
const TREAD_GAP_M = 0.012;
/** How far the tread stands proud of the riser at the front and the two ends. */
const NOSING_M = 0.03;

function layTreads(buf, at, ae, an, oe, on, hl, hd, top, foot, level) {
  // The carcass: back flush with the part's own back, front and ends set in by
  // the nosing, top under the tread.
  const cTop = top - TREAD_T_M;
  const chl = Math.max(0.05, hl - NOSING_M);
  const chd = Math.max(0.05, hd - NOSING_M / 2);
  const ce = at[0] - oe * (NOSING_M / 2);
  const cn = at[1] - on * (NOSING_M / 2);
  pushBox(buf, ce, (cTop + foot) / 2, -cn, ae, -an, chl, chd, (cTop - foot) / 2, level);
  // The tread: boards along the face, across the part's depth, seams between.
  const n = Math.max(1, Math.round((hd * 2) / TREAD_BOARD_M));
  const pitch = (hd * 2) / n;
  for (let i = 0; i < n; i += 1) {
    const so = -hd + (i + 0.5) * pitch;
    pushBox(buf, at[0] + oe * so, top - TREAD_T_M / 2, -(at[1] + on * so), ae, -an,
      hl, Math.max(0.01, (pitch - TREAD_GAP_M) / 2), TREAD_T_M / 2, level);
  }
}

/**
 * The painted name, as a canvas texture on a plane just proud of each board
 * face. Drawn rather than left blank because the wording is evidence this
 * project holds and the letterform is the only invented part — see
 * docs/LIBERTIES.md L135 and the record's own `lettering` block.
 */
function makeLettering(boards) {
  const lettered = boards.filter((b) => b && b.text);
  if (!lettered.length) return null;
  const pos = [];
  const nrm = [];
  const uv = [];
  const conf = [];
  // Only one texture is supported per draw call, so the layer draws the first
  // wording it meets and says so if a second ever appears. One board today.
  const first = lettered[0];
  for (const board of lettered) {
    if (board.text !== first.text) continue;
    const { cx, cy, cz, ox, oz, wx, wz, bw, bh, bt } = board;
    const mx = bw * 0.5 - 0.07;
    const my = bh * 0.5 - 0.07;
    const proud = bt / 2 + 0.006;
    for (const side of [1, -1]) {
      const nx = ox * side;
      const nz = oz * side;
      // WHICH WAY THE NAME RUNS. A reader standing off the face has the board's
      // along-wall axis on their LEFT when they look at the near face and on
      // their right at the far one, so the horizontal axis flips with the face
      // — and it is the NEAR face that takes the minus. Getting this backwards
      // draws a perfectly lit board with the name mirrored on both sides, which
      // is what the first build of this layer did.
      const ux = -wx * side;
      const uz = -wz * side;
      const P = (s, t) => [cx + nx * proud + ux * s * mx, cy + t * my, cz + nz * proud + uz * s * mx];
      const quad = [P(-1, -1), P(1, -1), P(1, 1), P(-1, 1)];
      const uvs = [[0, 0], [1, 0], [1, 1], [0, 1]];
      for (const [i, j, k] of [[0, 1, 2], [0, 2, 3]]) {
        for (const idx of [i, j, k]) {
          pos.push(quad[idx][0], quad[idx][1], quad[idx][2]);
          nrm.push(nx, 0, nz);
          uv.push(uvs[idx][0], uvs[idx][1]);
          conf.push(board.level ?? 1);
        }
      }
    }
  }
  if (!pos.length) return null;

  const W = 1024;
  const H = Math.round(W * (first.bh / first.bw));
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;
  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = PAINT;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  // Fit the wording to the board rather than choosing a size: the board is a
  // derived width and the name is a given, so the type is what gives way.
  let size = Math.round(H * 0.52);
  const face = (px) => `600 ${px}px Georgia, "Times New Roman", Times, serif`;
  ctx.font = face(size);
  const limit = W * 0.86;
  while (size > 8 && ctx.measureText(first.text).width > limit) {
    size -= 4;
    ctx.font = face(size);
  }
  ctx.fillText(first.text, W / 2, H / 2 + size * 0.03);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 4;
  texture.needsUpdate = true;
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(nrm, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  geo.setAttribute('_confidence', new THREE.Float32BufferAttribute(conf, 1));
  geo.computeBoundingSphere();
  return { geo, texture, text: first.text };
}

/* -------------------------------------------------------------------------- */
/* the layer                                                                   */
/* -------------------------------------------------------------------------- */

/** T-2037: the furniture reach may hide board detail, but not the footway.
 * Copy only emitted walk/crossing top faces, preserving every source attribute.
 * A changing index submits eligible, reach-culled chunks in one shared-material
 * draw. The source and its replacement never draw together; farMerge hiding a
 * source is not a reason to replace it. No heights, gaps or support are inferred.
 */
function createFarWalkTops(group, sources, material) {
  const entries = [];
  let vertices = 0;
  for (const { mesh, ranges } of sources) {
    const normal = mesh.geometry.getAttribute('normal');
    const selected = [];
    for (const { from, to } of ranges) {
      for (let i = from; i < to; i += 3) {
        if (normal.getY(i) < 0.99) continue;
        selected.push(i, i + 1, i + 2);
      }
    }
    if (!selected.length) continue;
    if (!mesh.geometry.boundingSphere) mesh.geometry.computeBoundingSphere();
    entries.push({ source: mesh, selected, from: vertices,
      count: selected.length, active: false,
      sphere: mesh.geometry.boundingSphere.clone() });
    vertices += selected.length;
  }
  const geometry = new THREE.BufferGeometry();
  let boxed = false;
  if (entries.length) {
    for (const [name, attribute] of Object.entries(entries[0].source.geometry.attributes)) {
      if (name === 'position') {
        // In the group's frame, as float32 for now: a source chunk may be
        // quantized over its own box (T-2687) or boxed piece by piece (T-2700),
        // each on its own grid; this copy is boxed on its own grid below.
        const packed = new Float32Array(vertices * 3);
        const p = new THREE.Vector3();
        let offset = 0;
        for (const entry of entries) {
          const source = entry.source;
          source.updateMatrix();
          for (const vertex of entry.selected) {
            // A boxed source (T-2700) reads each vertex through its own box.
            boxedPositionAt(source.geometry, vertex, p).applyMatrix4(source.matrix);
            packed[offset++] = p.x; packed[offset++] = p.y; packed[offset++] = p.z;
          }
        }
        geometry.setAttribute(name, new THREE.BufferAttribute(packed, 3));
        continue;
      }
      const size = attribute.itemSize;
      const packed = new attribute.array.constructor(vertices * size);
      let offset = 0;
      for (const entry of entries) {
        const original = entry.source.geometry.getAttribute(name).array;
        for (const vertex of entry.selected) {
          for (let k = 0; k < size; k++) packed[offset++] = original[vertex * size + k];
        }
      }
      geometry.setAttribute(name, new THREE.BufferAttribute(packed, size, attribute.normalized));
    }
    // The tone's fourth lane is the confidence on every source (T-2689), so on
    // the copy too: `confidenceOf` reads it as it reads them.
    if (entries.every((entry) => entry.source.geometry.userData.confidenceLane === 'color')) {
      geometry.userData.confidenceLane = 'color';
    }
    geometry.computeBoundingSphere();
    // The copy spans the town, so it is boxed piece by piece on the material's
    // own table (T-2701): 8 B a position for 12, still one draw. Before the
    // index goes on — a boxing takes the triangles as they lie, and the index
    // below names vertices it never moves.
    const table = material.userData.boxTable;
    if (table && packPositionBoxes(geometry, table)) boxed = true;
  }
  const index = new THREE.BufferAttribute(new Uint32Array(vertices), 1);
  index.setUsage(THREE.DynamicDrawUsage);
  geometry.setIndex(index);
  geometry.setDrawRange(0, 0);
  const mesh = new THREE.Mesh(geometry, material);
  if (boxed) {
    mesh.raycast = raycastBoxed;
    mesh.customDepthMaterial = boxDepthMaterial(material.userData.boxTable);
  }
  mesh.name = 'frontage-far-walk-tops';
  mesh.userData.farWalkTops = true;
  mesh.userData.groundHugging = true;
  mesh.renderOrder = 1;
  mesh.castShadow = false;
  mesh.receiveShadow = true;
  mesh.visible = false;
  group.add(mesh);
  group.updateWorldMatrix(true, true);
  for (const entry of entries) {
    entry.sphere.applyMatrix4(entry.source.matrixWorld);
    // Indices are copied only when the selected chunk set changes.
    entry.indices = Uint32Array.from({ length: entry.count }, (_, i) => entry.from + i);
    delete entry.selected;
  }
  const frustum = new THREE.Frustum();
  const viewProjection = new THREE.Matrix4();
  const state = { candidateChunks: entries.length, candidateTriangles: vertices / 3,
    eligibleChunks: 0, eligibleTriangles: 0, activeChunks: 0, triangles: 0,
    drawCalls: 0, indexUpdates: 0 };
  function update(camera, crossStreetWalks = true) {
    camera.updateMatrixWorld();
    viewProjection.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse);
    frustum.setFromProjectionMatrix(viewProjection);
    let changed = false, activeChunks = 0, triangles = 0;
    let eligibleChunks = 0, eligibleTriangles = 0;
    for (const entry of entries) {
      const source = entry.source;
      const eligible = crossStreetWalks || !source.userData.crossStreet;
      if (eligible) { eligibleChunks++; eligibleTriangles += entry.count / 3; }
      const active = eligible && source.userData.reachCulled === true
        && !source.visible && frustum.intersectsSphere(entry.sphere);
      if (active !== entry.active) changed = true;
      entry.active = active;
      if (active) { activeChunks++; triangles += entry.count / 3; }
    }
    if (changed) {
      let offset = 0;
      for (const entry of entries) {
        if (!entry.active) continue;
        index.array.set(entry.indices, offset);
        offset += entry.count;
      }
      index.clearUpdateRanges();
      if (offset) index.addUpdateRange(0, offset);
      index.needsUpdate = true;
      geometry.setDrawRange(0, offset);
      state.indexUpdates++;
    }
    mesh.visible = activeChunks > 0;
    Object.assign(state, { eligibleChunks, eligibleTriangles, activeChunks,
      triangles, drawCalls: activeChunks > 0 ? 1 : 0 });
    return state;
  }
  return { mesh, state, update, dispose: () => geometry.dispose() };
}


async function getJSON(url) {
  const res = await fetch(url, { cache: 'no-cache' });
  if (!res.ok) throw new Error(`${res.status} ${res.statusText} — ${url}`);
  return res.json();
}

/* -------------------------------------------------------------------------- */
/* THE TOWN'S TIMBER, PREBUILT (T-2677)                                        */
/* -------------------------------------------------------------------------- */

/**
 * T-2677, the second piece of T-2560 ("ship the town prebuilt"). Laying the
 * frontage's boards (1.95 million vertices) over the terrain is one main-thread task: 0.9 s on
 * the steward runner, 3.3 s at its 4x CPU throttle. `tools/publish.sh` now runs
 * this same function in Node (`tools/prebuild_layers.mjs`, byte-equal to the
 * page's build since T-2676) and writes `data/prebuilt/<year>/frontage.{json,bin}`,
 * and the page uploads those buffers instead of building them.
 *
 * WHAT IS PREBUILT AND WHAT IS NOT. Only the board geometry. The records are
 * still fetched and walked in the browser, so the walks, decks, keep-outs, cards
 * and census are built by the same loop as ever; the one thing that changes is
 * that each geometry call (`buildWalk`, `laySegment`, `buildFence`, `buildPost`,
 * `buildFitting`) is not made. Its answer — laid or not, and a post's board
 * frame — is read off a TAPE the Node build recorded, in call order, and the
 * buffers come from the file. The pick spans and the walk-top ranges the far
 * tops are cut from ride in the index beside the meshes.
 *
 * WHEN IT IS USED. Only when every one of these holds, and otherwise the page
 * builds in the browser exactly as before (the source tree always does):
 *   - the page carries a build stamp, and the prebuild was written by the same
 *     publish (`index.build`): the code and terrain it was built from are the
 *     page's own, not a cached file from another release;
 *   - every frontage record file the page fetched hashes (SHA-256) to what the
 *     index lists for it, and the index lists no other: the data is the same;
 *   - no host building is missing (`hostMissing`), because a missing host
 *     drops its fences and posts, which a recorded build did not;
 *   - the buffer is the length the index says.
 * `tools/check_published.mjs` refuses a published prebuild whose inputs have
 * moved, so the page's check is the second line, for a visitor whose cache holds
 * one release's prebuild beside another's page.
 */
/** 3 since T-2687: each mesh's quantized-position transform travels with it.
 *  4 since T-2689: the colour's fourth lane is the confidence, and says so.
 *  5 since T-2700: a boxed mesh's pieces travel with it (`position_boxes`). */
export const PREBUILT_FORMAT = 5;

/** The page's own build id, from the stamp publish.sh writes into it. */
export function pageBuild(doc = globalThis.document) {
  const text = doc?.getElementById?.('gate-build')?.textContent ?? '';
  return /^\s*build\s+(\S+)/.exec(text)?.[1] ?? null;
}

/**
 * Fetch `data/prebuilt/<year>/frontage.{json,bin}` for this page, or say why
 * not. Started early by main.js, so the download overlaps the boot phases ahead
 * of this layer. Resolves `{ index, bin }` or `{ why }`; it never rejects.
 */
export async function fetchPrebuiltFrontage({ dataBase, year, build }) {
  if (!dataBase || !year) return { why: 'this scene draws no frontage' };
  if (!build) return { why: 'this page carries no build stamp, so it builds its own (the source tree)' };
  // Imported here, not at the top: the node harnesses that load this file as a data:
  // URL never reach the fetch, as with jobs/pool.js below.
  const { prebuiltAbsent } = await import('./prebuilt-index.js');
  const absent = await prebuiltAbsent({ dataBase, year, build, layer: 'frontage' });
  if (absent) return { why: `${absent}, so the page builds its own timber` };
  const base = new URL(`prebuilt/${year}/`, dataBase);
  try {
    const res = await fetch(new URL('frontage.json', base));
    if (!res.ok) return { why: `no prebuilt frontage (${res.status})` };
    const index = await res.json();
    if (index.format !== PREBUILT_FORMAT) return { why: `prebuilt format ${index.format}, this page reads ${PREBUILT_FORMAT}` };
    if (index.build !== build) return { why: `prebuilt by build ${index.build}, this page is build ${build}` };
    const binRes = await fetch(new URL(index.bin, base));
    if (!binRes.ok) return { why: `no prebuilt buffer (${binRes.status})` };
    let bin = await binRes.arrayBuffer();
    // Shipped gzipped (the tree budget, prebuild_layers.mjs). A server that sent
    // it with Content-Encoding has already inflated it, so read the magic bytes.
    const head = new Uint8Array(bin, 0, Math.min(2, bin.byteLength));
    if (index.encoding === 'gzip' && head[0] === 0x1f && head[1] === 0x8b) {
      if (typeof DecompressionStream !== 'function') return { why: 'this browser cannot inflate the prebuilt buffer' };
      // On a pool worker: 78 MB inflated on the main thread was a second of long
      // tasks at the phone profile (jobs/inflate-kernel.js).
      // Imported here, not at the top: the node harnesses that load this file as a
      // data: URL (check_plank_*.mjs) never reach it, and the page already holds it.
      const { runJob } = await import('./jobs/pool.js');
      const { bytes } = await runJob('inflateGzip', { bytes: new Uint8Array(bin), passes: index.passes ?? 1 },
        { transfer: [bin] });
      bin = bytes.byteOffset === 0 && bytes.byteLength === bytes.buffer.byteLength
        ? bytes.buffer : bytes.slice().buffer;
    }
    if (bin.byteLength !== index.bytes) return { why: `prebuilt buffer is ${bin.byteLength} bytes, its index says ${index.bytes}` };
    return { index, bin };
  } catch (err) {
    return { why: `prebuilt frontage did not load: ${err.message}` };
  }
}

/** A record fetched as bytes, so its hash can be compared with the prebuild's. */
async function getJSONHashed(url) {
  const res = await fetch(url, { cache: 'no-cache' });
  if (!res.ok) throw new Error(`${res.status} ${res.statusText} — ${url}`);
  const bytes = await res.arrayBuffer();
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
  return { json: JSON.parse(new TextDecoder().decode(bytes)),
    sha256: Array.from(digest, (b) => b.toString(16).padStart(2, '0')).join('') };
}

/** One prebuilt mesh's geometry: typed-array views over the shared buffer. */
function prebuiltGeometry(m, bin) {
  const geo = new THREE.BufferGeometry();
  const view = (a) => new globalThis[a.type](bin, a.offset, a.byteLength / globalThis[a.type].BYTES_PER_ELEMENT);
  for (const a of m.attributes) geo.setAttribute(a.name, new THREE.BufferAttribute(view(a), a.itemSize, a.normalized));
  if (m.index) geo.setIndex(new THREE.BufferAttribute(view(m.index), 1));
  const s = m.bounding_sphere;
  if (s) geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(...s.center), s.radius);
  else geo.computeBoundingSphere();
  if (m.position_quantized) geo.userData.positionQuantized = m.position_quantized;
  if (m.position_boxes) geo.userData.positionBoxes = m.position_boxes;
  if (m.confidence_lane) geo.userData.confidenceLane = m.confidence_lane;
  return geo;
}

/**
 * Put a prebuilt mesh where its build left it. A mesh whose positions were
 * quantized (T-2687, compact-streams.js) holds Int16 over its own box, and the
 * box is the mesh's position and uniform scale: without them every chunk is
 * drawn as a one-metre blob at the origin, which is what a format-2 replay did.
 */
function placePrebuilt(mesh, m) {
  if (m.position) mesh.position.fromArray(m.position);
  if (typeof m.scale === 'number') mesh.scale.setScalar(m.scale);
  mesh.updateMatrix();
}

/**
 * @param {object} o dataBase (data/ root) · terrain · confidence · problems
 * @returns {Promise<{group: THREE.Group, records: object[], census: object,
 *                    pickAt: function, dispose: function}>}
 */
export async function createFrontage({
  dataBase, terrain, confidence = null, problems = [],
  /**
   * T-1126 — and here the answer is split, because this layer draws two
   * different kinds of thing off one record.
   *
   * The STANDING timber goes with its building: a board fence behind a shopfront
   * and a hitching post at a trading frontage are furniture belonging to a
   * business, and left standing around an empty lot they say a business was
   * there in exactly the way the auction room's signboard did.
   *
   * The PLANK WALKS do not. A footway is ground, not furniture — it is laid
   * along a street, the walker stands on it (`walkableDecks`), and a stretch of
   * boards with no shop behind it claims nothing about the shop. Taking the walk
   * away would put a hole in the surface a visitor is standing on to look at the
   * hole in the town, which trades a false claim for a worse one.
   */
  hostMissing = () => false,
  /**
   * T-2677: `{ index, bin }` from `fetchPrebuiltFrontage` (or a promise of it),
   * used when it is current against what this page read (see THE TOWN'S TIMBER,
   * PREBUILT above); `record` keeps the tape a prebuild writes.
   */
  prebuilt = null,
  record = false,
} = {}) {
  const group = new THREE.Group();
  group.name = 'frontage';
  const out = {
    group,
    records: [],
    walks: [],
    posts: [],
    /** The fittings at the business fronts (T-1813): stoops, mounting blocks,
     *  tie rails and wagon aprons, each a record naming the business it serves. */
    fittings: [],
    /** Deck rectangles in local ENU, for the planting block-list: a walk is a
     *  floor, and nothing may grow up through it (T-0085/T-0124). Same shape
     *  as the wharves' keepOut — `{ id, pts }`, consumed by flora's
     *  footprintCircles. */
    keepOut: [],
    /** Walker decks (T-0119): where a walk RIDES a committed deck over water,
     *  the planks are a surface a visitor stands ON, so the walk publishes the
     *  same `{ id, y, pts }` shape `decksFrom()` builds and main.js appends it
     *  to the walker's registry. `y` is the plank top — the deck the record
     *  rides plus the walk's own rise — so the boot and the board agree. */
    walkableDecks: [],
    /** The street-lining fence runs actually built (T-0069). */
    fences: [],
    census: {
      records: 0, walks: 0, crossings: 0, posts: 0, hitching: 0, lettered: 0,
      fittings: 0, fittingKinds: {}, fences: 0, decks: 0, refused: 0, orphaned: 0, meshes: 0,
      /** THE EDGE RULE (T-0460). `kerb` is how many lengths of string piece the
       *  layer laid down the sides of its walks; `kerbStep_m` is the largest
       *  height step between two consecutive lengths on one run, which is what
       *  is left of the sawtooth once the boards stopped each taking their own
       *  sample of the mud. Both are reported rather than asserted here — the
       *  gate proves the edge on the drawn geometry. */
      kerb: 0, kerbStep_m: 0,
      /** The substrate whose grain the timber carries (T-1815), or null. */
      relief: null,
    },
    /** T-2677: whether the timber came prebuilt, and if not, why not. */
    prebuilt: { used: false, why: prebuilt ? null : 'none offered' },
    pickAt: () => null,
    dispose: () => {},
  };

  if (!dataBase || !terrain) {
    problems.push('frontage: no data base or no terrain — no walk is laid');
    return out;
  }
  // The grain's maps load beside the records; the material waits for them.
  const reliefP = loadTimberRelief(resolveBases().assetBase);
  const offered = prebuilt ? await prebuilt : null;
  const read = offered?.index && globalThis.crypto?.subtle ? new Map() : null;
  if (offered && !offered.index) out.prebuilt.why = offered.why ?? 'none offered';
  else if (offered && !read) out.prebuilt.why = 'this page cannot hash what it read (no SubtleCrypto)';
  const fetchJSON = async (file) => {
    if (!read) return getJSON(new URL(file, dataBase));
    const { json, sha256 } = await getJSONHashed(new URL(file, dataBase));
    read.set(`data/${file}`, sha256);
    return json;
  };
  let index;
  try {
    index = await fetchJSON('frontage/index.json');
  } catch (err) {
    // Degrade to NOTHING drawn plus a recorded problem, never to an invented
    // walk: the same contract the enclosure, signage and yard layers keep.
    problems.push(`frontage: ${err.message} — no walk is laid`);
    return out;
  }
  const wanted = Array.isArray(index.frontage) ? index.frontage : [];
  const loaded = await Promise.all(wanted.map(async (f) => {
    if (!f.file) return [f.id, null, 'the manifest gave no file'];
    try {
      return [f.id, await fetchJSON(`frontage/${f.file}`), null];
    } catch (err) { return [f.id, null, err.message]; }
  }));

  // T-2677: the prebuild is replayed only over exactly the records it was built
  // from, with every host standing.
  let replay = null;
  if (read) {
    const built = offered.index.inputs.files.filter((f) => f.path.startsWith('data/frontage/'));
    const moved = built.filter((f) => read.get(f.path) !== f.sha256).map((f) => f.path)
      .concat([...read.keys()].filter((p) => !built.some((f) => f.path === p)));
    const orphan = loaded.some(([, record]) => record && ['fences', 'posts', 'fittings']
      .some((k) => (record[k] ?? []).some((item) => hostMissing(item.belongs_to))));
    if (moved.length) out.prebuilt.why = `built from other frontage data (${moved.slice(0, 3).join(', ')})`;
    else if (orphan) out.prebuilt.why = 'a host building is missing, so its timber is not the recorded build';
    else replay = offered;
  }
  /** Each geometry call's answer: made and recorded, or read off the tape. */
  const tape = [];
  let step = 0;
  const lay = (build) => {
    if (replay) return replay.index.tape[step++];
    const r = build();
    if (record) tape.push(r ?? null);
    return r;
  };

  const buf = timberBuf();
  const spans = [];
  const boards = [];
  // T-2037: planting exclusions also include yards and fittings. Only emitted
  // board crossings ask the far terrain to resolve their lowered street bed.
  const crossingFootprints = [];
  /** What the string pieces down the walks' edges came to (T-0460). */
  const edgeStats = { kerb: 0, kerbStep: 0 };
  /**
   * CHUNKED TIMBER (T-0119). The layer's timber has been one draw call since
   * T-0082, and for walks a few metres long that is right. The river walk is
   * 400 m of boards, and one geometry spanning Wolf Point to the slough mouth
   * has a bounding sphere no frustum ever culls — every triangle of a walk
   * behind the camera would be drawn from everywhere in the town. So a walk
   * with a POLYLINE centreline builds one small mesh per segment instead
   * (same material, same render order — the draw-call principle bends only as
   * far as culling needs it to), each carrying the walk's owner for the pick.
   */
  const chunks = [];
  /**
   * NAMED CHUNKS (T-0069). A record may put a `chunk` id on a walk, a crossing
   * or a fence, and everything carrying the same id lands in one buffer and
   * becomes one mesh. The town street edge names a chunk per platted block face,
   * so a face's sidewalk, the crossing at its corner and the fence behind it are
   * one bounding sphere and one draw call rather than three of each.
   */
  const named = new Map();
  const bufFor = (chunk, pickId, standing = false) => {
    if (!chunk) return null;
    const key = standing ? `${chunk}__standing` : chunk;
    let hit = named.get(key);
    if (!hit) {
      hit = { buf: replay ? null : timberBuf(), pickId, standing };
      named.set(key, hit);
    }
    return hit;
  };
  /**
   * T-0127 — WHY A FENCE NO LONGER SHARES ITS WALK'S MESH, and it is a shadow
   * decision rather than a culling one.
   *
   * T-0069 put a face's sidewalk, its corner crossing and the fence behind it in
   * ONE buffer, because three meshes where one would do is three draw calls and
   * three bounding spheres. That was right while every furniture mesh cast the
   * same shadow. It stops being right once the two halves want different
   * answers from the sun: a plank walk lies 0.11 m proud of the ground and its
   * own shadow is about 0.04 m wide at noon on 1 July — nothing a visitor can
   * see — while a 1.37 m board fence throws about half a metre of it along the
   * walk it stands behind (T-0115's ledger costed both). Drawing the boards into
   * the shadow map buys nothing and costs their whole triangle count a second
   * time, at the two tiers that cast at all.
   *
   * So the standing timber goes into its own buffer, keyed PER STREET rather
   * than per face: one extra mesh for each covered street instead of one for
   * each fenced face. T-0194's hitching posts join it — they are standing
   * timber on the same faces and they ride the meshes that already exist, which
   * is why a post at every trading frontage costs no draw call at all. That is the whole of the draw-call cost — three calls in
   * the colour pass and three in the shadow pass — against the thirty-five
   * ground-hugging chunks that leave the shadow pass entirely. Per-face
   * standing meshes would have cost twenty-six of each and made the trade a
   * loss.
   */
  // T-1823 — an item may name its own standing mesh: the fronts-only faces'
  // posts and fittings do, so a lone post far down a street does not stretch that
  // street's mesh (and its fences) into a shadow box it never reached before.
  const standingChunk = (record, item) => (item.standing_chunk
    ?? (item.street ? `${record.id}__${item.street}__standing` : item.chunk));
  const cards = new Map();
  for (const [id, record, why] of loaded) {
    if (!record) { problems.push(`frontage: ${id} — ${why}`); continue; }
    out.records.push(record);
    out.census.records += 1;
    out.census.refused += (record.refused ?? []).length;
    // A record that is its own subject (the river walk) rather than a
    // building's frontage carries a `card` block, and the layer answers a pick
    // on it with a registry-shaped record of its own — the same shape the boat
    // layer builds, for the same reason: there is no structure to open.
    if (record.card?.id) {
      cards.set(record.card.id, {
        id: record.card.id,
        sidecar: {
          name: record.card.name ?? record.name ?? record.card.id,
          phase: null,
          placement: {
            symbolic_location: record.card.symbolic_location ?? '',
            position_confidence: 'reconstructed',
            position_sources: [],
            position_note: record.card.position_note ?? record.existence?.note ?? '',
          },
          attributes: record.card.attributes ?? {},
          citations: [],
          research_note: record.card.research_note ?? record.research_note ?? '',
        },
      });
    }
    // T-0192 — the cross streets' own faces. A chunk is one block face, so a
    // face on a north-south street is one mesh, and it carries the flag that
    // lets `light` leave it out (main.js, `light.crossStreetWalks`).
    const crossStreets = new Set(record.rule?.cross_streets ?? []);
    for (const walk of record.walks ?? []) {
      const level = LEVEL[walk.confidence] ?? 1;
      const line = walk.centreline_local_enu_m ?? [];
      const crossing = walk.kind === 'board_crossing';
      const named0 = bufFor(walk.chunk, walk.belongs_to);
      if (named0 && crossStreets.has(walk.street)) named0.crossStreet = true;
      const chunked = !named0 && !crossing && Array.isArray(line) && line.length > 2;
      let ok;
      if (named0) {
        // A named chunk: lay straight into the face's own buffer (T-0069).
        ok = lay(() => inWalkTone(named0.buf, walk, () => (crossing
          ? buildCrossing(named0.buf, walk, terrain, level, problems)
          : buildWalk(named0.buf, walk, terrain, level, problems, edgeStats))));
      } else if (chunked) {
        // One chunk per segment; the walk is laid iff any segment laid boards.
        let laid = 0;
        for (let i = 0; i + 1 < line.length; i += 1) {
          const cbuf = replay ? null : timberBuf();
          const boardsLaid = lay(() => inWalkTone(cbuf, walk, () => laySegment(cbuf, walk,
            line[i][0], line[i][1], line[i + 1][0], line[i + 1][1], terrain, level,
            edgeStats)));
          if (!boardsLaid) continue;
          chunks.push({ buf: cbuf, pickId: walk.belongs_to });
          laid += boardsLaid;
        }
        ok = laid > 0;
        if (!ok) {
          problems.push(`frontage: ${walk.id} found no ground under any board `
            + '— nothing is laid');
        }
      } else {
        const from = buf.pos.length / 9;
        ok = lay(() => inWalkTone(buf, walk, () => (crossing
          ? buildCrossing(buf, walk, terrain, level, problems)
          : buildWalk(buf, walk, terrain, level, problems, edgeStats))));
        if (ok) spans.push({ id: walk.belongs_to, from, to: buf.pos.length / 9 });
      }
      if (!ok) continue;
      out.walks.push(walk);
      if (crossing) {
        // buildCrossing uses the first two points and this 1.22 m fallback.
        const [a, b] = line;
        const de = b[0] - a[0], dn = b[1] - a[1];
        const halfWidth = (walk.width_m ?? 1.22) / 2;
        const length = Math.hypot(de, dn);
        const pe = -dn / length * halfWidth, pn = de / length * halfWidth;
        crossingFootprints.push({
          id: walk.id,
          pts: [[a[0] + pe, a[1] + pn], [b[0] + pe, b[1] + pn],
            [b[0] - pe, b[1] - pn], [a[0] - pe, a[1] - pn]],
        });
      }
      out.census[crossing ? 'crossings' : 'walks'] += 1;
      // A walk that rides a committed deck registers the planks as a surface
      // the walker stands on (T-0119) — see `walkableDecks` above.
      if (Number.isFinite(walk.deck_m) && Array.isArray(walk.deck_span_local_enu_m)
          && walk.deck_span_local_enu_m.length >= 3) {
        out.walkableDecks.push({
          id: `${walk.id}__footway`,
          y: walk.deck_m + (walk.rise_m ?? 0.11),
          pts: walk.deck_span_local_enu_m,
        });
      }
      /**
       * AND THE WALK A VISITOR STANDS ON (T-0069). A sidewalk that a walker
       * sinks through is a painted stripe, not a walk, so every run and every
       * crossing on the town street edge publishes its own walking surfaces —
       * the same `{ id, y, pts }` the bridge decks and the river footway
       * publish, through the same registry (T-0045), because there is exactly
       * one mechanism in this project for "the visitor is standing on
       * something that is not the heightfield" and this is it. The heights are
       * the GENERATOR's: it cuts each run into the longest pieces whose ground
       * stays inside one flat deck and takes the highest ground under each,
       * which is what keeps `max(deck, ground)` on the planks from end to end.
       */
      for (const [i, deck] of (walk.footway_decks ?? []).entries()) {
        if (!Number.isFinite(deck?.y) || !Array.isArray(deck.pts) || deck.pts.length < 3) {
          problems.push(`frontage: ${walk.id} deck ${i} is not a surface — skipped`);
          continue;
        }
        out.walkableDecks.push({ id: `${walk.id}__footway_${i}`, y: deck.y, pts: deck.pts });
        out.census.decks += 1;
      }
      // The walk's deck rectangles, in ENU, for the planting block-list — one
      // per centreline segment, so a polyline blocks its whole run. The
      // builders work in world x/z; this stays in the (e, n) frame the flora
      // layer tests in. Exact width on purpose - a tuft leaning over the edge
      // is a verge, a tuft rooted mid-deck is a hole in the model.
      // A LONG SEGMENT IS CUT INTO PIECES, and it is the planting layer that
      // asks for it: `flora.js` rejects most candidates with one squared
      // distance against each block's own bounding circle, and a hundred-metre
      // rectangle has a fifty-metre circle — so a town-length walk would drag
      // every tuft within fifty metres of it down the slow path. Same ground,
      // same block, in pieces the circle test can actually reject.
      const hw = (walk.width_m ?? 1.83) / 2;
      for (let i = 0; i + 1 < line.length; i += 1) {
        const wa = line[i];
        const wb = line[i + 1];
        const de = wb[0] - wa[0];
        const dn = wb[1] - wa[1];
        const wl = Math.hypot(de, dn);
        if (wl < 0.5) continue;
        const cuts = Math.max(1, Math.ceil(wl / KEEPOUT_PIECE_M));
        for (let k = 0; k < cuts; k += 1) {
          const t0 = k / cuts;
          const t1 = (k + 1) / cuts;
          const ae = wa[0] + de * t0;
          const an = wa[1] + dn * t0;
          const be = wa[0] + de * t1;
          const bn = wa[1] + dn * t1;
          const pe = (-dn / wl) * hw;
          const pn = (de / wl) * hw;
          out.keepOut.push({
            id: `${walk.belongs_to}__walk`,
            pts: [[ae + pe, an + pn], [be + pe, bn + pn],
              [be - pe, bn - pn], [ae - pe, an - pn]],
          });
        }
      }
    }
    // The street-lining fences (T-0069). A fence that names a chunk lands in
    // that face's own buffer beside the walk it stands behind; one with no
    // chunk falls back to the layer's shared mesh, exactly as a post does.
    for (const fence of record.fences ?? []) {
      if (hostMissing(fence.belongs_to)) { out.census.orphaned += 1; continue; }
      const level = LEVEL[fence.confidence] ?? 1;
      const bucket = bufFor(standingChunk(record, fence), fence.belongs_to, true);
      const target = bucket ? bucket.buf : buf;
      const from = buf.pos.length / 9;
      if (!lay(() => buildFence(target, fence, terrain, level, problems))) continue;
      if (!bucket) spans.push({ id: fence.belongs_to, from, to: buf.pos.length / 9 });
      out.fences.push(fence);
      out.census.fences += 1;
    }
    // The posts. A post that names a street (the street edge's hitching posts,
    // T-0194) is STANDING timber and lands in that street's own standing mesh
    // beside the fences — it culls with them, it casts with them, and it costs
    // no draw call of its own. A post with no street (the two inns' own, which
    // are one record each) falls back to the layer's shared mesh, exactly as it
    // always did.
    for (const post of record.posts ?? []) {
      if (hostMissing(post.belongs_to)) { out.census.orphaned += 1; continue; }
      const level = LEVEL[post.confidence] ?? 1;
      const bucket = bufFor(standingChunk(record, post), post.belongs_to, true);
      const target = bucket ? bucket.buf : buf;
      const from = buf.pos.length / 9;
      // A hitching post is street-edge timber and takes the weathered palette,
      // keyed on the house it stands at (T-1815); a sign post keeps `TIMBER`,
      // the tone it shares with the board it carries.
      const board = lay(() => (post.kind === 'hitching_post'
        ? inOwnerTone(target, post.stands_at ?? post.belongs_to ?? post.id,
          () => buildPost(target, post, terrain, level, problems))
        : buildPost(target, post, terrain, level, problems)));
      if (!board) continue;
      if (!bucket) spans.push({ id: post.belongs_to, from, to: buf.pos.length / 9 });
      out.posts.push(post);
      out.census.posts += 1;
      if (post.kind === 'hitching_post') out.census.hitching += 1;
      if (board.text) out.census.lettered += 1;
      boards.push({ ...board, level });
    }
    // The fittings (T-1813) are standing timber at a street's edge exactly as the
    // posts are, so they land in the same street's standing chunk — no draw call
    // of their own.
    for (const fit of record.fittings ?? []) {
      if (hostMissing(fit.belongs_to)) { out.census.orphaned += 1; continue; }
      const level = LEVEL[fit.confidence] ?? 1;
      const bucket = bufFor(standingChunk(record, fit), fit.belongs_to, true);
      const target = bucket ? bucket.buf : buf;
      const from = buf.pos.length / 9;
      if (!lay(() => inOwnerTone(target, fit.serves ?? fit.belongs_to ?? fit.id,
        () => buildFitting(target, fit, terrain, level, problems)))) continue;
      if (!bucket) spans.push({ id: fit.belongs_to, from, to: buf.pos.length / 9 });
      out.fittings.push(fit);
      // A stoop or an apron is a floor like the walk, and a block or a rail stands
      // on its own ground: nothing is planted up through any of them. An apron is
      // named apart because it is the one floor here a WAGON may stand on — it is
      // laid for the dray at a forwarding house's door.
      const fb = ((fit.facade_bearing_deg ?? 0) * Math.PI) / 180;
      const [fae, fan, foe, fon] = [Math.cos(fb), -Math.sin(fb), Math.sin(fb), Math.cos(fb)];
      for (const part of fit.parts) {
        const [pe, pn] = part.at_local_enu_m;
        const hl = part.len_m / 2;
        const hd = part.depth_m / 2;
        out.keepOut.push({
          id: `${fit.belongs_to}__${fit.kind === 'wagon_apron' ? 'apron' : 'fitting'}`,
          pts: [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([sa, so]) => [
            pe + fae * sa * hl + foe * so * hd, pn + fan * sa * hl + fon * so * hd]),
        });
      }
      out.census.fittings += 1;
      out.census.fittingKinds[fit.kind] = (out.census.fittingKinds[fit.kind] ?? 0) + 1;
    }
  }
  // A works' bare front (T-1814): no walk is laid there, and nothing is planted
  // either, so the smith's front reads as trodden yard rather than prairie.
  for (const [, record] of loaded) {
    if (!record) continue;
    for (const bare of record.bare_fronts ?? []) {
      if (Array.isArray(bare.pts_local_enu_m) && bare.pts_local_enu_m.length >= 3) {
        out.keepOut.push({ id: `${bare.belongs_to}__bare`, pts: bare.pts_local_enu_m });
      }
    }
  }
  // The named chunks join the polyline ones: same material, same render order,
  // one bounding sphere each (T-0069).
  for (const [id, hit] of named) {
    if (hit.buf?.pos.length) {
      chunks.push({ buf: hit.buf, pickId: hit.pickId, id, standing: hit.standing,
        crossStreet: !!hit.crossStreet });
    }
  }
  if (replay && step !== replay.index.tape.length) {
    problems.push(`frontage: the prebuilt tape ran ${step} of ${replay.index.tape.length} steps — `
      + 'the page and the prebuild disagree about the records');
  }
  if (replay) releaseTimberBuf(buf);
  else if (!buf.pos.length && !chunks.length) {
    if (out.census.records) {
      problems.push('frontage: the records loaded and not one board was laid');
    }
    return out;
  }

  // T-2677: a replay takes every mesh's buffers from the prebuild instead.
  const geo = replay ? prebuiltGeometry(replay.index.meshes[0], replay.bin) : new THREE.BufferGeometry();
  if (!replay) {
    geo.setAttribute('position', new THREE.BufferAttribute(buf.pos.float32(), 3));
    // Normals and tones in compact normalized formats (T-2569, compact-streams.js),
    // the confidence in the tone's fourth lane (T-2689).
    geo.setAttribute('normal', compactNormals(buf.nrm.view()));
    setColorsAndConfidence(geo, buf.col.view(), buf.conf.float32());
    geo.setAttribute('uv', new THREE.BufferAttribute(buf.uv.float32(), 2));
    geo.setAttribute('aChiPlankGap', plankGapAttribute(buf.seam.view()));
    geo.computeBoundingSphere();
    releaseTimberBuf(buf);
  }

  const mat = new THREE.MeshStandardMaterial({
    // The colour is on the vertex since T-1800: the walks carry their owners'
    // weathered tones and the fences and posts carry `TIMBER`, in one material.
    color: 0xffffff, vertexColors: true, roughness: 0.9, metalness: 0.0,
    /**
     * IN THE TRANSPARENT PASS ON PURPOSE, AND NOT BECAUSE ANY OF IT IS
     * TRANSPARENT (T-0625). This timber is opaque and is drawn opaque: alpha is
     * 1, `depthWrite` stays on, and nothing about the picture blends. The flag
     * is here for ONE reason — it is what puts the layer in the same render
     * list as the street ribbon, so that `renderOrder` below can order the two.
     *
     * WHY THAT IS NEEDED. three sorts opaques and transparents into SEPARATE
     * lists and draws every opaque before any transparent; `renderOrder` sorts
     * WITHIN a list and cannot reach across the two. The street ribbon is
     * `transparent: true` (its alpha is genuinely graded — the track feathers
     * at its edges and the ruts and crown modulate it), so a ribbon set to
     * renderOrder 0 was still drawn AFTER opaque timber set to renderOrder 1.
     * The order the comment on `mesh.renderOrder` describes was never the order
     * that ran, for as long as that comment has been there.
     *
     * WHAT IT COST. The ribbon carries `polygonOffset -8/-32` to stop the
     * terrain punching through its drape (R-BUG2, then R-BUG3 deepening it),
     * and `polygonOffsetFactor` scales with the polygon's depth SLOPE — which at
     * the grazing angle you view a road at is enormous. So the ribbon, drawn
     * last and biased hard toward the camera, painted over the plank crossings
     * standing 0.06 m above it, in hard triangular patches following the
     * terrain's own triangulation. The owner reported it twice: it is the
     * "jagged sawtooth" of T-0460 as seen from the street, and T-0460 fixed the
     * walk's board ends without touching this, which is why it survived that
     * ticket. Measured at the Sauganash crossing: 5.2 % of frame pixels wrong.
     *
     * WHY NOT THE OTHER TWO REPAIRS. Biasing the timber's own polygonOffset
     * past the road's works, but it is an arms race against a number tuned
     * twice already, and it pushes the timber through what it abuts — measured
     * worse than this at -10/-40 and worse again at -16/-64. Making the ribbon
     * opaque also works and is worse still: its alpha is real, and dropping the
     * blend hardens every feathered track edge in the town.
     */
    transparent: true,
  });
  mat.name = 'frontage-timber';
  const grain = await reliefP;
  if (grain.problem) problems.push(`frontage: ${grain.problem}`);
  else grain.apply(mat);
  out.census.relief = grain.problem ? null : grain.id;
  filterPlankGaps(mat);
  // The grade is read from the tone's fourth lane, not a float stream (T-2689).
  confidence?.patch(mat, { packed: COLOR_LANE_CONFIDENCE });
  /**
   * ITS OWN PROGRAM CACHE KEY. three caches a compiled program under a key
   * ending in `customProgramCacheKey()`, whose default is the SOURCE TEXT of
   * `onBeforeCompile` — so every material `confidence.patch()` touches reports
   * the same key and two of them can silently share one program. That drew a
   * whole layer in another layer's shader once already; ticket T-0053 is the
   * general fix and this is the local guard every derived layer carries.
   */
  mat.customProgramCacheKey = () => 'chicago4d-frontage-timber-subpixel-gaps';
  /**
   * THE BOX TABLE (T-2700, compact-streams.js). The shared mesh spans the town,
   * far wider than one box keeps to the millimetre, so it is boxed piece by
   * piece and stays ONE draw: each vertex names its piece in the position's
   * padding lane and this material's vertex stage reads the piece's box. The
   * chunks name none and draw as they did. Patched after the key above, which
   * it extends with the table's length.
   */
  const boxes = createBoxTable();
  patchBoxTable(mat, boxes);
  /** A boxed mesh's table rows, its raycast and its shadow, wherever it came from. */
  const boxMesh = (m) => {
    if (!adoptPositionBoxes(m.geometry, boxes)) return;
    m.raycast = raycastBoxed;
    m.customDepthMaterial = boxDepthMaterial(boxes);
  };

  const mesh = new THREE.Mesh(geo, mat);
  // Int16 x 4 positions relative to the mesh, its box in its matrix, where that
  // keeps the millimetre (T-2687, compact-streams.js); boxed piece by piece where
  // it does not (T-2700). The chunks below do the same; a replay takes the
  // build's own transform and boxes with its buffers.
  if (replay) placePrebuilt(mesh, replay.index.meshes[0]);
  else if (!quantizeMeshPositions(mesh)) packPositionBoxes(geo, boxes);
  boxMesh(mesh);
  /**
   * DRAWN AFTER THE STREET RIBBON, and the owner's report is why. The road is a
   * decal: depthWrite off, polygonOffset -8/-32 so it hugs the terrain without
   * z-fighting it. At a grazing angle that offset outweighs the 6-11 cm a board
   * stands above the ground, so a ribbon drawn after the planks paints STRAIGHT
   * OVER a board crossing. Order is the whole fix: drawn after the ribbon, the
   * planks pass their depth test (the decal writes no depth) and the crossing
   * sits on the road the way a board laid on dirt does. Real occlusion is
   * untouched - terrain writes depth, so a walk behind a rise stays hidden.
   *
   * THIS LINE ALONE DID NOT DO IT, and for two months it read as though it had
   * (T-0625). `renderOrder` orders a mesh within its own render list, and until
   * the material above joined the transparent list this mesh was in the other
   * one — where three draws every opaque before any transparent, whatever their
   * renderOrder. The ordering this comment describes only became real when the
   * material got `transparent: true`; keep the two together.
   */
  mesh.renderOrder = 1;
  mesh.name = 'frontage';
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  group.add(mesh);

  // The chunked walks (T-0119): one small mesh per polyline segment, sharing
  // the layer's material and render order, each with its own bounding sphere so
  // a reach of the river walk behind the camera culls instead of drawing. The
  // pick carries the owner on the mesh itself — a chunk is one walk's timber
  // and nothing else, so it needs no face-span arithmetic.
  const chunkMeshes = [];
  const walkTopSources = [{ mesh,
    ranges: replay ? replay.index.meshes[0].walk_top_ranges : buf.walkTopRanges }];
  for (const m of replay ? replay.index.meshes.slice(1) : []) {
    const cmesh = new THREE.Mesh(prebuiltGeometry(m, replay.bin), mat);
    placePrebuilt(cmesh, m);
    boxMesh(cmesh);
    cmesh.renderOrder = m.renderOrder;
    cmesh.name = m.name;
    cmesh.castShadow = m.castShadow;
    cmesh.receiveShadow = m.receiveShadow;
    Object.assign(cmesh.userData, m.userData);
    group.add(cmesh);
    chunkMeshes.push(cmesh);
    walkTopSources.push({ mesh: cmesh, ranges: m.walk_top_ranges });
  }
  for (const chunk of replay ? [] : chunks) {
    const cgeo = new THREE.BufferGeometry();
    cgeo.setAttribute('position', new THREE.BufferAttribute(chunk.buf.pos.float32(), 3));
    cgeo.setAttribute('normal', compactNormals(chunk.buf.nrm.view()));
    setColorsAndConfidence(cgeo, chunk.buf.col.view(), chunk.buf.conf.float32());
    cgeo.setAttribute('uv', new THREE.BufferAttribute(chunk.buf.uv.float32(), 2));
    cgeo.setAttribute('aChiPlankGap', plankGapAttribute(chunk.buf.seam.view()));
    cgeo.computeBoundingSphere();
    releaseTimberBuf(chunk.buf);
    const cmesh = new THREE.Mesh(cgeo, mat);
    // One box where it keeps the millimetre (T-2687); the long street-edge
    // chunks, too wide for one, boxed piece by piece and still one draw (T-2701).
    if (!quantizeMeshPositions(cmesh)) packPositionBoxes(cgeo, boxes);
    boxMesh(cmesh);
    cmesh.renderOrder = 1;                 // same street-decal ordering as above
    cmesh.name = 'frontage-chunk';
    // T-0127 — GROUND-HUGGING TIMBER OPTS OUT OF THE SHADOW MAP. The flag is on
    // the MESH and not on the layer, because within this one layer the boards
    // and the fences want different answers (see `standingChunk` above).
    // `applyShadowTier` in main.js reads it; a tier that casts still casts
    // everything else, and `light`, which casts nothing, is unaffected.
    cmesh.userData.groundHugging = !chunk.standing;
    cmesh.castShadow = !!chunk.standing;
    cmesh.receiveShadow = true;
    cmesh.userData.pickId = chunk.pickId;
    if (chunk.crossStreet) cmesh.userData.crossStreet = true;
    group.add(cmesh);
    chunkMeshes.push(cmesh);
    walkTopSources.push({ mesh: cmesh, ranges: chunk.buf.walkTopRanges });
  }
  out.census.meshes = group.children.length;
  out.census.kerb = replay ? replay.index.census.kerb : edgeStats.kerb;
  out.census.kerbStep_m = replay ? replay.index.census.kerbStep_m
    : Math.round(edgeStats.kerbStep * 1000) / 1000;
  if (replay) {
    spans.splice(0, spans.length, ...replay.index.spans);
    out.prebuilt = { used: true, why: null, build: replay.index.build, bytes: replay.index.bytes };
  }
  // What a prebuild writes beside the buffers (tools/prebuild_layers.mjs).
  if (record) {
    out.prebuild = { tape, spans: spans.map((sp) => ({ ...sp })),
      walkTopRanges: walkTopSources.map((w) => w.ranges.map((r) => ({ ...r }))) };
  }
  terrain.protectGroundUnder?.(crossingFootprints);

  const letters = makeLettering(boards);
  let letterMat = null;
  if (letters) {
    letterMat = new THREE.MeshStandardMaterial({
      map: letters.texture,
      color: new THREE.Color(0xffffff),
      roughness: 0.95,
      metalness: 0.0,
      transparent: false,
      alphaTest: 0.5,
      /**
       * DOUBLE-SIDED, and it is not laziness. Each face's quad is wound from the
       * board's own axes rather than from a camera, so one of the two comes out
       * back-facing — and under `FrontSide` the name simply did not draw, on a
       * board that looked perfectly finished. Four triangles is not worth a
       * winding rule that has to be right twice.
       */
      side: THREE.DoubleSide,
    });
    letterMat.name = 'frontage-lettering';
    confidence?.patch(letterMat);
    letterMat.customProgramCacheKey = () => 'chicago4d-frontage-lettering';
    const letterMesh = new THREE.Mesh(letters.geo, letterMat);
    letterMesh.name = 'frontage-lettering';
    letterMesh.castShadow = false;
    letterMesh.receiveShadow = false;
    group.add(letterMesh);
    out.census.meshes = group.children.length;
    out.lettering = letters.text;
  }
  group.userData.census = out.census;
  // A replacement draw, not another frontage item: keep it outside the census
  // and picker just as the furniture's far-merge batches are counted separately.
  const farWalkTops = createFarWalkTops(group, walkTopSources, mat);
  out.updateFarWalks = farWalkTops.update;
  out.farWalkTops = farWalkTops.state;

  /**
   * What a pick on this layer answers: the id of the building (or, for a
   * record that is its own subject, the walk) the timber belongs to — plus,
   * when the layer holds its own card for that id, the registry-shaped record
   * main.js hands the popup when the registry has nothing under it (T-0119).
   * The tap is drawn, not raycast (gpu-pick.js, T-2572): the face it names is
   * the face the raycast named, so the spans below read it unchanged.
   */
  // A cross street's walk the tier hides is not drawn, so it is not tapped (T-0192).
  const pick = layerPick(() => [mesh, ...chunkMeshes.filter((c) => c.visible || !c.userData.crossStreet)], (hit) => {
    let id = hit.object.userData.pickId ?? null;
    if (!id) {
      const span = spans.find((sp) => hit.face >= sp.from && hit.face < sp.to);
      if (!span) return null;
      id = span.id;
    }
    return {
      id, point: hit.point, distance: hit.distance,
      record: cards.get(id) ?? null,
    };
  });
  out.pickAt = pick.pickAt;
  out.pickAtAsync = pick.pickAtAsync; // the gaze target's look (T-2723)
  out.pickAtRaycast = pick.pickAtRaycast;

  out.dispose = () => {
    geo.dispose();
    for (const c of chunkMeshes) c.geometry.dispose();
    farWalkTops.dispose();
    mat.dispose();
    boxes.depth?.dispose();
    grain.dispose?.();
    if (letters) { letters.geo.dispose(); letters.texture.dispose(); }
    if (letterMat) letterMat.dispose();
  };
  return out;
}
