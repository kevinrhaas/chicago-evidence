"""Prepare isolated fixtures only; never invokes Blender, browser, publisher or repo edits."""
import pathlib,shutil,json
P=pathlib.Path(__file__).parent;B=P.parent/'frame_tavern-combined';Q=P.parent/'T-2385-roof-flag-anchor';R=pathlib.Path('/workspace/chicago/chicago/4d');O=P/'preview-root'
O.mkdir(exist_ok=True)
shutil.copytree(B/'preview-root/tools',O/'tools',dirs_exist_ok=True)
(O/'node_modules').symlink_to('/workspace/node_modules',target_is_directory=True)
(O/'renderers/web').mkdir(parents=True,exist_ok=True)
(O/'renderers/web/vendor').symlink_to(R/'renderers/web/vendor',target_is_directory=True)
shutil.copytree(R/'renderers/web/js',O/'renderers/web/js',dirs_exist_ok=True)
for name in ['flags.js','flag-anchors.js']:shutil.copy2(Q/'proposed/chicago/4d/renderers/web/js'/name,O/'renderers/web/js'/name)
for name in ['tremont','tremont-flag']:
 d=O/'review'/name;d.mkdir(parents=True,exist_ok=True);shutil.copy2(B/'preview-root/review/tremont/gifford-provisional.json',d/'gifford-provisional.json')
# Canonical emitter fixture compares frozen final-gable old target modules/data;
# current parent Hogan branch must never be loaded as the baseline.
s=(B/'export_previews.py').read_text().replace('/tmp/chicago-next-model/frame_tavern-combined',str(P));(P/'export_previews.py').write_text(s)
s=(B/'run_exports.sh').read_text().replace('/tmp/chicago-next-model/frame_tavern-combined',str(P));(P/'run_exports.sh').write_text(s)
# Separate prototype helper includes the *actual proposed app layer*, not baked
# cloth or an independently reimplemented flag mesh. Standard helper stays intact.
f=O/'tools/photo_match_flags_diagnostic.mjs';s=(O/'tools/photo_match.mjs').read_text();s=s.replace("import {tintKeithStone} from '/renderers/web/js/keith-stone.js';", "import {tintKeithStone} from '/renderers/web/js/keith-stone.js';\nimport {createFlags} from '/renderers/web/js/flags.js';")
r=json.loads((Q/'proposed/chicago/4d/data/structures/tremont_house_1.json').read_text());attrs={k:r['phases'][0]['form'][k] for k in ['flag','flag_flying','flag_anchor']};side={'phase':'frame_1833','target_date':'1835-07-01','attributes':attrs}
old='})).then(placed=>{for(const object of placed)s.add(object);r.render(s,cam);window.__done=true;})'
new='''})).then(placed=>{
 for(const object of placed)s.add(object);
 const sidecar='''+json.dumps(side)+''';
 const bounds=new THREE.Box3().setFromObject(placed[0]);
 const problems=[];
 const flags=createFlags({registry:new Map([['tremont_house_1',{id:'tremont_house_1',sidecar}]]),
  buildings:{matrixOf:()=>new THREE.Matrix4(),instanceBounds:()=>({tremont_house_1:{min:bounds.min.toArray(),max:bounds.max.toArray()}})},problems});
 if(problems.length || flags.drawn.length!==1)throw Error(JSON.stringify({problems,drawn:flags.drawn}));
 flags.update(0);s.add(flags.group);
 window.__flagDiagnostics={prototype_only:true,animation_time:0,drawn:flags.drawn,problems,
  model_bounds:{min:bounds.min.toArray(),max:bounds.max.toArray()},anchor:sidecar.attributes.flag_anchor,
  flag_mesh:flags.group.children[0]?.children[0]?.position.toArray()};
 r.render(s,cam);window.__done=true;
})'''
assert old in s;s=s.replace(old,new)
s=s.replace("  const render = path.join(fs.mkdtempSync", "  fs.writeFileSync(path.join(out, 'flag-layer-diagnostic.json'), JSON.stringify(await page.evaluate(() => window.__flagDiagnostics), null, 2)+'\\n');\n  const render = path.join(fs.mkdtempSync",1)
f.write_text(s)
print('Prepared canonical export, unchanged camera, standard and actual app-layer diagnostic helpers; no heavy job started')
