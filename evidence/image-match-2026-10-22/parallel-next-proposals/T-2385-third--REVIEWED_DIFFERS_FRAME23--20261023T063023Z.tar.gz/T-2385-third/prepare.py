import pathlib,shutil,json,difflib
P=pathlib.Path(__file__).parent;B=P.parent/'frame-gable-cladding'
for folder in ('baseline','proposed'):
 for rel in ['generators/archetypes/frame_tavern.py','generators/archetypes/frame_tavern_params.py','data/structures/tremont_house_1.json','data/structures/green_tree_tavern.json','data/structures/sauganash_hotel.json']:
  f=P/folder/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(B/'proposed'/rel,f)
(P/'proposed/generators/archetypes/__init__.py').touch()
f=P/'proposed/generators/archetypes/frame_tavern_params.py';s=f.read_text();s=s.replace('"flagstaff", "flagstaff_height_m", "gable_wall_cladding",','"flagstaff", "flagstaff_height_m", "gable_wall_cladding",\n    "gable_arch_treatment", "corner_entry_surround",')
s=s.replace('    gable_lunette: bool = False','    gable_lunette: bool = False\n    # A matte unresolved panel avoids asserting glazing where Gifford shows\n    # lettering-like light marks. No text is invented or claimed legible.\n    gable_arch_treatment: str = "fanlight"\n    corner_entry_surround: bool = False')
s=s.replace('("flagstaff", self.flagstaff)):', '("flagstaff", self.flagstaff),\n                             ("corner_entry_surround", self.corner_entry_surround)):')
s=s.replace('        detailed = (self.first_story_height_m', '        if self.gable_arch_treatment not in ("fanlight", "opaque_panel"):\n            raise ParamError("gable_arch_treatment must be fanlight or opaque_panel")\n        if self.gable_arch_treatment != "fanlight" and not self.gable_lunette:\n            raise ParamError("opaque arch treatment needs a gable_lunette outline")\n        detailed = (self.first_story_height_m')
s=s.replace('                    or self.gable_lunette or self.flagstaff)', '                    or self.gable_lunette or self.flagstaff or self.corner_entry_surround)')
s=s.replace('        gable_lunette=val("gable_lunette", False),','        gable_lunette=val("gable_lunette", False),\n        gable_arch_treatment=val("gable_arch_treatment", "fanlight"),\n        corner_entry_surround=val("corner_entry_surround", False),')
f.write_text(s)
f=P/'proposed/generators/archetypes/frame_tavern.py';s=f.read_text();s=s.replace('                    if params.entry_raise_m > 0:\n                        _corner_landing', '                    if params.corner_entry_surround:\n                        _corner_entry_surround(b, params, axis, plane, outward,\n                                               centre, params.entry_raise_m)\n                    if params.entry_raise_m > 0:\n                        _corner_landing',1)
marker='def _corner_landing(b: MeshBuilder, axis: str, plane: float, outward: int,'
helper='''def _corner_entry_surround(b: MeshBuilder, params: FrameTavernParams,
                           axis: str, plane: float, outward: int,
                           centre: float, raised: float) -> None:
    """Plain broad jamb/header outline; stock and hidden repeats reconstructed.

    Gifford shows an outlined entry, not a measured order of columns. Keep the
    existing door opening/leaf and add neither a pediment nor decorative text.
    """
    trim = _kit(b, params).casing
    half, stock, top = 0.60, 0.14, raised + 2.10
    for side in (-1, 1):
        lo, hi = sorted((centre + side*half, centre + side*(half+stock)))
        _corner_wall_box(b, axis, plane, outward, lo, hi,
                         LIP_M+0.035, LIP_M+0.10, raised, top, trim)
    _corner_wall_box(b, axis, plane, outward, centre-half-stock,
                     centre+half+stock, LIP_M+0.035, LIP_M+0.10,
                     top, top+stock, trim)


'''
assert s.count(marker)==1;s=s.replace(marker,helper+marker)
s=s.replace('    half, rise, base = d * 0.20, 0.74, wall_z + 0.55','    opaque = params.gable_arch_treatment == "opaque_panel"\n    # Matte warm charcoal is a reconstructed tonal choice, not an original\n    # pigment identification from the monochrome reproduction.\n    field_mat = (b.named_mat("gable_panel", (0.11, 0.10, 0.09, 1.0), 0.95)\n                 if opaque else M_GLASS)\n    half, rise, base = d * 0.20, 0.74, wall_z + 0.55',1)
s=s.replace('            face(pts,M_GLASS)\n            pts = [point(*outer[i]', '            face(pts,field_mat)\n            pts = [point(*outer[i]',1)
s=s.replace('        # Three plain radial bars; source does not calibrate fanlight joinery.\n        for angle in (math.pi/4, math.pi/2, 3*math.pi/4):','        # Preserve the old fanlight only by default. The opaque-panel opt-in\n        # removes unsupported glazing bars; source lettering remains unresolved.\n        for angle in (() if opaque else (math.pi/4, math.pi/2, 3*math.pi/4)):')
f.write_text(s)
f=P/'proposed/data/structures/tremont_house_1.json';r=json.loads(f.read_text());form=r['phases'][0]['form']
form['gable_arch_treatment']={'value':'opaque_panel','confidence':'reconstructed','sources':['gifford_tremont_house_no_1'],'note':'Re-inspecting the Gifford reproduction, the dark arched field contains irregular light lettering-like marks rather than a clearly resolved fanlight radial pattern. Opaque matte panel is the more cautious working interpretation: remove the invented glass/radial bars, retain the prior arch outline, and do not invent a legible hotel name or any letter shapes. Exact original inscription, panel construction, finish/pigment and hidden opposite treatment remain unresolved/reconstructed. Working warm charcoal is a tonal choice from a monochrome image, not an attested colour. All source attribution and owner-approved use metadata remain controlling.'}
form['corner_entry_surround']={'value':True,'confidence':'reconstructed','sources':['gifford_tremont_house_no_1'],'note':'The pictured ground-level entries have broad simple outlines. Add plain jambs and a level header around the existing opening without a pediment or invented ornamental order. The working0.14m stock and65mm projection, existing trim palette, exact sections, and repeated concealed entry surrounds are reconstructed, not measured dimensions. Existing opening centres, door leaf,7.8m envelope, platform layout, footprint/placement and source-date uncertainty remain unchanged.'}
f.write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
rel=['generators/archetypes/frame_tavern.py','generators/archetypes/frame_tavern_params.py','data/structures/tremont_house_1.json']
patch=''.join(''.join(difflib.unified_diff((P/'baseline'/q).read_text().splitlines(True),(P/'proposed'/q).read_text().splitlines(True),fromfile='a/chicago/4d/'+q,tofile='b/chicago/4d/'+q)) for q in rel)
(P/'incremental.patch').write_text(patch)
print('Prepared bounded arch/entry incremental proposal; no tracked edits')
