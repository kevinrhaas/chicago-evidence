import pathlib,sys,types,importlib.util,dataclasses,json,copy,math
P=pathlib.Path(__file__).parent;R=pathlib.Path('/workspace/chicago/chicago/4d');sys.path[:0]=[str(P/'proposed/generators'),str(R/'generators')];sys.modules.setdefault('bpy',types.ModuleType('bpy'))
from archetypes import frame_tavern as new,frame_tavern_params as par
from common.mesh import MeshBuilder

def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m
old=load('tremont_third_before',P/'baseline/generators/archetypes/frame_tavern.py');op=load('tremont_third_before_params',P/'baseline/generators/archetypes/frame_tavern_params.py')
MeshBuilder.to_object=lambda self,mats=None:(self,list(mats or []))
for m in (old,new):m.simple_material=lambda n,*a,**kw:(n,a,kw)
def sig(result):
 b,m=result;return b.verts,b.faces,b.conf,b.mat_index,b.named,m
count=0
for f in sorted((R/'data/structures').glob('*.json')):
 r=json.loads(f.read_text())
 if r.get('archetype')!='frame_tavern':continue
 frozen=P/'baseline/data/structures'/f.name
 if frozen.exists():r=json.loads(frozen.read_text())
 for ph in r['phases']:
  a=op.from_phase(ph,r);b=par.from_phase(ph,r);d=dataclasses.asdict(b);assert d.pop('gable_arch_treatment')=='fanlight';assert d.pop('corner_entry_surround') is False;assert d==dataclasses.asdict(a)
  assert sig(old.build(a,r['id']+'__'+ph['id']))==sig(new.build(b,r['id']+'__'+ph['id'])),(r['id'],ph['id']);count+=1
print('PASS final-gable frozen defaults exactly unchanged:',count,'record-phases including Tremont')
r=json.loads((P/'proposed/data/structures/tremont_house_1.json').read_text());ph=r['phases'][0];p=par.from_phase(ph,r)
assert p.gable_arch_treatment=='opaque_panel' and p.corner_entry_surround
base=json.loads((P/'baseline/data/structures/tremont_house_1.json').read_text());clean=copy.deepcopy(r)
for a in ['gable_arch_treatment','corner_entry_surround']:clean['phases'][0]['form'].pop(a);assert a in par.CONSUMED
assert clean==base
import jsonschema;jsonschema.validate(r,json.loads((R/'data/structures.schema.json').read_text()))
b=MeshBuilder('opaque');new._corner_lunettes(b,p,p.width_m,p.depth_m,p.wall_height_m)
assert new.M_GLASS not in b.mat_index and 'gable_panel' in b.named
index=MeshBuilder.NAMED_BASE+b.named['gable_panel'][0];assert sum(m==index for m in b.mat_index)==32
assert b.named['gable_panel'][2]==.95 and all(c==1 for c in b.conf)
f=MeshBuilder('fanlight');new._corner_lunettes(f,dataclasses.replace(p,gable_arch_treatment='fanlight'),p.width_m,p.depth_m,p.wall_height_m)
assert 'gable_panel' not in f.named and sum(m==new.M_GLASS for m in f.mat_index)==32
assert len(f.faces)-len(b.faces)==6
for axis in ['x','y']:
 for out in [-1,1]:
  b=MeshBuilder('entry');new._corner_entry_surround(b,p,axis,0,out,3.,p.entry_raise_m);assert len(b.faces)==18
  assert len(set(b.mat_index))==1 and 'trim' in b.named and all(c==1 for c in b.conf)
  assert max(v[2] for v in b.verts)==p.entry_raise_m+2.1+.14
for changes in [{'gable_arch_treatment':'text'},{'gable_arch_treatment':None},{'gable_lunette':False},{'corner_entry_surround':'true'},{'corner_entry_surround':1},{'elevation_scheme':'frontage'}]:
 try:dataclasses.replace(p,**changes).validate()
 except par.ParamError:pass
 else:raise AssertionError(changes)
print('PASS isolated schema/data delta; opaque matte panel/no glass/radial bars; old fanlight intact; broad3board surrounds bothaxes/outwards reconstructed; invalid enum/boolean/dependency refused')
print('NO Blender/browser/fullgate, no accepted view, no metric or historical lettering assertion')
