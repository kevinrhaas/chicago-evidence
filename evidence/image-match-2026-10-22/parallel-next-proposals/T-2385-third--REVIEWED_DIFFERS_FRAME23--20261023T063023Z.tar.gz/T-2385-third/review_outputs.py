import json,pathlib,hashlib,re,shutil,struct
from PIL import Image,ImageDraw,ImageFont
P=pathlib.Path(__file__).parent;O=P/'preview-root';Q=P.parent/'T-2385-roof-flag-anchor'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
freeze=json.loads((P/'execution-freeze.json').read_text());assert all(sha(pathlib.Path(k))==v for k,v in freeze['code_and_contracts'].items())
rows=[]
for label,folder in [('previous final-gable proposal','review/tremont/before'),('third arch/entry proposal','review/tremont'),('third + proposed app flag layer, held0','review/tremont-flag')]:
 d=O/folder;cam=d/'gifford-provisional.json';m=json.loads(cam.with_suffix('.match.json').read_text());c=json.loads(cam.read_text());raw=pathlib.Path(re.search(r'  (/tmp/photo-match-[^\n]+-render.png)',(d/'photo-match.log').read_text()).group(1));shutil.copy2(raw,d/'render.png');m['verdict']='differs';m['prototype_only']=True
 if folder.endswith('before'):
  diffs=[('Arched gable retains the previous glass/radial-fanlight working interpretation; source lettering-like fine marks remain unresolved.','open'),('The existing entry has the prior narrow kit casing; the source broad plain entry outlines are not represented by the follow-up boards yet.','open')]
 else:
  diffs=[('Opaque matte arch panel removes invented radial glazing bars without inventing text; exact inscription/sign-versus-window identity, construction, tone and timing remain unresolved.','fixed'),('Plain broad jamb/header boards now outline the existing raised entries; exact sections, proportions, palette and hidden repeats remain reconstructed.','fixed'),('Source flag pose, opening/landing/rail/shutter/stack/eave details, finishes, neighbours and street context remain unresolved; the provisional camera is not accepted.','open')]
 if folder.endswith('tremont-flag'):
  diffs += [('Actual proposed app layer draws one period24-star flag on the explicit roof-spar anchor, held at time0, confidence reconstructed(1), with no reported anchor/phase/date problems. Cloth is not in the hotel GLB.','fixed'),('The current shared SW-to-NE breeze presents cloth nearly edge-on to this camera; the source flag projects visibly left of its spar. A source-faithful pose/wind comparison remains open; no larger dimensions were invented to hide orientation disagreement.','open')]
  m['runtime_layer_diagnostic']={'animation_time':0,'prototype_only':True,'actual_app_module':True,'code_sha256':{n:sha(O/'renderers/web/js'/n) for n in ['flags.js','flag-anchors.js']},'receipt':'review/tremont-flag/flag-layer-diagnostic.json','standard_photo_match_acceptance':False}
 else:
  m['renderer_helpers_sha256']={n:sha(O/'tools'/n) for n in ['photo_match.mjs','photo_match_group.mjs']}
 m['differences']=[{'what':a,'status':b} for a,b in diffs];cam.with_suffix('.match.json').write_text(json.dumps(m,indent=2)+'\n');(d/'observations.md').write_text('# '+label+'\n\nActual saved output visually inspected. Verdict: **differs**.\n\n'+'\n'.join('- **'+b+'**: '+a for a,b in diffs)+'\n')
 rows.append({'label':label,'camera_sha256':sha(cam),'numeric_camera':{k:c[k] for k in ['image_px','principal_px','focal_px','eye','yaw_deg','sun_uvy']},'glb_sha256':m['glb_sha256'],'source_sha256':m['photo_sha256'],'render_sha256':sha(d/'render.png'),'match_file':str(cam.with_suffix('.match.json').relative_to(O)),'all_captures_exit_code':0,'verdict':'differs'})
assert len({r['camera_sha256'] for r in rows})==1 and len({r['source_sha256'] for r in rows})==1 and all(r['numeric_camera']==rows[0]['numeric_camera'] for r in rows)
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',19);small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
photo=Image.open(json.loads((O/'review/tremont/gifford-provisional.json').read_text())['photo']).convert('RGB')
images=[photo]+[Image.open(O/folder/'render.png').convert('RGB') for folder in ['review/tremont/before','review/tremont','review/tremont-flag']]
labels=['Source: N. Roswell Gifford / Chicagology; owner-approved attributed use']+[r['label'] for r in rows]
def panel(images,labels,path,footer):
 W,H=images[0].size;gap,top,bottom=24,66,38;im=Image.new('RGB',(W*len(images)+gap*(len(images)-1),H+top+bottom),'white');d=ImageDraw.Draw(im)
 for i,(p,l) in enumerate(zip(images,labels)):
  x=i*(W+gap);im.paste(p,(x,top));d.text((x+10,9),l,font=font,fill='#242424');d.text((x+10,36),'T-2385 prototype; verdict differs; same numeric camera',font=small,fill='#454545')
 d.text((10,H+top+9),footer,font=small,fill='#333333');im.save(path,quality=88)
panel(images[:3],labels[:3],O/'review/tremont/source-before-after.jpg','Identical standard renderer/camera/source before and after. No image-match acceptance or official build.')
panel(images,labels,O/'review/tremont-flag/source-before-after-and-flag.jpg','Fourth panel imports actual proposed flags.js runtime layer; held time0. Remaining wind/pose difference is explicit. No ticket closure.')
# Exact same pixel crop in every panel, enlarged for inspection only.
box=(875,175,1260,535);details=[im.crop(box).resize((1155,1080),Image.Resampling.NEAREST) for im in images]
panel(details,labels,O/'review/tremont-flag/source-before-after-and-flag-detail.jpg','All four panels crop identical source-camera pixel rectangle[875,175,1260,535],3x nearest enlargement; nothing locally moved.')
report=json.loads((O/'blender-previews-report.json').read_text());contracts={}
for name,r in report['models'].items():
 path=pathlib.Path(r['glb']);data=path.read_bytes();magic,v,n=struct.unpack_from('<4sII',data);assert magic==b'glTF' and v==2 and n==len(data);length,kind=struct.unpack_from('<II',data,12);g=json.loads(data[20:20+length]);assert kind==0x4e4f534a
 attrs=[p['attributes'] for mesh in g['meshes'] for p in mesh['primitives']];assert all(all(k in a for k in ['POSITION','NORMAL','TEXCOORD_0','_CONFIDENCE']) for a in attrs);assert not any('uri' in b for b in g.get('buffers',[]));assert not g.get('images')
 extras=[node.get('extras',{}) for node in g['nodes']];assert any(e.get('structure_id')==name for e in extras)
 assert r['legacy_default_unchanged'] and r['zero_area_polygons']==0
 contracts[name]={'glb_sha256':sha(path),'bytes':len(data),'triangles':r['triangles'],'normal_uv_confidence':True,'structure_phase_extras':extras,'no_degenerate_polygons':True,'actual_disabled_default_equal':True,'materials':r['materials']}
 if name=='tremont_house_1':assert any(m['name']=='gable_panel' and abs(m['roughness']-.95)<1e-6 for m in r['materials'])
(O/'glb-contract-inspection.json').write_text(json.dumps(contracts,indent=2)+'\n')
flag=json.loads((O/'review/tremont-flag/flag-layer-diagnostic.json').read_text());assert flag['drawn']==[{'id':'tremont_house_1','pattern':'us_flag_24_star','fly_m':1.85,'hoist_m':1.3,'confidence':1}];assert not flag['problems'] and flag['animation_time']==0
receipt={'state':'actual isolated canonical exports and reviewed source/previous/third/actual-app-flag comparisons; all differ','all_frozen_code_hashes_unchanged':True,'blender_version':report['blender_version'],'same_camera_source_numeric_proof':rows,'standard_before_after_helper_identical':True,'flag_uses_separate_actual_app_layer_diagnostic_helper':True,'flag_position_visual_inspection':'At roof-spar head, not hotel bounds centre; matches encoded head/foot envelope. Existing breeze makes cloth nearly edge-on, source pose unresolved.','actual_flag_grade':1,'original_tickets_closed':False,'all_cpu_browser_closed':True,'official_assets_manifests_written':False}
(O/'reviewed-preview-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('All frozen code verified, mesh/flag contracts pass; final review panels and honest differs records prepared')
