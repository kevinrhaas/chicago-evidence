#!/usr/bin/env python3
"""CPU regression checks for T-2376/T-2383/T-2385 pictured frame-tavern forms.

These inspect the real accumulator and opening kit, without Blender/exporting.
They protect opt-in geometry, materials and confidence, not image-match verdicts.
The same-camera preview receipts separately cover actual Blender/glTF treatment.
"""
from __future__ import annotations

import collections
import copy
import dataclasses
import json
import math
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "generators"))
sys.modules.setdefault("bpy", types.ModuleType("bpy"))
from archetypes import frame_tavern as builder  # noqa: E402
from archetypes.frame_tavern_params import (  # noqa: E402
    CONSUMED, FrameTavernParams, ParamError, from_phase,
)
from common.mesh import MeshBuilder  # noqa: E402


def record_params(structure_id, phase_id):
    record = json.loads((ROOT / "data/structures" / f"{structure_id}.json").read_text())
    phase = next(p for p in record["phases"] if p["id"] == phase_id)
    return record, phase, from_phase(phase, record)


def signature(result):
    mesh, materials = result
    return (mesh.verts, mesh.faces, mesh.conf, mesh.mat_index, mesh.named, materials)


def normal(mesh, face):
    a, b, c = (mesh.verts[i] for i in face[:3])
    u = [b[i] - a[i] for i in range(3)]
    v = [c[i] - a[i] for i in range(3)]
    return (u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0])


class PictureFeatures(unittest.TestCase):
    def setUp(self):
        # Preserve named-kit material specifications and original accumulator indices.
        self.emit = patch.object(MeshBuilder, "to_object", lambda b, mats=None: (b, mats))
        self.material = patch.object(builder, "simple_material", lambda n, *a, **kw: (n, a, kw))
        self.emit.start()
        self.material.start()
        self.addCleanup(self.emit.stop)
        self.addCleanup(self.material.stop)

    def assert_valid_mesh(self, mesh):
        self.assertTrue(all(math.isfinite(c) for v in mesh.verts for c in v))
        self.assertTrue(all(0 <= c <= 1 for c in mesh.conf))
        for face in mesh.faces:
            self.assertGreater(sum(c*c for c in normal(mesh, face)), 1e-14)

    def test_small_legacy_fixture_keeps_old_roof_and_empty_opt_ins(self):
        p = FrameTavernParams(12.0, 8.0, 2, 5.5)
        p.validate()
        self.assertEqual((p.eaves_bays, p.end_windows, p.gable_wall_cladding), ({}, (), False))
        explicit = dataclasses.replace(p, eaves_bays={}, end_windows=(),
            gable_wall_cladding=False, first_story_height_m=None, entry_raise_m=0,
            gable_lunette=False, flagstaff=False)
        with patch.object(builder, "_win", wraps=builder._win) as windows, \
             patch.object(builder, "_door", wraps=builder._door) as doors, \
             patch.object(MeshBuilder, "add_gable_roof", autospec=True,
                          side_effect=MeshBuilder.add_gable_roof) as roof:
            result = builder.build(p, "legacy_fixture__frame")
        self.assertEqual(len(windows.call_args_list), 18)
        self.assertEqual(len(doors.call_args_list), 1)
        self.assertEqual(roof.call_count, 1)
        self.assertEqual(signature(result), signature(builder.build(explicit, "legacy_fixture__frame")))
        # The unchanged common helper closes the default roof with roof-material
        # triangles. A new opt-in must not silently repaint every legacy building.
        mesh, _ = result
        triangles = [(f, m) for f, m in zip(mesh.faces, mesh.mat_index) if len(f) == 3]
        self.assertEqual(len(triangles), 2)
        self.assertTrue(all(m == builder.M_ROOF for _, m in triangles))
        self.assertFalse(any(m == builder.M_SHUTTER for m in mesh.mat_index))
        self.assert_valid_mesh(mesh)

    def test_gable_wall_cladding_both_axes_preserves_roof_planes(self):
        for width, depth in ((12., 8.), (8., 12.)):
            with self.subTest(width=width):
                p = FrameTavernParams(width, depth, 2, 5.5, gable_wall_cladding=True)
                p.validate()
                legacy, after = MeshBuilder("legacy_roof"), MeshBuilder("wall_gables")
                expected_ridge = legacy.add_gable_roof(0, 0, width, depth, 5.5,
                    p.roof_pitch_deg, .5, builder.M_ROOF, ridge_along_x=width >= depth)
                ridge = builder._wall_clad_gable_roof(after, p, width, depth, 5.5, .5,
                                                     ridge_along_x=width >= depth)
                self.assertEqual(ridge, expected_ridge)
                points = lambda mesh, face: frozenset(tuple(round(c, 9) for c in mesh.verts[i]) for i in face)
                self.assertEqual({points(legacy, f) for f in legacy.faces[:2]},
                                 {points(after, f) for f in after.faces[:2]})
                self.assertEqual(after.mat_index[:2], [builder.M_ROOF]*2)
                self.assertTrue(all(after.conf[i] == .5 for f in after.faces[:2] for i in f))
                gables = [f for f, m in zip(after.faces, after.mat_index) if len(f) == 3 and m == builder.M_WALL]
                self.assertEqual(len(gables), 2)
                axis = 0 if width >= depth else 1
                for face in gables:
                    outward = -1 if after.verts[face[0]][axis] < 0 else 1
                    self.assertGreater(normal(after, face)[axis] * outward, 0)
                self.assertTrue(all(m == builder.M_WALL for m in after.mat_index[2:]))
                self.assertTrue(all(after.conf[i] == 1 for f in after.faces[2:] for i in f))
                self.assertGreater(len(after.faces), 4)  # relief, not just a repaint
                self.assert_valid_mesh(after)

    def test_pictured_records_use_wall_gables_in_actual_build(self):
        for structure, phase in (("green_tree_tavern", "frame_1833"),
                                 ("sauganash_hotel", "frame_1831")):
            with self.subTest(structure=structure):
                _, _, p = record_params(structure, phase)
                self.assertTrue(p.gable_wall_cladding)
                with patch.object(builder, "_wall_clad_gable_roof",
                                  wraps=builder._wall_clad_gable_roof) as roof:
                    mesh, _ = builder.build(p, structure + "__" + phase)
                self.assertEqual(roof.call_count, 1)
                triangles = [m for f, m in zip(mesh.faces, mesh.mat_index) if len(f) == 3]
                self.assertGreaterEqual(triangles.count(builder.M_WALL), 2)

    def test_tremont_openings_shutters_and_raised_entries(self):
        _, _, p = record_params("tremont_house_1", "frame_1833")
        self.assertEqual((p.stories, p.elevation_scheme), (3, "corner_gable"))
        with patch.object(builder, "_win", wraps=builder._win) as windows, \
             patch.object(builder, "_door", wraps=builder._door) as doors, \
             patch.object(builder, "_corner_landing", wraps=builder._corner_landing) as landings, \
             patch.object(builder, "_corner_lunettes", wraps=builder._corner_lunettes) as lunettes:
            mesh, _ = builder.build(p, "tremont_house_1__frame_1833")
        self.assertEqual((landings.call_count, lunettes.call_count), (4, 1))
        self.assertEqual(len(windows.call_args_list), 44)
        self.assertEqual(len(doors.call_args_list), 4)
        by_face = collections.Counter(tuple(c.args[2:4]) for c in windows.call_args_list)
        self.assertEqual(by_face, {("x", 0.): 8, ("x", p.width_m): 8,
                                   ("y", 0.): 14, ("y", p.depth_m): 14})
        first = p.first_story_height_m
        self.assertIsNotNone(first)
        upper = (p.wall_height_m - first) / 2
        levels = sorted({round(c.args[7], 9) for c in windows.call_args_list})
        expected = (first*.3, first + upper*.3, first + upper + upper*.3)
        for actual, wanted in zip(levels, expected):
            self.assertAlmostEqual(actual, wanted)
        self.assertEqual(len(levels), 3)
        for call in doors.call_args_list:
            self.assertEqual(call.args[7], p.entry_raise_m)
        shutter_faces = [f for f, m in zip(mesh.faces, mesh.mat_index) if m == builder.M_SHUTTER]
        self.assertEqual(len(shutter_faces), 88*6)
        self.assertTrue(all(mesh.conf[i] == 1 for f in shutter_faces for i in f))
        bare, _ = builder.build(dataclasses.replace(p, shutters=None), "tremont_house_1__frame_1833")
        self.assertNotIn(builder.M_SHUTTER, bare.mat_index)
        self.assert_valid_mesh(mesh)

    def test_tremont_lunette_staff_and_stack_occurrences(self):
        _, _, p = record_params("tremont_house_1", "frame_1833")
        lunette = MeshBuilder("lunette")
        builder._corner_lunettes(lunette, p, p.width_m, p.depth_m, p.wall_height_m)
        glass = [f for f, m in zip(lunette.faces, lunette.mat_index) if m == builder.M_GLASS]
        self.assertTrue(glass)
        for face in glass:
            outward = -1 if lunette.verts[face[0]][0] < 0 else 1
            self.assertGreater(normal(lunette, face)[0] * outward, 0)
            self.assertTrue(all(lunette.conf[i] == 1 for i in face))
        self.assert_valid_mesh(lunette)
        with patch.object(builder, "_corner_roof_staff", wraps=builder._corner_roof_staff) as staff, \
             patch.object(builder, "_corner_slope_stacks", wraps=builder._corner_slope_stacks) as stacks:
            builder.build(p, "tremont_house_1__frame_1833")
        self.assertEqual((staff.call_count, stacks.call_count), (1, 1))
        ridge = staff.call_args.args[-1]
        spar = MeshBuilder("roof_spar")
        builder._corner_roof_staff(spar, p, p.width_m, p.depth_m, ridge)
        self.assertAlmostEqual(max(v[2] for v in spar.verts), ridge + p.flagstaff_height_m)
        self.assertTrue(all(c == 1 for c in spar.conf))
        self.assert_valid_mesh(spar)
        stack_mesh = MeshBuilder("stacks")
        builder._corner_slope_stacks(stack_mesh, p, p.width_m, p.depth_m, p.wall_height_m, builder.M_BRICK)
        self.assertEqual(len(stack_mesh.faces), 4*2*5)  # four capped shafts, undersides omitted
        self.assertTrue(all(m == builder.M_BRICK for m in stack_mesh.mat_index))
        self.assertTrue(all(c == 1 for c in stack_mesh.conf))
        self.assert_valid_mesh(stack_mesh)
        off = dataclasses.replace(p, flagstaff=False)
        self.assertEqual(signature(builder.build(off, "staff_off__frame")),
                         signature(builder.build(dataclasses.replace(off, flagstaff_height_m=7.), "staff_off__frame")))

    def test_green_tree_override_changes_only_named_eaves_face(self):
        _, _, p = record_params("green_tree_tavern", "frame_1833")
        self.assertEqual(p.eaves_bays, {"x_min": 7})
        captures = []
        # An attested fenestration fixture isolates the weaker override's tint.
        p = dataclasses.replace(p, confidence={**p.confidence, "fenestration": "attested",
            "elevation_scheme": "attested", "eaves_bays": "inferred"})
        for current in (p, dataclasses.replace(p, eaves_bays={})):
            with patch.object(builder, "_win", wraps=builder._win) as windows:
                builder.build(current, "green_tree_tavern__frame_1833")
            captures.append([c.args[2:] for c in windows.call_args_list])
        after, before = captures
        upper = lambda seq, plane: [c for c in seq if c[0] == "x" and c[1] == plane and c[5] > 2.5]
        self.assertEqual((len(upper(after, 0)), len(upper(before, 0))), (7, 6))
        self.assertEqual(upper(after, p.width_m), upper(before, p.width_m))
        self.assertEqual([c for c in after if c[0] == "y"], [c for c in before if c[0] == "y"])
        self.assertTrue(all(c[-1] == .5 for c in upper(after, 0)))
        self.assertTrue(all(c[-1] == 0 for c in upper(after, p.width_m)))

    def test_sauganash_only_states_three_main_end_sash(self):
        _, _, p = record_params("sauganash_hotel", "frame_1831")
        self.assertEqual(len(p.end_windows), 3)
        with patch.object(builder, "_end_windows", wraps=builder._end_windows) as ends:
            builder.build(p, "sauganash_hotel__frame_1831")
        self.assertEqual(ends.call_count, 1)
        with patch.object(builder, "_win", wraps=builder._win) as windows:
            mesh = MeshBuilder("end_sash")
            builder._end_windows(mesh, p, p.width_m, p.depth_m, p.wall_height_m)
        calls = windows.call_args_list
        self.assertEqual(len(calls), 3)
        self.assertEqual([c.args[3] for c in calls], [p.width_m, p.width_m, p.width_m + builder.ROOF_OVERHANG])
        self.assertTrue(all(c.args[2] == "x" and c.args[4] == 1 for c in calls))
        self.assertEqual(calls[-1].kwargs["skin"], 0.)
        self.assert_valid_mesh(mesh)
        blank = MeshBuilder("blank_end")
        builder._end_windows(blank, dataclasses.replace(p, end_windows=()), p.width_m, p.depth_m, p.wall_height_m)
        self.assertFalse(blank.verts)

    def test_opt_in_invalid_configurations_are_refused(self):
        _, _, corner = record_params("tremont_house_1", "frame_1833")
        _, _, green = record_params("green_tree_tavern", "frame_1833")
        _, _, hotel = record_params("sauganash_hotel", "frame_1831")
        cases = [(corner, d) for d in ({"width_m": 8.}, {"depth_m": 16.},
            {"entry_raise_m": float("nan")}, {"entry_raise_m": True},
            {"first_story_height_m": 4.}, {"first_story_height_m": True},
            {"flagstaff_height_m": float("inf")}, {"flagstaff_height_m": True},
            {"entry_raise_m": 1.21},
            {"flagstaff": 1}, {"gable_lunette": "true"}, {"roof_pitch_deg": 10.},
            {"chimneys": 3}, {"roof_type": "hip"}, {"log_wing": True})]
        cases += [(green, {"eaves_bays": d}) for d in ({"x_min": True}, {"y_min": 7}, {"x_min": 20})]
        cases += [(hotel, {"end_windows": d}) for d in (
            (("+z", .5, 4., .7, 1.),), (("+x", .5, 20., .7, 1.),),
            (("+x", .5, 5.5, .7, 1.),), (("+x", .5, float("nan"), .7, 1.),))]
        cases += [(hotel, {"gable_wall_cladding": v}) for v in (1, "true", None)]
        cases += [(FrameTavernParams(12., 8., 2, 5.5),
                   {"gable_wall_cladding": True, "roof_type": "hip"})]
        for p, changes in cases:
            with self.subTest(changes=changes), self.assertRaises(ParamError):
                dataclasses.replace(p, **changes).validate()

    def test_record_values_are_consumed_and_not_truthy_coerced(self):
        fields = {"eaves_bays", "end_windows", "first_story_height_m", "entry_raise_m",
                  "gable_lunette", "flagstaff", "flagstaff_height_m", "gable_wall_cladding"}
        self.assertTrue(fields <= CONSUMED)
        record, phase, _ = record_params("green_tree_tavern", "frame_1833")
        for value in (1, "false", None):
            bad = copy.deepcopy(phase)
            bad["form"]["gable_wall_cladding"]["value"] = value
            with self.subTest(value=value), self.assertRaises(ParamError):
                from_phase(bad, record)


if __name__ == "__main__":
    unittest.main()
