import pathlib,json,hashlib,re,shutil,struct
P=pathlib.Path(__file__).parent;O=P/'preview-root';B=pathlib.Path('/tmp/chicago-next-model/frame_tavern-combined')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=json.loads((O/'blender-previews-report.json').read_text());proof=json.loads((O/'same-camera-before-after-proof.json').read_text());proof['models']=[r for r in proof['models'] if r['target']!='tremont'];contracts={}
for row in proof['models']:
 target=row['target'];folder=O/'review'/target;cam=O/row['after_camera'];record=cam.with_suffix('.match.json');m=json.loads(record.read_text());b=json.loads((O/row['before_camera']).with_suffix('.match.json').read_text())
 assert (O/row['before_camera']).read_bytes()==cam.read_bytes();assert m['camera_sha256']==b['camera_sha256'];assert m['photo_sha256']==b['photo_sha256']
 model=report['models'][row['structure_id']];row['after_capture_glb_sha256']=model['glb_sha256'];assert m['glb_sha256']==model['glb_sha256']
 m['verdict']='differs';m['differences'].insert(0,{'what':'Visible main-gable triangle now continues the existing wall finish and horizontal clapboard courses instead of using roof covering material. Roof planes/dimensions/pitch remain unchanged; concealed opposite-end treatment is reconstructed.','status':'fixed'})
 # Earlier copied first-stage notes refer to gables retaining treatment; clarify the actual scope.
 for d in m['differences']:
  d['what']=d['what'].replace('and both gables retain their previous treatment.','while main-block triangular gable cladding is corrected in this follow-up.')
 record.write_text(json.dumps(m,indent=2)+'\n')
 raw=pathlib.Path(re.search(r'  (/tmp/photo-match-[^\n]+-render.png)',(folder/'photo-match.log').read_text()).group(1));shutil.copy2(raw,folder/'proposal-render.png')
 (folder/'observations.md').write_text('# '+target+' — main-gable follow-up actual review\n\nSaved source/proposal comparison visually inspected. Verdict **differs**.\n\n'+'\n'.join('- **'+d['status']+'**: '+d['what'] for d in m['differences'])+'\n')
proof['state']='Two main-gable follow-up comparisons complete; same-camera proof and final panels being prepared; no acceptance';proof['canonical_after_producer']='emit.emit_structure with structure_id__phase_id seed';proof['all_cpu_browser_work_finished']=True
proof.pop('superseded_outputs',None)
(O/'same-camera-before-after-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
for id,row in report['models'].items():
 p=pathlib.Path(row['glb']);data=p.read_bytes();magic,version,length=struct.unpack_from('<4sII',data);assert magic==b'glTF' and version==2 and length==len(data);n,kind=struct.unpack_from('<II',data,12);g=json.loads(data[20:20+n]);assert kind==0x4e4f534a
 attrs=[p['attributes'] for mesh in g['meshes'] for p in mesh['primitives']];assert all(all(k in a for k in ['POSITION','NORMAL','TEXCOORD_0','_CONFIDENCE']) for a in attrs);assert not any('uri' in b for b in g.get('buffers',[]));assert not g.get('images')
 extras=[node.get('extras',{}) for node in g['nodes']];assert any(e.get('structure_id')==id for e in extras),extras
 contracts[id]={'glb_sha256':sha(p),'glb_bytes':len(data),'version':version,'all_primitives_normal_uv_confidence':True,'extras':extras,'zero_area_polygons':row['zero_area_polygons'],'actual_default_unchanged':row['legacy_default_unchanged']}
(O/'glb-contract-inspection.json').write_text(json.dumps(contracts,indent=2)+'\n')
# Reuse exact panel code with only target count/status wording adjusted.
s=(B/'make_same_camera_panels.py').read_text().replace('all3 committed','both committed').replace('Prepared3 review panels','Prepared2 review panels')
(P/'make_same_camera_panels.py').write_text(s)
print('Actual records differ; copied immutable committed baseline/camera verified; all3 GLB contracts pass')
