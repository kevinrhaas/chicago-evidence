import pathlib,shutil,json,difflib
P=pathlib.Path('/tmp/chicago-next-model/frame-gable-cladding');B=pathlib.Path('/tmp/chicago-next-model/frame_tavern-combined')
for name in ('frame_tavern.py','frame_tavern_params.py'):
 rel=pathlib.Path('generators/archetypes')/name
 for folder in ('baseline','proposed'):
  dest=P/folder/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(B/'proposed'/rel,dest)
(P/'proposed/generators/archetypes/__init__.py').touch()
for name in ('green_tree_tavern','sauganash_hotel','tremont_house_1'):
 rel=pathlib.Path('data/structures')/(name+'.json')
 for folder in ('baseline','proposed'):
  dest=P/folder/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(B/'proposed'/rel,dest)
f=P/'proposed/generators/archetypes/frame_tavern_params.py';s=f.read_text()
s=s.replace('"flagstaff", "flagstaff_height_m",','"flagstaff", "flagstaff_height_m", "gable_wall_cladding",')
s=s.replace('    # appearance\n','    # Main-block end triangles continue the wall cladding (T-2376/T-2383).\n    # False retains every legacy roof-material gable; no subsidiary roofs change.\n    gable_wall_cladding: bool = False\n\n    # appearance\n')
s=s.replace('        if self.roof_type not in ROOF_TYPES:', '        if not isinstance(self.gable_wall_cladding, bool):\n            raise ParamError("gable_wall_cladding must be a boolean")\n        if self.gable_wall_cladding and self.roof_type != "gable":\n            raise ParamError("gable_wall_cladding requires a gable roof")\n        if self.roof_type not in ROOF_TYPES:')
s=s.replace('        paint=str(val("paint", "unpainted")),','        paint=str(val("paint", "unpainted")),\n        gable_wall_cladding=val("gable_wall_cladding", False),')
f.write_text(s)
f=P/'proposed/generators/archetypes/frame_tavern.py';s=f.read_text()
s=s.replace('    else:\n        ridge_z = b.add_gable_roof(0, 0, w, d, wall_z, params.roof_pitch_deg, c_roof,','    elif params.gable_wall_cladding:\n        ridge_z = _wall_clad_gable_roof(\n            b, params, w, d, wall_z, c_roof, ridge_along_x=(w >= d))\n    else:\n        ridge_z = b.add_gable_roof(0, 0, w, d, wall_z, params.roof_pitch_deg, c_roof,',1)
start=s.index('    """The same wide-axis gable, with wall-coloured/coursed end triangles.',s.index('def _corner_gable_roof'))
end=s.index('\n\ndef _corner_wall_box',start)
old=s[start:end]
body=old[old.index('    x0,x1'):]
body=body.replace('    x0,x1,y0,y1 =','    # Work in ridge/run coordinates, swapping only for a deep-axis ridge.\n    if not ridge_along_x:\n        w, d = d, w\n\n    def poly(points, confidence, material):\n        if not ridge_along_x:\n            # Swapping x/y reverses handedness; reverse winding back outward.\n            points = [(y, x, z) for x, y, z in reversed(points)]\n        b.add_poly(points, confidence, material)\n\n    x0,x1,y0,y1 =')
body=body.replace('b.add_poly(', 'poly(')
# The local dispatch must call the builder, not recurse.
body=body.replace('        poly(points, confidence, material)','        b.add_poly(points, confidence, material)')
new='''    """Keep Tremont's existing wide-axis treatment byte-for-byte in geometry."""
    return _wall_clad_gable_roof(b, params, w, d, wall_z, conf,
                                ridge_along_x=True)


def _wall_clad_gable_roof(b: MeshBuilder, params: FrameTavernParams,
                         w: float, d: float, wall_z: float, conf: float,
                         ridge_along_x: bool) -> float:
    """Main roof planes unchanged; wall finish/course relief on end triangles.

    Pictured clapboard informs the opt-in, while course dimensions and unseen
    opposite triangles remain reconstructed. Subsidiary roofs are separate.
    """
'''+body
s=s[:start]+new+s[end:];f.write_text(s)
for name,source in [('green_tree_tavern','andreas_1884_green_tree_hotel_plate'),('sauganash_hotel','andreas_1884_sauganash_hotel_plate')]:
 f=P/'proposed/data/structures'/f'{name}.json';r=json.loads(f.read_text());phase=next(q for q in r['phases'] if q['id']==('frame_1831' if name=='sauganash_hotel' else 'frame_1833'))
 phase['form']['gable_wall_cladding']={'value':True,'confidence':'reconstructed','sources':[source],'note':'The pictured main gable continues the framed wall\u2019s horizontal clapboard above the eaves; it is not roof covering. The main-block end triangles now use the existing wall finish and existing reconstructed siding course stock. This switch covers both main gables for a closed model: continuing the pictured finish around the unseen/opposite end is reconstructed, not independently attested. Existing footprint, placement, eave/ridge geometry, roof pitch and covering, course stock and all subsidiary roofs remain unchanged. It does not settle the provisional camera or any remaining opening, roof, wing or grouped-annex differences.'}
 f.write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
patch=''
for rel in [pathlib.Path('generators/archetypes')/n for n in ('frame_tavern.py','frame_tavern_params.py')]+[pathlib.Path('data/structures')/(n+'.json') for n in ('green_tree_tavern','sauganash_hotel')]:
 patch+=''.join(difflib.unified_diff((P/'baseline'/rel).read_text().splitlines(True),(P/'proposed'/rel).read_text().splitlines(True),fromfile='a/chicago/4d/'+str(rel),tofile='b/chicago/4d/'+str(rel)))
(P/'incremental.patch').write_text(patch)
print('Prepared four-file incremental main-gable cladding patch')
