import pathlib,sys,types,importlib.util,dataclasses,json,math,copy
P=pathlib.Path(__file__).parent;R=pathlib.Path('/workspace/chicago/chicago/4d');sys.path[:0]=[str(P/'proposed/generators'),str(R/'generators')]
sys.modules.setdefault('bpy',types.ModuleType('bpy'))
from archetypes import frame_tavern as new,frame_tavern_params as par
from common.mesh import MeshBuilder

def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m
old=load('gable_before_builder',P/'baseline/generators/archetypes/frame_tavern.py');op=load('gable_before_params',P/'baseline/generators/archetypes/frame_tavern_params.py')
MeshBuilder.to_object=lambda self,mats=None:(self,list(mats or []))
for m in (old,new):m.simple_material=lambda name,*a,**kw:(name,a,kw)
def sig(res):
 b,m=res;return b.verts,b.faces,b.conf,b.mat_index,b.named,m
count=0
for f in sorted((R/'data/structures').glob('*.json')):
 r=json.loads(f.read_text())
 if r.get('archetype')!='frame_tavern':continue
 if (P/'baseline/data/structures'/f.name).exists():r=json.loads((P/'baseline/data/structures'/f.name).read_text())
 for ph in r['phases']:
  a=op.from_phase(ph,r);b=par.from_phase(ph,r);d=dataclasses.asdict(b);assert d.pop('gable_wall_cladding') is False;assert d==dataclasses.asdict(a)
  assert sig(old.build(a,r['id']+'__'+ph['id']))==sig(new.build(b,r['id']+'__'+ph['id'])),(r['id'],ph['id']);count+=1
print('PASS all',count,'record-phase accumulated legacy geometry/material/confidence exact, including current Tremont')
for id,phase in [('green_tree_tavern','frame_1833'),('sauganash_hotel','frame_1831')]:
 r=json.loads((P/'proposed/data/structures'/f'{id}.json').read_text());ph=next(q for q in r['phases'] if q['id']==phase);p=par.from_phase(ph,r);assert p.gable_wall_cladding and 'gable_wall_cladding' in par.CONSUMED
 before=json.loads((P/'baseline/data/structures'/f'{id}.json').read_text());clean=copy.deepcopy(r);next(q for q in clean['phases'] if q['id']==phase)['form'].pop('gable_wall_cladding');assert clean==before
 import jsonschema;jsonschema.validate(r,json.loads((R/'data/structures.schema.json').read_text()))
 a=MeshBuilder('oldroof');a.add_gable_roof(0,0,p.width_m,p.depth_m,p.wall_height_m,p.roof_pitch_deg,.5,new.M_ROOF,ridge_along_x=p.width_m>=p.depth_m)
 b=MeshBuilder('newroof');ridge=new._wall_clad_gable_roof(b,p,p.width_m,p.depth_m,p.wall_height_m,.5,ridge_along_x=p.width_m>=p.depth_m)
 points=lambda m,f:frozenset(tuple(round(c,8) for c in m.verts[i]) for i in f)
 assert {points(a,f) for f in a.faces[:2]}=={points(b,f) for f in b.faces[:2]},id
 assert b.mat_index[:2]==[new.M_ROOF]*2
 tri=[f for f,mat in zip(b.faces,b.mat_index) if len(f)==3 and mat==new.M_WALL];assert len(tri)==2
 axis=0 if p.width_m>=p.depth_m else 1
 for f in tri:
  v=[b.verts[i] for i in f];u=[v[1][i]-v[0][i] for i in range(3)];t=[v[2][i]-v[0][i] for i in range(3)];n=(u[1]*t[2]-u[2]*t[1],u[2]*t[0]-u[0]*t[2],u[0]*t[1]-u[1]*t[0]);out=-1 if v[0][axis]<0 else 1;assert n[axis]*out>0
  assert all(b.conf[i]==1 for i in f)
 assert len(b.faces)>4 and all(math.isfinite(c) for v in b.verts for c in v)
 for bad in (1,'true',None,{}):
  try:dataclasses.replace(p,gable_wall_cladding=bad).validate()
  except par.ParamError:pass
  else:raise AssertionError('nonboolean accepted')
 try:dataclasses.replace(p,roof_type='hip').validate()
 except par.ParamError:pass
 else:raise AssertionError('unsupported roof accepted')
 print('PASS',id,'isolated record delta/schema; unchanged roof planes; two outward wall gables with reconstructed confidence/courses; strict opt-in validation')
print('All focused main-gable checks pass. No official writes.')
