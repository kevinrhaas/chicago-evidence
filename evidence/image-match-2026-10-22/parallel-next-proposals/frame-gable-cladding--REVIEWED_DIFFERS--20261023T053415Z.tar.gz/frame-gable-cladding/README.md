# Main-block gable cladding follow-up

Incremental proposal against `/tmp/chicago-next-model/frame_tavern-combined/proposed` and the parent's applied five-file proposal. `incremental.patch` changes only two module files and GreenTree/Sauganash structure records. Append `liberty.md` separately under the next appropriate ledger entry. No tracked changes or official outputs.

Strict boolean `gable_wall_cladding=False` is consumed and resolved without truthy coercion. True requires a gable roof. The generic helper swaps ridge/run coordinates with corrected outward winding for a deep-axis roof, while retaining the existing Tremont roof's exact geometry. Only main-block end triangles receive wall material/coursed relief; subsidiary roofs unchanged. Both sides carry reconstructed confidence. Roof planes, footprint, placement, pitch, dimensions and established finishes unchanged.

`check.py`/`check.log`: 24 record-phase default accumulated geometry/material/confidence exact (all 23 current assets plus unregistered Sauganash log phase), including current Tremont; schema and isolated record deltas pass; both-axis unchanged slope planes, outward triangular normals and strict boolean/roof validation pass. Four-file `git apply --check` passed against parent checkout before adoption.

All 23 frame_tavern master recipes still require one official family refresh because module bytes/resolved fields change; no new common-module edits or family versions. Parent owns canonical official producer/manifests/derivatives/licence/grade sidecars, app/cards/fullgate, PR and merge.

`preview-root/` is isolated provisional output only. Baseline views are pinned committed575 assets captured with exactly the same cameras as the proposed views. Prior combined package and evidence remain immutable. Original tickets remain open.

Completed: all3 canonical pinned exports passed, both refreshed same-camera source/before/after panels visually inspected, contracts/defaults pass. Current Tremont GLB unchanged byte-for-byte. Final handoff and checkpoint record reviewed artifacts; all CPU/browser closed.
