#!/usr/bin/env bash
set -euo pipefail
if [ "${C4D_FAMILY_PARENT_RELEASED:-0}" != "1" ]; then
  echo 'Wait for parent local-gate release before running Blender.' >&2
  exit 2
fi
FAMILY_ROOT=/tmp/chicago-next-model/frame-gable-cladding
mkdir -p "$FAMILY_ROOT/preview-root/blender-config"
BLENDER_USER_CONFIG="$FAMILY_ROOT/preview-root/blender-config" /workspace/shared/blender-dl/blender-4.5.3-linux-x64/blender -b -noaudio --factory-startup --python-exit-code 1 --python "$FAMILY_ROOT/export_previews.py" > "$FAMILY_ROOT/preview-root/blender-previews.log" 2>&1
