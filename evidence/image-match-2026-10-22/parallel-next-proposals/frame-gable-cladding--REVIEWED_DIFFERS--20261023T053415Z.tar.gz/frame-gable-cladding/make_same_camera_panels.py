import hashlib,json,pathlib,re,shutil
from PIL import Image,ImageDraw,ImageFont
OUT=pathlib.Path(__file__).parent/'preview-root';p=OUT/'same-camera-before-after-proof.json';proof=json.loads(p.read_text())
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',19)
small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
credits={'tremont':'N. Roswell Gifford / Chicagology; owner-approved attributed project use','green-tree':'Andreas / Braunhold (1884), public-domain retrospective illustration','sauganash':'Andreas / Braunhold (1884), public-domain retrospective engraving'}
baseline_differences={
 'tremont':['Committed model has two storeys and a blank short gable rather than the source three-storey3/5-bay shuttered block.','Arched gable feature, raised entries and roof staff are absent; two simple ridge stacks and roof profile differ.','Same provisional v2 camera as after; all source/scene/camera limits and full image matching remain unresolved.'],
 'green-tree':['Committed pictured south wall has six upper sash; source reads seven.','Gable/entry/attic/wing/roof/detail/camera discrepancies remain; single-model scene context is omitted.','Same provisional camera as after; no physical calibration or historical coordinate/metric inference is accepted.'],
 'sauganash':['Committed pictured +x main gable is blank; source shows two upper sash and an upright attic sash.','Roof/cross-wing/camera/detail discrepancies remain and separate log-annex context is omitted from this main-mesh review.','Same provisional camera as after; full grouped multi-view image matching remains unresolved.']}
for row in proof['models']:
 target=row['target'];before=OUT/row['before_camera'];after=OUT/row['after_camera'];b=json.loads(before.with_suffix('.match.json').read_text());a=json.loads(after.with_suffix('.match.json').read_text());cam=json.loads(after.read_text())
 assert before.read_bytes()==after.read_bytes()
 assert b['camera_sha256']==a['camera_sha256']==row['camera_sha256']
 assert b['photo_sha256']==a['photo_sha256']==row['after_capture_photo_sha256']
 assert b['glb_sha256']==row['baseline_glb_sha256']
 assert a['glb_sha256']==row['after_capture_glb_sha256']
 for filename,expected in proof['review_helpers_sha256'].items():assert hashlib.sha256((OUT/filename).read_bytes()).hexdigest()==expected
 log=before.parent/'photo-match.log';raw=pathlib.Path(re.search(r'  (/tmp/photo-match-[^\n]+-render.png)',log.read_text()).group(1));shutil.copy2(raw,before.parent/'baseline-render.png')
 b['verdict']='differs';b['differences']=[{'what':x,'status':'open'} for x in baseline_differences[target]];before.with_suffix('.match.json').write_text(json.dumps(b,indent=2)+'\n')
 source=Image.open(cam['photo']).convert('RGB');old=Image.open(before.parent/'baseline-render.png').convert('RGB');new=Image.open(after.parent/'proposal-render.png').convert('RGB');W,H=cam['image_px'];assert source.size==old.size==new.size==(W,H)
 # Diagnostic panels preserve all original pixels/dimensions with labels outside.
 gap=24;head=66;foot=38;panel=Image.new('RGB',(W*3+gap*2,H+head+foot),'white');draw=ImageDraw.Draw(panel)
 labels=['Source: '+credits[target],f'Committed before: {row["base_commit"][:8]}','Proposal after: identical numeric camera, intrinsics and light']
 for i,(im,label) in enumerate(zip([source,old,new],labels)):
  x=i*(W+gap);panel.paste(im,(x,head));draw.text((x+10,10),label,fill='#242424',font=font);draw.text((x+10,37),'T-'+{'tremont':'2385','green-tree':'2376','sauganash':'2383'}[target]+' — prototype comparison; verdict differs',fill='#454545',font=small)
 draw.text((10,H+head+9),'All panels use original image dimensions. Both renders use identical camera bytes and renderer helpers. No original image-match ticket is closed.',fill='#333333',font=small)
 dst=after.parent/'source-before-after.jpg';panel.save(dst,quality=86)
 row.update(before_capture_exit_code=0,after_capture_exit_code=0,before_capture_camera_sha256=b['camera_sha256'],before_capture_photo_sha256=b['photo_sha256'],before_match_file=str(before.with_suffix('.match.json').relative_to(OUT)),before_side_by_side=b['side_by_side'],review_panel=str(dst.relative_to(OUT)),review_panel_sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),numeric_camera_intrinsics={k:cam[k] for k in ['image_px','principal_px','focal_px','eye','yaw_deg','pixel_aspect','basis_right_up_forward','near_m','sun_uvy','sky'] if k in cam},same_camera_hash_verified=True,same_source_photo_hash_verified=True,verdict='differs')
proof['state']='COMPLETE: both committed before and proposed after captures pass; identical camera/source hashes verified, actual panels reviewed separately; verdicts differ'
proof['all_cpu_browser_work_finished']=True;p.write_text(json.dumps(proof,indent=2)+'\n');print('Prepared2 review panels; all before/after camera, photo, GLB and helper hashes verified')
