#!/usr/bin/env python3
"""Adopt the two verified Gale1902 hotel sources, preserving unrelated current work.

Default materializes review files only. --apply writes a previously reviewed plan
after checking every current target, frozen payload and shared publication proof.
"""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
PLAN = HERE / 'source-adoption-plan.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def at(obj, fields):
    for key in fields:
        obj = obj[key]
    return obj


def atomic(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name('.' + path.name + '.gale-source.tmp')
    try:
        tmp.write_bytes(data)
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    root = args.repo.resolve()
    spec_path = HERE / 'source-update-operations.json'
    spec = json.loads(spec_path.read_text())
    for item in spec['required_publication_proof']:
        if sha((root / item['path']).read_bytes()) != item['sha256']:
            raise SystemExit('REFUSED: shared1902title/copyright proof drift')
    if args.apply:
        plan = json.loads(PLAN.read_text())
        if plan['repo'] != str(root) or plan['operation_spec_sha256'] != sha(spec_path.read_bytes()):
            raise SystemExit('REFUSED: plan root/spec differs; review again')
        for item in plan['files']:
            target = root / item['path']
            current = sha(target.read_bytes()) if target.exists() else None
            if current != item['old_sha256']:
                raise SystemExit(f"REFUSED: current target drift {target}; review again")
            if sha((HERE / item['review_path']).read_bytes()) != item['new_sha256']:
                raise SystemExit('REFUSED: reviewed output drift')
        for op in spec['operations']:
            if op['kind'] == 'new' and sha((HERE / op['payload']).read_bytes()) != op['sha256']:
                raise SystemExit('REFUSED: frozen payload drift')
        written = []
        try:
            for item in plan['files']:
                target = root / item['path']
                backup = HERE / 'apply-backup' / item['path']
                if target.exists():
                    atomic(backup, target.read_bytes())
                atomic(target, (HERE / item['review_path']).read_bytes())
                written.append(item)
        except BaseException:
            for item in reversed(written):
                target = root / item['path']
                backup = HERE / 'apply-backup' / item['path']
                if item['old_sha256'] is None:
                    target.unlink(missing_ok=True)
                else:
                    atomic(target, backup.read_bytes())
            raise
        (HERE / 'source-apply-receipt.json').write_text(json.dumps({'applied': True, 'files': plan['files']}, indent=2) + '\n')
        print(f"APPLIED {len(plan['files'])} reviewed source/note/evidence files; official bake, compilation and app QA remain parent work")
        return
    original = {}
    result = {}
    for op in spec['operations']:
        rel = op['path']
        if rel not in original:
            path = root / rel
            original[rel] = path.read_bytes() if path.exists() else None
            result[rel] = original[rel]
        data = result[rel]
        kind = op['kind']
        if kind == 'new':
            payload = (HERE / op['payload']).read_bytes()
            if sha(payload) != op['sha256'] or data not in (None, payload):
                raise SystemExit(f'REFUSED: new-file payload/target drift {rel}')
            result[rel] = payload
        elif kind == 'json_field':
            obj = json.loads(data)
            current = at(obj, op['field'])
            if current == op['new']:
                continue
            if current != op['old']:
                raise SystemExit(f"REFUSED: exact field drift {rel} {op['field']}")
            before = copy.deepcopy(obj)
            if op['field']:
                at(obj, op['field'][:-1])[op['field'][-1]] = op['new']
                # A field replacement must preserve every unrelated value.
                audit = copy.deepcopy(obj)
                at(audit, op['field'][:-1])[op['field'][-1]] = op['old']
                assert audit == before
            else:
                obj = op['new']
            result[rel] = (json.dumps(obj, indent=2, ensure_ascii=False) + '\n').encode()
        elif kind == 'text_replace':
            text = data.decode()
            if op['new'] in text and op['old'] not in text:
                continue
            if text.count(op['old']) != 1:
                raise SystemExit(f'REFUSED: exact text drift {rel}')
            result[rel] = text.replace(op['old'], op['new']).encode()
        elif kind == 'append':
            addition = op['text'].encode()
            if addition not in data:
                result[rel] = data + addition
        else:
            raise SystemExit('REFUSED: unknown operation kind')
    files = []
    for rel, data in result.items():
        if data == original[rel]:
            continue
        review = HERE / 'review-tree' / rel
        atomic(review, data)
        files.append({'path': rel, 'old_sha256': sha(original[rel]) if original[rel] is not None else None,
                      'new_sha256': sha(data), 'review_path': str(review.relative_to(HERE)), 'bytes': len(data)})
    plan = {'repo': str(root), 'operation_spec_sha256': sha(spec_path.read_bytes()), 'files': files,
            'source_metadata_only': True, 'geometry_values_grades_positions_dates_unchanged': True,
            'canonical_writes': False, 'official_gate_and_app_qa': 'UNRUN'}
    PLAN.write_text(json.dumps(plan, indent=2) + '\n')
    print(f'REVIEW ONLY: {len(files)} files; no canonical writes. Inspect source-adoption-plan.json and review-tree, then --apply.')


if __name__ == '__main__':
    main()
