from pathlib import Path
import json,hashlib,shutil
HERE=Path(__file__).resolve().parent
ROOT=Path('/workspace/chicago')
OPS=[]
def jfield(rel,path,new):
 obj=json.loads((ROOT/rel).read_text());cur=obj
 for k in path:cur=cur[k]
 OPS.append({'kind':'json_field','path':rel,'field':path,'old':cur,'new':new})
def textreplace(rel,old,new):
 assert (ROOT/rel).read_text().count(old)==1,(rel,old)
 OPS.append({'kind':'text_replace','path':rel,'old':old,'new':new})
def append(rel,text):
 assert text not in (ROOT/rel).read_text()
 OPS.append({'kind':'append','path':rel,'text':text})
def newfile(rel,data):
 target=HERE/'payload'/rel;target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(data if isinstance(data,bytes) else data.encode())
 OPS.append({'kind':'new','path':rel,'payload':str(target.relative_to(HERE)),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
credit='W. E. S. Trowbridge; in Edwin O. Gale (1902)'
proof=[]
for name,n in [('gale-title-n12.jpg',12),('gale-copyright-n13.jpg',13)]:
 p=ROOT/'chicago/4d/data/sources/assets/trowbridge_first_jail_gale_1902'/name
 dest=HERE/'publication-proof'/name;dest.parent.mkdir(exist_ok=True);shutil.copy2(p,dest)
 proof.append({'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'url':f'https://archive.org/download/reminiscencesofe00ingale/page/n{n}_large.jpg','actual_image_read':True})
for sid,n,page,title in [
 ('trowbridge_sauganash_hotel',49,31,"Mark Beaubien's Tavern, the Sauganash, in 1835"),
 ('trowbridge_green_tree_1902',55,35,'The Green Tree Tavern in 1835')]:
 rel=f'chicago/4d/data/sources/{sid}.json';r=json.loads((ROOT/rel).read_text());old=dict(r)
 plateurl=f'https://archive.org/download/reminiscencesofe00ingale/page/n{n}_large.jpg'
 pageurl=f'https://archive.org/details/reminiscencesofe00ingale/page/n{n}/mode/1up'
 r.update({'citation':f'{title} (published 1902). W. E. S. Trowbridge, in Edwin O. Gale, Reminiscences of Early Chicago and Vicinity. Chicago: Fleming H. Revell Company, 1902; plate facing printed p. {page}.',
 'author':credit,'date':'1902 (verified publication)','describes_date':'1835 as captioned; retrospective depiction, not a dated survey',
 'repository':'Internet Archive, Edwin O. Gale, Reminiscences of Early Chicago and Vicinity (1902), item reminiscencesofe00ingale',
 'url':pageurl,'archived_url':plateurl,
 'locator':f'Actual full plate at Internet Archive page/n{n}, facing printed p. {page}. Title page n12 credits ILLUSTRATED BY W. E. S. TROWBRIDGE and bears MCMII; copyright page n13 reads COPYRIGHT, 1902, BY FLEMING H. REVELL COMPANY / October.',
 'rights_status':'public_domain',
 'rights_note':'The exact artwork was actually inspected in the US-published 1902 volume together with its title and copyright pages. The underlying 1902 illustration is public domain in the United States by publication age. This verified publication supersedes the old artwork-level check_required hold; it does not assert an item-specific licence for a separately offered modern stock reproduction, establish original colours, or promote this retrospective drawing to an independent 1835 witness.',
 'note':f'VERIFIED 1902 PUBLICATION (T-3055): the exact full composition was directly inspected at Internet Archive n{n}, facing printed p. {page}, captioned "{title}." The actual title page names W. E. S. Trowbridge as illustrator and the actual copyright page establishes 1902 US publication. The held Chicagology reproduction matches the building, annex/shed, people, animals and surrounding composition. The 1835 caption is a retrospective depicted-state label, not proof of each feature on 1 July 1835. Tier5, source dependence, metric limits, and existing inferred/reconstructed feature grades remain unchanged. The old publication/rights uncertainty below is superseded by these independently verified pages. Modern reproduction-specific terms remain separate.\n\nHISTORICAL PRE-VERIFICATION SOURCE NOTE:\n'+old['note']})
 if sid=='trowbridge_sauganash_hotel':
  r['what_it_does_not_supply']=[("a drawing creation day or an independently observed1835 state; verified 1902 publication does not date every pictured fitting" if 'its own date' in s else s) for s in old['what_it_does_not_supply']]
 jfield(rel,[],r)
 plate=HERE/f'gale-n{n}.jpg';data=plate.read_bytes();assetrel=f'chicago/4d/data/sources/assets/{sid}'
 newfile(assetrel+f'/gale-n{n}.jpg',data)
 manifest={'source_id':sid,'publication':'Gale 1902, illustrated by W. E. S. Trowbridge','plate':{'path':f'gale-n{n}.jpg','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'url':plateurl,'caption':title,'printed_page_facing':page,'actual_image_read':True},'shared_publication_proof':proof,'rights':'Public domain by independently verified 1902 US publication; no modernstockreproductionlicenceclaimed','limits':'Retrospective 1835 caption; not dated July 1835 geometry, colours or metric dimensions.'}
 newfile(assetrel+'/evidence-files.json',json.dumps(manifest,indent=2)+'\n')
 newfile(assetrel+'/README.md',f'# {title} — verified 1902 publication\n\nCredit: **W. E. S. Trowbridge**, in Edwin O. Gale, *Reminiscences of Early Chicago and Vicinity* (Fleming H. Revell Company, 1902), plate facing printed p. {page}. [Actual plate]({pageurl}).\n\nThe JPEG is an unmodified original page scan, not a crop or a new recreation. Exact URL, bytes and SHA256 are in evidence-files.json. The actual title and copyright images already held under `../trowbridge_first_jail_gale_1902/` establish the independent 1902 US publication; this manifest pins their hashes. Underlying artwork is public domain by age. A modern stock agency\'s offered reproduction is a separate item, and no stock agency licence is claimed.\n\nThe caption names 1835 retrospectively. It does not establish each fitting on 1 July 1835 or supply colours, dimensions or independent corroboration of earlier dependent views. No image match, geometry change or confidence promotion follows from this source verification.\n')
 # Visitors should see the exact citation/source ID through the existing picture join.
 stid='sauganash_hotel' if 'sauganash' in sid else 'green_tree_tavern'
 srel=f'chicago/4d/data/structures/{stid}.json';st=json.loads((ROOT/srel).read_text())
 prefix=f'VERIFIED 1902 PICTURE SOURCE: {sid} is W. E. S. Trowbridge’s "{title}", independently verified in Edwin O. Gale’s 1902 book, facing printed p. {page}. The artwork’s earlier rights hold is superseded by the actual title/copyright publication evidence. Its 1835 caption is retrospective and does not date every feature to 1 July 1835. '
 if stid=='sauganash_hotel':prefix+='Bright-blue shutters remain grounded in Wau-Bun’s separate recollection of 1831; louvred leaf detail remains inferred from this later drawing. The monochrome Andreas plate cannot independently establish colour. '
 prefix+='Original picture comparisons remain open; no dimensions, placement, geometry or confidence values change with this source verification.\n\nPRIOR RESEARCH RECORD:\n'
 jfield(srel,['research_note'],prefix+st['research_note'])
# Correct only the stale rights clause in the otherwise historical cross-wing reasoning.
srel='chicago/4d/data/structures/sauganash_hotel.json';st=json.loads((ROOT/srel).read_text());pi=next(i for i,p in enumerate(st['phases']) if p['id']=='frame_1831');note=st['phases'][pi]['form']['cross_wing']['note']
old=" — and trowbridge_sauganash_hotel's rights are unresolved, so citing it here would put a mesh on a source nobody has checked for nothing gained."
assert old in note
jfield(srel,['phases',pi,'form','cross_wing','note'],note.replace(old,". The earlier separate rights concern is now superseded by verified 1902 publication, but the dependence argument still applies: a later copy is not independent corroboration."))
orel='chicago/4d/data/sources/assets/owner_brief_2026_08_18/README.md'
s=(ROOT/orel).read_text()
for num,sid,n,page in [(7,'trowbridge_green_tree_1902',55,35),(10,'trowbridge_sauganash_hotel',49,31)]:
 old=next(line for line in s.splitlines() if line.startswith(f'| {num} |'))
 subj='Green Tree Inn (Trowbridge)' if num==7 else 'The Sauganash (Trowbridge)'
 title='The Green Tree Tavern in 1835' if num==7 else "Mark Beaubien’s Tavern, The Sauganash, in 1835"
 new=f'| {num} | {subj} | *"{title}"*, W. E. S. Trowbridge, independently verified in Gale 1902, facing printed p. {page}, actual IA n{n} | `{sid}` | `public_domain` (verified 1902 US publication) |'
 textreplace(orel,old,new)
append(orel,'\n\n## T-3055: verified 1902 hotel plates supersede earlier rights uncertainty\n\nActual full-page inspection found the exact Trowbridge Sauganash drawing at Internet Archive `reminiscencesofe00ingale/page/n49` (facing printed p. 31), and the exact Green Tree drawing at `page/n55` (facing p. 35). The book’s actual title and copyright pages establish 1902 US publication and illustrator **W. E. S. Trowbridge**. Their prior `check_required` artwork holds and the older undated-publication language above are superseded; new unmodified page copies and hash manifests live in each source’s asset folder. The 1835 captions remain retrospective, and no historical fitting date, original colour, metric dimension, independent corroboration or image match is created by this verification.\n')
for inv in ['chicago/reference/images/IMAGE_SOURCES.md','chicago/reference/planning/images/IMAGE_SOURCES.md']:
 s=(ROOT/inv).read_text()
 for filename,sid,n,page,title in [('chicago_green_tree_tavern_1835.jpg','trowbridge_green_tree_1902',55,35,'The Green Tree Tavern in 1835'),('chicago_sauganash_tavern_1835.jpg','trowbridge_sauganash_hotel',49,31,"Mark Beaubien’s Tavern, The Sauganash, in 1835")]:
  marker=f'#### `{filename}`\n';a=s.index(marker);b=s.find('\n#### ',a+len(marker));old=s[a:b if b>=0 else len(s)]
  desc=('Two-storey clapboard hotel with shuttered sash, log annex, road-edge posts and figures/horse.' if 'sauganash' in sid else 'Two-storey clapboard tavern with hanging sign, seated figures, open wagon bay, wagons and field-edge context.')
  new=f'{marker}\n**{title}** — retrospective illustration · depicted state:1835 per caption · verified US publication:1902\n\n*W. E. S. Trowbridge, in Edwin O. Gale, Reminiscences of Early Chicago and Vicinity (Fleming H. Revell Company,1902), plate facing printed p. {page}.*\n\n{desc} The exact full composition was actually read in the1902 volume. Actual title credits **ILLUSTRATED BY W. E. S. TROWBRIDGE / MCMII**; actual copyright page says **COPYRIGHT, 1902, BY FLEMING H. REVELL COMPANY / October**.\n\nRights: **Public domain for the independently verified US-published 1902 artwork, by age** (`{sid}`). This replaces the formerly unsupported publication/rights claim and supersedes the source record’s artwork hold. A modern stock agency’s offered reproduction retains its own separate terms; no stock licence is claimed. Captioned 1835 does not prove every pictured fitting on 1 July 1835, dimensions, colour or independent corroboration.\n\nActual plate: <https://archive.org/details/reminiscencesofe00ingale/page/n{n}/mode/1up>; title <https://archive.org/details/reminiscencesofe00ingale/page/n12/mode/1up>; copyright <https://archive.org/details/reminiscencesofe00ingale/page/n13/mode/1up>. Original reproduction links remain documented in the source’s historical note.\n'
  textreplace(inv,old,new)
arel='chicago/4d/docs/RESEARCH/sauganash_image_accuracy.md'
old='The wash already recorded at `data/sources/trowbridge_sauganash_hotel.json`, undated, its companion signed 1902. Same composition with figures added.'
new='The wash recorded at `data/sources/trowbridge_sauganash_hotel.json`, now independently verified in Gale 1902 facing p. 31 (actual IA n49). Same composition with figures added; the1835 caption remains retrospective, not independent corroboration.'
textreplace(arel,old,new)
append('chicago/4d/assets/LICENSES.md','\n\n## Verified1902 Green Tree and Sauganash reference pages — T-3055\n\n| item | licence | provenance and limits |\n|---|---|---|\n| `data/sources/assets/trowbridge_green_tree_1902/gale-n55.jpg` and `data/sources/assets/trowbridge_sauganash_hotel/gale-n49.jpg` | Public domain by independently verified 1902 US publication | Unmodified InternetArchive page scans of W. E. S. Trowbridge illustrations in Edwin O. Gale, *Reminiscences of Early Chicago and Vicinity* (Fleming H. Revell Company,1902), facing printed pp. 35 and31. Exact URLs/hashes in adjacent manifests; actual title/copyright proof shared with `trowbridge_first_jail_gale_1902`. Retrospective 1835 caption does not establish July 1835 fitting dates, metrics, colours or modern stock reproduction licences. |\n')
newfile('chicago/4d/docs/RESEARCH/frame-hotels-gale-1902-source-audit.md','''# T-3055: actual1902 publication of Trowbridge hotel pictures

The exact held Sauganash composition is printed in Edwin O. Gale, *Reminiscences of Early Chicago and Vicinity* (Fleming H. Revell Company,1902), facing printed p. 31, actual InternetArchive `reminiscencesofe00ingale/page/n49`. Its full caption reads “Mark Beaubien’s Tavern, The Sauganash, in 1835.” It visibly shows sash shutters, attached log annex, figures, roadposts and the horse. The held GreenTreecomposition is in the same book facing printed p. 35, actual `page/n55`; its caption names1835 and Lake/WestWater(nowCanal), and its signature ends’02.

Both full unmodified pages were fetched and actually viewed, as were the actual title page n12 and copyright page n13. The title credits ILLUSTRATED BY W.E.S.TROWBRIDGE and MCMII; copyright reads COPYRIGHT, 1902, BY FLEMINGH.REVELL COMPANY / October. This is independently verified 1902 US publication, so the artwork is public domain by age and the older source-record artwork holds are superseded. Modern stock reproduction offers are separate and no stock licence is claimed.

This verifies publication, not the exact 1835 condition. The pictures are retrospective and compositionally dependent on earlier views. Their1835 captions do not establish each fitting on 1 July 1835, survey dimensions, geographic coordinates, historical colours or independent corroboration. All existing form values/confidences and original image-match gates remain unchanged.

Sauganash shutters: **bright-blue colour** is separately stated in Juliette Kinzie’s *Wau-Bun* (1856), recollecting1831. **Louvred leaf detail** remains a weaker inferred reading of the later Trowbridge drawing. The monochrome Andreas plate cannot establish colour. A whole-building Attested grade does not override those per-attribute limits. The newly verified source removes the rights uncertainty; it does not promote detail confidence.

The newsource asset directories retain exact scans/URLs/hashes. Title/copyright pages are reused from the already verified jail source directory with their hashes pinned in each hotel manifest. No accepted camera, full source-image match, official geometry freshness, published-app QA or full gate is asserted by this source-only verification package.
''')
(HERE/'source-update-operations.json').write_text(json.dumps({'operations':OPS,'required_publication_proof':proof},indent=2,ensure_ascii=False)+'\n')
print('Prepared',len(OPS),'selective operations; no canonical writes')
