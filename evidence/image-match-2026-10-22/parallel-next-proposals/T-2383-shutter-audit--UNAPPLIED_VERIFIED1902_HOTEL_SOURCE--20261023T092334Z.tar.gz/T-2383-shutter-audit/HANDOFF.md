# T-3055: verified 1902 Green Tree and Sauganash source credits

Both exact Trowbridge drawings have now been found and actually viewed in Edwin O. Gale, *Reminiscences of Early Chicago and Vicinity* (Fleming H. Revell Company, 1902):

- Sauganash: [actual full plate n49](https://archive.org/details/reminiscencesofe00ingale/page/n49/mode/1up), facing printed p. 31, caption “Mark Beaubien’s Tavern, The Sauganash, in1835.”
- Green Tree: [actual full plate n55](https://archive.org/details/reminiscencesofe00ingale/page/n55/mode/1up), facing printed p. 35, caption1835 and signature’02.

The actual book title page n12 and copyright page n13 were also viewed: ILLUSTRATED BY W. E. S. TROWBRIDGE, MCMII; COPYRIGHT,1902, BY FLEMING H. REVELL COMPANY / October. Original JPEGs, exact URLs and hashes are retained. Title/copyright originals are already in the sourceS jail directory; `publication-proof/` provides self-contained recovery copies without adding duplicate canonical proof pages.

This establishes independent 1902 US publication and public-domain artwork by age. Existing source IDs and tier5/dependence/scene-date limits stay intact; a retrospective1835caption is not proof of every fitting on1July1835. No modern stock reproduction licence is asserted. Sauganash’s **bright-blue** colour has separate Wau-Bun1856 testimony describing1831; **louvred leaf detail** remains inferred from the Trowbridge image. Keep both grades. Monochrome Andreas cannot establish colour. Do not remove shutters just to make the monochrome comparison simpler.

## Adoption order

This belongs to frameM T-3055, not the frozen sourceS T-3056 commit. Root should apply the main frozen frame helper, then the separate Tremont note correction, then review/adopt these sources BEFORE the actual23family bake:

```sh
cd /tmp/chicago-next-model/T-2383-shutter-audit
python adopt_sources.py --repo /workspace/chicago
# Review source-adoption-plan.json and review-tree/.
python adopt_sources.py --repo /workspace/chicago --apply
```

Always run default review again AFTER the frame helper/current sourceS commit: target byte hashes will change on unrelated preserved append work and `--apply` refuses drift. Do not rerun `prepare_source_update.py` for integration; it documents construction against the known source baseline. Its exact operation spec and payload are authoritative.

The16files include two source records, two unmodified original plate scans plus adjacent provenance files, source-visible Research prefixes on the two hotel records, the one obsolete Sauganash cross-wing rights clause, both inventories, ownerbrief rows/supersession, the Sauganash source-accuracy table date, a source-audit note, and appended licence provenance. Other form values, IDs, phases, dates, positions, confidences, source IDs and every unrelated JSON value stay unchanged. No LIBERTIES, runtime, archetype, GLB, manifest, compiled sidecar, accepted camera or match receipt is replaced. The source URL now links the verified original IA plate; historic Chicagology reproduction locators remain in the source note.

Default helper execution against root was REVIEW ONLY. A temporary copy layered with the actual final frame review files applied successfully; both hotel structures had exact non-note value parity and a second review was idempotent. `composition-review.json` records those checks. The actual existing pictures compiler’s `source_entry()` produces visible descriptive title, W.E.S.Trowbridge/Gale1902 credit, public-domain status and exact IA source link (`actual-picture-entry-reader.json`). No official bake, full gate or actual published app QA was run here.

## Published card QA

`group-card-additional-assertions.txt` supplies additional assertions for the existing non-Tremont hotel branch. Existing Andreas1884 checks and all mesh/grade/page/network/viewports must remain. Exact expected form values/grades in `group-card-expected.json` do not change. Add the assertions and execute the actual grouped card check after official generation/compilation/publish; this package does not claim that acceptance yet. The Research prefixes make both actual source IDs available to the existing Pictures join; no new join or invented figure geometry is introduced.

Original T-2376 and T-2383 picture-match tickets remain open. The earlier main-gable prototype comparisons still differ. Root’s existing final sourceS gate remains a distinct six-source/three-building result.
