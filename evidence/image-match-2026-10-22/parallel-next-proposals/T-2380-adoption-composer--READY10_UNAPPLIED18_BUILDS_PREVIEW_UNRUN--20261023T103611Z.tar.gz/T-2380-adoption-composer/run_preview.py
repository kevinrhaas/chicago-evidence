"""Actual core+keeper+palisade preview; --execute only after a coordinated slot."""
from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,os,shutil,subprocess,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('jailcompose',B/'compose.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(cmd,root,log):
 with log.open('w') as out:subprocess.run(cmd,cwd=root,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=subprocess.STDOUT,check=True)
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute',action='store_true');ap.add_argument('--blender',type=Path);ap.add_argument('--repo',type=Path,default=Path('/workspace/chicago'));a=ap.parse_args()
if not a.execute:
 print('NOT EXECUTED: planned1 actual committed bare-core baseline capture +3 official-name candidate builds and complete group capture, identical Gale optics. Requires coordinated Blender/browser slot; no fake/missing group members.');raise SystemExit(0)
assert a.blender and a.blender.is_file(),'existing pinned Blender4.5.3 executable required'
version=subprocess.run([str(a.blender),'--version'],text=True,capture_output=True,check=True).stdout;assert version.startswith('Blender 4.5.3'),'wrong pinned Blender version'
d=a.repo.resolve()/'chicago/4d';meta=c.j(B/'proposal.json')
for rel,want in meta['runner_sha256'].items():assert sha(B/rel)==want,'reviewed runner drift: '+rel
for rel,want in {**meta['before'],**meta['source_and_frame_guards']}.items():
 p=d/rel;assert (sha(p) if p.exists() else None)==want,'base drift: '+rel
for rel,want in meta['after'].items():assert sha(B/'candidate'/rel)==want,'candidate drift: '+rel
for rel,want in meta['preview_input_guards'].items():assert sha(d/rel)==want,'preview input drift: '+rel
source=B/'gale-plate-upright-analysis.png';assert sha(source)==meta['source_photo_sha256']
cam=c.j(B/'camera-gale-group.json');groupids=['log_jail','log_jail_keeper_house','log_jail_palisade']
assert [cam['structure_id'],*cam['also_render']]==groupids and cam['scene']=='1835'
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S-%f');folder=B/'runs'/stamp
for label in ['baseline','candidate']:
 root=folder/label;c.shadow(d,root)
 # No generated output may traverse a symlink to the canonical app.
 (root/'assets').unlink();(root/'assets/gltf').mkdir(parents=True)
 baseentry=c.j(d/'assets/manifest.json')['assets']['log_jail__log_1833.glb']
 assert baseentry['inputs_sha256']==meta['baseline_asset_entry']['inputs_sha256']
 shutil.copy2(d/'assets/gltf/log_jail__log_1833.glb',root/'assets/gltf/log_jail__log_1833.glb')
 (root/'assets/manifest.json').write_text(c.text({'assets':{'log_jail__log_1833.glb':baseentry}}))
 shutil.copy2(d/'assets/LICENSES.md',root/'assets/LICENSES.md')
 if label=='candidate':
  for rel in meta['after']:c.write(root,rel,(B/'candidate'/rel).read_text())
  # Materialize only real compiler output destinations, never fake sidecars/assets.
  for sid in groupids:
   p=root/'data/sidecars/1835'/f'{sid}.json';c.own_parent(root,p.parent)
   if p.exists() or p.is_symlink():p.unlink()
  # Compiler must create all3 complete records; group renderer refuses missing,
  # wrong-date or assetless members. No placeholder sidecars are written.
  run([sys.executable,str(B/'compile_preview_members.py')],root,root/'sidecars.log')
  for sid in groupids:
   sc=c.j(root/'data/sidecars/1835'/f'{sid}.json');assert sc['id']==sid and sc['target_date']=='1835-07-01'
  wrote=root/'wrote.txt'
  run([str(a.blender),'-b','-noaudio','--factory-startup','--threads','2','--python','generators/build.py','--','--only',','.join(groupids),'--scene','1835','--no-bake','--out','assets/gltf','--wrote',str(wrote)],root,root/'export.log')
  expected={sid+'__'+('log_1833' if sid=='log_jail' else 'context_1835')+'.glb' for sid in groupids}
  assert set(wrote.read_text().splitlines())==expected,'unexpected preview build scope'
  importstruct={sid:c.j(root/'data/structures'/f'{sid}.json') for sid in groupids}
  manifest=c.j(root/'assets/manifest.json')['assets']
  planned={r['asset']:r['after'] for r in c.j(B/'recipe-scope.json')['recipes']}
  for sid in groupids:
   asset=next(k for k,v in manifest.items() if v.get('structure_id')==sid);entry=manifest[asset]
   assert entry['phase_id']==importstruct[sid]['phases'][0]['id']
   assert entry['inputs_sha256']==planned[asset],'candidate recipe drift: '+asset
   assert (root/'assets/gltf'/next(k for k,v in manifest.items() if v.get('structure_id')==sid)).stat().st_size>100
 localcam=dict(cam)
 if label=='baseline':localcam.pop('also_render');localcam['solve']+=' BASELINE: committed bare core, honestly incomplete missing context; optics identical.'
 localcam['photo']='../../sources/assets/jail-gale1902/upright.png'
 c.write(root,'data/reference_views/log_jail/gale-compound-pilot.json',c.text(localcam))
 p=root/'data/sources/assets/jail-gale1902/upright.png';c.own_parent(root,p.parent)
 if p.is_symlink():p.unlink()
 shutil.copy2(source,p)
 # npm dependencies are read-only; subprocesses write only under this fixture.
 if (root/'node_modules').exists() or (root/'node_modules').is_symlink():raise RuntimeError('unexpected fixture dependency path')
 (root/'node_modules').symlink_to('/workspace/node_modules',target_is_directory=True)
 run(['node','tools/photo_match.mjs','data/reference_views/log_jail/gale-compound-pilot.json','--glb','assets/gltf/log_jail__log_1833.glb','--out','reviews'],root,root/'photo-match.log')
 print(label,'captured in',root/'reviews',flush=True)
print('All subprocesses exited. Inspect both actual same-camera captures; no matches, asset promotion, root writes or ticket closure performed.')
