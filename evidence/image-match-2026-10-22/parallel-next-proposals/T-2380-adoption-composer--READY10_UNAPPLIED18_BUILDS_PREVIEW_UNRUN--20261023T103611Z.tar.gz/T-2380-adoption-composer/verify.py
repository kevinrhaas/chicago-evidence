"""Focused no-Blender proof against the prepared disposable candidate."""
from pathlib import Path
import ast,dataclasses,hashlib,importlib.util,json,math,sys,zlib
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;D=B/'light-fixture/chicago/4d';O=B/'frozen-inputs/compound';R=Path('/workspace/chicago/chicago/4d')
sys.path[:0]=[str(D/'tools'),str(D/'generators')]
import jsonschema,validate as v,replace_invented_residents as pool,mesh_inputs
J=lambda p:json.loads(p.read_text())
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
tree=ast.parse((O/'verify.py').read_text());nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in ['functions','Collector','capture']]
ns={'ast':ast,'math':math,'zlib':zlib};exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(O/'verify.py'),'exec'),ns)
oldp=module('jailadopt_oldparams',O/'before/chicago/4d/generators/archetypes/palisade_params.py')
newp=module('jailadopt_newparams',D/'generators/archetypes/palisade_params.py')
oldn=ns['functions'](O/'before/chicago/4d/generators/archetypes/palisade.py');newn=ns['functions'](D/'generators/archetypes/palisade.py')
scope=J(B/'build-scope.json');recipes=[]
for row in scope['masters'][:15]:
 record=J(D/'data/structures'/f"{row['structure_id']}.json");ph=next(p for p in record['phases'] if p['id']==row['phase_id'])
 a=oldp.from_phase(ph,record);b=newp.from_phase(ph,record);aa=dataclasses.asdict(a);bb=dataclasses.asdict(b)
 assert bb.pop('curtain_runs')==() and bb.pop('wickets')==();assert aa==bb
 assert [f.name for f in dataclasses.fields(type(a)) if not f.kw_only]==[f.name for f in dataclasses.fields(type(b)) if not f.kw_only]
 name=Path(row['asset']).stem
 assert ns['capture'](oldn,a,name)==ns['capture'](newn,b,name),name
 newsha=mesh_inputs.structure_inputs_sha(record,ph);assert newsha!=row['inputs_sha256']
 recipes.append({'asset':row['asset'],'before':row['inputs_sha256'],'after':newsha,'exact_default_raw_parity':True})
print('PASS all15 palisade default params, positional constructor order and complete raw polygon/material/confidence/tone parity; all15 require genuine recipe refresh.')
records={s:J(D/'data/structures'/f'{s}.json') for s in ['log_jail','log_jail_keeper_house','log_jail_palisade']}
schema=J(D/'data/structures.schema.json')
for s,r in records.items():
 jsonschema.validate(r,schema);ph=r['phases'][0];p=mesh_inputs.resolve_params(r['archetype'],ph,r);p.validate()
 if s!='log_jail':assert not any(k in r for k in ['occupants','person_id','residents'])
 if s=='log_jail':assert ph['form']['roof_pitch_deg']['value']==22 and ph['form']['wall_height_m']['value']==2.66
 else:assert ph['documented_range']['confidence']=='inferred' and '1836' in ph['documented_range']['note']
 recipes.append({'asset':s+'__'+ph['id']+'.glb','after':mesh_inputs.structure_inputs_sha(r,ph)})
source=J(D/'data/sources/gale_1902_jail_walk_text.json');jsonschema.validate(source,J(D/'data/source.schema.json'));assert source['rights_status']=='public_domain'
gale=J(D/'data/sources/trowbridge_first_jail_gale_1902.json');ucr=J(D/'data/sources/calisphere_ucr_first_jail_catalogue_1930.json')
assert gale['rights_status']=='public_domain' and ucr['rights_status']=='check_required' and 'text_only' in json.dumps(ucr)
rep=v.Report();consumed=v.archetype_consumed(rep);v.check_geometry_declarations(records,consumed,rep)
doc=J(D/'data/liberties.json');entry=next(e for e in doc['liberties'] if e['id']=='L-log-jail-gale-compound-2380')
v.check_liberties_coverage(records,{'liberties':[entry]},rep,consumed)
assert not rep.errors,rep.errors
print('PASS3 record schemas/parameters; new text source schema; unchanged sourceS Gale/UCR distinctions; exact native liberty coverage both directions.')
declared=J(D/'data/reconstruction/name_pool_keys.json');parsed,bad=pool.harvest_names();assert not bad,bad
raw={}
for kind,paths in pool.name_pool_sources().items():
 ignored=set(declared.get('ignored',{}).get(kind,{}))
 for p in paths:
  for key,value in pool.string_leaves(J(p)):
   if key in ignored:continue
   for word in pool.NAME_WORD.findall(value):raw.setdefault(word.lower(),[]).append((p.relative_to(D/'data').as_posix(),key))
assert raw==parsed
(B/'name-pool-proof.json').write_text(json.dumps({'native_reader':'replace_invented_residents.harvest_names','raw_reader':'same native string_leaves/NAME_WORD across actual source files, excluding only explicitly declared ignored paths','raw_and_parsed_word_counts':[len(raw),len(parsed)],'exact_word_and_origin_lists_equal':True,'undeclared':bad,'introduced_note_paths':J(B/'proposal.json')['new_name_pool_paths'],'no_person_or_household_assignment':True},indent=2)+'\n')
print('PASS actual declared name pool equals raw-text pool after the explicitly ignored paths; zero undeclared keys. Actual --check CLI log is separate.')
# Required opt-in refusal boundaries are re-exercised against this composed candidate.
base=records['log_jail_palisade']['phases'][0]
import copy
cases=[('ordinarygate',lambda f:f.update(gate_sides={'value':['n']})),('bastion',lambda f:f.update(bastion_corners={'value':['nw']})),('offboundary',lambda f:f.update(curtain_runs={'value':[[1,1,2,1]]})),('overlap',lambda f:f.update(curtain_runs={'value':[[0,0,4,0],[2,0,6,0]]})),('string',lambda f:f.update(curtain_runs={'value':[['0',0,4,0]]})),('bool',lambda f:f.update(curtain_runs={'value':[[False,0,4,0]]})),('tallgate',lambda f:f.update(wickets={'value':[[6.6,5.622,7.5,5.622,2.5]]}))]
for name,mut in cases:
 ph=copy.deepcopy(base);mut(ph['form'])
 try:newp.from_phase(ph,records['log_jail_palisade'])
 except (ValueError,TypeError):pass
 else:raise AssertionError('missing refusal: '+name)
(B/'recipe-scope.json').write_text(json.dumps({'total':len(recipes),'recipes':recipes},indent=2)+'\n')
print('PASS7 refusal boundaries re-exercised;18 exact recipes enumerated. No assets, broad gates, browser or app writes.')
