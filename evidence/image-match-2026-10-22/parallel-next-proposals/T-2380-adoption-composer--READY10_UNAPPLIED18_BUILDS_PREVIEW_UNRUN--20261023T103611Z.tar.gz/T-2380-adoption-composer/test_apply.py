"""Exercise refusal and actual10-file application only in an owned temporary target."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;D=Path('/workspace/chicago/chicago/4d');meta=json.loads((B/'proposal.json').read_text());out=B/'apply-smoke';d=out/'chicago/4d';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not out.exists(),'smoke output is immutable; choose a new package rather than overwrite'
for rel in {**meta['before'],**meta['source_and_frame_guards'],**meta['proof_input_guards']}:
 p=D/rel
 if not p.exists():continue
 dest=d/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
root_before={r:sha(D/r) for r in meta['before'] if (D/r).exists()}
ledger=d/'docs/LIBERTIES.md';prior=ledger.read_bytes();ledger.write_bytes(prior+b'\nlocal refusal probe\n')
r=subprocess.run([sys.executable,str(B/'compose.py'),'--apply',str(out)],text=True,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
assert r.returncode and 'REFUSE changed destination input: docs/LIBERTIES.md' in r.stderr,r
for rel,want in meta['before'].items():
 if rel=='docs/LIBERTIES.md':continue
 p=d/rel;assert (sha(p) if p.exists() else None)==want,'partial write before guard failure: '+rel
ledger.write_bytes(prior)
r2=subprocess.run([sys.executable,str(B/'compose.py'),'--apply',str(out)],text=True,capture_output=True,check=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
for rel,want in meta['after'].items():assert sha(d/rel)==want,rel
for rel,want in meta['source_and_frame_guards'].items():assert sha(d/rel)==want,rel
for rel,want in root_before.items():assert sha(D/rel)==want,'canonical input changed during apply smoke: '+rel
(B/'apply-smoke-proof.json').write_text(json.dumps({'target':str(out),'canonical_application':False,'refused_dirty_ledger_before_any_write':r.stderr.strip(),'successful_owned_target_application':r2.stdout.strip(),'exact10_after_hashes':True,'sourceS_and_frameM_guards_preserved':True,'canonical_inputs_unchanged':True},indent=2)+'\n')
print('PASS guarded refusal before any write, then exact10-file apply to owned temporary target; canonical inputs and sourceS/frameM unchanged.')
