"""Finalize local runner guards and test dry-run parsing; never starts heavy work."""
from pathlib import Path
import hashlib,json,py_compile,shutil,subprocess,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;D=Path('/workspace/chicago/chicago/4d');meta=json.loads((B/'proposal.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=B/'gale-plate-upright-analysis.png';meta['source_photo_sha256']=sha(source)
camera=json.loads((B/'frozen-inputs/roof/camera-gale-core-pilot.json').read_text())
camera['scene']='1835';camera['also_render']=['log_jail_keeper_house','log_jail_palisade'];camera['photo']='gale-plate-upright-analysis.png'
camera['solve']=camera['solve'].replace('No keeper house/stockade/figures are added; they remain visible unbuilt differences.','The candidate also renders the genuine new keeper house and palisade from actual scene sidecars and real official-name GLBs. Context dimensions/placement remain reconstructed, and figures/outer rail/plankwalk remain missing. This is an unsolved whole-compound camera pilot, not a historic metric reconstruction.')
(B/'camera-gale-group.json').write_text(json.dumps(camera,indent=2)+'\n')
rels=['generators/build.py','generators/blender.pin','generators/mesh_inputs.py','generators/code_inputs.py','generators/emit.py','generators/archetypes/frame_dwelling.py','generators/archetypes/frame_dwelling_params.py','generators/archetypes/outbuilding.py','generators/archetypes/outbuilding_params.py','generators/archetypes/facade_openings.py','tools/compile_scene.py','tools/photo_match.mjs','tools/photo_match_group.mjs','renderers/web/js/keith-stone.js','data/scenes/1835.json','data/datum.json','assets/gltf/log_jail__log_1833.glb']
rels.extend(str(p.relative_to(D)) for p in (D/'generators/common').glob('*.py'))
meta['preview_input_guards']={r:sha(D/r) for r in rels}
meta['baseline_asset_entry']=json.loads((D/'assets/manifest.json').read_text())['assets']['log_jail__log_1833.glb']
scope=json.loads((B/'build-scope.json').read_text());ids={r['structure_id'] for r in scope['masters']}
versions=json.loads((D/'assets/manifest.versions.json').read_text())['assets'];affected={k:v for k,v in versions.items() if v.get('structure_id') in ids};assert not affected,affected
meta['registered_affected_versions']=0
proofrels=['tools/compile_liberties.py','tools/replace_invented_residents.py','tools/validate.py','data/structures.schema.json','data/source.schema.json']+[f"data/structures/{r['structure_id']}.json" for r in scope['masters'][:15]]
meta['proof_input_guards']={r:sha(D/r) for r in proofrels}
meta['runner_sha256']={p:sha(B/p) for p in ['compose.py','run_preview.py','compile_preview_members.py','verify.py','camera-gale-group.json','recipe-scope.json']}
(B/'proposal.json').write_text(json.dumps(meta,indent=2,ensure_ascii=False)+'\n')
for p in ['compose.py','verify.py','run_preview.py','compile_preview_members.py','freeze.py']:
 py_compile.compile(str(B/p),cfile='/tmp/jail-adoption-'+p+'.pyc',doraise=True)
r=subprocess.run([sys.executable,str(B/'run_preview.py')],text=True,capture_output=True,check=True);(B/'preview-dry-run.log').write_text(r.stdout)
r=subprocess.run([sys.executable,str(B/'compose.py')],text=True,capture_output=True,check=True);(B/'apply-dry-run.log').write_text(r.stdout)
print('Frozen local optics/source/input guards;0 versions; runners parse and default to NOT EXECUTED/NOT APPLIED.')
