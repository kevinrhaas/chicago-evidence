# T-2380 — guarded jail adoption composer

**Canonical UNAPPLIED; actual heavy preview UNRUN.** This is one candidate: the22° core roof plus the genuine keeper-house/palisade compound and latest clearance correction. No4.2m diagnostic, extra upper light, John Beach identity link, walker passage, camera refit or acceptance shortcut is included.

## Review and apply

Review `T-2380-adoption.patch`, `candidate/`, `proposal.json` and the actual logs. The patch currently passes `git apply --check` against the live repository. It contains10 files:3 structure records, the Gale text source,2 guarded palisade modules, reserved-ground permissions, name-pool declarations, liberty prose and its actual generated JSON.

`compose.py` defaults to **NOT APPLIED**. After reviewing the concrete candidate, the parent may explicitly apply to its chosen full fixture or repository:

```bash
python3 compose.py --apply /absolute/repository/path
```

All destination hashes, protected source/current-frame inputs, tested family records/tools and reviewed candidate/tool hashes must match before the first write. A deliberately dirty ledger was rejected with no partial writes, followed by exact10-file application in the wholly owned `apply-smoke/` target. No canonical files changed in that test. This applies source/ledger records only; it does not pretend to materialize assets or derived app layers.

The package preserves the current sourceS Gale/UCR distinctions and the parent's frame work. The independently published1902 art stays public domain; UCR's1930 catalogue/copy remains uncertain publication/check-required/text-only with its actual credit. Neither rights record nor frame records/builders/grade table is a patch target. The new book-text source is separately typed and graded. Both actual Public Square permission entries cite the specific printedp51 sentences and retain1835/1836 limits; there is no blanket waiver.

Ongoing parent work appended liberty prose during preparation. The old candidate correctly refused the changed ledger; `rejected-ledger-drift.json` records it. An explicit ledger-only refresh preserved those additions and rebuilt the actual JSON. If those two files alone drift again, while all other guards still pass:

```bash
python3 compose.py --refresh-ledger
python3 verify.py
python3 freeze.py
```

Re-review the refreshed patch before application. Any other drift requires a new reviewed preparation. The command never updates the canonical app. Do not run `--prepare` over a frozen package; use a fresh package directory to recompose a broader change.

## Actual focused proof

- All15 existing palisade masters: exact legacy default parameters, positional constructor order, and every raw polygon/material/confidence/tone value remain identical. All15 actual candidate recipe hashes change and need genuine rebuilds. Seven important opt-in refusal boundaries were re-exercised against the composed code; the frozen original package's14-case evidence is retained upstream.
- All3 structure schemas and native parameter objects pass; the book-text source schema passes. No occupants/person/household link is added. The core retains its original footprint, position and2.66m eave; only the bounded22° roof/notes/confidences and compound census prose are adopted.
- One real parsed liberty, `L-log-jail-gale-compound-2380`, has22 exact reconstructed `Covers` paths. No shorthand `.form` or relative `.position` tokens survive. The native validator passes coverage in both directions. The actual compiler required the existing roof-scope population to increase690→691 for the one new roof; its history/prose now says why. The current real CLI reports709 parsed liberties and passes `--check`.
- The actual name-pool CLI passes:4 documented residents still head their existing roofs,13 candidates refused, all remain unplaced under the existing rule. New `curtain_runs.note` and `wickets.note` paths are explicitly read. The raw/native parsed pools have3,468 words with identical origin lists after the existing explicit ignored paths, and zero undeclared keys. No resident assignment changes.
- Actual native sidecar compilation ran for the3 real proposed records in the light fixture. No hand-authored substitute sidecars or fake GLBs were used. The native group resolver correctly refuses the missing real keeper GLB; it cannot silently render an incomplete after group.

The prior clearance proof is copied under `frozen-inputs/clearance/proofs/`: house wall/stoop margins1.544/0.656m, palisade envelope/timber0.788/~0.698m inside drawn Randolph; no drawn/control roadway intrusion; the reserved square has no lots. Native raw curtain geometry misses the house interior; conservative core/house roof gap0.247m. These remain plan/collision tests, not terrain or full mesh certification.

The low wicket is explicitly **closed as a reconstructed static instant**. Walker collision consumes the entire palisade footprint, not individual runs/rails. Outside core/gate approaches stop at the envelope; an inside spawn is pushed outward. Public sidewalk and translated keeper-door approaches pass only the stated flat native collision study. No courtyard accessibility or broad walker change is claimed.

## Future actual preview

`run_preview.py` defaults to **NOT EXECUTED**. Only after the parent coordinates its Blender/browser slot:

```bash
python3 run_preview.py --execute --blender /verified/pinned/blender
```

It verifies4.5.3, snapshots guarded current inputs into wholly temporary fixtures and performs exactly3 official-name candidate builds with `--scene 1835 --no-bake`. It captures the actual committed bare-core baseline as honestly missing context, then all3 actual candidate members, with identical Gale optics. The candidate uses complete native compiler output, checks official wrote names and exact candidate recipe hashes, and requires every real GLB before the group renderer runs. No blank assets, placeholder sidecars, raised diagnostic or silently dropped member is permitted. All subprocesses must exit. Source/pixel/camera choices are frozen in this package; optics remain provisional and the source caption remains1836.

The preview's3 builds do **not** satisfy production freshness. Inspect actual full-group results and all remaining source differences before adopting a verdict. No browser/Blender has run for this package, no source image has been retouched, and T-2380 remains open.

## Exact production unit

`build-scope.json`, `recipe-scope.json` and `production-build-plan.json` enumerate **18 master builds**:

| Scope | Count |
|---|---:|
|Existing palisades refreshed by the two shared modules |15 |
|Existing core with22° roof |1 |
|New keeper house and palisade |2 |
|Total masters / corresponding web derivatives |18 /18 |
|Registered affected versions |0 |

No existing frame-family master is stale from this change. Common emit/material/mesh modules are untouched. A production selected build must include **all scenes**: an1835-only filter would skip the1812 palisades in the shared blast. The plan supplies the exact selection and expected wrote names; use the actual builder wrote file for derivatives. Final licenses, actual producer outputs, compiled sidecars/source-use/entrance/frontage layers, full required gate, site mirroring, release notes and original grouped image acceptance remain the parent's integration work. The copied current frame/source inputs are guarded rather than replaced with archived snapshots.

## Recovery

The prepared application/preview package is self-contained apart from the guarded current repository/toolchain. Selected frozen source inputs, original palisade baseline/helper, roof recipe and camera are copied into `frozen-inputs/`; the upright source PNG is local. No dependency on another temporary proposal directory remains in the runnable tools. The original scan/title/copyright/provenance evidence remains independently archived with the earlier jail packages at tickets commit4038f9ff7a39f5457aa37e8d87277e3e39d5c9d8. Recreating `light-fixture` uses current guarded canonical inputs; that directory and the failed first attempt are disposable local overlays, not deployable app outputs.
