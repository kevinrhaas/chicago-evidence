"""Compose/review a jail-only candidate; writes the app only with explicit --apply."""
from pathlib import Path
import argparse,copy,datetime,difflib,hashlib,json,os,shutil,subprocess,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent
F=B/'frozen-inputs/clearance/chicago/4d'
OLD=B/'frozen-inputs/compound'
ROOF=B/'frozen-inputs/roof'
def j(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def text(x):return json.dumps(x,indent=2,ensure_ascii=False)+'\n'
def run(cmd,root,log):
 with log.open('w') as f:subprocess.run(cmd,cwd=root,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=f,stderr=subprocess.STDOUT,check=True)
def own_parent(root,path):
 if path==root:return
 own_parent(root,path.parent)
 if path.is_symlink():
  source=path.resolve();path.unlink();path.mkdir()
  for p in source.iterdir():(path/p.name).symlink_to(p,target_is_directory=p.is_dir())
 elif not path.exists():path.mkdir()
def write(root,rel,value):
 p=root/rel;own_parent(root,p.parent)
 if p.is_symlink():p.unlink()
 p.write_text(value)
def shadow(source,dest):
 dest.mkdir(parents=True)
 for p in source.iterdir():
  if p.name in ['tools','generators']:shutil.copytree(p,dest/p.name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
  else:(dest/p.name).symlink_to(p,target_is_directory=p.is_dir())
def append_ledger(d,covers):
 fragment=(B/'liberty-body.md').read_text().replace('@@COVERS@@',', '.join('`'+c+'`' for c in covers))
 ledger=(d/'docs/LIBERTIES.md').read_text();assert '### L-log-jail-gale-compound-2380 ' not in ledger
 old_scope='**Scope:** `structures.phases[roof_type_stated]` — 690 phases ('
 assert ledger.count(old_scope)==1,'L263 population changed; remeasure rather than overwrite'
 ledger=ledger.replace(old_scope,'**Scope:** `structures.phases[roof_type_stated]` — 691 phases (690 until T-2380 added the jail keeper house, 2026-10-23, L-log-jail-gale-compound-2380; ')
 return ledger.rstrip()+'\n\n'+fragment.strip()+'\n'
def patch_from_targets(d,targets):
 patch=[]
 for rel,value in sorted(targets.items()):
  p=d/rel;prior=p.read_text() if p.exists() else '';name='chicago/4d/'+rel
  patch.append('diff --git a/'+name+' b/'+name+'\n')
  if not p.exists():patch.append('new file mode 100644\n')
  patch.extend(difflib.unified_diff(prior.splitlines(True),value.splitlines(True),fromfile='a/'+name if p.exists() else '/dev/null',tofile='b/'+name))
 return ''.join(patch)

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--repo',type=Path,default=Path('/workspace/chicago'));ap.add_argument('--prepare',action='store_true');ap.add_argument('--refresh-ledger',action='store_true',help='rebase only the two ledger files onto current prose after all other guards pass');ap.add_argument('--apply',type=Path,help='explicit reviewed repository target; never implicit');a=ap.parse_args()
 if a.refresh_ledger:
  d=a.repo.resolve()/'chicago/4d';meta=j(B/'proposal.json');ledgers={'docs/LIBERTIES.md','data/liberties.json'}
  for rel,want in {**{k:v for k,v in meta['before'].items() if k not in ledgers},**meta['source_and_frame_guards'],**meta.get('proof_input_guards',{})}.items():
   p=d/rel;assert (sha(p) if p.exists() else None)==want,'non-ledger drift requires full re-review: '+rel
  drift={r:{'prepared':meta['before'][r],'current':sha(d/r)} for r in ledgers if meta['before'][r]!=sha(d/r)}
  (B/'rejected-ledger-drift.json').write_text(text({'action':'Old guarded patch/application would refuse; no root writes performed. Explicit ledger-only refresh follows.','drift':drift}))
  fixture=Path(meta['light_fixture']);value=append_ledger(d,meta['exact_covers']);write(fixture,'docs/LIBERTIES.md',value)
  run([sys.executable,'tools/compile_liberties.py'],fixture,B/'liberties-write.log');run([sys.executable,'tools/compile_liberties.py','--check'],fixture,B/'liberties-check.log')
  for rel,after in [('docs/LIBERTIES.md',value),('data/liberties.json',(fixture/'data/liberties.json').read_text())]:
   (B/'candidate'/rel).write_text(after);meta['before'][rel]=sha(d/rel);meta['after'][rel]=sha(B/'candidate'/rel)
  (B/'proposal.json').write_text(text(meta));targets={r:(B/'candidate'/r).read_text() for r in meta['after']}
  (B/'T-2380-adoption.patch').write_text(patch_from_targets(d,targets))
  subprocess.run(['git','apply','--check',str(B/'T-2380-adoption.patch')],cwd=a.repo,check=True,capture_output=True)
  print('Refreshed only jail ledger append/derived copy against current prose. No root writes. Re-run verify/freeze before review.');return
 if a.apply:
  target=a.apply.resolve();meta=j(B/'proposal.json');d=target/'chicago/4d'
  for rel,want in meta['before'].items():
   p=d/rel;got=sha(p) if p.exists() else None
   if got!=want:raise SystemExit('REFUSE changed destination input: '+rel)
  for rel,want in meta['source_and_frame_guards'].items():
   if sha(d/rel)!=want:raise SystemExit('REFUSE changed source/frame guard: '+rel)
  for rel,want in meta.get('proof_input_guards',{}).items():
   if sha(d/rel)!=want:raise SystemExit('REFUSE changed tested input: '+rel)
  for rel,want in meta.get('runner_sha256',{}).items():
   if sha(B/rel)!=want:raise SystemExit('REFUSE changed reviewed tool: '+rel)
  for rel,want in meta['after'].items():
   p=B/'candidate'/rel
   if sha(p)!=want:raise SystemExit('REFUSE changed candidate: '+rel)
  for rel in meta['after']:
   p=d/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((B/'candidate'/rel).read_bytes())
  print('Applied reviewed source/ledger candidate only. Assets/sidecars/site/producers/full gate still required. No ticket verdict changed.');return
 if not a.prepare:
  print('NOT APPLIED. Use --prepare for a disposable light candidate; --apply <repo> requires a reviewed prepared package. Preview runner is separately execute-gated.');return
 d=a.repo.resolve()/'chicago/4d'
 if (B/'proposal.json').exists():raise SystemExit('Package already frozen; prepare a new directory rather than overwrite it')
 # SourceS is current input. Never replace either rights record with archived claims.
 gale=j(d/'data/sources/trowbridge_first_jail_gale_1902.json')
 ucr=j(d/'data/sources/calisphere_ucr_first_jail_catalogue_1930.json')
 assert gale['rights_status']=='public_domain' and gale['verified']
 assert ucr['rights_status']=='check_required' and 'text_only' in json.dumps(ucr)
 core=j(d/'data/structures/log_jail.json');old=j(ROOF/'before/chicago/4d/data/structures/log_jail.json');roof=j(ROOF/'roof-only/chicago/4d/data/structures/log_jail.json')
 result=copy.deepcopy(core)
 # Guard/merge the exact changed form attributes; preserve all current sourceS data.
 for key,value in roof['phases'][0]['form'].items():
  if value!=old['phases'][0]['form'].get(key):
   assert core['phases'][0]['form'].get(key)==old['phases'][0]['form'].get(key),'core form drift: '+key
   result['phases'][0]['form'][key]=value
 result['phases'][0]['change_note']=j(F/'data/structures/log_jail.json')['phases'][0]['change_note']
 assert result['phases'][0]['form']['roof_pitch_deg']['value']==22
 targets={'data/structures/log_jail.json':text(result)}
 for rel in ['data/sources/gale_1902_jail_walk_text.json','data/structures/log_jail_keeper_house.json','data/structures/log_jail_palisade.json']:
  assert not (d/rel).exists(),'already exists: '+rel;targets[rel]=(F/rel).read_text()
 for rel in ['generators/archetypes/palisade.py','generators/archetypes/palisade_params.py']:
  assert (d/rel).read_bytes()==(OLD/'before/chicago/4d'/rel).read_bytes(),'shared palisade drift: '+rel
  targets[rel]=(F/rel).read_text()
 reserved=j(d/'data/reconstruction/1835_reserved_ground.json');approved=j(F/'data/reconstruction/1835_reserved_ground.json')
 hold=next(b for b in reserved['blocks'] if b['block_id']=='blk_randolph_lasalle')
 extra=next(b for b in approved['blocks'] if b['block_id']=='blk_randolph_lasalle')['what_may_stand_here']['permitted'][-2:]
 assert {r['structure_id'] for r in extra}=={'log_jail_keeper_house','log_jail_palisade'}
 assert not ({r['structure_id'] for r in extra}&{r['structure_id'] for r in hold['what_may_stand_here']['permitted']})
 hold['what_may_stand_here']['permitted'].extend(extra);targets['data/reconstruction/1835_reserved_ground.json']=text(reserved)

 fixture=B/'light-fixture/chicago/4d';shadow(d,fixture)
 for rel,value in targets.items():write(fixture,rel,value)
 # Query the actual name-pool reader in a subprocess using the actual fixture ROOT.
 pool_probe="""import json,sys
from pathlib import Path
sys.path.insert(0,'tools')
import replace_invented_residents as r
pool,bad=r.harvest_names()
print(json.dumps({'undeclared':bad}))
"""
 cp=subprocess.run([sys.executable,'-c',pool_probe],cwd=fixture,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},check=True,text=True,capture_output=True)
 bad=json.loads(cp.stdout)['undeclared'];keys=j(d/'data/reconstruction/name_pool_keys.json')
 newkeys=sorted({x[1] for x in bad if x[0]=='structures'})
 assert all(x[0]=='structures' and x[2] in ['structures/log_jail_keeper_house.json','structures/log_jail_palisade.json'] for x in bad),bad
 keys['read']['structures']=sorted(set(keys['read']['structures'])|set(newkeys));targets['data/reconstruction/name_pool_keys.json']=text(keys)
 write(fixture,'data/reconstruction/name_pool_keys.json',targets['data/reconstruction/name_pool_keys.json'])
 # Explicit exact paths for every reconstructed attribute in the three records.
 # The native validator decides the vocabulary; do not invent abbreviated .form claims.
 cover_probe="""import json,sys
sys.path.insert(0,'tools')
import validate as v
from pathlib import Path
r={s:json.loads(Path('data/structures/'+s+'.json').read_text()) for s in ['log_jail','log_jail_keeper_house','log_jail_palisade']}
print(json.dumps(['.'.join(x for x in (sid,pid,aspect) if x) for sid,pid,aspect,where in v.inferred_values(r)]))
"""
 cp=subprocess.run([sys.executable,'-c',cover_probe],cwd=fixture,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},check=True,text=True,capture_output=True)
 covers=sorted(set(json.loads(cp.stdout)));targets['docs/LIBERTIES.md']=append_ledger(d,covers)
 write(fixture,'docs/LIBERTIES.md',targets['docs/LIBERTIES.md'])
 write(fixture,'data/liberties.json',(d/'data/liberties.json').read_text())
 run([sys.executable,'tools/compile_liberties.py'],fixture,B/'liberties-write.log')
 run([sys.executable,'tools/compile_liberties.py','--check'],fixture,B/'liberties-check.log')
 targets['data/liberties.json']=(fixture/'data/liberties.json').read_text()
 run([sys.executable,'tools/replace_invented_residents.py','--check'],fixture,B/'name-pool-cli.log')
 # Keep future root frame/source edits visible: apply refuses any changed protected input.
 guardrels=['data/sources/trowbridge_first_jail_gale_1902.json','data/sources/calisphere_ucr_first_jail_catalogue_1930.json','data/structure_grades.json','generators/archetypes/frame_tavern.py','generators/archetypes/frame_tavern_params.py','data/structures/green_tree_tavern.json','data/structures/sauganash_hotel.json','data/structures/tremont_house_1.json']
 before={};after={};patch=[]
 for rel,value in sorted(targets.items()):
  p=d/rel;prior=p.read_text() if p.exists() else '';before[rel]=sha(p) if p.exists() else None
  dest=B/'candidate'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(value);after[rel]=sha(dest)
  name='chicago/4d/'+rel;patch.append('diff --git a/'+name+' b/'+name+'\n')
  if not p.exists():patch.append('new file mode 100644\n')
  patch.extend(difflib.unified_diff(prior.splitlines(True),value.splitlines(True),fromfile='a/'+name if p.exists() else '/dev/null',tofile='b/'+name))
 (B/'T-2380-adoption.patch').write_text(''.join(patch))
 subprocess.run(['git','apply','--check',str(B/'T-2380-adoption.patch')],cwd=a.repo,check=True,capture_output=True)
 family=[{'asset':k,**v} for k,v in j(d/'assets/manifest.json')['assets'].items() if v.get('archetype')=='palisade']
 assert len(family)==15
 build=family+[{'asset':'log_jail__log_1833.glb','structure_id':'log_jail','phase_id':'log_1833','archetype':'outbuilding','reason':'22-degree roof'}]+[{'asset':s+'__context_1835.glb','structure_id':s,'phase_id':'context_1835','archetype':arch,'reason':'new compound component'} for s,arch in [('log_jail_keeper_house','frame_dwelling'),('log_jail_palisade','palisade')]]
 (B/'build-scope.json').write_text(text({'existing_palisade_masters':15,'existing_changed_core_masters':1,'new_masters':2,'total_masters':18,'masters':build}))
 (B/'proposal.json').write_text(text({'status':'UNAPPLIED; heavy preview UNRUN','repo_head':subprocess.run(['git','rev-parse','HEAD'],cwd=a.repo,text=True,capture_output=True,check=True).stdout.strip(),'before':before,'after':after,'source_and_frame_guards':{r:sha(d/r) for r in guardrels},'new_name_pool_paths':newkeys,'exact_covers':covers,'light_fixture':str(fixture)}))
 print('Prepared guarded jail candidate:',len(targets),'files;',len(covers),'exact Covers;',len(newkeys),'declared new name-pool paths;18 masters. No app/asset/ticket writes.')

if __name__=='__main__':main()
