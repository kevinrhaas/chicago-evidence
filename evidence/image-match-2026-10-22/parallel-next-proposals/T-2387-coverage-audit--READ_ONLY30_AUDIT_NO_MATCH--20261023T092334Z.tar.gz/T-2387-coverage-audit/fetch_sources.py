from pathlib import Path
import concurrent.futures,urllib.request
h=Path(__file__).resolve().parent
urls={'prefire274.html':'https://chicagology.com/prefire/prefire274/','whistler-1808.png':'https://www.gutenberg.org/files/69274/69274-h/images/fpage164_lg.png'}
def get(kv):
 n,u=kv
 try:
  with urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Chicago4DSourceAudit/1.0'}),timeout=35) as r:d=r.read()
  (h/n).write_bytes(d);return n,len(d)
 except Exception as e:return n,str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:
 for r in p.map(get,urls.items()):print(r)
