"""Read the museum's anonymous public search exactly as its public JS does."""
from pathlib import Path
from html.parser import HTMLParser
import base64,concurrent.futures,json,urllib.parse,urllib.request
H=Path(__file__).resolve().parent
class Inputs(HTMLParser):
 def __init__(self):super().__init__();self.inputs={}
 def handle_starttag(self,tag,attrs):
  d=dict(attrs)
  if tag=='input' and 'id'in d:self.inputs[d['id']]=d
p=Inputs();p.feed((H/'chm-62505-search.html').read_text());i=p.inputs
# These are anonymous public-page session parameters; never print their values.
base=i['cooURL']['value'];token=i['stat']['value'];ip=i['uIP']['value']
auth='Basic '+base64.b64encode((token+':'+ip).encode()).decode()
def get(q):
 url=base.rstrip('/')+'/search/unified?'+urllib.parse.urlencode({'doctype':'asset','searchterm':q,'simples':'','itemsPerPage':10})
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Referer':'https://images.chicagohistory.org/','Accept':'application/json; charset=utf-8','Authorization':auth})
  with urllib.request.urlopen(req,timeout=25) as r:d=json.load(r)
  (H/('museum-search-'+q+'.json')).write_text(json.dumps(d,indent=2))
  return q,d.get('meta',{}).get('total'),list(d)
 except Exception as e:return q,str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for x in pool.map(get,['ICHi-62486','ICHi-62505','ICHi-59714','ICHi-21562']):print(x)
