#!/usr/bin/env python3
from pathlib import Path
import json,re,sys,hashlib
sys.dont_write_bytecode=True
R=Path('/workspace/chicago/chicago/4d');H=Path(__file__).resolve().parent
cam=json.loads((R/'docs/RESEARCH/fort-reference-groups-T-3040/first-fort-panel-1.json').read_text());ids=sorted([cam['structure_id']]+cam['also_render'])
ticket=Path('/workspace/chicago-tickets/T-2250-2499/T-2387-match-the-first-fort-dearborn-1812-to-its-pictur.md').read_text();ticketpart=ticket[ticket.index('Records:'):ticket.index('Pictures:')];original=set(re.findall(r'`([^`]+)`',ticketpart))
manifest=json.loads((R/'assets/manifest.json').read_text());assets=manifest.get('assets',manifest)
sys.path.insert(0,str(R/'generators'));import mesh_inputs
roofed={'fort_structure','log_dwelling','outbuilding'}
rows=[]
for sid in ids:
 rec=json.loads((R/f'data/structures/{sid}.json').read_text());ph=rec['phases'][0];asset,meta=next((k,v) for k,v in assets.items() if isinstance(v,dict) and v.get('structure_id')==sid and v.get('phase_id')==ph['id']);kind=ph.get('form',{}).get('kind',{}).get('value');is_roofed=rec['archetype'] in roofed and kind not in ['flagstaff','parade'];sources=set()
 def walk(v):
  if isinstance(v,dict):
   sources.update(v.get('sources') or [])
   for x in v.values():walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 walk(rec)
 try:current=meta.get('inputs_sha256')==mesh_inputs.structure_inputs_sha(rec,ph,rec['archetype']);error=None
 except Exception as e:current=None;error=str(e)
 views=[]
 for f in (R/'data/reference_views'/sid).glob('*.json'):
  if not f.name.endswith('.match.json'):views.append(str(f.relative_to(R)))
 row={'id':sid,'name':rec.get('name'),'scope':'original21' if sid in original else 'additional9','roofed_building':is_roofed,'archetype':rec['archetype'],'kind':kind,'phase':ph['id'],'range':ph['documented_range'],'position':ph['position'],'footprint':ph['footprint'],'form_values':{k:v.get('value') for k,v in ph['form'].items()},'cited_sources':sorted(sources),'canonical_asset':asset,'canonical_asset_sha256':hashlib.sha256((R/'assets/gltf'/asset).read_bytes()).hexdigest(),'canonical_recipe_current':current,'recipe_error':error,'accepted_reference_camera_files':views,'research_group_camera':'docs/RESEARCH/fort-reference-groups-T-3040/first-fort-panel-1.json','research_group_role':'anchor' if sid==cam['structure_id'] else 'context_member','full_match_status':'open/not accepted'}
 rows.append(row)
report={'records':len(rows),'original21':len(original),'additional9':len(rows)-len(original),'roofed_buildings':sum(r['roofed_building'] for r in rows),'site_works_or_grounds':sum(not r['roofed_building'] for r in rows),'canonical_recipe_current_count':sum(r['canonical_recipe_current'] is True for r in rows),'canonical_recipe_unknown_count':sum(r['canonical_recipe_current'] is None for r in rows),'accepted_reference_camera_files':sum(len(r['accepted_reference_camera_files']) for r in rows),'rows':rows}
(H/'inventory.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2))
