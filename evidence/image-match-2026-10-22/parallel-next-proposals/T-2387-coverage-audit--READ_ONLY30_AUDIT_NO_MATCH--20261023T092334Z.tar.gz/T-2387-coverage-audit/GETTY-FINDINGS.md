# Getty / museum verification and bounded source correction

Actual public Getty credit pages were read (four saved HTML/text receipts). Getty labels the three paintings Date created Jan1,1803 and the engraving Jan1,1850, but those catalog fields do not prove original creation years. Getty supplies rights-managed reproductions, not an open license. The held thumbnail does not acquire reuse permission from the historical scene date.

The museum's own public catalog resolves the objects and creators:

| Getty | Museum object and public page | Actual catalog result |
|---|---|---|
|529323671|ICHi-062486 https://images.chicagohistory.org/asset/5857/|Edgar Spier Cameron1862–1944, oil; accession1905.12. Description depicts1803; Date Depicted field1903 conflicts. No creation date established. No Known Copyright.|
|529322537|ICHi-062505 https://images.chicagohistory.org/asset/25650/|Lawrence C.Earle, oil; accession1933.49, gift Central Republic Bank and Trust Company. Date Depicted1803. No Known Copyright. Visually matches Chicagology's full Earle1902 bank mural.|
|529264885|ICHi-059714 https://images.chicagohistory.org/asset/23966/|C.E.Petford, watercolor; accession1896.18. Date Depicted1803, not creation year. No Known Copyright.|
|88810552|ICHi-021562 https://images.chicagohistory.org/asset/12763/|Creator unknown; engraving. Copyright Undetermined; Rights restricted.|

Museum No Known Copyright is the catalog's statement, not proof of publication or a Getty reproduction license. Accession years are not publication years. No underlying work is called pre1850 merely because it depicts1803. The independently published Currey1912 numbered fort illustration is a public-domain book image, distinct from modern/1902 oil painting reproductions. Chicagology identifies the Earle Chicago National Bank mural as1902,16ft×9ft in segmental frames; original1902/1912 publication verification remains a possible follow-up, not a prerequisite for the existing public-domain-based geometry.

No NEW geometry in the frozen shared-fort proposal derives from Getty: first-fort blockhouse chimney removals read Kurz1893 panel1; double galleries read Currey1912 p27 and Whistler1808; second-fort cupola reads Kurz panel5; lighthouse reads Castelnau1842 plate18; Lake House corrects an existing roof-none parameter. Do not delay those on a stock-image rights inference.

`source-ledger-correction.patch` proposes four tightly scoped entries in BOTH existing IMAGE_SOURCES ledgers. It corrects creators, removes unsupported pre1850 assertions and records the museum metadata without claiming an asset license. It does not remove existing files, clear rights, mark a camera matches, or change geometry.
