from pathlib import Path
import json,hashlib,re,difflib
H=Path(__file__).resolve().parent; R=Path('/workspace/chicago'); data=json.loads((H/'inventory.json').read_text())
common='C0 compound diagnostic only; no accepted individual camera. Current recipe verified; pending proposals are not baked.'
gaps={
'blockhouse_nw':('Whistler1808 no.1; Currey1912 no.4; Kurz1893 panel1 compound','Remove domestic chimney (frozen proposal); then build first-fort capped roof lantern from Currey/Kurz. Do not infer exact lantern dimensions or move the surveyed corner.'),
'blockhouse_se':('Whistler no.2; Currey no.5; Kurz compound','Same chimney/lantern correction, independently review southeast silhouette and upper jetty. Do not substitute the second-fort closed drum without comparison.'),
'commanding_officers_barracks':('Whistler folded east elevation, no.11; Currey interior range','Four front rectangles per storey, versus current three bays; two gallery levels pending frozen proposal. Exact widths, heights and door identities reconstructed.'),
'north_range':('Whistler no.12 soldiers + no.13 contractor store in ONE roof','Four front rectangles per storey, versus current two bays; two gallery levels pending. Preserve combined plan/roof; do not split rooms into buildings.'),
'officers_barracks':('Whistler folded west elevation, no.10; Currey no.6','Five front rectangles per storey versus current four bays; two gallery levels pending. Courtyard doorway choice remains reconstructed.'),
'soldiers_barracks_se':('Whistler folded south elevation, no.12; Currey no.7','Four front rectangles per storey versus current two; two gallery levels pending. Preserve plan and south-gate gap.'),
'soldiers_barracks_sw':('Whistler folded south elevation, no.12; Currey no.7','Four front rectangles per storey versus current two; two gallery levels pending. Separate render required; southeast agreement cannot stand in for this range.'),
'magazine':('Whistler no.4 arched elevation; Currey no.8 curved cap','Current gable is inconsistent with arched/barrel appearance. No supported barrel roof in fort_structure, so NOT a data-only roof change; next bounded curved-cap/arched-front helper needs explicit reconstructed section.'),
'small_house_ne':('Whistler no.16 low trapezoidal/hip cap; Currey low northeast house','Current gable differs. outbuilding supports only gable/shed: hip is NOT a supported data-only change. Do not silently swap archetype; add opt-in supported roof later.'),
'small_house_sw':('Whistler no.19 plan symbol; no unique retrospective elevation','No evidence-bounded visible correction yet. Keep reconstructed gable, dimensions and door declared; obtain diagnostic identification before choosing a new shape.'),
'flagstaff':('Whistler no.20 laid-down staff and75ft annotation; Kurz mast','Retain22.86m attested height. C0 projects mast above image; solve drawing camera/visibility conflict, do not shorten height to fit.'),
'parade':('Whistler enclosed parade; Currey courtyard','No basis for precise gutter dimensions. Whistler34 gutters are explicitly omitted from drawing; avoid inventing a measured drainage network.'),
'pickets_inner':('Whistler inner curtain; Currey paired pickets and gates','Review actual gate/wicket locations and central south gatehouse/monitor missing in current composite. Preserve traced plan; drawing is not a reason to move corners.'),
'pickets_outer':('Whistler outer curtain; Currey; Kurz riverfront','Resolve camera and gatehouse silhouette; keep two distinct rows. Do not merge rows or enlarge posts solely for distant legibility.'),
}
outer={
'first_fort_outer_agents_house':('Whistler Indian Department no.21; prospective riverfront house not uniquely identified','Study primary facade symbol before changing bays/porch; do not assign the frame-right two-storey porch house solely by plausibility.'),
'first_fort_outer_factory':('Whistler Indian Department no.22; no unique retrospective identification','Study the actual two-storey symbol; external plan is not regular garrison scale. Avoid transferring dimensions from an unidentified painted house.'),
'first_fort_outer_interpreters_house':('Whistler no.25','Primary symbol is useful for facade topology, not a surveyed metric elevation. Present gable/two storeys remain a declared approximation.'),
'first_fort_outer_armourers_shop':('Whistler no.17','Primary small building symbol only; furnace/chimney and exact door layout not proved. Do not add trade equipment merely from name.'),
'first_fort_outer_bake_house':('Whistler no.18','Primary symbol only; oven form not dimensioned. Next source-shaped oven/roof study only if visible elevation identifies it.'),
'first_fort_outer_merchants_shop':('Whistler no.26','Study facade symbol, then opt-in bays; no unique painted building identity established.'),
'first_fort_outer_stable_middle':('Whistler no.23 HOUSE in factor department','Legacy stable_middle ID is NOT a third stable. Preserve house function; next facade study against no.23, not a livestock-door substitution.'),
'first_fort_outer_stable_north':('Whistler no.24 north stable','Primary symbol constrains footprint/topology, not regular garrison-scale dimensions. Validate a horse entrance against shown elevation before adding details.'),
'first_fort_outer_stable_south':('Whistler no.24 south stable','Independent small stable; no reason to duplicate exact north-stable facade. Obtain source crop and separate diagnostic.'),
'first_fort_outer_officers_garden':('Whistler no.28 clear two rows of four beds','Current fenced prairie omits eight beds and crossing walks. Highest grounded visible grounds change: reconstructed bare cultivated bed/path geometry, no invented crop or figures.'),
'first_fort_outer_sutlers_garden':('Whistler no.27 fenced plot','Bed layout is not clear; do not copy the officers garden eight-bed pattern without evidence.'),
'first_fort_wharf':('Whistler no.29 landing mark, outer irregular scale','pier_crib minimum10m is not an attested10ft conversion. Investigate smaller landing against shoreline; fix literal {R:.2f}/{H:.1f} placeholders separately, not by inventing dimensions.'),
}
for s in ['bank_lower','bank_middle','bank_upper','terrace']:
 outer['first_fort_covered_way_'+s]=('Whistler index33 expressly OMITTED from plan; Quaife1913 narrative northeast corner to river','Review continuity and automatic gates at every reconstructed terrain segment; four palisade boxes may produce unjustified repeated gates. No pictured roof width or exact path exists to trace.')
rows=[]
for r in data['rows']:
 key=r['id'].removeprefix('first_fort_dearborn_'); ev,nxt=gaps.get(key,outer.get(r['id'],('UNRESOLVED','Needs individual evidence review')))
 rows.append(f"| `{r['id']}` | {r['scope']} | {ev} | {nxt} |")
head='''# First Fort Dearborn: complete record/part audit (T-2387 / remaining T-3041)

Read-only audit, frozen before further geometry work. No original picture gate is satisfied. All30 canonical recipe hashes recomputed current; zero accepted reference-view camera files. The existing C0 Kurz panel1 diagnostic includes all30 records (one anchor+29 also_render); it is an initial curtain calibration, not a solved camera. No individual record has a reviewed `matches` receipt. The frozen shared-fort proposal changes seven first-fort records (two chimney removals and five double galleries); that does not represent agreement of the other23.

Inventory: original ticket21 records plus9 existing context records =30;19 roofed buildings and11 works/grounds. `inventory.json` contains exact phases, provenance, polygon, world position, form, asset SHA and recipe verification per record. `first_fort_outer_stable_middle` is a legacy ID for a house, so there are two stable buildings, not three. North range is one building containing soldiers quarters and contractor store. The unlocated guardhouse9, hospital-store14, assistant military-agent-store15 and narrative root houses have not been turned into extra guessed buildings.

Actual images inspected: public-domain Kurz & Allison1893 panel1 (`p4_0.png`); Currey1912 p27 numbered birdseye; Kinzie/fort riverfront composition; all four held Getty pictures; Whistler1808 actual plan with folded elevations (Gutenberg Quaife1913 reproduction); Chicagology's1857 oval print, Kinzie-view engraving and Earle mural; additional Sarony/Currey and Kirkland Kinzie-house images, which show no fort and are not independent fort-elevation witnesses. Hake1936 construction and Strayer Christmas paintings remain modern reference material with unresolved reproduction rights. Getty source/creator correction is in GETTY-FINDINGS.md.

Whistler gives garrison scale20ft/in, Indian Department40ft/in and other outlying buildings not regularly scaled. The folded elevations are positive appearance evidence, but are not extra plan footprints and not metrically exact elevations. Five range fronts face the parade under existing rotations0/90/180/270; no plan move is proposed. Counts are4 north,4 each southern range,5 west officers,4 east commanding range. Opening types and exact metrics remain reconstructed. Whistler's1808 note that blockhouse cupolas were not yet built does not prohibit inferred completion by1812; source/date reconciliation must remain explicit.

| Record | Ticket scope | Actual identification / evidence | Next highest-impact bounded difference |
|---|---|---|---|
'''
(H/'README.md').write_text(head+'\n'.join(rows)+'''\n
All rows share the current camera gap: C0 compound only, no accepted per-part camera/render. Currey interior requires a separate oblique diagnostic and isolation of each numbered part. Kinzie-foreground pictures require north-bank context beyond this30-record south-bank inventory. A group picture cannot serve as evidence that an occluded tiny house matches. Every future render retains the plan and records unresolved drawing contradictions rather than stretching attested measurements.

Roof audit: fort_structure supports gable/hip/pyramid/shed/flat/none but no barrel; magazine cannot be corrected data-only. small_house_ne uses outbuilding, whose supported roofs are only gable/shed; its likely hip likewise requires explicit helper support, not an unsupported `hip` record or archetype swap.
''')
findings='''# Getty / museum verification and bounded source correction

Actual public Getty credit pages were read (four saved HTML/text receipts). Getty labels the three paintings Date created Jan1,1803 and the engraving Jan1,1850, but those catalog fields do not prove original creation years. Getty supplies rights-managed reproductions, not an open license. The held thumbnail does not acquire reuse permission from the historical scene date.

The museum's own public catalog resolves the objects and creators:

| Getty | Museum object and public page | Actual catalog result |
|---|---|---|
|529323671|ICHi-062486 https://images.chicagohistory.org/asset/5857/|Edgar Spier Cameron1862–1944, oil; accession1905.12. Description depicts1803; Date Depicted field1903 conflicts. No creation date established. No Known Copyright.|
|529322537|ICHi-062505 https://images.chicagohistory.org/asset/25650/|Lawrence C.Earle, oil; accession1933.49, gift Central Republic Bank and Trust Company. Date Depicted1803. No Known Copyright. Visually matches Chicagology's full Earle1902 bank mural.|
|529264885|ICHi-059714 https://images.chicagohistory.org/asset/23966/|C.E.Petford, watercolor; accession1896.18. Date Depicted1803, not creation year. No Known Copyright.|
|88810552|ICHi-021562 https://images.chicagohistory.org/asset/12763/|Creator unknown; engraving. Copyright Undetermined; Rights restricted.|

Museum No Known Copyright is the catalog's statement, not proof of publication or a Getty reproduction license. Accession years are not publication years. No underlying work is called pre1850 merely because it depicts1803. The independently published Currey1912 numbered fort illustration is a public-domain book image, distinct from modern/1902 oil painting reproductions. Chicagology identifies the Earle Chicago National Bank mural as1902,16ft×9ft in segmental frames; original1902/1912 publication verification remains a possible follow-up, not a prerequisite for the existing public-domain-based geometry.

No NEW geometry in the frozen shared-fort proposal derives from Getty: first-fort blockhouse chimney removals read Kurz1893 panel1; double galleries read Currey1912 p27 and Whistler1808; second-fort cupola reads Kurz panel5; lighthouse reads Castelnau1842 plate18; Lake House corrects an existing roof-none parameter. Do not delay those on a stock-image rights inference.

`source-ledger-correction.patch` proposes four tightly scoped entries in BOTH existing IMAGE_SOURCES ledgers. It corrects creators, removes unsupported pre1850 assertions and records the museum metadata without claiming an asset license. It does not remove existing files, clear rights, mark a camera matches, or change geometry.
'''
(H/'GETTY-FINDINGS.md').write_text(findings)
patch=[]
updates={
'chicago_fort_dearborn_1803_getty_2.jpg':('Edgar Spier Cameron (1862–1944)','ICHi-062486','5857','Creation year unverified; museum description depicts1803 but its Date Depicted field says1903. Accession1905.12 is not a publication date.','No Known Copyright'),
'chicago_fort_dearborn_1803_getty_3.jpg':('Lawrence C. Earle','ICHi-062505','25650','Museum identifies Earle; the full composition matches the1902 Chicago National Bank mural described by Chicagology. The1803 catalog date describes the scene, not the making.','No Known Copyright'),
'chicago_fort_dearborn_watercolor_1803_getty.jpg':('C. E. Petford','ICHi-059714','23966','Creation year unverified. Museum Date Depicted1803 and accession1896.18 do not establish creation or publication date.','No Known Copyright'),
'chicago_fort_dearborn_1803_getty.jpg':('unknown engraver','ICHi-021562','12763','Getty catalog gives Jan1,1850; the museum establishes no creation/publication date.','Copyright Undetermined; Rights restricted'),
}
for rel in ['chicago/reference/images/IMAGE_SOURCES.md','chicago/reference/planning/images/IMAGE_SOURCES.md']:
 old=(R/rel).read_text();new=old
 for name,(artist,obj,aid,note,rights) in updates.items():
  pat=r'(#### `'+re.escape(name)+r'`\n)(.*?)(?=\n#### |\Z)';m=re.search(pat,new,re.S)
  if not m:raise ValueError(name)
  block=m[2];block=re.sub(r'\*Chicago History Museum\*',f'*{artist}; Chicago History Museum*',block,count=1)
  block=re.sub(r'Rights: Unwatermarked 612px thumbnail\. Underlying pre-1850 artwork is public domain; the agency licenses its scan/reproduction\.',f'Rights: Held Getty thumbnail/reproduction is rights-managed; no open reproduction license verified. Museum catalog: {rights}. Do not derive assets from the held preview without cleared rights.',block,count=1)
  block+=f'\nMuseum object: {obj} · <https://images.chicagohistory.org/asset/{aid}/>  \nDate/identity caution: {note}  \n'
  new=new[:m.start(2)]+block+new[m.end(2):]
 patch+=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(H/'source-ledger-correction.patch').write_text(''.join(patch))
ledger={str(p.relative_to(H)):hashlib.sha256(p.read_bytes()).hexdigest() for p in H.iterdir() if p.is_file() and p.name!='evidence-sha256.json'}
(H/'evidence-sha256.json').write_text(json.dumps(ledger,indent=2)+'\n')
print('Frozen30-row report, actual museum findings and2-ledger scoped correction patch')
