from pathlib import Path
import concurrent.futures,urllib.request
h=Path(__file__).resolve().parent
urls={
'getty-88810552.html':'https://www.gettyimages.com/detail/news-photo/engraving-depicting-the-old-fort-dearborn-originally-built-news-photo/88810552',
'getty-529323671.html':'https://www.gettyimages.com/detail/news-photo/oil-painting-depicting-fort-dearborn-in-1803-news-photo/529323671',
'getty-529322537.html':'https://www.gettyimages.com/detail/news-photo/oil-painting-depicting-the-first-fort-dearborn-in-1803-news-photo/529322537',
'getty-529264885.html':'https://www.gettyimages.com/detail/news-photo/watercolor-depicting-fort-dearborn-in-1803-news-photo/529264885'}
def get(kv):
 n,u=kv
 try:
  with urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=35) as r:d=r.read();status=r.status
  (h/n).write_bytes(d);return n,status,len(d)
 except Exception as e:return n,str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p:
 for r in p.map(get,urls.items()):print(r)
