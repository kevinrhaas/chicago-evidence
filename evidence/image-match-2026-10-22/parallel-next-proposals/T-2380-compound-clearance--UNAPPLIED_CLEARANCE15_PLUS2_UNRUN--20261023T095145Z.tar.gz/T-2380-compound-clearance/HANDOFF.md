# T-2380 compound — light clearance follow-up

Prepared and unapplied. The frozen compound and 22° core packages remain intact. No Blender, browser, assets, canonical edits, ticket updates or image-match verdict.

The combined seven-file patch is `T-2380-compound-clearance.patch`, checked against current canonical inputs. `incremental-from-frozen.patch` contains only the two new context-record refinements plus the public-square permission entries, for an isolated tree already carrying the frozen compound patch. Do not apply both patches to one tree.

## Proposed correction

Move only the newly reconstructed keeper house **0.60 m east and 0.60 m south**, retaining every house dimension, the fixed jail, palisade envelope and north curtain. The final house origin is E447545.0600 / N4637121.4348, bearing0°, relative to the unchanged core Δeast6.85m / Δnorth0.2048m. Adjust the two east-side curtain endpoints to stop at the translated house's south/north walls. The house still overlaps the nominal enclosure by a0.65m strip; the native curtain geometry never crosses its open interior.

This is a functional reconstruction within the already disclosed uncertainty, not a historical measurement. The old proposal's stoop nearly reached the block edge and its door's hand-clearance zone overlapped the palisade's filled collision envelope. Translation fixes those problems without narrowing a historical building, moving the anchored core or altering the street/grid.

The low wicket is **closed**, exactly as the existing proposed `wickets` note and native `_low_wicket` geometry state. Its pose is a reconstructed modelling instant, not an attested condition or an operational gate. No passage is added through it.

## Which line answers each question

`analyze.py` declares `CORRIDOR_LINE = 'both'` and its reason. It calls the real consumer functions with temporary overlays.

| Question | Consumer and line | Result |
|---|---|---|
| Seat within the Public Square/block | `block_faces.face_frame/project`, committed **drawn** block boundary | Palisade envelope north margin0.788m, west2.095m |
| Chosen palisade timber reaches street? | Native raw geometry dimensions, **drawn** north face | Approximately0.698m remains inside; north curtain unchanged |
| Does the plat put roadway beneath a footprint? | `plat_corridors.corridors(from_control=True)` + `intrusion` | Zero for all3 records |
| Does any drawn street run through a footprint? | `check_structure_corridors.laps` and drawn `corridors()` | Zero for all3 records |
| Does a private lot/inset apply here? | Real `plat_occupancy.overlap_area`, actual grid | Public Square is reserved and has **zero lots**, no lot overlap; the private-lot1.5m inset is not a palisade failure |
| Conservative new house block-front wall | Actual world footprint against **drawn** north face |1.544m inside, versus0.948m frozen |
| Native house stoop outside its footprint | Actual `_porch`0.92m projection, conservative box |0.656m inside drawn boundary, versus0.061m frozen |

Randolph's control verdict is `centred`; LaSalle has `no_control`, so this particular location gets identical drawn/control corridor geometry. That coincidence does not erase the distinction. No line was re-centred or moved. The chosen1.5m house wall setback is a conservative functional choice on this reserved square, not an archival setback or newly invented private lot.

The7-file patch adds two explicit entries to `1835_reserved_ground.json`: the actual1902 printedp51 keeper-house sentence and the high-palisade sentence, each naming `gale_1902_jail_walk_text`, with1835/1836 and reconstruction limits. These admit these particular documented components. Native `measure_reserved_ground.measure()` refuses both new records before those entries and has no problems after them; the rule is unchanged.

## Real consumer proof and its limits

The three temporary sidecars are output from the **unmodified actual nested `compile_scene.build_sidecar` function**, extracted with AST solely to avoid unrelated whole-scene writers. It resolves genuine proposed records and citations. Their asset paths are official references to **unbuilt** GLBs. No hand-written stand-in sidecars, empty GLBs or generated fake assets are used. Core placement/footprint output is checked against the committed sidecar. Only proposal records are written; unchanged structure overlay files are read-only symlinks to canonical inputs.

`generate_entrances.build/front_doors/doorway_zones` reads those sidecars and the proposed records using the existing frame/outbuilding facade readers. The translated keeper door's1.52m wide×1.8m deep clear zone has no other footprint blocker; the frozen version overlaps the palisade. Native `measure_doorways` point/segment predicates find no existing placed-layer objects in either proposed door zone. **That existing-object sweep does not read palisade GLB geometry**; the separate footprint check still records the jail's own door zone as intersecting the curtain envelope.

Native `_placed_footprints`/`_wall_on` finds no wall at101 samples over the first25m of Randolph sidewalk, using the real1.83m width and1.165m outward offset. All actual committed north-side footway decks have zero plan-area intersection with the proposed footprints/stoop box. This is a plan test, not an assertion about terrain or step heights; frontage regeneration remains required after integration.

`walker.mjs` imports the **real `footprintsFrom/createWalker`** and actual Three library. Its flat unit-test substrate isolates collision behavior and is explicitly not a generated terrain asset:

| Route | Frozen | Translated candidate |
|---|---|---|
|25m along drawn Randolph sidewalk centre |25m travelled |25m travelled |
|Street-side approach to keeper door centre |Reaches wall,0.040m lateral deflection |Reaches wall, no lateral deflection |
|Final keeper wall standoff |0.342m |0.342m (radius0.34m plus record/output rounding) |
|Street-side approach to jail door |Stopped at palisade envelope |Still stopped |
|Street-side approach to closed low gate |Stopped at palisade envelope |Still stopped |

**The walker consumes the whole palisade footprint as one solid polygon. It does not consume `curtain_runs` or individual wicket rails.** There is no archetype exception or passage here. An inside spawn is pushed outside the entire envelope, and reaching the core door through the yard is unavailable. A closed gate can reasonably stop an outside approach, but that does not make the whole-envelope approximation a working courtyard collision model. No broad walker rewrite, fake open passage or special acceptance exemption is proposed. Future app QA must inspect inside spawning, doorway approaches and actual gate state explicitly.

Native palisade raw geometry remains finite,1390 polygons, with zero projected-area intersection with the keeper house. The translated core/house wall gap is0.754m; conservatively allowing0.25716m core and0.25m house roof extensions leaves0.24684m. The house's actual gable roof ends are flush, so that symmetric box is deliberately conservative. This is a bounded plan check, not a full mesh collision certification.

## Date, picture and remaining acceptance

Gale's actual1902 published plate is independently public domain and captioned1836; printedp51 retrospectively frames the walk in1835 and describes the small jail hidden by a high plank palisade, with John Beach's Randolph-facing house partly inside. July presence remains inferred. No exact1833 compound completion, added-cell date, historical metric or person identity is manufactured. Andreas's separate later oaken cell, fall1835 courthouse and contrasting compound picture remain explicit conflicts. No inference is promoted by these clearance checks.

The original T-2380 grouped comparison still needs real core+house+palisade assets with the frozen source camera. Preserve the fixed optical recipe and the separate22° roof pilot until an actual group render can compare occlusion honestly. House attic/second gable lights, material/facade details, core shape/openings, outer street rail/plankwalk, flagstaff and other source context still differ or need review. No `matches` or completion is written.

## Scope, checks and next integration

The combined patch includes the frozen source, two new structure records, original core change-note correction, guarded palisade builder/params, and public-square list. Only the current core's `change_note` changes; current forms/position/dates and mesh recipe are preserved. It is compatible with the separate roof pilot's scope. Generator/parameter bytes are identical to the frozen compound proposal, retaining its15-master exact default/raw-output parity and14 refusal cases. Shared hash blast remains **15 existing palisade masters**,0 versions, plus2 new masters; no existing frame family is stale. The new follow-up introduces no shared-code change.

Checks: `analysis.log`, `walker.log`, `verify.log`, `analysis.json`, `walker-results.json`, `geometry-lightcheck.json`, `input-hashes.json`, `patch-files.json`. `git apply --check` passes. No canonical derived file is claimed current and no asset has been built.

After parent accepts this isolated candidate: apply one patch to a disposable full fixture, compile actual sidecars/layers, build all affected official-name assets with pinned Blender and run the existing gates; review the same-camera complete source group and actual walker/terrain routes. The current plan clears the public route and keeper entrance; it intentionally does not certify whole-compound accessibility or a picture match.
