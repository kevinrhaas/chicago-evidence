// Actual walker consumer, real temporary compiled proposal sidecars. No fake assets.
import fs from 'node:fs';
import { register } from 'node:module';
import { pathToFileURL } from 'node:url';
const root='/workspace/chicago/chicago/4d';
const base='/tmp/chicago-next-model/T-2380-compound-clearance';
const vendor=pathToFileURL(root+'/renderers/web/vendor/three-0.185.1/').href;
register(`data:text/javascript,${encodeURIComponent(`export function resolve(s,c,next){if(s==='three')return {url:'${vendor}three.module.js',shortCircuit:true};if(s.startsWith('three/addons/'))return {url:'${vendor}addons/'+s.slice(13),shortCircuit:true};return next(s,c);}`)}`,import.meta.url);
const THREE=await import('three');
const {createWalker,footprintsFrom,WALK}=await import(pathToFileURL(root+'/renderers/web/js/walker.js'));
const {createIntent}=await import(pathToFileURL(root+'/renderers/web/js/controls/intent.js'));
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const study=read(base+'/analysis.json');
const flat={walkHeight:()=>0,surfaceHeight:()=>0,isWater:()=>false};
function walk(fp,start,bearing,seconds){
 const camera=new THREE.PerspectiveCamera();
 const w=createWalker({camera,terrain:flat,footprints:fp,spawn:{local_e:start[0],local_n:start[1],yaw_deg:bearing}});
 const intent=createIntent();const points=[];
 for(let i=0;i<seconds*60;i++){intent.forward=1;w.update(1/60,intent);points.push([w.state.e,w.state.n]);}
 return {start,bearing_deg:bearing,seconds,end:points.at(-1),displacement_m:Math.hypot(points.at(-1)[0]-start[0],points.at(-1)[1]-start[1]),points};
}
function settle(fp,start){
 const camera=new THREE.PerspectiveCamera();
 const w=createWalker({camera,terrain:flat,footprints:fp,spawn:{local_e:start[0],local_n:start[1],yaw_deg:0}});
 const intent=createIntent();w.update(1/60,intent);
 return {start,end:[w.state.e,w.state.n]};
}
const out={scope:'Native walker collision with flat unit-test substrate only. No terrain, decks/step heights, generated assets, browser, or visual acceptance.',radius_m:WALK.radius,cases:{}};
const oldSpeed=WALK.speed;WALK.speed=1.0;
try{
 for(const [name,data] of Object.entries(study.cases)){
  const folder=base+'/overlay/'+name+'/compiled-sidecars';
  const registry=new Map(fs.readdirSync(folder).filter(x=>x.endsWith('.json')).map(x=>{const sc=read(folder+'/'+x);return [sc.id,{id:sc.id,sidecar:sc}];}));
  const fp=footprintsFrom(registry);
  const house=data.entrances.find(x=>x.structure_id==='log_jail_keeper_house');
  const jail=data.entrances.find(x=>x.structure_id==='log_jail');
  const origin=[463.07,-268.43],along=[.9999673320745274,-.008082993489538583],outward=[.008082993489538583,.9999673320745274];
  const streetStart=origin.map((x,i)=>x+outward[i]*1.165);
  const publicWalk=walk(fp,streetStart,Math.atan2(along[0],along[1])*180/Math.PI,25);
  const keeper=walk(fp,[house.at_local_enu_m[0],house.at_local_enu_m[1]+6],180,8);
  const core=walk(fp,[jail.at_local_enu_m[0],jail.at_local_enu_m[1]+6],180,8);
  const gate=walk(fp,[472.21,-264.298],180,8);
  out.cases[name]={footprint_ids:fp.map(x=>x.id),palisade_passages:fp.find(x=>x.id==='log_jail_palisade').passages??null,
   publicWalk,keeper,core,gate,insideSpawn:settle(fp,[466.01,-269.67]),
   keeper_door_centre_lateral_error_m:Math.abs(keeper.end[0]-house.at_local_enu_m[0]),
   keeper_wall_standoff_m:keeper.end[1]-house.at_local_enu_m[1]};
 }
}finally{WALK.speed=oldSpeed;}
fs.writeFileSync(base+'/walker-results.json',JSON.stringify(out,null,2)+'\n');
for(const [name,x] of Object.entries(out.cases))console.log(name,JSON.stringify({public_displacement:x.publicWalk.displacement_m,keeper_end:x.keeper.end,keeper_lateral_error:x.keeper_door_centre_lateral_error_m,keeper_standoff:x.keeper_wall_standoff_m,core_end:x.core.end,gate_end:x.gate.end}));
if(out.cases.house_south_east_060.publicWalk.displacement_m<24.99)throw Error('Public route blocked');
if(out.cases.house_south_east_060.keeper_door_centre_lateral_error_m>.001)throw Error('Keeper door centre deflected');
if(Math.abs(out.cases.house_south_east_060.keeper_wall_standoff_m-WALK.radius)>.012)throw Error('Keeper wall approach blocked before capsule reaches wall');
