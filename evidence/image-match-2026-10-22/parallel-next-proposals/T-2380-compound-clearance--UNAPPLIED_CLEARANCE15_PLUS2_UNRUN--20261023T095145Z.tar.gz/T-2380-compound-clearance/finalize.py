from pathlib import Path
import ast, copy, dataclasses, difflib, hashlib, importlib.util, json, math, subprocess, sys, zlib
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;R=Path('/workspace/chicago');D=R/'chicago/4d'
F=Path('/tmp/chicago-next-model/T-2380-compound-next');A=F/'after/chicago/4d'
O=B/'overlay/house_south_east_060';sys.path[:0]=[str(D/'tools'),str(D/'generators')]
import jsonschema,mesh_inputs,plat_occupancy as po
import measure_doorways as md
from archetypes.frame_dwelling_params import from_phase as hp
from archetypes.outbuilding_params import from_phase as op,eave_overhang_m
J=lambda p:json.loads(p.read_text())
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m

pm=module('jailclearance_palisade_params',A/'generators/archetypes/palisade_params.py')
# Reuse the frozen light collector and exact builder functions. This emits only
# temporary numeric arrays, never fake GLBs or stand-in mesh assets.
t=ast.parse((F/'verify.py').read_text());nodes=[n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in ['functions','Collector','capture']]
ns={'ast':ast,'math':math,'zlib':zlib};exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(F/'verify.py'),'exec'),ns)
builder=ns['functions'](A/'generators/archetypes/palisade.py')
pali=J(O/'structures/log_jail_palisade.json');house=J(O/'structures/log_jail_keeper_house.json')
pc=pm.from_phase(pali['phases'][0],pali);pc.validate();h=hp(house['phases'][0],house);h.validate()
raw=ns['capture'](builder,pc,'log_jail_palisade__context_1835')
datum=J(D/'data/datum.json');ph=pali['phases'][0];pe=ph['position']['utm_e']-datum['origin_utm_e'];pn=ph['position']['utm_n']-datum['origin_utm_n']
hw=po.world_polygon(house['phases'][0],datum)
intersections=[]
for i,(points,c,mat,tones) in enumerate(raw):
 plan=[(pe+x,pn+y) for x,y,z in points]
 area=po.overlap_area(plan,hw)
 if area>1e-7:intersections.append([i,area])
assert not intersections,intersections[:10]
assert all(math.isfinite(v) for ps,*_ in raw for p in ps for v in p)
core=J(D/'data/structures/log_jail.json');cp=op(core['phases'][0],core);over=eave_overhang_m(cp.width_m,cp.depth_m)
roofgap=(house['phases'][0]['position']['utm_e']-.25)-(core['phases'][0]['position']['utm_e']+cp.width_m+over)
assert roofgap>.2
schema=J(D/'data/structures.schema.json')
for rec in [house,pali]:jsonschema.validate(rec,schema)
assert house['phases'][0]['documented_range']==J(A/'data/structures/log_jail_keeper_house.json')['phases'][0]['documented_range']
assert not any(k in house for k in ['occupants','person_id','residents'])
analysis=J(B/'analysis.json');chosen=analysis['cases']['house_south_east_060']
for row in chosen['records'].values():
 assert row['drawn_platted_intrusion'][0] is None
 assert row['control_platted_intrusion'][0] is None
 assert not row['all_drawn_street_laps']
 assert not row['lot_overlaps']
assert not chosen['street_edge_025m_probes']['wall_hits']
assert not chosen['reserved_after_correction']
assert chosen['house_stoop_drawn_north_margin_m']>.65
assert not next(x for x in chosen['entrances'] if x['structure_id']==house['id'])['zone_blockers']
zones=J(O/'doorway-zones.json');existing_hits=[]
for eid,ring in zones:
 for layer,oid,kind,pt,seg,serves in md.objects():
  if serves==eid.split('__')[0]:continue
  if (md._inside(pt,ring) if pt is not None else md._seg_inside(*seg,ring)):
   existing_hits.append([eid,layer,oid,kind])
assert not existing_hits,existing_hits
town=J(D/'data/frontage/town_street_edge.json');deckhits=[];deckcount=0
footprints={s:r['footprint'] for s,r in chosen['records'].items()}
footprints['house_stoop_conservative_box']=chosen['house_stoop_conservative_box']
for walk in town['walks']:
 if not walk['id'].startswith('blk_randolph_lasalle_north_walk'):continue
 for deck in walk.get('footway_decks',[]):
  deckcount+=1
  for sid,poly in footprints.items():
   a=po.overlap_area(poly,deck['pts'])
   if a>1e-6:deckhits.append([walk['id'],sid,a])
assert deckcount and not deckhits,deckhits

targets={}
for p in A.rglob('*'):
 if p.is_file() and p.suffix in ['.json','.py']:targets[p.relative_to(A)]=p.read_text()
for sid in ['log_jail_keeper_house','log_jail_palisade']:
 rel=Path('data/structures')/f'{sid}.json';targets[rel]=(O/'structures'/f'{sid}.json').read_text()
# Preserve any concurrent legitimate core edits, changing only compound census prose.
fixed=copy.deepcopy(core);fixed['phases'][0]['change_note']=J(A/'data/structures/log_jail.json')['phases'][0]['change_note']
targets[Path('data/structures/log_jail.json')]=json.dumps(fixed,indent=2,ensure_ascii=False)+'\n'
assert mesh_inputs.structure_inputs_doc(core,core['phases'][0])==mesh_inputs.structure_inputs_doc(fixed,fixed['phases'][0])
targets[Path('data/reconstruction/1835_reserved_ground.json')]=(B/'proposed-reserved-ground.json').read_text()
patch=[];files=[]
for rel,after in sorted(targets.items()):
 canonical=D/rel;before=canonical.read_text() if canonical.exists() else ''
 dump_path=B/'candidate/chicago/4d'/rel;dump_path.parent.mkdir(parents=True,exist_ok=True);dump_path.write_text(after)
 if before==after:continue
 name='chicago/4d/'+str(rel)
 patch.append('diff --git a/'+name+' b/'+name+'\n')
 if not canonical.exists():patch.append('new file mode 100644\n')
 patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+name if before else '/dev/null',tofile='b/'+name))
 files.append({'path':name,'before_sha256':sha(canonical) if canonical.exists() else None,'after_sha256':sha(dump_path)})
out=B/'T-2380-compound-clearance.patch';out.write_text(''.join(patch));dump(B/'patch-files.json',files)
subprocess.run(['git','apply','--check',str(out)],cwd=R,check=True,capture_output=True)
# An incremental patch for parent already carrying the frozen compound in an isolated tree.
inc=[]
for rel in [Path('data/structures/log_jail_keeper_house.json'),Path('data/structures/log_jail_palisade.json')]:
 before=(A/rel).read_text();after=targets[rel];name='chicago/4d/'+str(rel)
 inc.append('diff --git a/'+name+' b/'+name+'\n');inc.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
rel=Path('data/reconstruction/1835_reserved_ground.json');name='chicago/4d/'+str(rel)
inc.append('diff --git a/'+name+' b/'+name+'\n');inc.extend(difflib.unified_diff((D/rel).read_text().splitlines(True),targets[rel].splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(B/'incremental-from-frozen.patch').write_text(''.join(inc))
dump(B/'geometry-lightcheck.json',{'raw_palisade_polygons':len(raw),'house_overlap_polygons':intersections,'core_house_wall_gap_m':round(house['phases'][0]['position']['utm_e']-core['phases'][0]['position']['utm_e']-cp.width_m,6),'core_eave_m':over,'house_eave_m':.25,'conservative_axis_roof_gap_m':round(roofgap,6),'actual_committed_north_footway_decks_checked':deckcount,'deck_overlap_hits':deckhits,'existing_objects_native_doorway_sweep_hits':existing_hits,'palisade_code_unchanged_from_frozen':True,'core_recipe_unchanged':True,'patch_files':len(files)})
print('PASS native temporary compilation, both corridor questions, all drawn roads, no private lots, native entrances, frontage footprint march, reserved-ground overlay.')
print('PASS finite native palisade raw geometry; zero projected-area intersection with house; conservative core/house roof gap',round(roofgap,6),'m.')
print('PASS new records schema/house+palisade parameters; dates and identity limits preserved; unchanged core recipe; seven-file patch applies to current canonical inputs.')
print('UNRUN: actual meshes, terrain/stoop step heights, full derived producers, browser, Blender, assets and original image-match gate. No canonical writes.')
