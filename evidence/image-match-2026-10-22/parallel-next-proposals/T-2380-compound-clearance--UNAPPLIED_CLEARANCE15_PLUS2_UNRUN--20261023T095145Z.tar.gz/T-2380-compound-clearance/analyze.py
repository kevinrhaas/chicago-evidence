"""Light consumer study. Canonical inputs are read only; no assets are generated."""
from pathlib import Path
import ast, copy, datetime as dt, hashlib, json, math, sys
sys.dont_write_bytecode=True

B=Path(__file__).resolve().parent
R=Path('/workspace/chicago'); D=R/'chicago/4d'
F=Path('/tmp/chicago-next-model/T-2380-compound-next/after/chicago/4d')
sys.path[:0]=[str(D/'tools'),str(D/'generators')]
import compile_scene as cs
import plat_corridors as pc
import plat_occupancy as po
import check_structure_corridors as csc
import generate_entrances as ge
import generate_business_signboards as gbs
import generate_frontage_works as gfw
import measure_reserved_ground as mrg
from block_faces import face_frame, project

CORRIDOR_LINE='both'
CORRIDOR_LINE_WHY='Drawn line seats block/frontage and walking tests; control line separately asks platted roadway intrusion. Neither moves.'

def load(p):return json.loads(p.read_text())
def dump(p,x):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

datum=load(D/'data/datum.json');scene=load(D/'data/scenes/1835.json')
grid=load(D/'data/traces/vectors/thompson_lots.json')
block=next(x for x in grid['blocks'] if x['id']=='blk_randolph_lasalle')
frames={f:face_frame(block,f) for f in ['north','west']}
original={s:load(F/'data/structures'/f'{s}.json') for s in ['log_jail','log_jail_keeper_house','log_jail_palisade']}
chosen=copy.deepcopy(original)
hp=chosen['log_jail_keeper_house']['phases'][0]
# Move only the newly reconstructed context, preserving every chosen house dimension.
hp['position']['utm_n']=round(hp['position']['utm_n']-.6,4)
hp['position']['utm_e']=round(hp['position']['utm_e']+.6,4)
hp['position']['note']=hp['position']['note'].replace('Δeast=6.25m, Δnorth=0.8048m','Δeast=6.85m, Δnorth=0.2048m').replace('The north edge must be checked against the committed drawn Randolph frontage/corridor before integration.','The light consumer follow-up measures the front wall 1.54m inside the drawn Randolph block edge; the kit’s 0.92m stoop remains at least0.65m inside. Actual mesh/terrain comparison remains open.')
hp['position']['note']+=' CLEARANCE FOLLOW-UP: the proposed house alone moved 0.60m south and0.60m east from the initial compound trial, retaining chosen dimensions and fixed jail. Its end-biased door and hand clearances now clear the palisade’s filled walker envelope. The house remains partly inside the nominal enclosure. The Public Square has no lots;1.5m is used conservatively for this house’s block-front wall, not asserted as an archival setback or a private-lot rule on this reserved square. This is an explicit functional reconstruction, not a measured historical separation.'
pf=chosen['log_jail_palisade']['phases'][0]['form']
pf['curtain_runs']['value'][1][3]=.5548
pf['curtain_runs']['value'][2][1]=4.822
pf['curtain_runs']['note']+=' CLEARANCE FOLLOW-UP: house alone is moved 0.60m south, with these two east-side curtain endpoints following its chosen south and north walls. Envelope, fixed core, north curtain, gate and all historical evidence grades stay unchanged.'
ppos=chosen['log_jail_palisade']['phases'][0]['position']
ppos['note']=ppos['note'].replace('The north edge must be checked against the committed drawn Randolph frontage/corridor before integration.','Light native consumers measure the north envelope0.79m inside the drawn Randolph block edge; the chosen0.18m timbers remain approximately0.70m inside. Both drawn/control roadway-intrusion tests are clear. The Public Square has no lots, so no private-lot margin is asserted for this curtain. This does not certify mesh/terrain clearance or make the filled walker envelope a model of a walkable courtyard.')
palrec=chosen['log_jail_palisade']
palrec['research_note']=palrec['research_note'].replace('Street-facing north edge is 0.70m beyond the fixed core’s north wall: based on the anchor’s stated 1.5m setback this leaves about 0.8m to the drawn frontage, which is NOT a certified street/lot-margin pass. Exact corridor and walking clearances must be checked before integration.','Light consumers place the north envelope0.788m inside the drawn Randolph block edge (chosen timber approximately0.698m inside), with zero drawn/control roadway intrusion. This reserved square has no lots; the1.5m private-lot inset is not asserted for this curtain. Walker collision currently consumes the entire footprint envelope, not individual curtain runs or the low wicket. The closed wicket is a reconstructed static instant; jail-door/gate approach is stopped at the outer envelope, and an inside spawn would be pushed to that envelope. The translated keeper-house door and existing public sidewalk remain approachable in the flat collision test. Full mesh/terrain/inside-yard behavior and grouped image review remain open.')

# Use the actual nested compiler, unmodified. Extracting the single function avoids
# invoking compile_scene's unrelated town/people/layer writers. Complete output is
# real producer output; its asset reference is NOT a claim that a GLB exists.
tree=ast.parse((D/'tools/compile_scene.py').read_text())
outer=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='compile_scene')
node=next(x for x in outer.body if isinstance(x,ast.FunctionDef) and x.name=='build_sidecar')
sources={}
def collect(n):
 if isinstance(n,dict):
  for s in n.get('sources',[]) or []:
   if s not in sources:
    p=F/'data/sources'/f'{s}.json'
    if not p.exists():p=D/'data/sources'/f'{s}.json'
    sources[s]=load(p)
  for v in n.values():collect(v)
 elif isinstance(n,list):
  for v in n:collect(v)
for r in chosen.values():collect(r)
ns=dict(vars(cs));ns.update(scene_id='1835',scene=scene,target=dt.date(1835,7,1),datum=datum,
 residents={},lodging={},trade_roofs_unseatable={},sources=sources,
 structure_names={s:r['name'] for s,r in chosen.items()})
exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(D/'tools/compile_scene.py'),'exec'),ns)
build_sidecar=ns['build_sidecar']

drawn=pc.corridors();control=pc.corridors(from_control=True)
streets=load(D/'data/streets/1835.json')
all_existing=po.footprints(datum)
def footprint_row(sid,record):
 ph=record['phases'][0];world=po.world_polygon(ph,datum)
 margins={f:round(-max(project(fr,p)[1] for p in world),5) for f,fr in frames.items()}
 return {'footprint':world,'drawn_block_margin_m':margins,
  'drawn_platted_intrusion':pc.intrusion(world,drawn),
  'control_platted_intrusion':pc.intrusion(world,control),
  'all_drawn_street_laps':csc.laps({sid:record},streets,datum),
  'lot_overlaps':[(b['id'],i,round(a,5)) for b in grid['blocks'] for i,l in enumerate(b['lots']) if (a:=po.overlap_area(world,l['polygon']))>po.SLIVER_M2]}

result={'scope':'Light metadata/footprint consumers only. No GLBs, terrain sampling, mesh collisions, bake, browser, or matches verdict.',
 'corridor_line':CORRIDOR_LINE,'corridor_line_why':CORRIDOR_LINE_WHY,
 'square_reserved':block['reserved'],'square_lots':len(block['lots']),
 'lot_margin_m':po.LOT_MARGIN_M,'corridor_control':{s:control[s]['control_verdict'] for s in ['randolph','lasalle']},
 'cases':{}}

for case,records in [('frozen',original),('house_south_east_060',chosen)]:
 out=B/'overlay'/case
 structure_dir=out/'structures';structure_dir.mkdir(parents=True,exist_ok=True)
 # Real record overlay: symlink unchanged canonical records, write only proposed
 # replacements/new records. Nothing canonical can be overwritten through a link.
 for p in (D/'data/structures').glob('*.json'):
  if p.stem not in records and not (structure_dir/p.name).exists():(structure_dir/p.name).symlink_to(p)
 for s,r in records.items():dump(structure_dir/f'{s}.json',r)
 scs=[build_sidecar(r,r['phases'][0]) for r in records.values()]
 for sc in scs:dump(out/'compiled-sidecars'/f"{sc['id']}.json",sc)
 canonical=load(D/'data/sidecars/1835/log_jail.json')
 pilot=next(s for s in scs if s['id']=='log_jail')
 for key in ['local_e','local_n','rotation_deg']:assert pilot['placement'][key]==canonical['placement'][key]
 assert pilot['footprint']==canonical['footprint']
 gbs.STRUCTURES=structure_dir
 ge._sidecars=lambda:scs
 ent=ge.build();zones=ge.doorway_zones()
 dump(out/'entrance-consumer-output.json',ent);dump(out/'doorway-zones.json',zones)
 gfw.SIDECARS=out/'compiled-sidecars'
 buildings=gfw._placed_footprints()
 assert {b['id'] for b in buildings}==set(records)
 prior_fp=mrg.footprints;prior_load=mrg.load
 overlayfp=[(s,p) for s,p in all_existing if s not in records]+[(s,po.world_polygon(r['phases'][0],datum)) for s,r in records.items()]
 mrg.footprints=lambda _datum:overlayfp
 reserved=load(D/'data/reconstruction/1835_reserved_ground.json')
 base_reserved_rows,base_reserved_problems=mrg.measure()
 for s in ['log_jail_keeper_house','log_jail_palisade']:
  why=('Gale, Reminiscences (1902), actual printed p51, says John Beach occupies a house partly in the same enclosure, facing Randolph (source gale_1902_jail_walk_text). This admits that particular keeper-house component, not a person/household link or private dwelling programme.' if s=='log_jail_keeper_house' else 'Gale, Reminiscences (1902), actual printed p51, describes the small log jail as concealed within a high plank palisade (source gale_1902_jail_walk_text). This admits that particular jail boundary, not a military work or anonymous enclosure.')
  why+=' Presence in July1835 remains inferred from the retrospective1835 walk; the independent illustration is explicitly captioned1836. Shape and relative position are reconstructed, with the original core fixed.'
  next(b for b in reserved['blocks'] if b['block_id']==block['id'])['what_may_stand_here']['permitted'].append({'structure_id':s,'why':why})
 mrg.load=lambda p:reserved if p==mrg.RESERVED_PATH else prior_load(p)
 fixed_reserved_rows,fixed_reserved_problems=mrg.measure()
 mrg.footprints=prior_fp;mrg.load=prior_load
 rows={s:footprint_row(s,r) for s,r in records.items()}
 for x in ent['entrances']:
  # Exact current consumer doorway zone has a rounded wall point (to 0.01m).
  zone=next(z for eid,z in zones if eid==x['id'])
  x['zone_blockers']=[b['id'] for b in buildings if b['id']!=x['structure_id'] and po.overlap_area(zone,b['pts'])>.000001]
 house=next(x for x in ent['entrances'] if x['structure_id']=='log_jail_keeper_house')
 he,hn=house['at_local_enu_m'];stoop=[[he-.775,hn],[he+.775,hn],[he+.775,hn+.92],[he-.775,hn+.92]]
 # Conservative enclosing stoop box; lower step is actually 0.09m narrower.
 stoop_margin=-max(project(frames['north'],p)[1] for p in stoop)
 pali=records['log_jail_palisade']['phases'][0];pworld=rows['log_jail_palisade']['footprint']
 # Stockade plank half-thickness is 0.09m for this chosen 0.18m picket width.
 wood_margin=rows['log_jail_palisade']['drawn_block_margin_m']['north']-.09
 # Existing street-edge consumer, tested at every 0.25m along the affected span
 # and its full 1.83m width via the unchanged _wall_on function.
 span=(0.,25.);fr=frames['north'];hits=[]
 for i in range(101):
  t=i*.25;point=gfw._point_on(fr,t,gfw.EDGE_OFFSET_M)
  wall=gfw._wall_on(point,gfw.WALK_W_M/2,fr['outward'],buildings)
  if wall:hits.append([t,wall])
 result['cases'][case]={'records':rows,'entrances':ent['entrances'],'entrance_unread':ent['unread'],
  'house_stoop_conservative_box':stoop,'house_stoop_drawn_north_margin_m':round(stoop_margin,5),
  'palisade_chosen_wood_drawn_north_margin_m':round(wood_margin,5),
  'street_edge_025m_probes':{'span_m':span,'count':101,'deck_width_m':gfw.WALK_W_M,'offset_m':gfw.EDGE_OFFSET_M,'wall_hits':hits},
  'reserved_before_correction':base_reserved_problems,'reserved_after_correction':fixed_reserved_problems}
 if case=='house_south_east_060':dump(B/'proposed-reserved-ground.json',reserved)

dump(B/'analysis.json',result)
dump(B/'input-hashes.json',{str(p):sha(p) for p in [D/'tools/compile_scene.py',D/'tools/plat_corridors.py',D/'tools/plat_occupancy.py',D/'tools/generate_entrances.py',D/'tools/generate_business_signboards.py',D/'tools/generate_frontage_works.py',D/'tools/check_structure_corridors.py',D/'tools/measure_reserved_ground.py',D/'renderers/web/js/walker.js',D/'data/streets/1835.json',D/'data/traces/vectors/thompson_lots.json',D/'data/reconstruction/1835_reserved_ground.json']})
print(json.dumps({c:{'margins':{s:r['drawn_block_margin_m'] for s,r in x['records'].items()},'stoop':x['house_stoop_drawn_north_margin_m'],'wood':x['palisade_chosen_wood_drawn_north_margin_m'],'entrances':x['entrances'],'edge_hits':x['street_edge_025m_probes']['wall_hits'],'reserved_after':x['reserved_after_correction']} for c,x in result['cases'].items()},indent=2))
