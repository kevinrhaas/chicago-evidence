# Read GLB JSON chunks only, never binary geometry, for current1835 batch compatibility.
from pathlib import Path
import hashlib,json,struct
H=Path(__file__).resolve().parent;R=Path('/workspace/worktrees/t2373-lighthouse/chicago/4d')
index=json.loads((R/'data/sidecars/1835/index.json').read_text());blend=[];missing=[];transmission=[];unmodeled=[]
for row in index['structures']:
 if row['asset'] is None:unmodeled.append(row['id']);continue
 p=R/'assets'/row['asset']
 if not p.exists():missing.append(str(p));continue
 with p.open('rb') as f:
  magic,version,total=struct.unpack('<III',f.read(12));size,kind=struct.unpack('<II',f.read(8));assert magic==0x46546c67 and version==2 and kind==0x4e4f534a
  j=json.loads(f.read(size))
 for m in j.get('materials',[]):
  if m.get('alphaMode','OPAQUE')=='BLEND':blend.append({'structure_id':row['id'],'material':m.get('name'),'alpha':m.get('pbrMetallicRoughness',{}).get('baseColorFactor',[1,1,1,1])[3]})
  if m.get('extensions',{}).get('KHR_materials_transmission',{}).get('transmissionFactor',0)>0:transmission.append({'structure_id':row['id'],'material':m.get('name')})
assert not missing,missing
paths=['renderers/web/js/buildings.js','renderers/web/js/glass.js','renderers/web/js/confidence.js','renderers/web/vendor/three-0.185.1/addons/loaders/GLTFLoader.js']
report={'status':'passed','source_head':'a5cae2adc766425103151debd8ef57b152d70022','structures_read':len(index['structures']),'read_GLTF_JSON_chunks_only':True,'no_asset_records':unmodeled,'current_BLENDruntime_candidates':blend,'current_transmission_candidates':transmission,'interpretation':'If there are no current BLEND/transmission building materials, the single proposed0.18-alpha lantern cannot merge with an existing different-opacity transparent building batch in this1835 source state. This is point-in-time evidence, not a general materialKey guarantee. Recheck after tree/asset changes; no runtime key edit proposed.','read_only_helpers':[{'path':p,'sha256':hashlib.sha256((R/p).read_bytes()).hexdigest()} for p in paths]}
(H/'current1835-material-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
