from pathlib import Path
from types import ModuleType,SimpleNamespace
from dataclasses import asdict,replace
import ast,copy,inspect,json,math,sys,subprocess,hashlib
import numpy as np,jsonschema
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;R=Path('/workspace/worktrees/t2373-lighthouse/chicago/4d');pr='chicago/4d/generators/archetypes/fort_structure_params.py';gr='chicago/4d/generators/archetypes/fort_structure.py';rr='chicago/4d/data/structures/chicago_lighthouse_1832.json'
def load(p,name):
 m=ModuleType(name);sys.modules[name]=m;exec(compile(p.read_text(),str(p),'exec'),m.__dict__);return m
old=load(H/'baseline'/pr,'lantern_before');new=load(H/'candidate'/pr,'lantern_after')
assert old.FortStructureParams.__match_args__==new.FortStructureParams.__match_args__
assert len(new.FortStructureParams.__match_args__)==16
assert new.CONSUMED==old.CONSUMED|{'tower_lantern_detail'}
for key,p in inspect.signature(new.FortStructureParams).parameters.items():
 if key=='tower_lantern_detail':assert p.kind==inspect.Parameter.KEYWORD_ONLY and p.default is None
 else:assert p==inspect.signature(old.FortStructureParams).parameters[key]
manifest=json.loads((R/'assets/manifest.json').read_text());family=[]
for asset,row in manifest['assets'].items():
 if row.get('archetype')=='fort_structure':family.append((asset,row))
assert len(family)==25,len(family)
phases=[]
for asset,row in family:
 rec=json.loads((R/'data/structures'/f"{row['structure_id']}.json").read_text());ph=next(p for p in rec['phases'] if p['id']==row['phase_id']);a=old.from_phase(ph,rec);b=new.from_phase(ph,rec);d=asdict(b);assert d.pop('tower_lantern_detail') is None;assert d==asdict(a)
 legacy=new.FortStructureParams(*[getattr(a,k) for k in a.__match_args__],**{k:getattr(a,k) for k,p in inspect.signature(old.FortStructureParams).parameters.items() if p.kind==inspect.Parameter.KEYWORD_ONLY});legacy.validate();dd=asdict(legacy);assert dd.pop('tower_lantern_detail') is None;assert dd==asdict(a);phases.append((a,b))
def funcs(path):return {n.name:n for n in ast.parse(path.read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
af,bf=funcs(H/'baseline'/gr),funcs(H/'candidate'/gr)
assert set(bf)==set(af)|{'_birdcage_clear_detail','_configure_cage_glass'}
for key in af:
 if key not in {'build','_birdcage_partitioned'}:assert ast.dump(af[key])==ast.dump(bf[key]),key
# Existing build behavior and partition helper AST are identical after removing ONLY opt-in branches.
ob=copy.deepcopy(bf['build']);ob.body=[n for n in ob.body if not(isinstance(n,ast.If) and isinstance(n.test,ast.Compare) and isinstance(n.test.left,ast.Attribute) and n.test.left.attr=='tower_lantern_detail')]
assert ast.dump(ob.body[-2].value)==ast.dump(af['build'].body[-1].value)
part=copy.deepcopy(bf['_birdcage_partitioned']);part.body=[n for n in part.body if not(isinstance(n,ast.If) and isinstance(n.test,ast.Compare) and isinstance(n.test.left,ast.Attribute) and n.test.left.attr=='tower_lantern_detail')];assert ast.dump(part)==ast.dump(af['_birdcage_partitioned'])
sys.path.insert(0,str(R/'generators'));from common import openings
class Collect:
 def __init__(self):self.faces=[];self.named={}
 def named_mat(self,name,*spec):self.named.setdefault(name,(1000+len(self.named),spec));return self.named[name][0]
 def add_poly(self,points,confidence,mat=0):self.faces.append((tuple(tuple(float(v) for v in p) for p in points),float(confidence),mat));return list(range(len(points)))
box=next(n for n in next(n for n in ast.parse((R/'generators/common/mesh.py').read_text()).body if isinstance(n,ast.ClassDef) and n.name=='MeshBuilder').body if isinstance(n,ast.FunctionDef) and n.name=='add_box');ns={};exec(compile(ast.Module(body=[box],type_ignores=[]),'<actual add_box>','exec'),ns);Collect.add_box=ns['add_box']
def extract(fs,mod):
 names=['_tower','_birdcage_lantern','_TowerFacetBuilder','_tower_apertures','_birdcage_partitioned','_birdcage_clear_detail','_configure_cage_glass'];tree=ast.Module(body=[copy.deepcopy(fs[k]) for k in names if k in fs],type_ignores=[])
 ns={'math':math,'openings':openings,'M_WALL':0,'M_ROOF':1,'M_DARK':2,'M_TRIM':3,'tower_opening_layout':mod.tower_opening_layout};exec(compile('from __future__ import annotations\n'+ast.unparse(tree),'<actual tower>', 'exec'),ns);return ns
xo,xn=extract(af,old),extract(bf,new)
for a,b in phases:
 if a.kind!='tower':continue
 for profile,lit in [('legacy',False),('legacy',True),('birdcage_dome',True)]:
  ca,cb=Collect(),Collect();xo['_tower'](ca,replace(a,lantern_profile=profile,lantern=lit));xn['_tower'](cb,replace(b,lantern_profile=profile,lantern=lit));assert ca.faces==cb.faces and ca.named==cb.named
base=json.loads((H/'baseline'/rr).read_text());candidate=json.loads((H/'candidate'/rr).read_text());a=old.from_phase(base['phases'][0],base);p=new.from_phase(candidate['phases'][0],candidate);before,disabled,after=Collect(),Collect(),Collect();xo['_tower'](before,a);xn['_tower'](disabled,replace(p,tower_lantern_detail=None));xn['_tower'](after,p);assert before.faces==disabled.faces and before.named==disabled.named
for key in base:
 if key!='phases':assert candidate[key]==base[key],key
bph,cph=base['phases'][0],candidate['phases'][0]
for key in bph:
 if key!='form':assert bph[key]==cph[key],key
assert {k:v for k,v in cph['form'].items() if k!='tower_lantern_detail'}==bph['form']
def bounds(col):
 vs=[v for poly,_,_ in col.faces for v in poly];return [[min(v[i] for v in vs) for i in range(3)],[max(v[i] for v in vs) for i in range(3)]]
assert np.allclose(bounds(before),bounds(after),rtol=0,atol=1e-12)
feet=lambda col:sorted(set(v for poly,_,_ in col.faces for v in poly if abs(v[2])<1e-9));assert feet(before)==feet(after)
for poly,c,mat in after.faces:
 assert c==1 and np.isfinite(np.array(poly)).all()
 for i in range(1,len(poly)-1):assert np.linalg.norm(np.cross(np.array(poly[i])-poly[0],np.array(poly[i+1])-poly[0]))>1e-10
# Material alpha must affect only the named lantern cage; common/shaft glass remains opaque.
alpha=SimpleNamespace(default_value=1);node=SimpleNamespace(inputs={'Alpha':alpha});mat=SimpleNamespace(name='lantern_cage_glass',node_tree=SimpleNamespace(nodes={'Principled BSDF':node}),diffuse_color=(.1134,.1164,.1144,1),surface_render_method=None);shaft_mat=SimpleNamespace(name='lantern_glass',diffuse_color=(.1134,.1164,.1144,1));xn['_configure_cage_glass'](SimpleNamespace(data=SimpleNamespace(materials=[shaft_mat,mat])),p);assert alpha.default_value==.18 and mat.diffuse_color[3]==.18 and shaft_mat.diffuse_color[3]==1 and mat.surface_render_method=='DITHERED'
for bad in [True,{},dict(p.tower_lantern_detail,pane_opacity=1),dict(p.tower_lantern_detail,cage_uprights=12.5),dict(p.tower_lantern_detail,dome_rise_m=99),dict(p.tower_lantern_detail,sill_height_m=float('nan'))]:
 try:replace(p,tower_lantern_detail=bad).validate()
 except new.ParamError:pass
 else:raise AssertionError(bad)
for changed in [{'kind':'quarters'},{'lantern':False},{'tower_profile':None},{'tower_profile':{}}]:
 try:replace(p,**changed).validate()
 except new.ParamError:pass
 else:raise AssertionError(changed)
jsonschema.validate(candidate,json.loads((R/'data/structures.schema.json').read_text()))
r=subprocess.run(['git','apply','--check',str(H/'lantern-detail-next.patch')],cwd=H/'baseline',text=True,capture_output=True);assert r.returncode==0,r.stderr
cam=json.loads((H/'camera-profile-research.json').read_text());prev=Path('/tmp/chicago-next-model/T-2373-lighthouse-M-profile-prepared-20261023/camera-profile-research.json');assert (H/'camera-profile-research.json').read_bytes()==prev.read_bytes()
y=lambda z:cam['principal_px'][1]-cam['focal_px']/102.8*(z-2)
result={'status':'passed','current25records_default_parameter_and_API_parity':len(phases),'legacy16positional_and_all_previous_keyword_fields_preserved':True,'new_field_keyword_only':True,'all_old_non_tower_geometry_functions_AST_equal':True,'old_tower3profile_geometry_and_named_materials_exact':True,'prior_profile_geometry_exact_when_detail_disabled':True,'only_lantern_detail_attribute_added_to_record':True,'all_prior_profile_height_position_dates_footprint_and_windows_exact':True,'overall_bounds_m':bounds(after),'ground_feet_equal':True,'triangles_before':sum(len(poly)-2 for poly,_,_ in before.faces),'triangles_after':sum(len(poly)-2 for poly,_,_ in after.faces),'all_new_triangles_finite_nondegenerate_reconstructed':True,'lantern_material_only_alpha_configuration_proof':True,'camera_bytes_fixed':True,'diagnostic_y':{'gallery_underside':y(p.tower_shaft_height_m),'cap_base':y(p.tower_profile['cap_base_m']),'dome_apex':y(p.tower_profile['cap_base_m']+p.tower_lantern_detail['dome_rise_m']),'finial_max':y(bounds(after)[1][2])},'actual_export_render_and_GLTFLoader_contract':'UNRUN_pending_explicit_heavy_slot'}
(H/'light-check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
