from pathlib import Path
import ast,hashlib,json,shutil,subprocess
H=Path(__file__).resolve().parent
PRE=Path('/tmp/chicago-next-model/T-2373-lighthouse-M-profile-prepared-20261023')
R=Path((PRE/'latest-run.txt').read_text().strip())
paths=['chicago/4d/generators/archetypes/fort_structure_params.py','chicago/4d/generators/archetypes/fort_structure.py','chicago/4d/data/structures/chicago_lighthouse_1832.json']
for rel in paths:
 for kind in ['baseline','candidate']:
  dest=H/kind/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/'proposed'/Path(rel).relative_to('chicago/4d'),dest)
p=H/'candidate'/paths[0];s=p.read_text();s=s.replace('"tower_profile", "face_openings",','"tower_profile", "tower_lantern_detail", "face_openings",')
needle='    tower_profile: dict | None = field(default=None, kw_only=True)'
assert s.count(needle)==1
s=s.replace(needle,needle+'\n\n    # Lighthouse-only source-shaped cage/scantlings; None preserves old meshes.\n    tower_lantern_detail: dict | None = field(default=None, kw_only=True)')
needle='        if self.tower_openings is not None:\n'
validation='''        if self.tower_lantern_detail is not None:
            if (self.kind != "tower" or not self.lantern or
                    self.lantern_profile != "birdcage_dome" or self.tower_profile is None):
                raise ParamError("tower_lantern_detail requires a partitioned birdcage tower")
            d = self.tower_lantern_detail
            keys = {"pane_opacity", "sill_height_m", "dome_rise_m", "cage_uprights",
                    "cage_member_m", "gallery_posts", "gallery_member_m", "finial_radius_m"}
            if not isinstance(d, dict) or set(d) != keys:
                raise ParamError("tower_lantern_detail needs the eight declared detail controls")
            if any(isinstance(v, bool) or not isinstance(v, (float, int)) or not math.isfinite(v)
                   for v in d.values()):
                raise ParamError("tower_lantern_detail controls must be finite numbers")
            if any(not isinstance(d[k], int) or not 6 <= d[k] <= 32
                   for k in ("cage_uprights", "gallery_posts")):
                raise ParamError("lantern member counts must be integers in6..32")
            if not (.02 <= d["pane_opacity"] <= .65 and .04 <= d["sill_height_m"] <= .4
                    and .02 <= d["cage_member_m"] <= .1 and .02 <= d["gallery_member_m"] <= .1
                    and .01 <= d["finial_radius_m"] <= .04):
                raise ParamError("lantern detail controls out of reconstructed bounds")
            r1 = (self.tower_diameter_m if self.tower_diameter_m is not None else self.width_m)/2*self.taper
            cap_total = self.wall_height_m+r1*.7-self.tower_profile["cap_base_m"]
            if not (.3 <= d["dome_rise_m"] < cap_total-.2):
                raise ParamError("dome must leave at least0.2m finial within unchanged maximum")
'''
assert s.count(needle)==1;s=s.replace(needle,validation+needle)
needle='        tower_profile=val("tower_profile", None),';assert s.count(needle)==1;s=s.replace(needle,needle+'\n        tower_lantern_detail=val("tower_lantern_detail", None),');p.write_text(s)
p=H/'candidate'/paths[1];s=p.read_text();needle='    return b.to_object(mats)';assert s.count(needle)==1;s=s.replace(needle,'''    ob = b.to_object(mats)
    if params.tower_lantern_detail is not None:
        _configure_cage_glass(ob, params)
    return ob''')
needle='    cap_base = p.tower_profile[\'cap_base_m\']';assert s.count(needle)==1
s=s.replace(needle,'''    if p.tower_lantern_detail is not None:
        _birdcage_clear_detail(b, p, cx, cy, r1, shaft, h)
        return
'''+needle)
node=next(n for n in ast.parse(s).body if isinstance(n,ast.FunctionDef) and n.name=='_birdcage_partitioned')
helper=ast.get_source_segment(s,node)
helper=helper.replace('def _birdcage_partitioned(', 'def _birdcage_clear_detail(')
start=helper.index('    if p.tower_lantern_detail is not None:');end=helper.index('    cap_base =',start);helper=helper[:start]+helper[end:]
helper=helper.replace('    cap_base =', '    d = p.tower_lantern_detail\n    cap_base =',1)
helper=helper.replace("glass = b.named_mat('lantern_glass', *openings.glass_material_spec())","glass = b.named_mat('lantern_cage_glass', *openings.glass_material_spec())")
helper=helper.replace('b.add_poly([lower[i], lower[j], upper[j], upper[i]], c, M_TRIM)','b.add_poly([lower[i], lower[j], upper[j], upper[i]], c, M_DARK)')
helper=helper.replace('    for i in range(n):\n        a = 2 * math.pi * i / n','    for i in range(d["gallery_posts"]):\n        a = 2 * math.pi * i / d["gallery_posts"]')
helper=helper.replace('x - 0.0225, y - 0.0225, floor, x + 0.0225, y + 0.0225, floor + rail','x - d["gallery_member_m"]/2, y - d["gallery_member_m"]/2, floor, x + d["gallery_member_m"]/2, y + d["gallery_member_m"]/2, floor + rail')
helper=helper.replace('band(gal_r - 0.055, gal_r, floor + rail - 0.05, floor + rail, M_DARK)','band(gal_r - d["gallery_member_m"], gal_r, floor + rail - d["gallery_member_m"], floor + rail, M_DARK)\n    band(gal_r - d["gallery_member_m"], gal_r, floor + .08, floor + .08 + d["gallery_member_m"], M_DARK)')
helper=helper.replace('ring(lantern_r, floor), ring(lantern_r, cap_base)','ring(lantern_r, floor + d["sill_height_m"]), ring(lantern_r, cap_base)')
helper=helper.replace('    for i in range(8):\n        a = 2 * math.pi * i / 8','    for i in range(d["cage_uprights"]):\n        a = 2 * math.pi * i / d["cage_uprights"]',1)
helper=helper.replace('x - 0.0275, y - 0.0275, floor, x + 0.0275, y + 0.0275, cap_base','x - d["cage_member_m"]/2, y - d["cage_member_m"]/2, floor, x + d["cage_member_m"]/2, y + d["cage_member_m"]/2, cap_base')
helper=helper.replace('floor, floor + 0.06, M_DARK','floor, floor + d["sill_height_m"], M_DARK')
helper=helper.replace('cap_total * 0.55 / 0.7','d["dome_rise_m"]')
helper=helper.replace('c, M_ROOF','c, M_DARK')
helper=helper.replace('max(0.025, r1 * 0.025), cap_total * 0.15 / 0.7','d["finial_radius_m"], cap_total-rise')
helper=helper.replace('Reconstructed partition from Castelnau controls; same overall envelope.','Castelnau light cage, fine rail and shallow crown; reconstructed controls.')
s+='\n\n'+helper+'\n\n'+'''def _configure_cage_glass(ob, p: FortStructureParams) -> None:
    """Lantern-only alpha; shaft panes and the common glass sheet stay opaque.

    Alpha is explicitly set on Principled BSDF: Base Color alpha alone is not
    the glTF exporter alpha input. Blender4.5's exporter reads constant Alpha
    into baseColorFactor[3]/alphaMode BLEND; actual GLB+GLTFLoader checks follow.
    No transmission extension or second opaque-scene transmission pass is used.
    """
    opacity = p.tower_lantern_detail["pane_opacity"]
    rows = [m for m in ob.data.materials if m.name == "lantern_cage_glass"]
    if len(rows) != 1:
        raise RuntimeError("expected exactly one lantern-only cage glass")
    m = rows[0]
    node = m.node_tree.nodes.get("Principled BSDF")
    if node is None:
        raise RuntimeError("lantern cage material has no Principled BSDF")
    node.inputs["Alpha"].default_value = opacity
    rgba = tuple(m.diffuse_color)
    m.diffuse_color = (*rgba[:3], opacity)
    m.surface_render_method = "DITHERED"
'''
p.write_text(s)
p=H/'candidate'/paths[2];j=json.loads(p.read_text());f=j['phases'][0]['form'];f['tower_lantern_detail']={'value':{'pane_opacity':.18,'sill_height_m':.16,'dome_rise_m':.72,'cage_uprights':12,'cage_member_m':.045,'gallery_posts':16,'gallery_member_m':.035,'finial_radius_m':.018},'confidence':'reconstructed','sources':['castelnau_1842_chicago_harbor'],'note':'LANTERN-ONLY NEXT TRIAL after actual profile comparison. Actual1842 lithograph/held reproduction show a light cage with dark members, a lower band and shallow rounded crown; the actual previous render was an opaque black drum with tall dome. Pane alpha0.18,0.16m dark sill,0.72m dome rise,12cage members at45mm,16gallery posts at35mm, lower gallery ring and18mm finial radius are reconstructed diagnostic choices, not historical measurements or counts. Retain existing gallery/cap-base profile, maximum12.84968m, nominal12.19m height literal, footprint, world centre, position, bearing, ground and dates. Cap/rail/frame neutral dark finish is reconstructed from monochrome tonal separation, not attested paint or metal. Longer thin finial partitions the unchanged cap envelope;1838-to-July1835 continuity remains inferred. Shared opaque glass and shaft windows are unchanged. No match or complete original ticket acceptance is claimed.'};p.write_text(json.dumps(j,indent=2)+'\n')
for p in (H/'candidate').rglob('*.py'):ast.parse(p.read_text())
for name in ['camera-profile-research.json','source-next-research.json','run-preview.sh','prepare_fixture.py','glb_contracts.py']:
 shutil.copy2(PRE/name,H/name)
# Preserve the new runner's actual material/loader checks on a deliberate replay.
p=H/'run-preview.sh';text=p.read_text();needle='python3 "$lighthouse_package/glb_contracts.py" "$lighthouse_run"'
assert needle in text
text=text.replace(needle,needle+'\npython3 "$lighthouse_package/check_material_export.py" "$lighthouse_run"\nnode "$lighthouse_package/check_renderer.mjs" "$lighthouse_run/proposed/assets/gltf/chicago_lighthouse_1832__tower_1832.glb"\ncp "$lighthouse_package/actual-renderer-contract.json" "$lighthouse_run/actual-renderer-contract.json"')
p.write_text(text)
meta=[]
for rel in paths:
 meta.append({'path':rel,'baseline_sha256':hashlib.sha256((H/'baseline'/rel).read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256((H/'candidate'/rel).read_bytes()).hexdigest()})
(H/'inputs.json').write_text(json.dumps(meta,indent=2)+'\n')
r=subprocess.run(['git','diff','--no-index','--','baseline','candidate'],cwd=H,text=True,capture_output=True);assert r.returncode==1
(H/'lantern-detail-next.patch').write_text(r.stdout.replace('a/baseline/','a/').replace('b/candidate/','b/'))
print(H)
