## L-lighthouse-lantern-detail-2373 — A light lantern cage and shallow crown

**Scope:** Chicago Lighthouse1832, reconstructed lantern-only diagnostic after actual Castelnau comparison.
**Tier:** reconstructed
**Covers:** chicago_lighthouse_1832.form.tower_lantern_detail
**Sources:** castelnau_1842_chicago_harbor

**Why:** The actual lithograph shows a light cage with dark slender members, a lower band and a shallow rounded crown; the previous actual research render showed an opaque black drum and a tall dome. Neither image measures glass optical values, member counts or construction sections. Opacity0.18,0.16m sill,0.72m dome,12cage members45mm wide,16gallery posts35mm wide, lower gallery ring and18mm finial radius are chosen within that visible form. Cap/frame dark tonal proxy is not attested paint or material. The stem extends through the remainder of the unchanged cap envelope; its metric length remains reconstructed. Circa1838-to-July1835 detail continuity is inferred. Camera remains provisional and the historical40ft datum remains unresolved.

**Limits:** This changes no source height literal, overall bounds, profile gallery/cap-base controls, world centre, origin, position, bearing, physical footprint, foundation, shaft windows or dates. Shared dark glass remains opaque. It is an UNRUN research proposal and no match verdict or original-ticket completion is claimed.
