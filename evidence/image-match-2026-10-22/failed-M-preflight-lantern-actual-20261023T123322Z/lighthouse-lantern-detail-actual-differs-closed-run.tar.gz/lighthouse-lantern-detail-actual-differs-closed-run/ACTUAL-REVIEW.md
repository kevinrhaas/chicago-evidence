# Actual lighthouse lantern-detail review — 2026-10-23

**DIFFERS. Heavy slot CLEAR.** Exact prepared two-export/two-render runner exited0. Both side-by-sides and the actual Castelnau tower detail were inspected. No source/camera/model variant was added during this slot. Six frozen model-input hashes still match.

The previous black full-height drum is now a visibly light/open framed cage. Its shallower rounded crown and thin stem look closer to the source, and the lower gallery band is clearer. This is bounded actual visible progress; the full original T-2373 Image gate remains unsatisfied.

Remaining differences:
- Shaft remains a smooth uniform taper; lithograph depicts irregular masonry courses, joints and surface tone.
- Shaft windows are reconstructed kit rectangles; exact source mark positions, widths, relief and joinery are not matched. The shaded upper-right mark is less certain.
- Cage/rail members, lower transition and cap tonal balance still differ at detail scale; counts, sections, optical alpha and crown/stem partition remain reconstructed. The shallower crown/light cage is a visible improvement, not full agreement.
- Provisional camera and weak partly occluded foot leave framing/grade/eye-height degeneracy unresolved. Nominal40ft height datum is not established.
- Other original T2373 pictures have not been matched by this trial; circa1838 appearance continuing to July1835 remains inferred.

Geometry/material checks passed:1062→1254triangles,0zero-area faces, finite streams, max unit-normal error1.08530466169654e-7; overall glTF bounds remain exactly `[1.2799999714,0,-4.3200001717]..[4.3200001717,12.8496799469,-1.2799999714]`. Fresh baseline equals prior actual profile GLB bytes: True.

Exactly one proposed material is BLEND: lantern_cage_glass. Actual vendored GLTFLoader gives transparent=true, opacity0.18000000715255737, depthWrite=false, transmission0. Shared shaft glass stays opaque. Confidence shader setup retains reconstructed grade; default By grade dithers fragments, and ghost multiplies alpha. No in-app/GPU By grade picture or full repository gate is claimed. Both generated match files remain unreviewed; this explicit receipt records the actual DIFFERS verdict.

Exact artifact SHA256:

- `38aced7ae5a99be374834c45b125995f5a7dec3a0df8e54226713c09957d477a` — `baseline/assets/gltf/chicago_lighthouse_1832__tower_1832.glb`
- `3934500d1ff4a94ef975de8d234395834acd22a619f574cdcbecf0cda0928ad2` — `baseline/docs/RESEARCH/profile-trial/camera.json`
- `d96c1fd32f172c680f6afe373cf24e408d80b18b0ce9198e7bf4db54a60c02f0` — `baseline/docs/RESEARCH/profile-trial/camera.match.json`
- `6db98a8dc196525c353e0520012a451c14ea4480a6aa173eb4f11bb2a1a178bd` — `baseline/data/sources/assets/chicago_harbor_lighthouse_1838.jpg`
- `40678a9ce2e0736354274f72c1f0313dce74a99d3d7903f266999a1f25829581` — `reviews/baseline/camera-render.png`
- `991aa14dd2fbd390f57a4ba82fb39503ab02d52e81864ef33834ca63909b4f32` — `reviews/baseline/camera-side-by-side.jpg`
- `f87fbfe62625d0f9606623433ce4b5ede0edbbd149b2bbb6635a62e5c78fe6a4` — `proposed/assets/gltf/chicago_lighthouse_1832__tower_1832.glb`
- `3934500d1ff4a94ef975de8d234395834acd22a619f574cdcbecf0cda0928ad2` — `proposed/docs/RESEARCH/profile-trial/camera.json`
- `885142ac022aac7db455a39cf2199d456efcda5e0cd90eb992f33c3a43808970` — `proposed/docs/RESEARCH/profile-trial/camera.match.json`
- `6db98a8dc196525c353e0520012a451c14ea4480a6aa173eb4f11bb2a1a178bd` — `proposed/data/sources/assets/chicago_harbor_lighthouse_1838.jpg`
- `32685cfdd1b4a7d617011091354e05011988d9fd98bc6ec0d483d3d026a47e80` — `reviews/proposed/camera-render.png`
- `66d1ff8723e394d1e1e1d418b22c5d1a06453717c29049d04142e759e522185e` — `reviews/proposed/camera-side-by-side.jpg`
- `94d32c80d8167f051024905d230ebe4f6290e5741158d6836af4cf30bd70922a` — `glb-contracts.json`
- `a939a9ead6dafa54bc299dc9a84293b19b12d9f3ac3a2e7875b7bd89571aab33` — `material-export-contract.json`
- `02d747296a3810ec7790520a4d47411fcbabe45071bd85cf1bac584a1f67b669` — `actual-renderer-contract.json`
