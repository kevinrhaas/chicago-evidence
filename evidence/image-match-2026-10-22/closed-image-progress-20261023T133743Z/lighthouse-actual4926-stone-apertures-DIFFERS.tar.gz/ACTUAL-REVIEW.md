# Actual lighthouse shaft-masonry review — 2026-10-23

**DIFFERS. Heavy slot CLEAR.** The exact frozen two-export/two-render runner exited0. Both same-camera comparisons, the native proposed render surface and actual source detail crops were inspected. No variant or source/camera tweak occurred.

Actual visible progress: the formerly blank smooth shaft now shows courses/stone units/joints; larger plain dark recesses look closer to the source marks than the bright kit casing. The earlier light cage and shallow crown are preserved. The full original T-2373 image gate remains unsatisfied.

Remaining differences:
- Procedural masonry is visibly more regular/checkered and lower contrast than the source irregular masonry/graphic hatch; source lighting, local weathering and large surface shadows are not reproduced.
- Plain larger dark apertures are closer than the white kit casings but source exact aperture shapes, edge softness and positions remain different; shaded upper-right mark remains uncertain and rightward.
- Lantern cage, lower transition, rail and crown/stem details remain reconstructed and do not yet exactly reproduce the drawing. The previous lantern improvement is preserved.
- Camera remains provisional with an occluded weak foot and grade/eye-height/principal degeneracy; the nominal40ft datum is not established.
- Every other original T2373 reference still requires a dated camera/current canonical GLB comparison. Circa1838-to-July1835 appearance continuity remains inferred.

Checks passed:1254→4926triangles,0zero-area, all finite streams and all reconstructed1.0 confidence; max unit-normal error1.2533536830616754e-7. Both actual masters retain exactly `[1.2799999714,0,-4.3200001717]..[4.3200001717,12.8496799469,-1.2799999714]`. Baseline GLB and comparison are byte-identical to the prior actual lantern proposed result. The25 frozen author file hashes remain unchanged.

Both masters preserve exactly one lantern BLEND material, alpha0.18000000715255737, depthWrite=false, transmission0; shaft panes remain opaque. Actual GLTFLoader/confidence-state checks passed. This does not establish in-app/GPU normal/By grade views or the full repository gate. Stone dimensions, bond, relief, seed and tones remain reconstructed; source hatch/shadow is not a measured masonry specification. No texture or palette was copied from source pixels.

Generated match files stay unreviewed; this explicit receipt records the actual DIFFERS verdict. Canonical checkout and isolated lighthouse worktree were not edited. The published fa201069 UNRUN archive remains the historical preparation checkpoint; this run and receipt are later evidence.

Exact artifact SHA256:

- `f87fbfe62625d0f9606623433ce4b5ede0edbbd149b2bbb6635a62e5c78fe6a4` — `baseline/assets/gltf/chicago_lighthouse_1832__tower_1832.glb`
- `3934500d1ff4a94ef975de8d234395834acd22a619f574cdcbecf0cda0928ad2` — `baseline/docs/RESEARCH/profile-trial/camera.json`
- `93180be890216a13da6a750aa56c1dc45ab7e9ddd94630c51be470800edfbfd2` — `baseline/docs/RESEARCH/profile-trial/camera.match.json`
- `6db98a8dc196525c353e0520012a451c14ea4480a6aa173eb4f11bb2a1a178bd` — `baseline/data/sources/assets/chicago_harbor_lighthouse_1838.jpg`
- `32685cfdd1b4a7d617011091354e05011988d9fd98bc6ec0d483d3d026a47e80` — `reviews/baseline/camera-render.png`
- `66d1ff8723e394d1e1e1d418b22c5d1a06453717c29049d04142e759e522185e` — `reviews/baseline/camera-side-by-side.jpg`
- `20e548d0c746db03d5798b39a309fe0bfc101842b047108fab4b0ab3b735ac04` — `proposed/assets/gltf/chicago_lighthouse_1832__tower_1832.glb`
- `3934500d1ff4a94ef975de8d234395834acd22a619f574cdcbecf0cda0928ad2` — `proposed/docs/RESEARCH/profile-trial/camera.json`
- `73527f897e5331afe33aa6c7aaa282bdc2d7d57e627c6518891cd47c933054c7` — `proposed/docs/RESEARCH/profile-trial/camera.match.json`
- `6db98a8dc196525c353e0520012a451c14ea4480a6aa173eb4f11bb2a1a178bd` — `proposed/data/sources/assets/chicago_harbor_lighthouse_1838.jpg`
- `5bff07b27c6895e9e03daa5d8d75944bbe035ac5b9c3d05ef621c41f50a1c600` — `reviews/proposed/camera-render.png`
- `b79e0b0c859c04eb5d54790cf8b80c39c2129fc7c34ddf78f8e3fcdf3ec2ce6e` — `reviews/proposed/camera-side-by-side.jpg`
- `28070c1114b70a7cd6ce04c30ed5ec3f496dc37c773a6f7281fea67470fb4cd9` — `glb-contracts.json`
- `cf350699887fb1cf2fd597e1b73110e8f260b1309e38ca127a9150d6ea3f80b8` — `material-export-contract.json`
- `9c8f9c6a65c5a8fe28dd4c66859ff325cf9802dc9a92c74df2fbf5f0f483c429` — `actual-renderer-contract.json`
