# Hogan PR1229: current dev integration, local gate closed; fresh CI pending

Normal pushed head: 5eaeac194eb12843e511e1ab5d7deff70daa57e3. Actual dev at integration/push: c48b7feed7d5ed7e66cea1e33a40af1e348f0dff. Parents: a5ca and c48. Tree: 4e9e3357b4e2579e23619beac0d1bdf1f7e6fcd2.

Official strict candidate-working-tree preflight PASS 1053, no red, plus changelog and ticket-ID checks; exit 0, wall 747s. Actual native 59-stage producer tail settled after two laps, last unchanged. Required readers/base and four-worker pool enabled; TMPDIR outside every Git worktree. test_ticket_after completed 2.260s, vs former nested-fixture 326.818s; no test/code changes.

Full-gate inputs remained frozen throughout. After the gate closed, a research XLSX was restored to exact incoming dev bytes only after complete namespace-expanded XML/member semantic equality was proved. Existing published and offline-pack checks then passed. Postcommit changelog/IDs passed. This semantic-only normalization is explicitly qualified; do not claim the final ZIP bytes were the full-gate candidate's bytes.

Incoming generators/non-Hogan assets, records and registry entries remain exact dev; only Hogan's entries retain its own increment. All three Hogan source/record/master byte guards remain exact. Incoming raw liberty history is an exact prefix, with the exact own Hogan suffix appended; its sole terminal blank-line advisory was retained by explicit parent instruction. The native registry conflict helper refused because the merge was already clean and had no conflict stages; independent entrywise checks passed. No fake conflict was created.

No SourceS/Gale/frame proposal, assertion/workflow/timeout change, PR merge or lap mutation. Worktree clean; only two exact local runtime/recovery exclusions. Root owns new-head published-smoke dispatch, required CI review, held lap and final merge. These are PENDING at this checkpoint. A5ca's ten actual PASS workflows remain historical exact-a5ca evidence only, archived separately at tickets b08e8c76d2245ef4f671338aa62f18f25ef12ca9. All earlier shutdown/ORB/cancellation histories remain preserved.

Original T-2377 stays OPEN; actual image comparison still DIFFERS. No accepted match is claimed. The committed source/camera/before-after dossier is at chicago/4d/docs/RESEARCH/hogan-picture-match-T-2377.

Resume in /tmp/hogan-pr1229-integration on steward/t2377-hogan-current-dev. Existing PR source branch is steward/t2377-hogan-picture-match. Do not merge or change root's lap. No heavy child remains.
