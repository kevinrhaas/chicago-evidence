#!/usr/bin/env bash
set -euo pipefail
hogan_root=/tmp/hogan-pr1229-integration
hogan_logs="$hogan_root/.hogan-recovery"
trap 'hogan_exit=$?; printf "%s\n" "$hogan_exit" > "$hogan_logs/c48-tail.exit"' EXIT
export PYTHONPATH="/workspace/shared/python${PYTHONPATH:+:$PYTHONPATH}"
export PATH="/workspace/shared/tools/usr/bin:$PATH"
export npm_config_cache=/workspace/shared/npm-cache
export CHECK_JOBS=4 C4D_GATE_REQUIRE_READERS=1 C4D_GATE_REQUIRE_BASE=1
export TMPDIR=/tmp/hogan-pr1229-tmp-c48
mkdir -p "$TMPDIR"
cd "$hogan_root/chicago/4d"
python3 tools/check_gate_readers.py > "$hogan_logs/c48-readers.log" 2>&1
bash tools/publish.sh > "$hogan_logs/c48-publish-initial.log" 2>&1
node tools/rederive.mjs --tail tools/compile_liberties.py > "$hogan_logs/c48-rederive-ordered-tail.log" 2>&1
