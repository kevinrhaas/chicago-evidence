from pathlib import Path
from types import ModuleType
from dataclasses import asdict,replace
import ast,copy,inspect,json,math,sys,subprocess,zlib
import numpy as np,jsonschema
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent;R=Path('/workspace/worktrees/t2373-lighthouse/chicago/4d');pr='chicago/4d/generators/archetypes/fort_structure_params.py';gr='chicago/4d/generators/archetypes/fort_structure.py';rr='chicago/4d/data/structures/chicago_lighthouse_1832.json'
def load(p,name):
 m=ModuleType(name);sys.modules[name]=m;exec(compile(p.read_text(),str(p),'exec'),m.__dict__);return m
old,new=load(H/'baseline'/pr,'stone_before'),load(H/'candidate'/pr,'stone_after')
assert old.FortStructureParams.__match_args__==new.FortStructureParams.__match_args__ and len(new.FortStructureParams.__match_args__)==16
assert new.CONSUMED==old.CONSUMED
assert inspect.signature(new.FortStructureParams)==inspect.signature(old.FortStructureParams)

family=[(k,v) for k,v in json.loads((R/'assets/manifest.json').read_text())['assets'].items() if v.get('archetype')=='fort_structure'];assert len(family)==25
phases=[]
for asset,row in family:
 rec=json.loads((R/'data/structures'/f"{row['structure_id']}.json").read_text());ph=next(p for p in rec['phases'] if p['id']==row['phase_id']);a,b=old.from_phase(ph,rec),new.from_phase(ph,rec);d=asdict(b);assert d==asdict(a)
 pos=new.FortStructureParams(*[getattr(a,k) for k in a.__match_args__],**{k:getattr(a,k) for k,p in inspect.signature(old.FortStructureParams).parameters.items() if p.kind==inspect.Parameter.KEYWORD_ONLY});pos.validate();dd=asdict(pos);assert dd==asdict(a);phases.append((a,b))
def funcs(p):return {n.name:n for n in ast.parse(p.read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
af,bf=funcs(H/'baseline'/gr),funcs(H/'candidate'/gr);added={'_tower_irregular_stone_shaft'};assert set(bf)==set(af)|added
for k in af:
 if k!='_tower':assert ast.dump(af[k])==ast.dump(bf[k]),k
sys.path.insert(0,str(R/'generators'));from common import openings
class Collect:
 def __init__(self):self.faces=[];self.named={};self.name='chicago_lighthouse_1832'
 def named_mat(self,name,*spec):self.named.setdefault(name,(1000+len(self.named),spec));return self.named[name][0]
 def add_poly(self,points,confidence,mat=0):self.faces.append((tuple(tuple(float(v) for v in p) for p in points),float(confidence),mat));return list(range(len(points)))
box=next(n for n in next(n for n in ast.parse((R/'generators/common/mesh.py').read_text()).body if isinstance(n,ast.ClassDef) and n.name=='MeshBuilder').body if isinstance(n,ast.FunctionDef) and n.name=='add_box');ns={};exec(compile(ast.Module(body=[box],type_ignores=[]),'<actual add_box>','exec'),ns);Collect.add_box=ns['add_box']
def extract(fs,mod):
 names=[k for k in fs if k.startswith(('_tower','_birdcage','_stone')) or k in {'_unit','_TowerFacetBuilder'}];tree=ast.Module(body=[copy.deepcopy(fs[k]) for k in names if k in fs],type_ignores=[])
 ns={'math':math,'zlib':zlib,'openings':openings,'M_WALL':0,'M_ROOF':1,'M_DARK':2,'M_TRIM':3,'WALL_RGBA':{'stone':(.58,.56,.51,1.)},'tower_opening_layout':mod.tower_opening_layout};exec(compile('from __future__ import annotations\n'+ast.unparse(tree),'<actual tower>', 'exec'),ns);return ns
xo,xn=extract(af,old),extract(bf,new)
for a,b in phases:
 if a.kind=='tower':
  for profile,lit in [('legacy',False),('legacy',True),('birdcage_dome',True)]:
   ca,cb=Collect(),Collect();xo['_tower'](ca,replace(a,lantern_profile=profile,lantern=lit));xn['_tower'](cb,replace(b,lantern_profile=profile,lantern=lit));assert ca.faces==cb.faces and ca.named==cb.named
base,candidate=json.loads((H/'baseline'/rr).read_text()),json.loads((H/'candidate'/rr).read_text());a=old.from_phase(base['phases'][0],base);p=new.from_phase(candidate['phases'][0],candidate);before,disabled,after=Collect(),Collect(),Collect();xo['_tower'](before,a);xn['_tower'](disabled,replace(p,tower_masonry={k:v for k,v in p.tower_masonry.items() if k!='character'}));xn['_tower'](after,p);assert before.faces==disabled.faces and before.named==disabled.named
for k in base:
 if k!='phases':assert base[k]==candidate[k],k
for k in base['phases'][0]:
 if k!='form':assert base['phases'][0][k]==candidate['phases'][0][k],k
for k in base['phases'][0]['form']:
 if k!='tower_masonry':assert base['phases'][0]['form'][k]==candidate['phases'][0]['form'][k],k
assert set(candidate['phases'][0]['form'])==set(base['phases'][0]['form'])
assert {k:v for k,v in candidate['phases'][0]['form']['tower_masonry']['value'].items() if k!='character'}==base['phases'][0]['form']['tower_masonry']['value']
def bounds(col):
 vs=[v for poly,_,_ in col.faces for v in poly];return [[min(v[i] for v in vs) for i in range(3)],[max(v[i] for v in vs) for i in range(3)]]
assert np.allclose(bounds(before),bounds(after),rtol=0,atol=1e-12)
feet=lambda col:sorted(set(v for poly,_,_ in col.faces for v in poly if abs(v[2])<1e-9));assert feet(before)==feet(after)
# Material IDs shift because stone slots precede the cage. Compare actual names/specs.
def normalized(col,zmin):
 rev={i:(name,spec) for name,(i,spec) in col.named.items()}
 return [(poly,c,rev.get(mat,mat)) for poly,c,mat in col.faces if min(v[2] for v in poly)>=zmin-1e-10]
assert normalized(before,p.tower_shaft_height_m)==normalized(after,p.tower_shaft_height_m)
rev={i:name for name,(i,_) in after.named.items()};apertures=new.tower_opening_layout(p);radius=p.tower_diameter_m/2;shaft=p.tower_shaft_height_m
stone_faces=0
for poly,c,mat in after.faces:
 assert c==1 and np.isfinite(np.array(poly)).all()
 for i in range(1,len(poly)-1):assert np.linalg.norm(np.cross(np.array(poly[i])-poly[0],np.array(poly[i+1])-poly[0]))>1e-10,(rev.get(mat,mat),poly)
 if max(v[2] for v in poly)<=shaft+1e-9 and min(v[2] for v in poly)<shaft-1e-9:
  for x,y,z in poly:
   for facet in range(12):
    ang=math.radians(15+30*facet);limit=radius*(1-(1-p.taper)*z/shaft)*math.cos(math.pi/12)
    assert (x-2.8)*math.cos(ang)+(y-2.8)*math.sin(ang)<=limit+1e-10,(x,y,z,facet)
 if rev.get(mat,'').startswith('tower_stone_'):
  stone_faces+=1;pts=np.array(poly);center=pts.mean(axis=0);normal=np.cross(pts[1]-pts[0],pts[2]-pts[0]);assert np.dot(normal[:2],center[:2]-[2.8,2.8])>0,('inward stone face',rev.get(mat),poly,normal.tolist(),center.tolist())
  facet=int((math.atan2(center[1]-2.8,center[0]-2.8)%(2*math.pi))/(math.pi/6));ang=math.radians(15+30*facet);u=-(center[0]-2.8)*math.sin(ang)+(center[1]-2.8)*math.cos(ang)
  for o in apertures:
   if o['facet']==facet:assert not(o['u0']+1e-9<u<o['u1']-1e-9 and o['z0']+1e-9<center[2]<o['z1']-1e-9),'stone backing covers an aperture'
assert stone_faces>100
# Deterministic reconstruction and actual clipped hole area, not source pixels.
again=Collect();xn['_tower'](again,p);assert after.faces==again.faces and after.named==again.named
for bad in [True,{},dict(p.tower_masonry,character='unknown'),dict(p.tower_masonry,relief_m=.2),dict(p.tower_masonry,course_m=float('nan'))]:
 try:replace(p,tower_masonry=bad).validate()
 except new.ParamError:pass
 else:raise AssertionError(bad)
for changed in [{'kind':'quarters'},{'construction':'log'}]:
 try:replace(p,**changed).validate()
 except new.ParamError:pass
 else:raise AssertionError(changed)
jsonschema.validate(candidate,json.loads((R/'data/structures.schema.json').read_text()))
r=subprocess.run(['git','apply','--check',str(H/'irregular-character-next.patch')],cwd=H/'baseline',text=True,capture_output=True);assert r.returncode==0,r.stderr
assert(H/'camera-profile-research.json').read_bytes()==Path('/tmp/chicago-next-model/T-2373-shaft-stone-next/camera-profile-research.json').read_bytes()
cam=json.loads((H/'camera-profile-research.json').read_text());projections=[]
for o in new.tower_opening_layout(p):
 z=(o['z0']+o['z1'])/2;ang=math.radians(o['azimuth_deg']);u=(o['u0']+o['u1'])/2;r=radius*(1-(1-p.taper)*z/shaft)*math.cos(math.pi/12);x=2.8+r*math.cos(ang)-u*math.sin(ang);v=2.8+r*math.sin(ang)+u*math.cos(ang);den=v-cam['eye'][1];scale=cam['focal_px']/den
 projections.append({'facet':o['facet'],'center_px':[cam['principal_px'][0]+scale*(x-cam['eye'][0]),cam['principal_px'][1]-scale*(z-cam['eye'][2])],'width_px':scale*(o['u1']-o['u0'])*abs(math.sin(ang)),'height_px':scale*(o['z1']-o['z0'])})
report={'status':'passed','current25default_parameters_and_legacy16positionals_and_old_keywords_equal':True,'no_new_dataclass_fields_all_prior_signature_and_keywords_exact':True,'all_old_non_tower_and_lantern_geometry_AST_equal':True,'all_old3tower_geometry_streams_and_actual4926baseline_equal_without_character':True,'prior_actual_lantern_geometry_above_shaft_and_named_material_specs_exact':True,'physical_bounds_unchanged_m':bounds(after),'ground_feet_exact':True,'every_new_shaft_point_inside_original12planes':True,'all_stone_normals_outward_and_no_stone_centroids_cover_apertures':True,'stone_faces':stone_faces,'triangles_before':sum(len(poly)-2 for poly,_,_ in before.faces),'triangles_after':sum(len(poly)-2 for poly,_,_ in after.faces),'all_finite_nondegenerate_reconstructed':True,'deterministic_geometry_and_prior_palette_exact':all(after.named[k][1]==before.named[k][1] for k in before.named),'no_textures_or_source_pixel_copy':True,'candidate_aperture_projections_diagnostic':projections,'camera_bytes_fixed_schema_and_patch_pass':True,'actual_export_render':'UNRUN_wait_parent_grant'}
(H/'light-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
