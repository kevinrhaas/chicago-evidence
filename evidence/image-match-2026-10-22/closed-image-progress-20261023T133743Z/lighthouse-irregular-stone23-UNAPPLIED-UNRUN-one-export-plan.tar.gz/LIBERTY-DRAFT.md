### L-lighthouse-irregular-stone-2373 — Irregular unit shapes inside the old shaft

**Covers:** `chicago_lighthouse_1832.tower_1832.form.tower_masonry`.
**Decision:** After actual4926-triangle comparison, reconstruct independently varied bed heights by facet, variable unit widths, locally sloped beds and chipped polygonal corners instead of checker-like courses. Keep every previous metric control, seed and stone/joint palette; relief remains inside the old12 taper planes and small pieces cap their crown depth.
**Uncertainty:** The actual Castelnau plate shows irregular masonry-like marks, but hatch and large surface shadows are not measured physical joints. Exact unit shapes, jitter and chip sections are reconstructed. No engraved stroke, texture or palette is copied. This does not attest stone colour, paint, a masonry bond, a metric course schedule or an1835 unchanged finish. Camera and40ft datum remain unresolved.
**Source:** `castelnau_1842_chicago_harbor`, actual1842 plate and held reproduction, interpreted as circa1838 form by continuity inference for the July1835 tower.
**How to resolve:** Inspect the next actual same-camera comparison and all dated pictures. Seek contemporary construction specifications and distinguish illustration technique from physical surface. Preserve full original image acceptance and all surveyed/date/nominal-height controls.
**Recorded:** 2026-10-23, UNRUN lighthouse-only character proposal, not a match or canonical admission.
