// CPU-only material/loader contract. No browser, WebGL, render or network.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { registerHooks } from 'node:module';
registerHooks({resolve(specifier,context,nextResolve){
 if(specifier==='three') return {url:'file:///workspace/worktrees/t2373-lighthouse/chicago/4d/renderers/web/vendor/three-0.185.1/three.module.js',shortCircuit:true};
 return nextResolve(specifier,context);
}});
const { GLTFLoader }=await import('/workspace/worktrees/t2373-lighthouse/chicago/4d/renderers/web/vendor/three-0.185.1/addons/loaders/GLTFLoader.js');
const { cheapenGlass }=await import('/workspace/worktrees/t2373-lighthouse/chicago/4d/renderers/web/js/glass.js');
const { createConfidenceView }=await import('/workspace/worktrees/t2373-lighthouse/chicago/4d/renderers/web/js/confidence.js');
const here=path.dirname(fileURLToPath(import.meta.url));
const actual=process.argv[2];
let data;
if(actual){const b=fs.readFileSync(actual); data=b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength);}
else data=JSON.stringify({asset:{version:'2.0'},scene:0,scenes:[{}],materials:[{name:'lantern_cage_glass',alphaMode:'BLEND',pbrMetallicRoughness:{baseColorFactor:[.1134,.1164,.1144,.18],roughnessFactor:.065,metallicFactor:0}}]});
const gltf=await new Promise((resolve,reject)=>new GLTFLoader().parse(data,'',resolve,reject));
const materials=await gltf.parser.getDependencies('material');
const cage=materials.filter(m=>m.name==='lantern_cage_glass');assert.equal(cage.length,1);
const m=cage[0];assert.equal(m.transparent,true);assert.equal(m.depthWrite,false);assert(Math.abs(m.opacity-.18)<1e-6);assert(!m.transmission);
for(const mode of ['transmission','clear','dark'])assert.equal(cheapenGlass(m,mode),m);
const old={opacity:m.opacity,transparent:m.transparent,depthWrite:m.depthWrite};
const view=createConfidenceView();view.patch(m);view.set(false);assert.deepEqual({opacity:m.opacity,transparent:m.transparent,depthWrite:m.depthWrite},old);
const shader={uniforms:{},vertexShader:'#include <common>\n#include <begin_vertex>',fragmentShader:'#include <clipping_planes_fragment>\n#include <color_fragment>\n#include <opaque_fragment>'};
m.onBeforeCompile(shader,{});assert(shader.fragmentShader.includes('uGradeOpacity'));assert(shader.fragmentShader.includes('#ifdef CHICAGO_GHOST_PASS'));
view.set(true);assert.equal(view.getGrade?.('reconstructed')?.mode ?? view.modes.reconstructed,'dither');assert.deepEqual({opacity:m.opacity,transparent:m.transparent,depthWrite:m.depthWrite},old);
view.setGrade('reconstructed',{mode:'tint'});assert.deepEqual({opacity:m.opacity,transparent:m.transparent,depthWrite:m.depthWrite},old);
view.setGrade('reconstructed',{mode:'ghost',opacity:.34});assert(shader.fragmentShader.includes('gl_FragColor.a *='));assert.deepEqual({opacity:m.opacity,transparent:m.transparent,depthWrite:m.depthWrite},old);
if(actual){const shaft=materials.find(m=>m.name==='lantern_glass');assert(shaft);assert.equal(shaft.transparent,false);assert.equal(shaft.opacity,1);}
const report={status:'passed',input:actual??'synthetic expected material only; actual exported material pending',actual_export:!!actual,GLTFLoader:{transparent:m.transparent,opacity:m.opacity,depthWrite:m.depthWrite,transmission:m.transmission??0},shared_dark_and_clear_cheapenGlass_do_not_replace_nontransmissive_cage:true,normal_and_bygrade_state_preserved:true,bygrade_limits:'Reconstructed1.0 geometry keeps reconstructed grade. Default By grade dither discards about66% of its fragments in addition to material alpha0.18; tint keeps alpha, and ghost multiplies alpha in its own pass. No WebGL screenshot or GPU shader compilation is claimed.',runtime_batch_caveat:'General materialKey includes transparent flag but omits opacity; canonical adoption must inspect coexisting BLEND building materials. This proposal does not change the runtime key or common glass.',no_browser_or_WebGL:true};
fs.writeFileSync(path.join(here,actual?'actual-renderer-contract.json':'synthetic-renderer-contract.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
