#!/usr/bin/env bash
# PREPARED ONLY. One candidate export/render; preserve actual4926 held baseline.
set -euo pipefail
lighthouse_package="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONDONTWRITEBYTECODE=1
python3 "$lighthouse_package/prepare_fixture.py"
lighthouse_run="$(cat "$lighthouse_package/latest-run.txt")"
python3 - "$lighthouse_package" "$lighthouse_run" <<'PY'
from pathlib import Path
import hashlib,json,shutil,sys
h,r=map(Path,sys.argv[1:]);old=Path('/tmp/chicago-next-model/T-2373-shaft-stone-next/runs/20261023-130205-554211');asset='chicago_lighthouse_1832__tower_1832.glb';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();src=old/'proposed/assets/gltf'/asset
assert sha(src)=='20e548d0c746db03d5798b39a309fe0bfc101842b047108fab4b0ab3b735ac04'
assert sha(r/'proposed/docs/RESEARCH/profile-trial/camera.json')=='3934500d1ff4a94ef975de8d234395834acd22a619f574cdcbecf0cda0928ad2'
shutil.copy2(src,r/'baseline/assets/gltf'/asset);shutil.copy2(old/'proposed/assets/manifest.json',r/'baseline/assets/manifest.json');shutil.copy2(old/'proposed-wrote.txt',r/'baseline-wrote.txt')
(r/'reviews/baseline').mkdir(parents=True,exist_ok=True)
for name in ['camera-render.png','camera-side-by-side.jpg']:shutil.copy2(old/'reviews/proposed'/name,r/'reviews/baseline'/name)
(r/'held-baseline.json').write_text(json.dumps({'status':'HELD_ACTUAL_BASELINE_NOT_REEXPORTED_OR_RERENDERED_THIS_RUN','previous_run':str(old),'GLB_sha256':sha(src),'camera_sha256':sha(r/'proposed/docs/RESEARCH/profile-trial/camera.json'),'comparison_sha256':sha(old/'reviews/proposed/camera-side-by-side.jpg')},indent=2)+'\n')
PY
source "$lighthouse_run/proposed/generators/blender.pin"
lighthouse_archive="/workspace/shared/blender-dl/$(basename "$BLENDER_URL")"
lighthouse_binary="/workspace/shared/blender-dl/$BLENDER_DIR/blender"
printf '%s  %s\n' "$BLENDER_SHA256" "$lighthouse_archive" | sha256sum -c -
python3 - "$lighthouse_binary" "$BLENDER_VERSION" <<'PY'
import subprocess,sys
r=subprocess.run([sys.argv[1],'--version'],text=True,capture_output=True,check=True);assert r.stdout.splitlines()[0].split()[1]==sys.argv[2]
PY
cd "$lighthouse_run/proposed"
BLENDER_USER_CONFIG="$lighthouse_run/blender-config" "$lighthouse_binary" -b -noaudio --factory-startup --python generators/build.py -- --only chicago_lighthouse_1832 --wrote "$lighthouse_run/proposed-wrote.txt" > "$lighthouse_run/proposed-export.log" 2>&1
PW_EXECUTABLE="${PW_EXECUTABLE:-/usr/bin/chromium}" node tools/photo_match.mjs docs/RESEARCH/profile-trial/camera.json --out "$lighthouse_run/reviews/proposed" > "$lighthouse_run/proposed-review.log" 2>&1
python3 "$lighthouse_package/glb_contracts.py" "$lighthouse_run"
python3 "$lighthouse_package/check_material_export.py" "$lighthouse_run"
node "$lighthouse_package/check_renderer.mjs" "$lighthouse_run/proposed/assets/gltf/chicago_lighthouse_1832__tower_1832.glb"
cp "$lighthouse_package/actual-renderer-contract.json" "$lighthouse_run/actual-renderer-contract.json"
