from pathlib import Path
import ast,hashlib,json,shutil,subprocess
H=Path(__file__).resolve().parent;PRE=Path('/tmp/chicago-next-model/T-2373-shaft-stone-next');run=Path((PRE/'latest-run.txt').read_text().strip());paths=['chicago/4d/generators/archetypes/fort_structure_params.py','chicago/4d/generators/archetypes/fort_structure.py','chicago/4d/data/structures/chicago_lighthouse_1832.json']
for rel in paths:
 for kind in ['baseline','candidate']:
  p=H/kind/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(run/'proposed'/Path(rel).relative_to('chicago/4d'),p)
p=H/'candidate'/paths[0];s=p.read_text();old='''            if not isinstance(d,dict) or set(d)!=keys or any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in d.values()):''';new='''            if not isinstance(d,dict) or set(d)-{'character'}!=keys or any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for k,v in d.items() if k!='character'):
                raise ParamError("tower_masonry needs six finite declared controls")
            if d.get('character','legacy_courses') not in {'legacy_courses','irregular_rubble'}:''';assert old in s;s=s.replace(old,new);p.write_text(s)
p=H/'candidate'/paths[1];s=p.read_text();old='''    if p.tower_masonry is not None:
        _tower_stone_shaft(b,p,cx,cy,r0,shaft)''';new='''    if p.tower_masonry is not None:
        if p.tower_masonry.get('character','legacy_courses') == 'irregular_rubble':
            _tower_irregular_stone_shaft(b,p,cx,cy,r0,shaft)
        else:
            _tower_stone_shaft(b,p,cx,cy,r0,shaft)''';assert s.count(old)==1;s=s.replace(old,new)
node=next(n for n in ast.parse(s).body if isinstance(n,ast.FunctionDef) and n.name=='_tower_stone_shaft');helper=ast.get_source_segment(s,node).replace('def _tower_stone_shaft(', 'def _tower_irregular_stone_shaft(')
helper=helper.replace('Reconstructed masonry inside the EXISTING12 taper facets, not a texture.','Irregular rubble character inside the same old12 planes; no source pixels.')
helper=helper.replace("_unit('lighthouse-stone',d['seed'],row)","_unit('lighthouse-irregular-bed',d['seed'],row,facet)")
helper=helper.replace('end=start+width','end=start+width*(.65+.7*_unit(\'lighthouse-irregular-width\',d[\'seed\'],row,facet,col))')
old='''                    poly=[(u0,zlo),(u1,zlo),(u1,zhi),(u0,zhi)]''';new='''                    # Inset each irregular unit inside its old cell. Bed slopes and
                    # chipped corners are reconstructed, not engraved hatch copies.
                    short=min(u1-u0,zhi-zlo)
                    bevel=min(.06,short*.14)
                    bed=min(.045,short*.08)
                    a,b0,c0,d0=[bevel*(.35+.65*_unit('lighthouse-irregular-corner',d['seed'],row,facet,col,k)) for k in range(4)]
                    bl,br,tr,tl=[bed*_unit('lighthouse-irregular-bededge',d['seed'],row,facet,col,k) for k in range(4)]
                    poly=[(u0+a,zlo+bl),(u1-b0,zlo+br),(u1,zlo+br+b0),
                          (u1,zhi-tr-c0),(u1-c0,zhi-tr),(u0+d0,zhi-tl),
                          (u0,zhi-tl-d0),(u0,zlo+bl+a)]''';assert old in helper;helper=helper.replace(old,new)
s+='\n\n'+helper+'\n';p.write_text(s)
p=H/'candidate'/paths[2];j=json.loads(p.read_text());m=j['phases'][0]['form']['tower_masonry'];m['value']['character']='irregular_rubble';m['note']+=' IRREGULAR CHARACTER TRIAL after the actual4926-triangle comparison: independent beds by facet, variable unit widths, sloped beds and chipped polygonal corners soften the visible checker bands without changing the existing five reconstructed stone tones or joint proxy. Exact chip sections, bed/width jitter and seed are reconstructed; the drawing\'s hatch and large-scale light/shade are not treated as literal masonry or copied into the material. All previous nominal course/bond/joint/relief/reveal controls, apertures, lantern, overall bounds, foot vertices, camera and surveyed placement stay fixed. This is not a match.';p.write_text(json.dumps(j,indent=2)+'\n')
for p in (H/'candidate').rglob('*.py'):ast.parse(p.read_text())
for name in ['camera-profile-research.json','source-next-research.json','prepare_fixture.py','glb_contracts.py','check_material_export.py','check_renderer.mjs']:
 shutil.copy2(PRE/name,H/name)
# The next runner deliberately uses one export plus a held actual baseline.
p=H/'glb_contracts.py';text=p.read_text().replace("'export_sets':2,'exported_assets':len(rows)","'export_sets':1,'held_baseline_masters':1,'inspected_assets':len(rows),'exported_assets':1").replace("'limitations':'Checks master GLBs only;","'limitations':'Baseline is the exact held actual4926master, not reexported/rerendered this run. Checks master GLBs only;");p.write_text(text)
meta=[{'path':rel,**{kind+'_sha256':hashlib.sha256((H/kind/rel).read_bytes()).hexdigest() for kind in ['baseline','candidate']}} for rel in paths];(H/'inputs.json').write_text(json.dumps(meta,indent=2)+'\n')
r=subprocess.run(['git','diff','--no-index','--','baseline','candidate'],cwd=H,text=True,capture_output=True);assert r.returncode==1;(H/'irregular-character-next.patch').write_text(r.stdout.replace('a/baseline/','a/').replace('b/candidate/','b/'));print(H)
