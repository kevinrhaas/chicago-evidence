from pathlib import Path
import json,struct,sys
R=Path(sys.argv[1]);rows=[]
for kind in ['baseline','proposed']:
 p=R/kind/'assets/gltf/chicago_lighthouse_1832__tower_1832.glb'
 with p.open('rb') as f:
  magic,version,total=struct.unpack('<III',f.read(12));size,tag=struct.unpack('<II',f.read(8));assert magic==0x46546c67 and tag==0x4e4f534a;j=json.loads(f.read(size))
 blend=[m for m in j['materials'] if m.get('alphaMode','OPAQUE')=='BLEND']
 assert not any(m.get('extensions',{}).get('KHR_materials_transmission') for m in j['materials'])
 shaft=next(m for m in j['materials'] if m.get('name')=='lantern_glass');assert shaft.get('alphaMode','OPAQUE')=='OPAQUE';assert shaft.get('pbrMetallicRoughness',{}).get('baseColorFactor',[1,1,1,1])[3]==1
 if kind in ['baseline','proposed']:
  assert len(blend)==1 and blend[0].get('name')=='lantern_cage_glass'
  assert abs(blend[0]['pbrMetallicRoughness']['baseColorFactor'][3]-.18)<1e-6
 rows.append({'kind':kind,'BLEND_materials':[m.get('name') for m in blend],'shaft_glass_opaque':True,'transmission_extension':False})
report={'status':'passed','actual_exported_materials':rows,'all_geometry_confidence_must_remain_reconstructed':'checked by glb-contracts.json'};(R/'material-export-contract.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
