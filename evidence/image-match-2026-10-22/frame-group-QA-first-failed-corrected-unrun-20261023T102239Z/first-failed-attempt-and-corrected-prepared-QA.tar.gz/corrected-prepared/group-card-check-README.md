# Grouped published-app/card acceptance — prepared, not executed

Run after the final T-3055/T-3056 official bake, compilation, full publisher and parent release of the shared CPU/browser slot:

```sh
node /tmp/frame-integration/group-card-check.mjs
```

The script opens **one published 1835 app page per viewport**, reused for all six cases: St Mary's, Beaubien, log jail, Green Tree, Sauganash and first Tremont. Both **390 × 780** and **1280 × 800** must run (12 cases); an inherited `QA_VIEWPORT` is rejected. Default output is `/tmp/frame-integration/group-card-check`; `QA_SITE_ROOT` and `QA_OUT` can select another published tree/output folder. It uses `/workspace/node_modules` Playwright and `/usr/bin/chromium`.

The source-only script `/tmp/source-prerequisite/card-check.mjs` remains byte-identical, SHA256 `3149380a6f468b6f4d490bee7d9469739a3fd86de102c10ff4029f3c4d423dc1`. That source-only script is preserved as an earlier snapshot, including its superseded jail scope; do not use it alone for the current jail acceptance. The grouped script retains the other source checks and supersedes its jail expectations, using **actual visible** Photos/Sources/Research content and real existing image links. It requires no invented jail source/context anchor. The grouped jail case now requires actual Images credit for Trowbridge / Gale / 1902 and the Internet Archive plate n79 link. Its grade remains inferred because the core is mostly obscured; no camera or whole-building promotion is invented. Research must expose the independent 1902 artwork clearance and supersession of the old blanket artwork hold. The separately catalogued UCR copy still requires its complete collection/institution credit, exact catalogued-copy date, publication distinction and copy-specific rights caution to be visible in Research or Sources. No new form or geometry is claimed by this metadata correction. Beaubien's Story must preserve unknown construction; its corrected detailed narrative and identity limit must be visible in Research.

Hotel opt-in values and per-attribute grades are frozen from the selected final review-tree records in `group-card-expected.json`. The three hotels' whole-building grades must be attested; geometry/flag details retain their own inferred/reconstructed grades. The actual Photos panes must credit/link the Andreas plates or Gifford/Chicagology. Relevant Sources rows must show their actual grades. All cases save visible pane text, links, screenshots, and a normal scene screenshot. No source-image match is asserted.

## Tremont's actual application flag

The existing harness already exposes real `flags`, `scene3d`, `buildings`, `camera`, `renderer`, and `confidence` objects. No production API or renderer code is added. The grouped script checks:

- The actual `flag:tremont_house_1` mesh is visible, attached to the actual rendered scene and actual flag layer, with exactly one drawn-layer entry.
- The holder equals the explicit phase anchor's head mapped `[east,north,up]` → glTF `[east,up,south]` and transformed by the live building matrix, less the existing 0.18 m truck gap. The actual cloth stands off by the declared radius; head/foot fall inside actual built bounds. Cloth size/pattern match the record.
- The actual cloth `_confidence` stream is SCALAR and uniformly **1**, independent of the whole-building attested grade. Its static projected mesh must be in the actual camera and at least one pixel across/in height; a tiny or out-of-frame flag fails rather than passing on metadata alone.
- A temporary observation-only `onAfterRender` hook reads the **actual draw's linked GPU program and uniforms**. Normal mode must receive `uConfMode=0`; By grade must receive `1`, reconstructed dither mode `2`, opacity `0.34`, and an unhidden reconstructed component. The actual compiled shaders must carry the confidence stream/control path. The original render hook is restored in `finally`.

Normal and confidence app scene screenshots are saved at both sizes, together with JSON draw/anchor/projection evidence. Projected static bounds omit flutter; GPU controls and an actual draw prove integration, while screenshots still require human visual review. This is not an accepted picture comparison, a claim that the cloth matches Gifford, or a new historical attestation.

## Failure and cleanup

The declared-review loader oracle is recomputed from the actual registry; page errors, failed HTTP/requests, local serving errors and unexpected loader problems fail. Per-case diagnostics/screenshots remain on failures, and the script continues the other cases where possible. A failed case makes the final result fail. Contexts, browser, native hook and ephemeral server close through nested `finally` paths. No browser was launched while preparing this package; `node --check` is the only executed Node check.

The source-only S checkpoint may truthfully say the grouped published-card QA is pending. Parent runs this once for the final group and reviews actual screenshots before marking that acceptance complete. No app, repository, ticket or production-manifest writes were performed by this agent.

## Gale1902 checkpoint update

The pre-Gale grouped script, expectation, README and checkpoint are preserved under `group-card-history/pre-gale-1902/`. The current assertion fragment is `jail-gale-1902-assertions.txt`, and regeneration is included in `prepare-group-card-check.py`. This update is QA-only; it does not edit app/data files or run a browser. Current source-only authors/citations must expose publication words and the later-copy credit on an actual card surface; source JSON existence alone does not pass those checks.


## Verified1902 hotel source addition

The current script additionally requires actual Images credit for **W. E. S. Trowbridge / Edwin O. Gale /1902** on both GreenTree and Sauganash, and exact verified original plate links IA n55 and n49. Existing Andreas1884 credit/link assertions remain. Actual Research must disclose the retrospective1835caption; Sauganash must retain separate Wau-Bun bright-blue colour evidence and inferred louvred-detail reasoning. Expected form values/grades do not change. These assertions follow the frame-specific source-adoption package `T-2383-shutter-audit`; execute only after its guarded adoption, official23family build and ordered compilation/publish. PriorQA files are preserved under `group-card-history/pre-hotel-1902-*`. No browser or actualcardacceptance was run during this update.


Composed M roof/glyph QA promotion: guarded current canonical record values and hashes, Sauganash reconstructed25.2°/attic and Tremont reconstructedTREMONT visible grade checks, all12 prior cases retained. See group-card-roof-glyph-update.json. No actual browser execution is asserted by this promotion.


Actual first attempt (2026-10-23): stopped after the Record disclosure navigation failed on St Mary and Beaubien. The fixture compared CSS-uppercased innerText to mixed-case Record, leaving the native fold closed. The selector now compares native textContent case-insensitively before clicking the real summary; the Research-content assertion and every model/source/network oracle remain. Authoritative regeneration reproduces the corrected script exactly. The interrupted attempt and its browser-close fallout remain in canonical23/group-card-QA; the complete corrected run is still pending.
