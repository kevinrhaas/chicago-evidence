A queue ordinal can select a different ticket as the queue moves. Add optional `target_ticket` so an owner-requested Chicago geometry task can run on a native worker pinned to Ubuntu 26.04, using the existing SHA-verified Blender cache and 150-minute authoring budget. Blank input preserves existing queue lanes and budgets.

The new job reuses every existing public worker step. Validation rejects malformed tickets, other apps/processors, finish-only mode and multiple or ordinal slots. Its prompt requires that exact ticket, normal ownership, genuine affected models before the first source commit, all four source checks, both viewport checks and normal green PRs into dev. Exact tasks do not refill an unrelated scheduler slot. Nine selector cases are wired into the existing lane tests.

The required platform smoke exposed a live changelog CORS dependency. Make its documented offline-ingest fixture deterministic by allowing only the local fixture origin and aborting external requests. Every UI, error and layout assertion remains intact; launcher and shared-library code are unchanged.

Validation:
- All 11 native platform CI command groups passed, including the existing lane tests and nine new selector cases.
- Official smoke passed all 15 Chromium cases at 1280×800 and 390×780 in 14.766 seconds, with zero tolerated page errors. WebKit was unavailable and emitted its native skip warning.
- YAML/alias and patch checks passed. Official actionlint reports the same single pre-existing empty-effort-choice finding on baseline and proposed workflow; there are no new findings after declaring the real `ubuntu-26.04` runner label.
- All 337 tracked source bodies remained unchanged through the smoke; native process receipts closed with all children reaped. Hosted checks are still owed.

This draft is for owner-visible workflow review. No worker dispatch or platform-main merge has occurred. Chicago's older no-Blender-on-improve wording differs from the current platform native-authoring instructions; this job explicitly supplies the pinned native-authoring role and does not install Blender on the cloud host. Review and applicable hosted checks precede activation.

[Coherent source and preserved first-smoke failure](https://github.com/kevinrhaas/chicago-evidence/blob/b348b6a10826eb5f635b58cfc87f95e5ec83f4f8/evidence/native-geometry-worker-2026-11-03/coherent5-before-smoke-retry/RECOVERY.md). Final commit/smoke recovery proof will be added after publication.
