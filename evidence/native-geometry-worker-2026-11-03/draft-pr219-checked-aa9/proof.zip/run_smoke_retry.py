from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

R = Path('/workspace/polecat-platform')
O = Path(__file__).resolve().parent
frozen = json.loads((O/'CURRENT-FROZEN-SOURCE-BEFORE-SMOKE.json').read_bytes())
env = os.environ.copy()
env.update(PLAYWRIGHT_BROWSERS_PATH='/workspace/shared/playwright-browsers',
           PW_CHROMIUM='/usr/bin/chromium',
           PLAYWRIGHT_DISABLE_FORCED_CHROMIUM_PROXIED_LOOPBACK='1')

def source():
    return {name: hashlib.sha256((R/name).read_bytes()).hexdigest() for name in frozen['source']}

assert source() == frozen['source'], 'Source changed after qualification'
assert not (O/'SMOKE-OFFLINE-RETRY-REAPER.json').exists()
started = time.monotonic()
with (O/'SMOKE-OFFLINE-RETRY.log').open('xb') as log:
    result = subprocess.run([
        'python', '/workspace/shared/run-with-reaping.py',
        str(O/'SMOKE-OFFLINE-RETRY-REAPER.json'), '--',
        'timeout', '--signal=TERM', '--kill-after=10s', '120',
        'nice', '-n', '19', 'taskset', '-c', '2',
        'node', 'scripts/smoke-test.mjs'], cwd=R, env=env,
        stdout=log, stderr=subprocess.STDOUT)
receipt = json.loads((O/'SMOKE-OFFLINE-RETRY-REAPER.json').read_bytes())
text = (O/'SMOKE-OFFLINE-RETRY.log').read_text(errors='replace')
checks = [line for line in text.splitlines() if line.startswith('✓ ')]
unchanged = source() == frozen['source']
passed = (result.returncode == receipt['command_exit'] == 0
          and receipt['all_children_reaped'] and not receipt['leftover_cleanup']
          and receipt['interrupted_signal'] is None and unchanged
          and len(checks) == 15 and '✅ smoke test passed' in text)
out = {'status': 'ACTUAL_OFFICIAL_PLATFORM_SMOKE_PASS' if passed else 'NOT_QUALIFIED',
       'seconds': time.monotonic()-started, 'exit': result.returncode,
       'checks': checks, 'check_count': len(checks),
       'viewports': ['1280x800', '390x780'],
       'webkit_native_warning': next((line for line in text.splitlines() if 'webkit not installed' in line), None),
       'source_all_337_members_exact': unchanged, 'reaper': receipt,
       'scope': 'Unmodified fifteen UI/error/layout assertions; external requests aborted by the documented offline fixture. No hosted CI or worker dispatch claim.'}
(O/'SMOKE-OFFLINE-RETRY-RESULT.json').write_text(json.dumps(out, indent=2)+'\n')
print(json.dumps({'status': out['status'], 'seconds': out['seconds'], 'checks': len(checks), 'webkit_warning': out['webkit_native_warning']}), flush=True)
raise SystemExit(0 if passed else 1)
